"""Link with the phone app (v124).

Owner 2026-11-16: "the user should have the option to connect it to a desktop version (maybe through a QR code generator?) We dont want
to store logins, but will need some way to link the programs so that when a product is added, both the desktop and the mobile app are
updated accordingly" ... "Now how do I connect the two programs?"

How it works
- "Link phone" makes a link code once: "RK1.<channel>.<secret>" (24 random letters + 32 random bytes). The page shows it as a QR code; the
  phone app scans it. Nothing else is shared - no sign-ins, no passwords, no addresses.
- Both sides post their Amazon products (product code, name, price cap, Buy, Watch, kind, when it was last bought) to that private ntfy
  channel, ENCRYPTED with the secret (HMAC-SHA256 counter-mode stream + HMAC-SHA256 tag; Python's own library, the same on the phone), so
  the ntfy server sees only noise. Each side reads the channel every minute.
- A change wins over an older one (each product carries the time of its last change). A product removed on one side is removed on the other.
  At the first link the desktop's values win where both have the same product.
- ONE buyer: the desktop buys while it runs with Amazon auto-buy on; the phone buys only when the desktop has been silent for 45 minutes,
  is stopped, or has auto-buy off (the desktop tells the phone at Stop / Close). So the same product is never ordered twice.
- A product the other side BOUGHT is switched off here (one order per product).

The desktop side (reading the table / changing it) is given by app.py: READ() -> {asin: item}, APPLY(asin, new, old) -> True when done.

v147 (owner 2026-11-20: "The ntfy messages arent really needed anymore since the app can handle notifications"): the channel is now
on the Restalker relay (relay.py - one request a minute reads it; no daily limit). The posts are the same sealed posts as before - the
relay cannot read them either. ntfy.sh is still used, and only then, for
- a linked phone / tablet that runs an app from before 1.0.6 (it reads and posts only there): heard on ntfy without the mark "rl",
  it gets this PC's posts there too, for as long as it is heard (3 days). No device has to update for the link to keep working;
- the fast "buy now" signal (also sent on the relay: a phone hears it there within a minute if ntfy refuses it);
- every post, when the relay cannot be reached (and reading there too) - the link then works as it did before v147.
"""
import base64
import hashlib
import hmac
import json
import os
import re
import secrets
import threading
import time
import urllib.parse
import urllib.request
import zlib

VERSION = "v148"
SERVER = "https://ntfy.sh"
STATE_FILE = "phonelink.json"
ABC = "abcdefghijkmnpqrstuvwxyz23456789"
EVERY = 60                      # read the channel every minute
BEAT = 30 * 60                  # post the products at least every 30 minutes (the phone knows the desktop is alive)
INLINE_MAX = 3500               # a longer post goes as a file
TOMB_KEEP = 60 * 86400          # a removed product is remembered 60 days (so it does not come back)
PEND_RETRY = 5 * 60             # a change from the phone that could not be made here yet is tried again for 5 minutes
FIELDS = ("c", "b", "w")        # cap, Buy, Watch - what a change is
_lock = threading.RLock()
_st = {"started": False, "last_read": 0.0, "last_post": 0.0, "error": "", "got": 0, "sent": 0, "bad": 0, "applied": 0}
READ = None                     # app.py: () -> {asin: {"n","c","b","w","k","ba"}}
APPLY = None                    # app.py: (asin, new_item, old_item_or_None) -> bool
LOG = None
_wake = threading.Event()


# ------------------------------------------------------------------ the link code and the encryption (the same on the phone)

def _b64e(b):
    return base64.urlsafe_b64encode(b).decode().rstrip("=")


def _b64d(s):
    s = str(s)
    return base64.urlsafe_b64decode(s + "=" * (-len(s) % 4))


def make_code():
    return "RK1." + "".join(secrets.choice(ABC) for _ in range(24)) + "." + _b64e(secrets.token_bytes(32))


def parse_code(code):
    """-> (channel, secret bytes) or None."""
    m = re.fullmatch(r"RK1\.([a-z0-9]{24})\.([A-Za-z0-9_-]{43})", str(code or "").strip())
    if not m:
        return None
    try:
        sec = _b64d(m.group(2))
    except Exception:
        return None
    return ("rkl-" + m.group(1), sec) if len(sec) == 32 else None


def _prf(k, m):
    return hmac.new(k, m, hashlib.sha256).digest()


def lock_group(secret):
    """v141: the group code of this link's devices for the shared checkout lock (relay.py) - the phone app makes the same one
    (LinkCrypto.lockGroup): 32 hex letters of HMAC(secret, "rk-lock")."""
    return _prf(secret, b"rk-lock").hex()[:32]


def seal(secret, obj):
    pt = zlib.compress(json.dumps(obj, separators=(",", ":")).encode("utf-8"), 9)
    nonce = secrets.token_bytes(16)
    kenc, kmac = _prf(secret, b"rk-enc"), _prf(secret, b"rk-mac")
    ks = b"".join(_prf(kenc, nonce + i.to_bytes(4, "big")) for i in range((len(pt) + 31) // 32))
    ct = bytes(a ^ b for a, b in zip(pt, ks))
    return "rk1:" + _b64e(nonce + ct + _prf(kmac, nonce + ct)[:16])


def unseal(secret, text):
    """-> the object, or None (not ours / damaged / wrong secret)."""
    try:
        s = str(text or "").strip()
        if not s.startswith("rk1:"):
            return None
        raw = _b64d(s[4:])
        if len(raw) < 33:
            return None
        nonce, ct, tag = raw[:16], raw[16:-16], raw[-16:]
        kenc, kmac = _prf(secret, b"rk-enc"), _prf(secret, b"rk-mac")
        if not hmac.compare_digest(_prf(kmac, nonce + ct)[:16], tag):
            return None
        ks = b"".join(_prf(kenc, nonce + i.to_bytes(4, "big")) for i in range((len(ct) + 31) // 32))
        obj = json.loads(zlib.decompress(bytes(a ^ b for a, b in zip(ct, ks)), bufsize=1 << 16).decode("utf-8"))
        return obj if isinstance(obj, dict) else None
    except Exception:
        return None


# ------------------------------------------------------------------ the saved state

def _blank():
    return {"code": "", "dev": "", "since": "", "recs": {}, "peer": {}, "linkedAt": 0, "pubAt": 0, "dirty": False}


def load():
    try:
        with open(STATE_FILE, encoding="utf-8") as f:
            s = json.load(f)
        if isinstance(s, dict) and isinstance(s.get("recs"), dict):
            b = _blank()
            b.update(s)
            return b
    except FileNotFoundError:
        pass
    except Exception:
        try:
            os.replace(STATE_FILE, STATE_FILE + ".bad")          # a damaged file is set aside (the link must be made again)
        except OSError:
            pass
    return _blank()


def save(s):
    tmp = STATE_FILE + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(s, f)
    os.replace(tmp, STATE_FILE)


def linked(s=None):
    s = s or load()
    return bool(parse_code(s.get("code")))


def new_link():
    """A new code (the old link ends: a phone linked before must scan again)."""
    with _lock:
        s = _blank()
        s["code"] = make_code()
        s["dev"] = "d-" + secrets.token_hex(6)
        s["linkedAt"] = time.time()
        save(s)
    _log("[link] a new phone link code was made (scan it with the phone app).")
    _wake.set()
    return s["code"]


def unlink():
    with _lock:
        s = load()
        was = linked(s)
        if was:
            try:
                _post(s, bye=True)
            except Exception:
                pass
        save(_blank())
    if was:
        _log("[link] the phone link was removed by you (the phone keeps its products and buys on its own).")


# ------------------------------------------------------------------ merging

def _same(a, b):
    if (a or {}).get("b") != (b or {}).get("b") or (a or {}).get("w") != (b or {}).get("w"):
        return False
    if int((a or {}).get("q") or 1) != int((b or {}).get("q") or 1):
        return False
    try:
        return abs(float((a or {}).get("c") or 0) - float((b or {}).get("c") or 0)) < 0.005
    except Exception:
        return False


def _item_ok(it):
    return (isinstance(it, dict) and re.fullmatch(r"[A-Z0-9]{10}", str(it.get("a") or "")) and isinstance(it.get("t"), (int, float))
            and (it.get("g") or (isinstance(it.get("c"), (int, float)) and 0 < float(it["c"]) < 100000)))


SOFT = ("st", "pr", "ss", "ms", "tc", "sx", "im", "tu")      # v127: im = the product picture's address; v135: tu = its TCGplayer page
# v145 (the owner's phone, 2026-11-20 8:41 AM: "PC heard 16 h ago" although the PC was running): with some 36 products at 5 stores
# a stock or price moves about every 10 minutes, so this PC alone posted up to 144 times a day - more than half of the 250 messages a
# day the free message service gives a home for ALL its devices (the phones' hourly posts, the alerts and the reports share them). Now
# at most every 30 minutes (48 a day); a product YOU change still goes out at once, and a restock still reaches the phones within
# seconds over the fast channel.
SOFT_GAP = 30 * 60               # stock / price changes reach the phone within 30 minutes


def _sx_moved(a, b):
    k = lambda l: sorted((str(x.get("s")), str(x.get("st")), x.get("pr"), str(x.get("u") or "")) for x in (l or []) if isinstance(x, dict))
    return k(a) != k(b)


def merge(s, msg, now=None):
    """Takes in one post of the other side. -> [(asin, new, old)] to make here (a product added / changed / removed there)."""
    now = time.time() if now is None else now
    out = []
    if not isinstance(msg, dict) or msg.get("d") == s.get("dev"):
        return out
    srv = msg.get("_srv")
    s["peer"] = {"d": str(msg.get("d") or "")[:20], "r": str(msg.get("r") or "")[:10], "at": float(srv) if isinstance(srv, (int, float)) else now,
                 "sentAt": msg.get("at"),
                 "amz": bool(msg.get("amz")), "bye": bool(msg.get("bye")), "n": len(msg.get("items") or []), "rl": bool(msg.get("rl"))}
    # v127: every phone linked with this code (phone, tablet, ...): when heard, its app version, whether it updates itself
    if str(msg.get("r") or "") == "phone":
        ph = s.setdefault("phones", {})
        d0 = str(msg.get("d") or "")[:20]
        if d0 not in ph and not msg.get("rl"):
            s["dirty"] = True                              # (v147: a device that reads only ntfy is new here: it gets ours there at once)
        ph[d0] = {"at": s["peer"]["at"], "av": int(msg.get("av") or 0) if str(msg.get("av") or "0").isdigit() else 0,
                  "au": bool(msg.get("au")), "amz": bool(msg.get("amz")),
                  # v134 (owner 2026-11-17: "each mobile device should only control its own buying"): each device's own choice and name
                  "bm": str(msg.get("bm") or "pc") if str(msg.get("bm") or "pc") in MODES else "pc", "fo": msg.get("fo") is not False,
                  "nm": str(msg.get("nm") or "")[:40],
                  # v140: how that device's updates go in ("silent", "once", "always", "allow", "off") and its ntfy alerts channel
                  "um": str(msg.get("um") or "")[:10], "nt": str(msg.get("nt") or "")[:64],
                  "vn": str(msg.get("vn") or "")[:12],          # v145: its version as it shows it ("1.0.4")
                  "rl": bool(msg.get("rl")),                    # v147: it reads the relay (app 1.0.6 or newer) - nothing on ntfy for it
                  "nf": bool(msg.get("nf"))}                    # ... and it knows a device on this link that reads only ntfy
        _adopt_alerts(ph[d0]["nt"])
        for k in [k for k, v in ph.items() if now - float(v.get("at") or 0) > 30 * 86400][:50]:
            del ph[k]
    if msg.get("hi"):
        s["dirty"] = True                                  # the other side (re)started: it gets ours at once
        _buys_sent.pop("h", None)                          # (v135: with the purchase list)
        _th_sent.pop("h", None)                            # (v138: and the TCG price history)
    for it in (msg.get("items") or [])[:500]:
        if not _item_ok(it):
            continue
        a = it["a"]
        old = s["recs"].get(a)
        new = {"a": a, "n": str(it.get("n") or a)[:200], "c": float(it.get("c") or (old or {}).get("c") or 0), "b": bool(it.get("b")),
               "w": bool(it.get("w", True)), "k": str(it.get("k") or "other")[:20], "t": float(it["t"]), "g": bool(it.get("g")),
               "ba": max(float(it.get("ba") or 0), float((old or {}).get("ba") or 0)),
               "q": max(1, min(3, int(it.get("q") or (old or {}).get("q") or 1))) if str(it.get("q") or "1").isdigit() else 1}
        if old is None or new["t"] > float(old.get("t") or 0):
            if old is not None and old.get("g") and new.get("g"):
                old["t"] = new["t"]
                continue
            new["here"] = bool((old or {}).get("here"))
            new["pend"] = now
            # (which fields the other side changed: the change counts as made here once THOSE match - a later change made here then
            #  still goes out, v125: a Buy 3 chosen here right after the phone's change waited 5 minutes)
            new["pf"] = [k for k in ("c", "b", "w", "q") if old is None or old.get(k) != new.get(k)]
            s["recs"][a] = new
            if not (old is None and new["g"]):
                out.append((a, dict(new), dict(old) if old else None))
        elif float(it.get("ba") or 0) > float(old.get("ba") or 0):
            old["ba"] = float(it["ba"])                    # bought there (an older record otherwise): one order per product
            out.append((a, dict(old), dict(old)))          # (Buy goes off here; that change is posted as ours)
    return out


def scan(s, cur, now=None):
    """Our own products now ({asin: item}) against what was posted. Changes made here get the time now. -> True when something changed."""
    now = time.time() if now is None else now
    ch = False
    for a, it in cur.items():
        r = s["recs"].get(a)
        if r is not None and r.get("pend") and not r.get("g"):
            pf = r.get("pf") or ["c", "b", "w", "q"]
            done = all((abs(float(r.get(k) or 0) - float(it.get(k) or 0)) < 0.005) if k == "c" else
                       (int(r.get(k) or 1) == int(it.get(k) or 1)) if k == "q" else (r.get(k) == it.get(k)) for k in pf)
            if done:
                r.pop("pend", None)
                r.pop("pf", None)
                r["here"] = True
            elif now - float(r["pend"]) < PEND_RETRY:
                continue                                   # (the other side's change is still being made here)
            else:
                r.pop("pend", None)                        # could not be made here - ours wins from now
        if r is None or r.get("g") or not _same(r, it) or float(it.get("ba") or 0) > float(r.get("ba") or 0):
            s["recs"][a] = {"a": a, "n": str(it.get("n") or a)[:200], "c": float(it.get("c") or 0), "b": bool(it.get("b")),
                            "w": bool(it.get("w", True)), "k": str(it.get("k") or "other")[:20], "t": now, "g": False,
                            "ba": max(float(it.get("ba") or 0), float((r or {}).get("ba") or 0)), "here": True, "q": int(it.get("q") or 1)}
            ch = True
        else:
            r["here"] = True
        g = s["recs"][a]
        if it.get("gy") is not None and (g.get("gy"), g.get("gs")) != (it.get("gy"), it.get("gs")):
            g["gy"], g["gs"] = str(it.get("gy") or "")[:40], str(it.get("gs") or "")[:80]
        # v125: what the table shows now (stock, price, MSRP, TCG, the other stores) and the table's name - shown on the phone; not a
        # change of the product: posted with the next post, or within SOFT_GAP when the stock / price / name changed
        soft = {k: it.get(k) for k in SOFT if k in it}
        if soft:
            moved = any(g.get(k) != soft.get(k) for k in ("st", "pr", "im")) or _sx_moved(g.get("sx"), soft.get("sx"))
            g.update(soft)
            if moved:
                s["soft"] = True
        if it.get("n") and g.get("n") != it.get("n"):
            g["n"] = str(it["n"])[:200]
            s["soft"] = True
    for a, r in list(s["recs"].items()):
        if a in cur:
            continue
        if r.get("g"):
            if now - float(r.get("t") or 0) > TOMB_KEEP:
                del s["recs"][a]
            continue
        if r.get("pend") and now - float(r["pend"]) < PEND_RETRY:
            continue                                       # (an add from the other side not made here yet)
        if not r.get("here"):
            continue                                       # never was here: it is not "removed here"
        r.update({"g": True, "t": now})
        r.pop("pend", None)
        ch = True
    if ch:
        s["dirty"] = True
    return ch


BUYS_SENT = 100
BUYS_EVERY = 6 * 3600
_buys_sent = {}


def buys_for_phone(rows=None):
    """v135 (owner: 'the "bought" section of the app should include the data from the PC version as well ... time, device, price, store,
    and browser'): this PC's purchases (newest first, at most BUYS_SENT; crossed-out ones left out) - when, store, product, price, which
    browser bought it and the listing. No order numbers, names or addresses."""
    if rows is None:
        try:
            import amazon_buy
            rows = amazon_buy.purchases_list(BUYS_SENT)
        except Exception:
            rows = []
    out = []
    for r in rows[:BUYS_SENT]:
        try:
            t = float(r.get("t") or 0)
        except Exception:
            continue
        if t <= 1e9:
            continue
        pr = r.get("price")
        out.append({"t": round(t, 1), "s": str(r.get("store") or "")[:20], "n": str(r.get("product") or "")[:160],
                    "p": float(pr) if isinstance(pr, (int, float)) and 0 < pr < 100000 else None,
                    "by": str(r.get("by") or "")[:60], "a": str(r.get("asin") or "")[:30]})
    return out


_NT_RE = __import__("re").compile(r"^[A-Za-z0-9_-]{6,64}$")


def _adopt_alerts(nt):
    """v140 (owner 2026-11-18: "a way to connect the user to ntfy alerts. This code should be unique for each user, but identical to all
    devices used by the user if the devices are linked"): this PC has no phone alerts channel yet and a linked phone has one -> the PC
    uses that one (Phone: set up shows it), so the person has ONE alert code on every device. A PC that has its own keeps it (the phones
    take the PC's)."""
    try:
        import notify
        if nt and _NT_RE.match(nt) and not notify.phone_topic():
            with open(notify.PHONE_FILE, "w", encoding="utf-8") as f:
                f.write(nt)
            if LOG:
                LOG("[phone link] Phone alerts: this PC now uses the alert code your phone made (one code on every linked device).")
    except Exception:
        pass


def _alerts_topic():
    try:
        import notify
        return notify.phone_topic()
    except Exception:
        return ""


def post_obj(s, now=None, bye=False, hi=False, amz=True):
    now = time.time() if now is None else now
    items = [{k: r[k] for k in ("a", "n", "c", "b", "w", "k", "t", "g", "ba", "gy", "gs", "q") + SOFT if k in r} for r in s["recs"].values()]
    o = {"v": 1, "d": s["dev"], "r": "desktop", "at": now, "amz": bool(amz) and not bye, "items": items,
         "hand": buyer_mode(now, s) == "phone" and not bye,      # v134: not buying on Amazon because a phone / tablet buys instead
         "lk": True,           # v141: this PC claims every Amazon order on the shared checkout lock (the phones may race it - relay.py)
         "rl": 1 if _via["relay_ok"] else 0,   # v147: this PC reads and posts on the relay right now (a device that does too
                                               # needs nothing on ntfy; 0 = the relay is not reached: it finds this PC on ntfy)
         "nf": 1 if ntfy_peers(s, now) else 0,   # v147: a device that reads only ntfy is on this link (this PC heard it there) - the
         }                                     # devices that read the relay then read ntfy with every round too, and find it at once
    # v135: this PC's purchase list (the phone's Bought shows it) - only when it changed, a new phone said hello, or every 6 hours (the
    # phones keep the last one they got), so the usual small post stays small
    b = buys_for_phone()
    h = hashlib.sha256(json.dumps(b, sort_keys=True).encode()).hexdigest()[:16]
    if bye or h != _buys_sent.get("h") or now - _buys_sent.get("at", 0) > BUYS_EVERY:
        o["buys"] = b
        _buys_sent.update(h=h, at=now)
    # v138: the owner's own PC (master.py) - its linked phones / tablets have no purchase limit either
    try:
        import master
        if master.is_master():
            o["mst"] = True
    except Exception:
        pass
    # v138: the TCG price history this PC recorded, per product (Amazon code) - like the purchases, only when it changed or every 6 hours
    th = tcg_history_for_phone()
    h2 = hashlib.sha256(json.dumps(th, sort_keys=True).encode()).hexdigest()[:16]
    if th and (bye or h2 != _th_sent.get("h") or now - _th_sent.get("at", 0) > BUYS_EVERY):
        o["th"] = th
        _th_sent.update(h=h2, at=now)
    # v140: this PC's phone alerts channel (inside the sealed link only) - the linked phones / tablets use the same one
    nt = _alerts_topic()
    if nt:
        o["nt"] = nt
    if bye:
        o["bye"] = True
    if hi:
        o["hi"] = True
    if _set.get("p"):
        o["set"] = dict(_set["p"])          # v145: a device's buying choice changed on this PC (the device takes it itself)
    return o


_th_sent = {}
TH_ROWS = None          # app.py: () -> {Amazon code: product row key}


def tcg_history_for_phone():
    """v138: {Amazon code: [[day, price], ...]} - the TCG price history of each linked product (at most 120 days)."""
    try:
        import tcg_index
        hist = tcg_index.history_by_row()
        rows = TH_ROWS() if TH_ROWS else {}
        return {a: hist[k][-120:] for a, k in rows.items() if k in hist and len(hist[k]) >= 2}
    except Exception:
        return {}


# ------------------------------------------------------------------ the channel

def _http(url, data=None, headers=None, method=None, timeout=30):
    h = {"User-Agent": "Restalker/" + VERSION}
    h.update(headers or {})
    req = urllib.request.Request(url, data=data, headers=h, method=method)
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.status, r.read()


def _amz_on():
    try:
        import amazon_buy
        return bool(amazon_buy.enabled()) and amazon_buy._engine_client() is not None and buyer_mode() != "phone"
    except Exception:
        return False


# ------------------------------------------------------------------ v147: which way a post goes (the relay first; ntfy only when needed)
NTFY_PEER_DAYS = 3              # a device that reads only ntfy (an app before 1.0.6) gets this PC's posts there while heard this lately
NTFY_SLOW = 15 * 60             # with no such device known, ntfy is still read this often (one may link, or come back)
NTFY_HOT = 15 * 60              # ... and every round for this long after the Phone panel was opened / a new code was made
_via = {"relay_ok": False, "relay_posts": 0, "ntfy_posts": 0, "ntfy_read": 0.0, "hot": 0.0, "relay_lines": 0, "ntfy_lines": 0, "owed": 0.0,
        "seen": []}


def hot(now=None):
    """app.py: the Phone panel is open (someone may be scanning the code with an older app): ntfy is read every round for a while."""
    _via["hot"] = (time.time() if now is None else now) + NTFY_HOT


def ntfy_peers(s, now=None):
    """The linked phones / tablets that read only ntfy: heard in the last 3 days, and neither their last post nor their beat on the
    relay carries the mark "rl"."""
    now = time.time() if now is None else now
    pres = s.get("pres") or {}
    out = []
    for d, v in (s.get("phones") or {}).items():
        if now - float(v.get("at") or 0) > NTFY_PEER_DAYS * 86400:
            continue
        pr = pres.get(d) or {}
        if v.get("rl") or (pr.get("rl") and float(pr.get("at") or 0) >= float(v.get("at") or 0)):
            continue
        out.append(d)
    return out


def _ntfy_post(ch, body, http=None):
    http = http or _http
    if len(body) <= INLINE_MAX:
        st, _ = http(SERVER + "/" + ch, data=body.encode(), headers={"Title": "rk"}, method="POST")
    else:
        st, _ = http(SERVER + "/" + ch, data=body.encode(), headers={"Filename": "rk.txt"}, method="PUT")
    if not 200 <= int(st) < 300:
        raise OSError(f"the link server answered {st}")


def _post(s, bye=False, hi=False, http=None, now=None, rhttp=None, ntfy_ok=True):
    """One sealed post: on the relay, and on ntfy too when a linked device reads only there or the relay did not take it.
    ntfy_ok=False: few of the day's free messages are left and this post can wait there (it still goes on the relay)."""
    ch, sec = parse_code(s["code"])
    now = time.time() if now is None else now
    body = seal(sec, post_obj(s, now=now, bye=bye, hi=hi, amz=_amz_on()))
    import relay
    took = False
    try:
        took = relay.post_ch(ch, body, http=rhttp)
    except Exception:
        took = False
    if took:
        _via["relay_posts"] += 1
    old = ntfy_peers(s, now)
    if not took or (old and (ntfy_ok or bye)):
        try:
            _ntfy_post(ch, body, http)
            _via["ntfy_posts"] += 1
            _via["owed"] = 0.0
        except Exception:
            if not took:
                raise
            _via["owed"] = now                    # (the relay has it; the older device gets it with the next post that goes through)
            _st["error"] = "posting to an older linked app (message service): refused"
            _quota["ask"] = True
    elif old:
        _via["owed"] = now
    s["pubAt"] = now
    s["dirty"] = False
    s["soft"] = False
    _st["sent"] += 1
    _st["last_post"] = s["pubAt"]
    if _set.get("p") and float(_set["p"].get("at") or 0) <= now:
        _set["sent"] = _set.get("sent", 0) + 1
        if _set["sent"] >= 2:                # (sent with two posts: a phone that missed one still gets it; the newest change wins there)
            _set.pop("p", None)
            _set["sent"] = 0


def _fresh(text):
    """A sealed post not taken in yet this run (the same post may come by the relay and by ntfy)."""
    h = hashlib.sha256(str(text).encode()).hexdigest()[:20]
    if h in _via["seen"]:
        return False
    _via["seen"].append(h)
    del _via["seen"][:-400]
    return True


def _read_relay(s, rhttp=None, now=None):
    """v147: this PC's round with the relay - the link channel and its fast channel in one request (relay.sync, which also says "I am
    here" and reads the crowd's line). -> the other devices' posts (oldest first), or None when the relay was not reached."""
    ch, sec = parse_code(s["code"])
    import relay
    got = relay.sync({ch: str(s.get("rsince") or ""), ch + "-go": str(_go.get("rsince") or "")}, http=rhttp, now=now)
    if got is None:
        return None
    out = []
    for m in got.get(ch) or []:
        if str(m.get("id") or "").isdigit():
            s["rsince"] = str(m["id"])
        text = m.get("message") or ""
        o = unseal(sec, text)
        if o is None:
            _st["bad"] += 1
            continue
        if o.get("d") != s.get("dev") and _fresh(text):
            if isinstance(m.get("time"), (int, float)):
                o["_srv"] = float(m["time"])
            out.append(o)
            _via["relay_lines"] += 1
    for m in got.get(ch + "-go") or []:
        if str(m.get("id") or "").isdigit():
            _go["rsince"] = str(m["id"])
        _take_go(s, m, sec)
    return out


def _read(s, http=None):
    """-> the other side's posts on ntfy since the last read there (oldest first)."""
    ch, sec = parse_code(s["code"])
    http = http or _http
    since = s.get("since") or str(int(max(s.get("linkedAt") or 0, time.time() - 12 * 3600)))
    st, raw = http(SERVER + "/" + ch + "/json?poll=1&since=" + urllib.parse.quote(since), timeout=30)
    out = []
    for line in raw.decode("utf-8", "replace").splitlines():
        try:
            m = json.loads(line)
        except Exception:
            continue
        if m.get("event") != "message":
            continue
        s["since"] = str(m.get("id") or s.get("since") or "")
        text = m.get("message") or ""
        att = m.get("attachment") or {}
        if att.get("url") and str(att["url"]).startswith(SERVER + "/file/"):
            try:
                _, b = http(att["url"], timeout=30)
                text = b.decode("utf-8", "replace")
            except Exception:
                continue
        o = unseal(sec, text)
        if o is None:
            _st["bad"] += 1
            continue
        if o.get("d") != s.get("dev") and _fresh(text):
            if isinstance(m.get("time"), (int, float)):
                o["_srv"] = float(m["time"])              # (the ntfy server's clock: when it was posted)
            out.append(o)
            _via["ntfy_lines"] += 1
    return out


def cycle(now=None, http=None, read=None, apply=None, rhttp=None):
    """One round: read the phone's posts, make its changes here, post ours when something changed (or every 30 minutes).
    v147: read on the relay (rhttp: the tests' stand-in for it); on ntfy too when a device that reads only there is linked, the
    Phone panel is open, the relay was not reached, or 15 minutes have passed."""
    read, apply = read or READ, apply or APPLY
    with _lock:
        s = load()
        if not linked(s):
            return "not linked"
        now = time.time() if now is None else now
        first = not s.get("pubAt")
        if first and not s["recs"] and read:
            try:
                cur0 = read()
            except Exception as e:
                cur0 = None
                _st["error"] = "table: " + str(e)[:100]
            if cur0 is None:
                save(s)
                return "table not readable"
            for a, it in cur0.items():          # first link: the desktop's products as OLD records (t=2) - before anything from the
                s["recs"][a] = {"a": a, "n": str(it.get("n") or a)[:200], "c": float(it.get("c") or 0), "b": bool(it.get("b")),  # phone
                                "w": bool(it.get("w", True)), "k": str(it.get("k") or "other")[:20], "t": 2.0, "g": False,      # is taken in:
                                "ba": float(it.get("ba") or 0), "here": True, "q": int(it.get("q") or 1)}   # they win over the phone's first records (t=1)
            s["dirty"] = True
        msgs, err = [], ""
        try:
            rm = _read_relay(s, rhttp, now)
        except Exception as e:
            rm, err = None, "relay: " + str(e)[:80]
        _via["relay_ok"] = rm is not None
        old = ntfy_peers(s, now)
        # (a device that reads the relay says it heard one that reads only ntfy: look there with every round too)
        told = (any(v.get("nf") and v.get("rl") and now - float(v.get("at") or 0) < NTFY_PEER_DAYS * 86400 for v in (s.get("phones") or {}).values())
                or any(o.get("nf") for o in (rm or [])))
        ntfy_due = (rm is None or bool(old) or told or now < _via["hot"] or not s.get("phones") and now - float(s.get("linkedAt") or 0) < 86400 and
                    now - _via["ntfy_read"] >= 120 or now - _via["ntfy_read"] >= NTFY_SLOW)
        nm = None
        if ntfy_due:
            try:
                nm = _read(s, http)
                _via["ntfy_read"] = now
            except Exception as e:
                err = "reading: " + str(e)[:100]
        if rm is None and nm is None:
            _st["error"] = err or "reading: neither the relay nor the message service answered"
            save(s)
            return "read failed"
        msgs = sorted((rm or []) + (nm or []), key=lambda o: float(o.get("_srv") or o.get("at") or 0))
        _st["last_read"] = now
        _st["got"] += len(msgs)
        todo = []
        for m in msgs:
            todo += merge(s, m, now)
        # v142: the phones' heartbeats (every 5 min) read every 3rd round, not every minute - fewer requests to ntfy, which allows each
        # home internet address about one every 5 seconds for ALL its Restalker devices together (diagnostics of 2026-11-20: "429")
        # v147: those heartbeats come with the relay round now; ntfy's fast channel is read only for a device that posts only there
        # (an app before 1.0.6), or when the relay was not reached
        _go["round"] = _go.get("round", 0) + 1
        if _go["round"] % 3 == 1 and (old or rm is None):
            try:
                _read_go(s, http, now)
            except Exception as e:
                _go["error"] = str(e)[:100]
        for a, new, old in todo:
            try:
                ok = bool(apply(a, new, old)) if apply else False
            except Exception as e:
                ok = False
                _log(f"[link] {a}: the phone's change could not be made here: {str(e)[:120]}")
            if ok:
                _st["applied"] += 1
        if read:
            try:
                cur = read()
            except Exception as e:
                cur = None
                _st["error"] = "table: " + str(e)[:100]
            if cur is not None:
                scan(s, cur, now)
        # v145: while few of the day's free messages are left, what can wait (the half-hourly "still here" and stock / price news)
        # waits - a change you made, and the first post, still go out; the relay beat says "running" meanwhile (presence, below)
        # v147: every post goes on the relay (no daily limit). Only the copy for a device that reads only ntfy still waits when few
        # messages are left - and when the relay is not reached, the old rule holds for the whole post
        age = now - float(s.get("pubAt") or 0)
        spare = quota_may(KEEP_FOR_URGENT, now)
        # (a post an older linked app still has to get on ntfy - held back or refused there - goes again once messages are spare)
        owed = bool(_via["owed"]) and bool(old) and spare and now - _via["owed"] >= 600
        urgent = bool(s.get("dirty") or first or owed)
        routine = age >= BEAT or (s.get("soft") and age >= SOFT_GAP)
        if urgent or (routine and (_via["relay_ok"] or spare)):
            try:
                _post(s, hi=first, http=http, now=now, rhttp=rhttp, ntfy_ok=urgent or spare)
                if not _via["owed"]:
                    _st["error"] = ""
            except Exception as e:
                _st["error"] = "posting: " + str(e)[:100]
                if "429" in str(e):
                    _quota["ask"] = True          # (refused: ask the service how many are left and when the count starts again)
        elif routine:
            _st["held"] = _st.get("held", 0) + 1
        if http is None and (old or not _via["relay_ok"]):
            quota_refresh(now)                    # (the day's free messages matter only while something still goes through ntfy)
        save(s)
        return "ok"


def changed():
    """app.py: a product was changed in the table - post it soon (not wait a minute)."""
    _wake.set()


def goodbye():
    """Stop / Close Restalker: the phone takes over buying at once."""
    with _lock:
        s = load()
        if linked(s):
            try:
                _post(s, bye=True)
                save(s)
            except Exception:
                pass


def _round_wait():
    """Seconds until the next round: every minute - or as the relay asks (it stretches everyone's rounds alike when the free plan it
    runs on would be passed), but never slower while a device that reads only ntfy is linked."""
    try:
        import relay
        if _via["relay_ok"] and not ntfy_peers(load()):
            return max(EVERY, min(900, relay.next_wait()))
    except Exception:
        pass
    return EVERY


def _loop():
    time.sleep(20)
    while True:
        try:
            cycle()
        except Exception as e:
            _st["error"] = str(e)[:120]
        try:                                                # v145: "I am here" to the relay every 15 minutes (presence) - also while
            if linked():                                    # crowd sharing is off; relay.heartbeat keeps its own 15 minutes
                import relay
                relay.heartbeat()
        except Exception:
            pass
        _wake.wait(_round_wait())
        if _wake.is_set():
            _wake.clear()
            time.sleep(3)                                   # (several clicks in a row go out as one post)


def start(log=None):
    global LOG
    LOG = log
    if not _st["started"]:
        _st["started"] = True
        threading.Thread(target=_loop, daemon=True, name="phonelink").start()


def _log(m):
    if LOG:
        try:
            LOG(m)
        except Exception:
            pass


def info():
    """For the page: linked?, the code (for the QR), the phone last heard, counts."""
    s = load()
    p = s.get("peer") or {}
    q = quota_now()
    return {"linked": linked(s), "code": s.get("code") if linked(s) else "", "phoneSeen": p.get("at") or 0, "phone": bool(p),
            "products": sum(1 for r in s["recs"].values() if not r.get("g")), "error": _st["error"], "lastRead": _st["last_read"],
            "lastPost": _st["last_post"], "mode": buyer_mode(s=s), "devices": devices(s),
            # v145: the day's free messages (the service's own count for this internet address), when known
            "quota": ({"left": q["left"], "limit": q["limit"], "reset": q["reset"]} if q else None),
            # v147: the link runs on the relay; "old" = linked devices that still read only the message service (an app before 1.0.6)
            "relay": bool(_via["relay_ok"]), "old": [(s.get("phones") or {}).get(d, {}).get("nm") or d[-4:] for d in ntfy_peers(s)]}


def phones(days=3):
    """v127: the linked phones / tablets heard in the last [days]: [{d, at, av, au}]."""
    s = load()
    if not linked(s):
        return []
    t = time.time()
    return [dict(v, d=k) for k, v in (s.get("phones") or {}).items() if t - float(v.get("at") or 0) < days * 86400]


def status():
    s = load()
    if not linked(s):
        return "phone link (v124): not linked"
    p = s.get("peer") or {}
    seen = f"phone last heard {int((time.time() - p['at']) / 60)} min ago" if p.get("at") else "phone not heard yet (scan the QR code with the app)"
    ph = s.get("phones") or {}
    if ph:
        um = {"silent": " updates itself (no tap)", "once": " asks once more (Install), then by itself", "always": " asks every update (Android 11)",
              "allow": " may not install yet (Allow)", "off": " updating by itself off"}
        seen += "; devices: " + ", ".join(f"{k[:6]} app code {v.get('av') or '?'}{um.get(v.get('um') or '', ' updates itself' if v.get('au') else '')} heard {int((time.time() - float(v.get('at') or 0)) / 60)} min ago"
                                          for k, v in sorted(ph.items(), key=lambda kv: -float(kv[1].get('at') or 0))[:5])
    return (f"phone link (v124): linked; {seen}; {sum(1 for r in s['recs'].values() if not r.get('g'))} products shared; posts sent "
            f"{_st['sent']}, read {_st['got']}, changes made here {_st['applied']}, unreadable {_st['bad']}"
            + (f"; last problem: {_st['error']}" if _st["error"] else "")
            + f"; who buys on Amazon (v134, each device its own): this PC {'does not buy (a phone / tablet buys instead)' if buyer_mode(s=s) == 'phone' else 'buys'}; "
              + "; ".join(f"{x['name']}: {x['mode']}{'' if x['alive'] else ' (not heard lately)'}" for x in devices(s)) + f"; fast signals sent {_go['sent']}, "
              f"results sent {_go['res']}, phone heartbeats {len(_go['hb'])}" + (f", last: {_go['last']}" if _go['last'] else "")
            + (f", problem: {_go['error']}" if _go['error'] else "")
            + f"; the link's way (v147): relay {'reached' if _via['relay_ok'] else 'NOT reached - everything over the message service'}, "
              f"{_via['relay_posts']} posts and {_via['relay_lines']} read there; message service: {_via['ntfy_posts']} posts, {_via['ntfy_lines']} read, "
              f"devices that read only there: {len(ntfy_peers(s))}; buy-now signals: {_go.get('relay', 0)} on the relay, {_go.get('ntfy', 0)} on the doorbell; this PC's messages shown by the apps: {_go.get('alerts', 0)}"
            + "; " + quota_text() + "; presence (relay beats): "
            + (", ".join(f"{v.get('nm') or d[-4:]} {v.get('vn') or '?'} {int((time.time() - float(v.get('at') or 0)) / 60)} min ago"
                         for d, v in sorted((s.get("pres") or {}).items(), key=lambda kv: -float(kv[1].get("at") or 0))[:6]) or "none yet"))


# ------------------------------------------------------------------ v132: who buys on Amazon, and the fast "go" channel
# (owner 2026-11-17: "When linked, there should be an option to buy only on desktop, buy only on app (so the desktop is doing the searching
# work but pushing purchasing to the app for user input/review) or both"). v134: EACH phone / tablet makes its own choice (sent with its
# posts and heartbeats; nothing is echoed). pc = that device does not buy (this PC buys on Amazon); phone = this PC watches and
# tells the phone within seconds (it does not check out on Amazon itself); both = both check out - the phone presses Place your order only
# after this PC said its own try FAILED (one order per product). A second channel (<link channel>-go, sealed the same way) carries:
#   from here: {"go": {"a": asin, "pr": price}} (a restock under the cap) and {"res": {"a": asin, "k": started|bought|failed|busy}}
#   from a phone: {"hb": 1} every 5 minutes (it is listening) - without a heartbeat for 20 minutes the mode falls back to pc.
MODES = ("pc", "phone", "both")
MODE_ALIVE = 20 * 60
GO_GAP = 20                      # one fast signal per product every 20 s at most
_go = {"sent": 0, "res": 0, "hb": {}, "last": "", "error": "", "at": {}, "since": ""}


BOTH_ALIVE = 75 * 60             # v144: a phone that buys WITH this PC (or not at all) is heard by its hourly link post


def _alive(s, now):
    """v134: the phones / tablets heard lately (their link post or their go-channel heartbeat): {id: record}.
    v144 (2026-11-20: ntfy.sh allows each home internet address 250 messages a day for all its Restalker devices together - the phones'
    heartbeats, every 5 minutes, were 288 a day EACH and used it up by morning; then the link, the reports and the phone messages failed):
    only a phone that buys INSTEAD of this PC still sends the 5-minute heartbeat (20 minutes without it: this PC buys again); the others
    count as there while their hourly link post is fresh (75 minutes)."""
    out = {}
    for d, v in (s.get("phones") or {}).items():
        lim = MODE_ALIVE if v.get("bm") == "phone" else BOTH_ALIVE
        if now - max(float(v.get("at") or 0), float(_go["hb"].get(d) or 0)) < lim:
            out[d] = v
    return out


def buyer_mode(now=None, s=None):
    """v134 (each device its own choice): -> "phone" when a device that may buy chose to buy INSTEAD of this PC (this PC then does not check
    out on Amazon); "both" when one chose to buy WITH it (it gets this PC's checkout news); otherwise "pc". Only devices heard in the last
    20 minutes count (without them this PC buys again by itself)."""
    try:
        s = s or load()
        if not linked(s):
            return "pc"
        now = time.time() if now is None else now
        mine = [v.get("bm") for v in _alive(s, now).values() if v.get("amz")]
        return "phone" if "phone" in mine else "both" if "both" in mine else "pc"
    except Exception:
        return "pc"


def devices(s=None, now=None):
    """v134: every linked phone / tablet for the page and the reports: [{id, name, mode, takes_over, app, heard_min, alive}].
    v145 (owner 2026-11-20: "the pc version does not appear to have an option to see linked devices"): also its version as it shows
    it, "heard" = its newest sign of life (a post on the link, its heartbeat on the fast channel, or its beat on the Restalker relay),
    "sync_min" = minutes since its last post on the link alone (-1 = none yet), "running" = heard within 35 minutes; a device known
    only by its beat (linked, its first post not here yet) is listed too (mode "")."""
    s = s or load()
    now = time.time() if now is None else now
    al = _alive(s, now)
    pres = s.get("pres") or {}
    out = []
    for d, v in sorted((s.get("phones") or {}).items(), key=lambda kv: -float(kv[1].get("at") or 0)):
        pr = pres.get(d) or {}
        post = float(v.get("at") or 0)
        heard = max(post, float(_go["hb"].get(d) or 0), float(pr.get("at") or 0))
        if now - heard > 30 * 86400:
            continue
        vn = pr.get("vn") if (pr.get("vn") and float(pr.get("at") or 0) >= post) else (v.get("vn") or "")
        out.append({"id": d, "name": v.get("nm") or pr.get("nm") or ("phone / tablet " + d[-4:]), "mode": v.get("bm") or "pc",
                    "takes_over": v.get("fo") is not False, "app": v.get("av") or 0, "heard_min": int((now - heard) / 60), "alive": d in al,
                    "may_buy": bool(v.get("amz")), "version": str(vn or ""), "sync_min": int((now - post) / 60) if post else -1,
                    "running": now - heard < PRES_FRESH})
    for d, pr in sorted(pres.items()):
        if d in (s.get("phones") or {}) or pr.get("r") == "desktop" or d == s.get("dev") or now - float(pr.get("at") or 0) > 30 * 86400:
            continue
        out.append({"id": d, "name": pr.get("nm") or ("phone / tablet " + d[-4:]), "mode": "", "takes_over": True, "app": 0,
                    "heard_min": int((now - float(pr.get("at") or 0)) / 60), "alive": False, "may_buy": False, "version": str(pr.get("vn") or ""),
                    "sync_min": -1, "running": now - float(pr.get("at") or 0) < PRES_FRESH})
    return out


# ------------------------------------------------------------------ v145: presence, a device's choice set from here, the day's messages
# (owner 2026-11-20: "In linked devices, it's showing old data for my pc and tablet. Both of these devices are currently active, so there
# may be a communication problem. Confirm the devices can see and report active links. Similarly, the pc version does not appear to have
# an option to see linked devices")
#
# What was wrong: "heard" was only the time of a device's last post on the link channel, and the free message service (ntfy.sh) refuses
# a home's posts once its 250 a day are used - a PC that was running then looked silent for hours on the phone, and the phones here.
# - Presence: with its 15-minute heartbeat to the Restalker relay (relay.py - no message is used) each linked device gives its link
#   group (lock_group: made from the link secret, no one else can guess it) and a few words about itself - id, kind, name, version -
#   SEALED with the link secret (the relay sees only noise), and gets the other devices' beats back. "Heard" is the newest sign of life.
#   Who buys still goes by the link channel and the fast channel alone, as before.
# - The day's messages: the service says how many are left and when the count starts again (GET /v1/account - asking uses none). With
#   few left, what can wait waits (cycle); the page says so when the link is behind.
# - Phone ▾ lists every linked device and can change its buying choice: the change travels sealed in the next post ("set"); the device
#   takes it itself (phone app 1.0.4 or newer; the newest change wins).
PRES_FRESH = 35 * 60             # a device's beat on the relay (every 15 minutes) counts as "running now" this long
KEEP_FOR_URGENT = 40             # the half-hourly post waits when no more than this many of the day's messages are left
KEEP_FOR_NORMAL = 100            # automatic reports (report.py) wait when no more than this many are left
QUOTA_URL = SERVER + "/v1/account"
_quota = {"q": None, "asked": 0.0, "ask": False}
_set = {}


def who(s=None):
    """What this PC says about itself on the relay: sealed with the link secret (None when not linked)."""
    s = s or load()
    p = parse_code(s.get("code"))
    if not p:
        return None
    try:
        import updater
        vn = updater.shown_version()
    except Exception:
        vn = VERSION
    return seal(p[1], {"d": s.get("dev") or "", "r": "desktop", "nm": "PC", "vn": str(vn)[:12], "rl": 1})    # (v147: rl - it reads the relay)


def take_presence(beats, now=None):
    """The other devices' beats from the relay: [(what it said - sealed, when the relay heard it in seconds)]. Anything not sealed with
    THIS link's secret is ignored. -> how many were taken."""
    now = time.time() if now is None else now
    with _lock:
        s = load()
        p = parse_code(s.get("code"))
        if not p:
            return 0
        pres = dict(s.get("pres") or {})
        n = 0
        for w, at in list(beats or [])[:40]:
            o = unseal(p[1], w)
            try:
                at = float(at)
            except Exception:
                continue
            if not o or at <= 0 or at > now + 600:
                continue
            d = str(o.get("d") or "")[:20]
            if not d or d == s.get("dev"):
                continue
            if d not in pres or at >= float(pres[d].get("at") or 0):
                pres[d] = {"r": str(o.get("r") or "")[:10], "nm": str(o.get("nm") or "")[:40], "vn": str(o.get("vn") or "")[:12], "at": at,
                           "rl": bool(o.get("rl"))}
            n += 1
        for d in [d for d, v in pres.items() if now - float(v.get("at") or 0) > 30 * 86400]:
            del pres[d]
        if pres != (s.get("pres") or {}):
            s["pres"] = pres
            save(s)
        return n


def set_for(target, bm, takes_over=True, now=None):
    """Phone ▾ on this PC: a linked phone's / tablet's buying choice changed here -> True. It goes out sealed with the next post (at
    once); the device takes it itself."""
    now = time.time() if now is None else now
    if bm not in MODES:
        return False
    with _lock:
        s = load()
        if not linked(s) or target not in (s.get("phones") or {}):
            return False
        _set["p"] = {"d": str(target)[:20], "bm": bm, "fo": bool(takes_over), "at": now}
        _set["sent"] = 0
        s["phones"][target]["bm"] = bm                      # (shown at once; the device's own next post confirms it)
        s["phones"][target]["fo"] = bool(takes_over)
        s["dirty"] = True
        save(s)
    _log(f"[link] {s['phones'][target].get('nm') or target}: set to {bm}" + ("" if bm != "pc" else (", takes over if this PC stops" if takes_over else ", never buys"))
         + " (changed on this PC).")
    _wake.set()
    return True


def quota_parse(text, now=None):
    """The message service's answer -> {"limit", "left", "reset" (seconds), "at"} or None."""
    now = time.time() if now is None else now
    try:
        d = json.loads(text)
        lim = int(d["limits"]["messages"])
        left = int(d["stats"]["messages_remaining"])
        if lim <= 0 or left < 0:
            return None
        return {"limit": lim, "left": min(left, lim), "reset": float(d["stats"].get("reset_at") or 0), "at": now}
    except Exception:
        return None


def quota_now(now=None):
    """What is known and still true: asked within the last 6 hours, and the count has not started again since."""
    now = time.time() if now is None else now
    q = _quota.get("q")
    if not q or now - q["at"] > 6 * 3600 or (q["reset"] and now >= q["reset"]):
        return None
    return q


def quota_may(keep, now=None):
    """May something that can wait be sent now? keep = how many are kept back for what cannot wait. Not known = yes."""
    q = quota_now(now)
    return True if q is None else q["left"] > keep


def quota_refresh(now=None, http=None, force=False):
    """Asks the service (no message used): every 30 minutes while linked, and at once (at most every 5 minutes) after a refusal."""
    now = time.time() if now is None else now
    gap = 300 if (force or _quota.get("ask")) else 1800
    if now - _quota["asked"] < gap:
        return _quota.get("q")
    _quota["asked"] = now
    _quota["ask"] = False
    try:
        st, raw = (http or _http)(QUOTA_URL, timeout=15)
        q = quota_parse(raw.decode("utf-8", "replace"), now)
        if q:
            _quota["q"] = q
    except Exception:
        pass
    return _quota.get("q")


def quota_text(now=None):
    q = quota_now(now)
    if not q:
        return "message service: not asked yet (or its answer is old)"
    return (f"message service (ntfy, per internet address): {q['left']} of {q['limit']} messages left today, the count starts again "
            f"{time.strftime('%m-%d %H:%M', time.localtime(q['reset'])) if q['reset'] else '?'}; routine posts held back so far: {_st.get('held', 0)}")


def _go_post(obj, http=None, rhttp=None):
    """v147: on ntfy (a phone that holds its fast connection open hears it within a second - the doorbell) AND on the relay (it reads
    that every minute: the signal still arrives when ntfy refuses it). The phone takes the same signal once."""
    s = load()
    if not linked(s):
        return False
    ch, sec = parse_code(s["code"])
    o = dict(obj, v=1, d=s["dev"], r="desktop", at=time.time())
    body = seal(sec, o)
    ok = [False, False]

    def to_relay():
        try:
            import relay
            ok[0] = relay.post_ch(ch + "-go", body, http=rhttp, timeout=8.0)
        except Exception:
            pass
    t = threading.Thread(target=to_relay, daemon=True, name="link-go-relay")
    t.start()
    try:
        st, _ = (http or _http)(SERVER + "/" + ch + "-go", data=body.encode(), headers={"Title": "rk"}, method="POST", timeout=15)
        ok[1] = 200 <= int(st) < 300
    except Exception as e:
        _go["error"] = "doorbell (message service): " + str(e)[:80]
    t.join(10)
    _go["relay"] = _go.get("relay", 0) + (1 if ok[0] else 0)
    _go["ntfy"] = _go.get("ntfy", 0) + (1 if ok[1] else 0)
    return ok[0] or ok[1]


def go(asin, price=None, http=None, now=None, wait=False, rhttp=None):
    """amazon_buy: an Amazon restock at or under the cap of a product set to Buy -> the phone hears it within seconds (mode phone / both)."""
    now = time.time() if now is None else now
    if buyer_mode(now) == "pc":
        return "pc"
    if now - _go["at"].get(asin, 0) < GO_GAP:
        return "repeat"
    _go["at"][asin] = now

    def send():
        try:
            if _go_post({"go": {"a": asin, "pr": price}}, http, rhttp):
                _go["sent"] += 1
                _go["last"] = f"{time.strftime('%H:%M:%S')} go {asin}"
        except Exception as e:
            _go["error"] = str(e)[:100]
    if wait:
        send()
    else:
        threading.Thread(target=send, daemon=True, name="link-go").start()
    return "sent"


_al = []


def app_peers(s=None, now=None):
    """The linked phones / tablets that read the relay (app 1.0.6 or newer), heard in the last 3 days."""
    s = s or load()
    now = time.time() if now is None else now
    old = set(ntfy_peers(s, now))
    return [d for d, v in (s.get("phones") or {}).items() if d not in old and now - float(v.get("at") or 0) < NTFY_PEER_DAYS * 86400]


def alert(title, msg, kind="", link=None, rhttp=None, now=None):
    """v147 (notify.py): this PC's message for the linked Restalker apps - sealed, on the relay's fast channel (they read it every
    minute and show it as their own notification, unless ntfy already shows it on that phone). -> True when the relay took it.
    At most 20 in 10 minutes."""
    now = time.time() if now is None else now
    s = load()
    if not linked(s) or not app_peers(s, now):
        return False
    _al[:] = [x for x in _al if now - x < 600]
    if len(_al) >= 20:
        return False
    _al.append(now)
    ch, sec = parse_code(s["code"])
    o = {"v": 1, "d": s["dev"], "r": "desktop", "at": now,
         "al": {"ti": str(title or "")[:200], "tx": str(msg or "")[:1500], "k": str(kind or "")[:20], "u": str(link or "")[:500] if str(link or "").startswith("https://") else ""}}
    try:
        import relay
        ok = relay.post_ch(ch + "-go", seal(sec, o), http=rhttp, timeout=8.0)
    except Exception:
        ok = False
    _go["alerts"] = _go.get("alerts", 0) + (1 if ok else 0)
    return ok


# the PC's checkout events -> what the phone needs to know in mode "both"
_RES = {"CHECKOUT": "started", "BOUGHT": "bought", "OLDBOUGHT": "bought", "SUBMITTED": "bought", "UNKNOWN": "bought",
        "FAILED": "failed", "NOTFOUND": "failed", "CHECK": "failed", "ACTION": "failed", "APPROVE": "busy", "CVV": "busy"}


def result(asin, kind, http=None, wait=False, rhttp=None):
    """amazon_buy._event: in mode both, every Amazon checkout start / end of this PC goes to the phone (it holds Place your order until then)."""
    k = _RES.get(str(kind or ""))
    if not k or not re.fullmatch(r"B[0-9A-Z]{9}", str(asin or "")) or buyer_mode() != "both":
        return ""

    def send():
        try:
            if _go_post({"res": {"a": asin, "k": k}}, http, rhttp):
                _go["res"] += 1
                _go["last"] = f"{time.strftime('%H:%M:%S')} {k} {asin}"
        except Exception as e:
            _go["error"] = str(e)[:100]
    if wait:
        send()
    else:
        threading.Thread(target=send, daemon=True, name="link-res").start()
    return k


def _read_go(s, http=None, now=None):
    """The phones' heartbeats on the go channel (read with each round)."""
    ch, sec = parse_code(s["code"])
    http = http or _http
    since = _go["since"] or str(int((time.time() if now is None else now) - 30 * 60))
    st, raw = http(SERVER + "/" + ch + "-go/json?poll=1&since=" + urllib.parse.quote(since), timeout=20)
    for line in raw.decode("utf-8", "replace").splitlines():
        try:
            m = json.loads(line)
        except Exception:
            continue
        if m.get("event") != "message":
            continue
        _go["since"] = str(m.get("id") or _go["since"])
        _take_go(s, m, sec)


def _take_go(s, m, sec):
    """One line of the fast channel (from ntfy or from the relay): a phone's heartbeat."""
    o = unseal(sec, m.get("message") or "")
    if not o or o.get("r") != "phone" or o.get("d") == s.get("dev"):
        return
    if o.get("hb"):
        d0 = str(o.get("d") or "")[:20]
        _go["hb"][d0] = max(float(_go["hb"].get(d0) or 0), float(m.get("time") or time.time()))
        v = s.setdefault("phones", {}).get(d0)                 # v134: its own choice, as it says with each heartbeat
        if v is not None and str(o.get("bm") or "") in MODES:
            v["bm"] = o["bm"]
