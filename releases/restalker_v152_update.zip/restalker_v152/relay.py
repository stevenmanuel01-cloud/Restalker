"""v141: the Restalker relay (a small Cloudflare server - relay/ in the release repository) from the PC.

- The race to checkout (owner, 2026-11-19: "Its a race to checkout, so whichever happens first is the winner and should lock the product
  normally"): right before Place order on Amazon, the PC claims the product for the owner's linked devices. The first device to claim it
  orders; the others stop. The group code is made from the link secret (no one else can guess it); the phone app makes the same one.
  When the relay cannot be asked, the rules before v141 decide (the PC goes first; never two orders).
- "Active now": a heartbeat every 15 minutes (the live count of working devices).
- Problem reports of a PC that is not the owner's go here (compiled once a day on Discord) - the owner's PC sends its own directly.
- v145: presence of one person's linked devices (who is running now), with the heartbeat.
- The Discord invite.
- v147 (owner 2026-11-20: "The ntfy messages arent really needed anymore since the app can handle notifications ... the PC version
  should still be sending alerts to a users phone if they dont have a linked app"): what this PC and its linked phones / tablets tell
  each other (phonelink.py - sealed there, the relay cannot read it) and the crowd's sightings (crowd.py) go through the relay, not
  through the free message service - that service allows a home 250 messages a day for all its devices together, and the linked
  devices' updates alone used them up. ONE request a minute (sync) says "I am here", brings the active count, the linked devices'
  signs of life, and everything new on the channels this PC reads; the answer says when to ask again. ntfy stays for alerts to a
  phone without the Restalker app, for linked devices that still run an older version, and as the doorbell for "buy now".
Nothing here can buy anything; nothing personal is sent (product codes, a random device code, the report text).
"""
import json
import os
import threading
import time
import urllib.error
import urllib.parse
import urllib.request

VERSION = "v152"
BASE = "https://restalker-relay.restalker.workers.dev"
LOG = None
_st = {"active": -1, "active_at": 0.0, "error": "", "claims": 0, "won": 0, "lost": 0, "unreachable": 0, "beat_at": 0.0, "invite": None,
       "invite_at": 0.0}
_held = {}              # asin -> when this PC claimed it
_lock = threading.Lock()


def _call(method, path, body=None, timeout=6.0, http=None, raw=None):
    """raw: a text sent as it is (a sealed post) instead of a JSON body."""
    if http is not None:
        return http(method, path, raw if raw is not None else body)
    if os.environ.get("RK_TEST_NOEXIT"):                 # (test runs never talk to the real relay)
        return None
    data = raw.encode() if raw is not None else json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(BASE + path, data=data, method=method,
                                 headers={"Content-Type": "text/plain" if raw is not None else "application/json", "User-Agent": "Restalker/" + VERSION})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            _st["error"] = ""
            return json.loads(r.read().decode() or "{}")
    except urllib.error.HTTPError as e:
        _st["error"] = f"HTTP {e.code}"
        try:
            return json.loads(e.read().decode() or "{}")
        except Exception:
            return None
    except Exception as e:
        _st["error"] = str(e)[:80]
        return None


# ---- v151: ONE connection to the relay, held open ("near zero latency") ---------------------------------------------------------------
# Owner, 2026-11-24: "prepare everything for a full scale launch ... the capacity to receive thousands of users as well as send messages
# back to them in near zero latency". Until v150 this PC asked the relay once a minute; a line waited up to a minute, and every device
# cost the relay 1,440 requests a day (its free plan: 100,000 a day for everybody together - about 60 linked devices).
# Now the PC opens one WebSocket (wsclient.py) and keeps it open. The relay pushes each new line the moment it has it: a crowd sighting
# goes straight to crowd.py, the buy-now doorbell straight to phonelink.py, a linked device's post wakes the link round at once.
# This PC's own posts and sightings go up the same connection. Asking the old way stays as the fallback - whenever the connection
# is down (it is opened again by itself: after 5 s, 10 s ... at most 5 minutes) - and as a check every few hours while it is up.
WS_URL = None            # tests: another relay's address (ws://...); None = the real one
WS_PING = 50.0           # a protocol ping this often keeps routers from dropping the idle connection. Cloudflare's edge answers it
                         # itself: the relay is not woken and it is not counted against the free plan (a text "ping" would be)
WS_QUIET = 150.0         # nothing heard for this long (not even the answer to a ping) -> the connection is opened anew
WS_HERE = 900.0          # LINKED only: "I am here" with this PC's sign of life for its linked devices (as the old heartbeat: 15 min).
                         # The active count needs no asking: the relay sends it down the connection whenever it changes.
_ws = {"ws": None, "up": False, "hello": 0.0, "heard": 0.0, "thread": None, "connects": 0, "fails": 0, "lines": 0, "sent": 0, "error": "",
       "since_up": 0.0, "safety": 21600, "http_at": 0.0, "stop": False, "here_at": 0.0, "down_at": 0.0, "top": 0}
_ws_buf = {}             # link channel -> lines pushed and not yet taken by the link round
_ws_ack = []             # answers ("ok" / "no") to what this PC sent, in order
_ws_send_lock = threading.Lock()
_ws_cv = threading.Condition()


def ws_up(now=None):
    """The connection is open, the relay said hello on it, and it was heard from lately."""
    now = time.time() if now is None else now
    return bool(_ws["up"] and _ws["hello"] and now - _ws["heard"] < WS_QUIET)


def _ws_url():
    base = WS_URL or (None if os.environ.get("RK_TEST_NOEXIT") else BASE.replace("https://", "wss://").replace("http://", "ws://"))
    if not base:
        return None
    q = {"c": device()}
    cursors = []
    try:
        import phonelink
        g = group()
        chs = phonelink.channels()
        if g and chs:
            q["g"], q["ch"] = g, ",".join(chs)
            cursors += phonelink.cursors()
    except Exception:
        pass
    crowd_on = False
    try:
        import crowd
        crowd_on = crowd.on()
        if crowd_on:
            cursors.append(crowd.relay_since())
    except Exception:
        pass
    if not crowd_on and "g" not in q:
        return None                                 # (sharing off and nothing linked: this PC has nothing to hear from the relay)
    nums = [int(x) for x in cursors if str(x).isdigit()]
    if nums and len(nums) == len(cursors):
        q["s"] = str(min(nums))                     # (the oldest place any reader is at: nothing is missed, a line twice is dropped by its id)
    return base + "/v1/ws?" + urllib.parse.urlencode(q)


def _ws_line(o, now):
    ch = str(o.get("ch") or "")
    _ws["lines"] += 1
    if str(o.get("id") or "").isdigit():
        _ws["top"] = max(_ws["top"], int(o["id"]))
    if ch == "crowd":
        try:
            import crowd
            if crowd.on():
                last = crowd.relay_since()
                if not (str(last).isdigit() and str(o.get("id") or "").isdigit() and int(o["id"]) <= int(last)):
                    threading.Thread(target=crowd.relay_take, args=([o],), daemon=True, name="crowd-relay-take").start()
        except Exception:
            pass
        return
    how = False
    try:
        import phonelink
        how = phonelink.ws_line(ch, o)              # (a phone's heartbeat is noted at once; "quiet" = no round needs to start for it)
    except Exception:
        pass
    if how is True:
        return
    with _lock:
        _ws_buf.setdefault(ch, []).append(o)
        del _ws_buf[ch][:-400]
    if how != "quiet":
        try:
            import phonelink
            phonelink.wake_now()                    # the link round reads it now (not at the next minute)
        except Exception:
            pass


def _ws_take(text, now):
    _ws["heard"] = now
    if text == "pong":
        return
    try:
        o = json.loads(text)
    except Exception:
        return
    if not isinstance(o, dict):
        return
    t = o.get("t")
    if t == "m":
        _ws_line(o, now)
    elif t == "hello":
        _ws["hello"] = now
        try:
            _ws["safety"] = max(600, min(86400, int(o.get("next") or 21600)))
        except Exception:
            _ws["safety"] = 21600
        _took(o, now)
        _st["sync_at"] = now
        _ws["http_at"] = now                        # (hello comes after everything this PC missed: it counts as a full round)
    elif t == "a":                                  # (the active count, sent by the relay when it changed)
        _took(o, now)
        _st["sync_at"] = now
    elif t == "here":
        _took(o, now)
        _st["sync_at"] = _st["beat_at"] = now
    elif t in ("ok", "no"):
        with _ws_cv:
            _ws_ack.append(o)
            _ws_cv.notify_all()


def _ws_here(now):
    if now - _ws["here_at"] < WS_HERE:
        return
    _ws["here_at"] = now
    w = None
    try:
        import phonelink
        w = phonelink.who() if group() else None
    except Exception:
        w = None
    if w:                                           # (not linked: nothing to say - the open connection itself counts this PC as active)
        ws_send(json.dumps({"t": "h", "w": w}))


def ws_send(text):
    w = _ws["ws"]
    if not w or not _ws["up"]:
        return False
    try:
        w.send(text)
        _ws["sent"] += 1
        return True
    except Exception as e:
        _ws["error"] = "send: " + str(e)[:60]
        return False


def _ws_ask(obj, wait=4.0):
    """Send one thing up the connection and wait for the relay's answer to it -> the answer, or None (then it goes the old way)."""
    if not ws_up():
        return None
    with _ws_send_lock:
        with _ws_cv:
            del _ws_ack[:]
        if not ws_send(json.dumps(obj)):
            return None
        end = time.time() + wait
        with _ws_cv:
            while not _ws_ack and time.time() < end:
                _ws_cv.wait(max(0.01, end - time.time()))
            return _ws_ack.pop(0) if _ws_ack else None


def _ws_loop():
    import wsclient
    wait = 5.0
    while not _ws["stop"]:
        url = None
        try:
            url = _ws_url()
        except Exception as e:
            _ws["error"] = "address: " + str(e)[:60]
        if not url:
            time.sleep(30)
            continue
        t_open = time.time()
        try:
            w = wsclient.WS(url, timeout=20.0)
            _ws.update(ws=w, up=True, since_up=t_open, heard=t_open, hello=0.0, error="", url_key=url.split("&s=")[0])
            _ws["connects"] += 1
            last_ping = last_key = t_open
            while not _ws["stop"]:
                msg = w.recv(5.0)
                now = time.time()
                if msg is not None:
                    _ws_take(msg, now)
                _ws["heard"] = max(_ws["heard"], w.last_rx)
                if now - last_ping >= WS_PING:
                    last_ping = now
                    w.ping()
                if _ws["hello"]:
                    _ws_here(now)
                if now - _ws["heard"] > WS_QUIET:
                    raise wsclient.Closed("nothing heard for %d s" % int(now - _ws["heard"]))
                if now - last_key >= 20:
                    last_key = now                    # (linked, unlinked or sharing switched since: opened anew with the right channels)
                    try:
                        cur = _ws_url()
                    except Exception:
                        cur = url
                    if (cur or "").split("&s=")[0] != _ws["url_key"]:
                        raise wsclient.Closed("what this PC listens to changed")
        except Exception as e:
            _ws["error"] = str(e)[:100]
            _ws["fails"] += 0 if _ws["up"] and _ws["hello"] else 1
        finally:
            was = _ws["up"] and bool(_ws["hello"])
            _ws.update(up=False, hello=0.0, down_at=time.time())
            try:
                if _ws["ws"]:
                    _ws["ws"].close()
            except Exception:
                pass
            _ws["ws"] = None
        wait = 5.0 if was and time.time() - t_open > 60 else min(300.0, wait * 2)
        end = time.time() + wait
        while time.time() < end and not _ws["stop"]:
            time.sleep(0.5)


def ws_start():
    """Opens the connection (once) and keeps it open. Called when the program starts."""
    with _lock:
        if _ws["thread"] and _ws["thread"].is_alive():
            return False
        _ws["stop"] = False
        _ws["thread"] = threading.Thread(target=_ws_loop, daemon=True, name="relay-ws")
        _ws["thread"].start()
        return True


def ws_text():
    now = time.time()
    return (f"relay connection (v151): {'OPEN for %d s' % int(now - _ws['since_up']) if ws_up(now) else 'not open'}"
            f"; opened {_ws['connects']} time(s), {_ws['fails']} failed; {_ws['lines']} line(s) pushed to this PC, {_ws['sent']} message(s) sent up"
            + (f"; last problem: {_ws['error']}" if _ws["error"] else "") + ".")


def device():
    try:
        import crowd
        return crowd.my_id()
    except Exception:
        return ""


def group():
    """This link's group code (None when no phone / tablet is linked)."""
    try:
        import phonelink
        p = phonelink.parse_code(phonelink.load().get("code"))
        return phonelink.lock_group(p[1]) if p else None
    except Exception:
        return None


def claim(asin, http=None):
    """Right before Place order on Amazon: True = this PC orders, False = another of your devices has it, None = not asked."""
    g = group()
    if not g or not asin:
        return None
    _st["claims"] += 1
    r = _call("POST", "/v1/lock", {"c": device(), "g": g, "a": str(asin)}, timeout=4.0, http=http)
    if not r or r.get("ok") is not True:
        _st["unreachable"] += 1
        return None
    if r.get("granted"):
        _st["won"] += 1
        with _lock:
            _held[str(asin)] = time.time()
        return True
    _st["lost"] += 1
    if LOG:
        LOG(f"[relay] {asin}: another of your linked devices is placing this order (the shared lock) - not ordered here")
    return False


def release(asin, result, http=None, background=True):
    """How this PC's claimed checkout ended: "bought" (or maybe bought) keeps the others out for a day; anything else frees it."""
    with _lock:
        if _held.pop(str(asin), None) is None:
            return False
    g = group()
    if not g:
        return False

    def go():
        _call("POST", "/v1/release", {"c": device(), "g": g, "a": str(asin), "result": "bought" if result == "bought" else "failed"}, http=http)
    if background:
        threading.Thread(target=go, daemon=True, name="relay-release").start()
    else:
        go()
    return True


def holds(asin):
    with _lock:
        return str(asin) in _held


def _took(r, now):
    """What every answer of the relay to "I am here" carries: the active count and this PC's linked devices' signs of life."""
    _st["active"], _st["active_at"] = int(r.get("active") or 0), now
    if isinstance(r.get("peers"), list):
        try:
            import phonelink
            beats = [(p.get("w"), float(p.get("at") or 0) / 1000.0) for p in r["peers"] if isinstance(p, dict) and isinstance(p.get("w"), str)]
            _st["peers"] = phonelink.take_presence(beats)
            _st["peers_at"] = now
        except Exception:
            pass


def post_ch(ch, text, http=None, timeout=12.0):
    """v147: a sealed post on a linked group's channel (ch) -> True when the relay took it."""
    r = None
    if http is None:
        a = _ws_ask({"t": "p", "ch": str(ch), "m": str(text)})       # v151: up the open connection (1/20 of a request), else the old way
        if a and a.get("t") == "ok" and a.get("ch") == str(ch):
            r = {"ok": True}
    if r is None:
        r = _call("POST", "/v1/ch/" + str(ch), timeout=timeout, http=http, raw=str(text))
    ok = bool(r and r.get("ok") is True)
    _st["posts" if ok else "post_fails"] = _st.get("posts" if ok else "post_fails", 0) + 1
    return ok


def share(sightings, http=None):
    """v147: this PC's own sighting(s) for the crowd, straight to the relay -> True when taken."""
    if http is None:
        a = _ws_ask({"t": "s", "l": list(sightings)[:20]})          # v151: up the open connection, else the old way
        if a and a.get("t") == "ok" and "ch" not in a:
            return True
    r = _call("POST", "/v1/s", list(sightings)[:20], timeout=8.0, http=http)
    return bool(r and r.get("ok") is True)


def sync(reads=None, http=None, now=None):
    """v147: this PC's whole round with the relay in ONE request - "I am here" (the active count, the linked devices' signs of life)
    and what is new on the channels in [reads] ({channel: the last id read, "" = from the start}). The crowd's line is added when
    sharing is on, and what it brings is handed to crowd.py. -> {channel: [lines as ntfy hands them out]} or None (not reached)."""
    now = time.time() if now is None else now
    reads = dict(reads or {})
    if http is None and ws_up(now) and now - float(_ws.get("http_at") or 0) < _ws["safety"]:
        # v151: the connection is open - what is new was pushed already (crowd lines went to crowd.py as they came)
        with _lock:
            raw = {ch: _ws_buf.pop(ch, []) for ch in reads if ch != "crowd"}
        out = {}
        for ch, lines in raw.items():               # (each line once, in order, and only those after the reader's own place)
            last = int(reads[ch]) if str(reads.get(ch) or "").isdigit() else -1
            seen, keep = set(), []
            for m in sorted(lines, key=lambda x: int(x["id"]) if str(x.get("id") or "").isdigit() else 0):
                i = int(m["id"]) if str(m.get("id") or "").isdigit() else None
                if i is not None and (i <= last or i in seen):
                    continue
                seen.add(i)
                keep.append(m)
            out[ch] = keep
        _st["sync_at"], _st["next"] = now, 60
        return out
    body = {"c": device()}
    g = group()
    if g:
        try:
            import phonelink
            w = phonelink.who()
            if w:
                body["g"], body["w"] = g, w
        except Exception:
            pass
    crowd_on = False
    try:
        import crowd
        crowd_on = crowd.on()
        if crowd_on:
            reads["crowd"] = crowd.relay_since()
    except Exception:
        pass
    if not reads and not g and not crowd_on:
        return None
    body["r"] = reads
    _st["sync_try"] = now
    r = _call("POST", "/v1/sync", body, timeout=12.0, http=http)
    if not r or r.get("ok") is not True:
        _st["sync_fails"] = _st.get("sync_fails", 0) + 1
        if r and r.get("next"):
            _st["next"] = max(20, min(900, int(r["next"])))
        return None
    _st["sync_at"], _st["beat_at"], _st["syncs"] = now, now, _st.get("syncs", 0) + 1
    if http is None:
        _ws["http_at"] = now                         # (v152: only a full round that WORKED counts; a failed one is asked again)
        with _lock:
            for _ch in list(reads):
                _ws_buf.pop(_ch, None)               # (its answer holds everything since each reader's own place)
    try:
        _st["next"] = max(20, min(900, int(r.get("next") or 60)))
    except Exception:
        _st["next"] = 60
    _took(r, now)
    m = r.get("m") if isinstance(r.get("m"), dict) else {}
    out = {k: [x for x in v if isinstance(x, dict)] for k, v in m.items() if isinstance(v, list)}
    if crowd_on and out.get("crowd"):
        try:                                             # (on its own thread: the look it starts must never hold up a link round -
            import crowd                                 # waited for only a moment)
            t = threading.Thread(target=crowd.relay_take, args=(out["crowd"],), daemon=True, name="crowd-relay-take")
            t.start()
            t.join(3)
        except Exception:
            pass
    return out


def sync_age(now=None):
    """Seconds since the last round that reached the relay (a big number when none yet)."""
    return (time.time() if now is None else now) - float(_st.get("sync_at") or 0)


def next_wait():
    """Seconds the relay asked to wait until the next round (60 when it has not said)."""
    return int(_st.get("next") or 60)


def pump(http=None, now=None):
    """crowd.py's loop, every 30 s: a PC WITHOUT linked devices still reads the crowd's line (and says "I am here") - every 3 minutes,
    or as the relay says. A linked PC does it with its link round every minute (phonelink.cycle), so nothing is asked twice."""
    now = time.time() if now is None else now
    try:
        import phonelink
        if phonelink.linked():
            return None
    except Exception:
        pass
    if now - float(_st.get("sync_try") or 0) < max(180, next_wait()):
        return None
    return sync({}, http=http, now=now)


def heartbeat(force=False, http=None):
    """Every 15 minutes while sharing with the crowd is on: this device is working.
    v145 (owner 2026-11-20: "Both of these devices are currently active ... Confirm the devices can see and report active links"): a PC
    with linked phones / tablets also gives its link group and a few sealed words about itself, and gets the other devices' beats back
    (phonelink.py, presence) - so "heard" no longer depends on the free message service alone. Linked: sent also while crowd sharing is
    off (nothing about restocks is in it). force = now, at most once a minute (the page was opened)."""
    g = group()
    try:
        import crowd
        if not crowd.on() and not g:
            return None
    except Exception:
        pass
    now = time.time()
    if http is None and ws_up(now):                             # (v151: the open connection is the beat - "I am here" goes up it)
        return None
    if now - _st["beat_at"] < (60 if force else 15 * 60):       # (v147: a round with the relay - sync - counts as the beat)
        return None
    _st["beat_at"] = now
    body = {"c": device()}
    if g:
        try:
            import phonelink
            w = phonelink.who()
            if w:
                body["g"], body["w"] = g, w
        except Exception:
            pass
    r = _call("POST", "/v1/h", body, http=http)
    if r and r.get("ok"):
        _took(r, now)
    return r


def report(title, note, text, http=None):
    """A report of a PC that is not the owner's -> the relay (compiled once a day for the Restalker team). -> True when taken."""
    r = _call("POST", "/v1/report", {"c": device(), "app": "pc", "ver": VERSION, "title": str(title)[:200], "note": str(note or "")[:1000],
                                     "text": str(text)[:250_000]}, timeout=30.0, http=http)
    return bool(r and r.get("ok"))


def invite(http=None):
    """The Restalker Discord invite (kept for a day)."""
    now = time.time()
    if _st["invite"] and now - _st["invite_at"] < 24 * 3600:
        return _st["invite"]
    r = _call("GET", "/v1/links", http=http)
    u = (r or {}).get("discord")
    if isinstance(u, str) and u.startswith("https://discord.gg/"):
        _st["invite"], _st["invite_at"] = u, now
    return _st["invite"]


def active():
    """Devices heard in the last 30 minutes (-1 = not known yet; kept for an hour)."""
    return _st["active"] if _st["active"] >= 0 and time.time() - _st["active_at"] < 3600 else -1


def invite_cached():
    """The invite without waiting (fetched in the background the first time)."""
    if not _st["invite"] and time.time() - _st.get("invite_try", 0) > 600:
        _st["invite_try"] = time.time()
        threading.Thread(target=invite, daemon=True, name="relay-invite").start()
    return _st["invite"]


def _status_ws():
    try:
        return "\n" + ws_text()
    except Exception:
        return ""


def status_text():
    act = _st["active"]
    return (f"relay (v141): active now {act if act >= 0 else '?'}; race to checkout: claims {_st['claims']}, won {_st['won']}, "
            f"lost {_st['lost']}, relay not reached {_st['unreachable']}; linked group: {'yes' if group() else 'no'}"
            + (f"; linked devices heard there: {_st.get('peers', 0)} ({int((time.time() - _st['peers_at']) / 60)} min ago)" if _st.get("peers_at") else "")
            + (f"; rounds (v147, one request each): {_st.get('syncs', 0)} ok, {_st.get('sync_fails', 0)} failed, last "
               f"{int(sync_age() / 60) if _st.get('sync_at') else '?'} min ago, asks again every {next_wait()} s; sealed posts: {_st.get('posts', 0)} taken, "
               f"{_st.get('post_fails', 0)} not")
            + (f"; last error {_st['error']}" if _st["error"] else "") + _status_ws())
