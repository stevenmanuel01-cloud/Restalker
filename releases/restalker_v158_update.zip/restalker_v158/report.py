"""Problem reports (v122).

Owner 2026-11-16: "The log needs to be downloadable or uploadable such that screenshots aren't required. Ideally, there should just be a way
to report the bug to you and have you automatically move to fix it ... I am unable to easily give you results from desktop and app
simultaneously".
"Report problem" (the button at the top of the page) sends the diagnostics file - the same one Download diagnostics gives (no passwords,
card code or addresses) - to this Restalker's own private ntfy channel ("rkr-" + 20 random letters, made once: report_topic.txt).
It is read with that report code. The phone app has the same button (its own code). With automatic reports on (the default), a report
is also sent by itself when a checkout does not buy or something needs you - at most one every 2 hours.

v145 (owner 2026-11-20: "it should be a generic message to allow automatic reporting, and sending a manual report"): the program's own
words name no one - "Report sent".
"""
import os
import re
import secrets
import threading
import time
import urllib.request

VERSION = "v158"
SERVER = "https://ntfy.sh"
TOPIC_FILE = "report_topic.txt"
AUTO_OFF_FILE = "report_auto_off.txt"
# v145: 2 hours (was 30 minutes) - every report is one of the 250 messages a day the free message service gives a home for ALL its
# devices (the link with the phones and the phone messages share them); a lasting problem reported every 30 minutes used most of them
AUTO_GAP = 2 * 3600
RETRY_WAIT = 5
ABC = "abcdefghijkmnpqrstuvwxyz23456789"
PROBLEM_KINDS = {"FAILED", "ACTION", "CHECK", "UNKNOWN", "NOTFOUND", "REST", "APPROVE", "CVV"}
_st = {"last_auto": 0.0, "sent": 0, "last": "", "error": "", "busy": False}
_lock = threading.Lock()
BUILD = None          # app.py: () -> diagnostics text (str)
LOG = None


def valid(t):
    return bool(re.fullmatch(r"rkr-[a-z0-9]{20}", t or ""))


def code():
    """This Restalker's report code (made the first time)."""
    try:
        t = open(TOPIC_FILE, encoding="utf-8").read().strip()
        if valid(t):
            return t
    except Exception:
        pass
    t = "rkr-" + "".join(secrets.choice(ABC) for _ in range(20))
    with open(TOPIC_FILE, "w", encoding="utf-8") as f:
        f.write(t)
    return t


def auto_on():
    return not os.path.exists(AUTO_OFF_FILE)


def set_auto(on):
    if on:
        try:
            os.remove(AUTO_OFF_FILE)
        except OSError:
            pass
    else:
        with open(AUTO_OFF_FILE, "w", encoding="utf-8") as f:
            f.write("automatic problem reports switched off by you\n")


def _put(url, headers, body):
    req = urllib.request.Request(url, data=body, method="PUT", headers=dict(headers, **{"User-Agent": "Restalker/" + VERSION}))
    with urllib.request.urlopen(req, timeout=90) as r:
        return r.status


def direct():
    """v141 (owner, 2026-11-19: the option to send reports directly "should be removed from all devices except for my master account (and
    my linked devices) ... all issues should be reported to discord, which can be sorted, compiled, and sent to me/you for review"): only
    the owner's PC sends its reports directly (its own private report channel); any other PC's reports go to the Restalker relay
    (compiled once a day on Discord)."""
    try:
        import master
        return master.is_master()
    except Exception:
        return True


def send(text, why, put=None):
    """Sends the diagnostics text as a file. -> (ok, code)."""
    if not direct():
        try:
            import relay
            ok = relay.report(str(why)[:200], "", text if isinstance(text, str) else text.decode("utf-8", "replace"))
        except Exception:
            ok = False
        if ok:
            _st["sent"] += 1
            _st["last"] = time.strftime("%m-%d %H:%M:%S")
        if LOG:
            LOG(f"[report] {'sent to the Restalker team (looked at once a day)' if ok else 'could not be sent'} - {why}")
        return ok, "the Restalker team"
    topic = code()
    body = text.encode("utf-8", "replace") if isinstance(text, str) else text
    headers = {"Title": "Restalker desktop report", "Filename": "restalker-desktop-report.txt", "Tags": "restalker-report",
               "Message": re.sub(r"[\r\n]+", " ", str(why))[:300]}
    ok = False
    for attempt in range(3):                     # v123: the report server sometimes refuses for a moment - 3 tries, 5 s apart
        if attempt:
            time.sleep(RETRY_WAIT)
        try:
            st = (put or _put)(SERVER + "/" + topic, headers, body)
            ok = 200 <= int(st) < 300
            _st["error"] = "" if ok else f"the report server answered {st}"
        except Exception as e:
            ok = False
            _st["error"] = str(e)[:120]
        if ok:
            break
    if ok:
        _st["sent"] += 1
        _st["last"] = time.strftime("%m-%d %H:%M:%S")
    if LOG:
        LOG(f"[report] {'sent (code ' + topic + ')' if ok else 'could not be sent: ' + _st['error']} - {why}")
    return ok, topic


def send_now(why, put=None):
    """Builds the diagnostics and sends them (one at a time). -> (ok, code)."""
    with _lock:
        if _st["busy"]:
            return False, code()
        _st["busy"] = True
    try:
        text = "REPORT: " + str(why) + "\n\n" + (BUILD() if BUILD else "(no diagnostics builder)")    # v126: your note first
        return send(text, why, put)
    finally:
        _st["busy"] = False


SAME_GAP = 6 * 3600                 # v133: the same automatic report (same title) at most once per 6 hours


def _messages_left():
    """v145: enough of the day's free messages left for a report that can wait (not known = yes)."""
    try:
        import phonelink
        return phonelink.quota_may(phonelink.KEEP_FOR_NORMAL)
    except Exception:
        return True


def auto(kind, title, now=None, put=None, background=True):
    """A report by itself after a problem event - automatic reports on, and at most one every 2 hours. -> True when one is sent.
    v145: a direct report waits while no more than 100 of the day's free messages are left (phonelink.quota_may)."""
    if kind not in PROBLEM_KINDS or not auto_on():
        return False
    if direct() and not _messages_left():
        return False
    t = now if now is not None else time.time()
    key = str(title or "")[:200]
    with _lock:
        if t - _st["last_auto"] < AUTO_GAP:
            return False
        # v133: the SAME problem again (e.g. Best Buy refusing the same bundle every half hour) is reported once per 6 hours - it is
        # already known; a different problem still goes out (after the 2-hour gap)
        sent = _st.setdefault("titles", {})
        if t - sent.get(key, 0) < SAME_GAP:
            return False
        sent[key] = t
        for k in [k for k, v in sent.items() if t - v > SAME_GAP]:
            del sent[k]
        _st["last_auto"] = t
    if background:
        threading.Thread(target=send_now, args=("automatic: " + str(title)[:200], put), daemon=True, name="report").start()
    else:
        send_now("automatic: " + str(title)[:200], put)
    return True


# v127 (owner: "The PC version does not seem to be sending you diagnostics automatically ... such that i can go to sleep and you
# can present me with a brief summary of actions taken overnight"): besides the reports after a problem, a regular report every 4 hours
# while automatic reports are on - the night can be followed from them.
# v148: no longer started (app.py) - the owner no longer needs the regular reports. Kept here, unused.
PERIODIC = 4 * 3600
PERIODIC_FILE = "report_periodic.txt"


def _periodic_last():
    try:
        with open(PERIODIC_FILE, encoding="utf-8") as f:
            return float(f.read().strip() or 0)
    except Exception:
        return 0.0


def periodic_due(now=None):
    t = time.time() if now is None else now
    return auto_on() and t - _periodic_last() >= PERIODIC


def periodic_once(now=None, put=None):
    """Sends the regular report when it is due. -> True when sent."""
    t = time.time() if now is None else now
    if not periodic_due(t) or (direct() and not _messages_left()):
        return False
    try:
        with open(PERIODIC_FILE, "w", encoding="utf-8") as f:
            f.write(str(t))
    except OSError:
        pass
    ok, _ = send_now("automatic: regular report (every 4 hours, to follow how things went)", put)
    return ok


def start_periodic(first_wait=600, every=300):
    def loop():
        time.sleep(first_wait)
        while True:
            try:
                periodic_once()
            except Exception as e:
                _st["error"] = str(e)[:120]
            time.sleep(every)
    threading.Thread(target=loop, daemon=True, name="report-periodic").start()


def status():
    return (f"problem reports (v122): code {code()}; automatic {'on' if auto_on() else 'off'}; sent {_st['sent']}"
            + (f", last {_st['last']}" if _st["last"] else "") + (f"; last problem: {_st['error']}" if _st["error"] else ""))
