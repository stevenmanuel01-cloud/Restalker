"""The product-by-store table: which products are watched at which stores, and the on/off switches.

  * one ROW per product (a set + a kind: box / pack / bundle), one COLUMN per store, a cell = the product's link(s) at that store (blank =
    not sold there, not watched). v109: a store can sell one product on SEVERAL pages (Amazon often has 2-3 listings of one box) - they all
    stay in that one cell, each read and bought on its own (one purchase per product still holds across all of them)
  * switch on a row  -> that product is on/off at every store
  * switch on a column -> that store is on/off for every product
  * switch in a cell -> that one link only
  A link is watched only when ALL of its switches are on. Switches take effect at once (the checkers ask is_off() before every look).
  * ONE price cap per row, the same at every store.
The switches live in ui_state.yaml; the links stay in targets.yaml (nothing else about a product changes).
"""
import os, re, threading
import yaml
import products
import msrp

VERSION = "v114"
UI_PATH = "ui_state.yaml"
STORE_ORDER = ["tcg", "amazon", "target", "walmart", "bestbuy", "gamestop"]          # v46: TCG (a price index, not a shop) sits right after the price cap
STORE_NAMES = {"tcg": "TCG", "amazon": "Amazon", "target": "Target", "walmart": "Walmart", "bestbuy": "Best Buy", "gamestop": "GameStop"}
SET_ORDER = ["the hobbit", "reality fracture", "star trek"]
KIND_ORDER = {"box": 0, "pack": 1, "bundle": 2}
# v55: groups. The current sets (SET_ORDER) are each a group of their own; every older set is grouped by the year it came out (US release).
RELEASE_YEAR = {
    "secrets of strixhaven": 2026, "lorwyn eclipsed": 2026, "avatar the last airbender": 2025, "spider-man": 2025, "marvel's spider-man": 2025,
    "edge of eternities": 2025, "final fantasy": 2025, "tarkir dragonstorm": 2025, "aetherdrift": 2025, "innistrad remastered": 2025,
    "foundations": 2024, "duskmourn": 2024, "duskmourn house of horror": 2024, "bloomburrow": 2024, "assassin's creed": 2024,
    "modern horizons 3": 2024, "outlaws of thunder junction": 2024, "fallout": 2024, "murders at karlov manor": 2024, "ravnica remastered": 2024,
    "the lost caverns of ixalan": 2023, "lost caverns of ixalan": 2023, "doctor who": 2023, "wilds of eldraine": 2023, "commander masters": 2023,
    "the lord of the rings tales of middle-earth": 2023, "lord of the rings tales of middle-earth": 2023, "march of the machine": 2023,
    "phyrexia all will be one": 2023, "dominaria remastered": 2023,
    "the brothers' war": 2022, "the brothers war": 2022, "unfinity": 2022, "warhammer 40,000": 2022, "warhammer 40000": 2022,
    "dominaria united": 2022, "double masters 2022": 2022, "commander legends battle for baldur's gate": 2022, "streets of new capenna": 2022,
    "kamigawa neon dynasty": 2022, "innistrad crimson vow": 2021, "innistrad midnight hunt": 2021, "adventures in the forgotten realms": 2021,
    "modern horizons 2": 2021, "strixhaven": 2021, "strixhaven school of mages": 2021, "time spiral remastered": 2021, "kaldheim": 2021,
    "commander legends": 2020, "zendikar rising": 2020, "double masters": 2020, "core set 2021": 2020, "ikoria": 2020,
    "ikoria lair of behemoths": 2020, "theros beyond death": 2020, "throne of eldraine": 2019, "core set 2020": 2019,
    "modern horizons": 2019, "war of the spark": 2019, "ravnica allegiance": 2019,
}


def group_of(theme):
    """(sort order, group name) of a set: a current set is its own group; older sets are grouped by release year."""
    if theme in SET_ORDER:
        return (SET_ORDER.index(theme), title_of(theme))
    y = RELEASE_YEAR.get(theme)
    if y is None:
        y = RELEASE_YEAR.get(theme.replace(":", "").replace("  ", " "))
    if y:
        return (100 + (3000 - y), f"Released {y}")
    return (9999, "Other sets")
KIND_LABEL = {"box": "Collector Booster Box", "pack": "Single Collector Booster"}
# the choices offered when a product is added (box / pack / bundle are built in; more can be made in the table: "+ New category...")
KIND_CHOICES = [("box", "Collector Booster Box"), ("pack", "Single collector pack"), ("bundle", "Bundle"),
                ("play_booster_box", "Play Booster Box"), ("commander_deck", "Commander Deck")]
STORE_DEFAULTS = {"tcg": {"fetch_mode": "http", "interval_sec": 600.0}, "target": {"fetch_mode": "http", "interval_sec": 1.0}, "walmart": {"fetch_mode": "http", "interval_sec": 15.0},
                  "amazon": {"fetch_mode": "browser", "interval_sec": 5.0}, "bestbuy": {"fetch_mode": "browser", "interval_sec": 2.5},
                  "gamestop": {"fetch_mode": "browser", "interval_sec": 5.0}}
GENERIC_STORE = {"fetch_mode": "browser", "interval_sec": 5.0}
INDEX_STORES = ("tcg",)                       # columns that show a reference price (never watched for stock, no alerts)
BUILTIN_ALIAS = {"tcgplayer": "tcg"}          # tcgplayer.com links always belong to the TCG column

LOCK = threading.RLock()
UI = {"products_off": set(), "stores_off": set(), "cells_off": set(), "extra_products": [], "extra_stores": [], "caps_unified": False, "gaming": False,
      "gaming_mode": "auto", "extra_kinds": [], "msrp": {}, "push_dismissed": [], "searched": {}, "store_alias": {}, "load_profile": "balanced", "bad_links": {}}
REV = [0]          # goes up whenever the table's content changed behind the page's back (a picture arrived, a link was found); the page then redraws


def bump():
    REV[0] += 1


# ------------------------------------------------------------------ naming

def host_key(url):
    """The store name taken from a web address (www.starcitygames.com -> starcitygames), before any column name you gave it."""
    url = url or ""
    host = url.lower().split("/")[2] if "//" in url else url.lower()
    parts = [p for p in host.split(".") if p not in ("www", "com", "net", "org", "co", "us")]
    return parts[-1] if parts else host


def store_of(t):
    """The table column a link belongs to: its web-address name, unless you told the program that this address is the column you added
    (a column called 'Star City' takes starcitygames.com links)."""
    k = host_key(t.get("url") or "")
    if k in BUILTIN_ALIAS:
        return BUILTIN_ALIAS[k]
    return UI.get("store_alias", {}).get(k, k)


def add_alias(host, column):
    """Links of this web-address name go into this column from now on."""
    if not host or not column or host == column:
        return
    with LOCK:
        UI.setdefault("store_alias", {})[host] = column
    save_ui()


def column_takes(column, url):
    """True when a link may be saved into this column: it is from that store, or the column is one you added yourself (any web address is
    then taken, and remembered as belonging to it). The five built-in stores never take another store's link."""
    hk = host_key(url)
    if store_of({"url": url}) == column or hk == column:
        return True
    with LOCK:
        mine = column in UI["extra_stores"]
    if mine:
        add_alias(hk, column)
        return True
    return False


def store_name(key):
    return STORE_NAMES.get(key, key.replace("_", " ").title())


_KEY_CACHE = {}


def key_of(t):
    ck = (t.get("match_name", ""), t.get("kind", ""))
    k = _KEY_CACHE.get(ck)
    if k is None:
        k = f"{products.theme_of(t)}|{products.kind_of(t)}"
        _KEY_CACHE[ck] = k
    return k


def split_key(key):
    theme, _, kind = key.partition("|")
    return theme, kind or "box"


def title_of(theme):
    return " ".join(w.capitalize() if w not in ("the", "of", "and") else w for w in theme.split()).replace("The ", "The ", 1) if not theme.startswith("the ") else "The " + " ".join(w.capitalize() for w in theme[4:].split())


def kind_options():
    """[(slug, label)] offered in the add-product box: the built-in ones, the ready-made ones, then the ones you made."""
    out = list(KIND_CHOICES)
    have = {k for k, _ in out}
    with LOCK:
        for e in UI["extra_kinds"]:
            if e["slug"] not in have:
                out.append((e["slug"], e.get("label") or e["slug"].replace("_", " ").title()))
                have.add(e["slug"])
    return out


def kind_label(kind):
    for k, lab in kind_options():
        if k == kind:
            return lab
    return kind.replace("_", " ").title()


def kind_rank(kind):
    if kind in KIND_ORDER:
        return KIND_ORDER[kind]
    for i, (k, _) in enumerate(kind_options()):
        if k == kind:
            return 3 + i
    return 99


def add_kind(label):
    """Makes (or finds) a category. Returns its slug, or None when the name is empty."""
    label = re.sub(r"\s+", " ", (label or "").strip())[:40]
    slug_ = re.sub(r"[^a-z0-9]+", "_", label.lower()).strip("_")
    if not slug_:
        return None
    if not slug_[0].isalpha():
        slug_ = "k_" + slug_
    if len(slug_) < 2:
        slug_ += "_x"
    slug_ = slug_[:40]
    for k, lab in kind_options():
        if k == slug_ or lab.lower() == label.lower():
            return k
    with LOCK:
        UI["extra_kinds"].append({"slug": slug_, "label": label})
    save_ui()
    return slug_


def label_of(kind, match_name=""):
    if kind in KIND_LABEL:
        return KIND_LABEL[kind]
    if products.is_custom(kind):
        return kind_label(kind)
    theme = products.theme_of(match_name)
    rest = products.norm(match_name)
    rest = rest[len(theme):].strip() if rest.startswith(theme) else rest
    return " ".join(w.capitalize() for w in rest.split()) or "Bundle"


def slug(text):
    return re.sub(r"[^a-z0-9]+", "_", (text or "").lower()).strip("_")


# ------------------------------------------------------------------ the switches

def is_off(t):
    """True when this link must not be looked at right now (any of its switches is off)."""
    if not t.get("active", True) or t.get("needs_cap"):       # needs_cap: no trustworthy price cap yet - not watched until you type one
        return True
    with LOCK:
        if store_of(t) == "tcg":                  # v58: the TCG price has no switches (read for every product, every 2 hours)
            return False
        return (store_of(t) in UI["stores_off"] or key_of(t) in UI["products_off"] or t.get("id") in UI["cells_off"])


def load_ui(path=None):
    path = path or UI_PATH
    d = {}
    try:
        with open(path, encoding="utf-8") as f:
            d = yaml.safe_load(f) or {}
    except Exception:
        d = {}
    with LOCK:
        UI["products_off"] = set(d.get("products_off") or [])
        UI["stores_off"] = set(d.get("stores_off") or [])
        UI["cells_off"] = set(d.get("cells_off") or [])
        UI["extra_products"] = list(d.get("extra_products") or [])
        UI["extra_stores"] = [x for x in (d.get("extra_stores") or []) if x not in STORE_ORDER]       # (v46: "tcg" is a built-in column now)
        UI["caps_unified"] = bool(d.get("caps_unified"))
        UI["gaming"] = bool(d.get("gaming"))
        gm = d.get("gaming_mode")
        UI["gaming_mode"] = gm if gm in ("auto", "on", "off") else ("on" if d.get("gaming") else "auto")
        UI["extra_kinds"] = [dict(k) for k in (d.get("extra_kinds") or []) if isinstance(k, dict) and k.get("slug")]
        UI["msrp"] = {str(k): v for k, v in (d.get("msrp") or {}).items()}
        UI["push_dismissed"] = list(d.get("push_dismissed") or [])
        UI["searched"] = {str(k): dict(v) for k, v in (d.get("searched") or {}).items() if isinstance(v, dict)}
        UI["store_alias"] = {str(k): str(v) for k, v in (d.get("store_alias") or {}).items()}
        UI["bad_links"] = {str(k): {str(s): [str(u) for u in (v or [])][-20:] for s, v in (m or {}).items()} for k, m in (d.get("bad_links") or {}).items() if isinstance(m, dict)}
        lp = d.get("load_profile")
        UI["load_profile"] = lp if lp in ("full", "balanced", "light", "minimum") else "balanced"
        UI["restored_v58"] = bool(d.get("restored_v58"))
        migrate = not UI["restored_v58"]
        if migrate:
            # v58 (diagnostics 57): store squares were switched off by the program's link check (a bare "Amazon.com" page looked like
            # a wrong product) - not by you. Every store square is switched ON again once. Your product and store-column choices stay.
            UI["restored_v58"] = True
            UI["cells_restored"] = sorted(UI["cells_off"])
            UI["cells_off"] = set()
            UI["stores_off"].discard("tcg")
    if migrate:
        save_ui(path)


def save_ui(path=None):
    path = path or UI_PATH
    with LOCK:
        d = {"products_off": sorted(UI["products_off"]), "stores_off": sorted(UI["stores_off"]), "cells_off": sorted(UI["cells_off"]),
             "extra_products": UI["extra_products"], "extra_stores": UI["extra_stores"], "caps_unified": UI["caps_unified"], "gaming": UI["gaming"],
             "gaming_mode": UI["gaming_mode"], "extra_kinds": UI["extra_kinds"], "msrp": UI["msrp"], "push_dismissed": UI["push_dismissed"],
             "searched": UI["searched"], "store_alias": UI["store_alias"], "load_profile": UI.get("load_profile", "balanced"), "bad_links": UI.get("bad_links") or {},
             "restored_v58": bool(UI.get("restored_v58"))}
    try:
        with open(path, "w", encoding="utf-8") as f:
            yaml.safe_dump(d, f, sort_keys=False, allow_unicode=True)
    except Exception:
        pass


def _flip(group, item, on):
    with LOCK:
        (UI[group].discard if on else UI[group].add)(item)
    save_ui()


def set_product(key, on):
    _flip("products_off", key, on)


def set_store(store, on):
    _flip("stores_off", store, on)


def set_cell(tid, on):
    _flip("cells_off", tid, on)


# ------------------------------------------------------------------ the table

def build(targets):
    """The table as plain data: stores (columns), products (rows) with one cell per store (None = blank)."""
    with LOCK:
        ui = {k: (set(v) if isinstance(v, set) else list(v) if isinstance(v, list) else v) for k, v in UI.items()}
    live = [t for t in targets if t.get("active", True)]           # active:false = retired (kept in the file, not shown here)
    stores = list(STORE_ORDER)
    for t in live:
        s = store_of(t)
        if s not in stores:
            stores.append(s)
    for s in ui["extra_stores"]:
        if s not in stores:
            stores.append(s)
    rows = {}
    for t in live:
        k = key_of(t)
        r = rows.setdefault(k, {"key": k, "match_name": t.get("match_name", ""), "kind": products.kind_of(t), "cells": {}, "more": {}, "cap": None, "user": False})
        s_ = store_of(t)
        if s_ in r["cells"] and not (r["cells"][s_].get("extra_link") and not t.get("extra_link")):
            r["more"].setdefault(s_, []).append(t)                     # v109: another page of this product at this store
        else:
            if s_ in r["cells"]:
                r["more"].setdefault(s_, []).insert(0, r["cells"][s_])
            r["cells"][s_] = t
    for e in ui["extra_products"]:
        r = rows.setdefault(e["key"], {"key": e["key"], "match_name": e.get("match_name", ""), "kind": e.get("kind", "box"), "cells": {}, "more": {}, "cap": e.get("max_price"), "user": True})
        r["user"] = True
    theme_rank = lambda th: SET_ORDER.index(th) if th in SET_ORDER else len(SET_ORDER)
    out = []
    for k, r in sorted(rows.items(), key=lambda kv: (group_of(split_key(kv[0])[0])[0], theme_rank(split_key(kv[0])[0]), split_key(kv[0])[0], kind_rank(split_key(kv[0])[1]))):
        theme, kind = split_key(k)
        caps = [c["max_price"] for c in list(r["cells"].values()) + [m for ms in r["more"].values() for m in ms] if c.get("max_price") is not None]
        cap = min(caps) if caps else r["cap"]
        cells = {}
        for s in stores:
            t = r["cells"].get(s)
            if t is None:
                cells[s] = None
                continue
            one = lambda t: {"id": t["id"], "url": t.get("url", ""), "cell_on": t["id"] not in ui["cells_off"], "tier": t.get("tier", "core"),
                             "found": bool(t.get("found_by")), "found_by": t.get("found_by") or "", "index": s in INDEX_STORES}
            cells[s] = one(t)
            cells[s]["more"] = [one(m) for m in r["more"].get(s, [])]
        ids = [c["id"] for c in cells.values() if c] + [m["id"] for c in cells.values() if c for m in c.get("more", [])]
        mi = msrp.for_row(k, {})            # the MSRP column is fixed (published or calculated); it is not editable
        sn = msrp.seen(ids) if ids else {}
        sr = ui["searched"].get(k) or {}
        out.append({"key": k, "title": title_of(theme), "label": label_of(kind, r["match_name"]), "kind": kind, "on": k not in ui["products_off"],
                    "group": group_of(theme)[1],
                    "cap": cap, "cells": cells, "user": r["user"], "msrp": mi, "seen": sn, "searched": sr})
    return {"stores": [{"key": s, "name": store_name(s), "on": s not in ui["stores_off"],
                        "count": sum(1 for p in out if p["cells"].get(s))} for s in stores], "products": out}


# ------------------------------------------------------------------ changes (all return what they did; the caller saves targets.yaml)

def sku_from_url(url):
    m = re.search(r"/sku/(\d{6,8})", url or "") or re.search(r"/site/(\d{6,8})\.p", url or "") or re.search(r"[?&]skuId=(\d{6,8})", url or "")
    return int(m.group(1)) if m else None


LAST_ACTIVATED = [0]


def set_cap(targets, key, cap):
    """Sets the cap of a product at every store. Links that were waiting for a cap (needs_cap) start being watched."""
    n = 0
    LAST_ACTIVATED[0] = 0
    for t in targets:
        if key_of(t) == key:
            t["max_price"] = cap
            if t.get("needs_cap"):
                t.pop("needs_cap", None)
                LAST_ACTIVATED[0] += 1
            n += 1
    with LOCK:
        for e in UI["extra_products"]:
            if e["key"] == key:
                e["max_price"] = cap
    save_ui()
    return n


def unify_caps(targets):
    """One cap per product: the LOWEST one in use. Returns how many links changed."""
    by = {}
    for t in targets:
        if t.get("max_price") is not None and t.get("active", True):
            by.setdefault(key_of(t), []).append(t)
    changed = 0
    for k, ts in by.items():
        low = min(float(t["max_price"]) for t in ts)
        for t in ts:
            if float(t["max_price"]) != low:
                t["max_price"] = low
                changed += 1
    return changed


MAX_LINKS = 4                 # v109: links of one product at one store (one cell)


def same_page(a, b):
    """v109: two links are the same product page (Amazon: the same product number; else the same address without its extras)."""
    ra = re.search(r"/(?:dp|gp/product)/(B0[A-Z0-9]{8})", a or "", re.I)
    rb = re.search(r"/(?:dp|gp/product)/(B0[A-Z0-9]{8})", b or "", re.I)
    if ra and rb:
        return ra.group(1).upper() == rb.group(1).upper()
    return link_norm(a) == link_norm(b)


def new_link(targets, key, store, url, found_by=None, extra=False):
    """Builds the target for a blank cell (or None when the row already has a link at that store).
    found_by: 'search' when the program found the link itself (the table then marks it so you can check it).
    extra (v109): one MORE page of this product at this store (same cell) - None when that page is there already or the cell is full."""
    here = [t for t in targets if key_of(t) == key and store_of(t) == store and t.get("active", True)]
    if here and not extra:
        return None
    if extra and (any(same_page(t.get("url", ""), url) for t in here) or len(here) >= MAX_LINKS):
        return None
    sib = next((t for t in targets if key_of(t) == key and t.get("active", True)), None)
    with LOCK:
        xp = next((e for e in UI["extra_products"] if e["key"] == key), None)
    base = sib or xp or {}
    theme, kind = split_key(key)
    suffix = sib["id"].split("_", 1)[1] if sib and "_" in sib["id"] else slug(base.get("match_name") or theme) + ("" if kind == "box" else "_" + kind)
    tid = f"{store}_{suffix}"
    taken = {t["id"] for t in targets}
    n = 2
    while tid in taken:
        tid = f"{store}_{suffix}_{n}"
        n += 1
    t = {"id": tid, "url": url.strip(), "match_name": base.get("match_name", ""), "kind": kind}
    if base.get("aliases"):
        t["aliases"] = list(base["aliases"])
    t["tier"] = base.get("tier", "extra") if sib else "extra"
    t.update(STORE_DEFAULTS.get(store, GENERIC_STORE))
    t["active"] = True
    if found_by:
        t["found_by"] = found_by
    if extra and here:
        t["extra_link"] = True
    cap = base.get("max_price")
    if cap is not None:
        t["max_price"] = cap
    if store == "bestbuy" and sku_from_url(url):
        t["sku"] = sku_from_url(url)
    return t


def add_product(name, kind, cap):
    name = (name or "").strip()
    if not name or kind not in {k for k, _ in kind_options()}:
        return None
    kind = products.kind_of({"match_name": name, "kind": kind})      # 'X Play Booster Box' filed under Collector Booster Box is its own product
    if kind not in {k for k, _ in kind_options()}:
        return None
    theme = products.theme_of({"match_name": name, "kind": kind})
    if not theme:
        return None
    key = f"{theme}|{kind}"
    with LOCK:
        if any(e["key"] == key for e in UI["extra_products"]):
            return key
        UI["extra_products"].append({"key": key, "match_name": name, "kind": kind, "max_price": cap})
    save_ui()
    return key


def remove_product(targets, key):
    gone = [t["id"] for t in targets if key_of(t) == key]
    with LOCK:
        UI["extra_products"] = [e for e in UI["extra_products"] if e["key"] != key]
        UI["products_off"].discard(key)
        for i in gone:
            UI["cells_off"].discard(i)
    save_ui()
    return gone


def add_store(name):
    key = re.sub(r"[^a-z0-9]", "", (name or "").lower())      # same as the store name taken from a web address (samsclub.com -> samsclub)
    if not key:
        return None
    with LOCK:
        if key not in UI["extra_stores"] and key not in STORE_ORDER:
            UI["extra_stores"].append(key)
        STORE_NAMES.setdefault(key, (name or "").strip())
    save_ui()
    return key


def remove_store(targets, store):
    gone = [t["id"] for t in targets if store_of(t) == store]
    with LOCK:
        UI["extra_stores"] = [s for s in UI["extra_stores"] if s != store]
        UI["store_alias"] = {k: v for k, v in UI.get("store_alias", {}).items() if v != store}
        UI["stores_off"].discard(store)
        for i in gone:
            UI["cells_off"].discard(i)
    save_ui()
    return gone


# ------------------------------------------------------------------ MSRP, dismissed reminders, searches, upgrades of older rows

def set_dismissed(tracker_id, on):
    with LOCK:
        d = [x for x in UI["push_dismissed"] if x != tracker_id]
        if on:
            d.append(tracker_id)
        UI["push_dismissed"] = d
    save_ui()


def mark_searched(key, store, found, at=None):
    import time as _t
    with LOCK:
        UI["searched"].setdefault(key, {})[store] = {"found": bool(found), "at": int(at or _t.time())}
    save_ui()
    bump()


def link_norm(url):
    """v75: a link without its ?query / #part and trailing slash, lower case - to recognise a link you marked wrong."""
    return str(url or "").split("#")[0].split("?")[0].rstrip("/").lower()


def add_bad_link(key, store, url):
    """v75: you marked this link as the WRONG product - the search never puts it back for this product."""
    with LOCK:
        lst = UI.setdefault("bad_links", {}).setdefault(key, {}).setdefault(store, [])
        n = link_norm(url)
        if n and n not in lst:
            lst.append(n)
            del lst[:-20]
        UI["searched"].get(key, {}).pop(store, None)
    save_ui()


def bad_links(key):
    with LOCK:
        return sorted({u for v in (UI.get("bad_links") or {}).get(key, {}).values() for u in v})


def unmark_searched(key):
    with LOCK:
        UI["searched"].pop(key, None)
    save_ui()


def _old_theme(name):
    n = products.norm(name)
    return re.sub(r"\s*(collector booster box|collector booster pack|collector booster|gift bundle|secret lair bundle|beam me up bundle|bundle)$", "", n).strip()


def migrate_rows(targets):
    """Older versions put every row you added under 'box', named after the brand ('Magic the Gathering Star Trek Commander Deck') and
    showed it as a Collector Booster Box. This gives such rows their own category (Commander Deck / Play Booster Box) and set name.
    Only rows YOU added are touched. Returns (renames {old key: new key}, number of links changed). Safe to run again."""
    renames, links = {}, 0
    with LOCK:
        for e in UI["extra_products"]:
            name, kind = e.get("match_name", ""), e.get("kind", "box")
            old_key = e["key"]
            nk = kind
            n = products.norm(name)
            if kind == "box" and "collector" not in n:
                if "play booster" in n:
                    nk = "play_booster_box"
                elif "commander" in n:
                    nk = "commander_deck"
            new_key = f"{products.theme_of({'match_name': name, 'kind': nk})}|{nk}"
            if new_key.startswith("|"):
                continue
            if nk != kind:
                e["kind"] = nk
            if new_key != old_key:
                e["key"] = new_key
                renames[old_key] = new_key
                # the links of that row (they still carry the old kind)
                for t in targets:
                    if f"{_old_theme(t.get('match_name', ''))}|{(t.get('kind') or 'box')}" == old_key:
                        t["kind"] = nk
                        links += 1
        seen_keys, kept = set(), []
        for e in UI["extra_products"]:           # two entries that now mean the same row (the one you re-added) become one
            if e.get("key") in seen_keys:
                continue
            seen_keys.add(e.get("key"))
            kept.append(e)
        UI["extra_products"] = kept
        if renames:
            UI["products_off"] = {renames.get(k, k) for k in UI["products_off"]}
            UI["searched"] = {renames.get(k, k): v for k, v in UI["searched"].items()}
            UI["msrp"] = {renames.get(k, k): v for k, v in UI["msrp"].items()}
        _KEY_CACHE.clear()
    if renames:
        save_ui()
    return renames, links
