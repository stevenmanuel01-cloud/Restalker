"""Finds the same product at the other stores.

You add a product with ONE link (or only a name). This opens each other store's own SEARCH page (one page per store, one store at
a time, in an ordinary Chrome parked off screen, closed again afterwards), reads the product links on it and keeps the first one whose
title really is your product (same matching rules the tracker alerts use: right set, right kind - a box is not a pack, a Commander Deck
is not a bundle). A link found this way is saved like one you typed, and marked "found by search" in the table so you can check it.
Nothing is found when the store hides its search results from this kind of visitor, or has no such product; the square then says so
and offers "search again" / "+ link". Costs a handful of page loads per added product - never repeated by itself.
"""
import html as _html
import os
import re
import threading
import time
import urllib.parse

import products

VERSION = "v114"
STORES = ["target", "walmart", "amazon", "bestbuy", "gamestop"]          # the order they are searched in (friendliest first)
SEARCH_URLS = {
    "target": "https://www.target.com/s?searchTerm={q}",
    "walmart": "https://www.walmart.com/search?q={q}",
    "amazon": "https://www.amazon.com/s?k={q}",
    "bestbuy": "https://www.bestbuy.com/site/searchpage.jsp?st={q}",
    "gamestop": "https://www.gamestop.com/search/?q={q}&lang=default",
}
# product links as the stores write them; group 1 (and 2) identify the product (so the same product is not listed twice)
LINK_RES = {
    "target": re.compile(r"(?:https?://www\.target\.com)?(/p/[A-Za-z0-9_%.\-]+/-/A-(\d{6,}))", re.I),
    "walmart": re.compile(r"(?:https?://www\.walmart\.com)?(/ip/(?:[A-Za-z0-9_%.\-]+/)?(\d{6,}))", re.I),
    "amazon": re.compile(r"(?:https?://www\.amazon\.com)?(/(?:[A-Za-z0-9_%.\-]+/)?dp/([A-Z0-9]{10}))", re.I),
    "bestbuy": re.compile(r"(?:https?://www\.bestbuy\.com)?(/product/[A-Za-z0-9_%.\-]+/([A-Z0-9]{8,12})(?:/sku/\d{6,9})?)", re.I),
    "gamestop": re.compile(r"(?:https?://www\.gamestop\.com)?(/[A-Za-z0-9_%.\-/]+/(\d{5,})\.html)", re.I),
}
HOSTS = {"target": "https://www.target.com", "walmart": "https://www.walmart.com", "amazon": "https://www.amazon.com",
         "bestbuy": "https://www.bestbuy.com", "gamestop": "https://www.gamestop.com"}
JUNK = re.compile(r"\b(case of|sealed case|sample|empty|sleeves?|playmat|binder|poster|toploader|proxy|proxies|lot of|custom|"
                  r"pack of \d|wallet|deck box|storage|figure|puzzle|t shirt|tshirt|book)\b")
FETCH = None            # tests put a function(store, url) -> (html, error) here; normally a parked ordinary Chrome is used
GAP = 0.2 if os.environ.get("RK_FINDER_MOCK") else 4.0               # seconds between two store searches
_lock = threading.Lock()
_active = {"keys": set(), "last": ""}


def query_for(name):
    n = products.strip_brand(products.norm(name))
    return "Magic The Gathering " + n


def _strip_tags(s):
    return re.sub(r"\s+", " ", _html.unescape(re.sub(r"<[^>]+>", " ", s or ""))).strip()


def candidates(store, html, base=None):
    """[(clean product link, product id, text about it)] in page order, without duplicates."""
    rx = LINK_RES.get(store)
    if not rx or not html:
        return []
    base = base or HOSTS.get(store, "")
    out, seen = [], set()
    # text next to each link: the link's own text / label, else its address words
    anchors = []
    for m in re.finditer(r"<a\b([^>]*)>(.*?)</a>", html, re.I | re.S):
        attrs, inner = m.group(1), m.group(2)
        h = re.search(r'href\s*=\s*(?:"([^"]*)"|\'([^\']*)\')', attrs, re.I)
        if not h:
            continue
        href = _html.unescape(h.group(1) or h.group(2) or "")
        lab = " ".join(filter(None, [(re.search(r'(?:aria-label|title)\s*=\s*"([^"]*)"', attrs, re.I) or [None, ""])[1], _strip_tags(inner)[:240]]))
        anchors.append((href, lab))
    # links that are only in the page's data (not in an <a>)
    for m in rx.finditer(html.replace("\\/", "/")):
        anchors.append((m.group(1), ""))
    for href, lab in anchors:
        if any(w in href for w in ("/sspa/", "slredirect", "aax-us", "/gp/bestsellers")):
            continue
        m = rx.search(href)
        if not m:
            continue
        path, pid = m.group(1), m.group(2)
        if pid in seen:
            # a later copy of the same link may carry the better text
            for i, (u, p, t) in enumerate(out):
                if p == pid and lab and len(lab) > len(t):
                    out[i] = (u, p, lab)
            continue
        seen.add(pid)
        words = re.sub(r"[/\-_.%]+", " ", urllib.parse.unquote(path.split("?")[0]))
        out.append((_clean_link(store, path, pid), pid, (lab + " " + words).strip()))
    return out


def _clean_link(store, path, pid):
    host = HOSTS.get(store, "")
    path = path.split("?")[0].split("#")[0]
    if store == "amazon":
        return f"{host}/dp/{pid}"
    return host + path


_STOPW = {"the", "and", "for", "with", "of", "a", "an", "to", "in", "by", "ft", "pack", "new"}


def name_words(name):
    """v75: the words of a product's name that must ALL be on a found page (for products outside the MTG sets)."""
    return [w for w in re.findall(r"[a-z0-9]+", products.norm(name or "")) if w not in _STOPW and len(w) > 1]


def too_general(target):
    """v75 (diagnostics 63/64: 'Charging Cable' found three different cables): a product outside the MTG sets whose name has fewer than
    3 telling words is not searched for at the other stores - any cable would match. Give it its full name (brand and model)."""
    return products.is_custom(products.kind_of(target)) and len(name_words(target.get("match_name", ""))) < 3


def pick(store, cands, target):
    """The first candidate whose text names this product. -> (link, text) or None."""
    kind = products.kind_of(target)
    own = products.norm(target.get("match_name", ""))
    must = name_words(target.get("match_name", "")) if products.is_custom(kind) else []
    bad = {str(u).split("#")[0].split("?")[0].rstrip("/").lower() for u in (target.get("exclude") or [])}
    for link, pid, text in cands:
        if str(link).split("#")[0].split("?")[0].rstrip("/").lower() in bad:
            continue                                       # v75: you marked this link as the wrong product
        tn = products.norm(text)
        if JUNK.search(tn) and not JUNK.search(own):
            continue
        if kind == "box" and re.search(r"\b(bundle|play booster|set booster|draft)\b", tn) and not re.search(r"\b(bundle|play booster|set booster|draft)\b", own):
            continue
        if not products.kind_sure(kind, text):           # v62: the result must SAY it is this kind (a box says box/display; a pack does not) - v46 only
            continue                                       # asked "is it clearly something else?" and let a single pack through for a box
        if must and not all(re.search(r"\b" + re.escape(w) + r"\b", tn) for w in must):
            continue                                       # v75: every word of the name (brand, model, size) must be there
        if products.title_matches(tn, target) or (must and len(must) >= 3):
            return link, text
    return None


def search_url(store):
    mock = os.environ.get("RK_FINDER_MOCK")          # tests: a local pretend store instead of the real ones
    if mock:
        return mock.rstrip("/") + "/search/" + store + "?q={q}"
    return SEARCH_URLS.get(store)


def _mock_fetch(store, url):
    import urllib.request
    try:
        return urllib.request.urlopen(url, timeout=10).read().decode("utf-8", "replace"), None
    except Exception as e:
        return None, str(e)[:100]


_BLOCK_RX = re.compile(r"access denied|are you a (human|robot)|unusual (traffic|activity)|captcha|press (&amp;|and) hold|verify (that )?you are|"
                       r"request (was )?blocked|pardon our interruption|robot or human", re.I)


def finder_browsers():
    """v76: the browsers the search uses, in order: your Chrome, Edge, Hidden Chrome, then the built-in one. When a store will not show its
    search page to one of them (blocked, human check, nothing loads) the next one tries the same search."""
    out = []
    try:
        from browser_fetch import RealChromeFetcher
        for kind in ("chrome", "edge"):
            i = RealChromeFetcher.exe_index(kind)
            if i >= 0:
                out.append((kind, i))
        if not out and RealChromeFetcher.available():
            out.append(("chrome", 0))
    except Exception:
        pass
    try:
        from browser_fetch import stealth_ready
        if stealth_ready():
            out.append(("stealth", 0))
    except Exception:
        pass
    out.append(("builtin", 0))
    return out


def _make_finder_browser(kind, idx):
    from browser_fetch import BrowserFetcher
    if kind in ("chrome", "edge"):
        from browser_fetch import RealChromeFetcher
        f = RealChromeFetcher(profile_dir="browser_profile_finder", port=9335 if kind == "chrome" else 9338, store="finder", block_media=True)
        f._exe_idx = idx
        return f
    if kind == "stealth":
        from browser_fetch import StealthChromeFetcher
        return StealthChromeFetcher(profile_dir="browser_profile_finder_stealth", store="finder", block_media=True)
    return BrowserFetcher(store="finder")


def _default_fetch_factory():
    state = {"inst": None, "at": 0, "order": None, "used": {}}
    if os.environ.get("RK_FINDER_MOCK"):
        return _mock_fetch, (lambda: None)

    def _drop():
        inst = state["inst"]
        state["inst"] = None
        if inst is not None:
            try:
                inst.close()
            except Exception:
                pass

    def _one(store, url):
        if state["order"] is None:
            state["order"] = finder_browsers()
        if state["inst"] is None:
            kind, idx = state["order"][state["at"] % len(state["order"])]
            state["inst"] = _make_finder_browser(kind, idx)
        inst = state["inst"]
        html, err = inst.fetch(url)
        if html and not LINK_RES[store].search(html):
            # results are drawn by the page after it loads: give it a few more seconds, twice
            for _ in range(2):
                time.sleep(3.0)
                try:
                    pg = getattr(inst, "_page", None)
                    more = pg.content() if pg is not None else ""
                except Exception:
                    more = ""
                if more and LINK_RES[store].search(more):
                    html = more
                    break
        return html, err

    def fetch(store, url):
        tries = len(state["order"] or finder_browsers())
        html = err = None
        for n in range(tries):
            html, err = _one(store, url)
            bad = (not html) or (not LINK_RES[store].search(html) and bool(_BLOCK_RX.search(html[:60000])))
            if not bad:
                return html, err
            kind = state["order"][state["at"] % len(state["order"])][0]
            state["used"][kind] = "blocked" if html else (err or "no page")[:80]
            if n < tries - 1:
                _drop()                       # this browser was turned away: the next one tries the same search
                state["at"] += 1
        if html:
            return None, "the store turned the search away (human check / blocked) in every browser"
        return html, err

    return fetch, _drop


def search_row(target, stores, add_cb, log=None, stop=None, gaming_fn=None, mark_cb=None):
    """target: {'match_name','kind','aliases'}. stores: store keys to look in. add_cb(store, link) saves a found link
    (returns True if it was saved). mark_cb(store, found) records that the store was searched.
    -> {store: 'found' | 'not found' | 'error: ...'}"""
    log = log or (lambda m: None)
    result = {}
    fetch, close = (FETCH, (lambda: None)) if FETCH else _default_fetch_factory()
    q = urllib.parse.quote_plus(query_for(target.get("match_name", "")))
    try:
        for i, store in enumerate(stores):
            if stop is not None and stop.is_set():
                break
            while gaming_fn is not None and gaming_fn() and not (stop is not None and stop.is_set()):
                time.sleep(15.0)             # never while you are playing
            url = search_url(store)
            if not url:
                continue
            try:
                html, err = fetch(store, url.format(q=q))
            except Exception as e:
                html, err = None, f"{type(e).__name__}: {str(e)[:100]}"
            if not html:
                result[store] = "error: " + str(err or "no page")[:140]
                log(f"[search] {target.get('match_name', '')}: {store} - could not load the search page ({str(err or '')[:100]}).")
            else:
                cands = candidates(store, html)
                got = pick(store, cands, target)
                if got:
                    link, text = got
                    ok = add_cb(store, link)
                    result[store] = "found" if ok else "found (not saved)"
                    log(f"[search] {target.get('match_name', '')}: found at {store}: {link}")
                    if mark_cb:
                        mark_cb(store, True)
                else:
                    result[store] = "not found"
                    log(f"[search] {target.get('match_name', '')}: not found at {store} ({len(cands)} product link(s) on the search page, none matched).")
                    if mark_cb:
                        mark_cb(store, False)
            if i < len(stores) - 1:
                time.sleep(GAP)
    finally:
        close()
    return result


def start_search(key, target, stores, add_cb, log=None, stop=None, gaming_fn=None, mark_cb=None, done_cb=None):
    """Runs search_row in a background thread (one search at a time). Returns False if this row is already being searched."""
    with _lock:
        if key in _active["keys"]:
            return False
        _active["keys"].add(key)

    def run():
        res = {}
        try:
            with _SERIAL:
                res = search_row(target, stores, add_cb, log, stop, gaming_fn, mark_cb)
        except Exception as e:
            if log:
                log(f"[search] stopped by an error: {type(e).__name__}: {str(e)[:100]}")
        finally:
            with _lock:
                _active["keys"].discard(key)
                _active["last"] = f"{target.get('match_name', '')}: " + ", ".join(f"{k} {v}" for k, v in res.items())
            if done_cb:
                try:
                    done_cb(res)
                except Exception:
                    pass
    threading.Thread(target=run, daemon=True, name="finder").start()
    return True


_SERIAL = threading.Lock()


def busy(key=None):
    with _lock:
        return (key in _active["keys"]) if key else bool(_active["keys"])


def summary():
    with _lock:
        return f"searching now: {sorted(_active['keys']) or 'nothing'}; last: {_active['last'] or 'no search yet'}"
