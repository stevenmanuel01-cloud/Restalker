"""Link check (v46): is the product page behind a link really the product of its row?

The program loads every product page anyway. This reads the page's own product name (thumbs.page_title) and compares it with the row:
  - the set name must be in it ('Phyrexia: All Will Be One'),
  - and it must not clearly be another kind of product (a Commander deck, a bundle, a Play Booster box, a single pack ... for a Collector Booster Box row).
A link the PROGRAM found by searching (marked "auto-found") that fails is switched OFF in the table (its switch is turned off; you can turn it back on)
and the log says why. A link you put in yourself is never switched off - the log and the table's tooltip only say it looks wrong.
"""
import threading
import time

import products
import thumbs

VERSION = "v114"
_LOCK = threading.Lock()
_STATE = {"checked": {}, "bad": {}, "off": [], "last": "", "good": {}, "bad_url": {}, "loaded": False}
STATE_PATH = None             # v62: linkcheck_state.json next to app.py (set on first use) - what each link's page was seen to be survives a restart


_PROG = {"ids": None}


def _program_ids():
    """Ids of the links the PROGRAM added from new_products.yaml (they were found by search, so a wrong one may be switched off like any auto-found link)."""
    if _PROG["ids"] is None:
        ids = set()
        try:
            import os
            import yaml
            with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "new_products.yaml"), encoding="utf-8") as f:
                ids = {x.get("id") for x in (yaml.safe_load(f) or {}).get("targets", [])}
        except Exception:
            pass
        _PROG["ids"] = ids
    return _PROG["ids"]


_GENERIC = {"amazon", "com", "target", "walmart", "best", "buy", "bestbuy", "gamestop", "tcgplayer", "www", "the", "page", "not", "found",
            "access", "denied", "robot", "or", "human", "sorry", "error", "something", "went", "wrong", "sign", "in", "just", "a", "moment"}


def _generic(title):
    import re as _re
    words = _re.findall(r"[a-z0-9]+", (title or "").lower())
    return len(words) < 3 or all(w in _GENERIC for w in words)


def _path():
    import os
    global STATE_PATH
    if STATE_PATH is None:
        STATE_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "linkcheck_state.json")
    return STATE_PATH


def _load():
    if _STATE["loaded"]:
        return
    _STATE["loaded"] = True
    try:
        import json
        with open(_path(), encoding="utf-8") as f:
            d = json.load(f) or {}
        _STATE["good"].update({k: v for k, v in (d.get("good") or {}).items() if isinstance(v, dict)})
        _STATE["bad"].update({k: str(v) for k, v in (d.get("bad") or {}).items()})
        _STATE["bad_url"].update({k: str(v) for k, v in (d.get("bad_url") or {}).items()})
    except Exception:
        pass


def _save():
    try:
        import json
        import os
        tmp = _path() + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump({"good": _STATE["good"], "bad": _STATE["bad"], "bad_url": _STATE["bad_url"]}, f)
        os.replace(tmp, _path())
    except Exception:
        pass


def strict_ok(t, title):
    """v62: -> (ok, why). The page's product name must NAME this row's product: the set name, and the kind shown in words
    (a box says box / display / case / '12 packs'; a pack does not; a bundle says bundle). Used before anything is bought."""
    if not (title or "").strip() or _generic(title):
        return False, "its product page has not been read yet"
    kind = products.kind_of(t)
    theme = products.theme_of(t)
    if not products.theme_in_title(theme, title):
        return False, f"the page is '{title[:70]}' - the set name '{theme}' is not in it"
    if not products.kind_sure(kind, title):
        return False, f"the page is '{title[:70]}' - that does not say it is a {kind.replace('_', ' ')}"
    return True, ""


def note_title(t, title, log_fn=None, source="page"):
    """v62: a product name seen for this link (its page, or the buying browser's copy of it) -> remembered (also after a restart)."""
    if not (title or "").strip() or _generic(title):
        return None
    tid = t.get("id", "")
    ok, why = strict_ok(t, title)
    lenient, lwhy = check_title(t, title)
    with _LOCK:
        _load()
        _STATE["checked"][tid] = time.time()
        before = _STATE["bad"].get(tid)
        g0 = _STATE["good"].get(tid) or {}
        if g0.get("by_you") and g0.get("url") == t.get("url", ""):
            return True                           # v63: you looked at this link yourself and said it is the right product - that stands
        if ok:
            _STATE["good"][tid] = {"title": title[:200], "at": time.time(), "url": t.get("url", "")}
            _STATE["bad"].pop(tid, None)
        elif user_link(t):
            pass                                  # v75: your own link is never judged by its page name
        else:
            _STATE["good"].pop(tid, None)
            if not lenient or t.get("found_by"):
                _STATE["bad"][tid] = lwhy or why
                _STATE["bad_url"][tid] = t.get("url", "")
                _STATE["last"] = f"{tid}: {lwhy or why}"
        changed = before != _STATE["bad"].get(tid) or ok
        bad_now = _STATE["bad"].get(tid)
    if changed:
        _save()
    if bad_now and bad_now != before and log_fn:
        log_fn(f"[link check] {tid}: {bad_now}. NOT BOUGHT at this link until it shows the right product (open it and change the link if it is wrong).")
    return ok


def user_link(t):
    """v75 (your rule): a link YOU gave (typed or pasted into the table) is the right product - it is never checked against the row's
    name. Only a link the PROGRAM found by searching is checked. A link you marked wrong is never bought."""
    if not t:
        return False
    if t.get("by_you"):
        return True                               # (you typed / pasted / changed it yourself)
    return not t.get("found_by") and t.get("id") not in _program_ids()


def marked_wrong(t):
    """v75: you pressed 'wrong link' for this very link."""
    tid = t.get("id", "")
    with _LOCK:
        _load()
        return bool(str(_STATE["bad"].get(tid) or "").startswith("you checked it") and _STATE["bad_url"].get(tid) in (None, t.get("url", "")))


def buy_problem(t):
    """v62: -> '' when this link may be bought, else the reason it may not.
      - a link whose page shows ANOTHER product (wrong set, or a pack for a box row, ...) is never bought;
      - a link the PROGRAM found by searching is bought only after its own page was read and shows this row's product;
      - a link you put in yourself is bought unless its page clearly shows another product."""
    tid = t.get("id", "")
    if user_link(t):                              # v75: your own link - bought, unless you marked it wrong
        return ("wrong product - " + _STATE["bad"].get(tid, "")) if marked_wrong(t) else ""
    with _LOCK:
        _load()
        bad = _STATE["bad"].get(tid)
        if bad and _STATE["bad_url"].get(tid) not in (None, t.get("url", "")):
            bad = None                            # the link was changed since: its new page decides
        good = _STATE["good"].get(tid)
    if good and good.get("url") and good.get("url") != t.get("url", ""):
        good = None                               # the link was changed since: its new page decides
    if bad and not good:
        return "wrong product - " + bad
    if t.get("found_by") and not good:
        return "found by search - waiting until its page is read and shows this exact product"
    return ""


def confirm_by_you(t, right):
    """v63: you opened the link and answered "is this exactly the product?" - yes: it may be bought; no: never bought at this link."""
    tid = t.get("id", "")
    with _LOCK:
        _load()
        if right:
            _STATE["good"][tid] = {"title": "confirmed by you", "at": time.time(), "url": t.get("url", ""), "by_you": True}
            _STATE["bad"].pop(tid, None)
        else:
            _STATE["good"].pop(tid, None)
            _STATE["bad"][tid] = "you checked it: this link is NOT the product - change the link"
            _STATE["bad_url"][tid] = t.get("url", "")
    _save()


def verified(tid):
    with _LOCK:
        _load()
        return dict(_STATE["good"].get(tid) or {})


def check_title(t, title):
    """-> (ok, why) for a target dict and the product name its page shows."""
    if not (title or "").strip():
        return True, ""
    # v58: a page that only carries the store's own name ("Amazon.com"), a human-check or an error page says nothing about the
    # product (diagnostics 57: three good links were switched off because Amazon answered with a bare "Amazon.com" page)
    import re as _re
    words = _re.findall(r"[a-z0-9]+", title.lower())
    generic = {"amazon", "com", "target", "walmart", "best", "buy", "bestbuy", "gamestop", "tcgplayer", "www", "the", "page", "not", "found",
               "access", "denied", "robot", "or", "human", "sorry", "error", "something", "went", "wrong", "sign", "in", "just", "a", "moment"}
    if len(words) < 3 or all(w in generic for w in words):
        return True, ""
    kind = products.kind_of(t)
    theme = products.theme_of(t)
    if not products.theme_in_title(theme, title):
        return False, f"the page is '{title[:70]}' - the set name '{theme}' is not in it"
    if not products.kind_fits(kind, title):
        return False, f"the page is '{title[:70]}' - that is not a {kind.replace('_', ' ')}"
    return True, ""


def note(t, html, log_fn=None, switch_off=None, now=None):
    """Called by a checker with a product page it just loaded. -> (ok, why). switch_off(target_id) is called for a wrong auto-found link."""
    try:
        title = thumbs.page_title(html)
    except Exception:
        title = ""
    try:
        note_title(t, title, log_fn)
    except Exception:
        pass
    ok, why = check_title(t, title)
    tid = t.get("id", "")
    with _LOCK:
        _load()
        _STATE["checked"][tid] = now or time.time()
        if ok or user_link(t):                   # v75: your own link is never judged by its page name
            return True, ""
        _STATE["bad"][tid] = why
        _STATE["bad_url"][tid] = t.get("url", "")
        _STATE["last"] = f"{tid}: {why}"
    auto = bool(t.get("found_by")) or tid in _program_ids()
    if False and auto and first and switch_off:          # v58: never switched off by the program - you decide (it is only reported)
        try:
            switch_off(tid)
            with _LOCK:
                _STATE["off"].append(tid)
        except Exception:
            pass
    return False, why


def summary():
    with _LOCK:
        bad = dict(_STATE["bad"])
        off = list(_STATE["off"])
        n = len(_STATE["checked"])
    with _LOCK:
        good = len(_STATE["good"])
    txt = f"{n} links checked against their page's product name; {len(bad)} look wrong (never bought); {good} confirmed as the right product; {len(off)} auto-found ones switched off"
    if bad:
        txt += "\n" + "\n".join(f"  {k}: {v}" for k, v in list(bad.items())[:20])
    return txt
