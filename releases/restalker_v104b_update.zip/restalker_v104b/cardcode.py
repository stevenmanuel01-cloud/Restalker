"""Restalker v77 - your card's security code, saved so checkout needs nobody (owner 2026-10-29: "I want to make sure this process is
completely automated").

The stores keep your card; at checkout some of them (Best Buy, Target, Walmart, GameStop) still ask for the 3-4 digit security code.
Chrome cannot hand that to a program (its autofill only fills when a PERSON picks the card from its list), so Restalker keeps it itself:
  - you type it once in Restalker's page (Card code (top bar)); it is saved ENCRYPTED with Windows' own protection (DPAPI): only your
    Windows account on this PC can read it back - a copy of the file is useless anywhere else;
  - it is never written to the log, the diagnostics, page samples or any file in plain text, and never sent anywhere except into the
    security-code box of the store's own checkout page (by the program's buying browsers);
  - if a store says the code is wrong, the program stops using it (so a wrong code is never tried again and again) and asks you.
Without Windows' protection (not Windows) it is kept in memory only, until the program closes.
"""
import os
import re
import threading
import time

VERSION = "v104b"
HERE = os.path.dirname(os.path.abspath(__file__))
FILE = os.path.join(HERE, "card_code.bin")
_lock = threading.Lock()
_mem = {"code": None, "loaded": False, "suspect": None, "used": 0, "last_used": 0.0}


def _dpapi(data, protect):
    """Windows' own encryption for this user (CryptProtectData / CryptUnprotectData). Returns bytes or None."""
    if os.name != "nt":
        return None
    try:
        import ctypes
        from ctypes import wintypes

        class BLOB(ctypes.Structure):
            _fields_ = [("cbData", wintypes.DWORD), ("pbData", ctypes.POINTER(ctypes.c_char))]
        buf = ctypes.create_string_buffer(data, len(data))
        src = BLOB(len(data), ctypes.cast(buf, ctypes.POINTER(ctypes.c_char)))
        out = BLOB()
        crypt32, kernel32 = ctypes.windll.crypt32, ctypes.windll.kernel32
        fn = crypt32.CryptProtectData if protect else crypt32.CryptUnprotectData
        ok = fn(ctypes.byref(src), "Restalker card code" if protect else None, None, None, None, 0x01, ctypes.byref(out))   # 0x01: no prompt
        if not ok:
            return None
        try:
            return ctypes.string_at(out.pbData, out.cbData)
        finally:
            kernel32.LocalFree(out.pbData)
    except Exception:
        return None


def _load():
    if _mem["loaded"]:
        return
    _mem["loaded"] = True
    try:
        raw = open(FILE, "rb").read()
    except OSError:
        return
    plain = _dpapi(raw, False)
    if plain and re.fullmatch(rb"\d{3,4}", plain):
        _mem["code"] = plain.decode()


def save(value):
    """-> {"ok", "saved_to_disk", "reason"}"""
    v = re.sub(r"\D", "", str(value or ""))
    if not 3 <= len(v) <= 4:
        return {"ok": False, "reason": "the security code has 3 or 4 digits"}
    with _lock:
        _mem["code"], _mem["loaded"], _mem["suspect"] = v, True, None
        enc = _dpapi(v.encode(), True)
        disk = False
        if enc:
            try:
                tmp = FILE + ".tmp"
                with open(tmp, "wb") as f:
                    f.write(enc)
                os.replace(tmp, FILE)
                disk = True
            except OSError:
                disk = False
    return {"ok": True, "saved_to_disk": disk}


def remove():
    with _lock:
        _mem["code"], _mem["loaded"], _mem["suspect"] = None, True, None
        try:
            os.remove(FILE)
        except OSError:
            pass
    return {"ok": True}


def get():
    """The code for a checkout (None when there is none, or it was turned away by a store)."""
    with _lock:
        _load()
        if _mem["suspect"]:
            return None
        if _mem["code"]:
            _mem["used"] += 1
            _mem["last_used"] = time.time()
        return _mem["code"]


def have():
    with _lock:
        _load()
        return bool(_mem["code"])


def mark_wrong(store_name, why=""):
    """A store said the security code is wrong: it is not used again until you save it again."""
    with _lock:
        if _mem["code"] and not _mem["suspect"]:
            _mem["suspect"] = {"store": store_name, "why": str(why)[:120], "at": time.time()}
            return True
    return False


WRONG_RX = re.compile(r"security code|\bcvv\b|\bcvc\b|\bcsc\b|card (verification|code)", re.I)


def looks_wrong(text):
    """True when a store's message is about the security code (not just any payment trouble)."""
    return bool(WRONG_RX.search(str(text or "")))


def status():
    with _lock:
        _load()
        s = _mem["suspect"]
        return {"saved": bool(_mem["code"]), "on_disk": os.path.exists(FILE), "protected": os.name == "nt",
                "paused": (f"{s['store']} said it is wrong - save it again to use it" if s else ""), "used": _mem["used"]}
