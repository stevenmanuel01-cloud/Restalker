"""v138 (owner 2026-11-17: "a max amount of 3 purchases for each product ever (with the exception of my master account) ... Im not sure the
best way to mark my specific instance as master but that part is important"): which Restalker is the owner's own (the master).

The master is recognised without anything to set up: this PC's private report code (report.py) is compared with the owner's - only a
one-way fingerprint (sha256) of it is in the program, so the code itself is never public and cannot be worked out from it. As a spare
key the owner has a master code (typed once: Help > Master code); again only its fingerprint is here. The owner's phone app is
recognised the same way; a phone or tablet linked to this PC is told (inside the sealed link) that this PC is the master.
"""
import hashlib
import os

VERSION = "v151"
FILE = "master.txt"
HASHES = {
    "77f1096b2366d0cc97ad304aeb07cbbe49baf9d5475b594910f73008175c6948",     # the owner's PC (its report code)
    "6168946e644a94ac4d5c14e7becf946436ef2e8e8bc19895e57f662f5259db03",     # the owner's phone (its report code)
    "ade0a35119b780e65be47fcfb31222e9f863eb97d4b9639ef59b646b27d5be62",     # the owner's master code
}
_cache = {"v": None}


def _fp(s):
    return hashlib.sha256(str(s or "").strip().encode()).hexdigest()


def code_ok(code):
    return _fp(code) in HASHES


def is_master():
    if _cache["v"] is not None:
        return _cache["v"]
    v = False
    try:
        import report
        v = _fp(report.code()) in HASHES
    except Exception:
        pass
    if not v:
        try:
            with open(FILE, encoding="utf-8") as f:
                v = code_ok(f.read())
        except Exception:
            pass
    _cache["v"] = v
    return v


def enter(code):
    """The master code typed on this PC -> True (kept in master.txt) or False (wrong; nothing kept)."""
    if not code_ok(code):
        return False
    with open(FILE, "w", encoding="utf-8") as f:
        f.write(str(code).strip())
    _cache["v"] = True
    return True


def status_text():
    return f"master (v138): {'YES - the purchase limit does not apply here' if is_master() else 'no - at most 3 purchases of each product'}"
