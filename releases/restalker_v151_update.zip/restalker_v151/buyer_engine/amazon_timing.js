// Restalker v151: WHERE THE TIME GOES on Amazon's own pages - measured, not guessed. Reads only; presses nothing; changes nothing.
// Diagnostics 97: 864 checkout tries for one listing, none won; one try every 11-14 s. In the lab the engine itself needs 0.05 s per
// try - the rest is Amazon's two pages loading. This part runs from the first moment of a product page or a checkout page and notes,
// in milliseconds from the start of the page load: when the first byte came, when the Buy Now button / title / price / seller were
// in the page, when the page was complete enough for the engine to start (it starts when the page is "idle"), and on a checkout page
// when Amazon's verdict (Place your order, or "unavailable") was in the page. Restalker's diagnostics show the middle and slow values.
(() => {
  if (window.top !== window || globalThis.__rkT) return;
  const path = location.pathname;
  const kind = /\/(?:dp|gp\/product|gp\/aw\/d)\//i.test(path) ? 'product' : /^\/(?:checkout\/|gp\/buy\/|buy\/|gp\/checkoutportal\/)/i.test(path) ? 'checkout' : '';
  if (!kind) return;
  const marks = {}, now = () => Math.round(performance.now());
  const mark = k => { if (!(k in marks)) marks[k] = now(); };
  const has = sel => { try { return !!document.querySelector(sel); } catch { return false; } };
  const UNAVAIL = /you cannot buy this item because it(?:'s|’s| is) out of stock|item is no longer available|this item is currently unavailable|no longer available from the seller|removed from your order/i;
  let lastText = 0, sent = false, queued = false;
  function look() {
    queued = false;
    if (kind === 'product') {
      if (document.getElementById('buy-now-button')) mark('buyNow');
      if (document.getElementById('add-to-cart-button')) mark('addToCart');
      if (document.getElementById('productTitle')) mark('title');
      if (has('#corePrice_feature_div .a-offscreen, #corePriceDisplay_desktop_feature_div .a-offscreen, #apex_desktop .a-offscreen, #price_inside_buybox')) mark('price');
      if (document.getElementById('availability') || document.getElementById('outOfStock')) mark('availability');
      if (has('#merchantInfoFeature_feature_div, #tabular-buybox, #offerDisplayFeatures_desktop, #merchant-info')) mark('seller');
      if (document.getElementById('addToCart')) mark('form');
      // (the part of the page after the buy box has begun: the buy box is complete)
      if (('buyNow' in marks || 'addToCart' in marks) && has('#centerCol, #feature-bullets, #productOverview_feature_div, #aplus, #detailBullets_feature_div')) mark('afterBox');
    } else {
      if (has('input[name="placeYourOrder1"], #placeOrder, #submitOrderButtonId, #bottomSubmitOrderButtonId, [data-testid*="place-order" i], [name*="placeYourOrder" i]')) mark('placeOrder');
      if (!('unavailable' in marks) && document.body && (lastText === 0 || now() - lastText > 90)) { lastText = now(); if (UNAVAIL.test(document.body.innerText || '')) mark('unavailable'); }
    }
  }
  const mo = new MutationObserver(() => { if (!queued) { queued = true; setTimeout(look, 25); } });
  try { mo.observe(document, {childList: true, subtree: true}); } catch {}
  const tick = setInterval(() => { if (sent) clearInterval(tick); else look(); }, 100);        // (a page that stands still while a part of it loads is looked at too)
  document.addEventListener('DOMContentLoaded', () => { mark('dom'); look(); }, {once: true});
  window.addEventListener('load', () => { mark('load'); look(); setTimeout(done, 1200); }, {once: true});
  window.addEventListener('pagehide', done, {once: true});
  setTimeout(done, 20000);
  globalThis.__rkT = k => { mark(String(k)); if (k === 'idle') look(); };       // ('idle' is marked by amazon_timing_idle.js - the moment the engine's own page part starts)
  function done() {
    if (sent) return; sent = true;
    try { mo.disconnect(); } catch {}
    look();
    let first = null, got = null;
    try { const n = performance.getEntriesByType('navigation')[0]; if (n) { first = Math.round(n.responseStart); got = Math.round(n.responseEnd); } } catch {}
    const asin = (path.match(/\/(?:dp|gp\/product|gp\/aw\/d)\/([A-Z0-9]{10})/i) || [])[1] || (new URLSearchParams(location.search).get('asin') || '');
    try { chrome.runtime.sendMessage({type: 'RK_PAGE_TIMING', kind, asin: String(asin).toUpperCase().slice(0, 10), path: path.replace(/[0-9]{3}-[0-9]{7}-[0-9]{7}/g, '#').slice(0, 60),
      first, got, marks, at: Date.now()}).catch(() => {}); } catch {}
  }
})();
