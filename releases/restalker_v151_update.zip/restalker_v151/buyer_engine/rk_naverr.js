// Restalker v151: the browser's REAL reason when a store page does not load.
// Diagnostics 97: thirteen Best Buy checkouts ended with "the page part could not be added: Frame with ID 0 is showing error page" - the
// browser was showing its own error page instead of the store's, and nothing said WHY (the store cut the connection? no answer? this
// PC's internet?). The browser knows the reason; from v151 it is recorded per tab the moment it happens, put into the failure text, and
// the checkout loads the page again at once (until v150 it sat on the error page for 15 s first).
(function () {
  const last = new Map();        // tab -> {error, url, at}                (the page of this tab could not be loaded)
  const prev = new Map();        // tab -> the same, of the load before the one running now
  const http = new Map();        // tab -> {status, url, at}               (the store's answer number for the page, when it was 400 or more)
  const count = new Map();       // "store error" -> {n, at}
  const STORES = ['bestbuy', 'target', 'walmart', 'gamestop', 'amazon'];
  const store = u => { try { const h = new URL(u).hostname.toLowerCase(); return STORES.find(s => h === s + '.com' || h.endsWith('.' + s + '.com')) || ''; } catch { return ''; } };
  const bare = e => String(e || '').replace(/^net::/, '');
  // what each of the browser's reasons means, in plain words
  function meaning(e, status) {
    e = bare(e);
    if (status === 403) return 'the store refused this browser (it takes it for a bot)';
    if (status === 429) return 'the store says: too many requests from this PC';
    if (status >= 500) return "the store's own servers failed";
    if (status >= 400) return 'the store answered with an error';
    if (/INTERNET_DISCONNECTED|NAME_NOT_RESOLVED|NETWORK_CHANGED|ADDRESS_UNREACHABLE|NETWORK_ACCESS_DENIED|PROXY|DNS/.test(e)) return "this PC's internet connection";
    if (/TIMED_OUT/.test(e)) return 'the store did not answer';
    if (/HTTP2|QUIC|SPDY|CONNECTION_(RESET|CLOSED|ABORTED)|EMPTY_RESPONSE|SSL|SOCKET/.test(e)) return 'the store cut the connection (it does that to a browser it takes for a bot, and when it is overloaded)';
    if (/CONNECTION_(REFUSED|FAILED)/.test(e)) return 'the store could not be reached';
    if (/TOO_MANY_REDIRECTS/.test(e)) return 'the store sent the browser in a circle (its cookies are out of order)';
    if (/BLOCKED_BY/.test(e)) return 'something on this PC blocked the page';
    if (/CERT/.test(e)) return "the page's security certificate was not accepted";
    return 'the browser could not load it';
  }
  const kind = (e, status) => /internet connection/.test(meaning(e, status)) ? 'offline' : (status === 403 || status === 429) ? 'refused' : 'cut';
  function note(tabId, error, url) {
    error = bare(error);
    if (!error || error === 'ERR_ABORTED') return;                 // (aborted = the browser itself went on to another page)
    const s = store(url);
    if (!s) return;
    const h = http.get(tabId), status = h && Date.now() - h.at < 15000 ? h.status : 0;
    last.set(tabId, {error, url: String(url).replace(/\?.*/, '').slice(0, 120), at: Date.now(), status});
    const k = s + ' ' + error + (status ? ' ' + status : ''), c = count.get(k) || {n: 0, at: 0};
    count.set(k, {n: c.n + 1, at: Date.now()});
    try { if (typeof diag === 'function') diag('nav_error', {store: s, error, status, url: String(url).replace(/\?.*/, '').slice(0, 120)}); } catch {}
  }
  try {
    chrome.webNavigation.onBeforeNavigate.addListener(d => { if (d.frameId === 0) { const x = last.get(d.tabId); if (x) prev.set(d.tabId, x); last.delete(d.tabId); http.delete(d.tabId); } });
    chrome.webNavigation.onErrorOccurred.addListener(d => { if (d.frameId === 0) note(d.tabId, d.error, d.url); });
  } catch {}
  try {
    chrome.webRequest.onCompleted.addListener(d => {
      if (d.tabId >= 0 && d.statusCode >= 400) http.set(d.tabId, {status: d.statusCode, url: d.url, at: Date.now()});
    }, {urls: STORES.flatMap(s => ['https://' + s + '.com/*', 'https://*.' + s + '.com/*']), types: ['main_frame']});
  } catch {}
  try { chrome.tabs.onRemoved.addListener(id => { last.delete(id); prev.delete(id); http.delete(id); }); } catch {}
  globalThis.RestalkerNav = {
    // -> {error, status, url, at, text, kind} for a tab whose page could not be loaded just now, else null
    // the same, also from the load just before (for a tab that IS showing an error page while the browser tries again by itself)
    recent(tabId, withinMs = 20000) { return this.last(tabId, withinMs) || this.last(tabId, withinMs, prev); },
    last(tabId, withinMs = 60000, from = last) {
      const x = from.get(tabId);
      if (!x || Date.now() - x.at > withinMs) return null;
      return {...x, kind: kind(x.error, x.status), text: x.error + (x.status ? ' (answer ' + x.status + ')' : '') + ' - ' + meaning(x.error, x.status)};
    },
    // the store's answer number for this tab's page when it was an error (403, 429, 503 ...), else 0
    status(tabId, withinMs = 60000) { const h = http.get(tabId); return h && Date.now() - h.at < withinMs ? h.status : 0; },
    meaning, note,
    counts() { return [...count.entries()].map(([k, v]) => ({what: k, n: v.n, at: v.at})).sort((a, b) => b.n - a.n).slice(0, 30); },
    _reset() { last.clear(); prev.clear(); http.clear(); count.clear(); }
  };
})();
