// Restalker v151: takes the page timings (amazon_timing.js) and hands them to Restalker for its diagnostics.
(function () {
  const kept = [];
  try {
    chrome.runtime.onMessage.addListener((m, sender) => {
      if (!m || m.type !== 'RK_PAGE_TIMING' || !sender || !sender.tab) return;
      const row = {kind: m.kind === 'checkout' ? 'checkout' : 'product', asin: String(m.asin || '').slice(0, 10), path: String(m.path || '').slice(0, 60),
        first: Number.isFinite(m.first) ? m.first : null, got: Number.isFinite(m.got) ? m.got : null, at: Number(m.at) || Date.now(), marks: {}};
      for (const [k, v] of Object.entries(m.marks || {}).slice(0, 16)) if (Number.isFinite(v)) row.marks[String(k).slice(0, 16)] = Math.round(v);
      kept.push(row); if (kept.length > 300) kept.shift();
      try { if (globalThis.buyerDetectorBridge && globalThis.buyerDetectorBridge.tell) globalThis.buyerDetectorBridge.tell({type: 'page_timing', row}); } catch {}
    });
  } catch {}
  globalThis.RestalkerTiming = {all: () => kept.slice()};
})();
