// Restalker v151: marks the moment the engine's own page part starts on an Amazon page (see amazon_timing.js).
try { if (typeof globalThis.__rkT === 'function') globalThis.__rkT('idle'); } catch {}
