"""v137 (owner 2026-11-17: "contributors ... crowdsourcing the information for everyone to share" - chose "Build real sharing"):
the Restalker crowd. Every Restalker (PCs and phone apps) that has sharing on tells the others, on one public channel, when it sees a
product of the central list (mobile/catalog.json) come IN STOCK at a store - the product's Amazon code, the store, the price and the time.
Nothing else: no name, no account, no order, no address, no products of your own that are not on the central list. Each device has a
random contributor number (made here, not tied to anything) so the devices can be counted.

What a sighting from the crowd does here: the program LOOKS at that product at that store itself at once (like a tracker alert) - it
never buys on the crowd's word; it buys only what its own look sees in stock under YOUR cap. A false or old sighting therefore costs one
extra look at most (and each product is looked at no more than once every 2 minutes because of the crowd).
"""
import json
import os
import re
import secrets
import threading
import time
import urllib.request

VERSION = "v154"
SERVER = "https://ntfy.sh"
TOPIC = "restalker-crowd-5e1f0c7a92b4"
FILE = "crowd.json"
CATALOG_URL = "https://raw.githubusercontent.com/stevenmanuel01-cloud/Restalker/main/mobile/catalog.json"
STORES = ("Amazon", "Target", "Walmart", "Best Buy", "GameStop", "TCGplayer", "Barnes & Noble", "Costco", "Sam's Club", "Pokemon Center")
HELLO_EVERY = 6 * 3600
POLL_EVERY = 20
LOOK_GAP = 120                 # a product at a store is looked at no more than once in 2 minutes because of the crowd
LOOKS_PER_HOUR = 40
FIRST_SINCE = "12h"             # v139: the first read goes back 12 h (the channel keeps 12 h; everyone says hello every 6 h) - the count is right at once
SEEN_MAX = 20000
ASIN = re.compile(r"^B[0-9A-Z]{9}$")
LOG = print

_lock = threading.Lock()
_st = None
_cat = {"at": 0.0, "asins": set()}
_looked = {}                   # (asin, store) -> time looked because of the crowd
_hour = []                     # times of looks because of the crowd (last hour)
_stats = {"heard": 0, "shared": 0, "looks": 0, "ignored": 0, "error": "", "last": 0.0, "connects": 0, "refused": 0, "mode": "poll",
          "relay_shared": 0, "relay_heard": 0, "ntfy_shared": 0}
_look = {"f": None}            # v147: what start() was given (the relay's crowd line makes it look the same way)


def _load():
    global _st
    if _st is None:
        try:
            with open(FILE, encoding="utf-8") as f:
                _st = json.load(f)
        except Exception:
            _st = {}
        if not re.fullmatch(r"[0-9a-f]{12}", str(_st.get("id") or "")):
            _st["id"] = secrets.token_hex(6)
        _st.setdefault("on", True)
        _st.setdefault("seen", {})
        _st.setdefault("since", "")
        _st.setdefault("hello", 0.0)
    return _st


def _save():
    try:
        tmp = FILE + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(_st, f)
        os.replace(tmp, FILE)
    except Exception:
        pass


def on():
    with _lock:
        return bool(_load().get("on"))


def set_on(v):
    with _lock:
        _load()["on"] = bool(v)
        _save()
    LOG(f"[crowd] sharing with the Restalker crowd switched {'ON' if v else 'OFF'}.")


def my_id():
    with _lock:
        return _load()["id"]


def count():
    """Every contributor heard so far (this one included) - the 'total contributors and counting'."""
    with _lock:
        s = _load()
        return len(set(s["seen"]) | {s["id"]})


def _catalog(http=None, now=None):
    """The central list's Amazon codes (fetched at most every 6 hours) - only these products are shared."""
    now = now or time.time()
    if now - _cat["at"] < 6 * 3600 and _cat["asins"]:
        return _cat["asins"]
    try:
        body = (http or _get)(CATALOG_URL)
        d = json.loads(body)
        a = {str(x.get("a")) for x in d.get("products") or [] if ASIN.match(str(x.get("a") or ""))}
        if a:
            _cat.update(at=now, asins=a)
    except Exception as e:
        _stats["error"] = f"central list: {str(e)[:80]}"
        _cat["at"] = now - 6 * 3600 + 600          # (try again in 10 minutes)
    return _cat["asins"]


def _get(url, timeout=25):
    req = urllib.request.Request(url, headers={"User-Agent": "Restalker/" + VERSION, "Cache-Control": "no-cache"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read(2_000_000).decode("utf-8", "replace")


def _post(obj, http=None):
    data = json.dumps(obj, separators=(",", ":")).encode()
    if http:
        return http(f"{SERVER}/{TOPIC}", data)
    req = urllib.request.Request(f"{SERVER}/{TOPIC}", data=data, method="POST",
                                 headers={"User-Agent": "Restalker/" + VERSION, "Title": "rk-crowd"})
    with urllib.request.urlopen(req, timeout=20) as r:
        return r.status


def clean(m, now=None):
    """One message from the channel -> a clean dict, or None (anything odd is dropped)."""
    now = now or time.time()
    if not isinstance(m, dict) or m.get("v") != 1:
        return None
    c = str(m.get("c") or "")
    if not re.fullmatch(r"[0-9a-f]{12}", c):
        return None
    k = m.get("k")
    if k == "h":
        return {"k": "h", "c": c}
    if k != "s":
        return None
    a, s, st = str(m.get("a") or ""), str(m.get("s") or ""), m.get("st")
    if not ASIN.match(a) or s not in STORES or st not in ("in", "out"):
        return None
    try:
        t = float(m.get("t"))
    except Exception:
        return None
    if abs(now - t) > 3600:                       # only fresh news
        return None
    p = m.get("p")
    p = float(p) if isinstance(p, (int, float)) and 0 < p < 100000 else None
    return {"k": "s", "c": c, "a": a, "s": s, "st": st, "p": p, "t": t}


def share(asin, store, st="in", price=None, http=None, now=None, catalog=None, relay_http=None):
    """This program saw [asin] (a product of the central list) in stock at [store]: tell the crowd. -> True when sent."""
    now = now or time.time()
    if not on() or not ASIN.match(str(asin or "")) or store not in STORES or st not in ("in", "out"):
        return False
    if asin not in (catalog if catalog is not None else _catalog()):
        return False
    o = {"v": 1, "c": my_id(), "k": "s", "a": asin, "s": store, "st": st, "t": round(now, 1)}
    if isinstance(price, (int, float)) and 0 < price < 100000:
        o["p"] = round(float(price), 2)
    # v147: to the Restalker relay first (it has no daily message limit; every Restalker from v147 / app 1.0.6 reads the crowd there),
    # and to the old crowd channel too while that takes it - versions before read only there, and it reaches them at once
    took = False
    if st == "in":
        try:
            import relay
            took = bool(relay.share([o], http=relay_http))
            if took:
                _stats["relay_shared"] += 1
        except Exception:
            pass
    try:
        _post(o, http)
        _stats["ntfy_shared"] += 1
        took = True
    except Exception as e:
        if not took:
            _stats["error"] = f"share: {str(e)[:80]}"
    if took:
        _stats["shared"] += 1
    return took


def relay_since():
    """v147: where reading the crowd's line on the relay goes on ("" = from the start)."""
    with _lock:
        return str(_load().get("rsince") or "")


def relay_take(lines, now=None):
    """v147: the crowd's new lines from the relay (relay.sync) - the same messages as on the old channel, taken the same way. A
    sighting that came both ways makes one look (LOOK_GAP)."""
    lines = [x for x in (lines or []) if isinstance(x, dict)]
    if not lines:
        return 0
    last = max((int(x["id"]) for x in lines if str(x.get("id") or "").isdigit()), default=None)
    if last is not None:
        with _lock:
            _load()["rsince"] = str(last)
    _stats["relay_heard"] += len(lines)
    _stats["last"] = now or time.time()
    take([json.dumps(x) for x in lines], _look["f"] or (lambda *a: False), now, mark=False)
    return len(lines)


def hello(http=None, now=None, force=False):
    """Every 6 hours: 'this contributor is here' (for the count).
    v147: not sent any more unless forced - the count is the relay's live one since v141 (this PC says "I am here" there with every
    round), and each hello was one of the home's 250 free messages a day. (Versions before v141 keep their own running total.)"""
    if not force:
        return False
    now = now or time.time()
    with _lock:
        s = _load()
        if not s.get("on") or (not force and now - float(s.get("hello") or 0) < HELLO_EVERY):
            return False
    try:
        _post({"v": 1, "c": my_id(), "k": "h"}, http)
        with _lock:
            _load()["hello"] = now
            _save()
        return True
    except Exception as e:
        _stats["error"] = f"hello: {str(e)[:80]}"
        return False


def take(lines, look, now=None, mark=True):
    """Messages read from the channel (ntfy's json lines) -> contributors counted; a fresh in-stock sighting of another contributor
    makes [look](asin, store, price) run (at most once per product and store in LOOK_GAP, LOOKS_PER_HOUR in all)."""
    now = now or time.time()
    me = my_id()
    for line in lines:
        try:
            ev = json.loads(line)
        except Exception:
            continue
        if not isinstance(ev, dict):
            continue
        if ev.get("event") != "message":
            continue                               # (v142: "open" / "keepalive" lines of the open connection carry an id of their own - not a mark)
        if ev.get("id") and mark:                  # (mark=False: lines from the relay - they have their own mark, relay_take)
            with _lock:
                _load()["since"] = str(ev["id"])[:40]
        try:
            m = clean(json.loads(ev.get("message") or ""), now)
        except Exception:
            m = None
        if not m:
            _stats["ignored"] += 1
            continue
        _stats["heard"] += 1
        with _lock:
            seen = _load()["seen"]
            seen[m["c"]] = round(now)
            if len(seen) > SEEN_MAX:
                for k_ in sorted(seen, key=seen.get)[: len(seen) - SEEN_MAX]:
                    seen.pop(k_, None)
        if m["k"] != "s" or m["st"] != "in" or m["c"] == me or not on():
            continue
        key = (m["a"], m["s"])
        _hour[:] = [x for x in _hour if now - x < 3600]
        if now - _looked.get(key, 0) < LOOK_GAP or len(_hour) >= LOOKS_PER_HOUR:
            continue
        _looked[key] = now
        _hour.append(now)
        try:
            if look(m["a"], m["s"], m["p"]):
                _stats["looks"] += 1
        except Exception:
            pass
    with _lock:
        _save()


def poll(look, http=None, now=None):
    """One read of the channel (only what is new since the last read)."""
    with _lock:
        since = _load().get("since") or ""
    url = f"{SERVER}/{TOPIC}/json?poll=1&since={since or FIRST_SINCE}"      # v139: the first read hears every hello of the last 12 h
    try:
        body = (http or _get)(url)
        _stats["last"] = now or time.time()
        take(body.splitlines(), look, now)
        _stats["error"] = ""
    except Exception as e:
        _stats["error"] = f"read: {str(e)[:80]}"


def _beat():
    try:                                         # v141: "active now" (the live count of working devices - relay.py)
        import relay
        relay.heartbeat()
    except Exception:
        pass


def listen(look, stop_event, opener=None):
    """v142 (diagnostics of 2026-11-20: ntfy answered "429 Too Many Requests" - the PC's link to the phones, its reports and its phone
    messages failed for hours; every Restalker at one home shares one internet address, and ntfy.sh allows each address about one request
    every 5 seconds): the channel is read over ONE open connection that ntfy keeps open and writes each new message into at once (it says
    "keepalive" every 45 s) - instead of a new request every 20 s (180 an hour; now about 1). A sighting also arrives at once, not up
    to 20 s later. Returns when the connection ends (the caller opens it again)."""
    with _lock:
        since = _load().get("since") or ""
    url = f"{SERVER}/{TOPIC}/json?since={since or FIRST_SINCE}"
    req = urllib.request.Request(url, headers={"User-Agent": "Restalker/" + VERSION, "Cache-Control": "no-cache"})
    with (opener or urllib.request.urlopen)(req, timeout=120) as r:      # (a read waits at most 120 s: ntfy writes every 45 s)
        _stats["connects"] += 1
        _stats["mode"] = "open connection"
        _stats["error"] = ""
        for raw in r:
            if stop_event.is_set() or not on():
                return
            line = raw.decode("utf-8", "replace").strip()
            _stats["last"] = time.time()
            if line and '"event":"message"' in line.replace(" ", ""):
                take([line], look)
            hello()
            _beat()


def start(look, stop_event):
    """The program: the channel over one open connection (listen); when it cannot be opened, waited 30 s - 2 min (longer after a
    "429") and opened again - a read with each new connection catches up whatever came meanwhile (since). Hello every 6 hours."""
    _look["f"] = look

    def pump():                                          # v147: the crowd's line on the relay, for a PC without linked devices
        while not stop_event.is_set():
            try:
                if on():
                    import relay
                    relay.pump()
            except Exception:
                pass
            stop_event.wait(30)
    threading.Thread(target=pump, daemon=True, name="crowd-relay").start()

    def loop():
        fails = 0
        while not stop_event.is_set():
            if not on():
                stop_event.wait(POLL_EVERY)
                continue
            hello()
            _beat()
            try:
                listen(look, stop_event)
                fails = 0
                stop_event.wait(2)                       # (closed by ntfy after a while: opened again)
            except Exception as e:
                fails += 1
                busy = "429" in str(e)
                if busy:
                    _stats["refused"] += 1
                _stats["error"] = f"read: {str(e)[:80]}"
                _stats["mode"] = "waiting to connect again"
                stop_event.wait(min(600, (120 if busy else 30) * min(fails, 5)))
    threading.Thread(target=loop, daemon=True, name="crowd").start()


def status_text():
    s = _stats
    return (f"Restalker crowd (v137): sharing {'ON' if on() else 'OFF'}; relay (v147): {s['relay_shared']} shared, {s['relay_heard']} read; "
            f"old channel: {s['ntfy_shared']} shared, read over {s['mode']} ({s['connects']} connect(s), ntfy busy {s['refused']}x); "
            f"{count()} contributor(s) heard so far; this session: "
            f"{s['heard']} message(s) read, {s['shared']} sighting(s) shared, {s['looks']} look(s) because of the crowd, {s['ignored']} odd message(s) "
            f"dropped" + (f"; last problem: {s['error']}" if s['error'] else ""))
