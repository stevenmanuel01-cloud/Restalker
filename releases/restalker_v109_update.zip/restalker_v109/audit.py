"""Checks the program's own work against the trackers: for every tracker alert, did the program log a restock for that product,
and who was first? Alerts the program did NOT match are listed with what the program's log says about that product at the time,
so a missed restock explains itself (price over the limit, price unreadable, store blocked, no check made, ...)."""
import csv
import os
import re
import time
from datetime import datetime, timezone

VERSION = "v109"
AGE_RE = re.compile(r"(\d+)\s*(s|m|h|d)\w*\s+ago", re.I)
UNIT = {"s": 1.0, "m": 60.0, "h": 3600.0, "d": 86400.0}
MATCH_BEFORE = 1800.0      # our restock up to this long before the alert still counts as the same event
MATCH_AFTER = 1800.0       # ... and up to this long after it


def _ts(s):
    try:
        return datetime.fromisoformat(str(s).strip().replace("Z", "+00:00")).astimezone(timezone.utc).timestamp()
    except Exception:
        return None


def _rows(path):
    out = []
    for p in (path, path + ".pending"):
        if not os.path.exists(p):
            continue
        try:
            with open(p, newline="", encoding="utf-8", errors="replace") as f:
                r = csv.reader(f)
                for row in r:
                    if row and row[0] and row[0][0].isdigit():
                        out.append(row)
        except Exception:
            pass
    return out


def load_alerts(path):
    """-> [(event_time, tracker, target, snippet, exact)] ; event_time = when the tracker really posted it
    (a feed card's age is taken off the moment we saw it; a push alert's arrival time is exact)."""
    res = []
    for row in _rows(path):
        if len(row) < 4:
            continue
        t = _ts(row[0])
        if t is None:
            continue
        sn = row[3]
        exact = "[push alert]" in sn or "push alert" in sn.lower()
        if not exact:
            m = AGE_RE.search(sn)
            if m:
                t -= int(m.group(1)) * UNIT[m.group(2).lower()]
        if "[push alert]" in sn and not re.search(r"in stock|restock|available", sn, re.I):
            continue                      # price drops etc. are not restocks
        res.append((t, row[1], row[2], sn, exact))
    return res


def load_restocks(path):
    """-> {target: [(logged_time, window_sec)]}"""
    out = {}
    for row in _rows(path):
        if len(row) < 3 or row[2] != "RESTOCK":
            continue
        t = _ts(row[0])
        if t is None:
            continue
        try:
            w = float(row[5]) if len(row) > 5 and row[5] != "" else None
        except Exception:
            w = None
        out.setdefault(row[1], []).append((t, w))
    return out


def log_lines_for(log_path, target, t0, t1, limit=3):
    """The program's own log lines about this product between t0 and t1."""
    hits = []
    if not os.path.exists(log_path):
        return hits
    try:
        with open(log_path, encoding="utf-8", errors="replace") as f:
            for ln in f:
                if target not in ln or len(ln) < 30:
                    continue
                t = _ts(ln[:32].split(" ")[0])
                if t is None or t < t0 or t > t1:
                    continue
                if any(k in ln for k in ("[price]", "[block]", "[evidence]", "[pace]", "[light]", "[info]", "[warn]", "RESTOCK", "[stats]")):
                    hits.append(ln.strip()[:230])
    except Exception:
        return []
    return hits[-limit:]


def why(lines):
    j = " ".join(lines).lower()
    if not lines:
        return "no check of this product was logged around that time (a quiet product is looked at only now and then, or the store was switched off / starved)"
    if "above the" in j and "limit" in j:
        return "the store showed it, but at a price above your limit (counted as a reseller)"
    if "could not be read" in j or "price could not" in j:
        return "it looked in stock but the price could not be read, so it was not counted"
    if "block" in j:
        return "the store was blocking the program at that time"
    if "reads out_of_stock" in j or "out_of_stock" in j:
        return "the program's own look at that time said out of stock"
    return "see the lines below"


def report(alerts_path="alerts.csv", gt_path="ground_truth.csv", log_path="debug.log", hours=48.0, now=None, limit=25):
    """-> (text, stats). stats: dict with counts."""
    import time
    now = now or time.time()
    al = [a for a in load_alerts(alerts_path) if now - a[0] <= hours * 3600]
    gt = load_restocks(gt_path)
    ours_first = tracker_first = unmatched = 0
    lag = []
    per = {}                 # v52: tracker -> [tracker minus program, ...] (negative = the tracker beat the program)
    lines_out = []
    for t, tracker, target, sn, exact in sorted(al, key=lambda a: a[0], reverse=True):
        cand = [(r, w) for r, w in gt.get(target, []) if t - MATCH_BEFORE <= r <= t + MATCH_AFTER]
        if cand:
            r, w = min(cand, key=lambda c: abs(c[0] - t))
            per.setdefault(tracker, []).append(t - r)
            if r <= t:
                ours_first += 1
                lag.append(t - r)
            else:
                tracker_first += 1
                lag.append(t - r)
            continue
        unmatched += 1
        if len(lines_out) < limit:
            ll = log_lines_for(log_path, target, t - 300, t + 600)
            when = datetime.fromtimestamp(t, timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
            lines_out.append(f"  {when} UTC  {tracker} said {target} {'(exact time)' if exact else '(card age)'}: "
                             f"program logged NO restock -> {why(ll)}")
            for x in ll:
                lines_out.append("      " + x)
    n = len(al)
    txt = [f"tracker alerts in the last {hours:g} h: {n}; matched by a restock the program logged: {ours_first + tracker_first} "
           f"(program first {ours_first}, tracker first {tracker_first}); NOT matched: {unmatched}"]
    if lag:
        lag_s = sorted(lag)
        txt.append(f"  on matched alerts: tracker minus program, median {lag_s[len(lag_s) // 2]:.0f}s (positive = the program saw it first)")
    for k in sorted(per):
        v = sorted(per[k])
        beat = [-x for x in v if x < 0]
        txt.append(f"  {k}: {len(v)} matched; later than the program by {v[len(v) // 2]:.0f} s in the middle (best {v[0]:.0f} s, worst {v[-1]:.0f} s)" +
                   (f"; BEAT the program {len(beat)}x, by {sum(beat) / len(beat):.0f} s on average (those are the restocks the program must get faster at)" if beat else "; never beat the program"))
    if per:
        allv = sorted(x for v in per.values() for x in v)
        beaten = sum(1 for x in allv if x < 0)
        txt.append(f"  all trackers together: the program was first on {len(allv) - beaten} of {len(allv)} matched alerts; a tracker was first on {beaten}. "
                   f"More trackers can only make the combined notice time shorter - a slow tracker is never a problem by itself, it just rarely wins.")
    txt += lines_out
    return "\n".join(txt), {"alerts": n, "ours_first": ours_first, "tracker_first": tracker_first, "unmatched": unmatched}


# ------------------------------------------------------------------ phone messages vs tracker alerts

def _read_csv(path):
    out = []
    try:
        with open(path, newline="", encoding="utf-8", errors="replace") as f:
            r = csv.reader(f)
            next(r, None)
            for row in r:
                if row:
                    out.append(row)
    except Exception:
        pass
    return out


def notify_report(alerts_path="alerts.csv", notify_path="notifications.csv", events_path="push_events.csv", hours=48.0, now=None, window=60.0, limit=30):
    """Every tracker alert the program counted: was a message sent to you (phone / Discord / pop-up)? And which alerts arrived but were NOT counted, and why.
    -> (text, stats)"""
    import time
    now = now or time.time()
    msgs = []
    for row in _read_csv(notify_path):
        t = _ts(row[0])
        if t is not None and len(row) >= 8:
            msgs.append({"t": t, "kind": row[1], "source": row[2], "target": row[3], "price": row[4], "title": row[5], "result": row[7]})
    first_msg = min((m["t"] for m in msgs), default=None)
    al = []
    for row in _read_csv(alerts_path):
        t = _ts(row[0])
        if t is not None and len(row) >= 4 and now - t <= hours * 3600:
            al.append({"t": t, "tracker": row[1], "target": row[2], "text": row[3][:150]})
    sent = held = missing = before = off = 0
    lines = []
    for a in sorted(al, key=lambda x: x["t"], reverse=True):
        near = [m for m in msgs if m["kind"] == "tracker" and m["source"] == a["tracker"] and m["target"] == a["target"] and abs(m["t"] - a["t"]) <= window]
        when = datetime.fromtimestamp(a["t"], timezone.utc).strftime("%m-%d %H:%M:%S")
        if first_msg is None or a["t"] < first_msg - window:
            before += 1
            verdict = "before messages were recorded (v33 and later keep this record)"
        elif any(m["result"].startswith("sent") for m in near):
            sent += 1
            continue
        elif near and all(m["result"].startswith("not sent: restock messages are off") for m in near):
            off += 1                       # v96: restock messages are switched off (purchases and problems only)
            continue
        elif near:
            held += 1
            verdict = near[0]["result"]
        else:
            missing += 1
            verdict = "NO message recorded - not sent"
        if len(lines) < limit:
            lines.append(f"  {when} UTC  {a['tracker']} -> {a['target']}: {verdict}   [{a['text'][:90]}]")
    txt = [f"tracker alerts the program counted in the last {hours:g} h: {len(al)}; a message was sent for {sent}; held back (the same restock was already announced) {held}; "
           f"no message recorded {missing}; older than the message record {before}" + (f"; not sent because restock messages are off (v96) {off}" if off else "")]
    rs = [m for m in msgs if now - m["t"] <= hours * 3600]
    txt.append(f"messages recorded in that time: {len(rs)} (restock {sum(1 for m in rs if m['kind'] == 'restock')}, tracker alert {sum(1 for m in rs if m['kind'] == 'tracker')}); "
               f"sent to someone: {sum(1 for m in rs if m['result'].startswith('sent to:'))}; sent to no one: {sum(1 for m in rs if m['result'].startswith('sent to no one'))}")
    txt += lines
    # alerts that arrived from the browser-alert trackers but were NOT counted (other products, other stores, above your limit)
    reasons = {}
    ex = []
    for row in _read_csv(events_path):
        t = _ts(row[0])
        if t is None or len(row) < 6 or now - t > hours * 3600:
            continue
        out = row[5]
        if out.startswith("recorded") or out.startswith("same alert") or out.startswith("no words yet"):
            continue
        key = out.split(":", 1)[-1].strip()[:60] if out.startswith("not counted") else out[:60]
        reasons[key] = reasons.get(key, 0) + 1
        if "above the limit" in out or "store we do not watch" in out:
            ex.append(f"  {datetime.fromtimestamp(t, timezone.utc).strftime('%m-%d %H:%M:%S')} UTC {row[1]}: {row[4][:110]} -> {out[:60]}")
    if reasons:
        txt.append("browser alerts (TrackaLacker / HotStock) that arrived but were NOT counted, by reason: " + "; ".join(f"{k}: {v}" for k, v in sorted(reasons.items(), key=lambda kv: -kv[1])))
        txt += ex[-12:]
    else:
        txt.append("browser alerts that arrived but were not counted: none recorded")
    return "\n".join(txt), {"alerts": len(al), "sent": sent, "held": held, "missing": missing, "before": before, "off": off}

def window_stats(gt_path="ground_truth.csv", hours=72.0, now=None):
    """v51: how long a restock could have gone unnoticed, measured on the restocks that were really logged. Every RESTOCK row carries a window:
    the time between the last look that saw the product OUT of stock and the first look that saw it IN stock - the restock happened somewhere
    inside it, so the real delay was at most that (about half of it on average). -> dict, or None when there are no windows yet."""
    now = now or time.time()
    ws = []
    for tid, lst in load_restocks(gt_path).items():
        for t, w in lst:
            if w is not None and 0 <= w < 24 * 3600 and now - t <= hours * 3600:
                ws.append(w)
    if not ws:
        return None
    ws.sort()
    n = len(ws)
    return {"n": n, "avg": sum(ws) / n, "median": ws[n // 2], "worst": ws[-1], "best": ws[0],
            "le1": sum(1 for w in ws if w <= 1.0), "le5": sum(1 for w in ws if w <= 5.0), "le10": sum(1 for w in ws if w <= 10.0),
            "hours": hours}


def window_text(st):
    if not st:
        return "no restocks with a measured window in the last 3 days yet"
    return (f"{st['n']} restocks logged in the last {st['hours']:.0f} h. The window in which each one happened (last look OUT -> first look IN): "
            f"average {st['avg']:.1f} s, middle {st['median']:.1f} s, best {st['best']:.1f} s, worst {st['worst']:.1f} s; "
            f"within 1 s: {st['le1']}, within 5 s: {st['le5']}, within 10 s: {st['le10']}. The real delay of a restock is at most its window (about half of it on average).")
