"""Restalker v82 - restock predictor: which products to look at hardest, learned from real restocks.
(owner 2026-10-31: "you can use predictive analysis if there is an established trend that can be reliable")

It never adds a single request to any store. It only decides how a store's looks are SHARED between its products: a product that
restocks often, or has just restocked and usually comes back again soon, is looked at more often; the others a little less.
That matters at Walmart and Amazon, where one product page is read at a time (16-18 products share one look every few seconds).
Best Buy, Target and GameStop read all products in one request, so there every product is already looked at every round.

What it learns from (the program's own files): ground_truth.csv (every restock the program saw) and alerts.csv (tracker alerts).
Two trends, each used only when the product's own history shows it:
  1. "restocks often": at least MIN_EVENTS restocks on at least MIN_DAYS different days in the last week, and clearly more than the
     other products of its store -> up to MAX_WEIGHT times the looks.
  2. "comes back soon": at least BURST_SHARE of its restocks were followed by another within BURST_GAP (diagnostics 67: the Walmart
     Star Trek pack came back 5 times in under 2 hours on Oct 28) -> for BURST_GAP after each restock it is looked at like a product a
     tracker just alerted for.
Reliability check: the predictor is re-tested on the store's own past restocks (using, for each restock, only what was known before it).
If the products it would have favoured did NOT get clearly more of the restocks than their share of looks, it is switched off for that
store by itself and every product is looked at evenly, as before. The result is in the diagnostics.
"""
import csv
import os
import threading
import time
from datetime import datetime, timezone

VERSION = "v109"
LOOKBACK = 7 * 86400
RATE_WINDOW = 3 * 86400       # "restocks often" counts the last 3 days
MIN_EVENTS = 4
MIN_DAYS = 2
MAX_WEIGHT = 4.0
BURST_GAP = 3600.0
BURST_SHARE = 0.4
BURST_WEIGHT = 4.0
SAME_EVENT = 300.0            # a tracker alert within 5 minutes of a restock (or another alert) of the same product is the same event
REFRESH = 120.0
CHECK_EVERY = 900.0           # the reliability check is re-run this often (on the last CHECK_LAST restocks of the store)
CHECK_LAST = 200
CHECK_MIN = 8                 # restocks at a store needed before the reliability check can decide
CHECK_LIFT = 1.25             # favoured products must get at least this many times their share of looks in restocks

_lock = threading.Lock()
_S = {"at": 0.0, "check_at": 0.0, "events": {}, "check": {}, "busy": False, "cache": {}}
_PRODUCTS = {}                # store -> set of product ids (told by the sweepers)


def _parse(ts):
    try:
        return datetime.fromisoformat(str(ts).replace("Z", "+00:00")).astimezone(timezone.utc).timestamp()
    except Exception:
        return None


def _read(path, id_col, kind_col=None, kind=None):
    out = {}
    try:
        with open(path, newline="", encoding="utf-8", errors="replace") as f:
            r = csv.reader(f)
            next(r, None)
            for row in r:
                if len(row) <= id_col:
                    continue
                if kind_col is not None and (len(row) <= kind_col or row[kind_col] != kind):
                    continue
                t = _parse(row[0])
                if t:
                    out.setdefault(row[id_col], []).append(t)
    except Exception:
        pass
    return out


def store_of(pid):
    return str(pid).split("_", 1)[0]


def note_products(store, ids):
    _PRODUCTS[store] = set(ids)


def _merge(gt, al, now):
    ev = {}
    for pid in set(gt) | set(al):
        ts = sorted([t for t in gt.get(pid, ()) if now - t <= LOOKBACK and t <= now + 60] +
                    [t for t in al.get(pid, ()) if now - t <= LOOKBACK and t <= now + 60])
        keep = []
        for t in ts:
            if keep and t - keep[-1] < SAME_EVENT:
                continue
            keep.append(t)
        if keep:
            ev[pid] = keep
    return ev


def _weight_at(pid, events, store_ids, now):
    """-> (weight, why) for product pid at time `now`, using only events before `now`."""
    mine = [t for t in events.get(pid, ()) if t < now]
    if len(mine) < MIN_EVENTS or len({int(t // 86400) for t in mine}) < MIN_DAYS:
        return 1.0, ""
    w, why = 1.0, []
    # 1. restocks often (compared with the other products of the store)
    recent = lambda ts: sum(1 for t in ts if now - RATE_WINDOW <= t < now)
    mine_n = recent(mine)
    others = [recent(events.get(p, ())) for p in store_ids if p != pid]
    avg = (sum(others) / len(others)) if others else 0.0
    if mine_n >= MIN_EVENTS and mine_n > 1.5 * max(avg, 0.5):
        w = min(MAX_WEIGHT, max(1.0, (mine_n / max(avg, 1.0)) ** 0.5))
        if w > 1.0:
            why.append(f"restocked {mine_n}x in 3 days (others {avg:.1f})")
    # 2. comes back soon after a restock
    follow = sum(1 for a, b in zip(mine, mine[1:]) if b - a <= BURST_GAP)
    if len(mine) >= MIN_EVENTS and follow >= BURST_SHARE * (len(mine) - 1) and now - mine[-1] <= BURST_GAP:
        w = max(w, BURST_WEIGHT)
        why.append(f"restocked {(now - mine[-1]) / 60:.0f} min ago and usually comes back within an hour ({follow} of {len(mine) - 1} times)")
    return w, "; ".join(why)


def _check(store, events, ids):
    """Re-test on the store's own past restocks. -> dict(on, n, hit_share, look_share, why)."""
    evs = sorted((t, p) for p in ids for t in events.get(p, ()))[-CHECK_LAST:]
    hits = looks = n = 0.0
    for t, p in evs:
        ws = {q: _weight_at(q, events, ids, t)[0] for q in ids}
        fav = {q for q, w in ws.items() if w > 1.0}
        if not fav:
            continue
        n += 1
        hits += 1.0 if p in fav else 0.0
        looks += sum(ws[q] for q in fav) / sum(ws.values())
    if n < CHECK_MIN:
        return {"on": False, "n": int(n), "hit": 0.0, "look": 0.0,
                "why": f"not enough restocks to test it yet ({int(n)} of {CHECK_MIN} where it had an opinion) - every product looked at evenly"}
    hit, look = hits / n, looks / n
    on = hit >= CHECK_LIFT * look and hit > look + 0.1
    return {"on": on, "n": int(n), "hit": hit, "look": look,
            "why": (f"tested on {int(n)} past restocks: the products it favoured had {hit * 100:.0f}% of the restocks with {look * 100:.0f}% of the looks"
                    + (" - reliable, in use" if on else " - not reliable enough, off (every product looked at evenly)"))}


def refresh(now=None, force=False):
    """Re-reads the history (and, every CHECK_EVERY, re-runs the reliability check). Runs in its own thread unless forced."""
    now = now or time.time()
    with _lock:
        if _S["busy"] or (not force and now - _S["at"] < REFRESH):
            return
        _S["busy"], _S["at"] = True, now
    if force:
        _refresh(now, True)
    else:
        threading.Thread(target=_refresh, args=(now, False), daemon=True, name="predict").start()


def _refresh(now, force):
    try:
        gt = _read("ground_truth.csv", 1, 2, "RESTOCK")
        al = _read("alerts.csv", 2)
        ev = _merge(gt, al, now)
        chk = None
        if force or now - _S["check_at"] >= CHECK_EVERY:
            chk = {}
            for store in set(_PRODUCTS) | {store_of(p) for p in ev}:
                ids = set(_PRODUCTS.get(store) or ()) | {p for p in ev if store_of(p) == store}
                chk[store] = _check(store, ev, ids)
        with _lock:
            _S["events"], _S["cache"] = ev, {}
            if chk is not None:
                _S["check"], _S["check_at"] = chk, now
    finally:
        _S["busy"] = False


def weight(pid, now=None):
    """How many times the usual share of looks product pid gets now (1.0 = as before). Never below 1: nobody is starved."""
    now = now or time.time()
    refresh(now)
    store = store_of(pid)
    if os.environ.get("RK_NO_PREDICT"):
        return 1.0
    with _lock:
        chk = _S["check"].get(store)
        if not chk or not chk["on"]:
            return 1.0
        c = _S["cache"].get(pid)
        if c and now - c[0] < 10.0:
            return c[1]
        ev = _S["events"]
    ids = set(_PRODUCTS.get(store) or ()) | {p for p in ev if store_of(p) == store}
    w = _weight_at(pid, ev, ids, now + 0.001)[0]
    with _lock:
        _S["cache"][pid] = (now, w)
    return w


def report_text():
    refresh(force=True)
    with _lock:
        ev, chk = dict(_S["events"]), dict(_S["check"])
    now = time.time()
    lines = ["restock predictor (v82): shares each store's looks between its products by their own restock history; adds no requests"]
    for store in sorted(chk):
        c = chk[store]
        lines.append(f"  {store}: {c['why']}")
        if c["on"]:
            ids = set(_PRODUCTS.get(store) or ()) | {p for p in ev if store_of(p) == store}
            for p in sorted(ids):
                w, why = _weight_at(p, ev, ids, now + 0.001)
                if w > 1.0:
                    lines.append(f"     {p}: {w:.1f}x the looks - {why}")
    return "\n".join(lines)
