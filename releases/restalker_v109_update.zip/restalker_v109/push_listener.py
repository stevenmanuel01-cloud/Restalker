"""Alert listener for trackers that only send ALERTS (browser push), such as TrackaLacker and HotStock.

These trackers have no public page that lists restocks with times, so there is nothing to read from outside.
What they do offer for free is "browser push": a Chrome window that is signed in to the tracker receives the same
alert a phone would. This module keeps one separate Chrome window (its own folder, never your normal Chrome),
and records the exact moment each alert ARRIVES in it - together with its words - using Chrome's own
developer-tools event log ("background services"). The program never logs in, scrapes, or touches a "are you a person" box:
you sign in and tick the products once, in that window; afterwards it only listens. (v37: the one thing it may press itself, in
the alert browser only, is the tracker's own "Enable browser alerts" button - Chrome's permission is pre-allowed in the saved
settings, so no pop-up has to be answered by a person.)

What is written: one row in alerts.csv (same file and layout the feed readers use) for an alert that names one of
our products AND one of our five stores AND is not above the price limit. Every alert, matched or not, is also
kept in push_events.csv so a wrong guess can be fixed from what really arrived.

Everything runs in ONE background thread (the Chrome control library may only be used from the thread that made
it); the web page only leaves requests in a queue and reads a status copy.
"""
VERSION = "v109"

import collections
import csv
import json
import os
import re
import threading
import time
import urllib.request
from datetime import datetime, timezone

import products
import matrix
from http_utils import append_csv_row, flush_pending_csv
from browser_fetch import RealChromeFetcher
from tracker_feed_poller import _norm, RETAILER_WORDS, RETAILER_DOMAINS, retailer_word

PORT = 9340
PROFILE = "browser_profile_alerts"
EVENTS_CSV = "push_events.csv"
EVENTS_MAX_BYTES = 3_000_000
DEDUPE_SEC = 5.0            # a push and its notification are one alert if they are this close with the same words
EMPTY_PAIR_SEC = 10.0       # an alert with no words is paired with the notification that follows it
PROBE_EVERY = 300.0         # how often the "is this tracker really set up" check runs (when the window is hidden)
KEEP_CHECK_EVERY = 15.0
KEEP_RELOAD_EVERY = 6 * 3600.0

# Built-in definitions. app.py adds these to trackers.yaml if they are missing (users never type them).
BUILTIN = [
    {"id": "trackalacker", "name": "TrackaLacker (free tier)", "kind": "push", "tier": "free",
     "feed_url": "https://www.trackalacker.com/products/showcase/mtg-reality-fracture-collector-booster-box",
     "push_hosts": ["trackalacker.com"],
     "setup_urls": ["https://www.trackalacker.com/users/sign_in"],
     "keep_open_url": None, "claimed_latency_sec": None, "interval_sec": 2, "active": True,
     "claimed_note": "free tier: alerts come after paid-tier members (their own statement); no speed number is claimed"},
    {"id": "hotstock", "name": "HotStock (free tier)", "kind": "push", "tier": "free",
     "feed_url": "https://www.hotstock.io/us",
     "push_hosts": ["hotstock.io"],
     "setup_urls": ["https://www.hotstock.io/us"],
     "enable_url": "https://www.hotstock.io/settings",
     "keep_open_url": "https://www.hotstock.io/us", "claimed_latency_sec": None, "interval_sec": 2, "active": True,
     "claimed_note": "free tier: delayed behind Premium (their own statement); no speed number is claimed"},
    {"id": "discord", "name": "Discord (your servers)", "kind": "push", "tier": "free",
     "feed_url": "https://discord.com/app",
     "push_hosts": ["discord.com"],
     "setup_urls": ["https://discord.com/login"],
     "keep_open_url": "https://discord.com/app", "claimed_latency_sec": None, "interval_sec": 2, "active": False,
     "claimed_note": "optional and experimental: alerts that tracker bots post in Discord servers you are in, read from Discord's own browser notifications"},
]

# Page-side hook: notes every notification a PAGE itself creates (sites that alert while their tab is open).
SW_QUIET_JS = r"""
(() => { try { if (self.__rkQuiet) return; self.__rkQuiet = true;
  const P = ServiceWorkerRegistration.prototype, o = P.showNotification;
  P.showNotification = function(title, opts) { const x = Object.assign({}, opts || {}, {silent: true}); delete x.vibrate; return o.call(this, title, x); };
  return 'quiet'; } catch (e) { return 'failed ' + e; } })()
"""

HOOK_JS = r"""
(() => {
  if (window.__rkHooked) return; window.__rkHooked = true;
  const send = (kind, title, opts) => { try {
      const o = opts || {};
      window.__rkNote(JSON.stringify({kind: kind, title: String(title == null ? '' : title), body: String(o.body || ''),
        data: (function(){ try { return o.data ? JSON.stringify(o.data).slice(0, 500) : ''; } catch (e) { return ''; } })(),
        t: Date.now(), href: location.href})); } catch (e) {} };
  const quiet = (opts) => { const x = Object.assign({}, opts || {}, {silent: true}); delete x.vibrate; return x; };   // never any sound
  try {
    const N = window.Notification;
    if (N) {
      const W = function(title, opts) { send('page-notification', title, opts); return new N(title, quiet(opts)); };
      W.prototype = N.prototype;
      Object.defineProperty(W, 'permission', {get: () => N.permission});
      W.requestPermission = function() { return N.requestPermission.apply(N, arguments); };
      Object.defineProperty(W, 'maxActions', {get: () => N.maxActions});
      window.Notification = W;
    }
  } catch (e) {}
  try {
    if (window.ServiceWorkerRegistration) {
      const o = ServiceWorkerRegistration.prototype.showNotification;
      ServiceWorkerRegistration.prototype.showNotification = function(title, opts) { send('page-sw-notification', title, opts); return o.call(this, title, quiet(opts)); };
    }
  } catch (e) {}
})();
"""

FIND_JS = r"""
(mode) => {
  const vis = e => { const r = e.getBoundingClientRect(); const cs = getComputedStyle(e); return r.width > 4 && r.height > 4 && cs.visibility !== 'hidden' && cs.display !== 'none'; };
  const norm = x => String(x || '').replace(/\s+/g, ' ').trim();
  const own = e => norm((e.innerText || e.value || '') + ' ' + (e.getAttribute('aria-label') || '') + ' ' + (e.getAttribute('title') || ''));
  document.querySelectorAll('[data-rk-pick]').forEach(e => e.removeAttribute('data-rk-pick'));
  const BAD = /disable|turn off|e-?mail|\bsms\b|text message|discord|telegram|phone|mobile|slack|webhook|whatsapp|alert me|unsubscribe/i;
  const els = Array.from(document.querySelectorAll('body *')).filter(vis);
  const clickable = e => e.closest('button, a, [role=button], [role=switch], label, [onclick], summary, input') || e;
  const isClick = e => !!e.closest('button, a, [role=button], [role=switch], label, [onclick], summary, input[type=button], input[type=submit], [tabindex]') || getComputedStyle(e).cursor === 'pointer';
  const rank = (t, e) => {
    if (!t || t.length > 90 || BAD.test(t) || /\?\s*$/.test(t)) return 0;      // a question ("Enable browser notifications?") is a heading, not the button
    const r0 = rank0(t, e);
    return r0 && (mode === 'confirm' || mode === 'bell' || isClick(e)) ? r0 : (r0 && mode === 'enable_loose' ? r0 - 1 : 0);
  };
  const rank0 = (t, e) => {
    if (mode === 'enable' || mode === 'enable_loose') {
      if (/^enable (browser|push|web) (alerts|notifications)\b/i.test(t)) return 10;
      if (/enable.{0,25}browser.{0,25}(alert|notification)/i.test(t) || /browser.{0,25}(alert|notification).{0,25}(enable|on\b)/i.test(t)) return 9;
      if (/^(turn on|allow|subscribe( to)?|activate) (browser |push |web )?(alerts|notifications)\b/i.test(t) && /browser|push|web/i.test(t)) return 8;
      if (/^(enable|turn on|allow) (alerts|notifications)$/i.test(t)) return 5;
      const sw = e.matches('input[type=checkbox], [role=switch]') ? e : e.querySelector('input[type=checkbox], [role=switch]');
      if (sw && /browser.{0,20}(alert|notification)|push (alert|notification)/i.test(t)) {
        const on = (sw.checked === true) || sw.getAttribute('aria-checked') === 'true';
        return on ? 0 : 4;
      }
      return 0;
    }
    if (mode === 'confirm') {
      if (!e.closest('[role=dialog], [aria-modal=true], [class*=modal], [class*=popup], [class*=dialog], [class*=overlay]')) return 0;
      return /^(allow|yes|continue|confirm|ok|okay|got it|enable|turn on|sounds good|let's go|i understand)\b/i.test(t) && t.length < 30 ? 7 : 0;
    }
    // bell
    const cls = (typeof e.className === 'string' ? e.className : '') + ' ' + (e.id || '');
    if (!e.matches('button, a, [role=button], svg, [class*=bell], [class*=icon]')) return 0;
    if (/\bbell\b/i.test(t + ' ' + cls)) return 4;
    return /\b(notifications?)\b/i.test(t + ' ' + cls) && !/^(enable|turn on|allow|subscribe)/i.test(t) ? 2 : 0;
  };
  const minr = mode === 'enable' ? 8 : mode === 'enable_loose' ? 4 : 1;
  let best = null, bestR = 0;
  const ranked = [];
  for (const e of els) { const r = rank(own(e), e); if (r >= minr) ranked.push([e, r]); }
  // the DEEPEST matching element: a box that merely contains the button (and a question above it) must not be taken for the button
  for (const [e, r] of ranked) {
    if (ranked.some(([o]) => o !== e && e.contains(o))) continue;
    if (r > bestR) { best = e; bestR = r; }
  }
  // many pages draw the same words on a heading and on the button around it: the button around is what gets pressed
  const cands = [];
  for (const e of els) {
    if (!e.matches('button, a, [role=button], [role=switch], [onclick], input[type=button], input[type=submit], input[type=checkbox], summary, label')) continue;
    const t = own(e).slice(0, 50);
    if (t && !cands.includes(t)) cands.push(t);
    if (cands.length >= 30) break;
  }
  if (!best) return {words: null, cands: cands};
  const target = clickable(best);
  target.setAttribute('data-rk-pick', '1');
  return {words: (own(best).slice(0, 60) || '(button)'), rank: bestR, cands: cands};
}
"""
PAGE_WORDS_JS = r"""() => ((document.body && document.body.innerText) || '').replace(/\s+/g, ' ').slice(0, 1500)"""


def preallow_notifications(prof, hosts):
    """Writes "this site may show notifications" into the saved settings of the program's own Chrome folder, so Chrome never has to ask
    (nobody sees a question in a hidden window). Must be done while Chrome is not running on that folder. Returns True when it wrote
    something. Other settings in the file are kept untouched."""
    try:
        d = os.path.join(prof, "Default")
        os.makedirs(d, exist_ok=True)
        path = os.path.join(d, "Preferences")
        data = {}
        if os.path.exists(path):
            with open(path, encoding="utf-8") as f:
                data = json.load(f)
            if not isinstance(data, dict):
                return False
        ex = data.setdefault("profile", {}).setdefault("content_settings", {}).setdefault("exceptions", {}).setdefault("notifications", {})
        stamp = str(int((time.time() + 11644473600) * 1000000))        # Chrome counts microseconds from 1601
        keys = []
        for h in hosts or []:
            h = str(h).lower().strip()
            if not h:
                continue
            if h.startswith(("http://", "https://")):          # (an address given with its scheme and port is used as it is)
                keys.append(f"{h.rstrip('/')},*")
                continue
            bare = h[4:] if h.startswith("www.") else h
            keys += [f"https://{bare}:443,*", f"https://www.{bare}:443,*", f"[*.]{bare},*"]
        changed = False
        for k in dict.fromkeys(keys):
            cur = ex.get(k)
            if not isinstance(cur, dict) or cur.get("setting") != 1:
                ex[k] = {"last_modified": stamp, "setting": 1}
                changed = True
        if changed:
            tmp = path + ".rk-tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(data, f, separators=(",", ":"))
            os.replace(tmp, path)
        return changed
    except Exception:
        return False


PROBE_JS = r"""
async () => {
  const o = {perm: (window.Notification ? Notification.permission : 'none'), sw: 0, subs: 0, host: location.host};
  try {
    const regs = await navigator.serviceWorker.getRegistrations();
    o.sw = regs.length;
    for (const r of regs) { try { if (r.pushManager && await r.pushManager.getSubscription()) o.subs++; } catch (e) {} }
  } catch (e) { o.err = String(e).slice(0, 120); }
  return o;
}
"""

_NOT_OURS = ("bundle", "play booster", "set booster", "draft", "jumpstart", "commander", "prerelease", "starter", "sleeve")
_PRICE_RE = re.compile(r"\$\s?(\d{1,4}(?:,\d{3})*(?:\.\d{1,2})?)")


# ------------------------------------------------------------------ reading an alert

def flatten_payload(raw):
    """Turn whatever a push carried (JSON or plain text) into one readable line of words."""
    if raw is None:
        return ""
    if isinstance(raw, bytes):
        raw = raw.decode("utf-8", "replace")
    raw = str(raw).strip()
    if not raw:
        return ""
    try:
        obj = json.loads(raw)
    except Exception:
        return re.sub(r"\s+", " ", "".join(ch if ch.isprintable() else " " for ch in raw))[:600]
    parts = []

    def walk(o, depth=0):
        if depth > 6 or len(parts) > 60:
            return
        if isinstance(o, dict):
            for v in o.values():
                walk(v, depth + 1)
        elif isinstance(o, (list, tuple)):
            for v in o:
                walk(v, depth + 1)
        elif isinstance(o, (str, int, float)) and not isinstance(o, bool):
            s = str(o).strip()
            if s:
                parts.append(s)
    walk(obj)
    return re.sub(r"\s+", " ", " | ".join(parts))[:600]


def theme_of(match_name):
    n = _norm(match_name)
    return re.sub(r"\s*collector booster box$", "", n).strip()


def product_matches(text_norm, target):
    """Does this alert name OUR product? Depends on its kind (products.py):
    box    - right set, a Collector Booster BOX (not a pack, bundle or other booster);
    pack   - right set, a single Collector Booster PACK (not a box, display, bundle or Omega);
    bundle - its name, or another name it goes by."""
    kind = products.kind_of(target)
    if kind not in ("box", "pack"):          # bundles and categories you made yourself (Commander Deck, ...): matched by their name
        return products.title_matches(text_norm, target)
    theme = products.theme_of(target) if kind == "pack" else theme_of(target.get("match_name", ""))
    if not theme:
        return False
    short = theme[4:] if theme.startswith("the ") else theme
    if theme not in text_norm and short not in text_norm:
        return False
    if "collector" not in text_norm:
        return False
    if kind == "pack":
        if re.search(r"\b(box|display|bundle|omega|case|value|play booster|set booster|draft|commander|prerelease|starter|sleeve|jumpstart)\b", text_norm):
            return False
        return True
    if not re.search(r"\b(box|display)\b", text_norm):
        return False
    if any(w in text_norm for w in _NOT_OURS):
        return False
    return True


def stores_named(text):
    """Set of store keys the alert names (words or web addresses), e.g. {'target'}."""
    low = (text or "").lower()
    flat = low.replace(" ", "")
    found = set()
    for key, word in RETAILER_WORDS.items():
        if word in low or key in flat:
            found.add(key)
    for key, doms in RETAILER_DOMAINS.items():
        if any(d in low for d in doms):
            found.add(key)
    return found


def store_key(target):
    w = retailer_word(target.get("url", ""))
    for key, word in RETAILER_WORDS.items():
        if word == w:
            return key
    return ""


def price_ok(text, target):
    """False only when every price in the alert is above the limit (a reseller listing)."""
    mx = target.get("max_price")
    prices = []
    for m in _PRICE_RE.finditer(text or ""):
        try:
            prices.append(float(m.group(1).replace(",", "")))
        except ValueError:
            pass
    if mx is None or not prices:
        return True
    return any(p <= float(mx) for p in prices)


def classify(text, targets):
    """(matched_targets, note). note says why nothing matched, for the log."""
    tn = _norm(text)
    prod = [t for t in targets if product_matches(tn, t)]
    if not prod:
        return [], "no product of ours"
    named = stores_named(text)
    if not named:
        return [], "names our product but no store"
    hit = [t for t in prod if store_key(t) in named]
    if not hit:
        return [], "names our product, but at a store we do not watch for it"
    ok = [t for t in hit if price_ok(text, t)]
    if not ok:
        return [], "price above the limit (reseller)"
    return ok, ""


# ------------------------------------------------------------------ the manager

def probe_url(url):
    """The page used to check a tracker's set-up: a plain text file of the same site (nothing to log in to or verify)."""
    if "127.0.0.1" in url or "localhost" in url:
        return url
    from urllib.parse import urlsplit
    u = urlsplit(url)
    return f"{u.scheme}://{u.netloc}/robots.txt"


class Manager:
    def __init__(self):
        self.lock = threading.Lock()
        self.trackers = []
        self.targets = []
        self.out_path = "alerts.csv"
        self.log_fn = print
        self.report_fn = None
        self.recording = False
        self.wanted = False
        self.requests = collections.deque()
        self.thread = None
        self.status = {"connected": False, "visible": False, "last_error": "", "events": 0, "chrome": "not started",
                       "trackers": {}, "recent": [], "setup_open": False}
        self._recent = collections.deque(maxlen=40)
        self._seen = {}          # (tracker, target) -> (ts, norm text)
        self._pending_empty = {}  # host -> ts of an alert that carried no words
        self._counts = collections.defaultdict(int)
        self._last_at = {}
        self._probe = {}
        self._probe_at = {}
        self._keep = {}
        self._keep_check = 0.0
        self._keep_reload = {}
        self._warned = {}
        self._pw = None
        self._br = None
        self._ctx = None
        self._anchor = None
        self._cdp = None
        self._proc = None
        self._visible = False
        self._rec_at_open = False
        self._setup_proc = None      # the plain set-up window (an ordinary Chrome that nothing is attached to)
        self._last_err_log = 0.0
        self._start_ts = time.time() - 1.0         # events older than this program's start are history, not live alerts
        self._selftest_state = None
        self._signup = {}              # tracker id -> what the last automatic sign-up attempt did
        self._signup_tries = {}
        self._bg_seen = collections.OrderedDict()   # events already handled (Chrome re-sends recent ones when we reconnect)

    # ---- called from the web page / app (any thread)
    def add_target(self, t):
        """A link added in the table while running: alerts for it are counted from now on."""
        with self.lock:
            if not any(x["id"] == t["id"] for x in self.targets):
                self.targets.append(t)

    def configure(self, trackers, targets, out_path, log_fn, report_fn):
        with self.lock:
            self.trackers = [t for t in trackers if t.get("kind") == "push" and t.get("active", True)]
            self.targets = list(targets)
            self.out_path = out_path
            self.log_fn = log_fn or print
            self.report_fn = report_fn
        self.ensure_thread()

    def ensure_thread(self):
        with self.lock:
            if self.thread is not None and self.thread.is_alive():
                return
            self.thread = threading.Thread(target=self._loop, daemon=True, name="alert-listener")
            self.thread.start()

    def set_recording(self, on):
        with self.lock:
            self.recording = bool(on)
            if on:
                self.wanted = True
        if on:
            try:
                if not os.path.exists(self.out_path):
                    with open(self.out_path, "w", newline="", encoding="utf-8") as f:
                        csv.writer(f).writerow(["timestamp_utc", "tracker_id", "target_id", "snippet"])
                flush_pending_csv(self.out_path)
            except Exception:
                pass
        self.ensure_thread()

    def request(self, action, **kw):
        with self.lock:
            self.wanted = True
            self.requests.append((action, kw))
        self.ensure_thread()

    def snapshot(self):
        with self.lock:
            st = json.loads(json.dumps(self.status, default=str))
        return st

    # ---- helpers (listener thread only)
    def _log(self, msg):
        try:
            self.log_fn(msg)
        except Exception:
            pass

    def _err_log(self, msg):
        now = time.time()
        if now - self._last_err_log > 60:
            self._last_err_log = now
            self._log(msg)

    def _push_trackers(self):
        with self.lock:
            return list(self.trackers)

    def _tracker_for(self, host_text):
        h = (host_text or "").lower()
        for t in self._push_trackers():
            if any(x.lower() in h for x in (t.get("push_hosts") or [])):
                return t
        return None

    def _alive(self):
        try:
            urllib.request.urlopen(f"http://127.0.0.1:{PORT}/json/version", timeout=1).read()
            return True
        except Exception:
            return False

    def _start_chrome(self):
        import subprocess
        cands = RealChromeFetcher.candidates()
        if not cands:
            raise RuntimeError("no Chrome or Edge found on this PC")
        exe = cands[0]
        prof = os.path.abspath(PROFILE) + "_" + os.path.basename(exe).replace(".exe", "").lower()
        os.makedirs(prof, exist_ok=True)
        self._preallow(prof)
        args = [exe, f"--remote-debugging-port={PORT}", f"--user-data-dir={prof}", "--no-first-run",
                "--no-default-browser-check", "--window-position=-32000,-32000", "--window-size=1200,850",
                "--disable-session-crashed-bubble", "--hide-crash-restore-bubble",
                "--disable-renderer-backgrounding", "--disable-background-timer-throttling",
                "--disable-backgrounding-occluded-windows", "--rk-store=alerts", "--mute-audio"]
        if os.environ.get("RK_CHROME_HEADLESS"):
            args += ["--headless=new", "--no-sandbox", "--disable-gpu"]
        args.append("about:blank")
        flags = (0x08000000 | 0x00004000) if os.name == "nt" else 0
        import subprocess as sp
        self._proc = sp.Popen(args, stdout=sp.DEVNULL, stderr=sp.DEVNULL, creationflags=flags)
        for _ in range(80):
            if self._alive():
                self._visible = False
                return
            time.sleep(0.5)
        raise RuntimeError("the alert browser did not start in time")

    # ---- the plain set-up window: an ordinary Chrome with nothing attached, so sites' "are you a person" checks behave normally
    def _kill_chrome_tree(self, proc):
        try:
            if proc is None:
                return
            try:
                import psutil
                for ch in psutil.Process(proc.pid).children(recursive=True):
                    try:
                        ch.kill()
                    except Exception:
                        pass
            except Exception:
                pass
            proc.kill()
            try:
                proc.wait(10)
            except Exception:
                pass
        except Exception:
            pass
        try:                                  # anything of ours still carrying the set-up mark (helper processes)
            import psutil
            for p in psutil.process_iter(["cmdline"]):
                try:
                    cl = p.info["cmdline"] or []
                    if cl and any(x in os.path.basename(cl[0]).lower() for x in ("chrome", "msedge")) and any("--rk-store=alerts-setup" in a for a in cl):
                        p.kill()
                except Exception:
                    pass
        except Exception:
            pass

    def _free_profile(self, prof, wait=12.0):
        """Wait until no Chrome still holds the saved profile folder (a new Chrome cannot start on a locked one)."""
        try:
            import psutil
        except Exception:
            time.sleep(2)
            return
        t0 = time.time()
        while time.time() - t0 < wait:
            holders = []
            for p in psutil.process_iter(["cmdline"]):
                try:
                    if any(prof in a for a in (p.info["cmdline"] or [])):
                        holders.append(p)
                except Exception:
                    pass
            if not holders:
                return
            if time.time() - t0 > 4:
                for p in holders:
                    try:
                        p.kill()
                    except Exception:
                        pass
            time.sleep(0.3)

    def _preallow(self, prof):
        hosts = []
        for t in self._push_trackers():
            hosts += list(t.get("push_hosts") or [])
        if hosts and preallow_notifications(prof, hosts):
            self._log("[push] pre-allowed notifications for " + ", ".join(dict.fromkeys(hosts)) + " in this Chrome's saved settings (Chrome will not ask; no pop-up to answer).")

    def _setup_is_open(self):
        return self._setup_proc is not None and self._setup_proc.poll() is None

    def _open_setup_window(self, urls):
        import subprocess as sp
        cands = RealChromeFetcher.candidates()
        if not cands:
            raise RuntimeError("no Chrome or Edge found on this PC")
        exe = cands[0]
        prof = os.path.abspath(PROFILE) + "_" + os.path.basename(exe).replace(".exe", "").lower()
        os.makedirs(prof, exist_ok=True)
        # the listening browser (if any) must be closed first: two Chromes cannot share one saved profile
        self._disconnect()
        self._kill_chrome_tree(self._proc)
        self._proc = None
        self._end_setup(quiet=True)
        self._free_profile(prof)
        self._preallow(prof)
        args = [exe, f"--user-data-dir={prof}", "--no-first-run", "--no-default-browser-check",
                "--window-position=80,60", "--window-size=1200,850", "--rk-store=alerts-setup"]
        shown = list(dict.fromkeys(urls or []))[:4]
        if os.environ.get("RK_CHROME_HEADLESS"):
            args += ["--headless=new", "--no-sandbox", "--disable-gpu"]
            shown = shown[:1]                      # (test lab only) hidden Chrome accepts one address
        args += shown
        flags = 0x00004000 if os.name == "nt" else 0
        self._setup_proc = sp.Popen(args, stdout=sp.DEVNULL, stderr=sp.DEVNULL, creationflags=flags)
        for _try in range(2):                       # if it died at once (profile still locked), try once more
            time.sleep(1.5)
            if self._setup_proc.poll() is None:
                break
            self._free_profile(prof)
            self._setup_proc = sp.Popen(args, stdout=sp.DEVNULL, stderr=sp.DEVNULL, creationflags=flags)
        self._rec_at_open = bool(self.recording)
        try:
            import focus_guard
            focus_guard.suspend(True)
        except Exception:
            pass
        with self.lock:
            self.status["setup_open"] = True
            self.status["visible"] = True
            self.status["connected"] = False
            self.status["chrome"] = "set-up window open"
            self.wanted = bool(self.recording)
        self._visible = True
        self._log("[push] set-up window opened (an ordinary Chrome window with no program attached). Sign in there, then press 'I'm done - Check my setup'.")

    def _end_setup(self, quiet=False):
        was = self._setup_is_open()
        if self._setup_proc is not None:
            self._kill_chrome_tree(self._setup_proc)
        self._setup_proc = None
        try:
            import focus_guard
            focus_guard.suspend(False)
        except Exception:
            pass
        with self.lock:
            self.status["setup_open"] = False
            if not self._br:
                self.status["visible"] = False
        self._visible = False
        if was and not quiet:
            self._log("[push] set-up window closed; the alert browser takes over (your sign-ins are kept).")

    def _setup_step(self):
        """Called by the loop before connecting. True = a set-up window is open and nothing else wants the alert browser yet."""
        urls = None
        with self.lock:
            for i, (action, kw) in enumerate(list(self.requests)):
                if action == "setup":
                    urls = kw.get("urls")
                    del self.requests[i]
                    break
        if urls is not None:
            self._open_setup_window(urls)
        if self._setup_proc is None:
            return False
        if not self._setup_is_open():          # the person closed the window themselves
            self._end_setup()
            return False
        with self.lock:
            wants = (self.recording and not self._rec_at_open) or any(a in ("probe", "hide", "show", "selftest", "enable") for a, _ in self.requests)
        if wants:
            self._end_setup()
            with self.lock:
                self.wanted = True
            return False
        return True

    def _disconnect(self):
        for obj, fn in ((self._br, "close"),):
            try:
                if obj is not None:
                    getattr(obj, fn)()
            except Exception:
                pass
        try:
            if self._pw is not None:
                self._pw.stop()
        except Exception:
            pass
        self._pw = self._br = self._ctx = self._anchor = self._cdp = None
        self._keep = {}
        with self.lock:
            self.status["connected"] = False

    def _connect(self):
        from playwright.sync_api import sync_playwright
        if not self._alive():
            self._start_chrome()
            with self.lock:
                self.status["chrome"] = "started"
        self._pw = sync_playwright().start()
        self._br = self._pw.chromium.connect_over_cdp(f"http://127.0.0.1:{PORT}")
        self._ctx = self._br.contexts[0] if self._br.contexts else self._br.new_context()
        self._ctx.expose_binding("__rkNote", self._on_page_note)
        self._ctx.add_init_script(HOOK_JS)
        try:                                   # a site's own background script shows its alerts: make those silent too
            self._ctx.on("serviceworker", self._quiet_worker)
            for w in list(self._ctx.service_workers):
                self._quiet_worker(w)
        except Exception:
            pass
        for pg in list(self._ctx.pages):
            try:
                pg.evaluate(HOOK_JS)
            except Exception:
                pass
        self._new_anchor()
        with self.lock:
            self.status["connected"] = True
            self.status["last_error"] = ""
            self.status["chrome"] = "running"
        self._log(f"[push] alert browser connected ({VERSION}). Listening for alerts from: "
                  + ", ".join(t["id"] for t in self._push_trackers()))

    def _quiet_worker(self, w):
        try:
            if w.evaluate(SW_QUIET_JS) == "quiet":
                with self.lock:
                    self.status["sw_quiet"] = self.status.get("sw_quiet", 0) + 1
        except Exception:
            pass

    def _new_anchor(self):
        self._anchor = None
        for pg in list(self._ctx.pages):          # reuse a blank tab left from before instead of piling up new ones
            try:
                if pg.url == "about:blank" and not pg.is_closed():
                    self._anchor = pg
                    break
            except Exception:
                pass
        if self._anchor is None:
            self._anchor = self._ctx.new_page()
            try:
                self._anchor.goto("about:blank")
            except Exception:
                pass
        self._cdp = self._ctx.new_cdp_session(self._anchor)
        self._cdp.on("BackgroundService.backgroundServiceEventReceived", self._on_bg_event)
        for svc in ("pushMessaging", "notifications"):
            self._cdp.send("BackgroundService.startObserving", {"service": svc})
            self._cdp.send("BackgroundService.setRecording", {"shouldRecord": True, "service": svc})

    # ---- events
    def _on_bg_event(self, e):
        try:
            ev = e.get("backgroundServiceEvent") or e
            svc = ev.get("service")
            name = ev.get("eventName", "")
            ts = float(ev.get("timestamp") or time.time())
            origin = ev.get("origin") or ev.get("storageKey") or ""
            key = (svc, name, round(ts, 4), origin)
            if ts < self._start_ts or key in self._bg_seen:
                return
            self._bg_seen[key] = True
            while len(self._bg_seen) > 500:
                self._bg_seen.popitem(last=False)
            meta = {m.get("key"): m.get("value") for m in (ev.get("eventMetadata") or [])}
            if svc == "pushMessaging" and name == "Push event dispatched":
                self._signal(ts, origin, "push", flatten_payload(meta.get("Payload", "")))
            elif svc == "notifications" and name == "Notification displayed":
                text = " | ".join(x for x in (meta.get("Title", ""), meta.get("Body", "")) if x)
                self._signal(ts, origin, "notification", re.sub(r"\s+", " ", text)[:600])
        except Exception as ex:
            self._err_log(f"[push] could not read an event: {ex}")

    def _on_page_note(self, source, raw):
        try:
            d = json.loads(raw)
            text = " | ".join(x for x in (d.get("title", ""), d.get("body", ""), d.get("data", "")) if x)
            href = d.get("href", "")
            self._signal(time.time(), href, d.get("kind", "page-notification"), re.sub(r"\s+", " ", text)[:600])
        except Exception as ex:
            self._err_log(f"[push] could not read a page notification: {ex}")

    def _save_event(self, ts, tracker_id, kind, host, text, outcome):
        try:
            if os.path.exists(EVENTS_CSV) and os.path.getsize(EVENTS_CSV) > EVENTS_MAX_BYTES:
                return
            new = not os.path.exists(EVENTS_CSV)
            with open(EVENTS_CSV, "a", newline="", encoding="utf-8", errors="replace") as f:
                w = csv.writer(f)
                if new:
                    w.writerow(["arrived_utc", "tracker_id", "kind", "from", "words", "outcome"])
                w.writerow([datetime.fromtimestamp(ts, timezone.utc).isoformat(), tracker_id, kind, host[:80], text[:500], outcome])
        except Exception:
            pass

    def _signal(self, ts, host, kind, text):
        """One alert has arrived (from Chrome's event log or a page). Decide what it is and record it."""
        st = self._selftest_state
        if st is not None and st["got"] is None and st["host"] and st["host"] in (host or ""):
            st["got"] = (ts, kind, text)          # the program's own test alert
            return
        tr = self._tracker_for(host)
        if tr is None:
            return                      # some other website's notification: not ours to look at
        tid = tr["id"]
        with self.lock:
            targets = [t for t in self.targets if not matrix.is_off(t)]       # switched-off products are not counted
            rec = self.recording
        self._counts[tid] += 1
        self._last_at[tid] = ts
        if not text:
            self._pending_empty[host] = ts
            self._save_event(ts, tid, kind, host, "", "no words yet (waiting for its notification)")
            self._remember(ts, tid, kind, "")
            return
        eff = ts
        pe = self._pending_empty.pop(host, None)
        if pe is not None and 0 <= ts - pe < EMPTY_PAIR_SEC:
            eff = min(ts, pe)           # the alert arrived when the empty push arrived; the words came with the notification
        matched, why = classify(text, targets)
        outcome = ""
        norm = _norm(text)
        if matched:
            outcome = "recorded" if rec else "matched, but the program was not 'watching' (not recorded)"
            for t in matched:
                prev = self._seen.get((tid, t["id"]))
                # one alert shows up twice: as the push itself and as the notification it displays (different kind, same instant)
                if prev and abs(eff - prev[0]) < DEDUPE_SEC and (prev[2] != kind or prev[1] == norm):
                    outcome = "same alert as one just recorded"
                    continue
                self._seen[(tid, t["id"])] = (eff, norm, kind)
                if rec:
                    self._write_row(tr, t, eff, text, host)
        else:
            outcome = "not counted: " + why
        self._save_event(eff, tid, kind, host, text, outcome)
        self._remember(eff, tid, kind, text, outcome)

    def _remember(self, ts, tid, kind, text, outcome=""):
        self._recent.appendleft({"at": datetime.fromtimestamp(ts, timezone.utc).strftime("%H:%M:%S"), "tracker": tid,
                                 "kind": kind, "words": text[:140], "outcome": outcome})
        with self.lock:
            self.status["events"] = sum(self._counts.values())
            self.status["recent"] = list(self._recent)[:12]

    def _write_row(self, tr, target, ts, text, host):
        iso = datetime.fromtimestamp(ts, timezone.utc).isoformat()
        word = retailer_word(target.get("url", ""))
        snippet = f"[push alert] {text[:300]} || store: {word} || via {tr['id']}"
        try:
            import hotness
            hotness.mark(target["id"], why=f"{tr['id']}: {text[:160]}")
        except Exception:
            pass
        _pr = products.prices_in(text)
        self._log(f"[{iso}] NEW MENTION: {tr['id']} / {target['id']} (push alert arrived; exact arrival time)" + (f" price ${_pr[0]:.2f}" if _pr else ""))
        if not append_csv_row(self.out_path, [iso, tr["id"], target["id"], snippet]):
            self._log(f"[error] {self.out_path} could not be written to (is it open in Excel?). This alert is saved in "
                      f"{self.out_path}.pending and is added automatically when the file is free.")
        if self.report_fn:
            try:
                self.report_fn("tracker", tr["id"], last_mention_at=time.time(), last_mention_target=target["id"])
            except Exception:
                pass

    # ---- window control
    def _set_visible(self, show):
        try:
            import focus_guard
            focus_guard.suspend(show)      # while you deliberately use the set-up window, don't hand focus back
        except Exception:
            pass
        try:
            cdp = self._cdp
            win = cdp.send("Browser.getWindowForTarget")
            if show:
                b = {"left": 80, "top": 60, "width": 1200, "height": 850, "windowState": "normal"}
            else:
                b = {"left": -32000, "top": -32000, "width": 1200, "height": 850, "windowState": "normal"}
            cdp.send("Browser.setWindowBounds", {"windowId": win["windowId"], "bounds": b})
            self._visible = bool(show)
            with self.lock:
                self.status["visible"] = bool(show)
            if show:
                try:
                    self._anchor.bring_to_front()
                except Exception:
                    pass
        except Exception as ex:
            self._err_log(f"[push] could not move the alert window: {ex}")

    def _handle_requests(self):
        while True:
            with self.lock:
                nxt = next((i for i, (a, _) in enumerate(self.requests) if a != "setup"), None)    # "setup" is left for the loop
                if nxt is None:
                    return
                action, kw = self.requests[nxt]
                del self.requests[nxt]
            try:
                if action == "setup":
                    pass                      # handled by _setup_step (a plain window, nothing attached)
                elif action == "show":
                    self._set_visible(True)
                elif action == "hide":
                    self._set_visible(False)
                elif action == "probe":
                    self._probe_all(force=True)
                elif action == "enable":
                    self._enable_all()
                elif action == "selftest":
                    self._selftest(kw.get("url"))
            except Exception as ex:
                self._err_log(f"[push] request '{action}' failed: {ex}")

    def _selftest(self, url):
        """Sends a harmless test alert to a tiny page of this program and checks that the arrival is noticed. Proves the
        listening part works on THIS PC (it cannot prove that a real tracker sends alerts)."""
        from urllib.parse import urlparse
        res = {"ok": False, "at": time.time(), "detail": ""}
        pg = None
        try:
            u = urlparse(url)
            host = u.netloc
            origin = f"{u.scheme}://{host}"
            pg = self._ctx.new_page()
            pg.goto(url, wait_until="load", timeout=20000)
            pg.wait_for_function("document.title==='ready'", timeout=15000)
            cdp = self._ctx.new_cdp_session(pg)
            regs = {}
            cdp.on("ServiceWorker.workerRegistrationUpdated",
                   lambda e: regs.update({r["registrationId"]: r for r in e["registrations"]}))
            cdp.send("ServiceWorker.enable")
            pg.wait_for_timeout(800)
            rids = [r["registrationId"] for r in regs.values() if str(r.get("scopeURL", "")).startswith(origin)]
            if not rids:
                raise RuntimeError("the test page's helper did not start")
            self._selftest_state = {"host": host, "got": None}
            t_send = time.time()
            cdp.send("ServiceWorker.deliverPushMessage", {"origin": origin, "registrationId": rids[0], "data": json.dumps(
                {"title": "Reality Fracture Collector Booster Box", "body": "Target $299.99 (this is only a test)"})})
            end = t_send + 10
            while time.time() < end and self._selftest_state["got"] is None:
                pg.wait_for_timeout(100)
            got = self._selftest_state["got"]
            if got:
                res.update(ok=True, ms=round((got[0] - t_send) * 1000),
                           detail=f"the test alert was noticed {round((got[0] - t_send) * 1000)} ms after it was sent")
            else:
                res["detail"] = "the test alert was sent but the listener did not notice it within 10 s"
        except Exception as ex:
            res["detail"] = f"could not run the test: {str(ex)[:150]}"
        finally:
            self._selftest_state = None
            try:
                if pg is not None:
                    pg.close()
            except Exception:
                pass
        with self.lock:
            self.status["selftest"] = res
        self._log(f"[push] self-test {'PASSED' if res['ok'] else 'FAILED'}: {res['detail']}")

    # ---- "is it really set up" checks
    def _page_probe(self, page):
        try:
            return page.evaluate(PROBE_JS)
        except Exception as ex:
            return {"err": str(ex)[:100]}

    def _probe_all(self, force=False):
        now = time.time()
        for tr in self._push_trackers():
            tid = tr["id"]
            if not force and now - self._probe_at.get(tid, 0) < PROBE_EVERY:
                continue
            if not force and self._visible:
                continue                # never disturb a person who is signing in
            self._probe_at[tid] = now
            res = None
            kp = self._keep.get(tid)
            try:
                if kp is not None and not kp.is_closed():
                    res = self._page_probe(kp)
                else:
                    url = (tr.get("setup_urls") or [tr.get("feed_url")])[0]
                    url = probe_url(url)
                    pg = self._ctx.new_page()
                    try:
                        pg.goto(url, wait_until="domcontentloaded", timeout=25000)
                        pg.wait_for_timeout(1500)
                        res = self._page_probe(pg)
                    finally:
                        try:
                            pg.close()
                        except Exception:
                            pass
            except Exception as ex:
                res = {"err": str(ex)[:100]}
            res = res or {}
            if res.get("perm") not in (None, "granted") and self._allow_notifications(tr):
                # the site is asking for permission in a window nobody sees: give it, then look again (no click needed from you)
                try:
                    if kp is not None and not kp.is_closed():
                        kp.reload(wait_until="domcontentloaded", timeout=25000)
                        kp.wait_for_timeout(1500)
                        res = self._page_probe(kp) or res
                except Exception:
                    pass
            try:
                self._auto_enable(tr, res)
                if (self._signup.get(tid) or {}).get("at", 0) >= now:
                    kp2 = self._keep.get(tid)
                    if kp2 is not None and not kp2.is_closed():
                        kp2.reload(wait_until="domcontentloaded", timeout=25000)
                        kp2.wait_for_timeout(1500)
                        res = self._page_probe(kp2) or res
                    elif (self._signup.get(tid) or {}).get("ok"):
                        res = dict(res, sw=max(res.get("sw") or 0, 1))
            except Exception as ex:
                self._err_log(f"[push] automatic sign-up step failed: {ex}")
            res["checked_at"] = now
            self._probe[tid] = res
            with self.lock:
                self.status["trackers"][tid] = self._tracker_status(tr)

    def _allow_notifications(self, tr):
        """Tells the alert browser itself (not a page) that this tracker's site may show notifications. Tried a few times only.
        Returns True when the permission was set."""
        tid = tr["id"]
        tries = self._grant_tries = getattr(self, "_grant_tries", {})
        if tries.get(tid, 0) >= 3:
            return False
        tries[tid] = tries.get(tid, 0) + 1
        ok = False
        for host in (tr.get("push_hosts") or []):
            for origin in (f"https://{host}", f"https://www.{host}"):
                try:
                    self._ctx.grant_permissions(["notifications"], origin=origin)
                    ok = True
                except Exception:
                    pass
        if ok:
            self._log(f"[push] {tr.get('name', tid)}: allowed notifications for its site in the alert browser (you do not need to press Allow).")
        return ok

    def _click_pick(self, pg, mode, ev=None):
        """Presses the best match on the page (mode 'enable' = the tracker's own Enable browser alerts button, 'confirm' = a Continue / Allow
        button inside the page's own dialog, 'bell' = its notification bell). Returns the button's words, or None when there is no such
        button. The visible buttons of the page are noted in `ev` so a failure leaves evidence."""
        try:
            got = pg.evaluate(FIND_JS, mode)
            if isinstance(got, dict):
                if ev is not None and got.get("cands"):
                    ev["clickables"] = got["cands"]
                words = got.get("words")
            else:
                words = got
            if not words:
                return None
            loc = pg.locator("[data-rk-pick]").first
            try:
                loc.scroll_into_view_if_needed(timeout=3000)
            except Exception:
                pass
            try:
                loc.click(timeout=6000)
            except Exception:
                loc.click(timeout=6000, force=True)       # something transparent in front: press it anyway, the way a person would
            return words
        except Exception:
            return None

    def _enable_signup(self, tr, manual=False):
        """In the alert browser (permission already allowed): open the tracker's settings page and press ITS OWN 'Enable browser alerts'
        button (if the card is hidden behind the bell, the bell first; if the page asks "Continue?" in its own dialog, that too), then look
        whether the site now holds a push sign-up (service worker / subscription). Everything the page showed is kept as evidence.
        Never touches a login or human-check box."""
        tid = tr["id"]
        name = tr.get("name", tid).split(" (")[0]
        url = tr.get("enable_url")
        if not url:
            return None
        n = self._signup_tries[tid] = self._signup_tries.get(tid, 0) + 1
        res = {"at": time.time(), "ok": False, "note": "", "attempt": n}
        ev = {"console": [], "requests": [], "clickables": [], "steps": []}
        res["evidence"] = ev
        pg = None
        try:
            pg = self._ctx.new_page()
            try:
                pg.on("console", lambda m: ev["console"].append(f"{m.type}: {m.text[:140]}") if m.type in ("error", "warning") and len(ev["console"]) < 8 else None)
                pg.on("pageerror", lambda e: ev["console"].append("page error: " + str(e)[:140]) if len(ev["console"]) < 8 else None)
                pg.on("requestfailed", lambda r: ev["requests"].append(f"FAILED {r.method} {r.url[:110]}") if len(ev["requests"]) < 10 else None)
                pg.on("response", lambda r: ev["requests"].append(f"{r.status} {r.request.method} {r.url[:110]}")
                      if (r.status >= 400 or re.search(r"subscri|push|onesignal|fcm|firebase|gcm|webpush|notif", r.url, re.I)) and len(ev["requests"]) < 10 else None)
            except Exception:
                pass
            try:
                pg.goto(url, wait_until="domcontentloaded", timeout=30000)
            except Exception as ex:
                res["note"] = f"its settings page did not open ({str(ex).splitlines()[0][:60]})"
            try:
                pg.wait_for_load_state("networkidle", timeout=8000)
            except Exception:
                pass
            pg.wait_for_timeout(2500)
            pre = self._page_probe(pg) or {}
            where = (pg.url or "").lower()
            words = ""
            try:
                words = pg.evaluate(PAGE_WORDS_JS) or ""
            except Exception:
                pass
            ev["url"] = (pg.url or "")[:120]
            ev["words"] = words[:260]
            ev["perm_before"] = pre.get("perm")
            if re.search(r"/(login|sign[-_]?in|auth)\b", where) or (re.search(r"\b(log ?in|sign ?in)\b", words, re.I) and not re.search(r"\b(log ?out|sign ?out|settings)\b", words, re.I)):
                res["note"] = f"{name} shows its log-in page in the alert browser: log in once in the set-up window (your login is kept), then press 'Check my setup'"
            else:
                pressed, pr = None, {}
                for rnd in range(4):
                    pressed = self._click_pick(pg, "enable", ev)
                    if not pressed:
                        bell = self._click_pick(pg, "bell", ev)
                        if bell:
                            ev["steps"].append("pressed the bell: " + bell)
                            pg.wait_for_timeout(1500)
                            pressed = self._click_pick(pg, "enable", ev)
                    if not pressed and rnd >= 1:
                        pressed = self._click_pick(pg, "enable_loose", ev)      # only now the plainer "Enable notifications" wording is accepted
                    if not pressed:
                        try:
                            pg.mouse.wheel(0, 900)           # the card may be further down the page
                        except Exception:
                            pass
                        pg.wait_for_timeout(1500)
                        continue
                    ev["steps"].append("pressed: " + pressed)
                    for _ in range(10):
                        pg.wait_for_timeout(1200)
                        pr = self._page_probe(pg) or {}
                        if (pr.get("subs") or 0) > 0 or (pr.get("sw") or 0) > (pre.get("sw") or 0):
                            break
                        c = self._click_pick(pg, "confirm", ev)     # the page's own "Continue" / "Allow" in its dialog
                        if c:
                            ev["steps"].append("pressed in the page's dialog: " + c)
                    if (pr.get("subs") or 0) > 0 or (pr.get("sw") or 0) > (pre.get("sw") or 0):
                        break
                    pg.wait_for_timeout(1500)
                if not pressed:
                    res["note"] = f"no 'Enable browser alerts' button found on {name}'s settings page (it may already be on, or the page changed)"
                else:
                    ev["perm_after"] = pr.get("perm")
                    if (pr.get("subs") or 0) > 0:
                        res.update(ok=True, note=f"pressed '{pressed}': {name} now has this browser on its alert list ({pr.get('subs')} sign-up)")
                    elif (pr.get("sw") or 0) > 0:
                        res.update(ok=True, note=f"pressed '{pressed}': {name} installed its alert helper in this browser")
                    elif pr.get("perm") == "granted":
                        res["note"] = f"pressed '{pressed}', but {name} did not complete the sign-up (permission was granted; no alert helper appeared)"
                    else:
                        res["note"] = f"pressed '{pressed}', but the browser still says notifications are '{pr.get('perm')}'"
        except Exception as ex:
            res["note"] = f"could not complete the sign-up step ({str(ex).splitlines()[0][:80]})"
        finally:
            try:
                if pg is not None:
                    pg.close()
            except Exception:
                pass
        self._signup[tid] = res
        self._log(f"[push] {name} alert sign-up {'OK' if res['ok'] else 'NOT done'}: {res['note']}.")
        if not res["ok"]:
            self._log(f"[push] {name} evidence: page={ev.get('url')} permission={ev.get('perm_before')}->{ev.get('perm_after')}; steps={ev.get('steps')}; "
                      f"buttons seen={ev.get('clickables')}; page text={ev.get('words')!r}; console={ev.get('console')}; requests={ev.get('requests')}")
        return res

    def _enable_all(self):
        for tr in self._push_trackers():
            if tr.get("enable_url"):
                self._allow_notifications_now(tr)
                self._enable_signup(tr, manual=True)
        self._probe_all(force=True)

    def _allow_notifications_now(self, tr):
        self._grant_tries = getattr(self, "_grant_tries", {})
        self._grant_tries[tr["id"]] = 0
        return self._allow_notifications(tr)

    def _auto_enable(self, tr, res):
        """After a check: allowed but never signed up -> press the site's own button (at most 3 times per run, 2 minutes apart)."""
        if not tr.get("enable_url") or res.get("perm") != "granted" or self._visible:
            return
        if (res.get("subs") or 0) > 0 or (res.get("sw") or 0) > 0 or self._counts.get(tr["id"], 0) > 0:
            return
        last = self._signup.get(tr["id"]) or {}
        if self._signup_tries.get(tr["id"], 0) >= 6 or time.time() - last.get("at", 0) < 120:
            return
        self._enable_signup(tr)

    def _tracker_status(self, tr):
        tid = tr["id"]
        p = self._probe.get(tid) or {}
        kp = self._keep.get(tid)
        return {"permission": p.get("perm"), "push_subscriptions": p.get("subs"), "service_workers": p.get("sw"),
                "probe_error": p.get("err"), "checked_at": p.get("checked_at"),
                "tab_open": (kp is not None and not kp.is_closed()) if tr.get("keep_open_url") else None,
                "alerts_seen": self._counts.get(tid, 0), "last_alert_at": self._last_at.get(tid),
                "signup_note": (self._signup.get(tid) or {}).get("note"), "signup_at": (self._signup.get(tid) or {}).get("at"),
                "signup_ok": (self._signup.get(tid) or {}).get("ok"), "can_enable": bool(tr.get("enable_url")),
                "signup_evidence": (self._signup.get(tid) or {}).get("evidence")}

    def _keep_tabs(self):
        now = time.time()
        if now - self._keep_check < KEEP_CHECK_EVERY:
            return
        self._keep_check = now
        for tr in self._push_trackers():
            url = tr.get("keep_open_url")
            if not url:
                continue
            tid = tr["id"]
            pg = self._keep.get(tid)
            try:
                if pg is None or pg.is_closed():
                    pg = self._ctx.new_page()
                    self._keep[tid] = pg
                    self._keep_reload[tid] = now
                    try:
                        pg.goto(url, wait_until="domcontentloaded", timeout=25000)
                    except Exception:
                        pass
                    self._log(f"[push] opened the {tid} page so its alerts keep coming (it stays open in the alert browser).")
                elif now - self._keep_reload.get(tid, now) > KEEP_RELOAD_EVERY:
                    self._keep_reload[tid] = now
                    pg.reload(wait_until="domcontentloaded", timeout=25000)
            except Exception as ex:
                self._err_log(f"[push] could not keep the {tid} page open: {ex}")

    # ---- main loop
    def _loop(self):
        backoff = 2.0
        while True:
            with self.lock:
                go = self.wanted or bool(self._setup_proc) or any(a == "setup" for a, _ in self.requests)
            if not go:
                time.sleep(0.4)
                continue
            try:
                if self._br is None:
                    if self._setup_step():
                        time.sleep(0.4)
                        continue
                    self._connect()
                    backoff = 2.0
                elif any(a == "setup" for a, _ in list(self.requests)):
                    if self._setup_step() or self._br is None:
                        continue
                self._tick()
            except Exception as ex:
                with self.lock:
                    self.status["last_error"] = str(ex)[:300]
                self._err_log(f"[push] alert browser problem ({ex}); trying again in {int(backoff)} s.")
                self._disconnect()
                time.sleep(backoff)
                backoff = min(60.0, backoff * 2)

    def _tick(self):
        try:
            self._anchor.wait_for_timeout(250)        # lets Playwright deliver the events that arrived
        except Exception as ex:
            if self._anchor is not None and self._anchor.is_closed():
                self._new_anchor()                       # somebody closed our blank tab: make another
                return
            raise
        if not self._alive():
            raise RuntimeError("the alert browser was closed")
        self._handle_requests()
        if any(a == "setup" for a, _ in list(self.requests)):
            return                              # the loop opens the set-up window next
        self._keep_tabs()
        self._probe_all()
        with self.lock:
            for tr in self.trackers:
                self.status["trackers"][tr["id"]] = self._tracker_status(tr)


_MANAGER = Manager()


def manager():
    return _MANAGER


def stop_browser():
    """End the alert browser this program started (and its helper processes). Also runs when the program exits normally."""
    m = _MANAGER
    try:
        if m._setup_proc is not None:
            m._kill_chrome_tree(m._setup_proc)
            m._setup_proc = None
    except Exception:
        pass
    try:
        if m._proc is not None:
            try:
                import psutil
                for ch in psutil.Process(m._proc.pid).children(recursive=True):
                    try:
                        ch.kill()
                    except Exception:
                        pass
            except Exception:
                pass
            m._proc.kill()
            m._proc = None
    except Exception:
        pass


import atexit
atexit.register(stop_browser)
