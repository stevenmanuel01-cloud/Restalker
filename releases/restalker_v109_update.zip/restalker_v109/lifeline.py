"""v62: everything this program starts ends when the program ends - however it ends.

Diagnostics / your report: after Stop, or after closing the window, browsers and helpers of the program kept running in the background.
  - Windows: at start the program puts itself in a Windows "job". Every browser and helper it starts (and everything THEY start) is in
    that job too, and Windows ends the whole job the moment the program ends - by Stop, by closing its window, by a crash, or by the
    Task Manager. Nothing is left behind even if a cleanup step hangs.
    Your own browser (the one showing Restalker's page) is opened OUTSIDE the job, so it is never closed by the program.
  - Also on every system: a tiny separate "clean-up helper" watches the program. The moment the program is gone - for ANY reason -
    it ends every browser and helper the program had started (the program tells it every 2 seconds which ones those are).
  - Stop: every cleanup step runs with a time limit; whatever is still running after that is ended, then the program ends itself.
    A hard limit makes sure the program is gone within 15 seconds of pressing Stop, whatever happens.
"""
import os
import subprocess
import sys
import threading
import time
import webbrowser

VERSION = "v109"
_JOB = {"handle": None, "error": None}
CREATE_BREAKAWAY_FROM_JOB = 0x01000000
CREATE_NO_WINDOW = 0x08000000


def bind_children_to_me():
    """Windows: put this program in a job that ends all its child processes when the program ends. Elsewhere: nothing to do."""
    if os.name != "nt" or _JOB["handle"]:
        return bool(_JOB["handle"])
    try:
        import ctypes
        from ctypes import wintypes
        k32 = ctypes.WinDLL("kernel32", use_last_error=True)

        class IO_COUNTERS(ctypes.Structure):
            _fields_ = [(n, ctypes.c_ulonglong) for n in ("ReadOperationCount", "WriteOperationCount", "OtherOperationCount",
                                                         "ReadTransferCount", "WriteTransferCount", "OtherTransferCount")]

        class BASIC(ctypes.Structure):
            _fields_ = [("PerProcessUserTimeLimit", ctypes.c_longlong), ("PerJobUserTimeLimit", ctypes.c_longlong),
                        ("LimitFlags", wintypes.DWORD), ("MinimumWorkingSetSize", ctypes.c_size_t), ("MaximumWorkingSetSize", ctypes.c_size_t),
                        ("ActiveProcessLimit", wintypes.DWORD), ("Affinity", ctypes.c_size_t), ("PriorityClass", wintypes.DWORD),
                        ("SchedulingClass", wintypes.DWORD)]

        class EXTENDED(ctypes.Structure):
            _fields_ = [("BasicLimitInformation", BASIC), ("IoInfo", IO_COUNTERS), ("ProcessMemoryLimit", ctypes.c_size_t),
                        ("JobMemoryLimit", ctypes.c_size_t), ("PeakProcessMemoryUsed", ctypes.c_size_t), ("PeakJobMemoryUsed", ctypes.c_size_t)]

        k32.CreateJobObjectW.restype = wintypes.HANDLE
        k32.CreateJobObjectW.argtypes = [ctypes.c_void_p, wintypes.LPCWSTR]
        k32.SetInformationJobObject.argtypes = [wintypes.HANDLE, ctypes.c_int, ctypes.c_void_p, wintypes.DWORD]
        k32.AssignProcessToJobObject.argtypes = [wintypes.HANDLE, wintypes.HANDLE]
        k32.GetCurrentProcess.restype = wintypes.HANDLE
        k32.TerminateJobObject.argtypes = [wintypes.HANDLE, wintypes.UINT]
        job = k32.CreateJobObjectW(None, None)
        if not job:
            raise OSError(ctypes.get_last_error(), "CreateJobObject")
        info = EXTENDED()
        # 0x2000 = end every process of the job when the program ends; 0x800 = a process may be started outside the job on purpose
        info.BasicLimitInformation.LimitFlags = 0x2000 | 0x800
        if not k32.SetInformationJobObject(job, 9, ctypes.byref(info), ctypes.sizeof(info)):
            raise OSError(ctypes.get_last_error(), "SetInformationJobObject")
        if not k32.AssignProcessToJobObject(job, k32.GetCurrentProcess()):
            raise OSError(ctypes.get_last_error(), "AssignProcessToJobObject")
        _JOB["handle"] = job              # (kept open for the program's whole life: closing it is what ends the children)
        _JOB["k32"] = k32
        return True
    except Exception as e:
        _JOB["error"] = str(e)[:160]
        return False


def status():
    if os.name != "nt":
        return "not Windows - the program ends its browsers itself at Stop"
    return "ON - every browser and helper of the program ends with it" if _JOB["handle"] else f"not available ({_JOB['error']}) - Stop ends them itself"


def open_user_browser(url):
    """Opens Restalker's page in YOUR browser - started outside the program's job, so it is never closed with the program."""
    if os.name == "nt":
        try:
            subprocess.Popen(["cmd", "/c", "start", "", url], creationflags=CREATE_BREAKAWAY_FROM_JOB | CREATE_NO_WINDOW,
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            return
        except Exception:
            pass
    webbrowser.open(url)


def release_reaper():
    """v104: before a restart for an update - the clean-up helper is ended first, so it cannot end the NEW copy's starter too. (Every
    browser of the program is closed by the program itself, and start_app.bat closes any leftover.)"""
    p = _JOB.get("reaper")
    try:
        if p is not None and p.poll() is None:
            p.kill()
    except Exception:
        pass
    _JOB["reaper"] = None


def start_outside(path, cwd):
    """v104: starts a .bat OUTSIDE the program's Windows job and process tree (so ending the program never ends it).
    -> True when it was started."""
    if os.name != "nt":
        return False
    for flags in (CREATE_BREAKAWAY_FROM_JOB | CREATE_NO_WINDOW | 0x00000200,):
        try:
            # (cmd ... start: the .bat gets a window of its own, and the cmd in between ends at once - nothing links it to this program)
            subprocess.Popen(["cmd", "/c", "start", "", "/min", path], cwd=cwd, creationflags=flags,
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, stdin=subprocess.DEVNULL)
            return True
        except Exception:
            pass
    return False


def kill_children():
    """Ends every process the program started (and theirs)."""
    try:
        import psutil
        me = psutil.Process()
        kids = me.children(recursive=True)
        for k in kids:
            try:
                k.kill()
            except Exception:
                pass
        psutil.wait_procs(kids, timeout=3)
        return len(kids)
    except Exception:
        return -1


def run_limited(fn, seconds):
    """Runs one cleanup step; never waits longer than `seconds` for it."""
    t = threading.Thread(target=fn, daemon=True)
    t.start()
    t.join(seconds)
    return not t.is_alive()


def end_now(code=0):
    """The very last step: everything that is left ends, then the program."""
    kill_children()
    if _JOB.get("handle"):
        try:
            _JOB["k32"].TerminateJobObject(_JOB["handle"], code)      # (ends the program too)
        except Exception:
            pass
    os._exit(code)


def hard_deadline(seconds=15.0):
    """Whatever hangs: the program is gone after `seconds`."""
    def _k():
        time.sleep(seconds)
        end_now(0)
    threading.Thread(target=_k, daemon=True, name="hard-deadline").start()


# ---------------------------------------------------------------- the clean-up helper (a separate small process)
PIDFILE = None


def _tree():
    try:
        import psutil
        me = psutil.Process()
        return [(k.pid, k.create_time()) for k in me.children(recursive=True)]
    except Exception:
        return []


def start_reaper(folder):
    """Starts the clean-up helper and keeps telling it which processes belong to the program."""
    global PIDFILE
    PIDFILE = os.path.join(folder, "restalker_children.txt")
    try:
        import psutil
        me = psutil.Process()
        mine = f"{me.pid} {me.create_time()}"
    except Exception:
        mine = f"{os.getpid()} 0"
    exe = sys.executable
    if os.name == "nt":
        w = os.path.join(os.path.dirname(exe), "pythonw.exe")
        if os.path.exists(w):
            exe = w
    args = [exe, os.path.abspath(__file__), "--reap"] + mine.split() + [PIDFILE]
    proc = None
    for flags in ((CREATE_BREAKAWAY_FROM_JOB | CREATE_NO_WINDOW | 0x00000200, CREATE_NO_WINDOW | 0x00000200) if os.name == "nt" else (0,)):
        try:
            proc = subprocess.Popen(args, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, stdin=subprocess.DEVNULL,
                                    creationflags=flags, **({} if os.name == "nt" else {"start_new_session": True}))
            break
        except Exception:
            proc = None
    _JOB["reaper"] = proc

    def tell():
        while True:
            try:
                kids = [x for x in _tree() if not (proc and x[0] == proc.pid)]
                tmp = PIDFILE + ".tmp"
                with open(tmp, "w") as f:
                    f.write("\n".join(f"{p} {c}" for p, c in kids))
                os.replace(tmp, PIDFILE)
            except Exception:
                pass
            time.sleep(2)
    threading.Thread(target=tell, daemon=True, name="reaper-list").start()
    return proc is not None


def _reap(main_pid, main_ct, pidfile):
    """(runs in the helper) waits until the program is gone, then ends what it had started."""
    try:
        import psutil
    except Exception:
        psutil = None

    def alive():
        if psutil is None:
            try:
                os.kill(main_pid, 0)
                return True
            except Exception:
                return False
        try:
            p = psutil.Process(main_pid)
            return abs(p.create_time() - main_ct) < 2 or main_ct == 0
        except Exception:
            return False
    while alive():
        time.sleep(1)
    try:
        with open(pidfile) as f:
            rows = [ln.split() for ln in f.read().splitlines() if ln.strip()]
    except Exception:
        rows = []
    for row in rows:
        try:
            pid, ct = int(row[0]), float(row[1])
        except Exception:
            continue
        if psutil is not None:
            try:
                p = psutil.Process(pid)
                if abs(p.create_time() - ct) > 2:
                    continue                      # (that number now belongs to another program: left alone)
                for k in p.children(recursive=True):
                    try:
                        k.kill()
                    except Exception:
                        pass
                p.kill()
            except Exception:
                pass
        elif os.name == "nt":
            subprocess.call(["taskkill", "/F", "/T", "/PID", str(pid)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                            creationflags=CREATE_NO_WINDOW)
    try:
        os.remove(pidfile)
    except Exception:
        pass


if __name__ == "__main__" and len(sys.argv) >= 5 and sys.argv[1] == "--reap":
    _reap(int(sys.argv[2]), float(sys.argv[3]), sys.argv[4])
