"""TCG column (v46): TCGplayer as a PRICE INDEX, not a shop to watch.

TCGplayer is the reference price for Magic cards and sealed boxes. A TCGplayer link in the table is therefore never checked for
"in stock" and never raises a restock alert: this module reads the market price now and then (a few small web requests per hour,
no browser at all) and shows it in the TCG column. The other squares and the alert messages then say how far a store's price is
over or under that market price.

Where a price comes from (first one that works):
  1. live   - TCGplayer's own public price service for that product number (about every 10 minutes per product)
  2. page   - the product page's own text ("Market Price"), if the service says no
  3. daily  - tcgcsv.com, a free public copy of TCGplayer's prices, refreshed about once a day (the safety net)
Nothing here uses a password or an account; if a source refuses, the next one is used and the column says which one it was.
"""
import csv
import json
import os
import re
import threading
import time
import urllib.parse
import urllib.request

VERSION = "v109"
COLUMN = "tcg"                      # the table column (key) TCGplayer links belong to
HOST_WORDS = ("tcgplayer",)
LIVE_EVERY = 7200.0                 # v55: seconds between two reads of one product (once at start, then every 2 hours: it is a price index, not a store)
DAILY_EVERY = 4 * 3600.0            # seconds between two reads of the daily copy
GAP = 6.0                           # seconds between two requests (to any TCGplayer address)
BACKOFF = (300.0, 900.0, 1800.0)    # after a failed read: wait this long (1st, 2nd, 3rd+ failure) before the live source is tried again
HIST_PATH = "tcg_prices.csv"
CACHE_PATH = "tcg_groups.json"      # product number -> tcgcsv group (set) number, learned once
UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36")
MAGIC_CATEGORY = 1
LIVE_URL = "https://mpapi.tcgplayer.com/v2/product/{pid}/pricepoints"
CSV_ROOT = "https://tcgcsv.com/tcgplayer/%d" % MAGIC_CATEGORY

HTTP = None          # tests put a function(url) -> text here; normally plain web requests are used
_LOCK = threading.RLock()
_LAST = {}           # target id -> {"market", "low", "source", "at", "row"}
_STATE = {"items": {}, "thread": None, "last": "", "reads": 0, "fails": 0, "sources": {}}
_GROUPS = {}         # tcgcsv: product number -> group number (loaded from CACHE_PATH)
_DAILY = {"at": 0.0, "prices": {}}


# ---------------------------------------------------------------- addresses
def is_tcg_url(url):
    host = (urllib.parse.urlparse(url or "").netloc or "").lower()
    return any(w in host for w in HOST_WORDS)


def is_tcg(t):
    return bool(t) and is_tcg_url(t.get("url") or "")


def product_id(url):
    m = re.search(r"/product/(\d+)", url or "")
    return int(m.group(1)) if m else None


def split(targets):
    """-> (stock targets, price-index targets): the TCG links are kept apart from the ones the store checkers watch."""
    a, b = [], []
    for t in targets:
        (b if is_tcg(t) else a).append(t)
    return a, b


# ---------------------------------------------------------------- web access
def _get(url, timeout=15.0, limit=4_000_000):
    if HTTP is not None:
        return HTTP(url)
    req = urllib.request.Request(url, headers={"User-Agent": UA, "Accept": "application/json,text/html;q=0.9,*/*;q=0.8",
                                               "Accept-Language": "en-US,en;q=0.9", "Origin": "https://www.tcgplayer.com",
                                               "Referer": "https://www.tcgplayer.com/"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        body = r.read(limit + 1)
        if len(body) > limit:
            raise ValueError("too big")
        return body.decode("utf-8", "replace")


def _num(v):
    try:
        x = round(float(str(v).replace("$", "").replace(",", "")), 2)
    except (TypeError, ValueError):
        return None
    return x if x > 0 else None


# ---------------------------------------------------------------- reading the sources
def parse_pricepoints(text):
    """TCGplayer's price service: a list like [{"printingType": "Normal", "marketPrice": 285.5, "listedMedianPrice": 301.0}]."""
    d = json.loads(text)
    rows = d if isinstance(d, list) else (d.get("results") or d.get("result") or d.get("data") or [])
    if isinstance(rows, dict):
        rows = [rows]
    best = None
    for r in rows:
        if not isinstance(r, dict):
            continue
        mk = _num(r.get("marketPrice"))
        lo = _num(r.get("lowPrice") or r.get("lowestPrice") or r.get("listedMedianPrice"))
        cand = {"market": mk, "low": lo}
        if best is None or (mk and not best["market"]):
            best = cand
        if (r.get("printingType") or r.get("subTypeName") or "Normal") in ("Normal", "Sealed", "Unopened"):
            if mk:
                best = cand
                break
    if not best or not (best["market"] or best["low"]):
        raise ValueError("no price in the answer")
    return best


def parse_page(html):
    """The product page itself: its data block ("marketPrice": 285.5) or the words Market Price followed by a dollar amount."""
    mk = lo = None
    m = re.search(r'"marketPrice"\s*:\s*([0-9]+(?:\.[0-9]+)?)', html or "")
    if m:
        mk = _num(m.group(1))
    m = re.search(r'"(?:lowestPrice|lowPrice)"\s*:\s*([0-9]+(?:\.[0-9]+)?)', html or "")
    if m:
        lo = _num(m.group(1))
    if mk is None:
        txt = re.sub(r"<[^>]+>", " ", html or "")
        m = re.search(r"Market\s+Price[^$0-9]{0,40}\$\s*([0-9][0-9,]*(?:\.[0-9]{2})?)", txt, re.I)
        if m:
            mk = _num(m.group(1))
    if mk is None and lo is None:
        raise ValueError("no price on the page")
    return {"market": mk, "low": lo}


def parse_csv_prices(text, pid):
    d = json.loads(text)
    best = None
    for r in d.get("results") or []:
        if int(r.get("productId") or 0) != int(pid):
            continue
        cand = {"market": _num(r.get("marketPrice")), "low": _num(r.get("lowPrice"))}
        if cand["market"] is None and cand["low"] is None and _num(r.get("midPrice")):
            cand = {"market": _num(r.get("midPrice")), "low": None}
        if best is None or (cand["market"] and not best["market"]):
            best = cand
    if not best or not (best["market"] or best["low"]):
        raise ValueError("product not in this price list")
    return best


def _load_groups():
    with _LOCK:
        if _GROUPS:
            return
    try:
        with open(CACHE_PATH, encoding="utf-8") as f:
            d = json.load(f)
        with _LOCK:
            _GROUPS.update({int(k): int(v) for k, v in d.items()})
    except Exception:
        pass


def _save_groups():
    try:
        tmp = CACHE_PATH + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump({str(k): v for k, v in _GROUPS.items()}, f)
        os.replace(tmp, CACHE_PATH)
    except OSError:
        pass


def _words(s):
    return [w for w in re.sub(r"[^a-z0-9]+", " ", (s or "").lower()).split() if w not in ("the", "of", "magic", "gathering", "mtg")]


def group_for_product(pid, url, log_fn=None):
    """tcgcsv lists prices per set. The set (group) of a product is found once: the set names are compared with the words of the
    product address, and the best few sets are asked until one of them lists the product number. The answer is kept in tcg_groups.json."""
    _load_groups()
    with _LOCK:
        if pid in _GROUPS:
            return _GROUPS[pid]
    slug_words = set(_words(urllib.parse.urlparse(url).path.split("/product/")[-1].split("/", 1)[-1].replace("-", " ")))
    groups = json.loads(_get(CSV_ROOT + "/groups")).get("results") or []
    scored = []
    for g in groups:
        gw = _words(g.get("name"))
        if not gw:
            continue
        hit = sum(1 for w in gw if w in slug_words)
        if hit == len(gw):                                   # every word of the set name is in the product address
            scored.append((hit, -len(gw), g["groupId"]))
    scored.sort(reverse=True)
    for _, _, gid in scored[:4]:
        time.sleep(0 if HTTP is not None else 0.3)
        try:
            prices = json.loads(_get(f"{CSV_ROOT}/{gid}/prices")).get("results") or []
        except Exception:
            continue
        if any(int(r.get("productId") or 0) == int(pid) for r in prices):
            with _LOCK:
                _GROUPS[pid] = gid
            _save_groups()
            return gid
    return None


def read_daily(pid, url):
    gid = group_for_product(pid, url)
    if gid is None:
        raise ValueError("set not found in the daily price copy")
    with _LOCK:
        cached = _DAILY["prices"].get(gid)
        fresh = cached is not None and time.time() - cached[0] < 1800
    text = cached[1] if fresh else _get(f"{CSV_ROOT}/{gid}/prices")
    if not fresh:
        with _LOCK:
            _DAILY["prices"][gid] = (time.time(), text)
    return parse_csv_prices(text, pid)


def read_price(url, allow_live=True):
    """-> {"market", "low", "source"} or raises. Tries live, then the page, then the daily copy."""
    pid = product_id(url)
    if pid is None:
        raise ValueError("no product number in the link")
    why = []
    if allow_live:
        try:
            r = parse_pricepoints(_get(LIVE_URL.format(pid=pid)))
            r["source"] = "live"
            return r
        except Exception as e:
            why.append(f"live: {type(e).__name__} {str(e)[:50]}")
        time.sleep(0 if HTTP is not None else 1.0)
        try:
            r = parse_page(_get(url))
            r["source"] = "page"
            return r
        except Exception as e:
            why.append(f"page: {type(e).__name__} {str(e)[:50]}")
    try:
        r = read_daily(pid, url)
        r["source"] = "daily"
        return r
    except Exception as e:
        why.append(f"daily: {type(e).__name__} {str(e)[:50]}")
    raise RuntimeError("; ".join(why))


# ---------------------------------------------------------------- finding a product's TCGplayer link
KIND_WORDS = {
    "box": r"collector booster( pack)? (box|display)",
    "play_booster_box": r"play booster (box|display)",
    "set_booster_box": r"set booster (box|display)",
    "pack": r"collector booster( pack)?$",
    "bundle": r"bundle",
}


def find_link(theme, kind):
    """Looks the product up in the daily copy of TCGplayer's catalogue. -> a TCGplayer link or None. Used when a row has no TCG link."""
    want = KIND_WORDS.get(kind)
    if not want:
        return None
    tw = _words(theme)
    if not tw:
        return None
    groups = json.loads(_get(CSV_ROOT + "/groups")).get("results") or []
    scored = []
    for g in groups:
        gw = set(_words(g.get("name")))
        if not gw:
            continue
        inter = sum(1 for w in tw if w in gw)
        if inter == len(tw):
            scored.append((-len(gw - set(tw)), g["groupId"]))
    scored.sort(reverse=True)
    for _, gid in scored[:3]:
        time.sleep(0 if HTTP is not None else 0.3)
        prods = json.loads(_get(f"{CSV_ROOT}/{gid}/products")).get("results") or []
        for p in prods:
            nm = (p.get("cleanName") or p.get("name") or "").lower()
            nm = re.sub(r"[^a-z0-9 ]+", " ", nm).strip()
            if re.search(want, nm) and not re.search(r"\b(case|sample|art series|display case)\b", nm):
                if kind == "box" and "play" in nm:
                    continue
                url = p.get("url") or ""
                if url:
                    return url.split("?")[0] + "?page=1&Language=English"
                return f"https://www.tcgplayer.com/product/{p['productId']}"
    return None


# ---------------------------------------------------------------- the background reader
def _history(tid, row, r):
    try:
        new = not os.path.exists(HIST_PATH)
        with open(HIST_PATH, "a", newline="", encoding="utf-8") as f:
            w = csv.writer(f)
            if new:
                w.writerow(["time", "id", "row", "market", "low", "source"])
            w.writerow([time.strftime("%Y-%m-%d %H:%M:%S"), tid, row, r.get("market") or "", r.get("low") or "", r.get("source")])
    except OSError:
        pass


def latest_for_row(row_key):
    """-> {"market", "low", "source", "at"} of the newest TCG price for this product row, or None."""
    best = None
    with _LOCK:
        for v in _LAST.values():
            if v.get("row") == row_key and (best is None or v["at"] > best["at"]):
                best = dict(v)
    return best


def _row_key(t):
    try:
        import matrix
        return matrix.key_of(t)
    except Exception:
        return ""


def _is_off(t):
    try:
        import matrix
        return matrix.is_off(dict(t, needs_cap=False))       # (a product that waits for a price cap still gets its market price)
    except Exception:
        return False


def _record(t, r, report, log_fn):
    tid = t["id"]
    row = _row_key(t)
    price = r.get("market") or r.get("low")
    now = time.time()
    with _LOCK:
        prev = _LAST.get(tid)
        _LAST[tid] = {"market": r.get("market"), "low": r.get("low"), "source": r["source"], "at": now, "row": row}
        _STATE["reads"] += 1
        _STATE["sources"][r["source"]] = _STATE["sources"].get(r["source"], 0) + 1
    if prev is None or prev.get("market") != r.get("market") or prev.get("low") != r.get("low"):
        _history(tid, row, r)
    if report:
        report("target", tid, status="INDEX", checked_at=now, fetch_mode="http", price=price, low=r.get("low"),
               market=r.get("market"), source=r["source"], checks=_STATE["reads"], errors=_STATE["fails"])


def run(targets, stop_event, log_fn=print, report=None, get_targets=None):
    """Reads the price of every TCG link in a loop until stop_event is set. targets: the TCG links at start-up; get_targets (optional)
    returns the current list (links added while running)."""
    items = _STATE["items"]
    items.clear()
    for t in targets:
        items[t["id"]] = {"t": t, "next": time.time() + 2.0 + len(items) * GAP * 0.5, "fails": 0, "live_after": 0.0, "daily_next": 0.0}
    log_fn(f"[tcg] price index: reading {len(items)} TCGplayer price(s) (about every {int(LIVE_EVERY // 60)} min each, no browser, no stock alerts).")
    ok_said = False
    next_scan = 0.0
    while not stop_event.is_set():
        if get_targets and time.time() >= next_scan:
            next_scan = time.time() + 30.0
            try:
                for t in get_targets():
                    if is_tcg(t) and t["id"] not in items:
                        items[t["id"]] = {"t": t, "next": time.time() + 3.0, "fails": 0, "live_after": 0.0, "daily_next": 0.0}
            except Exception:
                pass
        due = [(v["next"], k) for k, v in items.items() if v["next"] <= time.time()]
        if not due:
            if stop_event.wait(1.0):
                break
            continue
        due.sort()
        tid = due[0][1]
        it = items[tid]
        t = it["t"]
        if _is_off(t) or not t.get("active", True):
            it["next"] = time.time() + 20.0
            continue
        try:
            import hotness
            slow = 4.0 if hotness.gaming() else 1.0
        except Exception:
            slow = 1.0
        now = time.time()
        try:
            live_ok = now >= it["live_after"]
            if live_ok or now >= it["daily_next"]:
                r = read_price(t["url"], allow_live=live_ok)
                if r["source"] == "daily":
                    it["daily_next"] = now + DAILY_EVERY
                _record(t, r, report, log_fn)
                if r["source"] != "daily":
                    it["fails"] = 0
                else:
                    it["fails"] += 1
                if not ok_said:
                    ok_said = True
                    log_fn(f"[tcg] first price read: {tid} market ${r.get('market')} ({r['source']}).")
            _STATE["last"] = f"{tid}: ok"
        except Exception as e:
            it["fails"] += 1
            _STATE["fails"] += 1
            _STATE["last"] = f"{tid}: {str(e)[:120]}"
            if it["fails"] in (1, 5, 20):
                log_fn(f"[tcg] could not read the price of {tid} ({str(e)[:140]}).")
            if report:
                report("target", tid, status="UNKNOWN", checked_at=time.time(), fetch_mode="http", errors=_STATE["fails"])
        if it["fails"]:
            it["live_after"] = now + BACKOFF[min(it["fails"], len(BACKOFF)) - 1]
        it["next"] = time.time() + (LIVE_EVERY if not it["fails"] else min(1800.0, LIVE_EVERY + 300.0 * it["fails"])) * slow
        if stop_event.wait(GAP * slow):
            break


def start(targets, stop_event, log_fn=print, report=None, get_targets=None):
    th = threading.Thread(target=run, args=(targets, stop_event, log_fn, report, get_targets), daemon=True, name="tcg-index")
    th.start()
    with _LOCK:
        _STATE["thread"] = th
    return th


def adopt(t):
    """A TCG link added while the program is running."""
    if not is_tcg(t):
        return False
    it = _STATE["items"]
    if t["id"] not in it:
        it[t["id"]] = {"t": t, "next": time.time() + 2.0, "fails": 0, "live_after": 0.0, "daily_next": 0.0}
    return True


def snapshot():
    with _LOCK:
        srcs = dict(_STATE["sources"])
        n_items = len(_STATE["items"])
        have = len(_LAST)
        last = _STATE["last"]
        reads, fails = _STATE["reads"], _STATE["fails"]
    th = _STATE.get("thread")
    return {"running": bool(th and th.is_alive()), "links": n_items, "with_price": have, "reads": reads, "fails": fails,
            "sources": srcs, "last": last}


def summary_text():
    s = snapshot()
    src = ", ".join(f"{k} {v}" for k, v in s["sources"].items()) or "none yet"
    return (f"{s['with_price']} of {s['links']} TCG links have a price; reads {s['reads']} (by source: {src}), failed {s['fails']}; "
            f"last: {s['last'] or 'nothing yet'}")


def vs_text(store_price, row_key):
    """'12% under TCG market $285.50' for an alert message, or '' when there is no TCG price for the row."""
    try:
        sp = float(store_price)
    except (TypeError, ValueError):
        return ""
    r = latest_for_row(row_key)
    if not r or not r.get("market"):
        return ""
    d = (sp / r["market"] - 1.0) * 100.0
    age = time.time() - r["at"]
    old = " (price from " + (f"{int(age // 3600)} h" if age >= 3600 else f"{int(age // 60)} min") + " ago)" if age > 2 * 3600 else ""
    if abs(d) < 0.5:
        rel = "at"
    else:
        rel = f"{abs(d):.0f}% {'over' if d > 0 else 'under'}"
    return f"{rel} TCG market ${r['market']:.2f}{old}"
