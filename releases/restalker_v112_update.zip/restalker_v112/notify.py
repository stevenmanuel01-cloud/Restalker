"""Tells you when the program has logged a restock, so you know when there is data worth downloading.

- A Windows pop-up (it appears in the corner of the screen, never takes your typing focus, and needs nothing installed).
- Optional, to your PHONE too (free): put a made-up private topic name in the file notify_phone.txt, install the free "ntfy" app,
  and subscribe to the same name there.
Messages: a logged restock, and an alert that arrives live from TrackaLacker / HotStock. Never more than one message per product per 3 minutes, so a flapping product cannot flood you. Free, and every failure is swallowed."""
import os, re, time, threading, subprocess, urllib.request

VERSION = "v112"
PHONE_FILE = "notify_phone.txt"
POPUP_FILE = "notify_popup.txt"    # the Windows pop-up is OFF unless this file exists (the pop-up could make a loud sound on some PCs)
RESTOCKS_FILE = "notify_restocks.txt"   # v96 (owner 2026-11-04: "I only want to get an alert when something is purchased or if there is a problem
# needing my attention (no need for a restock alert since the program will buy faster than I can)"): restock / tracker-alert messages
# are OFF unless this file exists (they are still written to notifications.csv, so every alert can be checked later)
SERVER = os.environ.get("RK_NTFY_SERVER") or "https://ntfy.sh"     # (a stand-in server for the self-tests; the real one otherwise)
EVERY = 180.0                      # seconds between messages about the same product and kind
LOG = None                         # set by app.py: a function that writes a line to the log (the timings of each message)
DESCRIBE = None                    # set by app.py: target id -> {"store", "product", "cap", "msrp"} (what the message says about the product)
DISCORD_FILE = "discord_webhook.txt"   # optional: a Discord channel's webhook address; the same messages are posted there
NOTIFY_CSV = "notifications.csv"   # every message that was sent or held back, so each tracker alert can be checked against what you were told
_last = {}
_lock = threading.Lock()
status = {"sent": 0, "last": "", "last_error": "", "phone": False}

_PS = r"""
[Windows.UI.Notifications.ToastNotificationManager, Windows.UI.Notifications, ContentType = WindowsRuntime] | Out-Null
$id = '{1AC14E77-02E7-4E5D-B744-2EB1AE5198B7}\WindowsPowerShell\v1.0\powershell.exe'
$shown = $false
try {
  # silent pop-up written out in full (Microsoft's documented way to switch the sound off)
  $ti = [System.Security.SecurityElement]::Escape($env:RK_N_TITLE); $ms = [System.Security.SecurityElement]::Escape($env:RK_N_MSG)
  $x = [Windows.Data.Xml.Dom.XmlDocument, Windows.Data.Xml.Dom.XmlDocument, ContentType = WindowsRuntime]::new()
  $x.LoadXml("<toast><visual><binding template='ToastGeneric'><text>$ti</text><text>$ms</text></binding></visual><audio silent='true'/></toast>")
  $n = [Windows.UI.Notifications.ToastNotification]::new($x)
  [Windows.UI.Notifications.ToastNotificationManager]::CreateToastNotifier($id).Show($n)
  $shown = $true
} catch { }
if (-not $shown) {
  $x = [Windows.UI.Notifications.ToastNotificationManager]::GetTemplateContent([Windows.UI.Notifications.ToastTemplateType]::ToastText02)
  $t = $x.GetElementsByTagName('text')
  $t.Item(0).AppendChild($x.CreateTextNode($env:RK_N_TITLE)) | Out-Null
  $t.Item(1).AppendChild($x.CreateTextNode($env:RK_N_MSG)) | Out-Null
  $a = $x.CreateElement('audio'); $a.SetAttribute('silent', 'true'); $x.DocumentElement.AppendChild($a) | Out-Null
  $n = [Windows.UI.Notifications.ToastNotification]::new($x)
  [Windows.UI.Notifications.ToastNotificationManager]::CreateToastNotifier($id).Show($n)
}
"""


def _popup(title, msg):
    if os.name != "nt":
        return False
    env = dict(os.environ, RK_N_TITLE=title, RK_N_MSG=msg)
    r = subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-WindowStyle", "Hidden",
                        "-Command", _PS], env=env, capture_output=True, timeout=30, creationflags=0x08000000)
    return r.returncode == 0


def popup_enabled():
    return os.path.exists(POPUP_FILE)


def _default_popup(title, msg):
    if not popup_enabled():
        return False
    return _popup(title, msg)


def phone_topic():
    try:
        t = open(PHONE_FILE, encoding="utf-8").read().strip()
    except Exception:
        return ""
    return t if re.fullmatch(r"[A-Za-z0-9_-]{6,64}", t) else ""


_DISCORD_RE = re.compile(r"^https://(?:ptb\.|canary\.)?discord(?:app)?\.com/api/webhooks/\d+/[\w-]+$")


def discord_webhook():
    try:
        u = open(DISCORD_FILE, encoding="utf-8").read().strip()
    except Exception:
        return ""
    return u if _DISCORD_RE.match(u) else ""


def set_discord(url):
    """Saves (or, with an empty text, removes) the Discord webhook. Returns '' when fine, else what is wrong."""
    url = (url or "").strip()
    try:
        if not url:
            if os.path.exists(DISCORD_FILE):
                os.remove(DISCORD_FILE)
            return ""
        if not _DISCORD_RE.match(url):
            return "That is not a Discord webhook address. It starts with https://discord.com/api/webhooks/ ."
        with open(DISCORD_FILE, "w", encoding="utf-8") as f:
            f.write(url + "\n")
        return ""
    except Exception as e:
        return f"Could not save it: {e}"


# ---- v99 (owner 2026-11-04: "the discord was intended to aggregate the information it receives from each deployment and return it to all
# other users as an additional tracking source ... eventually becoming a crowdsourced restock detection input"):
# - every copy of Restalker has its own short name (instance_id.txt); it posts as "Restalker · <name>", so each copy recognises its OWN
#   posts and counts every OTHER copy's posts as a tracker alert (discord_source.is_own). Before, every post called "Restalker" was
#   ignored - also the other copies'.
# - the Discord channel gets the restocks THIS program found and confirmed on the store page (once per restock), whatever the phone's
#   restock switch says - not a tracker's alert passed on (no echo between copies), not one another copy shared a moment ago.
# - purchases, problems and phone answers stay private (your phone) unless you switch "also my purchases and problems" on.
INSTANCE_FILE = "instance_id.txt"
SHARE_OFF_FILE = "discord_share_off.txt"       # exists = restocks are NOT shared to the Discord channel
PERSONAL_FILE = "discord_personal.txt"         # exists = purchases / problems are posted to the Discord channel too
CROWD_QUIET = 180.0                            # a restock another copy shared this recently is not shared again
_crowd_seen = {}                               # product -> when another copy's post about it was counted
_instance = {"id": None}


def instance_id():
    """This copy's short name for the Discord channel (made once). A copy for a new user makes its own."""
    if _instance["id"]:
        return _instance["id"]
    try:
        t = open(INSTANCE_FILE, encoding="utf-8").read().strip().lower()
        if re.fullmatch(r"[a-z0-9]{4,12}", t):
            _instance["id"] = t
            return t
    except Exception:
        pass
    import secrets as _s
    t = "".join(_s.choice("abcdefghijkmnpqrstuvwxyz23456789") for _ in range(6))
    try:
        with open(INSTANCE_FILE, "w", encoding="utf-8") as f:
            f.write(t + "\n")
    except Exception:
        pass
    _instance["id"] = t
    return t


def crowd_name():
    return "Restalker · " + instance_id()


def share_on():
    return not os.path.exists(SHARE_OFF_FILE)


def personal_on():
    return os.path.exists(PERSONAL_FILE)


def set_flag(path, on):
    try:
        if on:
            with open(path, "w", encoding="utf-8") as f:
                f.write("on\n")
        elif os.path.exists(path):
            os.remove(path)
    except Exception:
        pass


def note_crowd(tid):
    """Another copy's Discord post about this product was counted (discord_source)."""
    _crowd_seen[tid] = time.time()


def _crowd_share(tid, kind, who, title, body, price):
    """A restock this program found and confirmed -> the Discord channel (in the background). -> True when it is sent."""
    hook = discord_webhook()
    if not hook or not share_on() or kind != "restock" or who != PROGRAM_NAME:
        return False
    if time.time() - _crowd_seen.get(tid, 0.0) < CROWD_QUIET:
        status["crowd_skipped"] = status.get("crowd_skipped", 0) + 1
        return False

    def go():
        try:
            _discord("IN STOCK - " + title, body, hook)
            status["crowd_shared"] = status.get("crowd_shared", 0) + 1
            status["discord_last_ok"] = time.time()
        except Exception as e:
            status["crowd_failed"] = status.get("crowd_failed", 0) + 1
            status["crowd_error"] = str(e)[:120]
    threading.Thread(target=go, daemon=True, name="notify-crowd").start()
    return True


def _discord(title, msg, url):
    import json
    req = urllib.request.Request(url, data=json.dumps({"username": crowd_name(), "content": f"**{title}**\n{msg}"[:1900]}).encode("utf-8"), method="POST",
                                 headers={"Content-Type": "application/json", "User-Agent": "DiscordBot (restock-benchmark, 1.0)"})
    urllib.request.urlopen(req, timeout=15).read()
    return True


_csv_lock = threading.Lock()


def _record(kind, source, target, price, title, msg, result):
    """One line per message in notifications.csv (never raises)."""
    import csv
    try:
        with _csv_lock:
            new = not os.path.exists(NOTIFY_CSV)
            with open(NOTIFY_CSV, "a", newline="", encoding="utf-8", errors="replace") as f:
                w = csv.writer(f)
                if new:
                    w.writerow(["time_utc", "kind", "source", "target_id", "price", "title", "message", "result"])
                w.writerow([time.strftime("%Y-%m-%dT%H:%M:%S+00:00", time.gmtime()), kind, source, target, price if price is not None else "", title, msg, result])
    except Exception:
        pass


def _phone(title, msg, topic, click=None, actions=None):
    """One phone message. v96: with `actions` (up to 3 buttons, see phone_actions.py) it is sent the ntfy way that carries buttons (one JSON
    message); if that is refused for any reason the same message goes out the old way, without buttons - a message is never lost for them."""
    if actions:
        import json
        body = {"topic": topic, "title": title[:250], "message": msg, "priority": 4, "actions": list(actions)[:3]}
        if click and str(click).startswith("http"):
            body["click"] = str(click)[:500]
        try:
            req = urllib.request.Request(SERVER + "/", data=json.dumps(body).encode("utf-8"), method="POST",
                                         headers={"Content-Type": "application/json"})
            urllib.request.urlopen(req, timeout=15).read()
            status["buttons_sent"] = status.get("buttons_sent", 0) + 1
            return True
        except Exception as e:
            status["buttons_failed"] = status.get("buttons_failed", 0) + 1
            status["buttons_error"] = str(e)[:120]
    hdr = {"Title": title.encode("ascii", "replace").decode(), "Priority": "high"}
    if click and str(click).startswith("http"):
        hdr["Click"] = str(click)[:500]            # tapping the message opens the product page
    req = urllib.request.Request(SERVER + "/" + topic, data=msg.encode("utf-8"), method="POST",
                                 headers=hdr)
    urllib.request.urlopen(req, timeout=15).read()
    return True


def restock_alerts_on():
    """v96: restock and tracker-alert messages are sent only while notify_restocks.txt exists (off by default)."""
    return os.path.exists(RESTOCKS_FILE)


def set_restock_alerts(on):
    try:
        if on:
            with open(RESTOCKS_FILE, "w", encoding="utf-8") as f:
                f.write("Restock and tracker-alert messages are ON while this file exists. Purchases and problems are always sent.\n")
        elif os.path.exists(RESTOCKS_FILE):
            os.remove(RESTOCKS_FILE)
    except Exception:
        pass


def _deliver(title, msg, popup=None, phone=None, queued_at=None, meta=None, discord=None, link=None, actions=None):
    """Phone message and pop-up are sent at the same time (a slow pop-up must never hold the phone message back)."""
    popup = popup or _default_popup
    phone = phone or _phone
    err, t = [], {}
    started = time.time()
    topic = phone_topic()
    status["phone"] = bool(topic)

    def do_phone():
        s0 = time.time()
        try:
            if phone is _phone:
                phone(title, msg, topic, click=link, actions=actions)
            else:
                phone(title, msg, topic)
            t["phone_ms"] = int((time.time() - s0) * 1000)
        except Exception as ex:
            err.append(f"phone: {ex}")

    # v99: the Discord channel is shared with other copies - your own messages (purchases, problems, answers) go there only when you chose
    # so; restocks reach it through _crowd_share (once per restock)
    hook = discord_webhook() if (personal_on() and (meta or {}).get("kind") not in ("restock", "tracker")) else ""

    def do_discord():
        s0 = time.time()
        try:
            (discord or _discord)(title, msg, hook)
            t["discord_ms"] = int((time.time() - s0) * 1000)
            status["discord_last_ok"] = time.time()
        except Exception as ex:
            err.append(f"discord: {ex}")

    dth = None
    if hook:
        dth = threading.Thread(target=do_discord, daemon=True, name="notify-discord")
        dth.start()
    th = None
    if topic:
        th = threading.Thread(target=do_phone, daemon=True, name="notify-phone")
        th.start()
    s0 = time.time()
    try:
        popup(title, msg)
        t["popup_ms"] = int((time.time() - s0) * 1000)
    except Exception as ex:
        err.append(f"pop-up: {ex}")
    if th is not None:
        th.join(20)
    if dth is not None:
        dth.join(20)
    status["sent"] += 1
    status["last"] = time.strftime("%H:%M:%S") + "  " + title
    status["last_error"] = "; ".join(err)
    if meta:
        _record(meta.get("kind", ""), meta.get("source", ""), meta.get("target", ""), meta.get("price"), title, msg,
                ("sent to: " + ", ".join(x for x, ok in (("phone", "phone_ms" in t), ("Discord", "discord_ms" in t), ("Windows pop-up", "popup_ms" in t)) if ok)
                 or "sent to no one (no phone topic, Discord channel or pop-up is set up)") + (f"; problems: {status['last_error']}" if err else ""))
    try:
        if LOG:
            wait_ms = int((started - (queued_at or started)) * 1000)
            LOG(f"[notify] '{title}' sent: waited {wait_ms} ms to start, phone message accepted by ntfy after {t.get('phone_ms', '-')} ms, "
                f"pop-up shown after {t.get('popup_ms', '-')} ms." + (f" Problems: {status['last_error']}" if err else ""))
    except Exception:
        pass


def send(title, msg, key=None, force=False, wait=False, popup=None, phone=None, meta=None, discord=None, link=None, actions=None):
    """Send one message (in the background). key: messages with the same key are limited to one per 3 minutes."""
    now = time.time()
    with _lock:
        if key and not force and now - _last.get(key, 0) < EVERY:
            if meta:
                _record(meta.get("kind", ""), meta.get("source", ""), meta.get("target", ""), meta.get("price"), title, msg,
                        "held back: a message about this same product was sent less than 3 minutes before")
            return False
        if key:
            _last[key] = now
    th = threading.Thread(target=_deliver, args=(title, msg, popup, phone, now, meta, discord, link, actions), daemon=True, name="notify")
    th.start()
    if wait:
        th.join(40)
    return True


def set_popup(on):
    """Turns the Windows pop-up for real restocks on / off (a small file next to the program)."""
    try:
        if on:
            with open(POPUP_FILE, "w", encoding="utf-8") as f:
                f.write("Windows pop-ups for restock messages are ON while this file exists.\n")
        elif os.path.exists(POPUP_FILE):
            os.remove(POPUP_FILE)
    except Exception:
        pass


def _ntfy_has(topic, marker, timeout=10.0):
    """Asks the ntfy server whether it is holding our test message for this topic (what a subscribed phone would be given)."""
    import json
    try:
        r = urllib.request.urlopen(f"https://ntfy.sh/{topic}/json?poll=1&since=5m", timeout=timeout)
        for ln in r.read().decode("utf-8", "replace").splitlines():
            try:
                if marker in (json.loads(ln).get("message") or ""):
                    return True
            except Exception:
                continue
    except Exception:
        return None
    return False


def _discord_check(url):
    """v101: Discord's own answer about the webhook (a READ: nothing is posted) -> its name and channel number."""
    import json
    req = urllib.request.Request(url, method="GET", headers={"User-Agent": "DiscordBot (restock-benchmark, 1.0)"})
    d = json.loads(urllib.request.urlopen(req, timeout=15).read().decode("utf-8", "replace") or "{}")
    if not isinstance(d, dict) or not d.get("id"):
        raise ValueError("Discord gave no webhook back")
    return {"name": str(d.get("name") or ""), "channel": str(d.get("channel_id") or "")}


def test_discord(title, msg="Test alert (Discord).", discord=None, check=None):
    """v101 (owner 2026-11-05: "the discord test did work but we don't want that to always post the test alert message since that would
    trigger an alert to all users monitoring the channel"): the test only ASKS Discord whether the channel's webhook works - nothing is
    posted, so nobody in the channel gets anything. Each copy's real posts carry its own name ("Restalker · <name>")."""
    hook = discord_webhook()
    if not hook:
        return {"state": "off", "text": "Discord is not connected (optional). Paste a webhook address on the Trackers tab to share restocks in a Discord channel."}
    last = status.get("discord_last_ok")
    tail = (f" Last real post: {time.strftime('%b %d %H:%M', time.localtime(last))}." if last else "")
    try:
        t0 = time.time()
        info = (check or _discord_check)(hook)
        return {"state": "ok", "text": f"The channel's webhook works (Discord answered in {int((time.time() - t0) * 1000)} ms). Nothing was posted, so nobody in "
                                       f"the channel got a message. This copy posts restocks as '{crowd_name()}'." + tail}
    except Exception as e:
        return {"state": "bad", "text": f"Discord did not accept the webhook: {str(e)[:100]}. Check that the address is complete and was not deleted." + tail}


def test_all(title, phone=None, popup=None, check=None, discord=None):
    """One test message by every way. -> {'phone': {'state', 'text'}, 'popup': {...}, 'popup_on': bool, 'topic': str}
    states: ok / warn / bad / off. phone/popup/check can be replaced (for the self-test)."""
    phone = phone or _phone
    popup = popup or _popup
    check = check or _ntfy_has
    marker = "test " + time.strftime("%H:%M:%S")
    msg = f"Test alert ({marker}). You will get a message like this when something is bought or needs you" + (" (and when a restock is logged)." if restock_alerts_on() else ".")
    topic = phone_topic()
    out = {"topic": topic, "popup_on": popup_enabled(), "marker": marker, "restocks_on": restock_alerts_on()}
    if not topic:
        out["phone"] = {"state": "off", "text": "Phone alerts are not set up yet. Press 'Phone' in the top bar, scan the code with the ntfy app, then test again."}
    else:
        t0 = time.time()
        try:
            if phone is _phone:
                try:
                    import phone_actions                  # v96: the test message has a button - a tap on it shows a tap reaches this PC
                    acts = phone_actions.test_buttons()
                except Exception:
                    acts = None
                phone(title, msg + (" Tap 'Test this button' below: Restalker answers within a few seconds if a tap reaches this PC." if acts else ""),
                      topic, actions=acts)
            else:
                phone(title, msg, topic)
            ms = int((time.time() - t0) * 1000)
            stored = check(topic, marker)
            if stored is True:
                out["phone"] = {"state": "ok", "text": f"Sent to the ntfy server in {ms} ms and the server is holding it under the name '{topic}'. "
                                "If your phone did not show it: in the ntfy app the name must be exactly that (tap + and type it, or scan the QR code again), "
                                "and the ntfy app's notifications must be allowed in the phone's settings (and not silenced by Do Not Disturb)."}
            elif stored is False:
                out["phone"] = {"state": "warn", "text": f"The ntfy server answered in {ms} ms but did not list the message afterwards. Try again in a minute."}
            else:
                out["phone"] = {"state": "warn", "text": f"The ntfy server accepted the message in {ms} ms (could not check it afterwards). "
                                f"Your phone shows it only if the ntfy app is subscribed to exactly '{topic}'."}
        except Exception as e:
            out["phone"] = {"state": "bad", "text": f"The message could not be sent to ntfy.sh: {str(e)[:100]}. Is this PC online?"}
    try:
        ok = popup(title, msg + " (Windows pop-up)")
        if not ok and os.name != "nt":
            out["popup"] = {"state": "off", "text": "Windows pop-ups only exist on Windows."}
        else:
            out["popup"] = {"state": "ok" if ok else "bad",
                            "text": ("Windows was asked to show a pop-up (bottom-right corner, then the notification centre). If you saw nothing: Windows 'Focus assist' / "
                                     "'Do not disturb' or a full-screen game hides pop-ups; check Settings > System > Notifications.") if ok else "Windows refused to show the pop-up."}
    except Exception as e:
        out["popup"] = {"state": "bad", "text": f"Windows pop-up failed: {str(e)[:100]}"}
    out["discord"] = test_discord(title, msg, discord)
    out["ok"] = True
    try:
        if LOG:
            LOG(f"[notify] test: phone={out['phone']['state']} ({out['phone']['text'][:90]}) | pop-up={out['popup']['state']}")
    except Exception:
        pass
    return out


def make_topic():
    """A private, hard-to-guess topic name for the phone app; saved to notify_phone.txt (kept if it already exists)."""
    import random, string
    t = phone_topic()
    if t:
        return t
    t = "restock-" + "".join(random.SystemRandom().choice(string.ascii_lowercase + string.digits) for _ in range(12))
    with open(PHONE_FILE, "w", encoding="utf-8") as f:
        f.write(t + "\n")
    return t


_RESTOCK = re.compile(r"RESTOCK DETECTED: (\S+)")
_MENTION = re.compile(r"NEW MENTION: (\S+) / (\S+) \(")
_PRICE = re.compile(r" price \$([\d,]+(?:\.\d+)?)")
TRACKER_NAMES = {"typa": "TYPA", "trackalacker": "TrackaLacker", "hotstock": "HotStock", "nowinstock": "NowInStock", "discord": "Discord"}
_TS = re.compile(r"\[(\d{4}-\d\d-\d\dT[\d:.]+(?:[+-]\d\d:\d\d)?)\]")


def _nice(item):
    return item.replace("_", " ")


def _clock(msg):
    """The time written at the start of a log line, as this PC's clock time (HH:MM:SS), or ''."""
    try:
        from datetime import datetime, timezone
        m = _TS.search(msg)
        d = datetime.fromisoformat(m.group(1))
        if d.tzinfo is None:
            d = d.replace(tzinfo=timezone.utc)
        return d.astimezone().strftime("%H:%M:%S")
    except Exception:
        return ""


def describe(target_id):
    try:
        d = DESCRIBE(target_id) if DESCRIBE else None
    except Exception:
        d = None
    return d or {"store": "", "product": _nice(target_id), "cap": None, "msrp": None}


EVENT_GAP = 600.0                  # one message per restock: later reports of the SAME product within this many seconds of the first message are not sent
SOFT_GAP = 120.0         # v83: a marked tracker message (store page says sold out) holds back repeats of it only this long
EPISODE_MAX = 12 * 3600.0          # v65: ... and none at all while the product has not been seen OUT of stock since that message (at most this long)
VERIFY_WAIT = 10.0                 # v44: after a tracker report, how long to wait for the store page itself to confirm (the product is looked at NOW); then the message goes out anyway
PENDING_KEEP = 600.0               # a tracker report the store page has not confirmed yet is kept this long: if the store page confirms it later, the message goes then
PROGRAM_NAME = "Restalker"          # what the message calls this program
TRACKER_LABEL = "tracker"          # v44: the message only says "tracker" (not which one) or "Restalker" (this program) as the first to report
HOLD_UNCONFIRMED_ENV = "RK_HOLD_UNVERIFIED"   # v44: set this to hold back (instead of sending) a tracker report the store page did not confirm in time
UNVERIFIED_FILE = "notify_unverified.txt"   # (older switch, no longer needed)
VERIFY = None                      # set by app.py: target id -> {"status", "price", "checked_at"} (the newest reading of the store page) or None
_events = {}                       # target id -> {"t0": when the one message went out (or None), "who": who was first, "clock": its clock time, "pend": ...}
_ev_lock = threading.Lock()


def _span(sec):
    sec = int(round(sec))
    return f"{sec} s" if sec < 120 else f"{sec // 60} min {sec % 60} s"


def _unverified_ok():
    """v44: after VERIFY_WAIT seconds without the store page's answer the message is sent anyway (no price / page check)."""
    return not os.environ.get(HOLD_UNCONFIRMED_ENV)


def _line(d, price, clock, who):
    """The message: title = 'Store - $price - Product', body = 'time - MSRP $x (+y%) - link - who found it' (parts that are not known are left out)."""
    store = d.get("store") or ""
    title = " - ".join(x for x in (store, f"${price:,.2f}" if price is not None else "", d["product"]) if x)
    msrp = d.get("msrp")
    ms = ""
    if msrp:
        ms = f"MSRP ${msrp:,.2f}"
        if price is not None:
            pct = (price / msrp - 1) * 100
            ms += f" ({'at MSRP' if abs(pct) < 0.5 else ('%+.0f%%' % pct)})"
    tg = ""
    if d.get("tcg"):                                  # v46: TCGplayer's market price is the reference for what the box is worth
        tg = f"TCG ${d['tcg']:,.2f}"
        if price is not None:
            pct = (price / d["tcg"] - 1) * 100
            tg += f" ({'at TCG' if abs(pct) < 0.5 else ('%+.0f%%' % pct)})"
    body = " - ".join(x for x in (clock, ms, tg, d.get("url") or "", who) if x)
    return title, body


_last_out = {}                      # v65: target id -> when our own check last saw it OUT of stock
_EP_FILE = "alert_episodes.json"


def saw_out(tid, at=None):
    """v65: our own check read this product OUT of stock - the next time it comes in stock is a new restock (a new message)."""
    at = float(at or time.time())
    if at > _last_out.get(tid, 0.0):
        _last_out[tid] = at


def _still_in(ev, tid, now):
    """v65 (your report: alerts kept coming for products that were simply still in stock): after the message of a restock, no further
    message for that product until our own check has seen it OUT of stock again (a tracker repeating "in stock" is the same restock).
    If the store cannot be read at all, at most one message per EPISODE_MAX."""
    t0 = ev.get("t0")
    if t0 is None:
        return False
    if ev.get("soft"):
        return now - t0 < SOFT_GAP        # v83: after a "tracker says in, our check says sold out" message, a real restock still gets its own
    if now - t0 < EVENT_GAP:
        return True
    return _last_out.get(tid, 0.0) <= t0 and now - t0 < EPISODE_MAX


def _save_episodes():
    try:
        import json
        with _ev_lock:
            d = {"t0": {k: [v["t0"], v.get("who")] for k, v in _events.items() if v.get("t0")}, "out": dict(_last_out)}
        with open(_EP_FILE, "w", encoding="utf-8") as f:
            json.dump(d, f)
    except Exception:
        pass


def _load_episodes():
    try:
        import json
        with open(_EP_FILE, encoding="utf-8") as f:
            d = json.load(f)
        now = time.time()
        for k, (t0, who) in (d.get("t0") or {}).items():
            if now - float(t0) < EPISODE_MAX:
                _events.setdefault(k, {"t0": float(t0), "who": who, "clock": "", "pend": None})
        for k, v in (d.get("out") or {}).items():
            saw_out(k, v)
    except Exception:
        pass


def _announce(tid, price, who, clock, kind, source, verified, note=None, **kw):
    """Sends THE message of this restock (once)."""
    now = time.time()
    with _ev_lock:
        ev = _events.setdefault(tid, {"t0": None, "who": None, "clock": "", "pend": None})
        if _still_in(ev, tid, now):
            return False
        ev["t0"], ev["who"], ev["clock"], ev["pend"], ev["soft"] = now, who, clock, None, bool(note)
    _save_episodes()
    d = describe(tid)
    title, body = _line(d, price, clock or time.strftime("%H:%M:%S"), who)
    if note:
        body += " " + note
    elif not verified:
        body += " (unconfirmed)"
    shared = _crowd_share(tid, kind, who, title, body, price)
    if not restock_alerts_on():
        # v96: restock messages are off (the program buys by itself) - written down only, so each alert can still be checked later
        _record(kind, source, tid, price, title, body, "not sent: restock messages are off (you chose purchases and problems only)"
                + ("; shared to the Discord channel" if shared else ""))
        return False
    return send(title, body, key=None, link=d.get("url"), meta={"kind": kind, "source": source, "target": tid, "price": price}, **kw)


def _verify_thread(tid, at, tracker_name, source, clock, tprice, kw=None):
    """A tracker reported this product. For up to VERIFY_WAIT seconds wait for the store page's own fresh reading:
    IN STOCK with a price -> the message goes out with the page's price; at the end of the wait:
    - the page said IN STOCK but showed no price -> sent with the tracker's price;
    - the page said OUT OF STOCK (a fresh reading) -> held back (it sold out again, or the tracker was wrong) - it goes out later if our check confirms it;
    - the page gave no fresh reading at all (blocked, slow, unreadable) -> sent anyway with the tracker's price, marked (unconfirmed)."""
    kw = kw or {}
    deadline = at + VERIFY_WAIT
    d = describe(tid)
    cap = d.get("cap")
    fresh = None
    while time.time() < deadline:
        try:
            r = VERIFY(tid) if VERIFY else None
        except Exception:
            r = None
        if r and (r.get("checked_at") or 0) > at:
            fresh = r
            if r.get("status") == "IN_STOCK" and r.get("price") is not None:
                if cap is None or r["price"] <= float(cap):
                    _announce(tid, r["price"], TRACKER_LABEL, clock, "tracker", source, True, **kw)
                    return
        time.sleep(0.02)          # v52: was 0.25 s - the message goes out within 20 ms of the store page's answer
    st = (fresh or {}).get("status")
    if st == "OUT_OF_STOCK":
        # v83 (owner 2026-10-31: "ntfy is sending me alerts for some items but not others"; diagnostics 68: 14 tracker alerts were held
        # back this way - the Best Buy Star Trek box pre-order among them, whose page showed "Pre-order" behind Best Buy's waiting line
        # while its data said sold out): the message now goes out anyway, clearly marked, so no tracker alert is silently swallowed.
        if os.environ.get("RK_HOLD_TRACKER_OUT"):
            _record("tracker", source, tid, tprice, f"{d['product']}", "",
                    f"held back: a tracker says it is in stock but the store page, read just now, says out of stock - the message goes out if our check confirms it in the next {int(PENDING_KEEP // 60)} min")
            return
        _announce(tid, tprice, TRACKER_LABEL, clock, "tracker", source, False,
                  note="(tracker says in stock - our check of the store page says sold out right now: it may be a waiting line or already gone)", **kw)
        return
    if _unverified_ok():
        _announce(tid, tprice, TRACKER_LABEL, clock, "tracker", source, st == "IN_STOCK", **kw)
        return
    _record("tracker", source, tid, tprice, f"{d['product']}", "",
            f"held back: a tracker says it is in stock but the store page gave no answer within {int(VERIFY_WAIT)} s - the message goes out if our check confirms it in the next {int(PENDING_KEEP // 60)} min")


def from_log(msg, **kw):
    """Called with every log line. ONE message per restock of a product, and only VERIFIED data:
    - our own check found it in stock (the price is the store page's)  -> the message goes out at once;
    - a tracker reported it -> the product is looked at immediately and the message goes out as soon as the store page confirms it (price
      from the store page); if the page has not answered after VERIFY_WAIT (10) seconds the message goes out anyway, with the tracker's price
      (if it gave one) and marked "(unconfirmed)". If the page DID answer "out of stock" it is held back instead.
    The message reads: Store - $price - Product, then time - MSRP - link - who found it first ("tracker", or "Restalker" = this program).
    Every other report of the same restock is only written to notifications.csv as held back."""
    try:
        pm = _PRICE.search(msg)
        price = float(pm.group(1).replace(",", "")) if pm else None
        now = time.time()
        if "RESTOCK DETECTED" in msg:
            m = _RESTOCK.search(msg)
            if not m:
                return False
            tid = m.group(1)
            at = _clock(msg)
            with _ev_lock:
                ev = _events.get(tid)
                if ev and _still_in(ev, tid, now):
                    held = (now - ev["t0"], ev["who"])
                else:
                    held = None
                pend = ev["pend"] if ev and ev.get("pend") and now - ev["pend"]["at"] < PENDING_KEEP else None
            if held:
                d = describe(tid)
                _record("restock", "program", tid, price, f"{d['product']}", msg[-160:], f"held back: you were already told about this restock ({_span(held[0])} ago; first found by {held[1]}; not seen out of stock since)")
                return False
            who, clock = (TRACKER_LABEL, pend["clock"]) if pend else (PROGRAM_NAME, at)       # (no price on the page: the message simply has no price)
            return _announce(tid, price, who, clock, "restock", "program", True, **kw)
        if "NEW MENTION" in msg:
            m = _MENTION.search(msg)
            if not m:
                return False
            tid = m.group(2)
            if m.group(1) == "discord_in":
                note_crowd(tid)                   # (v99: another copy - or another tracker in your Discord - reported it)
            tn = TRACKER_NAMES.get(m.group(1), m.group(1))
            at = _clock(msg)
            with _ev_lock:
                ev = _events.setdefault(tid, {"t0": None, "who": None, "clock": "", "pend": None})
                if _still_in(ev, tid, now):
                    held = (now - ev["t0"], ev["who"])
                elif ev.get("pend") and now - ev["pend"]["at"] < PENDING_KEEP:
                    held = (None, ev["pend"]["who"])
                else:
                    held = None
                    ev["pend"] = {"who": tn, "clock": at, "at": now}
            if held:
                d = describe(tid)
                _record("tracker", m.group(1), tid, price, f"{d['product']}", msg[-160:],
                        "held back: " + (f"you were already told about this restock ({_span(held[0])} ago; first found by {held[1]}; not seen out of stock since)" if held[0] is not None
                                         else f"{held[1]} reported it first; waiting for the store page to confirm it"))
                return False
            # the product is looked at NOW (the tracker poller already marked it hot), and the message waits for what the store page says
            th = threading.Thread(target=_verify_thread, args=(tid, now, tn, m.group(1), at, price, kw), daemon=True, name="notify-verify")
            th.start()
            if kw.get("wait"):
                th.join(VERIFY_WAIT + 5)
            return True
    except Exception:
        pass
    return False


_load_episodes()      # v65: what was already announced survives a restart (no repeat message for a product still in stock)
