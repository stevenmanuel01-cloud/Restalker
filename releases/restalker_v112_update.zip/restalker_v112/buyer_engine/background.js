importScripts('rk_windows.js','catalog.js','logic.js','intelligence.js','detector_bridge.js','resource_telemetry.js','bb_engine.js','rk_reader.js','store_engine.js'); // Restalker v56: + the Best Buy checkout (separate; the Amazon checkout is unchanged)
const RI=globalThis.RestockIntel||{CONFIG_KEY:'ri:v1:config',scheduleTrain(){},async getEvents(){return[]},async getModel(){return{asins:{},sources:{},setRestocks:{},eventCount:0,restockCount:0,trainedAt:null}},scoreFrom(){return{score:0.03,tier:'COLD',predicted:null,reasons:[]}},async summary(){return{eventCount:0,restockCount:0,lastTrainedAt:null,sourceCount:0,asinModels:0,keepaEnabled:false,publicFeedEnabled:false}},async exportBundle(){return{format:'restock-intelligence-unavailable',events:[],model:{},config:{}}},async getConfig(){return{}},async setConfig(v){return v||{}},async importBundle(){return{added:0}},async ingestFeedPayload(){return{added:0,total:0}},async pollKeepa(){return{skipped:true}},async pollPublicFeed(){return{skipped:true}},async clearLearning(){return true},async recordAvailability(){return{restock:false}}};
const BASE_CATALOG=globalThis.AMAZON_CATALOG.filter(x=>!x.customProduct);
const CUSTOM_TEMPLATE=globalThis.AMAZON_CATALOG.find(x=>x.customProduct)||{set:'Custom ASIN',name:'Custom ASIN Product',customProduct:true,enabled:true,verified:false,tokens:[],cap:null,monitor:false,autoBuy:false};
const CUSTOM_DEFS_KEY='customProductDefs';
async function catalog(){const x=await chrome.storage.local.get(CUSTOM_DEFS_KEY),defs=Array.isArray(x[CUSTOM_DEFS_KEY])?x[CUSTOM_DEFS_KEY]:[];return [...BASE_CATALOG,...defs.map(d=>({...CUSTOM_TEMPLATE,...d,set:'Custom ASIN',customProduct:true,enabled:true}))]}
async function productById(id){return (await catalog()).find(x=>x.id===id)||null}
async function saveCustomDefs(defs){await chrome.storage.local.set({[CUSTOM_DEFS_KEY]:defs})}
const MIGRATION='v3.8-checkout-identity'; // legacy audited migration key retained as a regression contract
const RELEASE_MIGRATION='v3.23.1-explicit-test-only-manual-arm'; // Keep the established state schema on this patch release
const FLOW=t=>'flow:'+t;
const DEFAULT_NTFY_TOPIC='amz-66771b3f617bf8bd3d1c2652b99d235ebf42a135';
const D={monitoring:false,liveGlobal:false,lastHeartbeat:null,tickCount:0,ntfyTopic:DEFAULT_NTFY_TOPIC,lastNotifyOk:null,lastNotifyAt:null,cartOwner:null,cartOwnerSince:null,emergencyStop:false,globalCooldownUntil:0,throttleEvents:0,sessionHealth:'NORMAL'};
const k=id=>'p:'+id;
let tickRunning=false;
const checking=new Set();
let initPromise=null,ready=null;
const TEST_REQUESTS=new Map();let testGlobalAddQueue=Promise.resolve();
const defer=fn=>typeof queueMicrotask==='function'?queueMicrotask(fn):Promise.resolve().then(fn);
const buyerDetectorBridge=globalThis.MTGDetectorBridge.create({catalog,ps,g,check,diag,setg,handle:(...a)=>globalThis.__RK_HANDLE(...a)}); // Restalker: the bridge can also pass Restalker's commands to the handler below
// v3.18 global traffic governor: one account-wide scheduler, no synchronized tab bursts.
const REQUEST_WINDOW_MS=60000, REQUEST_BUDGET=18, REQUEST_MIN_GAP_MS=1800, requestTimes=[];
const TRAFFIC_STATE_KEY='runtimeTrafficGovernorV319';
// August v3.23 fast retry limit: at most 3 checkout attempts inside 60 seconds.
const CHECKOUT_MAX_ATTEMPTS=10,CHECKOUT_CAMPAIGN_MS=120000;   // v87: 6 tries in 90 s (was 3 in 60 s) - flash restocks come back within seconds
let lastAmazonRequestAt=0, trafficBlocked=0,trafficLock=Promise.resolve();
function pruneRequestTimes(now=Date.now()){while(requestTimes.length&&now-requestTimes[0]>=REQUEST_WINDOW_MS)requestTimes.shift()}
async function hydrateTrafficState(){const z=(await chrome.storage.local.get(TRAFFIC_STATE_KEY))[TRAFFIC_STATE_KEY]||{},now=Date.now(),times=Array.isArray(z.requestTimes)?z.requestTimes.map(Number).filter(t=>Number.isFinite(t)&&now-t<REQUEST_WINDOW_MS):[];requestTimes.splice(0,requestTimes.length,...times.sort((a,b)=>a-b));lastAmazonRequestAt=Math.max(Number(z.lastAmazonRequestAt)||0,requestTimes.at(-1)||0);trafficBlocked=Math.max(trafficBlocked,Number(z.trafficBlocked)||0)}
async function persistTrafficState(){await chrome.storage.local.set({[TRAFFIC_STATE_KEY]:{requestTimes:requestTimes.slice(-REQUEST_BUDGET),lastAmazonRequestAt,trafficBlocked,updatedAt:Date.now()}})}
function trafficSnapshot(){const now=Date.now();pruneRequestTimes(now);return {requestsLastMinute:requestTimes.length,requestBudget:REQUEST_BUDGET,minGapMs:REQUEST_MIN_GAP_MS,trafficBlocked,cooldownRemainingMs:0}}
async function trafficPermit({force=false}={}){
 const run=trafficLock.catch(()=>{}).then(async()=>{await hydrateTrafficState();const now=Date.now(),x=await g();if(x.emergencyStop)return {ok:false,reason:'emergency stop'};if(Number(x.globalCooldownUntil)>now)return {ok:false,reason:'amazon cooldown',wait:Number(x.globalCooldownUntil)-now};pruneRequestTimes(now);const gap=now-lastAmazonRequestAt;if(gap<REQUEST_MIN_GAP_MS){trafficBlocked++;await persistTrafficState();return {ok:false,reason:'global minimum gap',wait:REQUEST_MIN_GAP_MS-gap}}if(requestTimes.length>=REQUEST_BUDGET){trafficBlocked++;const wait=Math.max(250,REQUEST_WINDOW_MS-(now-requestTimes[0]));await persistTrafficState();return {ok:false,reason:'global request budget',wait}}requestTimes.push(now);lastAmazonRequestAt=now;await persistTrafficState();return {ok:true}});
 trafficLock=run.then(()=>{},()=>{});return run
}

// v3.23.7 low-overhead segmented journal. Historical diagEventsV323 is kept read-only for export.
// Each storage write contains at most 128 rows, not the previous 12,000-row array.
const DIAG_EVENTS_KEY='diagEventsV323',DIAG_MAX=12000;
const DIAG_CHUNK_PREFIX='diagChunkV323:',DIAG_META_KEY='diagChunkMetaV323',DIAG_CHUNK_SIZE=128,DIAG_CHUNK_COUNT=94;
const DIAG_IMPORTANT=/^(purchase_success|submit_latched|submission_unclear|definite_submission_failure|checkout_campaign_terminal|checkout_exclusive_retry_scheduled|checkout_price_evidence|eligible_authorized|checkout_owner_tab_closed|detector_catalog_sync_ack)$/;
let diagnosticQueue=[],diagnosticTimer=null,diagnosticTimerAt=0,diagnosticFlushTail=Promise.resolve();
const buyerResources=globalThis.MTGBuyerResourceTelemetry.create();
function diag(type,data={}){
 try{
  diagnosticQueue.push({ts:Date.now(),type,...data});buyerResources.note(type);
  if(diagnosticQueue.length>DIAG_MAX)diagnosticQueue.splice(0,diagnosticQueue.length-DIAG_MAX);
  const delay=DIAG_IMPORTANT.test(type)?300:10000;
  if(!diagnosticTimer||Date.now()+delay<diagnosticTimerAt-20){if(diagnosticTimer)clearTimeout(diagnosticTimer);diagnosticTimerAt=Date.now()+delay;diagnosticTimer=setTimeout(()=>{diagnosticTimer=null;diagnosticTimerAt=0;void flushDiagnostics()},delay);}
  if(diagnosticQueue.length>=64){clearTimeout(diagnosticTimer);diagnosticTimer=null;diagnosticTimerAt=0;void flushDiagnostics()}
 }catch{}
}
async function flushDiagnostics(){
 if(diagnosticTimer){clearTimeout(diagnosticTimer);diagnosticTimer=null;diagnosticTimerAt=0}
 const job=diagnosticFlushTail.catch(()=>{}).then(async()=>{
  if(!diagnosticQueue.length)return true;
  const batch=diagnosticQueue.splice(0);
  try{
   const state=(await chrome.storage.local.get(DIAG_META_KEY))[DIAG_META_KEY]||{};
   let index=Number.isInteger(state.index)?state.index:0,sequence=Number(state.sequence)||0;
   const updates={};let position=0;
   while(position<batch.length){
    const key=DIAG_CHUNK_PREFIX+index,stored=updates[key]||(await chrome.storage.local.get(key))[key];
    let rows=stored?.sequence===sequence&&Array.isArray(stored.rows)?stored.rows:[];
    const n=Math.min(DIAG_CHUNK_SIZE-rows.length,batch.length-position);
    rows=rows.concat(batch.slice(position,position+n));position+=n;
    updates[key]={sequence,rows};
    if(rows.length>=DIAG_CHUNK_SIZE){index=(index+1)%DIAG_CHUNK_COUNT;sequence++}
   }
   updates[DIAG_META_KEY]={index,sequence,lastFlushAt:Date.now()};
   await chrome.storage.local.set(updates);
   return true;
  }catch(e){
   diagnosticQueue=batch.concat(diagnosticQueue).slice(-DIAG_MAX);
   if(!diagnosticTimer)diagnosticTimer=setTimeout(()=>{diagnosticTimer=null;void flushDiagnostics()},10000);
   return false;
  }
 });diagnosticFlushTail=job.catch(()=>{});return job
}
function restoreDiagnosticEvents(all){
 const old=Array.isArray(all[DIAG_EVENTS_KEY])?all[DIAG_EVENTS_KEY]:[];
 const shards=Object.entries(all).filter(([k,v])=>k.startsWith(DIAG_CHUNK_PREFIX)&&v&&Number.isFinite(Number(v.sequence))&&Array.isArray(v.rows));
 shards.sort((a,b)=>Number(a[1].sequence)-Number(b[1].sequence));
 return old.concat(shards.flatMap(([k,v])=>v.rows)).slice(-DIAG_MAX)
}
function percentile(a,q){if(!a?.length)return null;const x=[...a].filter(Number.isFinite).sort((m,n)=>m-n);if(!x.length)return null;return x[Math.min(x.length-1,Math.floor((x.length-1)*q))]}
function performanceSummary(events){
 const recognition=events.filter(e=>e.type==='availability_observed'&&Number.isFinite(Number(e.recognitionMs))).map(e=>Number(e.recognitionMs));
 const scheduler=events.filter(e=>e.type==='check_start'&&Number.isFinite(Number(e.schedulerDelayMs))).map(e=>Number(e.schedulerDelayMs));
 const submit=events.filter(e=>e.type==='submit_latched'&&Number.isFinite(Number(e.eligibleToSubmitMs))).map(e=>Number(e.eligibleToSubmitMs));
 const pushedToSubmit=events.filter(e=>e.type==='submit_latched'&&e.pushToSubmitMs!==null&&Number.isFinite(Number(e.pushToSubmitMs))).map(e=>Number(e.pushToSubmitMs));
 const pushedToConfirm=events.filter(e=>e.type==='purchase_success'&&e.pushToConfirmedMs!==null&&Number.isFinite(Number(e.pushToConfirmedMs))).map(e=>Number(e.pushToConfirmedMs));
 const stream=events.filter(e=>e.type==='sensor_stream_event'&&Number.isFinite(Number(e.receiveLagMs))).map(e=>Number(e.receiveLagMs));
 const out=a=>({count:a.length,p50:percentile(a,.50),p95:percentile(a,.95),p99:percentile(a,.99),max:a.length?Math.max(...a):null});
 return {domRecognitionMs:out(recognition),schedulerDelayMs:out(scheduler),eligibleToSubmitMs:out(submit),pushToSubmitMs:out(pushedToSubmit),pushToConfirmedMs:out(pushedToConfirm),sensorStreamReceiveLagMs:out(stream)};
}
// Detector's existing local read-only diagnostic endpoint provides measured Node process CPU time and RAM.
// Skip when offline: the Export button always completes with an explicit missing-data marker.
async function getDetectorProcessTelemetry(){
 if(!buyerDetectorBridge.connected())return {available:false,reason:'detector bridge disconnected',process:null};
 const ctl=new AbortController(),timer=setTimeout(()=>ctl.abort(),2500);
 try{
  const r=await fetch('http://127.0.0.1:17861/api/diagnostics',{signal:ctl.signal,cache:'no-store'});
  if(!r.ok)throw Error('detector status '+r.status);
  const doc=await r.json();const p=doc?.process;
  if(!p)throw Error('no detector process metrics in response');
  const use=p.cpuUsageMicroseconds||{},secs=Number(p.uptimeSeconds),micros=Number(use.user||0)+Number(use.system||0);
  return {available:true,measuredAt:doc.exportedAt,process:{bootId:p.bootId,pid:p.pid,uptimeSeconds:secs,cpuUsageMicroseconds:use,averageCpuPercentOneCore:secs>0?Math.round(micros/(secs*1000000)*10000)/100:null,memory:p.memory,eventLoop:p.eventLoop},note:'Detector Node process only; excludes its Chrome/browser probe processes.'};
 }catch(e){return {available:false,reason:String(e?.message||e).slice(0,180),process:null}}
 finally{clearTimeout(timer)}
}
async function diagnosticsBundle(){
 await flushDiagnostics();
 const resourceDiagnostics=await buyerResources.exportData();
 const detectorProcessTelemetry=await getDetectorProcessTelemetry();
 const all=await chrome.storage.local.get(null),manifest=chrome.runtime.getManifest(),intel=await RI.exportBundle();
 const safeStorage={...all};delete safeStorage['resourceTelemetryV3238'];delete safeStorage[DIAG_EVENTS_KEY];for(const key of Object.keys(safeStorage))if(key.startsWith(DIAG_CHUNK_PREFIX))delete safeStorage[key];if(safeStorage[RI.CONFIG_KEY])safeStorage[RI.CONFIG_KEY]={...safeStorage[RI.CONFIG_KEY],keepaApiKey:safeStorage[RI.CONFIG_KEY].keepaApiKey?'[REDACTED]':''};
 return {
  exportedAt:new Date().toISOString(),
  extension:{name:manifest.name,version:manifest.version},
  target:{restockOccurredToDetectionPushedGoalMs:1000,detectionPushedToOrderConfirmedGoalMs:1000,note:'Both cumulative budgets include external Amazon/network time; actual restock timestamp requires independent ground truth. Simulations are not proof.'},
  traffic:trafficSnapshot(),
  global:await g(),
  products:await catalog(),
  diagnosticEvents:restoreDiagnosticEvents(all),
  performanceSummary:performanceSummary(restoreDiagnosticEvents(all)),
  restockIntelligence:intel,
  detectorBridge:buyerDetectorBridge.status(),
  resourceDiagnostics,detectorProcessTelemetry,
  storage:safeStorage
 };
}
async function noteThrottle(reason='Amazon throttle/block detected'){const x=await g(),n=(Number(x.throttleEvents)||0)+1,cool=Math.min(30*60*1000,Math.max(2*60*1000,2*60*1000*n));await setg({throttleEvents:n,globalCooldownUntil:Date.now()+cool,sessionHealth:'COOLDOWN'});return cool}
async function clearCooldownIfHealthy(){const x=await g();if(Number(x.globalCooldownUntil)&&Date.now()>=Number(x.globalCooldownUntil))await setg({globalCooldownUntil:0,sessionHealth:'NORMAL'})}

const ensureInit=()=>initPromise||(initPromise=init());
const stateCacheEnabled=!!chrome.storage.onChanged?.addListener;let globalCache=null;const productStateCache=new Map();
async function g(){if(stateCacheEnabled&&globalCache)return {...D,...globalCache};const z=await chrome.storage.local.get(D);globalCache={...D,...z};return {...globalCache}}
function defaultProductState(p){return {monitor:p.monitor,autoBuy:p.autoBuy,enabled:p.enabled!==false,cap:p.cap,armed:false,purchased:false,attempted:false,inProgress:false,submissionPending:false,status:p.asin?'Waiting':'SEARCHING — exact Amazon listing unresolved',price:null,lastCheck:null,checks:0,tabId:null,discoveredAsin:null,discoveredUrl:null,approval:null,checkoutOwned:false,queued:false,queuedPrice:null,queuedAt:null,nextCheckAt:0,consecutiveErrors:0,customAsin:null,customName:null,customTokens:null,customMsrp:null,customCurrentPrice:null,hitDetectedAt:null,campaignStartedAt:null,campaignAttempts:0,campaignLastAttemptStartedAt:null,checkoutRetryPending:false,checkoutRetryDueAt:0,lastAttemptMs:null,lastAttemptOutcome:null,timingHistory:[],stockHistory:[],lastAvailabilityClass:null,unavailableStreak:0,setHeatUntil:0,priority:'NORMAL',restockScore:0,intelligenceTier:'COLD',predictedRestockLow:null,predictedRestockCenter:null,predictedRestockHigh:null,predictionConfidence:null,intelligenceReasons:[],collapsed:false}}
async function ps(p){const key=k(p.id);if(stateCacheEnabled&&productStateCache.has(key))return {...defaultProductState(p),...productStateCache.get(key)};const saved=(await chrome.storage.local.get(key))[key]||{};if(stateCacheEnabled)productStateCache.set(key,saved);return {...defaultProductState(p),...saved}}
const stateLocks=new Map();
async function setp(p,v){const id=p.id,key=k(id),prev=stateLocks.get(id)||Promise.resolve();const next=prev.catch(()=>{}).then(async()=>{const current=await ps(p),merged={...current,...v};if(stateCacheEnabled)productStateCache.set(key,merged);await chrome.storage.local.set({[key]:merged})});stateLocks.set(id,next);try{await next}finally{if(stateLocks.get(id)===next)stateLocks.delete(id)}}
async function setg(v){if(stateCacheEnabled)globalCache={...(globalCache||await g()),...v};await chrome.storage.local.set(v)}
chrome.storage.onChanged?.addListener?.((changes,area)=>{if(area!=='local')return;for(const [key,ch] of Object.entries(changes)){if(key.startsWith('p:')){if(ch.newValue)productStateCache.set(key,ch.newValue);else productStateCache.delete(key)}else if(Object.prototype.hasOwnProperty.call(D,key)){globalCache={...(globalCache||D),[key]:ch.newValue}}}})
function runtimeProduct(p,s){
 // v62: the kind and set name Restalker's table says this listing must show (checked on the product page before anything is bought)
 const rk={rkShape:s?.rkShape||null,rkTheme:Array.isArray(s?.rkTheme)?s.rkTheme:null};
 if(!p?.customProduct)return {...p,...rk};
 const asin=String(s?.customAsin||s?.discoveredAsin||'').toUpperCase();
 const name=String(s?.customName||p.name||'Custom ASIN Product');
 const tokens=Array.isArray(s?.customTokens)&&s.customTokens.length?s.customTokens:p.tokens;
 return {...p,asin,url:asin?'https://www.amazon.com/dp/'+asin:'',search:asin?'https://www.amazon.com/s?k='+asin:'',name,tokens,...rk};
}
function validCapState(s){return Number.isFinite(s?.cap)&&s.cap>0}
async function clearFlowForTab(tabId){if(Number.isInteger(tabId))await chrome.storage.local.remove(FLOW(tabId))}
async function init(){
 const mig=await chrome.storage.local.get(RELEASE_MIGRATION);
 if(!mig[RELEASE_MIGRATION]){
   // Clear stale transient purchase sessions and state for intentionally removed products.
   const all=await chrome.storage.local.get(null),flowKeys=Object.keys(all).filter(x=>x.startsWith('flow:'));if(flowKeys.length)await chrome.storage.local.remove(flowKeys);
   await chrome.storage.local.remove(['p:star-trek-bundle','p:test-crest-mouthwash-b0glqq7hjn']);
   let customStore=await chrome.storage.local.get(CUSTOM_DEFS_KEY),customDefs=Array.isArray(customStore[CUSTOM_DEFS_KEY])?customStore[CUSTOM_DEFS_KEY]:null;
   if(!customDefs){const legacy=all[k('custom-asin-product')]||{};customDefs=[{id:'custom-asin-product',name:'Custom ASIN Product',asin:'',url:'',search:'',tokens:[],capSource:null}];await saveCustomDefs(customDefs);if(legacy.customAsin){legacy.customName=legacy.customName||('Custom ASIN — '+legacy.customAsin);await chrome.storage.local.set({[k('custom-asin-product')]:legacy})}}
   for(const p of await catalog()){
     const key=k(p.id),existing=all[key]||{},isFF=p.id==='final-fantasy-cb-box',isCustom=!!p.customProduct,uncertain=!isCustom&&!!existing.attempted&&!existing.purchased,interrupted=!isCustom&&!!existing.inProgress&&!existing.attempted;
     const next={...existing,
       cap:isCustom?(Object.prototype.hasOwnProperty.call(existing,'cap')?existing.cap:null):(isFF?800:(Object.prototype.hasOwnProperty.call(existing,'cap')?existing.cap:p.cap)),
       monitor:false,
       inProgress:false,submissionPending:false,approval:null,
       armed:false,
       purchased:isCustom?!!existing.purchased:!!existing.purchased,attempted:isCustom?!!existing.attempted:!!existing.attempted,
       autoBuy:isCustom||uncertain||interrupted||existing.monitor===false?false:!!existing.autoBuy
     };
     if(isCustom)Object.assign(next,{customAsin:existing.customAsin||null,customName:existing.customName||null,customTokens:existing.customTokens||null,customMsrp:Number.isFinite(existing.customMsrp)?existing.customMsrp:null,customCurrentPrice:Number.isFinite(existing.customCurrentPrice)?existing.customCurrentPrice:null,discoveredAsin:existing.discoveredAsin||existing.customAsin||null,discoveredUrl:existing.discoveredUrl||(existing.customAsin?'https://www.amazon.com/dp/'+existing.customAsin:null),status:existing.customAsin?(existing.status||'ASIN LOADED — set maximum price'):'ENTER ASIN — cap required'});
     if(uncertain)next.status='ORDER STATE UNCERTAIN AFTER UPGRADE — CHECK AMAZON';else if(interrupted)next.status='PURCHASE INTERRUPTED BY UPGRADE — RE-ARM REQUIRED';
     next.armed=false;next.monitor=false;next.autoBuy=false;next.inProgress=false;next.submissionPending=false;next.approval=null;next.nextCheckAt=0;await chrome.storage.local.set({[key]:next});
   }
   // Major purchase-engine upgrades always require the user to re-enable the global live switch.
   await chrome.storage.local.set({[RELEASE_MIGRATION]:true,monitoring:false,liveGlobal:false,ntfyTopic:DEFAULT_NTFY_TOPIC,lastNotifyOk:null,lastNotifyAt:null});
 }
 // Keep the production-validated phone subscription stable across every reload/upgrade.
 // A stale topic in extension storage must never silently redirect purchase alerts.
 await chrome.storage.local.set({ntfyTopic:DEFAULT_NTFY_TOPIC});
 for(const p of await catalog()){const x=await chrome.storage.local.get(k(p.id));if(!(k(p.id) in x))await setp(p,{status:Number.isFinite(p.cap)&&p.cap>0?'CAP SET — monitoring':'CAP REQUIRED — not monitoring'})}
 await hydrateTrafficState();await buyerResources.load();await chrome.alarms.create('resource_sample_v3238',{periodInMinutes:.5});void buyerResources.capture({catalog,ps,g});await chrome.alarms.create('tick',{periodInMinutes:.5});await chrome.alarms.create('intelligence',{periodInMinutes:1});RI.scheduleTrain();startFastLoop();startIntelligenceLoop();void syncSensorStream();await refreshIntelligenceScores();await badge();
}
async function notify(title,message){
 let desktop=false,phone=false;
 try{await chrome.notifications.create({type:'basic',iconUrl:'icon128.png',title,message});desktop=true}catch{}
 const x=await g();if(x.ntfyTopic){for(let i=0;i<3&&!phone;i++){const ctl=new AbortController(),to=setTimeout(()=>ctl.abort(),5000);try{const r=await fetch('https://ntfy.sh/'+encodeURIComponent(x.ntfyTopic),{method:'POST',headers:{Title:title,Priority:'high'},body:message,signal:ctl.signal});phone=!!r.ok}catch{}finally{clearTimeout(to)}if(!phone)await new Promise(r=>setTimeout(r,750*(i+1)))}}
 await setg({lastNotifyOk:phone,lastNotifyAt:Date.now()});return {desktop,phone};
}
async function badge(){const x=await g(),cat=await catalog(),ss=await Promise.all(cat.map(ps)),buy=ss.some(s=>s.inProgress||s.submissionPending),err=ss.some(s=>/^(ACTION|ERROR|BLOCKED)/.test(String(s.status)));const t=buy?'BUY':err?'ERR':x.monitoring?'ON':'OFF';await chrome.action.setBadgeText({text:t});await chrome.action.setBadgeBackgroundColor({color:buy?'#f59e0b':err?'#dc2626':x.monitoring?'#16a34a':'#6b7280'})}
function amazonUrl(url){try{const h=new URL(url).hostname.toLowerCase();return h==='amazon.com'||h.endsWith('.amazon.com')}catch{return false}}
let tabAllocationLock=Promise.resolve();
async function tab(p,active=false){
 const run=tabAllocationLock.catch(()=>{}).then(async()=>{
  const s=await ps(p),rp=runtimeProduct(p,s),asin=(s.discoveredAsin||rp.asin||'').toUpperCase(),url=s.discoveredUrl||rp.url||rp.search;if(!url)return null;
  if(s.tabId){try{const e=await chrome.tabs.get(s.tabId);if(e?.id&&amazonUrl(e.url||url))return e}catch{}await setp(p,{tabId:null})}
  if(!active&&!(await g()).cartOwner){
   const candidates=[];
   for(const q of await catalog()){
    if(q.id===p.id||checking.has(q.id))continue;
    const st=await ps(q);
    if(!Number.isInteger(st.tabId)||st.inProgress||st.submissionPending||st.checkoutOwned||st.checkoutRetryPending||st.approval||st.queued)continue;
    try{const t=await chrome.tabs.get(st.tabId);if(t?.id&&!t.active&&!t.pinned&&globalThis.AmazonBuyerLogic.exactUrl(t.url,st.discoveredAsin||st.customAsin||q.asin||''))candidates.push({q,st,t})}catch{}
   }
   // Recycle oldest background listing instead of accumulating one tab per ASIN.
   if(candidates.length>=2){
    candidates.sort((a,b)=>(Number(a.st.lastCheck)||0)-(Number(b.st.lastCheck)||0));
    const old=candidates[0];await setp(old.q,{tabId:null});await setp(p,{tabId:old.t.id});
    return old.t; // check() performs exactly one exact-ASIN navigation below
   }
  }
  const t=await chrome.tabs.create({url,active});await setp(p,{tabId:t.id});return t;
 });tabAllocationLock=run.catch(()=>{});return run
}
// Old installation can have many already-open monitoring tabs. Trim only extension-owned
// inactive listing tabs, never a checkout, user-selected tab, or live check.
let lastWarmTrim=0;
async function trimWarmMonitorTabs(){
 const now=Date.now();if(now-lastWarmTrim<60000)return;
 lastWarmTrim=now;
 if((await g()).cartOwner)return;
 const owned=[];
 for(const p of await catalog()){
  if(checking.has(p.id))continue;
  const st=await ps(p),asin=st.discoveredAsin||st.customAsin||p.asin||'';
  if(!Number.isInteger(st.tabId)||st.inProgress||st.submissionPending||st.checkoutOwned||st.checkoutRetryPending||st.approval||st.queued)continue;
  try{const tab=await chrome.tabs.get(st.tabId);
   if(tab?.id&&!tab.active&&!tab.pinned&&globalThis.AmazonBuyerLogic.exactUrl(tab.url,asin))owned.push({p,st,tab});
  }catch{}
 }
 if(owned.length<=2)return;
 owned.sort((a,b)=>(Number(b.st.lastCheck)||0)-(Number(a.st.lastCheck)||0));
 for(const old of owned.slice(2)){
  if((await g()).cartOwner||checking.has(old.p.id))return;
  const current=await ps(old.p);if(current.tabId!==old.tab.id||current.inProgress||current.checkoutOwned||current.checkoutRetryPending||current.approval||current.submissionPending)continue;
  try{const tab=await chrome.tabs.get(old.tab.id);if(!tab||tab.active||tab.pinned||!globalThis.AmazonBuyerLogic.exactUrl(tab.url,current.discoveredAsin||current.customAsin||old.p.asin||''))continue;
   await setp(old.p,{tabId:null});await chrome.tabs.remove(tab.id);
  }catch{}
 }
}
const waitForComplete=(id,ms=15000)=>new Promise(r=>{let done=false;const finish=ok=>{if(done)return;done=true;clearTimeout(to);chrome.tabs.onUpdated.removeListener(fn);r(ok)},fn=(i,x)=>{if(i===id&&x.status==='complete')finish(true)},to=setTimeout(()=>finish(false),ms);chrome.tabs.onUpdated.addListener(fn)});
async function reloadAndWait(id){const w=waitForComplete(id);await chrome.tabs.reload(id);return w}
async function navigateAndWait(id,url){const w=waitForComplete(id);await chrome.tabs.update(id,{url});return w}
async function sendTab(id,message){let last=null;for(let i=0;i<4;i++){try{return await chrome.tabs.sendMessage(id,message)}catch(e){last=e;if(i<3)await new Promise(r=>setTimeout(r,40*(i+1)))}}throw last||new Error('content script unavailable')}
async function senderOwns(p,sender){if(!sender.tab?.id)return false;const s=await ps(p);return s.tabId===sender.tab.id}
async function refreshIntelligenceScores({wake=false}={}){
 if((await g()).cartOwner)return;
 try{
  const [events,model,items]=await Promise.all([RI.getEvents(),RI.getModel(),catalog()]);let best=null;
  for(const p of items){const st=await ps(p),rp=runtimeProduct(p,st),asin=rp.asin||st.discoveredAsin||st.customAsin;if(!asin)continue;const q=RI.scoreFrom(model,events,{asin,set:p.set,now:Date.now()}),pred=q.predicted||{};await setp(p,{restockScore:q.score,intelligenceTier:q.tier,predictedRestockLow:pred.low||null,predictedRestockCenter:pred.center||null,predictedRestockHigh:pred.high||null,predictionConfidence:Number.isFinite(Number(pred.confidence))?Number(pred.confidence):null,intelligenceReasons:q.reasons||[],priority:q.tier==='IMMINENT'?'IMMINENT':q.tier==='HOT'?'HOT':Number(st.setHeatUntil)>Date.now()?'HOT':historicalBoost(st)?'WARM':'NORMAL'});if(st.monitor&&Number.isFinite(st.cap)&&st.cap>0&&!st.purchased&&!st.attempted&&(q.tier==='IMMINENT'||q.tier==='HOT')&&(!best||q.score>best.score))best={p,score:q.score}}
  if(wake&&best){const st=await ps(best.p);await setp(best.p,{nextCheckAt:Date.now()});immediateCheck(best.p)}
 }catch(e){void diag('intelligence_error',{reason:String(e?.message||e)})}
}

let sensorSocket=null,sensorSocketUrl='',sensorReconnectTimer=null,sensorBackoffMs=1000;
function closeSensorStream(){try{sensorSocket?.close()}catch{}sensorSocket=null;sensorSocketUrl='';if(sensorReconnectTimer){clearTimeout(sensorReconnectTimer);sensorReconnectTimer=null}}
async function syncSensorStream(){
 try{
  const c=await RI.getConfig(),url=String(c.publicStreamUrl||'').trim();
  if(!c.enabled||!c.publicStreamEnabled||!/^wss:\/\//i.test(url)){closeSensorStream();return}
  if(sensorSocket&&sensorSocketUrl===url&&(sensorSocket.readyState===0||sensorSocket.readyState===1))return;
  closeSensorStream();sensorSocketUrl=url;
  const ws=new WebSocket(url);sensorSocket=ws;
  ws.onopen=()=>{sensorBackoffMs=1000;void diag('sensor_stream_open',{url:new URL(url).origin})};
  ws.onmessage=async ev=>{try{if((await g()).cartOwner)return;const recv=Date.now(),payload=JSON.parse(String(ev.data||'')),arr=Array.isArray(payload)?payload:Array.isArray(payload?.events)?payload.events:[payload],firstTs=Number(arr[0]?.ts||arr[0]?.timestamp),lag=Number.isFinite(firstTs)?Math.max(0,recv-(firstTs>1e12?firstTs:firstTs*1000)):null;const r=await RI.ingestFeedPayload(payload,'public_stream');if(r.added){void diag('sensor_stream_event',{events:r.added,receiveLagMs:lag});await refreshIntelligenceScores({wake:true})}}catch(e){void diag('sensor_stream_parse_error',{reason:String(e?.message||e)})}};
  ws.onerror=()=>void diag('sensor_stream_error',{});
  ws.onclose=()=>{if(sensorSocket===ws)sensorSocket=null;const delay=Math.min(30000,sensorBackoffMs);sensorBackoffMs=Math.min(30000,sensorBackoffMs*2);sensorReconnectTimer=setTimeout(()=>void syncSensorStream(),delay)};
 }catch(e){void diag('sensor_stream_setup_error',{reason:String(e?.message||e)})}
}
let lastIntelligenceRecompute=0;
async function pollIntelligenceSensors(){
 if((await g()).cartOwner)return;
 try{
  await syncSensorStream();
  const items=[];for(const p of await catalog()){const st=await ps(p),rp=runtimeProduct(p,st),asin=rp.asin||st.discoveredAsin||st.customAsin;if(st.monitor&&asin)items.push({asin,set:p.set,score:Number(st.restockScore)||0})}items.sort((a,b)=>b.score-a.score);
  let changed=false;try{const r=await RI.pollKeepa(items);if(r&&!r.skipped&&r.events){changed=true;void diag('sensor_keepa',{events:r.events,tokensLeft:r.tokensLeft})}}catch(e){void diag('sensor_keepa_error',{reason:String(e?.message||e)})}
  try{const r=await RI.pollPublicFeed();if(r&&!r.skipped&&r.added){changed=true;void diag('sensor_public_feed',{events:r.added})}}catch(e){void diag('sensor_public_feed_error',{reason:String(e?.message||e)})}
  if(changed||Date.now()-lastIntelligenceRecompute>300000){await refreshIntelligenceScores({wake:changed});lastIntelligenceRecompute=Date.now()}
 }catch(e){void diag('intelligence_poll_error',{reason:String(e?.message||e)})}
}
async function retryOwnsCheck(p){
 const x=await g();if(!x.cartOwner)return true;if(x.cartOwner!==p.id)return false;
 const st=await ps(p);return !!st.checkoutRetryPending&&!st.inProgress&&!st.submissionPending&&!st.attempted&&!st.approval;
}
async function check(p,{force=false}={}){
 await ensureInit();
 // Any active checkout owns the entire account. Even FORCE cannot reload its tab.
 if(!await retryOwnsCheck(p))return false;
 if(checking.has(p.id))return false;checking.add(p.id);
 try{
  const __checkStart=Date.now();const x=await g(),s=await ps(p);void diag('check_start',{productId:p.id,asin:p.asin||s.customAsin||s.discoveredAsin,scheduledAt:Number(s.nextCheckAt)||null,startedAt:__checkStart,schedulerDelayMs:Number(s.nextCheckAt)?Math.max(0,__checkStart-Number(s.nextCheckAt)):null,force:!!force});
  if(!await retryOwnsCheck(p))return false;
  if(s.checkoutOwned||s.inProgress||s.submissionPending||s.approval||s.queued)return false;
  if((!force&&!x.monitoring)||!s.enabled||(!force&&!s.monitor)||!Number.isFinite(s.cap)||s.cap<=0||s.purchased||s.attempted)return false;
  if(!force)await setp(p,{nextCheckAt:Date.now()+monitoringDelay(s)});
  const permit=await trafficPermit({force});if(!permit.ok){void diag('check_governor_wait',{productId:p.id,asin:p.asin||s.customAsin||s.discoveredAsin,reason:permit.reason,waitMs:Number(permit.wait)||0});if(Number.isFinite(permit.wait))await setp(p,{nextCheckAt:Date.now()+permit.wait,...(s.checkoutRetryPending?{checkoutRetryDueAt:Date.now()+Math.max(200,permit.wait)}:{})});return false}
  // Guard again after asynchronous traffic admission, BEFORE tab reuse and navigation.
  if(!await retryOwnsCheck(p))return false;
  const t=await tab(p,false);if(!t?.id)return false;
  // Avoid reloading again before this retry's content-script price observation arrives.
  if(s.checkoutRetryPending)await setp(p,{checkoutRetryDueAt:Date.now()+10000,nextCheckAt:Date.now()+10000});
  if(!await retryOwnsCheck(p))return false;
  const latest=await ps(p),rp=runtimeProduct(p,latest),asin=latest.discoveredAsin||rp.asin||'',url=latest.discoveredUrl||rp.url||rp.search;
  let live=await chrome.tabs.get(t.id);if(!await retryOwnsCheck(p))return false;
  if(asin&&!globalThis.AmazonBuyerLogic.exactUrl(live.url,asin)){if(!await navigateAndWait(t.id,url))throw new Error('product navigation timeout')}else if(!await reloadAndWait(t.id))throw new Error('page load timeout');
  live=await chrome.tabs.get(t.id);if(asin&&!globalThis.AmazonBuyerLogic.exactUrl(live.url,asin))throw new Error('wrong product URL after navigation');void diag('check_page_ready',{productId:p.id,asin,readyAt:Date.now(),startedAt:__checkStart,loadMs:Date.now()-__checkStart});
  const now=await ps(p),current=runtimeProduct(p,now);const r=await sendTab(t.id,{type:asin?'CHECK_PRODUCT':'DISCOVER_PRODUCT',product:{...current,asin,url,cap:now.cap,monitor:now.monitor,autoBuy:now.autoBuy}});if(!r?.ok)throw new Error('content check did not acknowledge');return true;
 }catch(e){
   const s=await ps(p),msg=String(e?.message||'Amazon tab/content unavailable'),challenge=/captcha|challenge|unusual|verify|blocked|throttl/i.test(msg),timeout=/timeout/i.test(msg);
   const errs=(s.consecutiveErrors||0)+1;
   let backoff=challenge?await noteThrottle(msg):timeout?Math.min(180000,20000*errs):Math.min(120000,15000*errs);
   await setp(p,{status:(challenge?'COOLDOWN — ':'ERROR — ')+msg,lastCheck:Date.now(),checks:(s.checks||0)+1,consecutiveErrors:errs,nextCheckAt:Date.now()+backoff,...(s.checkoutRetryPending?{checkoutRetryDueAt:Date.now()+backoff}:{})});
   return false
 }
 finally{checking.delete(p.id)}
}
async function runChecks(items,concurrency=2,force=false){
 if((await g()).cartOwner)return;
 let i=0;
 const worker=async()=>{while(i<items.length){const n=i++;await check(items[n],{force})}};
 await Promise.all(Array.from({length:Math.min(concurrency,items.length||1)},worker))
}
const SET_HEAT_MS=180000;
async function heatSet(setName,sourceId){if((await g()).cartOwner)return;const until=Date.now()+SET_HEAT_MS;for(const q of await catalog()){if(q.set!==setName||q.id===sourceId)continue;const st=await ps(q);if(st.enabled&&st.monitor&&Number.isFinite(st.cap)&&st.cap>0&&!st.purchased)await setp(q,{setHeatUntil:until,priority:'HOT',nextCheckAt:Math.min(Number(st.nextCheckAt)||until,Date.now()+REQUEST_MIN_GAP_MS)})}}
let monitoredTargetCount=1;
function monitoringDelay(st){
 // Buyer keeps low-rate direct Amazon coverage. Detector is primary, not sole source.
 // In disconnected mode cap to <=6 routine page checks/min across ALL monitored ASINs;
 // with an acknowledged detector catalog cap to <=2/min. Checkout retries bypass this.
 const synced=buyerDetectorBridge.active(),floor=synced?600000:180000;
 const spread=Math.ceil(Math.max(1,monitoredTargetCount)*60000/(synced?2:6));
 return Math.max(floor,spread);
}
function availabilityClass(status){const z=String(status||'').toUpperCase();if(z.startsWith('ELIGIBLE'))return 'ELIGIBLE';if(z.startsWith('OVER CAP'))return 'AVAILABLE_OVER_CAP';if(z.includes('THROTTL')||z.includes('COOLDOWN'))return 'THROTTLED';if(z.includes('OUT OF STOCK')||z.includes('UNAVAILABLE')||z.startsWith('WAITING'))return 'UNAVAILABLE';if(z.startsWith('ERROR')||z.startsWith('BLOCKED'))return 'ERROR';return 'UNKNOWN'}
function historicalBoost(st,now=Date.now()){const h=(Array.isArray(st.stockHistory)?st.stockHistory:[]).filter(x=>x&&(x.state==='ELIGIBLE'||x.state==='AVAILABLE_OVER_CAP')).slice(-30);if(h.length<3)return false;const d=new Date(now),minute=d.getHours()*60+d.getMinutes();let near=0,days=new Set();for(const x of h){const t=new Date(Number(x.at));if(!Number.isFinite(t.getTime()))continue;const m=t.getHours()*60+t.getMinutes(),diff=Math.min(Math.abs(m-minute),1440-Math.abs(m-minute));if(diff<=20){near++;days.add(t.toDateString())}}return near>=2&&days.size>=2}
async function syncHotLoops(){return true} // v3.18: intentionally one global scheduler; legacy per-tab hot loops removed.
async function dueProducts(){
 const now=Date.now(),active=[];let count=0;
 for(const p of await catalog()){
   const st=await ps(p);
   if(!st.enabled||!st.monitor||!Number.isFinite(st.cap)||st.cap<=0||st.purchased||st.attempted||st.inProgress||st.submissionPending||st.queued)continue;
   count++;
   if((st.nextCheckAt||0)>now)continue;
   const hot=Number(st.setHeatUntil)>now?1:0,warm=historicalBoost(st,now)?1:0,auto=st.autoBuy?1:0,intel=Math.max(0,Math.min(.99,Number(st.restockScore)||0)),stale=Math.max(0,now-Number(st.lastCheck||0));
   active.push({p,st,score:intel*2e12+hot*1e12+warm*5e11+auto*1e11+stale});
 }
 monitoredTargetCount=Math.max(1,count);
 active.sort((a,b)=>b.score-a.score||(a.st.nextCheckAt||0)-(b.st.nextCheckAt||0));
 return active;
}
async function normalDueProducts(){return (await dueProducts()).filter(x=>!x.st.autoBuy)}
let lastNormalTick=0;
async function tick(){
 if(tickRunning)return;
 const __resourceTickStart=performance.now();
 const now=Date.now();
 if(!globalCache?.cartOwner&&now-lastNormalTick<3000)return;
 tickRunning=true;
 try{
   await clearCooldownIfHealthy();const x=await g();if(!x.monitoring||x.emergencyStop)return;
   if(!x.cartOwner&&globalThis.RestalkerShops?.running?.())return; // Restalker v75: while a store checkout runs, the Amazon page checks wait (CPU, and fewer page loads that look like a bot)
   if(!x.cartOwner){if(Date.now()-lastNormalTick<3000)return;lastNormalTick=Date.now()}
   if(x.cartOwner){
     const owner=await productById(x.cartOwner),st=owner?await ps(owner):null;
     if(st?.checkoutRetryPending){
       const start=Number(st.campaignStartedAt)||Number(x.cartOwnerSince)||Date.now();
       if(Date.now()-start>=CHECKOUT_CAMPAIGN_MS){await finishRetryCampaign(owner,'RETRY WINDOW EXPIRED — MANUAL RE-ARM REQUIRED');return}
       if((Number(st.checkoutRetryDueAt)||0)<=Date.now())await check(owner,{force:true});
     }
     return;
   }
   await setg({lastHeartbeat:Date.now(),tickCount:(x.tickCount||0)+1});
   const due=await dueProducts();
   if(due.length)await check(due[0].p,{force:false});
   await trimWarmMonitorTabs();
   await badge();
 }finally{tickRunning=false;buyerResources.noteTick(performance.now()-__resourceTickStart)}
}
let fastLoop=null;
function startFastLoop(){
 if(fastLoop)return;
 fastLoop=setInterval(()=>void (ready||ensureInit().then(ensureSessionReady)).then(()=>tick()),500);
 if(fastLoop&&typeof fastLoop.unref==='function')fastLoop.unref();
}
let intelligenceLoop=null;
function startIntelligenceLoop(){
 if(intelligenceLoop)return;
 intelligenceLoop=setInterval(()=>void pollIntelligenceSensors(),60000);
 if(intelligenceLoop&&typeof intelligenceLoop.unref==='function')intelligenceLoop.unref();
}

let cartSlotLock=Promise.resolve();
async function acquireCartSlot(p){
 const run=cartSlotLock.catch(()=>{}).then(async()=>{
   const x=await g();
   if(x.cartOwner&&x.cartOwner!==p.id){
     const owner=await productById(x.cartOwner),st=owner?await ps(owner):null;
     const stale=!owner||!st||(!st.inProgress&&!st.submissionPending&&!st.approval&&!st.checkoutRetryPending)||Date.now()-(x.cartOwnerSince||0)>10*60*1000;
     if(!stale)return false;
   }
   await setg({cartOwner:p.id,cartOwnerSince:Date.now()});
   return true;
 });
 cartSlotLock=run.then(()=>{},()=>{});return run
}
async function queueEligible(p,price,hitAt){
 const s=await ps(p),at=Number.isFinite(Number(s.hitDetectedAt))?Number(s.hitDetectedAt):(Number.isFinite(Number(hitAt))?Number(hitAt):Date.now());
 await setp(p,{queued:true,queuedPrice:Number.isFinite(Number(price))?Number(price):null,queuedAt:at,hitDetectedAt:at,status:'ELIGIBLE — CHECKOUT QUEUED',nextCheckAt:Number.MAX_SAFE_INTEGER});
}
let queuePromoting=false;
async function promoteQueued(){
 if(queuePromoting)return;queuePromoting=true;
 try{
   const x=await g();if(x.cartOwner)return;
   const candidates=[];
   for(const p of await catalog()){const s=await ps(p);if(s.queued&&s.armed&&s.monitor&&s.autoBuy&&!s.purchased&&!s.attempted&&!s.inProgress&&!s.submissionPending&&Number.isFinite(s.cap)&&s.cap>0&&Number.isInteger(s.tabId))candidates.push({p,s})}
   candidates.sort((a,b)=>(a.s.queuedAt||a.s.hitDetectedAt||0)-(b.s.queuedAt||b.s.hitDetectedAt||0));
   const q=candidates[0];if(!q)return;
   let rv=null;try{rv=await sendTab(q.s.tabId,{type:'REVALIDATE_QUEUED',product:runtimeProduct(q.p,q.s)})}catch{}
   if(!rv?.ok||!rv.eligible){
     await setp(q.p,{queued:false,queuedPrice:null,queuedAt:null,hitDetectedAt:null,status:rv?.reason?'WAITING — queued hit expired: '+rv.reason:'WAITING — queued hit expired',nextCheckAt:Date.now()+REQUEST_MIN_GAP_MS});
     defer(()=>void promoteQueued());return;
   }
   const freshPrice=Number.isFinite(Number(rv.price))?Number(rv.price):q.s.queuedPrice;
   if(Number.isFinite(Number(freshPrice))&&Number(freshPrice)>Number(q.s.cap)+.001){
     await setp(q.p,{queued:false,queuedPrice:null,queuedAt:null,hitDetectedAt:null,status:'OVER CAP — queued hit revalidated at $'+Number(freshPrice).toFixed(2),price:Number(freshPrice),nextCheckAt:Date.now()+monitoringDelay(q.s)});
     defer(()=>void promoteQueued());return;
   }
   if(!await acquireCartSlot(q.p))return;
   await setp(q.p,{queued:false,queuedPrice:null,queuedAt:null,inProgress:true,checkoutOwned:true,campaignAttempts:(Number(q.s.campaignAttempts)||0)+1,campaignLastAttemptStartedAt:Date.now(),status:'CHECKOUT — STARTING QUEUED HIT'});
   try{const r=await sendTab(q.s.tabId,{type:'BEGIN_PURCHASE',product:runtimeProduct(q.p,q.s),listingPrice:freshPrice,hitDetectedAt:q.s.hitDetectedAt||q.s.queuedAt});if(!r?.ok)throw new Error(r?.reason||'queued purchase start not acknowledged')}
   catch(e){await blockPurchase(q.p,'BLOCKED — queued purchase could not resume: '+String(e?.message||e),q.s.tabId,{autoRearm:true})}
 }finally{queuePromoting=false}
}
async function releaseCartSlot(productId,{promote=true}={}){
 const x=await g();if(x.cartOwner===productId)await setg({cartOwner:null,cartOwnerSince:null});
 if(promote)defer(()=>void promoteQueued());
}
async function immediateCheck(p){defer(()=>void check(p,{force:true}))}
async function finishTiming(p,outcome,{terminal=false}={}){const s=await ps(p),attemptStart=Number(s.campaignLastAttemptStartedAt||s.hitDetectedAt),campaignStart=Number(s.campaignStartedAt||s.hitDetectedAt);if(!Number.isFinite(campaignStart))return null;const now=Date.now(),attemptMs=Number.isFinite(attemptStart)?Math.max(0,now-attemptStart):null,campaignMs=Math.max(0,now-campaignStart),history=Array.isArray(s.timingHistory)?s.timingHistory.slice(-99):[];history.push({at:now,attemptMs,campaignMs,outcome,attempt:Number(s.campaignAttempts)||1});await setp(p,{lastAttemptMs:attemptMs,lastCampaignMs:campaignMs,lastAttemptOutcome:outcome,timingHistory:history,hitDetectedAt:null,campaignLastAttemptStartedAt:null,...(terminal?{campaignStartedAt:null,campaignAttempts:0}:{})});return campaignMs}
// A campaign owns the account across rapid retries; only the target listing can refresh.
// Terminal outcomes revoke purchase authority, release the global slot, and resume others.
async function finishRetryCampaign(p,status,{uncertain=false}={}){
 const s=await ps(p);
 await finishTiming(p,uncertain?'UNCERTAIN':'FAILED',{terminal:true});
 await setp(p,{inProgress:false,submissionPending:false,checkoutOwned:false,checkoutRetryPending:false,checkoutRetryDueAt:0,
  queued:false,queuedPrice:null,queuedAt:null,approval:null,armed:false,autoBuy:false,monitor:false,nextCheckAt:0,
  attempted:uncertain||!!s.attempted,status});
 await releaseCartSlot(p.id);await syncHotLoops();await badge();
 void diag('checkout_campaign_terminal',{productId:p.id,reason:status,attempts:s.campaignAttempts||0,uncertain});
}
function withinCheckoutRetryLimit(s,now=Date.now()){
 const start=Number(s.campaignStartedAt)||Number(s.campaignLastAttemptStartedAt)||now;
 return (Number(s.campaignAttempts)||0)<CHECKOUT_MAX_ATTEMPTS && now-start<CHECKOUT_CAMPAIGN_MS;
}
async function scheduleExclusiveCheckoutRetry(p,s,status){
 const x=await g(),safe=!x.emergencyStop&&x.monitoring&&x.liveGlobal&&s.monitor&&s.autoBuy&&s.armed&&!s.purchased&&!s.submissionPending;
 if(!safe||!withinCheckoutRetryLimit(s))return false;
 // The owner slot is retained until success, final failure, or uncertain outcome.
 const held=x.cartOwner===p.id||await acquireCartSlot(p);if(!held)return false;
 const due=Date.now()+Math.max(REQUEST_MIN_GAP_MS,2000);
 await setp(p,{inProgress:false,submissionPending:false,checkoutOwned:false,checkoutRetryPending:true,checkoutRetryDueAt:due,
   queued:false,queuedPrice:null,queuedAt:null,approval:null,attempted:false,armed:true,autoBuy:true,monitor:true,nextCheckAt:due,
   status:status+' — EXCLUSIVE RETRY '+(Number(s.campaignAttempts)+1)+'/'+CHECKOUT_MAX_ATTEMPTS});
 void diag('checkout_exclusive_retry_scheduled',{productId:p.id,attemptsCompleted:s.campaignAttempts,nextAttempt:Number(s.campaignAttempts)+1,dueAt:due});
 await badge();return true;
}
async function blockPurchase(p,status,tabId,{autoRearm=false,manualRecovery=false}={}){
 const s=await ps(p);
 if(s.submissionPending||s.attempted){await setp(p,{status:'ORDER OUTCOME UNCERTAIN — CHECK AMAZON; automatic recovery prohibited'});return}
 if(!s.inProgress&&!s.checkoutOwned&&!s.approval){void diag('checkout_stale_failure_ignored',{productId:p.id,reason:status});return}
 if(tabId)await clearFlowForTab(tabId);
 const actionRequired=status.startsWith('ACTION REQUIRED');
 const canRetry=!manualRecovery&&!actionRequired&&!!autoRearm&&withinCheckoutRetryLimit(s);
 if(canRetry&&await scheduleExclusiveCheckoutRetry(p,{...s},status)){await finishTiming(p,'FAILED');return;}
 await finishRetryCampaign(p,status+' — TERMINAL; MANUAL RE-ARM REQUIRED');
}
async function recoverBrowserStartup(){
 const all=await chrome.storage.local.get(null),flows=Object.keys(all).filter(x=>x.startsWith('flow:'));if(flows.length)await chrome.storage.local.remove(flows);
 for(const p of await catalog()){const st=await ps(p),v={tabId:null,approval:null,checkoutOwned:false,checkoutRetryPending:false,checkoutRetryDueAt:0,armed:false,autoBuy:false,monitor:false,nextCheckAt:0};if(st.submissionPending||st.attempted&&!st.purchased){Object.assign(v,{inProgress:false,submissionPending:false,armed:false,autoBuy:false,status:'ORDER STATE UNCERTAIN AFTER BROWSER RESTART — CHECK AMAZON'})}else if(st.inProgress){Object.assign(v,{inProgress:false,armed:false,autoBuy:false,status:'PURCHASE INTERRUPTED — RE-ARM REQUIRED'})}await setp(p,v)}
 await setg({monitoring:false,liveGlobal:false,cartOwner:null,cartOwnerSince:null});await badge();
}
async function ensureSessionReady(){const s=await chrome.storage.session.get('startupRecovered');if(s.startupRecovered)return;await recoverBrowserStartup();await chrome.storage.session.set({startupRecovered:true})}
chrome.tabs.onRemoved.addListener(id=>void(async()=>{
 await clearFlowForTab(id);
 for(const p of await catalog()){
   const st=await ps(p);if(st.tabId!==id&&st.approval?.tabId!==id)continue;
   const wasOwner=(await g()).cartOwner===p.id;
   const v={tabId:st.tabId===id?null:st.tabId,approval:null,checkoutOwned:false,checkoutRetryPending:false,checkoutRetryDueAt:0};
   if(st.submissionPending||st.attempted&&!st.purchased)Object.assign(v,{inProgress:false,submissionPending:false,armed:false,autoBuy:false,monitor:false,nextCheckAt:0,status:'ORDER STATE UNCERTAIN AFTER TAB CLOSED — CHECK AMAZON'});
   else if(st.inProgress||st.checkoutRetryPending||wasOwner)Object.assign(v,{inProgress:false,armed:false,autoBuy:false,monitor:false,nextCheckAt:0,status:'PURCHASE INTERRUPTED BY CLOSED TAB — MANUAL RE-ARM REQUIRED'});
   await setp(p,v);
   if(wasOwner){await finishTiming(p,'TAB_CLOSED',{terminal:true});await releaseCartSlot(p.id);void diag('checkout_owner_tab_closed',{productId:p.id,tabId:id})}
 }
 await badge();
})());
chrome.alarms.onAlarm.addListener(a=>{if(a.name==='resource_sample_v3238')void buyerResources.capture({catalog,ps,g});if(a.name==='tick')void (ready||ensureInit().then(ensureSessionReady)).then(()=>tick());if(a.name==='intelligence')void (ready||ensureInit().then(ensureSessionReady)).then(()=>pollIntelligenceSensors())});chrome.runtime.onInstalled.addListener(()=>{ready=ensureInit().then(ensureSessionReady)});chrome.runtime.onStartup.addListener(()=>{ready=ensureInit().then(ensureSessionReady);void ready.then(()=>{startFastLoop();startIntelligenceLoop();void syncSensorStream();tick()})});
if(globalThis.__AMZ_ENABLE_TEST_HOOKS__)globalThis.__AMZ_BACKGROUND_TEST_HOOKS__={check,ps,setp,g,setg,acquireCartSlot,releaseCartSlot,blockPurchase,normalDueProducts,refreshIntelligenceScores,pollIntelligenceSensors,syncSensorStream};
chrome.runtime.onMessage.addListener(globalThis.__RK_HANDLE=(m,sender,respond)=>{(async()=>{
 if(ready)await ready;
 let p=m.productId?await productById(m.productId):null;if(!p&&m.type==='SET_CUSTOM_ASIN')p=(await catalog()).find(x=>x.customProduct)||null;
 // v88: Restalker's other buying browsers buy at Amazon too, with this same checkout (amz_part.js): they ask for the product's checks, and
 // tell when THEY placed the order (then this browser never presses for it again - one per product). Answered even while a checkout runs.
 if(m.type==='RK_RUNTIME_PRODUCT'){if(!p)return respond({ok:false,reason:'unknown product'});const s=await ps(p);return respond({ok:true,product:{...runtimeProduct(p,s),cap:Number(s.cap),customProduct:!!p.customProduct}})}
 if(m.type==='RK_AMZ_EXTRA_STATE'){if(!p)return respond({ok:false,reason:'unknown product'});const by=String(m.browser||'another browser').slice(0,40);
   try{globalThis.RestalkerShops?.markOrdered?.(String(m.group||''),'Amazon ('+by+')',m.state==='bought'?0:900000,p.id)}catch{}
   // v94 (review): another browser's Amazon order whose result could not be read is UNCLEAR here too - frozen (never bought again by
   // guessing) until its order check or you decide; before, only a 15-minute note kept the others off it, and it was armed again after
   if(m.state==='unclear'){const cur=await ps(p);if(!cur.purchased)await setp(p,{attempted:true,purchased:false,submissionPending:false,inProgress:false,armed:false,autoBuy:false,submitAt:Date.now(),price:Number.isFinite(Number(m.price))?Number(m.price):null,status:'ORDER MAY HAVE BEEN SUBMITTED — CHECK AMAZON (placed by '+by+')'});await badge();}
   if(m.state==='bought'){await setp(p,{purchased:true,attempted:true,orderNumber:m.orderNumber?String(m.orderNumber).slice(0,40):null,price:Number.isFinite(Number(m.price))?Number(m.price):null,submitAt:Date.now(),status:'PURCHASE SUCCESS — placed by '+by+(m.orderNumber?' — order '+String(m.orderNumber).slice(0,40):'')});await badge();}
   return respond({ok:true})}
 const activeLock=(await g()).cartOwner;
 if(activeLock&&!new Set(['GET_ALL','EXPORT_DIAGNOSTICS','FLOW_GET','FLOW_SAVE','FLOW_CLEAR','FLOW_BLOCKED','ACTION_REQUIRED','SHIPPING_APPROVAL_REQUIRED','APPROVE_SHIPPING','CANCEL_SHIPPING','SUBMITTING','DEFINITE_SUBMISSION_FAILURE','PURCHASE_SUCCESS','SUBMISSION_UNCLEAR','CHECKOUT_PRICE_EVIDENCE','EMERGENCY_STOP','TEST_DISARM_PRODUCT']).has(m.type)){
  if(m.type==='STATUS'&&p?.id===activeLock&&(await ps(p)).checkoutRetryPending){/* owner-only fresh retry observation */}
  else if(m.type==='STATUS'||m.type==='DETECTION_WAKE')return respond({ok:true,paused:true});
  else{
  void diag('checkout_locked_request',{productId:p?.id||null,owner:activeLock,requestType:m.type});
  return respond({ok:false,reason:'CHECKOUT LOCK: all refreshes, metadata edits and other processes paused until checkout resolves'});}
 }
 // v3.23.3: narrowly scoped UI authority repair; checkout flow and locked-cart handling are unchanged.
 // The special test product must always pass through the already field-tested TEST_ARM_PRODUCT handler.
 if((m.type==='ARM_PRODUCT'||m.type==='REARM')&&p&&(await ps(p)).testOnly){
   m={...m,type:'TEST_ARM_PRODUCT'};
 }
 if(m.type==='ARM_CATEGORY'){
   const group=String(m.set||''),members=(await catalog()).filter(q=>q.set===group);
   if(!members.length)return respond({ok:false,reason:'Unknown category'});
   const candidates=[];let skipped=0;
   for(const q of members){const st=await ps(q),asin=String(st.customAsin||q.asin||'').toUpperCase();
     if(!st.enabled||!validCapState(st)||!/^B[A-Z0-9]{9}$/.test(asin)||st.attempted||st.purchased||st.inProgress||st.submissionPending||st.checkoutOwned||st.approval){skipped++;continue}
     if(st.testOnly){if(!Array.isArray(st.customTokens)||st.customTokens.length<2||!Number(st.customMetadataVerifiedAt)){skipped++;continue}candidates.push({q,st,test:true});continue}
     candidates.push({q,st,test:false});
   }
   if(!candidates.length)return respond({ok:false,reason:'No eligible unpurchased products in category',skipped});
   const testOnly=candidates.filter(c=>c.test),normal=candidates.filter(c=>!c.test);
   if(testOnly.length===1&&!normal.length){
     // A test-only checkout must remain single-product; use the original validated test authorization.
     m={...m,type:'TEST_ARM_PRODUCT',productId:testOnly[0].q.id};p=testOnly[0].q;
   }else if(normal.length){
     // In mixed custom categories, keep test-only items disarmed unless individually authorized.
     skipped+=testOnly.length;
     const now=Date.now();
     for(let i=0;i<normal.length;i++){const {q}=normal[i];await setp(q,{monitor:true,armed:true,autoBuy:true,nextCheckAt:now+1500*i,status:'ARMED BY CATEGORY — AUTO BUY ON'});}
     await setg({monitoring:true,liveGlobal:true,emergencyStop:false});await syncHotLoops();await badge();
     immediateCheck(normal[0].q);
     void diag('category_manual_arm',{set:group,changed:normal.length,skipped});
     return respond({ok:true,changed:normal.length,skipped,enabled:true});
   }else{return respond({ok:false,reason:'Only one test checkout can be armed at a time. Use the Test Product panel.'});}
 }
 if(m.type==='DISARM_CATEGORY'){
   const group=String(m.set||''),members=(await catalog()).filter(q=>q.set===group);
   if(!members.length)return respond({ok:false,reason:'Unknown category'});
   let changed=0,skipped=0;
   for(const q of members){const st=await ps(q);
     if(st.inProgress||st.submissionPending||st.checkoutOwned||st.approval||st.attempted&&!st.purchased){skipped++;continue}
     if(st.monitor||st.armed||st.autoBuy||st.queued){await setp(q,{monitor:false,armed:false,autoBuy:false,queued:false,queuedPrice:null,queuedAt:null,nextCheckAt:0,status:st.purchased?st.status:'CATEGORY DISARMED'});changed++}
   }
   const others=await Promise.all((await catalog()).map(q=>ps(q)));
   if(!others.some(st=>st.autoBuy&&st.armed))await setg({liveGlobal:false});
   if(!others.some(st=>st.monitor))await setg({monitoring:false});
   await syncHotLoops();await badge();void diag('category_manual_disarm',{set:group,changed,skipped});
   return respond({ok:true,changed,skipped,enabled:false});
 }
 if(m.type==='DISARM_PRODUCT'&&p){
   const st=await ps(p);
   if(st.inProgress||st.submissionPending||st.checkoutOwned||st.approval||st.attempted&&!st.purchased)return respond({ok:false,reason:'Cannot disarm during active or unresolved checkout; use Emergency Stop if necessary'});
   await setp(p,{armed:false,autoBuy:false,monitor:!!m.keepMonitoring&&!!st.monitor,nextCheckAt:m.keepMonitoring?Date.now()+monitoringDelay(st):0,queued:false,queuedPrice:null,queuedAt:null,status:st.purchased?st.status:'PRODUCT DISARMED'});
   const others=await Promise.all((await catalog()).map(q=>ps(q)));
   if(!others.some(t=>t.autoBuy&&t.armed))await setg({liveGlobal:false});
   if(!others.some(t=>t.monitor))await setg({monitoring:false});
   await syncHotLoops();await badge();return respond({ok:true});
 }
 // A successful prior purchase may be authorized AGAIN only by an explicit dashboard action.
 // Do not weaken ARM_PRODUCT, ARM_CATEGORY or REARM_ALL one-per-SKU safety guards.
 if(m.type==='REARM_PURCHASED'&&p){
   // A dashboard opened through chrome.tabs.create has sender.tab; this is NOT an Amazon content script.
   // Authenticate the extension's own dashboard document, not absence of a tab.
   const dashUrl=chrome.runtime.getURL('dashboard.html');
   if(sender?.id!==chrome.runtime.id||sender?.url!==dashUrl||
       (sender?.tab?.url&&sender.tab.url!==dashUrl))
     return respond({ok:false,reason:'Buy Again requires an explicit dashboard action'});
   const st=await ps(p),asin=String(st.customAsin||p.asin||'').toUpperCase(),expectedAsin=String(m.expectedAsin||'').toUpperCase();
   if(!st.purchased)return respond({ok:false,reason:'No confirmed prior purchase to re-authorize'});   // v91: (an order placed by another buying browser has no 'attempted' here)
   if(!st.enabled||!validCapState(st)||!/^B[A-Z0-9]{9}$/.test(asin)||expectedAsin!==asin)return respond({ok:false,reason:'Exact ASIN or positive saved cap could not be verified'});
   if(p.customProduct&&(!Array.isArray(st.customTokens)||st.customTokens.length<2||!Number(st.customMetadataVerifiedAt)))return respond({ok:false,reason:'Custom ASIN metadata must be verified before Buy Again'});
   if(st.inProgress||st.submissionPending||st.checkoutOwned||st.checkoutRetryPending||st.approval||st.queued)return respond({ok:false,reason:'An order is still active, queued, or unresolved'});
   if(!m.confirmedAdditionalPurchase||Number(m.expectedPriorSubmitAt||0)!==Number(st.submitAt||0))return respond({ok:false,reason:'Prior order changed: reconfirm the additional purchase'});
   const prior={asin,submitAt:st.submitAt||null,orderNumber:st.orderNumber||null,price:Number.isFinite(st.price)?st.price:null,
     status:st.status,lastAttemptMs:st.lastAttemptMs??null,lastCampaignMs:st.lastCampaignMs??null,
     recordedAt:Array.isArray(st.timingHistory)?(st.timingHistory.filter(x=>x.outcome==='SUCCESS').at(-1)?.at||null):null,
     explicitlyRearmedAt:Date.now()};
   const history=Array.isArray(st.priorPurchaseHistory)?st.priorPurchaseHistory:[];
   // Persist previous success and reset ONLY the current authorization/campaign state.
   await setp(p,{priorPurchaseHistory:[...history,prior],purchased:false,attempted:false,
     armed:true,monitor:true,autoBuy:true,nextCheckAt:0,inProgress:false,submissionPending:false,approval:null,
     checkoutOwned:false,checkoutRetryPending:false,checkoutRetryDueAt:0,queued:false,queuedPrice:null,queuedAt:null,
     hitDetectedAt:null,campaignStartedAt:null,campaignAttempts:0,campaignLastAttemptStartedAt:null,
     eligibleAuthorizedAt:null,checkoutPushAt:null,submitAt:null,eligibleToSubmitMs:null,pushToSubmitMs:null,pushToConfirmedMs:null,
     status:'MANUALLY RE-ARMED FOR ONE ADDITIONAL PURCHASE — PRIOR SUCCESS SAVED'});
   await setg({monitoring:true,liveGlobal:true,emergencyStop:false});await syncHotLoops();await badge();
   diag('prior_purchase_manual_rearm',{productId:p.id,asin,priorSubmitAt:prior.submitAt,previousOrderNumber:prior.orderNumber,
     priorConfirmedAt:prior.recordedAt,historyCount:history.length+1});immediateCheck(p);
   return respond({ok:true,productId:p.id,armed:true,priorPurchasePreserved:true});
 }
 if((m.type==='ARM_PRODUCT'||m.type==='REARM')&&p){
   const st=await ps(p),asin=String(st.customAsin||p.asin||'').toUpperCase();
   if(!st.enabled||!validCapState(st)||!/^B[A-Z0-9]{9}$/.test(asin))return respond({ok:false,reason:'Product needs an ASIN and positive maximum item-price cap'});
   if(st.attempted||st.purchased||st.submissionPending||st.inProgress||st.checkoutOwned||st.approval)return respond({ok:false,reason:'Already purchased, attempted or order unresolved. Do not re-purchase automatically'});
   await setp(p,{armed:true,monitor:true,autoBuy:true,nextCheckAt:0,status:'INDIVIDUALLY ARMED — AUTO BUY ON'});
   // The old REARM handler failed to set these two necessary global purchase gates.
   await setg({monitoring:true,liveGlobal:true,emergencyStop:false});await syncHotLoops();await badge();immediateCheck(p);
   void diag('product_manual_arm',{productId:p.id,asin});return respond({ok:true,productId:p.id,armed:true});
 }
 // This dedicated isolated tester is the ONLY live-purchase authority added to the August v3.23 checkout core.
 if(m.type==='TEST_ADD_PRODUCT'){
  const asin=String(m.asin||'').trim().toUpperCase(),cap=m.cap===null||m.cap===undefined||m.cap===''?null:Number(m.cap);
  if(!/^B[A-Z0-9]{9}$/.test(asin))return respond({ok:false,reason:'Enter exactly one valid Amazon ASIN'});
  if(cap!==null&&(!Number.isFinite(cap)||cap<=0))return respond({ok:false,reason:'Product price cap must be positive'});
  if(TEST_REQUESTS.has(asin))return respond(await TEST_REQUESTS.get(asin));
  const operation=testGlobalAddQueue.catch(()=>{}).then(async()=>{
   const x=await g();if(x.cartOwner)return {ok:false,reason:'An order is active; do not change test products'};
   const cat=await catalog();
   for(const q of cat){const st=await ps(q);if(st.inProgress||st.submissionPending||st.attempted&&!st.purchased||st.checkoutOwned||st.approval)return {ok:false,reason:'Resolve active/uncertain order before adding a test product: '+q.id}}
   // Explicitly remove ALL purchase authority BEFORE opening the target page.
   await setg({monitoring:false,liveGlobal:false});
   for(const q of cat){const st=await ps(q);if(st.monitor||st.autoBuy||st.armed)await setp(q,{monitor:false,autoBuy:false,armed:false,nextCheckAt:0,status:st.purchased?st.status:'DISARMED — test preparation'})}
   let target=cat.find(q=>q.customProduct&&String((q.asin||(q.id&&null))||'').toUpperCase()===asin);
   if(!target){for(const q of cat.filter(q=>q.customProduct)){const st=await ps(q);if(String(st.customAsin||'').toUpperCase()===asin){target=q;break}}}
   if(!target){for(const q of cat.filter(q=>q.customProduct)){const st=await ps(q);if(!st.customAsin){target=q;break}}}
   if(!target){const store=await chrome.storage.local.get([CUSTOM_DEFS_KEY,'customProductSeq']),defs=Array.isArray(store[CUSTOM_DEFS_KEY])?store[CUSTOM_DEFS_KEY]:[],seq=Math.max(1,Number(store.customProductSeq)||1)+1,id='custom-asin-product-'+seq;defs.push({id,name:'Custom ASIN Product',asin:'',url:'',search:'',tokens:[],capSource:null});await saveCustomDefs(defs);await chrome.storage.local.set({customProductSeq:seq});target=await productById(id)}
   const st=await ps(target),changed=String(st.customAsin||'').toUpperCase()!==asin;
   const finalCap=cap!==null?cap:(changed?null:Number.isFinite(st.cap)?st.cap:null);
   await setp(target,{customAsin:asin,discoveredAsin:asin,discoveredUrl:'https://www.amazon.com/dp/'+asin,cap:finalCap,customName:changed?'Loading '+asin:st.customName,customTokens:changed?null:st.customTokens,customMetadataVerifiedAt:0,price:null,customCurrentPrice:null,armed:false,autoBuy:false,monitor:false,testOnly:true,attempted:false,purchased:changed?false:st.purchased,inProgress:false,submissionPending:false,approval:null,status:'TEST PRODUCT — opening exact Amazon listing'});
   if((await ps(target)).purchased)return {ok:false,id:target.id,reason:'This ASIN was already purchased; do not automatically rearm it'};
   let tabId=null;
   try{
    const found=await chrome.tabs.query({});const existing=found.find(t=>t.id&&globalThis.AmazonBuyerLogic.exactUrl(t.url||'',asin));
    let t;if(existing){t=await chrome.tabs.update(existing.id,{active:true});await setp(target,{tabId:existing.id})}else{
     t=await tab(target,true);
     if(t?.id)await chrome.tabs.update(t.id,{active:true});
    }
    if(!t?.id)throw Error('Amazon tab unavailable');tabId=t.id;
    const url='https://www.amazon.com/dp/'+asin,live=await chrome.tabs.get(tabId);
    if(!globalThis.AmazonBuyerLogic.exactUrl(live.url||'',asin)){if(!await navigateAndWait(tabId,url))throw Error('Amazon listing navigation timed out')}
    else if(live.status!=='complete'&&!await waitForComplete(tabId))throw Error('Amazon listing did not finish loading');
    const loaded=await chrome.tabs.get(tabId);
    if(!globalThis.AmazonBuyerLogic.exactUrl(loaded.url||'',asin))throw Error('Amazon redirected away from the exact ASIN');
    const rp=runtimeProduct(target,await ps(target)),meta=await sendTab(tabId,{type:'EXTRACT_CUSTOM_META',product:{...rp,asin,url}});
    if(!meta?.ok||!String(meta.name||'').trim()||!Array.isArray(meta.tokens)||meta.tokens.length<2)throw Error(meta?.reason||'Unable to verify ASIN, title, and metadata');
    const observed=Number(meta.price),price=Number.isFinite(observed)&&observed>0?observed:null,now=Date.now();
    await setp(target,{customName:String(meta.name).slice(0,500),customTokens:meta.tokens.slice(0,16),customMsrp:null,customCurrentPrice:price,price,customReferencePrice:Number.isFinite(Number(meta.referencePrice))&&Number(meta.referencePrice)>0?Number(meta.referencePrice):null,customMetadataVerifiedAt:now,lastCheck:now,checks:(Number(st.checks)||0)+1,status:price===null?'VERIFIED ASIN — price unavailable; NOT ARMED':'VERIFIED — Amazon $'+price.toFixed(2)+(finalCap===null?' · set cap':' · max $'+finalCap.toFixed(2))+' · NOT ARMED',nextCheckAt:now+30000,monitor:finalCap!==null});
    await setg({monitoring:finalCap!==null,liveGlobal:false});
    await badge();void diag('test_product_added',{productId:target.id,asin,price,cap:finalCap,tabId});
    return {ok:true,id:target.id,asin,price,cap:finalCap,verified:true,tabId};
   }catch(err){await setp(target,{armed:false,autoBuy:false,monitor:false,status:'TEST VERIFY FAILED — '+String(err?.message||err)});return {ok:false,id:target.id,reason:String(err?.message||err)}}
  });testGlobalAddQueue=operation.then(()=>{},()=>{});TEST_REQUESTS.set(asin,operation);
  try{return respond(await operation)}finally{if(TEST_REQUESTS.get(asin)===operation)TEST_REQUESTS.delete(asin)}
 }
 if(m.type==='TEST_SET_CAP'){
  if(!p?.customProduct)return respond({ok:false,reason:'Select a verified custom test product'});
  const st=await ps(p),cap=Number(m.cap),x=await g();
  if(!st.testOnly||!Array.isArray(st.customTokens)||st.customTokens.length<2||!Number(st.customMetadataVerifiedAt))return respond({ok:false,reason:'Add and verify the exact ASIN first'});
  if(!Number.isFinite(cap)||cap<=0)return respond({ok:false,reason:'Positive item-price cap required'});
  if(x.cartOwner||st.armed||st.autoBuy||st.inProgress||st.submissionPending||st.attempted||st.purchased||st.checkoutOwned)return respond({ok:false,reason:'Disarm product or resolve outstanding order before editing cap'});
  const price=Number(st.price),recent=Number(st.lastCheck)>0&&Date.now()-Number(st.lastCheck)<60000,kind=Number.isFinite(price)&&price>0?(price>cap?'OVER CAP':'WITHIN CAP'):'PRICE UNKNOWN';
  await setp(p,{cap,monitor:true,armed:false,autoBuy:false,nextCheckAt:0,status:kind+' — LAST OBSERVED '+(recent?'recent':'STALE')+' · NOT ARMED'});
  await setg({monitoring:true,liveGlobal:false});await badge();return respond({ok:true,cap,price:Number.isFinite(price)?price:null});
 }
 if(m.type==='TEST_ARM_PRODUCT'){
  if(!p?.customProduct)return respond({ok:false,reason:'Only a custom test ASIN can be armed here'});
  const st=await ps(p),x=await g(),asin=String(st.customAsin||'').toUpperCase(),cap=Number(st.cap);
  if(x.emergencyStop)return respond({ok:false,reason:'Emergency Stop is active; clear it explicitly before arming'});
  if(x.cartOwner||st.inProgress||st.submissionPending||st.attempted||st.purchased||st.checkoutOwned||st.approval)return respond({ok:false,reason:'Order active, purchased or outcome unresolved'});
  if(!st.testOnly||!/^B[A-Z0-9]{9}$/.test(asin)||!Array.isArray(st.customTokens)||st.customTokens.length<2||!(Number(st.customMetadataVerifiedAt)>0)||!Number.isFinite(cap)||cap<=0)return respond({ok:false,reason:'Add, verify, and set a positive price cap before ARM'});
  const t=Number.isInteger(st.tabId)?await chrome.tabs.get(st.tabId).catch(()=>null):null;
  if(!t||!globalThis.AmazonBuyerLogic.exactUrl(t.url||'',asin))return respond({ok:false,reason:'Test listing tab missing or incorrect ASIN; Add & Verify again'});
  for(const q of await catalog()){if(q.id===p.id)continue;const ss=await ps(q);if(ss.inProgress||ss.submissionPending||ss.attempted&&!ss.purchased||ss.checkoutOwned||ss.approval)return respond({ok:false,reason:'Unresolved order on another product'});if(ss.monitor||ss.armed||ss.autoBuy)await setp(q,{monitor:false,armed:false,autoBuy:false,nextCheckAt:0})}
  await setp(p,{monitor:true,armed:true,autoBuy:true,nextCheckAt:0,hitDetectedAt:null,campaignStartedAt:null,status:'TEST ARM AUTHORIZED — refreshing Amazon price before checkout'});
  await setg({monitoring:true,liveGlobal:true});
  void diag('test_product_manual_arm',{productId:p.id,asin,cap});
  defer(async()=>{
    try{
      const cur=await ps(p),tab=Number.isInteger(cur.tabId)?await chrome.tabs.get(cur.tabId).catch(()=>null):null;
      const isRecentlyObserved=Number(cur.lastCheck)>0&&Date.now()-Number(cur.lastCheck)<5000;
      if(isRecentlyObserved&&tab?.status==='complete'&&globalThis.AmazonBuyerLogic.exactUrl(tab.url||'',asin)){
        // This is a fresh DOM re-evaluation, not a cached-price purchase.
        const rp=runtimeProduct(p,cur);
        const ack=await sendTab(tab.id,{type:'CHECK_PRODUCT',product:{...rp,asin,cap:cur.cap,monitor:true,autoBuy:true}});
        if(!ack?.ok)await check(p,{force:true});
      }else await check(p,{force:true});
    }catch(e){void diag('test_product_arm_check_failed',{productId:p.id,asin,reason:String(e?.message||e)})}
  });await badge();return respond({ok:true,id:p.id,asin,cap,refreshStarted:true});
 }
 if(m.type==='TEST_DISARM_PRODUCT'){
  if(!p?.customProduct)return respond({ok:false,reason:'Select a custom test product'});
  const st=await ps(p);if(st.attempted||st.submissionPending)return respond({ok:false,reason:'Submitted order may be pending; cannot clear or rearm until verified'});
  await setg({liveGlobal:false});if(st.inProgress||st.checkoutOwned||st.approval){await clearFlowForTab(st.tabId);await releaseCartSlot(p.id,{promote:false})}
  await setp(p,{armed:false,autoBuy:false,monitor:Number.isFinite(st.cap)&&st.cap>0,testOnly:true,status:'TEST DISARMED — price monitoring only',nextCheckAt:Date.now()+30000,inProgress:false,checkoutOwned:false,approval:null});
  await badge();return respond({ok:true});
 }
 if(m.type==='TEST_REFRESH_PRODUCT'){
  if(!p?.customProduct)return respond({ok:false,reason:'Select a test ASIN'});
  const st=await ps(p);if(st.inProgress||st.submissionPending||st.checkoutOwned||st.attempted)return respond({ok:false,reason:'Cannot refresh while order active or unresolved'});
  if(!Number.isFinite(st.cap)||st.cap<=0)return respond({ok:false,reason:'Enter and save a price cap first'});
  const ok=await check(p,{force:true});return respond({ok:!!ok,reason:ok?null:'Refresh could not complete; check Amazon tab/session and diagnostics'});
 }
 if(m.type==='EXPORT_DIAGNOSTICS')return respond({ok:true,data:await diagnosticsBundle()});
 if(m.type==='GET_INTELLIGENCE'){const [summary,config]=await Promise.all([RI.summary(),RI.getConfig()]);return respond({ok:true,summary,config:{...config,keepaApiKey:'',keepaKeySet:!!config.keepaApiKey}})}
 if(m.type==='SET_INTELLIGENCE_CONFIG'){const values={...(m.values||{})};if(values.keepaApiKey==='')delete values.keepaApiKey;const config=await RI.setConfig(values);await refreshIntelligenceScores();await syncSensorStream();return respond({ok:true,config:{...config,keepaApiKey:'',keepaKeySet:!!config.keepaApiKey}})}
 if(m.type==='IMPORT_INTELLIGENCE'){const r=await RI.importBundle(m.data);await refreshIntelligenceScores({wake:false});return respond({ok:true,...r})}
 if(m.type==='EXPORT_INTELLIGENCE')return respond({ok:true,data:await RI.exportBundle()});
 if(m.type==='INGEST_SENSOR_EVENTS'){const r=await RI.ingestFeedPayload(m.data,'manual_import');await refreshIntelligenceScores({wake:r.added>0});return respond({ok:true,...r})}
 if(m.type==='CLEAR_INTELLIGENCE'){await RI.clearLearning();await refreshIntelligenceScores();return respond({ok:true})}
 if(m.type==='POLL_INTELLIGENCE'){await pollIntelligenceSensors();return respond({ok:true,summary:await RI.summary()})}
 if(m.type==='CHECKOUT_PRICE_EVIDENCE'){if(!p||!await senderOwns(p,sender))return respond({ok:false,reason:'checkout evidence sender does not own product'});void diag('checkout_price_evidence',{productId:p?.id||null,asin:p?(await ps(p)).customAsin||p.asin:null,priceCandidates:Array.isArray(m.candidates)?m.candidates.filter(Number.isFinite).slice(0,8):[],summaryBase:Number.isFinite(m.summaryBase)?m.summaryBase:null,listingReference:Number.isFinite(m.listingReference)?m.listingReference:null,decision:String(m.decision||'').slice(0,120),phase:String(m.phase||'').slice(0,32),identityMethod:String(m.identityMethod||'').slice(0,40),identityVerified:m.identityVerified===true,quantityOne:m.quantityOne===true,quantityZero:m.quantityZero===true,feesPresent:m.feesPresent===true,placeOrderPresent:m.placeOrderPresent===true,attemptAgeMs:Number.isFinite(Number(m.attemptAgeMs))?Math.max(0,Number(m.attemptAgeMs)):null,...(m.page?{page:String(m.page).slice(0,70)}:{}),...(m.label?{label:String(m.label).slice(0,40)}:{}),...(Array.isArray(m.headings)?{headings:m.headings.map(x=>String(x).slice(0,100)).slice(0,8)}:{}),...(Array.isArray(m.notes)?{notes:m.notes.map(x=>String(x).slice(0,200)).slice(0,5)}:{}),...(Number.isFinite(Number(m.presses))?{presses:Number(m.presses)}:{})});return respond({ok:true})}   // v91: which checkout step, its headings and Amazon's own item messages (never address / payment)
 if(m.type==='FLOW_GET'){if(!sender.tab?.id)return respond({ok:false});const x=await chrome.storage.local.get(FLOW(sender.tab.id));return respond({ok:true,flow:x[FLOW(sender.tab.id)]||null})}
 if(m.type==='FLOW_CLEAR'){if(sender.tab?.id)await clearFlowForTab(sender.tab.id);return respond({ok:true})}
 if(m.type==='FLOW_SAVE'){if(!p||!sender.tab?.id||!await senderOwns(p,sender))return respond({ok:false});const f=m.flow||{},st=await ps(p),expectedAsin=String(st.discoveredAsin||p.asin||'').toUpperCase();if(f.id!==p.id||!Number.isFinite(Number(f.cap))||Number(f.cap)<=0||!expectedAsin||String(f.asin||'').toUpperCase()!==expectedAsin)return respond({ok:false});await chrome.storage.local.set({[FLOW(sender.tab.id)]:f});return respond({ok:true})}
 if(m.type==='GET_ALL'){const cat=await catalog(),arr=await Promise.all(cat.map(async q=>[q.id,await ps(q)])),gg=await g(),ts=trafficSnapshot(),intel=await RI.summary();ts.cooldownRemainingMs=Math.max(0,Number(gg.globalCooldownUntil||0)-Date.now());return respond({ok:true,catalog:cat,states:Object.fromEntries(arr),global:{...gg,...ts},detectorBridge:buyerDetectorBridge.status(),intelligence:intel})}
 if(m.type==='SET_GLOBAL'){const v=m.values||{},cur=await g(),next={...(Object.prototype.hasOwnProperty.call(v,'monitoring')?{monitoring:!!v.monitoring,emergencyStop:false}:{}),...(Object.prototype.hasOwnProperty.call(v,'liveGlobal')?{liveGlobal:!!v.liveGlobal,emergencyStop:false}:{})};const monitorNext=Object.prototype.hasOwnProperty.call(next,'monitoring')?next.monitoring:cur.monitoring;if(!monitorNext)next.liveGlobal=false;await setg(next);await syncHotLoops();await badge();return respond({ok:true})}
if(m.type==='TEST_PHONE_NOTIFICATION'){const n=await notify('AMAZON MONITOR TEST','Phone notifications are connected.');await badge();return respond({ok:!!n.phone,phone:!!n.phone,desktop:!!n.desktop})}
 if(m.type==='SET_NOTIFICATION_TOPIC'){const topic=String(m.topic||'').trim();if(topic!==DEFAULT_NTFY_TOPIC)return respond({ok:false,reason:'notification topic locked to production subscription'});await setg({ntfyTopic:DEFAULT_NTFY_TOPIC,lastNotifyOk:null,lastNotifyAt:null});return respond({ok:true})}
 if(m.type==='MONITOR_ALL'){
   const eligible=[];for(const q of await catalog()){const st=await ps(q);if(validCapState(st)&&(q.asin||st.customAsin||st.discoveredAsin))eligible.push({q,st})}
   const turnOn=eligible.some(x=>!x.st.monitor);let changed=0;
   for(const {q,st} of eligible){if(turnOn){if(!st.monitor){await setp(q,{monitor:true,nextCheckAt:0});changed++;immediateCheck(q)}}else{if(st.monitor||st.autoBuy){await setp(q,{monitor:false,autoBuy:false,queued:false,queuedPrice:null,queuedAt:null,status:st.purchased?st.status:'MONITORING OFF'});changed++}}}
   await setg({monitoring:turnOn&&eligible.length>0,emergencyStop:false,...(!turnOn?{liveGlobal:false}:{})});await syncHotLoops();await badge();return respond({ok:true,changed,enabled:turnOn})
 }
 if(m.type==='REARM_ALL'){
   const eligible=[];for(const q of await catalog()){const st=await ps(q);if(validCapState(st)&&(q.asin||st.customAsin||st.discoveredAsin))eligible.push({q,st})}
   const turnOn=eligible.some(x=>!x.st.armed||!x.st.autoBuy||x.st.purchased);let changed=0,skippedActive=0;
   for(const {q,st} of eligible){if(st.purchased||st.attempted||st.checkoutOwned||st.inProgress||st.submissionPending||st.approval){skippedActive++;continue}await clearFlowForTab(st.tabId);await releaseCartSlot(q.id,{promote:false});if(turnOn){await setp(q,{monitor:true,armed:true,purchased:false,attempted:false,inProgress:false,submissionPending:false,checkoutOwned:false,approval:null,queued:false,queuedPrice:null,queuedAt:null,autoBuy:true,status:'ARMED — AUTO BUY ON',nextCheckAt:0});immediateCheck(q)}else{await setp(q,{armed:false,autoBuy:false,queued:false,queuedPrice:null,queuedAt:null,status:st.purchased?st.status:'DISARMED'});}changed++}
   if(turnOn)await setg({monitoring:true,emergencyStop:false});await syncHotLoops();await badge();return respond({ok:true,changed,skippedActive,enabled:turnOn})
 }
 if(m.type==='EMERGENCY_STOP'){
   await setg({monitoring:false,liveGlobal:false,emergencyStop:true});
   for(const q of await catalog()){const st=await ps(q);if(st.submissionPending||st.attempted)continue;await setp(q,{monitor:false,autoBuy:false,armed:false,queued:false,queuedPrice:null,queuedAt:null,status:st.purchased?st.status:'EMERGENCY STOP — DISARMED'})}
   await badge();return respond({ok:true})
 }
 if(m.type==='ADD_CUSTOM_PRODUCT'){
   const store=await chrome.storage.local.get([CUSTOM_DEFS_KEY,'customProductSeq']),defs=Array.isArray(store[CUSTOM_DEFS_KEY])?store[CUSTOM_DEFS_KEY]:[],seq=Math.max(1,Number(store.customProductSeq)||1)+1,id='custom-asin-product-'+seq;
   defs.push({id,name:'Custom ASIN Product',asin:'',url:'',search:'',tokens:[],capSource:null});await saveCustomDefs(defs);await chrome.storage.local.set({customProductSeq:seq});const q=await productById(id);await setp(q,{status:'ENTER ASIN — cap required'});return respond({ok:true,id})
 }
 if(m.type==='DELETE_CUSTOM_PRODUCT'&&p?.customProduct){
   const st=await ps(p);if(st.checkoutOwned||st.inProgress||st.submissionPending||st.approval)return respond({ok:false,reason:'cannot delete a product while checkout owns it'});await clearFlowForTab(st.tabId);await releaseCartSlot(p.id);const store=await chrome.storage.local.get(CUSTOM_DEFS_KEY),defs=(Array.isArray(store[CUSTOM_DEFS_KEY])?store[CUSTOM_DEFS_KEY]:[]).filter(d=>d.id!==p.id);await saveCustomDefs(defs);await chrome.storage.local.remove(k(p.id));await syncHotLoops();await badge();return respond({ok:true})
 }
 if(m.type==='DUPLICATE_CUSTOM_PRODUCT'&&p?.customProduct){
   const st=await ps(p),store=await chrome.storage.local.get([CUSTOM_DEFS_KEY,'customProductSeq']),defs=Array.isArray(store[CUSTOM_DEFS_KEY])?store[CUSTOM_DEFS_KEY]:[],seq=Math.max(1,Number(store.customProductSeq)||1)+1,id='custom-asin-product-'+seq;
   defs.push({id,name:st.customName||p.name,asin:st.customAsin||'',url:st.customAsin?'https://www.amazon.com/dp/'+st.customAsin:'',search:'',tokens:Array.isArray(st.customTokens)?st.customTokens:[],capSource:null});await saveCustomDefs(defs);await chrome.storage.local.set({customProductSeq:seq});const q=await productById(id);await setp(q,{customAsin:st.customAsin||null,customName:st.customName||null,customTokens:st.customTokens||null,customMsrp:Number.isFinite(st.customMsrp)?st.customMsrp:null,customCurrentPrice:Number.isFinite(st.customCurrentPrice)?st.customCurrentPrice:null,discoveredAsin:st.customAsin||null,discoveredUrl:st.customAsin?'https://www.amazon.com/dp/'+st.customAsin:null,cap:Number.isFinite(st.cap)?st.cap:null,monitor:false,autoBuy:false,armed:false,purchased:false,attempted:false,status:'DUPLICATED — review settings'});return respond({ok:true,id})
 }
 if(m.type==='SET_CUSTOM_ASIN'&&p?.customProduct){
   const busy=await g();if(busy.cartOwner&&busy.cartOwner!==p.id)return respond({ok:false,reason:'checkout active — metadata loading paused'});
   const asin=String(m.asin||'').trim().toUpperCase();if(!/^[A-Z0-9]{10}$/.test(asin))return respond({ok:false,reason:'ASIN must be exactly 10 letters/numbers'});const st=await ps(p);if(st.checkoutOwned||st.inProgress||st.submissionPending||st.approval)return respond({ok:false,reason:'custom product checkout currently owns its tab'});await clearFlowForTab(st.tabId);await releaseCartSlot(p.id);
   const changed=asin!==String(st.customAsin||'').toUpperCase();await setp(p,{customAsin:asin,customName:'Loading '+asin+'…',customTokens:null,customMsrp:null,customCurrentPrice:null,discoveredAsin:asin,discoveredUrl:'https://www.amazon.com/dp/'+asin,...(changed?{cap:null,monitor:false,autoBuy:false,armed:false,purchased:false,attempted:false,inProgress:false,submissionPending:false,checkoutOwned:false,approval:null,price:null,lastCheck:null,checks:0}:{}),status:'LOADING PRODUCT METADATA'});
   try{const t=await tab(p,false),url='https://www.amazon.com/dp/'+asin;if(!t?.id)throw new Error('Amazon product tab unavailable');const live=await chrome.tabs.get(t.id);if(!globalThis.AmazonBuyerLogic.exactUrl(live.url,asin)){if(!await navigateAndWait(t.id,url))throw new Error('metadata navigation timeout')}else if(!await reloadAndWait(t.id))throw new Error('metadata page load timeout');const current=runtimeProduct(p,await ps(p)),meta=await sendTab(t.id,{type:'EXTRACT_CUSTOM_META',product:{...current,asin,url}});if(!meta?.ok)throw new Error(meta?.reason||'metadata unavailable');const verifiedMsrp=Number.isFinite(meta.verifiedMsrp)&&meta.verifiedMsrp>0?Number(meta.verifiedMsrp):null;
const patch={customName:meta.name,customTokens:meta.tokens,customMsrp:verifiedMsrp,customCurrentPrice:Number.isFinite(meta.price)?meta.price:null,customReferencePrice:Number.isFinite(meta.referencePrice)?meta.referencePrice:null,price:Number.isFinite(meta.price)?meta.price:null,status:verifiedMsrp?'ASIN LOADED — VERIFIED MSRP FOUND':'ASIN LOADED — cap blank; MSRP not verified'};
if(changed)Object.assign(patch,{cap:verifiedMsrp,monitor:false,autoBuy:false});
await setp(p,patch);await syncHotLoops();await badge();return respond({ok:true,meta})}catch(e){await setp(p,{status:'ASIN LOADED — metadata unavailable; set cap manually'});await badge();return respond({ok:false,reason:String(e?.message||e)})}
 }
 if(m.type==='SET_PRODUCT'&&p){const v={...(m.values||{})};if(v.monitor===false){v.autoBuy=false;v.armed=false;v.nextCheckAt=0;v.queued=false;v.queuedPrice=null;v.queuedAt=null;}if('cap' in v){if(v.cap===null){v.monitor=false;v.autoBuy=false}else if(!Number.isFinite(v.cap)||v.cap<=0)return respond({ok:false,reason:'invalid cap'});else if(!('monitor' in v))v.monitor=true}if(v.autoBuy===true){const s=await ps(p),cap=('cap'in v)?v.cap:s.cap,mon=('monitor'in v)?v.monitor:s.monitor;if(!Number.isFinite(cap)||cap<=0)return respond({ok:false,reason:'cap required'});if(!mon)return respond({ok:false,reason:'monitor must be enabled'});if(!s.armed||s.attempted||s.purchased)return respond({ok:false,reason:'product must be re-armed'})}await setp(p,v);if(v.monitor===true)await setg({monitoring:true,emergencyStop:false});await syncHotLoops();await badge();if(v.monitor===true||v.autoBuy===true)immediateCheck(p);return respond({ok:true})}
 if(m.type==='OPEN_PRODUCT'&&p){const t=await tab(p,true);if(t?.id)await chrome.tabs.update(t.id,{active:true});return respond({ok:!!t})}
 if(m.type==='OPEN_DASHBOARD'){const u=chrome.runtime.getURL('dashboard.html'),ts=await chrome.tabs.query({url:u});ts[0]?.id?await chrome.tabs.update(ts[0].id,{active:true}):await chrome.tabs.create({url:u});return respond({ok:true})}
 if(m.type==='DETECTION_WAKE'&&p){void diag('detection_wake',{productId:p.id,asin:p.asin||(await ps(p)).customAsin||null,source:m.source||'dom_mutation',observedAt:Number(m.observedAt)||Date.now()});return respond({ok:true})}
 if(!p)return respond({ok:false});
 if(['DISCOVERED','PRODUCT_META','FLOW_BLOCKED','ACTION_REQUIRED','SHIPPING_APPROVAL_REQUIRED','SUBMITTING','PURCHASE_SUCCESS','DEFINITE_SUBMISSION_FAILURE','SUBMISSION_UNCLEAR'].includes(m.type)&&!await senderOwns(p,sender))return respond({ok:false,reason:'sender tab does not own product'});
 if(m.type==='PRODUCT_META'&&p?.customProduct){const name=String(m.name||'').trim().slice(0,500),tokens=Array.isArray(m.tokens)?m.tokens.map(x=>String(x).trim().toLowerCase()).filter(Boolean).slice(0,16):[];if(name.length<5||tokens.length<2)return respond({ok:false,reason:'invalid custom product identity'});await setp(p,{customName:name,customTokens:tokens});return respond({ok:true})}
 if(m.type==='STATUS'){
   let st=await ps(p);if(st.tabId!==sender.tab?.id)return respond({ok:false,reason:'sender tab does not own product'});if(st.attempted||st.purchased||st.inProgress||st.submissionPending)return respond({ok:true,ignored:true});
   const status=String(m.status||''),cls=availabilityClass(status),eligible=['ELIGIBLE','ELIGIBLE_PREORDER_PRICE_DEFERRED','ELIGIBLE_CONTROL_PENDING','ELIGIBLE_PREORDER_CONTROL_PENDING'].includes(status),hitAt=eligible&&Number.isFinite(Number(m.detectedAt))?Number(m.detectedAt):null,now=Date.now();void diag('availability_observed',{productId:p.id,asin:p.asin||st.customAsin||st.discoveredAsin,status,availabilityClass:cls,previousClass:st.lastAvailabilityClass||null,observedAt:Number(m.observedAt)||now,receivedAt:now,parseToReceiveMs:Number(m.observedAt)?Math.max(0,now-Number(m.observedAt)):null,recognitionMs:Number.isFinite(Number(m.recognitionMs))?Number(m.recognitionMs):null,parseMs:Number.isFinite(Number(m.parseMs))?Number(m.parseMs):null,trigger:m.trigger||null});
   if(st.checkoutRetryPending&&cls!=='ELIGIBLE'){await finishRetryCampaign(p,'RETRY STOPPED — new Amazon evidence '+status+'; MANUAL RE-ARM REQUIRED');return respond({ok:true,terminal:true})}
   if(cls==='THROTTLED'){const cool=await noteThrottle(status);await setp(p,{status:'COOLDOWN — Amazon throttling detected',lastCheck:now,checks:(st.checks||0)+1,consecutiveErrors:(st.consecutiveErrors||0)+1,nextCheckAt:now+cool});await badge();return respond({ok:true,cooldown:true})}
   const history=Array.isArray(st.stockHistory)?st.stockHistory.slice(-199):[],transition=cls!==st.lastAvailabilityClass;if(transition)history.push({at:now,state:cls,price:Number.isFinite(Number(m.price))?Number(m.price):null});if(transition){const rp=runtimeProduct(p,st),prev=st.lastAvailabilityClass;defer(()=>void RI.recordAvailability({asin:rp.asin||st.discoveredAsin||st.customAsin,productId:p.id,set:p.set,previousState:prev,state:cls,price:m.price,ts:now}).then(r=>{if(r?.restock)return refreshIntelligenceScores({wake:false})}).catch(()=>{}));}
   const unavailable=cls==='UNAVAILABLE',unavailableStreak=unavailable?(Number(st.unavailableStreak)||0)+1:0;
   const baseDelay=Math.max(Number(m.retryAfterMs)||0,monitoringDelay({...st,unavailableStreak}));
   const hitStamp=hitAt&&!st.hitDetectedAt?hitAt:st.hitDetectedAt;const eventPushedAt=eligible?(Number(m.eventPushedAt)>0?Number(m.eventPushedAt):now):null;
   const patch={status,price:m.price??null,lastCheck:now,checks:(st.checks||0)+1,consecutiveErrors:0,nextCheckAt:now+baseDelay,lastAvailabilityClass:cls,stockHistory:history,unavailableStreak,priority:Number(st.restockScore)>=.82?'IMMINENT':Number(st.restockScore)>=.55?'HOT':Number(st.setHeatUntil)>now?'HOT':historicalBoost(st,now)?'WARM':'NORMAL',...(hitAt&&!st.hitDetectedAt?{hitDetectedAt:hitAt,campaignStartedAt:Number(st.campaignStartedAt)>0?st.campaignStartedAt:hitAt,lastAttemptOutcome:null}:{}),...(eligible?{checkoutPushAt:eventPushedAt}:{}),...((m.deliver==='yes'||m.deliver==='no')?{deliver:m.deliver,deliverAt:now,deliverNote:String(m.deliverNote||'').slice(0,120)}:{})};
   if(eligible){
     const x=await g();
     if(x.monitoring&&!x.emergencyStop&&st.monitor&&st.autoBuy&&x.liveGlobal&&st.armed&&!st.inProgress&&!st.attempted&&!st.purchased){
       if(!await acquireCartSlot(p)){await setp(p,patch);await queueEligible(p,m.price,hitStamp||hitAt);if(transition)defer(()=>void heatSet(p.set,p.id));return respond({ok:true,queued:true})}
       const authorizedAt=Date.now();diag('eligible_authorized',{productId:p.id,asin:p.asin||st.customAsin||st.discoveredAsin,hitDetectedAt:hitStamp||hitAt,authorizedAt});await setp(p,{...patch,inProgress:true,checkoutOwned:true,checkoutRetryPending:false,checkoutRetryDueAt:0,campaignAttempts:(Number(st.campaignAttempts)||0)+1,campaignLastAttemptStartedAt:authorizedAt,eligibleAuthorizedAt:authorizedAt,status:'CHECKOUT — STARTING'});
       if(transition)defer(()=>void heatSet(p.set,p.id));void badge();return respond({ok:true,beginPurchase:true,hitDetectedAt:hitStamp||hitAt,eligibleAuthorizedAt:authorizedAt,eventPushedAt})
     }
   }
   await setp(p,patch);if((eligible||cls==='AVAILABLE_OVER_CAP')&&transition)defer(()=>void heatSet(p.set,p.id));void badge();return respond({ok:true})
 }
 if(m.type==='FLOW_BLOCKED') {try{void globalThis.RestalkerShops?.amazonDone?.(p.id)}catch{};void diag('checkout_stage_failure',{productId:p.id,reason:m.reason,flowStep:m.flowStep||null,flowAgeMs:m.flowAgeMs||null,perf:m.perf||null});await blockPurchase(p,'BLOCKED — '+m.reason,sender.tab?.id,{autoRearm:true});return respond({ok:true})}
 if(m.type==='ACTION_REQUIRED'){await blockPurchase(p,'ACTION REQUIRED — '+m.reason,sender.tab?.id,{manualRecovery:true});return respond({ok:true})}
 if(m.type==='SHIPPING_APPROVAL_REQUIRED'){
   const f=m.fees||{},base=Number(f.base),tax=Number(f.tax),shipping=Number(f.shipping),total=Number(f.total),s=await ps(p),x=await g();if(!x.monitoring||!s.monitor||!s.autoBuy||!x.liveGlobal||!s.armed||s.attempted||s.purchased)return respond({ok:false,reason:'purchase gates changed before shipping approval'});if([base,tax,shipping,total].some(x=>!Number.isFinite(x)))return respond({ok:false});const gate=globalThis.AmazonBuyerLogic.checkoutFees(base,tax,shipping,s.cap,total);if(!gate.ok||!gate.needsShippingApproval)return respond({ok:false,reason:'invalid approval request'});
   const approval={tabId:sender.tab.id,base,tax,shipping,total,created:Date.now()};await setp(p,{inProgress:true,status:`ACTION REQUIRED — SHIPPING $${shipping.toFixed(2)}`,approval});const n=await notify('SHIPPING APPROVAL REQUIRED',`${p.name}: item $${base.toFixed(2)}, tax $${tax.toFixed(2)}, shipping $${shipping.toFixed(2)}, total $${total.toFixed(2)}`);if(!n.phone)await setp(p,{status:`ACTION REQUIRED — SHIPPING $${shipping.toFixed(2)} — PHONE PUSH FAILED`});await badge();return respond({ok:true})
 }
 if(m.type==='APPROVE_SHIPPING'){
   const s=await ps(p),a=s.approval,x=await g();if(!a?.tabId)return respond({ok:false,reason:'No pending shipping approval'});if(!x.monitoring||!s.monitor||!s.autoBuy||!x.liveGlobal||!s.armed||s.attempted||s.purchased)return respond({ok:false,reason:'Monitoring, Auto Buy, armed state, and global LIVE must be enabled'});if(Date.now()-(a.created||0)>10*60*1000){await clearFlowForTab(a.tabId);await finishRetryCampaign(p,'SHIPPING APPROVAL EXPIRED — MANUAL RE-ARM REQUIRED');return respond({ok:false,reason:'Approval expired'})}
   try{const r=await sendTab(a.tabId,{type:'RESUME_FLOW',approvedShipping:a.shipping,cap:s.cap});if(!r?.ok)throw new Error('resume not acknowledged');await setp(p,{status:'SHIPPING APPROVED — revalidating checkout'});return respond({ok:true})}catch{await setp(p,{status:'ACTION REQUIRED — APPROVED SHIPPING COULD NOT RESUME'});return respond({ok:false})}
 }
 if(m.type==='CANCEL_SHIPPING'){const s=await ps(p),a=s.approval;if(a?.tabId)await clearFlowForTab(a.tabId);const ms=await finishTiming(p,'CANCELLED');await setp(p,{inProgress:false,checkoutOwned:false,approval:null,armed:false,autoBuy:false,monitor:false,nextCheckAt:0,status:'PURCHASE CANCELLED — RE-ARM REQUIRED'+(Number.isFinite(ms)?` — ${(ms/1000).toFixed(2)}s`:'')});await releaseCartSlot(p.id);await syncHotLoops();await badge();return respond({ok:true})}
 if(m.type==='SUBMITTING'){
   const flow=(await chrome.storage.local.get(FLOW(sender.tab.id)))[FLOW(sender.tab.id)];if(!flow||flow.id!==p.id||(flow.step!=='shipping_approval'&&flow.step!=='checkout'))return respond({ok:false,reason:'purchase flow state invalid'});
   // Restalker v75: the same product may be checking out at the other stores this very moment - ONE Place order at a time (waits its turn; never pressed when it was ordered there)
   const RSx=globalThis.RestalkerShops;if(RSx&&RSx.amazonTurn){const turn=await RSx.amazonTurn(p.id,async()=>{const q=await ps(p),y=await g();return !!(y.monitoring&&q.monitor&&q.autoBuy&&y.liveGlobal&&q.armed&&!q.attempted&&!q.purchased&&!y.emergencyStop)});if(!turn.ok)return respond({ok:false,reason:turn.reason});if(turn.waitedMs>50)void diag('amazon_waited_for_other_store',{productId:p.id,waitedMs:turn.waitedMs})}
   const s=await ps(p),x=await g(),fees=m.fees||{};if(!x.monitoring||!s.monitor||!s.autoBuy||!x.liveGlobal||!s.armed||s.attempted||s.purchased)return respond({ok:false,reason:'live purchase gates changed before submission'});const gate=globalThis.AmazonBuyerLogic.checkoutFees(Number(fees.base),Number(fees.tax),Number(fees.shipping),s.cap,Number(fees.total));if(!gate.ok)return respond({ok:false,reason:'background fee validation failed'});if(gate.needsShippingApproval&&(!s.approval||Number(fees.shipping)>Number(s.approval.shipping)+.01))return respond({ok:false,reason:'shipping approval missing or stale'});
   const submitAt=Date.now(),eligibleToSubmitMs=Number.isFinite(Number(s.hitDetectedAt))?Math.max(0,submitAt-Number(s.hitDetectedAt)):null;
   const eventPushedAt=Number(m.perf?.eventPushedAt)||Number(s.checkoutPushAt)||null;
   const pushToSubmitMs=eventPushedAt&&eventPushedAt<=submitAt?submitAt-eventPushedAt:null;
   diag('submit_latched',{productId:p.id,asin:p.asin||s.customAsin||s.discoveredAsin,submitAt,eligibleToSubmitMs,pushToSubmitMs,fees,perf:m.perf||null});await setp(p,{attempted:true,armed:false,inProgress:true,submissionPending:true,approval:null,status:'SUBMITTING ORDER'+(Number.isFinite(eligibleToSubmitMs)?` — ${(eligibleToSubmitMs/1000).toFixed(2)}s from hit`:''),price:m.price,submitAt,eligibleToSubmitMs,checkoutPushAt:eventPushedAt,pushToSubmitMs});await badge();return respond({ok:true,eligibleToSubmitMs})
 }
 if(m.type==='DEFINITE_SUBMISSION_FAILURE'){
   const pending=await ps(p);if(!pending.attempted||!pending.submissionPending){try{await globalThis.RestalkerShops?.amazonDone?.(p.id)}catch{};return respond({ok:false,reason:'no pending submitted order'})}
   await clearFlowForTab(sender.tab?.id);
   const reason='FAILED — '+String(m.reason||'Amazon definitively rejected order');
   const eligible=await scheduleExclusiveCheckoutRetry(p,{...pending,armed:true,attempted:false,submissionPending:false},reason);
   // (Restalker v75: released only AFTER the record says "not ordered" - a store waiting its turn then presses at once)
   if(eligible){await finishTiming(p,'DEFINITE_FAILED');try{await globalThis.RestalkerShops?.amazonDone?.(p.id)}catch{};return respond({ok:true,rearmed:true,attempts:pending.campaignAttempts})}
   await finishRetryCampaign(p,reason+' — RETRY LIMIT REACHED; MANUAL RE-ARM REQUIRED');await setp(p,{attempted:false});
   try{await globalThis.RestalkerShops?.amazonDone?.(p.id)}catch{};
   return respond({ok:true,rearmed:false,terminal:true})
 }
 if(m.type==='PURCHASE_SUCCESS'){try{void globalThis.RestalkerShops?.amazonDone?.(p.id)}catch{};
   const pending=await ps(p);if(!pending.attempted||!pending.submissionPending)return respond({ok:false,reason:'no pending submitted order'});
   const tid=sender.tab?.id;await clearFlowForTab(tid);const current=await ps(p),rp=runtimeProduct(p,current),submitMs=Number(current.eligibleToSubmitMs),ms=await finishTiming(p,'SUCCESS',{terminal:true});const confirmedAt=Date.now(),eventPush=Number(current.checkoutPushAt)||Number(m.perf?.eventPushedAt)||null;
   const pushToConfirmedMs=eventPush&&eventPush<=confirmedAt?confirmedAt-eventPush:null;
   diag('purchase_success',{productId:p.id,asin:rp.asin,submitMs,confirmedMs:ms,pushToConfirmedMs,underCheckoutBudget:pushToConfirmedMs!==null?pushToConfirmedMs<=1000:null,price:m.price,orderNumber:m.orderNumber||null,perf:m.perf||null});await setp(p,{purchased:true,attempted:true,armed:false,inProgress:false,submissionPending:false,checkoutOwned:false,checkoutRetryPending:false,checkoutRetryDueAt:0,queued:false,queuedPrice:null,queuedAt:null,status:'PURCHASE SUCCESS'+(Number.isFinite(submitMs)?` — SUBMIT ${(submitMs/1000).toFixed(2)}s`:``)+(Number.isFinite(ms)?` — CONFIRMED ${(ms/1000).toFixed(2)}s`:''),price:m.price,approval:null,orderNumber:m.orderNumber||null,monitor:false,autoBuy:false});await releaseCartSlot(p.id);await syncHotLoops();void badge();void notify('PURCHASE SUCCESS',rp.name+' purchased at $'+Number(m.price).toFixed(2)+(m.orderNumber?' — order '+m.orderNumber:'')).then(async n=>{if(!n.phone){const st=await ps(p);await setp(p,{status:st.status+' — PHONE PUSH FAILED'})}});return respond({ok:true})
 }
 if(m.type==='SUBMISSION_UNCLEAR'){try{void globalThis.RestalkerShops?.amazonDone?.(p.id)}catch{};const pending=await ps(p);if(!pending.attempted||!pending.submissionPending)return respond({ok:false,reason:'no pending submitted order'});await clearFlowForTab(sender.tab?.id);const ms=await finishTiming(p,'UNCERTAIN',{terminal:true});await setp(p,{attempted:true,armed:false,inProgress:false,submissionPending:false,checkoutOwned:false,checkoutRetryPending:false,checkoutRetryDueAt:0,monitor:false,queued:false,queuedPrice:null,queuedAt:null,approval:null,autoBuy:false,status:'ORDER MAY HAVE BEEN SUBMITTED — CHECK AMAZON'+(Number.isFinite(ms)?` — ${(ms/1000).toFixed(2)}s`:'')});await releaseCartSlot(p.id);await syncHotLoops();await badge();return respond({ok:true})}
 if(m.type==='DISCOVERED'){const asin=String(m.asin||'').trim().toUpperCase();if(!/^[A-Z0-9]{10}$/.test(asin))return respond({ok:false});await setp(p,{discoveredAsin:asin,discoveredUrl:'https://www.amazon.com/dp/'+asin,status:'DISCOVERED — '+asin,price:null,lastCheck:Date.now(),autoBuy:false});return respond({ok:true})}
 if(m.type==='REFRESH_PRODUCT'){
   const s=await ps(p);if(s.checkoutOwned||s.inProgress||s.submissionPending||s.approval)return respond({ok:false,reason:'purchase checkout owns this tab'});
   await check(p,{force:true});return respond({ok:true})
 }
 if(m.type==='REFRESH_SET'){const cat=await catalog();await runChecks(cat.filter(x=>x.set===m.set),3,true);return respond({ok:true})}
 if(m.type==='REFRESH_ALL'){await runChecks(await catalog(),3,true);return respond({ok:true})}
 respond({ok:false});
 })().catch(e=>{try{respond({ok:false,reason:'background handler error: '+String(e?.message||e)})}catch{}});return true});
ready=ensureInit().then(ensureSessionReady);
// v90: the link to Restalker starts even if the start-up work failed (it is reported in the hello), and how long that work took is sent
// along, so a slow start shows in Restalker's diagnostics instead of looking like a dead browser.
{const t0=Date.now();void ready.then(()=>{globalThis.__RK_INIT={ms:Date.now()-t0,error:null}},e=>{globalThis.__RK_INIT={ms:Date.now()-t0,error:String(e?.message||e).slice(0,200)};void diag('engine_init_failed',{reason:globalThis.__RK_INIT.error})})
  .finally(()=>{try{buyerDetectorBridge.start()}catch(e){void diag('detector_bridge_start_failed',{reason:String(e?.message||e)})}});}
// v90: the TAB JANITOR (diagnostics 73/74: the buying browser held 385 tabs in 113 windows - leftover checkout tabs, product pages of
// listings that could not be added, empty about:blank tabs - up to 34 GB and 20 processor cores, because its pages are never slowed
// down in the background; the PC ran out of memory). Every minute: each Amazon product's own watch tab, each store checkout's own tab,
// the sign-in window, the buying browser's first tab and every tab that did something in the last 5 minutes are KEPT; every other tab
// that has done nothing for 5 minutes is closed - and above 40 tabs, every other tab idle for 1 minute. Never while a Place order is
// being pressed. (Every part that needs a tab opens a new one when its old one is gone.)
const RK_JANITOR={idleMs:5*60*1000,crowdIdleMs:60*1000,crowd:40,everyMs:60*1000,seen:new Map(),closed:0,last:null};
try{chrome.tabs.onUpdated.addListener((id,ch)=>{if(ch.status||ch.url)RK_JANITOR.seen.set(id,Date.now())});chrome.tabs.onCreated.addListener(t=>RK_JANITOR.seen.set(t.id,Date.now()));chrome.tabs.onRemoved.addListener(id=>RK_JANITOR.seen.delete(id))}catch{}
async function rkJanitor(){
 try{
  const keep=new Set();
  for(const p of await catalog()){const s=await ps(p);if(s.submissionPending)return;if(Number.isInteger(s.tabId))keep.add(s.tabId)}
  try{const z=await chrome.storage.local.get(['bb:g','tg:g','wm:g','gs:g']);for(const v of Object.values(z))if(v&&Number.isInteger(v.tab))keep.add(v.tab)}catch{}
  try{for(const v of (globalThis.RestalkerRecs?await globalThis.RestalkerRecs.entries():[]))if(v&&v[1]&&v[1].submissionPending)return}catch{}
  const wins=await chrome.windows.getAll({populate:true});if(!wins.length)return;
  const first=wins.map(w=>w.id).sort((a,b)=>a-b)[0],now=Date.now(),total=wins.reduce((n,w)=>n+(w.tabs||[]).length,0);
  const test=Number((await chrome.storage.local.get('rkTestJanitorIdleMs')).rkTestJanitorIdleMs)||0;      // (tests only)
  const idle=test||(total>RK_JANITOR.crowd?RK_JANITOR.crowdIdleMs:RK_JANITOR.idleMs);let n=0;
  for(const w of wins){
   for(const t of (w.tabs||[])){
    if(!RK_JANITOR.seen.has(t.id)){RK_JANITOR.seen.set(t.id,now);continue}             // (first seen now: closed later at the earliest)
    if(keep.has(t.id)||w.id===globalThis.__rkSigninWin||(w.id===first&&t.index===0))continue;
    if(String(t.url||'').startsWith('chrome-extension://'))continue;
    if(now-RK_JANITOR.seen.get(t.id)<idle)continue;
    try{await chrome.tabs.remove(t.id);n++}catch{}
   }
  }
  RK_JANITOR.closed+=n;RK_JANITOR.last={at:now,closed:n,tabs:total-n,windows:wins.length};
  if(n)void diag('rk_janitor',{closed:n,left:total-n,windows:wins.length});
 }catch(e){void diag('rk_janitor_error',{reason:String(e?.message||e)})}
}
setInterval(()=>void rkJanitor(),RK_JANITOR.everyMs);
globalThis.RK_JANITOR=RK_JANITOR;
