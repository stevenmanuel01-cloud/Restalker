"""v101: updates from one central place (owner 2026-11-05: "yes let's move forward with a centralized github. we do need to solve the issue
though of what you upload there since it would either include my information, or would override and clear my information when I update.
the same would be for all other users, so only updating certain parts is important. ensuring that our architecture is set up to accept
updates without ever affecting individual users saved data").

How your data stays yours:
- An update holds PROGRAM files only, and lists each of them (MANIFEST.json, with a fingerprint per file). Only a name that is a program
  file can be in it: the .py files, stop_restalker.bat, msrp.yaml, new_products.yaml and the two engine folders. Anything else in an
  update - a product list, a purchase list, a sign-in, a setting, any .csv / .txt / .json / .bin at the top of the folder - refuses the
  WHOLE update before one file is touched.
- Nothing is ever deleted. A file the update does not list is never opened.
- Before an update, every data file is copied aside (_update/data_backup_<date>), and the program files it replaces too
  (_update/program_<old version>), so "Go back" restores the version before.
- The update is checked twice before it is used: the whole zip against the fingerprint the release names, and every file inside against
  its own fingerprint. A half-downloaded or changed file is never installed.
- It never installs while a checkout runs. It installs only when you press Install.
The release itself is built by the same rules (build_release below): it can only ever hold program files."""
import hashlib
import io
import json
import os
import re
import shutil
import subprocess
import sys
import threading
import time
import urllib.request
import zipfile

VERSION = "v112"
HERE = os.path.dirname(os.path.abspath(__file__))
SOURCE_FILE = "update_source.txt"           # optional: the address of latest.json (else UPDATE_URL)
UPDATE_URL = "https://raw.githubusercontent.com/stevenmanuel01-cloud/Restalker/main/latest.json"   # v102: the release home (public, program files only)
WORK = "_update"
CHECK_EVERY = 3600.0
MAX_ZIP = 60 * 1024 * 1024
PROGRAM_DIRS = ("buyer_engine", "reader_engine")
PROGRAM_TOP = ("stop_restalker.bat", "msrp.yaml", "new_products.yaml")
LOG = print
BUSY = None                                 # () -> a reason it must wait (a checkout runs), or "" (set by app.py)

state = {"checked_at": 0.0, "latest": None, "notes": "", "available": False, "error": "", "installing": False, "result": None,
         "last": None}
_lock = threading.Lock()


def vnum(v):
    m = re.fullmatch(r"v?(\d+)([a-z]?)", str(v or "").strip())
    return (int(m.group(1)), m.group(2)) if m else (0, "")


def source():
    try:
        u = open(os.path.join(HERE, SOURCE_FILE), encoding="utf-8").read().strip()
        if re.match(r"^https://[\w.-]+/\S+$", u):
            return u
    except Exception:
        pass
    return UPDATE_URL


def is_program_file(name):
    """The ONLY names an update may write. Everything else is yours."""
    n = str(name or "")
    if not n or n.startswith("/") or "\\" in n or ":" in n or any(p in ("", ".", "..") for p in n.split("/")):
        return False
    parts = n.split("/")
    if len(parts) == 1:
        return bool(re.fullmatch(r"[A-Za-z0-9_]+\.py", n)) or n in PROGRAM_TOP
    if parts[0] in PROGRAM_DIRS and len(parts) == 2:
        return bool(re.fullmatch(r"[A-Za-z0-9_.-]+\.(js|json|html|css|png)", parts[1]))
    return False


def data_files():
    """Your data in this folder (copied aside before every update): everything at the top that is not a program file, plus icons."""
    out = []
    for n in sorted(os.listdir(HERE)):
        p = os.path.join(HERE, n)
        if os.path.isfile(p) and not is_program_file(n) and os.path.getsize(p) < 200 * 1024 * 1024:
            out.append(n)
    return out


def _sha(b):
    return hashlib.sha256(b).hexdigest()


def _get(url, limit, timeout=30):
    req = urllib.request.Request(url, headers={"User-Agent": "Restalker-updater", "Cache-Control": "no-cache"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        b = r.read(limit + 1)
    if len(b) > limit:
        raise ValueError("too big")
    return b


FETCH = _get


def check(now=None):
    """Asks the release home what the newest version is. -> state (never raises)."""
    url = source()
    now = now or time.time()
    with _lock:
        state["checked_at"] = now
        if not url:
            state.update(available=False, error="", latest=None)
            return dict(state)
    try:
        d = json.loads(FETCH(url, 256 * 1024, 20).decode("utf-8", "replace"))
        v = str(d.get("version") or "")
        if not vnum(v)[0] or not str(d.get("url") or "").startswith("https://") or not re.fullmatch(r"[0-9a-f]{64}", str(d.get("sha256") or "")):
            raise ValueError("the release note is incomplete")
        with _lock:
            state.update(latest=d, error="", notes=str(d.get("notes") or "")[:400], available=vnum(v) > vnum(VERSION))
    except Exception as e:
        with _lock:
            state.update(error=f"could not check for updates: {str(e)[:100]}")
    return dict(state)


def _verify(zbytes, rel):
    """-> (version, {name: bytes}) or raises with a plain reason. Nothing is written here."""
    if _sha(zbytes) != rel["sha256"]:
        raise ValueError("the download does not match the release's fingerprint (incomplete or changed) - nothing was installed")
    z = zipfile.ZipFile(io.BytesIO(zbytes))
    names = [i.filename for i in z.infolist() if not i.is_dir()]
    mf = [n for n in names if n.endswith("/MANIFEST.json") and n.count("/") == 1]
    if len(mf) != 1:
        raise ValueError("the update has no list of its files - nothing was installed")
    top = mf[0].split("/")[0]
    man = json.loads(z.read(mf[0]).decode("utf-8"))
    files = man.get("files") or {}
    if str(man.get("version")) != str(rel["version"]) or not files:
        raise ValueError("the update's list does not belong to this release - nothing was installed")
    bad = [n for n in files if not is_program_file(n)]
    if bad:
        raise ValueError(f"the update names a file that is not a program file ({bad[0][:60]}) - REFUSED, nothing was installed")
    extra = [n for n in names if n != mf[0] and (not n.startswith(top + "/") or n[len(top) + 1:] not in files)]
    if extra:
        raise ValueError(f"the update holds a file it does not list ({extra[0][:60]}) - REFUSED, nothing was installed")
    out = {}
    for n, h in files.items():
        try:
            b = z.read(top + "/" + n)
        except KeyError:
            raise ValueError(f"the update lists {n[:60]} but does not hold it - nothing was installed")
        if _sha(b) != h:
            raise ValueError(f"{n[:60]} does not match its fingerprint - nothing was installed")
        out[n] = b
    for must in ("app.py",):
        if must not in out:
            raise ValueError("the update has no app.py - nothing was installed")
    return str(rel["version"]), out


def install(restart=True):
    """Download, check, copy your data aside, put the new program files in place (all or none), restart. -> {"ok", "text"}"""
    with _lock:
        if state["installing"]:
            return {"ok": False, "text": "an update is being installed already"}
        rel = state.get("latest")
        if not rel or not state.get("available"):
            return {"ok": False, "text": "no newer version is known - press Check first"}
        state["installing"] = True
    try:
        why = BUSY() if BUSY else ""
        if why:
            return {"ok": False, "text": f"not now: {why}. Press Install again in a minute."}
        zb = FETCH(rel["url"], MAX_ZIP, 120)
        ver, files = _verify(zb, rel)
        stamp = time.strftime("%Y%m%d-%H%M%S")
        work = os.path.join(HERE, WORK)
        dback = os.path.join(work, f"data_backup_{stamp}")
        pback = os.path.join(work, f"program_{VERSION}_{stamp}")
        os.makedirs(dback, exist_ok=True)
        for n in data_files():
            try:
                shutil.copy2(os.path.join(HERE, n), os.path.join(dback, n))
            except Exception:
                pass
        if os.path.isdir(os.path.join(HERE, "icons")):
            try:
                shutil.copytree(os.path.join(HERE, "icons"), os.path.join(dback, "icons"))
            except Exception:
                pass
        stage = os.path.join(work, f"new_{ver}_{stamp}")
        for n, b in files.items():
            p = os.path.join(stage, *n.split("/"))
            os.makedirs(os.path.dirname(p), exist_ok=True)
            with open(p, "wb") as f:
                f.write(b)
        done, added = [], []
        try:
            for n in files:
                dst = os.path.join(HERE, *n.split("/"))
                if not os.path.exists(dst):
                    added.append(n)
                else:
                    bp = os.path.join(pback, *n.split("/"))
                    os.makedirs(os.path.dirname(bp), exist_ok=True)
                    shutil.copy2(dst, bp)
                os.makedirs(os.path.dirname(dst), exist_ok=True)
                os.replace(os.path.join(stage, *n.split("/")), dst)
                done.append(n)
        except Exception as e:
            _restore(pback, done)
            return {"ok": False, "text": f"the update could not be put in place ({str(e)[:80]}) - the version before is back, nothing changed"}
        rec = {"from": VERSION, "to": ver, "at": time.time(), "backup": os.path.relpath(pback, HERE), "data_backup": os.path.relpath(dback, HERE),
               "files": len(done), "added": added}
        with open(os.path.join(work, "last_update.json"), "w", encoding="utf-8") as f:
            json.dump(rec, f)
        shutil.rmtree(stage, ignore_errors=True)
        _prune(work)
        LOG(f"[update] {VERSION} -> {ver}: {len(done)} program files replaced; your data was not touched (a copy of it: {rec['data_backup']}).")
        with _lock:
            state["result"] = rec
        if restart:
            threading.Timer(1.5, _restart).start()
        return {"ok": True, "text": f"{ver} is installed ({len(done)} program files). Restalker restarts now - this page reloads by itself.", "to": ver}
    except Exception as e:
        LOG(f"[update] not installed: {str(e)[:160]}")
        return {"ok": False, "text": str(e)[:200]}
    finally:
        with _lock:
            state["installing"] = False


def _restore(pback, names):
    for n in names:
        bp = os.path.join(pback, *n.split("/"))
        dst = os.path.join(HERE, *n.split("/"))
        try:
            if os.path.exists(bp):
                shutil.copy2(bp, dst)
            else:
                os.remove(dst)                 # (a file this update added: gone again)
        except Exception:
            pass


def last():
    try:
        with open(os.path.join(HERE, WORK, "last_update.json"), encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return None


def go_back(restart=True):
    """The program files as they were before the last update (your data is not touched)."""
    rec = last()
    if not rec:
        return {"ok": False, "text": "there is no update to go back from"}
    pback = os.path.join(HERE, rec["backup"])
    if not os.path.isdir(pback):
        return {"ok": False, "text": "the copy of the version before is gone"}
    n = 0
    for a in rec.get("added") or []:            # (a program file the update added - nothing of yours)
        if is_program_file(a):
            try:
                os.remove(os.path.join(HERE, *a.split("/")))
            except Exception:
                pass
    for root, _, fs in os.walk(pback):
        for f in fs:
            rel = os.path.relpath(os.path.join(root, f), pback).replace("\\", "/")
            if is_program_file(rel):
                shutil.copy2(os.path.join(root, f), os.path.join(HERE, *rel.split("/")))
                n += 1
    try:
        os.remove(os.path.join(HERE, WORK, "last_update.json"))
    except Exception:
        pass
    LOG(f"[update] back to {rec['from']}: {n} program files restored.")
    if restart:
        threading.Timer(1.5, _restart).start()
    return {"ok": True, "text": f"Back to {rec['from']}. Restalker restarts now."}


def _prune(work, keep=3):
    """Only the newest 3 copies of each kind are kept."""
    try:
        for pre in ("data_backup_", "program_"):
            ds = sorted(d for d in os.listdir(work) if d.startswith(pre))
            for d in ds[:-keep]:
                shutil.rmtree(os.path.join(work, d), ignore_errors=True)
    except Exception:
        pass


RESTART_BAT = """@echo off
rem Restalker update: starts the new version once the old one has closed (written by the update; safe to delete).
title Restalker - starting the new version
ping 127.0.0.1 -n 9 >nul
cd /d "%~dp0.."
if exist "start_app.bat" (
  start "" "start_app.bat"
) else (
  start "" /min py app.py
)
"""
SHUTDOWN = None          # v104: set by app.py - closes the program the normal way (every browser, then itself, exit 0)


FLAG = "restarted_for_update.txt"
FLAG_FRESH = 300.0


def _flag_write():
    try:
        os.makedirs(os.path.join(HERE, WORK), exist_ok=True)
        with open(os.path.join(HERE, WORK, FLAG), "w") as f:
            f.write(str(time.time()))
    except Exception:
        pass


def restarted_for_update(now=None):
    """v106: -> True once, when this start is the restart after an update (the page that was open reconnects by itself: no second tab)."""
    p = os.path.join(HERE, WORK, FLAG)
    try:
        t = float(open(p).read().strip() or 0)
    except Exception:
        return False
    try:
        os.remove(p)
    except Exception:
        pass
    return 0 <= (now or time.time()) - t <= FLAG_FRESH


def _restart():
    """v104 (owner 2026-11-06: "the program started to install, but froze up. the program stopped completely"): v102/v103 started
    start_app.bat INSIDE the program's own Windows job - start_app.bat then closed the old copy, and Windows ended everything in that job
    with it: the new copy too. Now: a small starter (_update/restart.bat) is started OUTSIDE the job and the program's process tree; it
    waits 8 seconds and opens start_app.bat. Meanwhile the program closes itself the normal way (every browser, then itself, exit 0)."""
    if os.environ.get("RK_TEST_NOEXIT"):
        return
    _flag_write()
    try:
        if os.name == "nt":
            import lifeline
            work = os.path.join(HERE, WORK)
            os.makedirs(work, exist_ok=True)
            rb = os.path.join(work, "restart.bat")
            with open(rb, "w", encoding="ascii", newline="\r\n") as f:
                f.write(RESTART_BAT)
            lifeline.release_reaper()
            if not lifeline.start_outside(rb, HERE):
                LOG("[update] could not start the new version by itself - close the black window and open start_app.bat")
                return
            LOG("[update] the new version starts in a few seconds - this copy closes now.")
        else:
            subprocess.Popen(["sh", "-c", 'sleep 4; exec "$0" "$@"', sys.executable] + sys.argv, cwd=HERE, start_new_session=True,
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, stdin=subprocess.DEVNULL)
        if SHUTDOWN:
            SHUTDOWN()
        else:
            os._exit(0)
    except Exception as e:
        LOG(f"[update] could not restart by itself ({e}) - close the black window and open start_app.bat")


def loop(stop=None):
    time.sleep(60)
    while not (stop and stop.is_set()):
        if source():
            check()
        time.sleep(CHECK_EVERY)


def start():
    threading.Thread(target=loop, daemon=True, name="updater").start()


def brief():
    s = dict(state)
    s["connected"] = bool(source())
    s["version"] = VERSION
    s["latest_version"] = (s.get("latest") or {}).get("version")
    s.pop("latest", None)
    s["last"] = last()
    return s


# ---------------------------------------------------------------- building a release (by the same rules)
def build_release(src_dir, version, zip_url, notes=""):
    """-> (zip bytes, latest.json text). Takes ONLY program files from src_dir; refuses if a program file carries anything personal."""
    files = {}
    for n in sorted(os.listdir(src_dir)):
        if os.path.isfile(os.path.join(src_dir, n)) and is_program_file(n):
            files[n] = open(os.path.join(src_dir, n), "rb").read()
    for d in PROGRAM_DIRS:
        dd = os.path.join(src_dir, d)
        if os.path.isdir(dd):
            for n in sorted(os.listdir(dd)):
                if os.path.isfile(os.path.join(dd, n)) and is_program_file(d + "/" + n):
                    files[d + "/" + n] = open(os.path.join(dd, n), "rb").read()
    if "app.py" not in files:
        raise ValueError("no app.py")
    top = f"restalker_{version}"
    man = {"version": version, "files": {n: _sha(b) for n, b in files.items()}}
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        for n, b in files.items():
            z.writestr(f"{top}/{n}", b)
        z.writestr(f"{top}/MANIFEST.json", json.dumps(man, indent=1))
    zb = buf.getvalue()
    latest = {"version": version, "url": zip_url, "sha256": _sha(zb), "size": len(zb), "notes": notes, "files": len(files)}
    return zb, json.dumps(latest, indent=1)
