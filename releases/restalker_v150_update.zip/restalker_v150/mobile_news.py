"""Restalker Mobile (the Android app) news on your phone (v121).

Owner 2026-11-16: "when it's ready, you can send me an ntfy notification with the link to download the app".
The app's newest tested version is announced in the release home's mobile/latest.json (written only after the app passed all its tests).
Restalker reads that small file 2 minutes after it starts and then once an hour; when it names a version this Restalker has not told you
about yet, ONE phone message is sent through your own Restalker channel (tap it to download the app). It is told once per version
(mobile_told.txt); nothing is downloaded or installed on the PC.

v123 - Restalker news (owner 2026-11-16: "It is highly desired that you are able to work on this as much as possible without me
having to log into these various things to check. This is also why the notifications are helpful, so that I know when my input is
needed"): the release home's notices.json holds short messages about Restalker. Every 10 minutes Restalker reads it and sends each NEW
message (by its number, notices_told.txt) to your phone once. Only messages from the last 2 days; a message can be meant for one
Restalker only ("for": the first 16 letters of the sha256 of its report code - the code itself is never published). Plain text only;
a link is passed on only when it points into the Restalker release home.
"""
import hashlib
import json
import os
import threading
import time
import urllib.request

VERSION = "v150"
URL = "https://raw.githubusercontent.com/stevenmanuel01-cloud/Restalker/main/mobile/latest.json"
TOLD_FILE = "mobile_told.txt"
NOTICES_URL = "https://raw.githubusercontent.com/stevenmanuel01-cloud/Restalker/main/notices.json"
NOTICES_TOLD = "notices_told.txt"
LINK_OK = "https://github.com/stevenmanuel01-cloud/Restalker/"
FIRST_WAIT = 120
EVERY = 3600
NOTICE_EVERY = 600
NOTICE_MAX_AGE = 2 * 86400
_st = {"started": False, "last": "", "told": 0, "error": "", "notices": 0, "nerror": ""}
LOG = None


def told():
    try:
        return int(open(TOLD_FILE, encoding="utf-8").read().strip() or 0)
    except Exception:
        return 0


def _fetch(url=None):
    req = urllib.request.Request((url or URL) + "?t=%d" % int(time.time()), headers={"User-Agent": "Restalker/" + VERSION, "Cache-Control": "no-cache"})
    with urllib.request.urlopen(req, timeout=20) as r:
        return json.loads(r.read().decode("utf-8"))


SELF_UPDATE_WAIT = 12 * 3600      # v128: the phone looks for updates every 3 hours and tells the PC its version within the hour after - so 12 h (was 3)
SEEN_FILE = "mobile_news_seen.json"


def _first_seen(code, t):
    """When this app version was first seen in latest.json (here)."""
    try:
        with open(SEEN_FILE, encoding="utf-8") as f:
            d = json.load(f)
    except Exception:
        d = {}
    if str(code) not in d:
        d = {str(code): t}
        try:
            with open(SEEN_FILE, "w", encoding="utf-8") as f:
                json.dump(d, f)
        except OSError:
            pass
    return float(d[str(code)])


def _mark_told(code):
    with open(TOLD_FILE, "w", encoding="utf-8") as f:
        f.write(str(code))
    _st["told"] = code


def check(fetch=None, send=None, now=None):
    """Reads the app's latest.json; tells the phone once about a version not told yet. Returns the version told, or ''."""
    try:
        d = (fetch or _fetch)()
        code = int(d.get("code") or 0)
        ver = str(d.get("version") or "")[:12]
        apk = str(d.get("apk") or "")
        if not (code > 0 and ver and apk.startswith("https://github.com/stevenmanuel01-cloud/Restalker/releases/download/")):
            _st["error"] = "the app's latest.json is not complete"
            return ""
        _st["last"] = ver
        _st["error"] = ""
        if code <= told():
            return ""
        # v127 (owner: "I just got a ntfy notification that v1.8 is ready, but i have already been running that version"): the app
        # updates itself now. A message only when a linked phone has NOT updated itself 3 hours after the release was seen here (or when
        # no phone is linked: then nobody else tells you). A phone that already runs it gets nothing.
        t = time.time() if now is None else now
        seen = _first_seen(code, t)
        try:
            import phonelink
            ph = phonelink.phones()
        except Exception:
            ph = []
        if ph:
            behind = [p for p in ph if int(p.get("av") or 0) < code]
            if not behind:
                _mark_told(code)
                if LOG:
                    LOG(f"[mobile] Restalker Mobile v{ver}: every linked phone already runs it - no message.")
                return ""
            if t - seen < SELF_UPDATE_WAIT:
                return ""                                 # (it is updating itself)
        if send is None:
            import notify
            send = notify.send
        # v132 (owner 2026-11-17: an old Chrome tab with the app's FILE kept offering "download v1.8" in every new tab, and a "waiting for
        # Chrome" notice stayed): the message opens the release PAGE, never the file itself - nothing downloads by itself
        page = "https://github.com/stevenmanuel01-cloud/Restalker/releases/tag/mobile-v%s" % ver
        send("Restalker Mobile v%s is ready" % ver,
             ("Your phone has not updated itself yet: open the Restalker app and tap Allow on the yellow line (once), or tap this message "
              "to open its download page." if ph else
              "The phone app passed all its tests. Tap this message on your Android phone to open its download page, then tap the .apk file there."),
             key=None, link=page)
        _mark_told(code)
        if LOG:
            LOG(f"[mobile] Restalker Mobile v{ver} announced on your phone (download link).")
        return ver
    except Exception as e:
        _st["error"] = str(e)[:120]
        return ""


def notices_told():
    try:
        return int(open(NOTICES_TOLD, encoding="utf-8").read().strip() or 0)
    except Exception:
        return 0


def _mine(code):
    return hashlib.sha256(str(code or "").encode("utf-8")).hexdigest()[:16]


def _clean(t, n):
    t = "".join(ch if ch.isprintable() or ch == "\n" else " " for ch in str(t or ""))
    return t.strip()[:n]


def check_notices(fetch=None, send=None, now=None, my_code=None):
    """Sends each new message of notices.json to the phone once. Returns how many were sent."""
    try:
        d = (fetch or (lambda: _fetch(NOTICES_URL)))()
        notes = d.get("notes") if isinstance(d, dict) else None
        if not isinstance(notes, list):
            _st["nerror"] = "notices.json is not complete"
            return 0
        t = time.time() if now is None else now
        if my_code is None:
            try:
                import report
                my_code = report.code()
            except Exception:
                my_code = ""
        done, sent = notices_told(), 0
        for n in sorted((x for x in notes if isinstance(x, dict)), key=lambda x: int(x.get("id") or 0) if str(x.get("id") or "").isdigit() else 0):
            nid = int(n.get("id") or 0) if str(n.get("id") or "").isdigit() else 0
            if nid <= done:
                continue
            done = nid                                   # (told or skipped - never looked at again)
            try:
                at = float(n.get("at") or 0)
            except Exception:
                at = 0
            if not at or t - at > NOTICE_MAX_AGE or at - t > 3600:
                continue
            if n.get("for") and str(n.get("for")) != _mine(my_code):
                continue
            title, text = _clean(n.get("title"), 80), _clean(n.get("text"), 600)
            if not title or not text:
                continue
            link = str(n.get("link") or "")
            link = link if link.startswith(LINK_OK) and len(link) < 300 else None
            if send is None:
                import notify
                send = notify.send
            send("Restalker: " + title, text, key=None, link=link)          # (v145: the program's words name no one)
            sent += 1
            if LOG:
                LOG(f"[news] message {nid} sent to your phone: {title}")
        if done > notices_told():
            with open(NOTICES_TOLD, "w", encoding="utf-8") as f:
                f.write(str(done))
        _st["notices"] += sent
        _st["nerror"] = ""
        return sent
    except Exception as e:
        _st["nerror"] = str(e)[:120]
        return 0


def _loop():
    time.sleep(FIRST_WAIT)
    i = 0
    while True:
        if i % (EVERY // NOTICE_EVERY) == 0:
            check()
        check_notices()
        i += 1
        time.sleep(NOTICE_EVERY)


def start(log=None):
    global LOG
    LOG = log
    if not _st["started"]:
        _st["started"] = True
        threading.Thread(target=_loop, daemon=True, name="mobile-news").start()


def status():
    return (f"phone app news (v121): newest app v{_st['last'] or '?'}; told up to version code {told()}"
            + (f"; last problem: {_st['error']}" if _st["error"] else "")
            + f"\nRestalker news (v123): {_st['notices']} sent this run; told up to number {notices_told()}"
            + (f"; last problem: {_st['nerror']}" if _st["nerror"] else ""))
