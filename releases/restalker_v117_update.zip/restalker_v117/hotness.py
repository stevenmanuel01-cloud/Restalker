"""What may slow a look down. Since v50 NOTHING slows reading down because of CPU load or the number of added products.

v50 (the owner's instruction): "nobody told you to slow things down ... if there is a realistic limit to be protected, limit the number
of products and/or stores polled". So the old CPU guard (x2 / x4 above 450% / 600%), the whole-PC guard, the program-memory guard and the
per-store looks-per-minute budget for added products are all GONE. What is left:
  1. A page that has been unreadable many checks in a row is looked at only once a minute (it gives no data; it is retried, so it recovers).
  2. Gaming mode (the owner's own switch, or automatic game detection): the extra readers rest and added products are looked at less often.
  3. A real emergency: the whole PC has under MEM_CRIT_GB of free memory -> the EXTRA readers of each store rest (their browsers are closed)
     until MEM_RESUME_GB is free again. That limits the number of readers, never the pace of the first one at each store.
A product is "hot" (looked at again at once, ahead of everything else) when a tracker has just alerted for it, or it is in stock / just changed."""
import csv, os, time, threading
from datetime import datetime, timezone

VERSION = "v117"
UNREADABLE_AFTER = 10      # unreadable checks in a row before slowing down
UNREADABLE_EVERY = 60.0    # seconds between looks at a page that cannot be read
# ---- used ONLY while Gaming mode is on (the owner's switch / game detection); otherwise nothing below slows anything ----
CALM_EVERY = 30.0          # Gaming mode: seconds between looks at a heavy Target page when nothing is expected
EXTRA_INSTOCK_EVERY = 15.0   # Gaming mode: an added product that is already in stock is looked at this often
EXTRA_CALM = {"target": 30.0, "walmart": 60.0, "amazon": 30.0, "gamestop": 30.0}      # Gaming mode: seconds between looks at an added product (before GAMING_X)
GAMING_X = 4.0             # Gaming mode: added products are looked at this much less often
GAMING_CALM_X = 2.0        # Gaming mode: Target pages that are drawn are looked at this much less often too
MEM_CRIT_GB = 1.5          # the WHOLE PC has less free memory than this (lowest of the last 2 minutes): the extra readers rest ...
MEM_RESUME_GB = 3.0        # ... until this much is free again. (Free memory, not used: Windows keeps spare memory busy as cache and gives it back.)
MEM_RELIEF_GB = 2.5        # under this much free memory one store's browser at a time is restarted (the leakiest first) - see _memory_relief
HOT_FOR = 900.0            # a tracker alert keeps a product hot this long
HALF_WINDOW = 1200.0       # "about this time of day" = within 20 minutes
MIN_DAYS = 2               # on at least this many different days
LOOKBACK = 21 * 86400
REFRESH = 600.0

_hot = {}
_poke = {}
_cheap = {}      # v44: stores whose products are all read with ONE small shared request (extras there cost nothing, so no calm pause)
_game = {"on": False, "mode": "auto", "auto": False, "reason": ""}      # on = what is in effect; mode = your switch (auto / on / off); auto = what game detection says
_lock = threading.Lock()


def _recompute():
    m = _game["mode"]
    _game["on"] = True if m == "on" else False if m == "off" else bool(_game["auto"])
    _gov["at"] = 0.0          # re-evaluate at once


def set_mode(mode):
    """'auto' (the program notices a game by itself), 'on' (always) or 'off' (never)."""
    _game["mode"] = mode if mode in ("auto", "on", "off") else "auto"
    _recompute()


def set_auto(on, reason=""):
    _game["auto"] = bool(on)
    _game["reason"] = reason if on else ""
    _recompute()


def mode():
    return _game["mode"]


def auto_reason():
    return _game["reason"]


def gaming():
    return bool(_game["on"])


def set_cheap(store, on):
    _cheap[store] = bool(on)


def is_cheap(store):
    return bool(_cheap.get(store))


_why = {}                 # v105: item -> (time, what the tracker said) - kept with the readings that follow (sweep.CAPTURES)


def mark(item, secs=HOT_FOR, why=""):
    """A tracker just alerted for this product: look at it at full speed for a while - and look at it RIGHT NOW."""
    with _lock:
        _hot[item] = max(_hot.get(item, 0), time.time() + secs)
        _poke[item] = time.time()
        if why:
            _why[item] = (time.time(), str(why)[:220])


def why_of(item, since=0.0):
    """-> (time, what the tracker said) of its newest alert for this product if newer than `since`, else (0.0, '')."""
    with _lock:
        t, w = _why.get(item, (0.0, ""))
    return (t, w) if t > since else (0.0, "")


def poked_since(item, since):
    """-> the time of a tracker alert for this product that is newer than `since`, else 0. (The checker uses it to pull the
    next look forward to now, instead of waiting out the calm pause.)"""
    with _lock:
        t = _poke.get(item, 0.0)
    return t if t > since else 0.0


def is_hot(item, now=None):
    with _lock:
        return (now or time.time()) < _hot.get(item, 0)


def _parse(ts):
    try:
        return datetime.fromisoformat(ts.replace("Z", "+00:00")).astimezone(timezone.utc).timestamp()
    except Exception:
        return None


def _read(path, item_col, kind=None):
    out = {}
    try:
        with open(path, newline="", encoding="utf-8", errors="replace") as f:
            r = csv.reader(f)
            next(r, None)
            for row in r:
                if len(row) <= item_col + 1:
                    continue
                if kind and len(row) > 2 and row[2] != kind:
                    continue
                t = _parse(row[0])
                if t:
                    out.setdefault(row[item_col], []).append(t)
    except Exception:
        pass
    return out


class History:
    """Times (of day) at which each product has restocked or had a tracker alert before."""
    def __init__(self, gt_path="ground_truth.csv", alerts_path="alerts.csv"):
        self.gt_path, self.alerts_path = gt_path, alerts_path
        self.events = {}
        self.loaded_at = 0.0

    def refresh(self, now=None):
        now = now or time.time()
        if now - self.loaded_at < REFRESH:
            return
        self.loaded_at = now
        ev = _read(self.gt_path, 1, "RESTOCK")
        for k, v in _read(self.alerts_path, 2).items():
            ev.setdefault(k, []).extend(v)
        self.events = ev

    def expected(self, item, now=None):
        """True if, at about this time of day, this product restocked / was alerted on at least MIN_DAYS different days."""
        now = now or time.time()
        tod = now % 86400
        days = set()
        for t in self.events.get(item, ()):
            if now - t > LOOKBACK or t > now:
                continue
            d = abs((t % 86400) - tod)
            d = min(d, 86400 - d)
            if d <= HALF_WINDOW:
                days.add(int(t // 86400))
        return len(days) >= MIN_DAYS


_gov = {"at": 0.0, "factor": 1.0, "avg": 0.0, "pc": None, "free_gb": None, "prog_gb": None, "pc_other": None}
_shed = {"on": False, "since": 0.0}      # v50: True while the PC is out of free memory and the extra readers rest


def extra_calm(store):
    """Seconds between looks at one added product. v50: 0 - an added product is looked at exactly like an original one.
    Only in Gaming mode are added products looked at less often (their old calm pause times GAMING_X)."""
    if not _game["on"]:
        return 0.0
    return (EXTRA_CALM.get(store) or 0.0) * GAMING_X


def lanes_may_run(lane, free_gb=None, store=None):
    """v50: may the `lane`-th reader of a store (0 = the store's main checker, which always runs) read right now? -> (ok, why).
    The extra readers rest in Gaming mode, in an emergency (the whole PC has under MEM_CRIT_GB free; they come back at MEM_RESUME_GB) and
    - v51 - when the owner's speed setting (loadplan.py) has no room for them. Never a slower pace: a reader either reads at full pace or rests."""
    if lane <= 0:
        return True, ""
    if _game["on"]:
        return False, "Gaming mode"
    if store:
        try:
            import loadplan
            if not loadplan.lane_allowed(store, lane):
                return False, "no room under your speed setting yet"
        except Exception:
            pass
    if free_gb is None:
        governor()
        free_gb = _gov.get("free_gb")
    if free_gb is not None:
        if free_gb < MEM_CRIT_GB:
            if not _shed["on"]:
                _shed["on"], _shed["since"] = True, time.time()
        elif free_gb >= MEM_RESUME_GB:
            _shed["on"] = False
    if _shed["on"]:
        return False, f"the PC has under {MEM_CRIT_GB:g} GB of free memory"
    return True, ""


def scouts_may_run(index):
    """Kept for the scouts (the older second readers): they follow the same rule as the extra readers, minus Gaming mode (handled by them)."""
    if index <= 0:
        return True, ""
    if _game["on"]:
        return True, ""
    return lanes_may_run(index)


def all_scouts_rest():
    return False


def governor_factor(own=0.0, pc=None, gaming_on=False, free_gb=None, prog_gb=None):
    """v50: x4 in Gaming mode, x1 otherwise. (CPU load, the PC's load and the program's memory no longer slow anything; the arguments
    are accepted only so older callers keep working.)"""
    return GAMING_X if gaming_on else 1.0


def governor(now=None):
    """-> (factor, recent average CPU). The factor is x4 in Gaming mode and x1 otherwise. The CPU / memory numbers are still measured
    (they are shown in the diagnostics) but they do not slow anything."""
    now = now or time.time()
    if now - _gov["at"] < 30:
        return _gov["factor"], _gov["avg"]
    _gov["at"] = now
    avg, pc, free, prog = 0.0, None, None, None
    try:
        import cpu_monitor
        avg = cpu_monitor.recent_avg(5)
        pc = cpu_monitor.pc_busy_avg(3)
        free = cpu_monitor.pc_free_gb(2)
        prog = cpu_monitor.mine_gb(2)
    except Exception:
        avg, pc, free, prog = 0.0, None, None, None
    _gov["avg"], _gov["pc"], _gov["free_gb"], _gov["prog_gb"] = avg, pc, free, prog
    pc_other = pc
    try:
        if pc is not None:
            cores = cpu_monitor._STATE.get("cores") or 1
            pc_other = max(0.0, pc - avg / float(cores))
    except Exception:
        pc_other = pc
    _gov["pc_other"] = pc_other
    _gov["factor"] = governor_factor(avg, pc_other, _game["on"], free, prog)
    return _gov["factor"], avg


def pace_floor(store, fetch_mode, status, unread_run, item, hist, now=None, heavy=False, extra=False):
    """-> (minimum seconds until the next look at this product, state name). 0 = no slowing.
    v50: the ONLY slowing outside Gaming mode is a page that cannot be read at all (it gives no data)."""
    now = now or time.time()
    if status == "UNKNOWN" and unread_run >= UNREADABLE_AFTER:
        return UNREADABLE_EVERY, "unreadable"
    if not _game["on"]:
        return 0.0, ("hot" if status == "IN_STOCK" else "normal")
    # ---- Gaming mode only (the owner switched it on, or a game was detected) ----
    if status == "IN_STOCK":
        if extra and not is_hot(item, now):
            return EXTRA_INSTOCK_EVERY, "instock"
        return 0.0, "hot"
    if extra and store in EXTRA_CALM and not _cheap.get(store):
        if is_hot(item, now):
            return 0.0, "hot"
        try:
            hist.refresh(now)
            if hist.expected(item, now):
                return 0.0, "expected"
        except Exception:
            return 0.0, "normal"
        return extra_calm(store), "calm"
    if store == "target" and (fetch_mode == "browser" or heavy) and status == "OUT_OF_STOCK":
        if is_hot(item, now):
            return 0.0, "hot"
        try:
            hist.refresh(now)
            if hist.expected(item, now):
                return 0.0, "expected"
        except Exception:
            return 0.0, "normal"
        return CALM_EVERY * GAMING_CALM_X, "calm"
    return 0.0, "normal"
