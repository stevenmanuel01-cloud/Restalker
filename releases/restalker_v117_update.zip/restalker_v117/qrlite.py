"""A small QR-code maker (no downloads, no extra programs): text in, picture (SVG) out. Byte mode, versions 1-10, error level L or M."""
VERSION = "v117"

# version -> (EC codewords per block, [(blocks, data codewords per block), ...])
_EC = {
    "L": {1: (7, [(1, 19)]), 2: (10, [(1, 34)]), 3: (15, [(1, 55)]), 4: (20, [(1, 80)]), 5: (26, [(1, 108)]),
          6: (18, [(2, 68)]), 7: (20, [(2, 78)]), 8: (24, [(2, 97)]), 9: (30, [(2, 116)]), 10: (18, [(2, 68), (2, 69)])},
    "M": {1: (10, [(1, 16)]), 2: (16, [(1, 28)]), 3: (26, [(1, 44)]), 4: (18, [(2, 32)]), 5: (24, [(2, 43)]),
          6: (16, [(4, 27)]), 7: (18, [(4, 31)]), 8: (22, [(2, 38), (2, 39)]), 9: (22, [(3, 36), (2, 37)]), 10: (26, [(4, 43), (1, 44)])},
}
_ALIGN = {1: [], 2: [6, 18], 3: [6, 22], 4: [6, 26], 5: [6, 30], 6: [6, 34], 7: [6, 22, 38], 8: [6, 24, 42], 9: [6, 26, 46], 10: [6, 28, 50]}
_FMT_BITS = {"L": 1, "M": 0}

# GF(256) arithmetic for Reed-Solomon
_EXP, _LOG = [0] * 512, [0] * 256
_x = 1
for _i in range(255):
    _EXP[_i] = _x
    _LOG[_x] = _i
    _x <<= 1
    if _x & 0x100:
        _x ^= 0x11D
for _i in range(255, 512):
    _EXP[_i] = _EXP[_i - 255]


def _gmul(a, b):
    return 0 if a == 0 or b == 0 else _EXP[_LOG[a] + _LOG[b]]


def _rs_generator(n):
    g = [1]
    for i in range(n):
        ng = [0] * (len(g) + 1)
        for j, c in enumerate(g):
            ng[j] ^= c
            ng[j + 1] ^= _gmul(c, _EXP[i])
        g = ng
    return g


def _rs_remainder(data, n):
    gen = _rs_generator(n)
    rem = [0] * n
    for b in data:
        f = b ^ rem[0]
        rem = rem[1:] + [0]
        if f:
            for i in range(n):
                rem[i] ^= _gmul(gen[i + 1], f)
    return rem


def _capacity(ver, ec):
    n_data = sum(c * d for c, d in _EC[ec][ver][1])
    return (n_data * 8 - 4 - (16 if ver >= 10 else 8)) // 8


def _bits_for(data, ver, ec):
    bits = [0, 1, 0, 0]
    cnt = 16 if ver >= 10 else 8
    bits += [(len(data) >> (cnt - 1 - i)) & 1 for i in range(cnt)]
    for byte in data:
        bits += [(byte >> (7 - i)) & 1 for i in range(8)]
    total = sum(c * d for c, d in _EC[ec][ver][1]) * 8
    bits += [0] * min(4, total - len(bits))
    while len(bits) % 8:
        bits.append(0)
    pad = [0xEC, 0x11]
    k = 0
    while len(bits) < total:
        bits += [(pad[k % 2] >> (7 - i)) & 1 for i in range(8)]
        k += 1
    return [int("".join(map(str, bits[i:i + 8])), 2) for i in range(0, len(bits), 8)]


def _codewords(data, ver, ec):
    cw = _bits_for(data, ver, ec)
    ecn, groups = _EC[ec][ver]
    blocks, pos = [], 0
    for cnt, dlen in groups:
        for _ in range(cnt):
            blocks.append(cw[pos:pos + dlen])
            pos += dlen
    eblocks = [_rs_remainder(b, ecn) for b in blocks]
    out = []
    for i in range(max(len(b) for b in blocks)):
        for b in blocks:
            if i < len(b):
                out.append(b[i])
    for i in range(ecn):
        for b in eblocks:
            out.append(b[i])
    return out


def _bch(value, poly, total_bits, check_bits):
    v = value << check_bits
    for i in range(total_bits - 1, check_bits - 1, -1):
        if (v >> i) & 1:
            v ^= poly << (i - check_bits)
    return (value << check_bits) | v


def _build(cw, ver, ec, mask):
    n = ver * 4 + 17
    M = [[None] * n for _ in range(n)]          # None = data area
    F = [[False] * n for _ in range(n)]         # function-pattern flag

    def setf(r, c, v):
        if 0 <= r < n and 0 <= c < n:
            M[r][c] = bool(v)
            F[r][c] = True

    def finder(r0, c0):
        for dr in range(-1, 8):
            for dc in range(-1, 8):
                inside = 0 <= dr <= 6 and 0 <= dc <= 6
                dark = inside and (dr in (0, 6) or dc in (0, 6) or (2 <= dr <= 4 and 2 <= dc <= 4))
                setf(r0 + dr, c0 + dc, dark)
    finder(0, 0); finder(0, n - 7); finder(n - 7, 0)
    for i in range(8, n - 8):
        setf(6, i, i % 2 == 0)
        setf(i, 6, i % 2 == 0)
    pos = _ALIGN[ver]
    for r in pos:
        for c in pos:
            if (r == 6 and c == 6) or (r == 6 and c == pos[-1]) or (r == pos[-1] and c == 6):
                continue
            for dr in range(-2, 3):
                for dc in range(-2, 3):
                    setf(r + dr, c + dc, max(abs(dr), abs(dc)) != 1)
    setf(n - 8, 8, True)                        # the always-dark module
    # reserve format areas
    for i in range(9):
        for (r, c) in ((8, i), (i, 8)):
            if not F[r][c]:
                setf(r, c, False)
    for i in range(8):
        for (r, c) in ((8, n - 1 - i), (n - 1 - i, 8)):
            if not F[r][c]:
                setf(r, c, False)
    if ver >= 7:
        vi = _bch(ver, 0x1F25, 18, 12)
        for i in range(18):
            bit = (vi >> i) & 1
            a, b = i // 3, i % 3
            setf(a, n - 11 + b, bit)
            setf(n - 11 + b, a, bit)
    # place data bits in the zigzag
    bits = []
    for b in cw:
        bits += [(b >> (7 - i)) & 1 for i in range(8)]
    i = 0
    c = n - 1
    up = True
    while c > 0:
        if c == 6:
            c -= 1
        rows = range(n - 1, -1, -1) if up else range(n)
        for r in rows:
            for cc in (c, c - 1):
                if not F[r][cc]:
                    bit = bits[i] if i < len(bits) else 0
                    i += 1
                    inv = [(r + cc) % 2 == 0, r % 2 == 0, cc % 3 == 0, (r + cc) % 3 == 0, (r // 2 + cc // 3) % 2 == 0,
                           (r * cc) % 2 + (r * cc) % 3 == 0, ((r * cc) % 2 + (r * cc) % 3) % 2 == 0, ((r + cc) % 2 + (r * cc) % 3) % 2 == 0][mask]
                    M[r][cc] = bool(bit) ^ inv
        c -= 2
        up = not up
    # format information
    fmt = _bch((_FMT_BITS[ec] << 3) | mask, 0x537, 15, 10) ^ 0x5412
    def fb(k): return (fmt >> k) & 1
    for k in range(6): M[k][8] = bool(fb(k))
    M[7][8] = bool(fb(6)); M[8][8] = bool(fb(7)); M[8][7] = bool(fb(8))
    for k in range(9, 15): M[8][14 - k] = bool(fb(k))
    for k in range(8): M[8][n - 1 - k] = bool(fb(k))
    for k in range(8, 15): M[n - 15 + k][8] = bool(fb(k))
    M[n - 8][8] = True
    return M


def _penalty(M):
    n = len(M)
    p = 0
    for grid in (M, [list(r) for r in zip(*M)]):
        for row in grid:
            run, prev = 1, row[0]
            for v in row[1:]:
                if v == prev:
                    run += 1
                else:
                    if run >= 5: p += run - 2
                    run, prev = 1, v
            if run >= 5: p += run - 2
    for r in range(n - 1):
        for c in range(n - 1):
            if M[r][c] == M[r][c + 1] == M[r + 1][c] == M[r + 1][c + 1]:
                p += 3
    pat1 = [True, False, True, True, True, False, True, False, False, False, False]
    pat2 = pat1[::-1]
    for grid in (M, [list(r) for r in zip(*M)]):
        for row in grid:
            for i in range(n - 10):
                seg = row[i:i + 11]
                if seg == pat1 or seg == pat2:
                    p += 40
    dark = sum(v for row in M for v in row)
    p += (abs(dark * 20 - n * n * 10) // (n * n)) * 10
    return p


def make(text, ec="M"):
    """-> list of rows of booleans (True = dark module)."""
    data = text.encode("utf-8")
    for ver in range(1, 11):
        if len(data) <= _capacity(ver, ec):
            break
    else:
        raise ValueError("text too long for this QR maker")
    cw = _codewords(data, ver, ec)
    best = None
    for mask in range(8):
        M = _build(cw, ver, ec, mask)
        s = _penalty(M)
        if best is None or s < best[0]:
            best = (s, M)
    return best[1]


def svg(text, ec="M", scale=6, quiet=4):
    M = make(text, ec)
    n = len(M)
    size = (n + 2 * quiet) * scale
    rects = "".join(f'<rect x="{(c + quiet) * scale}" y="{(r + quiet) * scale}" width="{scale}" height="{scale}"/>'
                    for r in range(n) for c in range(n) if M[r][c])
    return (f'<svg xmlns="http://www.w3.org/2000/svg" width="{size}" height="{size}" viewBox="0 0 {size} {size}">'
            f'<rect width="{size}" height="{size}" fill="#fff"/><g fill="#000">{rects}</g></svg>')
