#!/usr/bin/env python3
"""
The self-contained restock latency benchmark app. Double-click
start_app.bat (Windows) — or run `python app.py` — and your browser
opens automatically. Everything happens there: add products and
trackers (tested live before saving), start/stop the watchers, see
live per-item status, and download diagnostics if something looks off.

Usage:
    pip install flask pyyaml requests beautifulsoup4 --break-system-packages
    python app.py [--port 8001]
"""
import argparse
import collections
import csv
import io
import json
import copy
import os
import re
import threading
import time
import webbrowser
from datetime import datetime, timezone

import yaml
from flask import Flask, request, redirect, url_for, jsonify, Response

from http_utils import fetch, burst_test
from browser_fetch import BrowserFetcher, PLAYWRIGHT_NOT_INSTALLED
from stock_detect import detect_availability
import ground_truth_poller
import tracker_feed_poller
import stock_detect
import browser_fetch
import http_utils
import samples
import recon
import cpu_monitor
import cpuprof
import lifeline
import push_listener
import discord_source
import phone_actions
import export
import history
import steady
import updater
import page_facts
import tcg_index
import linkcheck
import focus_guard
import notify
import reader_browser
import hotness
import products
import matrix
import matrix_ui
import qrlite
import thumbs
import audit
import sweep
import msrp
import finder
import gamedetect
import loadplan
import hygiene
import amazon_buy
import multibuy
import cardcode
import logins
import predict

KIT_VERSION = "v117"


def file_versions():
    """Which version each program file reports. A file copied from an
    older update reports nothing, which is how a half-finished update is
    caught instead of silently running old code."""
    mods = {"ground_truth_poller": ground_truth_poller, "tracker_feed_poller": tracker_feed_poller,
            "stock_detect": stock_detect, "browser_fetch": browser_fetch, "http_utils": http_utils,
            "samples": samples, "cpu_monitor": cpu_monitor, "recon": recon,
            "push_listener": push_listener, "discord_source": discord_source, "tcg_index": tcg_index, "linkcheck": linkcheck, "focus_guard": focus_guard, "notify": notify, "hotness": hotness, "qrlite": qrlite, "products": products, "matrix": matrix, "matrix_ui": matrix_ui, "thumbs": thumbs, "audit": audit, "msrp": msrp, "finder": finder, "gamedetect": gamedetect, "loadplan": loadplan, "hygiene": hygiene, "amazon_buy": amazon_buy, "cpuprof": cpuprof, "lifeline": lifeline, "sweep": sweep, "reader_browser": reader_browser, "multibuy": multibuy, "cardcode": cardcode, "predict": predict, "logins": logins, "phone_actions": phone_actions, "export": export, "history": history, "steady": steady, "updater": updater, "page_facts": page_facts}
    out = {"app": KIT_VERSION}
    for name, m in mods.items():
        out[name] = getattr(m, "VERSION", "OLD")
    return out


def old_files():
    return [n for n, v in file_versions().items() if v != KIT_VERSION]


_VER_RE = re.compile(r'^(?:KIT_)?VERSION\s*=\s*"([^"]+)"', re.M)
_VER_FILES = ("app", "ground_truth_poller", "tracker_feed_poller", "stock_detect", "browser_fetch",
              "http_utils", "samples", "cpu_monitor", "recon", "push_listener", "discord_source", "tcg_index", "linkcheck", "focus_guard", "notify", "hotness", "qrlite", "products", "matrix", "matrix_ui", "thumbs", "audit", "msrp", "finder", "gamedetect", "loadplan", "hygiene", "amazon_buy", "cpuprof", "lifeline", "sweep", "reader_browser", "multibuy", "phone_actions", "export")


def disk_version():
    """The version the files now sitting in the folder report (what the NEXT start will run), or None if unreadable.
    If this differs from KIT_VERSION, new files were copied in while the old program kept running."""
    here = os.path.dirname(os.path.abspath(__file__))
    found = set()
    try:
        for name in _VER_FILES:
            with open(os.path.join(here, name + ".py"), encoding="utf-8", errors="replace") as f:
                m = _VER_RE.search(f.read())      # whole file: the version line may sit far down (it did in ground_truth_poller.py)
            found.add(m.group(1) if m else "?")
    except Exception:
        return None
    if len(found) == 1:
        return found.pop()
    return "mixed (" + ", ".join(sorted(found)) + ")"

app = Flask(__name__)
TARGETS_PATH = "targets.yaml"
TRACKERS_PATH = "trackers.yaml"
GT_OUT = "ground_truth.csv"
ALERTS_OUT = "alerts.csv"
DEBUG_LOG_PATH = "debug.log"

LOG_LINES = collections.deque(maxlen=300)
LOG_LOCK = threading.Lock()
STATE = {"running": False, "stop_event": None, "threads": [], "started_at": None, "targets": None}
STATE_LOCK = threading.Lock()
STATUS = {"targets": {}, "trackers": {}}  # id -> dict of live fields
STATUS_LOCK = threading.Lock()
CONFIG_LOCK = threading.Lock()


_LOG_WRITES = [0]
LOG_MAX_BYTES = 8_000_000      # the log is kept in two pieces (debug.log and debug.log.1), so it can never fill the disk


def log(msg):
    with LOG_LOCK:
        LOG_LINES.append(msg)
        _LOG_WRITES[0] += 1
        try:
            if _LOG_WRITES[0] % 300 == 0 and os.path.getsize(DEBUG_LOG_PATH) > LOG_MAX_BYTES:
                os.replace(DEBUG_LOG_PATH, DEBUG_LOG_PATH + ".1")
        except OSError:
            pass
    try:
        with open(DEBUG_LOG_PATH, "a", encoding="utf-8", errors="replace") as f:
            f.write(f"{datetime.now(timezone.utc).isoformat()} {msg}\n")
    except Exception:
        pass  # diagnostics logging is best-effort, never fatal (not even for an odd character)
    if "RESTOCK DETECTED" in msg or "NEW MENTION" in msg:
        amazon_buy.from_log(msg)  # v54: an Amazon restock goes to Restalker's own buying browser FIRST (it buys only armed products, under the cap)
        notify.from_log(msg)      # phone message (the Windows pop-up is off unless notify_popup.txt exists): there is data worth downloading


notify.LOG = log              # each message's timings go to the log ("[notify] ...")


def _describe_target(tid):
    """What a phone message says about a product: store, name, MSRP and your price limit."""
    t = next((x for x in _targets_snapshot() if x["id"] == tid), None)
    if t is None:
        return None
    key = matrix.key_of(t)
    theme, kind = matrix.split_key(key)
    mi = msrp.for_row(key, {})
    tc = None
    try:
        tc = tcg_index.latest_for_row(key)
    except Exception:
        tc = None
    return {"store": matrix.store_name(matrix.store_of(t)), "product": f"{matrix.title_of(theme)} {matrix.label_of(kind, t.get('match_name', ''))}",
            "cap": t.get("max_price"), "msrp": mi["value"] if mi else None, "url": t.get("url"),
            "tcg": tc["market"] if tc and tc.get("market") else None}


notify.DESCRIBE = _describe_target


def _verify_target(tid):
    """The newest reading of a product's store page (for the alert: it is only sent once the page itself confirms the stock and price)."""
    with STATUS_LOCK:
        e = STATUS["targets"].get(tid)
        return dict(e) if e else None


notify.VERIFY = _verify_target


def report(kind, item_id, **fields):
    with STATUS_LOCK:
        bucket = STATUS.setdefault(kind + "s" if not kind.endswith("s") else kind, {})
        entry = bucket.setdefault(item_id, {})
        entry.update(fields)
        _st, _pr = entry.get("status"), entry.get("price")
        if fields.get("status") in ("IN_STOCK", "OUT_OF_STOCK"):          # v58: the last real answer stays visible while a store is re-read
            entry["last_good"] = {"status": fields["status"], "price": fields.get("price", _pr), "at": fields.get("checked_at") or time.time(),
                                  "high": bool(fields.get("high_price"))}     # v90: for sale but over the cap (shown orange)
            if kind.startswith("target"):
                try:                                    # v101: what the square shows - steady across the browsers (steady.py)
                    entry["show"] = steady.note(item_id, fields["status"], bool(fields.get("high_price")), fields.get("price"),
                                                fields.get("read_by") or fields.get("engine") or "")
                    _cap = steady.capture_wants_page(item_id)
                    if _cap is not None:
                        _keep_alert_page(_cap, item_id, fields.get("read_by") or "")
                except Exception:
                    pass
            if fields["status"] == "OUT_OF_STOCK":
                try:
                    notify.saw_out(item_id, fields.get("checked_at"))     # v65: the next time it comes in stock is a new restock
                except Exception:
                    pass
            elif kind.startswith("target"):
                try:
                    amazon_buy._wake.set()              # v68b: an IN STOCK reading starts the purchase NOW (not at the next 5-s round)
                except Exception:
                    pass
    if kind.rstrip("s") == "target" and "status" in fields and _pr not in (None, "") and _st != "INDEX":
        try:
            msrp.record(item_id, _st, _pr)          # every price seen is kept (price_stats.json) for the % over MSRP and the average
        except Exception:
            pass
    if fields.get("auto_upgraded"):
        _persist_fetch_mode(kind, item_id, fields.get("fetch_mode"))
    if fields.get("learned_sku") and kind.rstrip("s") == "target":       # v59b: a Best Buy link's product number, learned from its page
        try:
            with CONFIG_LOCK:
                cfg = load(TARGETS_PATH, "targets")
                for t in cfg["targets"]:
                    if t["id"] == item_id and not t.get("sku"):
                        t["sku"] = int(fields["learned_sku"])
                save(TARGETS_PATH, cfg)
        except Exception as e:
            log(f"[warn] could not save the learned Best Buy number for {item_id}: {e}")


def _persist_fetch_mode(kind, item_id, fetch_mode):
    """A poller thread auto-upgraded an item to browser mode mid-run
    after plain requests started failing — write that back to disk so
    it stays fixed on the next run too, not just this one."""
    with CONFIG_LOCK:
        if kind.rstrip("s") == "target":
            cfg = load(TARGETS_PATH, "targets")
            for t in cfg["targets"]:
                if t["id"] == item_id:
                    t["fetch_mode"] = fetch_mode
            save(TARGETS_PATH, cfg)
        else:
            cfg = load(TRACKERS_PATH, "trackers", extra_keys=["excluded"])
            for t in cfg["trackers"]:
                if t["id"] == item_id:
                    t["fetch_mode"] = fetch_mode
            save(TRACKERS_PATH, cfg)
    log(f"[info] saved fetch_mode=browser for '{item_id}' to disk — it'll start in browser mode next time too.")


_YAML_LOADER = getattr(yaml, "CSafeLoader", yaml.SafeLoader)      # v62: the fast (C) reader when the PC has it
_LOAD_CACHE = {}                                                  # path -> (file stamp, parsed content)
_LOAD_LOCK = threading.Lock()


def _stamp(path):
    try:
        st = os.stat(path)
        return (st.st_mtime_ns, st.st_size)
    except OSError:
        return None


def load(path, key, extra_keys=None):
    """v62: the file is read from disk only when it has changed. Diagnostics 60: the whole product list was re-read from disk for every
    name shown (about 150 times a minute, ~0.3 s each), which kept the program's one Python core busy and slowed every reader and page."""
    stamp = _stamp(path)
    if stamp is None:
        d = {key: []}
    else:
        with _LOAD_LOCK:
            hit = _LOAD_CACHE.get(path)
        if hit and hit[0] == stamp:
            d = copy.deepcopy(hit[1])
        else:
            with open(path, encoding="utf-8", errors="replace") as f:
                parsed = yaml.load(f, Loader=_YAML_LOADER) or {key: []}
            with _LOAD_LOCK:
                _LOAD_CACHE[path] = (stamp, parsed)
            d = copy.deepcopy(parsed)
    d.setdefault(key, [])
    for k in (extra_keys or []):
        d.setdefault(k, [])
    return d


def save(path, cfg):
    """v62: written to a side file first and then swapped in, so a reader never sees a half-written list."""
    tmp = path + ".saving"
    with open(tmp, "w", encoding="utf-8") as f:
        yaml.safe_dump(cfg, f, sort_keys=False, allow_unicode=True)
    for i in range(20):
        try:
            os.replace(tmp, path)
            break
        except PermissionError:          # (Windows: the file is being read at this very moment - a moment later it is free)
            time.sleep(0.05)
    else:
        with open(path, "w", encoding="utf-8") as f:
            yaml.safe_dump(cfg, f, sort_keys=False, allow_unicode=True)
        try:
            os.remove(tmp)
        except OSError:
            pass
    with _LOAD_LOCK:
        _LOAD_CACHE.pop(path, None)


def ensure_push_trackers():
    """TrackaLacker and HotStock are 'alert' trackers (no public page): make sure they are listed, with current settings.
    A user's own choices (paused / active) are kept."""
    try:
        with CONFIG_LOCK:
            cfg = load(TRACKERS_PATH, "trackers", extra_keys=["excluded"])
            changed = False
            by_id = {t["id"]: t for t in cfg["trackers"]}
            for b in push_listener.BUILTIN:
                cur = by_id.get(b["id"])
                if cur is None:
                    cfg["trackers"].append(dict(b, active=True, v63_on=True) if b["id"] == "hotstock" else dict(b))
                    changed = True
                    log(f"[info] added the alert tracker '{b['id']}' ({b['name']}) to your trackers.")
                else:
                    for k in ("kind", "tier", "name", "feed_url", "push_hosts", "setup_urls", "enable_url", "keep_open_url", "claimed_note"):
                        if cur.get(k) != b.get(k):
                            cur[k] = b.get(k)
                            changed = True
                    if b["id"] == "hotstock" and not cur.get("v63_on"):
                        cur["active"] = True           # v63: HotStock's browser alerts are listened to again (v41 had switched them off); the one-time
                        cur["v63_on"] = True           # sign-in happens in the alert browser's set-up window
                        changed = True
                n0 = len(cfg["excluded"])
                cfg["excluded"] = [e for e in cfg["excluded"] if e.get("id") != b["id"]]
                changed = changed or len(cfg["excluded"]) != n0
            n_ex = len(cfg["excluded"])       # Restockd was parked in v31 as "app-only"; v39 reads its public feed, so that note goes
            cfg["excluded"] = [e for e in cfg["excluded"] if not (e.get("id") == "restockd" and str(e.get("reason", "")).startswith("app-only"))]
            changed = changed or len(cfg["excluded"]) != n_ex
            _d = discord_source.BUILTIN                              # v45: Discord server of your own as a source (added once; a tracker you removed stays removed)
            if _d["id"] not in by_id and not any(e.get("id") == _d["id"] for e in cfg["excluded"]):
                cfg["trackers"].append(dict(_d))
                changed = True
                log(f"[info] added the tracker '{_d['id']}' ({_d['name']}): other trackers' Discord alerts, read from a server of your own (one-time set-up).")
            elif _d["id"] in by_id:
                for k in ("kind", "name", "feed_url", "claimed_note"):
                    if by_id[_d["id"]].get(k) != _d.get(k):
                        by_id[_d["id"]][k] = _d.get(k)
                        changed = True
            for b in tracker_feed_poller.BUILTIN_FEEDS:            # public status pages: added once; a tracker you removed stays removed
                if b["id"] not in by_id and not any(e.get("id") == b["id"] for e in cfg["excluded"]):
                    cfg["trackers"].append(dict(b))
                    changed = True
                    log(f"[info] added the tracker '{b['id']}' ({b['name']}): a public page the program reads, no account needed.")
                elif b["id"] in by_id:
                    cur = by_id[b["id"]]
                    for k in ("kind", "name", "feed_url", "claimed_note", "pages", "parser") + (("interval_sec",) if b["id"].endswith("_page") else ()):
                        if k in b and cur.get(k) != b.get(k):
                            cur[k] = b.get(k)
                            changed = True
                    if b["id"] == "restockd" and cur.get("active", True):
                        cur["active"] = False             # v63: Restockd does not list Magic: The Gathering - reading it only cost time
                        changed = True
            if changed:
                save(TRACKERS_PATH, cfg)
    except Exception as e:
        log(f"[warn] could not add the alert trackers: {e}")


NEW_PRODUCTS_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "new_products.yaml")
MERGED_PATH = "products_merged.txt"


def ensure_new_products():
    """Adds the products in new_products.yaml that you do not have yet (each one only once, so a product you delete stays deleted).
    Nothing already in your targets.yaml is changed."""
    if os.environ.get("RK_NO_NEW_PRODUCTS") or not os.path.exists(NEW_PRODUCTS_PATH):
        return []
    try:
        with CONFIG_LOCK:
            cfg = load(TARGETS_PATH, "targets")
            with open(NEW_PRODUCTS_PATH, encoding="utf-8") as f:
                new = yaml.safe_load(f) or {}
            before = products.read_ids(MERGED_PATH)
            added, known = products.merge_new_products(cfg, new, before)
            if added:
                save(TARGETS_PATH, cfg)
                log(f"[info] added {len(added)} new product(s) to your list: " + ", ".join(added))
            if known != before:
                products.write_ids(MERGED_PATH, known)
            return added
    except Exception as e:
        log(f"[warn] could not add the new products: {type(e).__name__}: {str(e)[:120]}")
        return []


def ensure_unified_caps():
    """One price cap per product, the same at every store: the lowest one already in use. Done once; after that the table's cap box rules."""
    if os.environ.get("RK_NO_UNIFY") or matrix.UI.get("caps_unified"):
        return 0
    try:
        with CONFIG_LOCK:
            cfg = load(TARGETS_PATH, "targets")
            n = matrix.unify_caps(cfg["targets"])
            if n:
                save(TARGETS_PATH, cfg)
                log(f"[info] price caps made the same at every store for each product (lowest one kept): {n} link(s) changed.")
        with matrix.LOCK:
            matrix.UI["caps_unified"] = True
        matrix.save_ui()
        return n
    except Exception as e:
        log(f"[warn] could not unify the price caps: {type(e).__name__}: {str(e)[:120]}")
        return 0


FOUNDATIONS_PACK_IDS = ("target_foundations_pack", "walmart_foundations_pack", "bestbuy_foundations_pack", "tcg_foundations_pack")


def ensure_foundations_box():
    """v65 (your message 2026-10-28 23:58): Foundations was always meant to be the full Collector Booster BOX, not a single pack. The Amazon
    link is right (its page is the box); the Target, Walmart, Best Buy and TCG links were single-pack pages, so they are removed - the
    program searches those stores for the box again (a link it finds is bought only after its page shows the box). Done once."""
    try:
        with CONFIG_LOCK:
            cfg = load(TARGETS_PATH, "targets")
            if not any(t.get("id") == "amazon_foundations_pack" for t in cfg["targets"]):
                return False
            removed = [t["id"] for t in cfg["targets"] if t.get("id") in FOUNDATIONS_PACK_IDS]
            cfg["targets"] = [t for t in cfg["targets"] if t.get("id") not in FOUNDATIONS_PACK_IDS]
            for t in cfg["targets"]:
                if t.get("id") == "amazon_foundations_pack":
                    t["id"] = "amazon_foundations"
                    t["match_name"] = "Foundations Collector Booster Box"
                    t["kind"] = "box"
                    t.pop("aliases", None)
                    t["max_price"] = 299.88          # the box's MSRP (12 packs x $24.99) - change it in the table whenever you like
            save(TARGETS_PATH, cfg)
        with matrix.LOCK:
            if "foundations|pack" in matrix.UI["products_off"]:
                matrix.UI["products_off"].discard("foundations|pack")
                matrix.UI["products_off"].add("foundations|box")
            matrix.UI["searched"].pop("foundations|box", None)
        matrix.save_ui()
        matrix.bump()
        log("[info] Foundations is now the Collector Booster BOX (your rule): the Amazon link is kept (cap $299.88, the box's MSRP); the "
            f"single-pack links at the other stores were removed ({', '.join(removed) or 'none'}) - those stores are searched for the box.")

        def find_box():
            try:
                log("[info] Foundations box: " + search_other_stores("foundations|box", force=True))
                _search_tcg("foundations|box")
            except Exception as e2:
                log(f"[warn] Foundations box search: {e2}")
        tm = threading.Timer(120, find_box)            # (once the program's browsers are up)
        tm.daemon = True
        tm.start()
        return True
    except Exception as e:
        log(f"[warn] could not change Foundations to the box: {type(e).__name__}: {str(e)[:120]}")
        return False


def ensure_row_kinds():
    """Rows you added with an older version get their own category and set name (Commander Deck / Play Booster Box), see matrix.migrate_rows."""
    try:
        with CONFIG_LOCK:
            cfg = load(TARGETS_PATH, "targets")
            renames, n = matrix.migrate_rows(cfg["targets"])
            if renames:
                if n:
                    save(TARGETS_PATH, cfg)
                for old, new in renames.items():
                    thumbs.rename_row(old, new)
                log("[info] updated the rows you added: " + ", ".join(f"'{o.split('|')[0]}' -> '{nw}'" for o, nw in renames.items()) + f" ({n} link(s) kept).")
        _fix_shared_rows()
        return renames
    except Exception as e:
        log(f"[warn] could not update the rows you added: {type(e).__name__}: {str(e)[:120]}")
        return {}


def _fix_shared_rows():
    """v32, one time: Play Booster Box (and Commander Deck) links that were filed under the Collector Booster Box row now have their own row.
    The Collector row's kept picture may have come from the play box page, so it is fetched again."""
    marker = os.path.join(thumbs.AUTO_DIR, ".v32_rows")
    if os.path.exists(marker):
        return
    try:
        cfg = load(TARGETS_PATH, "targets")
        moved = set()
        for t in cfg["targets"]:
            raw = (t.get("kind") or "box").strip().lower()
            if raw == "box" and products.kind_of(t) != "box":
                moved.add(f"{products.theme_of(t)}|box")
        for key in sorted(moved):
            thumbs.forget(key)
        if moved:
            log("[info] Play Booster Box links now have their own row (they had been mixed into the Collector Booster Box row): "
                + ", ".join(k.split("|")[0] for k in sorted(moved)) + ". Their pictures are being fetched again.")
        os.makedirs(thumbs.AUTO_DIR, exist_ok=True)
        with open(marker, "w") as f:
            f.write("v32\n")
    except Exception as e:
        log(f"[warn] row clean-up: {type(e).__name__}: {str(e)[:120]}")


def retailer_of(t):
    host = (t.get("url") or "").lower().split("/")[2] if "//" in (t.get("url") or "") else ""
    for k in ("amazon", "target", "walmart", "bestbuy", "gamestop"):
        if k in host:
            return k
    return "other"


def count_rows(path):
    if not os.path.exists(path):
        return 0
    with open(path, newline="", encoding="utf-8", errors="replace") as f:
        return max(0, sum(1 for _ in csv.reader(f)) - 1)


STYLE = """
<style>
  body { font-family: -apple-system, sans-serif; max-width: 960px; margin: 0 auto 20px; padding: 0 16px; }
  h1.top { font-size: 1.35em; margin: 8px 0 4px; }
  table { width: 100%; border-collapse: collapse; margin-bottom: 24px; }
  th, td { text-align: left; padding: 8px; border-bottom: 1px solid #ddd; font-size: 14px; vertical-align: top; }
  th { background: #f5f5f5; }
  input, textarea { width: 100%; padding: 6px; margin-bottom: 8px; box-sizing: border-box; }
  form.inline { display: inline; }
  .grid { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
  button { padding: 6px 14px; cursor: pointer; }
  .del { background: #fee; border: 1px solid #f99; }
  button.drop { background: #f0f3f6; border: 1px solid #c3c9d0; border-radius: 6px; }
  button.drop.open { background: #ddf4ff; border-color: #54aeff; }
  .dropbox { display: none; border: 1px solid #d0d7de; border-radius: 6px; padding: 8px 12px; margin: 6px 0 10px; background: #fff; }
  .presult { border: 1px solid #bbb; border-radius: 6px; padding: 6px 10px; margin: 6px 0; font-size: 13px; background: #fff; }
  .presult.ok { border-color: #2a9d2a; background: #f1fbf1; } .presult.bad { border-color: #cf222e; background: #fff1f1; } .presult.wait { border-color: #bf8700; background: #fff8e1; }
  .hint { color: #666; font-size: 13px; margin-top: -4px; margin-bottom: 12px; }
  .excluded td { color: #999; }
  .tabs { margin-bottom: 6px; }
  .tabs a { display: inline-block; padding: 4px 14px; text-decoration: none; color: #333; border-bottom: 3px solid transparent; }
  .tabs a.active { border-bottom-color: #333; font-weight: bold; }
  .banner { padding: 12px 16px; border-radius: 6px; margin-bottom: 20px; font-size: 14px; }
  .banner.ok { background: #eaffea; border: 1px solid #7c7; }
  .banner.err { background: #ffeaea; border: 1px solid #c77; }
  .dash { background: #f7f7f9; border: 1px solid #ddd; border-radius: 8px; padding: 8px 12px; margin: 4px 0 8px; position: sticky; top: 0; z-index: 40;
          box-shadow: 0 2px 6px rgba(0,0,0,.08); }
  #pagebody { overflow: auto; }
  #buyBar { display: none; margin: 4px 0 2px; padding: 6px 10px; border-radius: 6px; font-size: 14px; }
  #buyBar.go { display: block; background: #fff4d6; border: 2px solid #d97706; }
  #buyBar.ok { display: block; background: #e6f0ff; border: 2px solid #1f6feb; }
  #buyBar.bad { display: block; background: #fde4e4; border: 2px solid #b42318; }
  #buyBar .x { float: right; cursor: pointer; color: #555; padding: 0 4px; }
  .dash-top { display: flex; align-items: center; gap: 12px; margin-bottom: 4px; flex-wrap: wrap; }
  .drow { display: flex; align-items: center; gap: 10px; flex-wrap: wrap; margin: 3px 0; font-size: 13px; }
  .drow .dlab { width: 70px; flex: none; font-size: 11px; font-weight: 600; letter-spacing: .06em; text-transform: uppercase; color: #6e7781; }
  .drow .dfill { flex: 1 1 0; }
  .drow button { padding: 4px 12px; border-radius: 6px; font-size: 13px; }
  button.pill { background: #fff; border: 1px solid #c3c9d0; color: #24292f; }
  button.pill:hover { background: #f3f4f6; }
  button.pill.open { background: #ddf4ff; border-color: #54aeff; }
  button.pill.bad { background: #fde4e4; border-color: #b42318; color: #b42318; font-weight: 600; }
  button.pill.good { color: #1a7f37; }
  #diagBtn { font-size: 13px; color: #0969da; }
  table.ptab { border-collapse: collapse; width: 100%; margin: 4px 0 6px; }
  table.ptab th, table.ptab td { border: 1px solid #d0d5db; padding: 3px 8px; font-size: 13px; text-align: left; vertical-align: top; }
  table.ptab th { background: #f5f5f5; font-weight: 600; }
  table.ptab td.num { text-align: right; white-space: nowrap; }
  .need { border: 1px solid #b42318; background: #fff6f6; border-radius: 6px; padding: 6px 10px; margin: 4px 0; }
  .need button { margin-left: 6px; padding: 2px 10px; font-size: 12px; }
  .allgood { color: #1a7f37; font-weight: 600; margin: 4px 0; }
  .sub { color: #57606a; font-size: 12px; }
  #healthStrip { display: inline-flex; gap: 8px; font-size: 12px; color: #444; }
  #healthStrip .hpill { white-space: nowrap; } #healthStrip i { display: inline-block; width: 9px; height: 9px; border-radius: 50%; margin-right: 3px; vertical-align: 0; }
  .dot { width: 10px; height: 10px; border-radius: 50%; display: inline-block; margin-right: 6px; }
  .dot.on { background: #2a2; } .dot.off { background: #999; } .dot.warn { background: #d90; }
  #startBtn { background: #2a2; color: white; border: none; }
  #startBtn:disabled { background: #1a7f37; color: white; opacity: 1; cursor: default; }
  #stopBtn { background: #c33; color: white; border: none; }
  #diagBtn { background: none; border: none; }
  #logbox { background: #111; color: #ddd; font-family: monospace; font-size: 12px; padding: 2px 8px; box-sizing: border-box;
            height: 260px; overflow-y: auto; border-radius: 6px; white-space: pre-wrap; display: none; margin-top: 4px; }
  #logbox.big { display: block; }
  #phoneInfo { display: none; position: absolute; z-index: 20; right: 12px; top: 100%; margin-top: 4px; width: 330px; background: #fff; border: 1px solid #999;
               border-radius: 8px; padding: 10px 12px; box-shadow: 0 6px 20px rgba(0,0,0,.25); font-size: 13px; }
  .linkbtn { background: none; border: none; color: #0969da; cursor: pointer; padding: 0 4px; font-size: 12px; }
  .counts { font-size: 14px; color: #333; }
  .status-cell { font-size: 13px; }
  .status-instock { color: #2a2; font-weight: bold; }
  .status-outofstock { color: #666; }
  .status-unknown { color: #c33; }
  .status-stale { color: #d90; }
</style>
"""

DASHBOARD = """
<div class="dash">
  <!-- v97 (owner 2026-11-04: "clean up some areas of the banner and simplify language ... clean, sleek, easy to read"): three rows -
       watching, buying, alerts - each with a short label; purchases and problems are separate -->
  <div class="dash-top drow">
    <span class="dlab">Watching</span>
    <span><span id="statusDot" class="dot off"></span><b id="statusText">Stopped</b></span>
    <button id="startBtn" onclick="startWatch()">Start watching</button>
    <button id="stopBtn" onclick="stopWatch()" style="background:#b42318;color:#fff;border:none" title="Stops EVERYTHING at once: no browser buys anything from this moment (a checkout ends where it is), watching stops and every browser of the program closes. Nothing is disarmed: what is set to Buy stays set for the next start.">Stop</button>
    <span class="counts">Restocks seen <b id="restockCount">0</b> &middot; Tracker alerts <b id="alertCount">0</b></span>
    <span id="healthStrip" title="Each store: green = its products are being read, amber = the store refused faster reads (all its products are read slower), red = none of its products read for minutes, grey = not watching"></span>
    <span class="dfill"></span>
    <span id="speedBox" title="How much of your PC the program may use. More room = more readers at the same time = a restock is noticed sooner. Click for the details.">
      <button class="linkbtn" id="speedBtn" onclick="lpToggle()" style="font-size:13px">Speed: <b id="speedNow">...</b> &#9662;</button></span>
    <span id="gameBox" title="While you play a game the program steps back: fewer, slower checks of the extra products and the lowest priority for its browsers. The original products keep their pace. Auto = the program notices a game by itself.">
      Gaming <select id="gameSel" onchange="setGame(this.value)" style="padding:1px 2px;font-size:12px"><option value="auto">Auto</option><option value="on">On</option><option value="off">Off</option></select>
      <span id="gameNow" style="font-size:12px;color:#57606a"></span></span>
    <a id="diagBtn" href="/api/diagnostics" download="restock-kit-diagnostics.txt" title="A text file with everything needed to find a problem (no passwords, card code or addresses)">Download diagnostics</a>
    <a href="/api/diagnostics-saved" download="restock-kit-diagnostics-saved.txt" style="font-size:12px" title="The copy saved at the last Stop (or every 2 hours) - also after a crash">saved copy</a>
    <button class="pill" id="copyBtn" onclick="toggleBox('copyBox', this)" title="A copy of Restalker for a new user, or for you on another PC">Copy &#9662;</button>
    <button class="pill" id="helpBtn" onclick="helpToggle(this)" title="The guide and the release notes (scan the code with your phone)">Help &#9662;</button>
    <!-- v90: "Download page samples" removed from the top bar (still at /api/samples if ever asked for) -->
  </div>
  <div id="pushBanner" style="display:none;margin:4px 0;padding:6px 10px;border:2px solid #d97706;background:#fff7ed;border-radius:6px;font-size:13px"></div>
  <div class="drow" title="Restalker buys by itself: its buying browsers buy a product set to Buy the moment it restocks at or under the product's price cap.">
    <span class="dlab">Buying</span>
    <button id="buyBtn" onclick="buyAct(buyOn ? 'off' : 'on')">...</button>
    <span id="buyDot" class="dot off"></span><span id="buyLine" style="color:#333;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;min-width:0;flex:0 1 auto">starting...</span>
    <span class="dfill"></span>
    <button class="pill" id="purchBtn" onclick="toggleBox('purchBox', this); buyLast = null; poll()" title="Every purchase, kept for good">Purchases &#9662;</button>
    <button class="pill" id="probBtn" onclick="toggleBox('probBox', this); buyLast = null; poll()" title="What needs you now - and what needed you before">Problems &#9662;</button>
    <button class="linkbtn" id="loginBtn" onclick="loginToggle()" title="Each store's e-mail and password, saved encrypted on this PC, so every browser signs itself back in">Sign-ins &#9662;</button>
    <button class="linkbtn" id="codeBtn" onclick="codeToggle()" title="Your card's 3-4 digit security code: saved encrypted on this PC so checkouts never wait for you">Card code &#9662;</button>
  </div>
  <div class="drow">
    <span class="dlab" title="Messages are sent when something is bought or needs you">Alerts</span>
    <button id="phoneBtn" class="pill" onclick="togglePhone()">Phone &#9662;</button>
    <button class="pill" onclick="enableBrowserAlerts()" title="A notification in the corner of this PC's screen (only while this page is open)">Browser alerts</button>
    <span id="alertInfo" style="color:#57606a"></span>
    <button class="pill" onclick="testAlerts()">Send a test</button>
    <span id="dismissInfo" style="color:#555;font-size:12px"></span>
    <span class="dfill"></span>
    <button class="linkbtn" id="logBtn" onclick="toggleLog()">Show log &#9662;</button>
  </div>
  <div id="loginBox" style="display:none;margin:4px 0;padding:6px 10px;border:1px solid #aab;background:#fff;border-radius:6px;font-size:13px">
    <div style="color:#555;margin-bottom:4px">Your sign-in for each store, saved <b>encrypted on this PC</b> (only your Windows account can read it; never shown again, never in the diagnostics).
      Every browser that finds itself signed out signs itself back in with it - at most once every 30 minutes per store. A code the store sends to your phone or e-mail, or a "verify it's you" page, is never answered by the program: then you are asked once.</div>
    <div id="loginRows"></div>
  </div>
  <div id="codeBox" style="display:none;margin:4px 0;padding:6px 10px;border:1px solid #aab;background:#fff;border-radius:6px;font-size:13px">
    <span id="codeSaved" style="display:none"><b style="color:#1a7f37">&#10003; Card security code saved</b> - every checkout types it in by itself
      (encrypted on this PC; only your Windows account can read it). <button onclick="codeReplace()">Replace</button> <button onclick="codeSave(true)">Remove</button></span>
    <span id="codeEntry">Card security code (the 3-4 digits on the back of the card the stores have on file):
    <input id="codeIn" type="password" inputmode="numeric" maxlength="4" autocomplete="off" style="width:70px;display:inline-block;margin:0"
           onkeydown="if (event.key === 'Enter') { event.preventDefault(); codeSave(false); }">
    <button onclick="codeSave(false)" style="background:#1a7f37;color:#fff;border:none">Save</button> <button id="codeCancel" style="display:none" onclick="codeShow(CODELAST)">Cancel</button></span>
    <span id="codeMsg" style="color:#333"></span>
  </div>
  <div id="buyWarn" style="display:none;margin:4px 0;padding:6px 10px;border:2px solid #b42318;background:#fff1f0;border-radius:6px;font-size:13px"></div>
  <div id="buyBar"></div>
  <div id="stopNote" style="display:none;margin:4px 0;padding:6px 10px;border:2px solid #b42318;background:#fff1f0;border-radius:6px;font-size:13px"></div>
  <div id="copyBox" class="dropbox" style="font-size:13px">
    <div style="display:flex;gap:14px;flex-wrap:wrap">
      <div style="flex:1 1 320px;border:1px solid #d0d7de;border-radius:6px;padding:8px 10px">
        <b>For a new user</b> - the program with nothing of yours: no sign-ins, card code, phone or Discord names, purchases, history or settings. Nothing is set to Buy.
        <div style="margin:6px 0"><label style="font-size:13px"><input type="checkbox" id="cpProducts" checked style="width:auto;margin:0 4px 0 0">include my product list (products, links, price caps)</label><br>
        <label style="font-size:13px"><input type="checkbox" id="cpDiscord" style="width:auto;margin:0 4px 0 0">include my Discord channel (their restocks are shared there too; anyone with the copy can post in it)</label></div>
        <button onclick="copyGet('new')" style="background:#1a7f37;color:#fff;border:none">Download the copy for a new user</button>
      </div>
      <div style="flex:1 1 320px;border:1px solid #d0d7de;border-radius:6px;padding:8px 10px">
        <b>For me on another PC</b> - the program and your data: products, switches, settings, phone and Discord set-up, purchases and history.
        Not in it (locked to this PC): your store sign-ins and card code - type them in once there - and the browsers' own sign-ins.
        <div class="sub" style="margin:6px 0">Run Restalker on ONE PC at a time (two PCs could buy one each). Keep this file private.</div>
        <button onclick="copyGet('move')" style="background:#1f6feb;color:#fff;border:none">Download the copy for my other PC</button>
      </div>
    </div>
    <div class="sub" style="margin-top:6px">Each copy has START HERE.txt with the steps. Updates contain only program files, never data, so both kinds take the same updates.</div>
  </div>
  <div id="helpBox" class="dropbox" style="font-size:13px"></div>
  <div id="purchBox" class="dropbox" style="font-size:13px"></div>
  <div id="probBox" class="dropbox" style="font-size:13px"></div>
  <div id="speedPanel" style="display:none;margin:4px 0;padding:8px 12px;border:1px solid #aab;background:#fff;border-radius:6px;font-size:13px;line-height:1.5"></div>
  <div id="ffInfo" style="display:none"></div>
  <div id="phoneInfo"></div>
  <div id="testResult" style="display:none;margin:4px 0;padding:6px 10px;border:1px solid #bbb;background:#fff;border-radius:6px;font-size:13px"></div>
  <div id="pushResultTop" class="presult" style="display:none"></div>
  <div id="logbox">Not running yet.</div>
</div>
<script>
function timeAgo(epochSeconds) {
  if (!epochSeconds) return 'never';
  const s = Math.max(0, Math.round(Date.now()/1000 - epochSeconds));
  if (s < 60) return s + 's ago';
  if (s < 3600) return Math.round(s/60) + 'm ago';
  return Math.round(s/3600) + 'h ago';
}
function statusClass(s) {
  if (s === 'IN_STOCK') return 'status-instock';
  if (s === 'OUT_OF_STOCK') return 'status-outofstock';
  return 'status-unknown';
}
let programClosed = false;
let lastRestocks = null, lastPush = null, restockAlertsOn = false;
const PAGE_VERSION = document.title.split(' ').pop();   // this page was made by this program version
function browserNotify(title, body) {
  if (!('Notification' in window) || Notification.permission !== 'granted') return;
  // silent: no sound. tag: two open copies of this page show ONE alert, not two.
  try { new Notification(title, {body: body, silent: true, tag: 'restock-' + title}); } catch (e) {}
}
function showAlertInfo() {
  const el = document.getElementById('alertInfo');
  if (!el) return;
  const p = ('Notification' in window) ? Notification.permission : 'unsupported';
  el.innerText = p === 'granted' ? 'on' : (p === 'denied' ? 'blocked (padlock next to the address > Notifications > Allow)' : 'off');
  el.title = p === 'granted' ? 'Browser alerts are on while this page stays open in a tab' : '';
}
async function enableBrowserAlerts() {
  if (!('Notification' in window)) { alert('This browser cannot show notifications.'); return; }
  await Notification.requestPermission();
  showAlertInfo();
  if (Notification.permission === 'granted') browserNotify('Restalker', 'Browser alerts are on. You will see one like this when a restock is logged.');
}
let phoneTopic = null;
function phoneLabel() { return phoneTopic ? 'Phone: <b style="color:#1a7f37">on</b>' : 'Phone: set up'; }
async function togglePhone() {
  const box = document.getElementById('phoneInfo');
  if (box.style.display === 'block') { box.style.display = 'none'; document.getElementById('phoneBtn').innerHTML = phoneLabel() + ' &#9662;'; return; }
  if (!phoneTopic) {
    try { const d = await (await fetch('/api/phone-setup', {method: 'POST'})).json(); phoneTopic = d.topic; } catch (e) {}
  }
  if (phoneTopic) showPhone(phoneTopic);
  box.style.display = 'block';
  document.getElementById('phoneBtn').innerHTML = phoneLabel() + ' &#9652;';
}

let lpOpen = false, lpTimer = null;
function lpToggle() {
  lpOpen = !lpOpen;
  const p = document.getElementById('speedPanel');
  p.style.display = lpOpen ? 'block' : 'none';
  if (lpOpen) { lpLoad(); lpTimer = setInterval(lpLoad, 4000); } else if (lpTimer) { clearInterval(lpTimer); lpTimer = null; }
}
async function lpSet(key) {
  try { await fetch('/api/loadplan', {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({profile: key})}); } catch (e) {}
  lpLoad();
}
function lpSec(x) { return (x === null || x === undefined) ? 'not measured yet' : (x < 10 ? x.toFixed(1) : Math.round(x)) + ' s'; }
async function lpLoad() {
  let d = null;
  try { d = await (await fetch('/api/loadplan')).json(); } catch (e) { return; }
  if (!d || !d.levels) return;
  const p = document.getElementById('speedPanel');
  if (!lpOpen) return;
  let h = '<div style="font-size:14px"><b>Speed vs. PC load</b></div>';
  h += '<div style="color:#444">Each <b>reader</b> is one more browser reading the stores at the same time. More readers = a restock is noticed sooner, but the program uses more of your PC. ' +
       'The program never slows its reading down to spare the PC: if the PC is full it uses <b>fewer readers</b> instead. Pick how much room it gets:</div>';
  h += '<div style="display:flex;gap:8px;flex-wrap:wrap;margin:8px 0">';
  for (const L of d.levels) {
    const on = L.current;
    h += '<div onclick="lpSet(&quot;' + L.key + '&quot;)" style="cursor:pointer;flex:1 1 200px;min-width:190px;padding:8px 10px;border:2px solid ' + (on ? '#1a7f37' : '#ccc') + ';border-radius:8px;background:' + (on ? '#eaffea' : '#fafafa') + '">' +
         '<b>' + L.label + '</b>' + (on ? ' &#10003;' : '') + '<br>' +
         '<span style="font-size:12px">up to <b>' + L.readers + ' readers</b><br>about ' + L.cpu_pct_pc + '% of your processor, ' + L.gb + ' GB memory<br>' +
         'never more than ' + L.ceiling_cpu_pc + '% processor / ' + L.ceiling_gb + ' GB</span><br>' +
         '<span style="font-size:12px">' + (L.gap ? 'each product looked at up to <b>every ' + L.gap + ' s</b>' : 'each product at its store\\'s own pace (1 - 15 s)') + '</span><br>' +
         '<span style="font-size:12px;color:#555">' + L.text + '</span></div>';
  }
  h += '</div>';
  h += '<div style="margin-bottom:4px;color:#444"><b>Why the pace per product matters:</b> a restock can only be noticed as fast as a product is looked at. A product looked at every 15 s is noticed after about 7 s on average, every 2 s after about 1 s - however many readers there are. A faster pace per product asks the stores for more pages, so a store may hang up or show its human check more often (the program then backs that reader off, it never pushes through).</div>';
  h += '<div><b>Right now:</b> ' + d.readers_active + ' readers working (' + d.readers_main + ' main + ' + d.readers_extra_allowed + ' extra' +
       (d.readers_extra_waiting ? ', ' + d.readers_extra_waiting + ' more waiting for room' : '') + '). ' +
       (d.cpu_pct_pc === null ? 'Measuring... ' : 'The program uses <b>' + d.cpu_pct_pc + '%</b> of your PC\\'s processor (' + d.cpu_cores + ' of ' + d.cores + ' cores) and <b>' + d.gb + ' GB</b> of memory (your PC has ' + d.ram_gb + ' GB). ') +
       'One reader costs about ' + d.per_reader_cpu_pc + '% of the processor and ' + d.per_reader_gb + ' GB' + (d.measured ? ' (measured)' : ' (an estimate until it has run a minute)') + '.' +
       (d.gaming ? ' <b>Gaming mode is on, so the extra readers are resting.</b>' : '') + '</div>';
  const st = d.stores || {};
  const names = Object.keys(st);
  if (names.length) {
    h += '<div style="margin-top:6px"><b>How often each product is looked at (all of a store\\'s readers together):</b></div><table style="border-collapse:collapse;font-size:12px;margin-top:2px"><tr style="text-align:left"><th style="padding:2px 10px 2px 0">Store</th><th style="padding:2px 10px">Products</th><th style="padding:2px 10px">Readers</th><th style="padding:2px 10px">A product is looked at every</th><th style="padding:2px 10px">A restock is noticed after about</th><th style="padding:2px 10px">Each product switched off makes the others faster by about</th></tr>';
    for (const n of names) { const s = st[n];
      h += '<tr><td style="padding:2px 10px 2px 0">' + n + '</td><td style="padding:2px 10px">' + s.products + '</td><td style="padding:2px 10px">' + s.readers + '</td><td style="padding:2px 10px">' + lpSec(s.avg_gap) + ' (slowest ' + lpSec(s.worst_gap) + ')</td><td style="padding:2px 10px">' + lpSec(s.delay) + '</td><td style="padding:2px 10px">' + (s.per_product === null || s.per_product === undefined ? '-' : s.per_product.toFixed(2) + ' s') + '</td></tr>'; }
    h += '</table><div style="margin-top:3px">All stores together: a restock is noticed after about <b>' + lpSec(d.delay_all) + '</b> on average by the program\\'s own readers (the trackers and Discord feeds fill in when a store is not answering). The goal is 1 second.</div>';
  }
  if (d.blocked && d.blocked.length) {
    h += '<div style="margin-top:6px"><b>Products a store is hiding behind a human-check page (' + d.blocked.length + '):</b> the program never tries to get past those pages. A reader that was shown one leaves that product alone and looks again after 2, 5, 10, 15, 20, then 30 minutes (each time with whichever browser is ready), so the PC\\'s power goes to the products that read fine. The store\\'s other readers keep reading it while they can.</div>' +
         '<table style="border-collapse:collapse;font-size:12px;margin-top:2px"><tr style="text-align:left"><th style="padding:2px 10px 2px 0">Store / product</th><th style="padding:2px 10px">Readers held back</th><th style="padding:2px 10px">Next look in</th><th style="padding:2px 10px">Browsers shown the page</th><th style="padding:2px 10px">Browser that last worked</th></tr>';
    for (const b of d.blocked) {
      h += '<tr><td style="padding:2px 10px 2px 0">' + b.store + ' / ' + b.product + '</td><td style="padding:2px 10px">' + b.readers_blocked + ' of ' + b.readers + (b.everywhere ? ' (all)' : '') + '</td><td style="padding:2px 10px">' + lpSec(b.probe_in) + '</td><td style="padding:2px 10px">' + b.engines.join(', ') + '</td><td style="padding:2px 10px">' + (b.good || '-') + '</td></tr>'; }
    h += '</table>';
  }
  if (d.housekeeping) h += '<div style="margin-top:4px;color:#444"><b>Memory:</b> ' + d.housekeeping + '</div>';
  if (d.windows) {
    const w = d.windows;
    h += '<div style="margin-top:4px"><b>Measured on real restocks</b> (last ' + w.hours + ' h): ' + w.n + ' logged. Each one happened inside a window between the last look that saw the product out of stock and the first look that saw it in stock: average <b>' + lpSec(w.avg) + '</b>, best ' + lpSec(w.best) + ', worst ' + lpSec(w.worst) + ' (' + w.le1 + ' within 1 s, ' + w.le5 + ' within 5 s). The real delay is at most the window, about half of it on average.</div>';
  }
  h += '<div style="margin-top:6px;color:#444"><b>If the PC is too busy:</b> pick a lower level above, <i>or</i> switch off products and stores you do not need in the table (each product switched off gives its share of the PC back to the others, so the ones that are left are looked at more often). ' +
       'Gaming mode (next to the Start button) rests the extra readers while you play.</div>';
  p.innerHTML = h;
}
function lpBrief(l) {
  const el = document.getElementById('speedNow');
  if (!el || !l || !l.label) return;
  el.innerText = l.label.replace(' (recommended)', '') + (l.cpu_pct_pc === null || l.cpu_pct_pc === undefined ? '' : ' - using ' + l.cpu_pct_pc + '% of the PC');
}
let gameOn = false;
function showGame(on, mode, reason) {
  gameOn = !!on;
  const sel = document.getElementById('gameSel'), now = document.getElementById('gameNow');
  if (!sel) return;
  if (mode && document.activeElement !== sel) sel.value = mode;
  if (now) {
    now.innerText = gameOn ? ('ON now' + (reason && mode === 'auto' ? ' (' + reason + ')' : '')) : 'off now';
    now.style.background = gameOn ? '#1a7f37' : '';
    now.style.color = gameOn ? '#fff' : '#555';
    now.style.padding = gameOn ? '1px 7px' : '0';
    now.style.borderRadius = '9px';
  }
}
async function setGame(mode) {
  try {
    const d = await (await fetch('/api/gaming', {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({mode: mode})})).json();
    showGame(d.on, d.mode, d.reason);
  } catch (e) {}
}
function toggleLog() {
  const b = document.getElementById('logbox');
  const big = b.classList.toggle('big');
  document.getElementById('logBtn').innerHTML = big ? 'Hide log &#9652;' : 'Show log &#9662;';
  try { localStorage.setItem('rk_log_big', big ? '1' : '0'); } catch (e) {}
  b.scrollTop = b.scrollHeight;
}
function showPhone(topic) {
  const qr = '<img src="/api/phone-qr.svg?t=' + Date.now() + '" alt="QR code" width="170" height="170" style="display:block;margin:6px 0;border:1px solid #ccc" onerror="this.style.display=&quot;none&quot;">';
  document.getElementById('phoneInfo').innerHTML =
    '<div style="text-align:right"><button class="linkbtn" onclick="togglePhone()">Hide &#10005;</button></div>' +
    'Install the free <b>ntfy</b> app, then <b>scan this code with your phone camera</b> (Android: it opens ntfy and subscribes by itself). ' +
    'iPhone, or if the scan does nothing: open ntfy, tap <b>+</b>, and paste the name below.' + qr +
    'Name (tap to select, then copy): <input readonly value="' + topic + '" onclick="this.select()" style="width:230px"> ' +
    'Then press <b>Send a test alert</b>.' +
    '<div style="margin-top:6px">You get a message when something is <b>bought</b> or <b>needs you</b>. It has buttons: <b>Buy one more</b> after a purchase, ' +
    '<b>Approve</b> / <b>Do not buy</b> for shipping, <b>It was bought</b> / <b>Not ordered</b> for an unclear order, and <b>Open Remote Desktop</b> for ' +
    'what only you can do on the PC (a card code, a password, a person check). A button that buys asks once more first. ' +
    'Restock messages: <b>' + (restockAlertsOn ? 'ON' : 'OFF') + '</b> <button class="linkbtn" onclick="setRestockAlerts(' + (restockAlertsOn ? 'false' : 'true') + ').then(() => showPhone(phoneTopic))">' +
    (restockAlertsOn ? 'turn off' : 'turn on') + '</button></div>';
}
function testLine(state, text) {
  const mark = {ok: '<span class="status-instock">&#10003;</span>', warn: '<span class="status-stale">&#9888;</span>', bad: '<span class="status-unknown">&#10007;</span>', off: '&#8211;'}[state] || '';
  return '<div style="margin:3px 0">' + mark + ' ' + text + '</div>';
}
async function testAlerts() {
  const box = document.getElementById('testResult');
  box.style.display = 'block';
  box.innerHTML = '<b>Sending a test...</b> (about 10 seconds)';
  let d = {};
  try { d = await (await fetch('/api/notify-test', {method: 'POST'})).json(); } catch (e) { d = {phone: {state: 'bad', text: 'Could not reach the program.'}}; }
  // the browser alert (this page): ask for permission now - a click is required for the browser to ask
  let bt = {state: 'off', text: ''};
  if (!('Notification' in window)) bt = {state: 'bad', text: 'This browser cannot show notifications.'};
  else {
    if (Notification.permission === 'default') { try { await Notification.requestPermission(); } catch (e) {} }
    if (Notification.permission === 'granted') {
      try { new Notification('Restalker', {body: 'Test alert. You will see one like this when a restock is logged.', silent: true, tag: 'restock-test-' + Date.now()});
            bt = {state: 'ok', text: 'Browser alert sent. It appears in the corner of the screen (Windows Focus assist / Do not disturb or a full-screen game can hide it). It only works while this page stays open in a tab.'}; }
      catch (e) { bt = {state: 'bad', text: 'The browser refused: ' + e}; }
    } else if (Notification.permission === 'denied') bt = {state: 'bad', text: 'Browser alerts are BLOCKED for this page. Click the padlock next to the address, set Notifications to Allow, then test again.'};
    else bt = {state: 'warn', text: 'The browser did not get permission. Press the test again and choose Allow when it asks.'};
  }
  showAlertInfo();
  let h = '<div style="text-align:right;float:right"><button class="linkbtn" onclick="document.getElementById(&quot;testResult&quot;).style.display=&quot;none&quot;">Hide &#10005;</button></div><b>Test alert - what happened:</b>';
  h += testLine((d.phone || {}).state, '<b>Phone</b> (ntfy): ' + ((d.phone || {}).text || ''));
  h += testLine((d.popup || {}).state, '<b>Windows pop-up</b>: ' + ((d.popup || {}).text || ''));
  h += testLine((d.discord || {}).state, '<b>Discord</b>: ' + ((d.discord || {}).text || ''));
  h += testLine(bt.state, '<b>Browser alert</b>: ' + bt.text);
  h += '<div style="margin-top:4px;color:#555">Purchases and problems: always sent' + (d.topic ? ' (on the phone with buttons - tap <b>Test this button</b> on the test message to check that a tap reaches this PC)' : '') +
       '. Restock messages: <b>' + (d.restocks_on ? 'ON' : 'OFF') + '</b> <button class="linkbtn" onclick="setRestockAlerts(' + (d.restocks_on ? 'false' : 'true') + ')">' + (d.restocks_on ? 'turn off' : 'turn on') + '</button>.</div>';
  h += '<div style="margin-top:4px;color:#555">Phone ' + (d.topic ? 'ON' : 'not set up') + '; Windows pop-up <b>' + (d.popup_on ? 'ON' : 'OFF') + '</b> ' +
       '<button class="linkbtn" onclick="setPopup(' + (d.popup_on ? 'false' : 'true') + ')">' + (d.popup_on ? 'turn off' : 'turn on') + '</button>; browser alert ' + ((('Notification' in window) && Notification.permission === 'granted') ? 'ON' : 'off') + '.</div>';
  box.innerHTML = h;
}
async function setRestockAlerts(on) {
  let d = {};
  try { d = await (await fetch('/api/restock-alerts', {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({on: on})})).json(); } catch (e) {}
  restockAlertsOn = !!d.on;
  const box = document.getElementById('testResult');
  if (box) box.innerHTML += '<div>Restock messages are now <b>' + (d.on ? 'ON' : 'OFF') + '</b> (purchases and problems are always sent).</div>';
}
async function setPopup(on) {
  try { await fetch('/api/popup-setting', {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({on: on})}); } catch (e) {}
  const box = document.getElementById('testResult');
  if (box) box.innerHTML += '<div>Windows pop-ups for real restocks are now <b>' + (on ? 'ON' : 'OFF') + '</b>.</div>';
}
async function loadPhone() {
  try {
    const d = await (await fetch('/api/phone-setup')).json();
    if (d.topic) phoneTopic = d.topic;
  } catch (e) {}
  const pbt = document.getElementById('phoneBtn'); if (pbt) pbt.innerHTML = phoneLabel() + ' &#9662;';
  try { if (localStorage.getItem('rk_log_big') === '1') toggleLog(); } catch (e) {}
}
const PUSH_NAMES = {trackalacker: 'TrackaLacker', hotstock: 'HotStock', discord: 'Discord'};
function pushSignedUp(s) {      // proof that the site really has this window on its alert list: a sign-up, a service worker, or an alert that arrived
  return !!((s.push_subscriptions || 0) > 0 || (s.service_workers || 0) > 0 || (s.alerts_seen || 0) > 0);
}
function pushGood(s) {
  return !!(s.checked_at && s.permission === 'granted' && s.tab_open !== false && pushSignedUp(s));
}
function pushWhy(s) {
  if (!s.checked_at) return 'not checked yet';
  if (s.permission === 'denied') return 'notifications are BLOCKED in its window';
  if (s.permission !== 'granted') return 'notifications not allowed yet in its window (press Allow there)';
  if (s.tab_open === false) return 'its page is not open in the alert window';
  if (s.can_enable && s.signup_at && s.signup_ok === false) return 'allowed in its window, and the program already tried the site\u2019s own sign-up button by itself (' + (s.signup_note || 'no result') + '). It keeps trying every few minutes, and what the page showed is saved in the diagnostics file under ALERT LISTENER';
  if (s.can_enable) return 'allowed in its window; the program is signing the site up by itself now (no pop-up to answer). Nothing is needed from you; then ALERT ME on the products';
  return 'logged in and allowed, but the site has NOT signed this window up for alerts (no sign-up found, none received yet): on its site use the Browser alert sign-up (Allow), then press ALERT ME on the products';
}
async function dismissPush(id, on) {
  try { await fetch('/api/push-dismiss', {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({id: id, on: on})}); } catch (e) {}
  poll();
}
function updatePushBanner(pu, dismissed, ts) {
  ts = ts || {};
  const el = document.getElementById('pushBanner');
  if (!el) return;
  dismissed = dismissed || [];
  const di = document.getElementById('dismissInfo');
  if (di) {
    const shown = dismissed.filter(x => x !== 'idle').map(x => PUSH_NAMES[x] || x);
    di.innerHTML = shown.length ? 'Reminders hidden for ' + shown.join(', ') + ' ' + dismissed.filter(x => x !== 'idle').map(x => '<button class="linkbtn" onclick="dismissPush(&quot;' + x + '&quot;, false)">show again (' + (PUSH_NAMES[x] || x) + ')</button>').join('') : '';
  }
  const need = [], good = [], covered = [];
  for (const [pid, s] of Object.entries(pu.trackers || {})) {
    const pg = ts[pid + '_page'];       // v39: the tracker's public page is read directly - no sign-up needed while that works
    if (pg && pg.ok === true && pg.checked_at && (Date.now() / 1000 - pg.checked_at) < 180) covered.push(pid);
    else if (pushGood(s)) good.push(pid);
    else if (!dismissed.includes(pid)) need.push([pid, s]);
  }
  let h = '';
  if (pu.setup_open) {
    h = '<b>Set-up window is open</b> (an ordinary Chrome window - find it on your screen). Sign in to TrackaLacker and HotStock there. ' +
        'If a &quot;verify you are human&quot; box appears, tick it yourself (the program never touches it). ' +
        'TrackaLacker: notification settings &rarr; <b>Browser Push Notifications</b> &rarr; <b>Enable on this device</b> &rarr; <b>Allow</b>. ' +
        'HotStock: just log in (notifications are already allowed for it, so there is no Allow pop-up). Then press <b>I&#39;m done</b> below: the program presses HotStock&#39;s own <b>Enable browser alerts</b> button for you. After that, press <b>ALERT ME</b> on the Collector Booster Box products. ' +
        'When done press <button onclick="pushAct(&quot;probe&quot;)">I&#39;m done - Check my setup</button> (this closes the window; your sign-ins are kept).';
  } else if (!pu.connected) {
    if (dismissed.includes('idle')) { el.style.display = 'none'; return; }
    h = 'TrackaLacker / HotStock alerts are recorded only while the program is watching (press <b>Start watching</b>). ' +
        '<button class="linkbtn" onclick="dismissPush(&quot;idle&quot;, true)">Don&#39;t show this</button>';
  } else if (need.length === 0 && covered.length && good.length === 0) {
    h = covered.map(x => '<b>' + (PUSH_NAMES[x] || x) + '</b>').join(' and ') + ': read straight from its public page every few seconds - no sign-up or pop-up needed.';
  } else if (need.length === 0) {
    el.style.display = 'none'; return;
  } else if (good.length === 0 && !dismissed.length) {
    h = '<b>' + need.map(x => PUSH_NAMES[x[0]] || x[0]).join(' and ') + ' not set up yet, so their alerts are NOT being recorded.</b> ' +
        'A sign-in is needed once, inside this program&#39;s own Chrome window (your normal Chrome login does not carry over).' +
        '<ol style="margin:6px 0 6px 18px;padding:0;line-height:1.5">' +
        '<li>Press <button onclick="pushAct(&quot;setup&quot;)">Open set-up window</button>. A separate Chrome window opens with the pages.</li>' +
        '<li><b>TrackaLacker</b> tab: log in. In your notification settings find <b>Browser Push Notifications</b>, press <b>Enable on this device</b>, then <b>Allow</b>.</li>' +
        (need.some(x => x[0] === 'hotstock') ? '<li><b>HotStock</b> tab: log in (notifications are already allowed - no pop-up to answer). Then press <button onclick="pushAct(&quot;enable&quot;)">Turn on HotStock alerts for me</button>: the program presses HotStock&#39;s own <b>Enable browser alerts</b> button by itself. Afterwards press <b>ALERT ME</b> on the Collector Booster Box products.</li>' : '<li><b>HotStock</b> needs nothing here: since v41 the program reads its public product pages by itself (no log-in, no alerts).</li>') +
        '<li>Press <button onclick="pushAct(&quot;probe&quot;)">I&#39;m done - Check my setup</button>. This box goes away once a tracker works - or press <b>Don&#39;t remind me</b> for one you do not want.</li></ol>' +
        need.map(x => '<button class="linkbtn" onclick="dismissPush(&quot;' + x[0] + '&quot;, true)">Don&#39;t remind me about ' + (PUSH_NAMES[x[0]] || x[0]) + '</button>').join(' ');
  } else {
    // at least one tracker works (or you hid one): a short note instead of the long steps
    h = need.map(x => '<b>' + (PUSH_NAMES[x[0]] || x[0]) + '</b> is not receiving alerts yet: ' + pushWhy(x[1]) + '. ' +
        '<button class="linkbtn" onclick="pushAct(&quot;setup&quot;)">Open set-up window</button>' +
        (x[1].can_enable ? '<button class="linkbtn" onclick="pushAct(&quot;enable&quot;)">Turn on HotStock alerts for me</button>' : '') +
        '<button class="linkbtn" onclick="pushAct(&quot;probe&quot;)">Check again</button>' +
        '<button class="linkbtn" onclick="dismissPush(&quot;' + x[0] + '&quot;, true)">Don&#39;t remind me</button>').join('<br>');
  }
  if (el.dataset.h !== h) { el.innerHTML = h; el.dataset.h = h; }
  el.style.display = 'block';
  el.style.padding = (h.indexOf('<ol') >= 0 || pu.setup_open) ? '6px 10px' : '3px 10px';
  el.style.border = (h.indexOf('<ol') >= 0 || pu.setup_open) ? '2px solid #d97706' : '1px solid #e0b070';
}
// v61: the diagnostics download shows that it is working, is started only once however often it is clicked, and is saved in one piece
document.addEventListener('click', async ev => {
  const a = ev.target.closest ? ev.target.closest('#diagBtn') : null;
  if (!a) return;
  ev.preventDefault();
  if (a.dataset.busy) return;
  a.dataset.busy = '1';
  const old = a.innerText;
  a.innerText = 'Preparing diagnostics...';
  try {
    const r = await fetch('/api/diagnostics', {cache: 'no-store'});
    const b = await r.blob();
    const u = URL.createObjectURL(b), x = document.createElement('a');
    x.href = u; x.download = 'restock-kit-diagnostics.txt'; document.body.appendChild(x); x.click();
    setTimeout(() => { URL.revokeObjectURL(u); x.remove(); }, 10000);
  } catch (e) { alert('The diagnostics could not be downloaded: ' + e); }
  finally { a.innerText = old; delete a.dataset.busy; }
});
let pollBusy = false;
async function poll() {
  // v61: never more than ONE status request at a time. (When the program was busy, the requests piled up and used every connection the
  // browser allows - the diagnostics download then had to wait minutes for a free one.)
  if (programClosed || pollBusy) return;
  pollBusy = true;
  setTimeout(() => { pollBusy = false; }, 20000);
  try { await pollOnce(); } finally { pollBusy = false; }
}
async function pollOnce() {
  try {
    const r = await fetch('/api/status');
    const d = await r.json();
    if (d.version && d.version !== PAGE_VERSION) {     // an old page left open from before an update: load the new one
      let again = false;
      try { again = sessionStorage.getItem('rk_reloaded') === d.version; sessionStorage.setItem('rk_reloaded', d.version); } catch (e) {}
      if (!again) { location.reload(); return; }
    }
    document.getElementById('statusDot').className = 'dot ' + (d.running ? 'on' : 'off');
    document.getElementById('statusText').innerText = d.running ? 'Running' : 'Stopped';
    { const sb = document.getElementById('startBtn'); sb.disabled = d.running;          // v62: says what is happening
      const lbl = d.running ? 'Actively watching' : 'Start watching'; if (sb.innerText !== lbl) sb.innerText = lbl;
      sb.title = d.running ? 'Every product is being watched right now' : 'Start watching every product'; }
    showGame(d.gaming, d.gaming_mode, d.gaming_reason);
    STOREHEALTH = d.stores_health || {}; healthShow(STOREHEALTH);
    updShow(d.update || {});
    lpBrief(d.load);
    if (typeof mxRevCheck === 'function') mxRevCheck(d.matrix_rev);
    document.getElementById('stopBtn').disabled = false;
    if (d.restock_alerts && lastRestocks !== null && d.restocks > lastRestocks) browserNotify('Restock logged', 'A restock was just logged. There is data to download now.');
    restockAlertsOn = !!d.restock_alerts;
    lastRestocks = d.restocks;
    document.getElementById('restockCount').innerText = d.restocks;
    document.getElementById('alertCount').innerText = d.alerts;
    const box = document.getElementById('logbox');
    const atBottom = box.scrollTop + box.clientHeight >= box.scrollHeight - 10;
    box.innerText = d.logs.length ? d.logs.join('\\n') : 'Not running yet.';
    if (atBottom) box.scrollTop = box.scrollHeight;

    for (const [tid, s] of Object.entries(d.target_status || {})) {
      const cell = document.getElementById('tstatus-' + tid);
      if (cell) {
        cell.innerText = (s.status || 'not checked yet') + ' · checked ' + timeAgo(s.checked_at);
        cell.className = 'status-cell ' + statusClass(s.status);
      }
    }
    for (const [trid, s] of Object.entries(d.tracker_status || {})) {
      const cell = document.getElementById('trstatus-' + trid);
      if (cell) {
        let txt = 'checked ' + timeAgo(s.checked_at) + (s.note ? ' · ' + s.note : '');
        if (s.ok === false) txt = 'page failed to load · ' + txt;
        if (s.last_mention_at) txt += ' · last mention ' + timeAgo(s.last_mention_at);
        cell.innerText = txt;
        cell.className = 'status-cell' + (s.ok === false ? ' status-unknown' : '');
      }
    }
    if (typeof mxStatus === 'function') { MXRUN = d.running; mxStatus(d.target_status || {}); }
    engineShow(d.engines);
    buyShow(d.buyer);
    const pu = d.push || {};
    updatePushBanner(pu, d.push_dismissed || [], d.tracker_status || {});
    checkPushResult(pu);
    if (d.restock_alerts && lastPush !== null && (pu.events || 0) > lastPush) browserNotify('Live tracker alert', 'A TrackaLacker / HotStock alert just arrived.');
    lastPush = pu.events || 0;
    for (const [pid, s] of Object.entries(pu.trackers || {})) {
      const cell = document.getElementById('pushstatus-' + pid);
      if (cell) { const r = describePush(pu, s); cell.innerHTML = r.html; cell.className = 'status-cell ' + r.cls; }
    }
    const pb = document.getElementById('pushBrowser');
    if (pb) pb.innerText = pu.setup_open ? 'set-up window open' : !pu.connected ? 'not open' : (pu.visible ? 'open (visible)' : 'running (hidden)');
    const st = document.getElementById('pushSelftest');
    if (st) st.innerText = pu.selftest ? ((pu.selftest.ok ? 'PASSED - ' : 'FAILED - ') + pu.selftest.detail + ' (' + timeAgo(pu.selftest.at) + ')') : 'not run yet';
    const pr = document.getElementById('pushRecent');
    if (pr) pr.innerText = (pu.recent && pu.recent.length) ? pu.recent.map(x => x.at + ' UTC  ' + x.tracker + '  ' + (x.words || '(no words)') + '  -> ' + (x.outcome || '')).join('\\n') : 'No alerts have arrived yet.';
  } catch (e) {
    if (UPD_RESTART) {         // v104: the new version is starting - say so, and say what to do if it does not come back
      const sec = Math.round((Date.now() - UPD_RESTART) / 1000);
      updNote(sec < 180 ? 'Restalker is starting the new version... (' + sec + ' s) - this page reloads by itself.'
                        : 'The new version did not start by itself. Open the Restalker folder and double-click <b>start_app.bat</b> - this page then reloads by itself.');
    }
  }
}
function describePush(pu, s) {
  if (!pu.connected) return {html: 'Alert browser is not running yet. Click "Open the set-up window" (below) or "Start watching".', cls: 'status-stale'};
  const ok = '<span class="status-instock">&#10003;</span> ', no = '<span class="status-unknown">&#10007;</span> ';
  const L = [];
  if (s.checked_at) {
    L.push(s.permission === 'granted' ? ok + 'notifications allowed'
      : (s.permission === 'denied' ? no + 'notifications are BLOCKED (click the padlock next to the address, set Notifications to Allow)'
      : no + 'notifications NOT allowed yet (click Allow in the alert window)'));
    if (s.tab_open === false) L.push(no + 'page not open');
    else if (s.tab_open) L.push(ok + 'page kept open');
    L.push(pushSignedUp(s) ? ok + 'signed up for alerts' : no + 'no alert sign-up found (' + (s.can_enable ? 'press &quot;Turn on HotStock alerts for me&quot; below, then ALERT ME on the products' : 'sign in, use the site&#39;s Browser alert sign-up, then press ALERT ME on the products') + ')');
    if (s.signup_note) L.push((s.signup_ok ? ok : no) + 'last automatic sign-up try (' + timeAgo(s.signup_at) + '): ' + s.signup_note);
  } else L.push('setup not checked yet (press "Check my setup")');
  L.push('alerts received so far: <b>' + (s.alerts_seen || 0) + '</b>' + (s.last_alert_at ? ' (last ' + timeAgo(s.last_alert_at) + ')' : ''));
  return {html: L.join('<br>'), cls: pushGood(s) ? '' : 'status-stale'};
}
let pushWait = null;
function showPushResult(state, html) {
  const el = document.getElementById('pushResult') || document.getElementById('pushResultTop');
  if (!el) return;
  el.className = 'presult ' + state; el.innerHTML = html; el.style.display = 'block';
}
let buyOn = null, buyVis = false, buyLast = null;
function esc(x) { return String(x === null || x === undefined ? '' : x).replace(/[&<>"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c])); }
function money(v) { return (v === null || v === undefined || v === '') ? '' : '$' + Number(v).toFixed(2); }
let buySeen = null;
const BUY_ALERT_KINDS = ['BOUGHT', 'APPROVE', 'CVV', 'OLDBOUGHT', 'CHECK'];      // v58: alerts only when bought (plus the two questions a purchase waits for)
function buyAlerts(b) {                 // v57: every purchase event also shows as a browser alert on this PC (when browser alerts are on)
  const evs = b.events || [];
  const newest = evs.reduce((m, e) => Math.max(m, e.t || 0), 0);
  if (buySeen === null) { buySeen = newest; return; }
  for (const e of evs.slice().reverse()) if ((e.t || 0) > buySeen && BUY_ALERT_KINDS.includes(e.kind)) browserNotify(e.title || 'Restalker purchase', e.text || '');
  buySeen = Math.max(buySeen, newest);
}
function buyShow(b) {
  if (!b) return;
  buyAlerts(b);
  buyOn = !!b.on; buyVis = !!b.visible;
  const btn = document.getElementById('buyBtn');
  btn.innerText = buyOn ? 'Buying ON' : 'Buying OFF';
  btn.title = buyOn ? 'Press to turn buying off (nothing is bought while it is off)' : 'Press to turn buying on';
  btn.style.background = buyOn ? '#1a7f37' : ''; btn.style.color = buyOn ? '#fff' : '';
  const good = buyOn && b.connected && b.signed_in && !b.emergency && b.armed_count > 0;
  document.getElementById('buyDot').className = 'dot ' + (good ? 'on' : 'off');
  const ln = document.getElementById('buyLine');
  ln.innerText = b.line_short || b.line || '';
  ln.title = b.line || '';
  ln.style.color = (buyOn && (b.signed_in === false || !b.listening || b.browser === 'cannot start' || b.emergency || b.engine_problem)) ? '#b42318' : (good ? '#087a36' : '#333');
  const w = document.getElementById('buyWarn');
  w.style.display = 'none';          // v58: no note about the old extension (it is refused silently)
  if (b.foreign) w.innerHTML = '<b>Remove the old MTG Amazon Buyer extension from your normal Chrome.</b> Restalker buys by itself now, and that extension could buy a second time. In Chrome open <b>chrome://extensions</b>, find <b>MTG Amazon Buyer</b> and press <b>Remove</b>.';
  if (typeof mxBuy === 'function') mxBuy(b);
  buyBarShow(b);
  // v97: purchases and problems apart - the Problems button counts what needs you NOW (ideally none)
  const pall = b.purchases || [], pur = pall.filter(x => !purVoid(x)), need = openProblems(b);
  const pb = document.getElementById('purchBtn'), qb = document.getElementById('probBtn');
  const fresh = pur.filter(x => Date.now() / 1000 - x.t < 86400).length;
  if (pb) { const t = 'Purchases' + (pur.length ? ' (' + pur.length + ')' : '') + (fresh ? ' &middot; ' + fresh + ' today' : '') + ' &#9662;'; if (pb.dataset.h !== t) { pb.innerHTML = t; pb.dataset.h = t; } }
  if (qb) { const t = need.length ? '&#9888; Problems: ' + need.length + ' &#9662;' : 'Problems: none &#9662;';
            if (qb.dataset.h !== t) { qb.innerHTML = t; qb.dataset.h = t; } qb.classList.toggle('bad', need.length > 0); qb.classList.toggle('good', !need.length); }
  const key = JSON.stringify([pall.map(x => [x.t, x.check && x.check.state]), need, b.problems_log, b.activity]);
  if (key === buyLast) return; buyLast = key;
  const pbox = document.getElementById('purchBox');
  if (pbox && pbox.style.display === 'block') pbox.innerHTML = purchHtml(pall);
  const qbox = document.getElementById('probBox');
  if (qbox && qbox.style.display === 'block') qbox.innerHTML = probHtml(need, b.problems_log || [], b.activity || []);
}
const ORDERS = {'Amazon': 'https://www.amazon.com/gp/css/order-history', 'Best Buy': 'https://www.bestbuy.com/profile/ss/orders', 'Target': 'https://www.target.com/orders',
                'Walmart': 'https://www.walmart.com/orders', 'GameStop': 'https://www.gamestop.com/account/order-history/'};
// v115 (owner: "the program should be able to automatically correct this list on its own as well"): each purchase shows its check -
// verified in your orders, not found (crossed out, not counted), or your decision - and Remove / Keep buttons
function purVoid(x) { return !!(x.check && (x.check.state === 'not_found' || x.check.state === 'removed')); }
function purCheck(x) {
  const c = x.check || {}, st = c.state || '', q = '\\'' + esc(x.key || '') + '\\'';
  const rm = '<button class="linkbtn" title="It was not bought: crossed out and not counted" onclick="if (confirm(&quot;Cross this purchase out? (It was not bought.)&quot;)) buyAct(\\'purchase_remove\\',' + q + ')">Remove</button>';
  const keep = '<button class="linkbtn" title="It was bought: counted again" onclick="buyAct(\\'purchase_keep\\',' + q + ')">Keep</button>';
  if (st === 'verified') return '<span style="color:#1a7f37" title="' + esc(c.why || '') + '">&#10003; in your orders</span> ' + rm;
  if (st === 'kept') return '<span class="sub">kept by you</span> ' + rm;
  if (st === 'removed') return '<span style="color:#b42318">removed by you</span> ' + keep;
  if (st === 'not_found') return '<span style="color:#b42318" title="' + esc(c.why || '') + '">NOT in your orders - not counted</span> ' + keep;
  if (st === 'unconfirmed') return '<span style="color:#9a6700" title="' + esc(c.why || '') + '">not in your orders yet</span> ' + rm;
  return rm;
}
function purchHtml(pall) {
  if (!pall.length) return '<div class="sub">No purchases yet. Every purchase is listed here for good, newest first (also in the file purchases.csv in your Restalker folder).</div>';
  const pur = pall.filter(x => !purVoid(x)), total = pur.reduce((m, x) => m + (x.price || 0), 0), nv = pall.length - pur.length;
  let h = '<div style="margin-bottom:4px"><b>' + pur.length + ' purchase' + (pur.length === 1 ? '' : 's') + '</b> &middot; ' + money(total) + ' in all (item prices) ' +
          (nv ? '&middot; <span style="color:#b42318">' + nv + ' crossed out (not bought)</span> ' : '') +
          '<span class="sub">- kept for good, newest first; Amazon purchases are checked against your Amazon orders by themselves; also in purchases.csv in your Restalker folder</span></div>';
  h += '<table class="ptab"><tr><th>When</th><th>Store</th><th>Product</th><th>Price</th><th>Order number</th><th>Bought by</th><th>Check</th><th></th></tr>';
  for (const x of pall) {
    const v = purVoid(x), o = (x.check && x.check.order) || x.order;
    const sx = v ? ' style="text-decoration:line-through;color:#888"' : '';
    h += '<tr><td style="white-space:nowrap' + (v ? ';text-decoration:line-through;color:#888' : '') + '">' + esc(buyWhen(x)) + '</td><td' + sx + '>' + esc(x.store) + '</td><td' + sx + '>' + esc(x.product) + '</td><td class="num"' + sx + '>' + money(x.price) +
       '</td><td' + sx + '>' + esc(o || '-') + '</td><td class="sub"' + sx + '>' + esc(x.by || '') + '</td><td style="white-space:nowrap">' + purCheck(x) + '</td><td>' +
       (ORDERS[x.store] ? '<a href="' + ORDERS[x.store] + '" target="_blank" rel="noopener">your ' + esc(x.store) + ' orders</a>' : '') + '</td></tr>';
  }
  return h + '</table>';
}
function openProblems(b) {
  // what needs you RIGHT NOW (worked out from the program's live state, so a problem that was solved disappears by itself)
  const out = [], q = s => '\\'' + esc(s) + '\\'';
  for (const n of (b.checkout_now || [])) {
    if (n.approval) out.push({t: '<b>Shipping ' + money(n.approval.shipping) + ' needs your OK</b> - ' + esc(n.product) + ' at ' + esc(n.store) + ' (the checkout waits up to 10 minutes)',
                              a: '<button onclick="buyAct(\\'approve\\',' + q(n.tid) + ')">Approve</button><button onclick="buyAct(\\'cancel\\',' + q(n.tid) + ')">Do not buy</button>'});
    if (n.needCvv) out.push({t: '<b>Card security code needed</b> - ' + esc(n.product) + ' at ' + esc(n.store) + ': type it in the orange bar at the top (or save it under Card code)', a: ''});
  }
  const hc = b.human_check;
  if (hc) out.push({t: '<b>' + esc(hc.store) + (hc.why === 'signin' ? ' wants your password</b> before checkout' : ' wants you to show you are a person</b>') + ' - ' + esc(hc.product),
                    a: '<button onclick="buyAct(\\'checkopen\\')">' + (hc.why === 'signin' ? 'Sign in to ' : 'Open ') + esc(hc.store) + '</button>'});
  for (const r of (b.rows || [])) {
    if (r.frozen === 'unknown') out.push({t: '<b>Order result unknown</b> - ' + esc(r.product) + ' at ' + esc(SNAME[r.store] || r.store) + ': check your orders there, then answer',
      a: '<button onclick="if (confirm(&quot;The order WAS placed?&quot;)) buyAct(\\'markbought\\',' + q(r.tid) + ')">It was bought</button>' +
         '<button onclick="if (confirm(&quot;Nothing was ordered? It is then bought at the next restock.&quot;)) buyAct(\\'again\\',' + q(r.tid) + ')">Not ordered - buy again</button>' +
         (ORDERS[SNAME[r.store]] ? ' <a href="' + ORDERS[SNAME[r.store]] + '" target="_blank" rel="noopener" style="font-size:12px">orders</a>' : '')});
  }
  const armed = (b.armed_count || 0) > 0;
  if (b.on && armed && b.signed_in === false) out.push({t: '<b>Not signed in to Amazon</b> - products set to Buy at Amazon cannot be bought', a: '<button onclick="buyAct(\\'signin\\',\\'amazon\\')">Sign in to Amazon</button>'});
  for (const [k, v] of Object.entries(b.shop_signed_in || {})) if (b.on && armed && v === false)
    out.push({t: '<b>Not signed in to ' + esc(SNAME[k] || k) + '</b> - products set to Buy there cannot be bought', a: '<button onclick="buyAct(\\'signin\\',' + q(k) + ')">Sign in to ' + esc(SNAME[k] || k) + '</button>'});
  if (b.engine_problem) out.push({t: '<b>Buying engine:</b> ' + esc(b.engine_problem), a: ''});
  if (b.on && b.browser === 'cannot start') out.push({t: '<b>The buying browser cannot start</b> - ' + esc(b.browser_detail || ''), a: ''});
  for (const [k, v] of Object.entries(STOREHEALTH || {})) if (v.state === 'stalled')
    out.push({t: '<b>' + esc(SNAME[k] || k) + ': none of its products is being read</b> - ' + esc(v.text) + '; restocks there are not seen right now (the program keeps trying)', a: ''});
  if (CODELAST && CODELAST.paused) out.push({t: '<b>Your saved card code was turned down</b> - save the right one', a: '<button onclick="codeToggle()">Card code</button>'});
  return out;
}
const SNAME = {amazon: 'Amazon', bestbuy: 'Best Buy', target: 'Target', walmart: 'Walmart', gamestop: 'GameStop'};
function probHtml(need, log, act) {
  let h = need.length ? '<b>Needs you now</b>' + need.map(x => '<div class="need">' + x.t + ' ' + x.a + '</div>').join('')
                      : '<div class="allgood">&#10003; Nothing needs you right now.</div>';
  h += '<div style="margin-top:8px"><b>Earlier</b> <span class="sub">(messages that needed you; newest first)</span></div>' +
       (log.length ? log.map(e => '<div><span class="sub">' + esc(buyWhen(e)) + '</span> &nbsp;' + esc(e.text) + '</div>').join('') : '<div class="sub">none</div>');
  h += '<div style="margin-top:6px"><button class="linkbtn" onclick="toggleBox(\\'actBox\\', this)">Other activity (checkouts, sold out, tried again...) &#9662;</button></div>' +
       '<div id="actBox" style="display:' + (ACTOPEN ? 'block' : 'none') + '">' +
       (act.length ? act.map(e => '<div class="sub">' + esc(buyWhen(e)) + ' &nbsp;' + esc(e.text) + '</div>').join('') : '<div class="sub">none</div>') + '</div>';
  return h;
}
function copyGet(kind) {
  const pr = (document.getElementById('cpProducts') || {}).checked ? '1' : '0', dc = (document.getElementById('cpDiscord') || {}).checked ? '1' : '0';
  if (kind === 'move' && !confirm('This copy holds your phone and Discord names. Keep the file private, and run Restalker on one PC at a time. Download it?')) return;
  location.href = '/api/export?kind=' + kind + (kind === 'new' ? '&products=' + pr + '&discord=' + dc : '');
}
async function helpToggle(btn) {
  toggleBox('helpBox', btn);
  const box = document.getElementById('helpBox');
  if (box.style.display !== 'block') return;
  let u = '';
  try { u = (await (await fetch('/api/help')).json()).url || ''; } catch (e) {}
  box.innerHTML = '<div style="display:flex;gap:14px;align-items:center;flex-wrap:wrap"><img src="/api/help-qr.svg?t=' + Date.now() + '" width="150" height="150" alt="QR code of the guide" style="border:1px solid #ccc">' +
    '<div><b>The guide and the release notes</b><br>Scan the code with your phone camera, or <a href="' + esc(u) + '" target="_blank" rel="noopener">open the guide</a>.' +
    '<div class="sub" style="margin-top:4px">The guide is a document that is kept up to date by itself - no program update needed to read the newest notes.</div></div></div>' +
    '<div id="updLine" style="margin-top:8px"></div>';
  updLine();
}
// v101: updates (updater.py) - only program files are ever replaced; your data is copied aside first and never touched
// v105 (owner 2026-11-06: "I would like the update button to be separated from the help function and static on the banner. it should
// either say "update available" or "check for updates" depending on the github status")
let UPD_STATE = {}, UPD_MSG_UNTIL = 0;
function updShow(u) {
  UPD_STATE = u || {};
  if (UPD_STATE.installing && !UPD_RESTART) UPD_RESTART = Date.now();     // (v115: an automatic install - the page waits for the new version)
  const b = document.getElementById('updBtn'); if (!b) return;
  b.style.display = UPD_STATE.connected === false ? 'none' : '';
  if (Date.now() < UPD_MSG_UNTIL) return;                   // (a short answer to a press stays a few seconds)
  const avail = !!(UPD_STATE.available && UPD_STATE.latest_version);
  b.innerText = UPD_STATE.installing ? 'Installing...' : avail ? (UPD_STATE.auto ? 'Updating to ' + UPD_STATE.latest_version + (UPD_STATE.waiting ? ' after the purchase' : '...') : 'Update available (' + UPD_STATE.latest_version + ')') : 'Check for updates';
  const sw = document.getElementById('updAuto'), swl = document.getElementById('updAutoL');
  if (sw && document.activeElement !== sw) sw.checked = !!UPD_STATE.auto;
  if (swl) swl.style.display = UPD_STATE.connected === false ? 'none' : '';
  b.style.background = avail ? '#1a7f37' : ''; b.style.color = avail ? '#fff' : ''; b.style.borderColor = avail ? '#1a7f37' : '';
}
async function updClick() {
  if (UPD_STATE.available && UPD_STATE.latest_version) { updInstall(); return; }
  const b = document.getElementById('updBtn');
  b.innerText = 'Checking...'; b.disabled = true;
  let d = null;
  try { d = await (await fetch('/api/update', {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({action: 'check'})})).json(); } catch (e) {}
  b.disabled = false;
  if (d && d.available && d.latest_version) { UPD_MSG_UNTIL = 0; updShow(Object.assign({}, UPD_STATE, {available: true, latest_version: d.latest_version, connected: true, auto: d.auto})); return; }
  b.innerText = !d ? 'No answer - try again' : d.error ? 'Could not check - try later' : 'Up to date (' + d.version + ')';
  b.title = d && d.error ? d.error : b.title;
  UPD_MSG_UNTIL = Date.now() + 6000;
  setTimeout(() => { UPD_MSG_UNTIL = 0; updShow(UPD_STATE); }, 6100);
  updLine();
}
// v115: automatic / manual updates
async function updAutoSet(on) {
  let d = null;
  try { d = await (await fetch('/api/update', {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({action: on ? 'auto_on' : 'auto_off'})})).json(); } catch (e) {}
  if (d) { updShow(Object.assign({}, UPD_STATE, {auto: d.auto, available: d.available, latest_version: d.latest_version, connected: d.connected})); updNote(on ? 'Automatic updates ON: a new version installs by itself (checked every hour), after any purchase in progress is finished.' : 'Automatic updates OFF: the button turns green when a new version is ready; you press Install.'); setTimeout(() => { const n = document.getElementById('updNote'); if (n) n.remove(); }, 6000); }
  else { const sw = document.getElementById('updAuto'); if (sw) sw.checked = !on; }
}
async function updLine(action) {
  const el = document.getElementById('updLine'); if (!el) return;
  let d = null;
  try { d = await (await fetch('/api/update', action ? {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({action: action})} : {})).json(); } catch (e) {}
  if (!d) { el.innerHTML = 'Updates: the program did not answer.'; return; }
  let h = '<b>Updates</b> (you run ' + esc(d.version) + '): ';
  if (!d.connected) h += 'not connected to the release home yet - updates come as a zip for now.';
  else if (d.available) h += '<b>' + esc(d.latest_version) + ' is ready</b>' + (d.notes ? ' - ' + esc(d.notes) : '') + ' <button class="pill" onclick="updInstall()">Install</button>';
  else h += (d.checked_at ? 'up to date (checked ' + timeAgo(d.checked_at) + ')' : 'not checked yet (it checks by itself every hour)') + ' <button class="linkbtn" onclick="updLine(\\'check\\')">Check now</button>';
  if (d.error) h += ' <span style="color:#b42318">' + esc(d.error) + '</span>';
  if (d.last && d.last.to === d.version) h += '<div class="sub">Updated from ' + esc(d.last.from) + ' ' + timeAgo(d.last.at) + '. <button class="linkbtn" onclick="updBack()">Go back to ' + esc(d.last.from) + '</button></div>';
  if (action && d.text) h += '<div class="sub">' + esc(d.text) + '</div>';
  el.innerHTML = h;
}
let UPD_RESTART = 0;          // v104: while the new version starts, "not answering" is expected - the page says so and reloads by itself
async function updInstall() {
  if (!confirm('Install the new version now?\\n\\nOnly program files are replaced. Your products, caps, settings, sign-ins, card code and purchases stay as they are (a copy of them is put aside first). Restalker closes and starts again by itself (about a minute without watching).')) return;
  const b = document.getElementById('updBtn'); if (b) { b.innerText = 'Installing...'; b.disabled = true; }
  let d = null;
  try { d = await (await fetch('/api/update', {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({action: 'install'})})).json(); } catch (e) {}
  if (d && d.ok) { UPD_RESTART = Date.now(); updNote('&#10003; ' + esc(d.text) + ' Please wait about a minute - do not close this page.'); return; }
  if (b) { b.disabled = false; updShow(UPD_STATE); }
  updNote(esc(d ? d.text : 'The program did not answer.'));
}
function updNote(html) {
  let n = document.getElementById('updNote');
  if (!n) { n = document.createElement('div'); n.id = 'updNote'; n.style.cssText = 'position:fixed;top:12px;left:50%;transform:translateX(-50%);z-index:9999;background:#ecfdf3;border:1px solid #1a7f37;color:#14532d;padding:10px 16px;border-radius:8px;box-shadow:0 4px 18px rgba(0,0,0,.2);max-width:640px;font-size:14px'; document.body.appendChild(n); }
  n.innerHTML = html;
}
async function updBack() {
  if (!confirm('Go back to the version before the last update? (Your data is not touched.)')) return;
  updLine('back');
}
let STOREHEALTH = {};
const HCOL = {ok: '#2da44e', slowed: '#d97706', stalled: '#cf222e', off: '#afb8c1'};
function healthShow(h) {
  const el = document.getElementById('healthStrip'); if (!el) return;
  const order = ['amazon', 'walmart', 'bestbuy', 'target', 'gamestop'];
  // (short: a pill only for a store that is slowed or stalled; when every watched store is read normally, one pill says so)
  const on = order.filter(k => h[k] && h[k].state !== 'off'), bad = on.filter(k => h[k].state !== 'ok');
  const all = on.map(k => SNAME[k] + ': ' + h[k].state + ' - ' + h[k].text).join('\\n');
  const x = !on.length ? '' : !bad.length ? '<span class="hpill" title="' + esc(all) + '"><i style="background:' + HCOL.ok + '"></i>all stores read</span>'
    : bad.map(k => '<span class="hpill" title="' + esc(all) + '"><i style="background:' + (HCOL[h[k].state] || '#afb8c1') + '"></i>' + esc(SNAME[k]) + ' ' + esc(h[k].state) + '</span>').join('');
  if (el.dataset.h !== x) { el.innerHTML = x; el.dataset.h = x; }
}
let ACTOPEN = false;
document.addEventListener('click', e => { if (e.target && e.target.closest && e.target.closest('#probBox .linkbtn')) setTimeout(() => { const x = document.getElementById('actBox'); ACTOPEN = !!x && x.style.display === 'block'; }, 0); });
let buyBarHidden = null;
function buyBarShow(b) {
  const el = document.getElementById('buyBar'); if (!el) return;
  const now = (b.checkout_now || [])[0], last = b.checkout_last;
  let cls = '', h = '';
  if (now) {
    const secs = now.since ? Math.max(0, Math.round(Date.now() / 1000 - now.since)) : null;
    cls = (now.approval || now.needCvv) ? 'bad' : 'go';
    // v90 (your report: "the status always shows Target ... I can't tell if it is the store or the product line"): the STORE is named as
    // a store ("at the Target store"), and a mere look at another store's page (the product restocked elsewhere) is called that
    // v90b (owner: "There should be no ambiguity"): the shop is always shown as "store: <name>" - never as a word in a sentence
    const at = ' &nbsp;&middot;&nbsp; store: <b>' + esc(now.store || '?') + '</b>' + (now.browser ? ' (' + esc(now.browser) + ')' : '') + ' &nbsp;&middot;&nbsp; ';
    h = ((now.approval || now.needCvv) ? '&#9888; <b>CHECKOUT WAITING FOR YOU</b>' + at : '&#128722; <b>CHECKOUT IN PROGRESS</b>' + at) + esc(now.product) + (now.price ? ' - ' + money(now.price) : '') +
        ' &nbsp;&middot;&nbsp; ' + esc(now.step) + (secs !== null ? ' &nbsp;&middot;&nbsp; ' + secs + ' s since detection' : '') + showCoBtns(b) +
        (now.approval ? ' &nbsp;<button onclick="buyAct(\\'approve\\',\\'' + esc(now.tid) + '\\')">Approve shipping ' + money(now.approval.shipping) + '</button> <button onclick="buyAct(\\'cancel\\',\\'' + esc(now.tid) + '\\')">Cancel</button>' : '') +
        (now.needCvv ? ' &nbsp;Card security code: <input id="cvv_' + esc(now.tid) + '" type="password" inputmode="numeric" maxlength="4" autocomplete="off" style="width:70px;display:inline-block;margin:0">' +
                       ' <button onclick="buyCvv(\\'' + esc(now.tid) + '\\')" style="background:#1a7f37;color:#fff;border:none">Send</button> <button onclick="buyAct(\\'cancel\\',\\'' + esc(now.tid) + '\\')">Cancel</button>' +
                       ' <span style="font-size:12px;color:#555">(used for this order only, never saved)</span>' : '');
  } else if (b.human_check) {
    // v65: a store showed the buying browser a "prove you are a person" page - you can do it yourself; the purchase is then tried again
    const hc = b.human_check;
    cls = 'bad';
    h = (hc.why === 'signin' ?
        '&#9888; <b>' + esc(hc.store) + ' WANTS YOUR PASSWORD BEFORE CHECKOUT</b> (' + esc(hc.product) + ' was not ordered by the buying browser; it is paused at ' + esc(hc.store) + ' - the other browsers go on) ' +
        ' &nbsp;<button onclick="buyAct(\\'checkopen\\')">Sign in to ' + esc(hc.store) + '</button> ' +
        '<span style="font-size:12px">' + (hc.opened ? 'sign in there (tick "Keep me signed in"), then close the window - the purchase is tried again right away' : 'the program never types passwords') + '</span>'
      : '&#9888; <b>' + esc(hc.store) + ' WANTS YOU TO SHOW YOU ARE A PERSON</b> before it lets Restalker buy ' + esc(hc.product) +
        ' &nbsp;<button onclick="buyAct(\\'checkopen\\')">Open ' + esc(hc.store) + '</button> ' +
        '<span style="font-size:12px">' + (hc.opened ? 'do the check in that window, then close it - the purchase is tried again right away' : 'the program never answers these checks; you can') + '</span>') +
        ' <span class="x" title="hide" onclick="buyAct(\\'checkdismiss\\')">&#10005;</span>';
  } else if ((b.views || []).length) {
    // v114: a checkout window you asked to see is still on your screen (it goes away by itself 5 minutes after the checkout ended)
    cls = 'go';
    h = '&#128065; <b>CHECKOUT WINDOW ON YOUR SCREEN</b> - ' + (b.views || []).map(v => esc(v.product || '')).join(', ') +
        ' &nbsp;<button onclick="buyAct(\\'hideco\\')">Hide</button> <span style="font-size:12px">(put away by itself 5 minutes after the checkout ended)</span>';
  } else if (last && last.t && buyBarHidden !== last.t) {
    cls = last.kind === 'BOUGHT' ? 'ok' : (last.kind === 'SUBMITTED' || last.kind === 'AGAIN' ? 'go' : 'bad');
    h = '<span class="x" title="hide" onclick="buyBarHidden=' + last.t + ';buyBarShow(window.__lastBuy||{})">&#10005;</span>' + (last.kind === 'BOUGHT' ? '&#10004; ' : '&#9888; ') + '<b>' + esc(last.at) + '</b> ' + esc(last.text);
  }
  window.__lastBuy = b;
  el.className = cls;
  const typing = document.activeElement && document.activeElement.id && document.activeElement.id.startsWith('cvv_');
  if (el.dataset.h !== h && !typing) { el.innerHTML = h; el.dataset.h = h; }
}
// v114 (owner, diagnostics 92: "when checkout is actively happening, there should be a link to pull up the active checkout page(s) for live
// monitoring (and intervention if necessary)"): one Show button per live checkout (the buying browser and every other browser checking out)
function showCoBtns(b) {
  const live = (b.checkout_now || []).filter(n => n.who), q = s => '\\'' + esc(s) + '\\'';
  let h = '';
  for (const n of live) {
    const label = 'Show ' + (live.length > 1 ? (n.browser || 'buying browser') + ' ' : '') + 'checkout';
    h += n.windowed ? ' <button title="puts this live checkout page on your screen; nothing is pressed for you. Closing that window stops this checkout - use Hide" onclick="buyAct(\\'showco\\',' + q(n.who + '|' + (n.who === 'main' ? n.tid : '')) + ')">' + esc(label) + '</button>'
                    : ' <span style="font-size:12px" title="Firefox and Camoufox run without a window">(' + esc(n.browser || '') + ': no window)</span>';
  }
  if ((b.views || []).length) h += ' <button onclick="buyAct(\\'hideco\\')">Hide checkout window' + ((b.views || []).length > 1 ? 's' : '') + '</button>';
  return h ? ' &nbsp;&middot;&nbsp;' + h : '';
}
function buyWhen(e) {
  if (e && e.t) { const d = new Date(e.t * 1000); return d.toLocaleDateString(undefined, {weekday: 'short', month: 'short', day: 'numeric'}) + ' ' + d.toLocaleTimeString(); }
  return (e && e.at) || '';
}
// v90 (your report: "I get no confirmation when I upload my credit card code ... the box goes blank"): once saved, the entry box is
// replaced by a clear confirmation with Replace / Remove; Enter saves too; a wrong entry says why. The code itself is never shown.
// v90b: the stores' sign-ins (the password is never sent back to this page)
const LOGIN_NAMES = {amazon: 'Amazon', bestbuy: 'Best Buy', target: 'Target', walmart: 'Walmart', gamestop: 'GameStop'};
function loginShow(d, msg) {
  const box = document.getElementById('loginRows'), b = document.getElementById('loginBtn');
  if (!d || !d.stores || !box) return;
  const n = Object.values(d.stores).filter(x => x.saved).length;
  if (b) b.innerHTML = 'Sign-ins: ' + (n ? '<b style="color:#1a7f37">' + n + ' saved</b>' : 'none saved') + ' &#9662;';
  box.innerHTML = Object.entries(LOGIN_NAMES).map(([k, nm]) => {
    const x = d.stores[k] || {};
    return '<div style="margin:3px 0"><b style="display:inline-block;width:80px">' + nm + '</b> ' + (x.saved
      ? '<span style="color:#1a7f37">&#10003; saved (' + esc(x.email || '') + ')</span> <button onclick="loginEdit(\\'' + k + '\\')">Replace</button> <button onclick="loginSave(\\'' + k + '\\', true)">Remove</button>'
      : loginForm(k)) + ' <span id="lmsg_' + k + '" style="color:#b42318">' + (msg && msg[k] ? esc(msg[k]) : '') + '</span></div>';
  }).join('');
}
function loginForm(k) {
  return 'e-mail or phone <input id="le_' + k + '" autocomplete="off" style="width:190px;display:inline-block;margin:0"> password <input id="lp_' + k +
    '" type="password" autocomplete="new-password" style="width:150px;display:inline-block;margin:0" onkeydown="if (event.key === \\'Enter\\') loginSave(\\'' + k + '\\', false)"> ' +
    '<button onclick="loginSave(\\'' + k + '\\', false)" style="background:#1a7f37;color:#fff;border:none">Save</button>';
}
function loginEdit(k) { const row = document.getElementById('lmsg_' + k).parentNode; row.innerHTML = '<b style="display:inline-block;width:80px">' + LOGIN_NAMES[k] + '</b> ' + loginForm(k) + ' <span id="lmsg_' + k + '"></span>'; }
async function loginToggle() {
  const x = document.getElementById('loginBox'); x.style.display = x.style.display === 'block' ? 'none' : 'block';
  try { loginShow(await (await fetch('/api/logins')).json()); } catch (e) {}
}
async function loginSave(k, remove) {
  if (remove && !confirm('Remove the saved ' + LOGIN_NAMES[k] + ' sign-in?')) return;
  const body = remove ? {store: k, remove: true} : {store: k, email: (document.getElementById('le_' + k) || {}).value || '', password: (document.getElementById('lp_' + k) || {}).value || ''};
  let d = null;
  try { d = await (await fetch('/api/logins', {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify(body)})).json(); } catch (e) {}
  if (!d) { const m = document.getElementById('lmsg_' + k); if (m) m.innerText = ' The program did not answer - nothing was saved.'; return; }
  loginShow(d, d.ok === false ? {[k]: ' ' + (d.msg || 'Not saved.')} : null);
}
setTimeout(async () => { try { loginShow(await (await fetch('/api/logins')).json()); } catch (e) {} }, 1700);
let CODELAST = null;
function codeShow(d, justSaved) {
  const m = document.getElementById('codeMsg'), b = document.getElementById('codeBtn');
  if (!d) return;
  if (d.ok !== false || d.saved !== undefined) CODELAST = d;
  const saved = !!d.saved && !d.paused;
  const sv = document.getElementById('codeSaved'), en = document.getElementById('codeEntry'), cc = document.getElementById('codeCancel');
  if (sv) sv.style.display = saved ? 'inline' : 'none';
  if (en) en.style.display = saved ? 'none' : 'inline';
  if (cc) cc.style.display = 'none';
  if (m) {
    m.innerText = d.ok === false ? (d.msg || 'Not saved.') : saved ? (justSaved ? ' Saved just now.' : '') : (d.msg || '');
    m.style.color = (d.paused || d.ok === false) ? '#b42318' : '#1a7f37';
  }
  if (b) b.innerHTML = 'Card code: ' + (d.paused ? '<b style="color:#b42318">turned down</b>' : d.saved ? '<b style="color:#1a7f37">saved &#10003;</b>' : 'not saved') + ' &#9662;';
}
function codeReplace() {
  document.getElementById('codeSaved').style.display = 'none';
  document.getElementById('codeEntry').style.display = 'inline';
  document.getElementById('codeCancel').style.display = 'inline';
  document.getElementById('codeMsg').innerText = '';
  const el = document.getElementById('codeIn'); el.value = ''; el.focus();
}
async function codeToggle() {
  const x = document.getElementById('codeBox'); x.style.display = x.style.display === 'block' ? 'none' : 'block';
  try { codeShow(await (await fetch('/api/cardcode')).json()); } catch (e) {}
}
async function codeSave(remove) {
  const el = document.getElementById('codeIn'), v = (el.value || '').replace(/\\D/g, '');
  if (!remove && (v.length < 3 || v.length > 4)) { const m = document.getElementById('codeMsg'); m.innerText = ' The security code has 3 or 4 digits - nothing was saved.'; m.style.color = '#b42318'; return; }
  if (remove && !confirm('Remove the saved card security code? Checkouts that need it will then wait for you.')) return;
  let d = null;
  try { d = await (await fetch('/api/cardcode', {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify(remove ? {remove: true} : {value: v})})).json(); } catch (e) {}
  el.value = '';
  codeShow(d || {ok: false, msg: 'The program did not answer - nothing was saved.'}, !remove && d && d.ok !== false);
}
setTimeout(async () => { try { codeShow(await (await fetch('/api/cardcode')).json()); } catch (e) {} }, 1500);
async function buyCvv(tid) {
  const el = document.getElementById('cvv_' + tid); if (!el) return;
  const v = el.value; el.value = '';
  let d = null;
  try { d = await (await fetch('/api/amazon-buy', {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({action: 'cvv', tid: tid, value: v})})).json(); } catch (e) {}
  if (d && d.result && d.result.ok === false) alert(d.result.reason || 'not accepted');
}
async function buyAct(action, tid) {
  let d = null;
  try { d = await (await fetch('/api/amazon-buy', {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({action: action, tid: tid || null})})).json(); } catch (e) {}
  if (d && d.result && d.result.ok === false && d.result.reason) alert(d.result.reason);
  buyLast = null;
  if (d) buyShow(d);
}
function toggleBox(id, btn) {
  const b = document.getElementById(id);
  if (!b) return;
  const on = b.style.display !== 'block';
  b.style.display = on ? 'block' : 'none';
  if (btn) btn.classList.toggle('open', on);
}
async function pushAct(a) {
  let d = {ok: false, error: 'The program did not answer. Is the black window still running?'};
  try { d = await (await fetch('/push/' + a, {method: 'POST'})).json(); } catch (e) {}
  if (!d.ok) { showPushResult('bad', d.error || 'That did not work.'); return; }
  if (a === 'probe') {
    pushWait = {kind: 'probe', since: Date.now() / 1000 - 1};
    showPushResult('wait', '<b>Checking each tracker...</b> this takes up to a minute (the alert browser may have to start first). The result appears here.');
  } else if (a === 'enable') {
    pushWait = {kind: 'enable', since: Date.now() / 1000 - 1};
    showPushResult('wait', '<b>Turning on the alerts...</b> the alert browser opens the tracker&#39;s settings page and presses its own Enable button. This takes up to a minute.');
  } else if (a === 'selftest') {
    pushWait = {kind: 'selftest', since: Date.now() / 1000 - 1};
    showPushResult('wait', '<b>Sending a test alert to the listener...</b> up to 30 seconds.');
  } else if (a === 'setup') {
    showPushResult('ok', 'The set-up window is opening: an ordinary Chrome window with the tracker pages. Sign in there, then press <b>Check my setup</b>.');
  } else if (a === 'hide') {
    showPushResult('ok', 'The alert browser is hidden. It keeps running and listening.');
  }
  poll();
}
function checkPushResult(pu) {
  if (!pushWait) return;
  const age = Date.now() / 1000 - pushWait.since;
  const esc = s => String(s == null ? '' : s).replace(/[&<>]/g, c => ({'&': '&amp;', '<': '&lt;', '>': '&gt;'}[c]));
  if (pushWait.kind === 'selftest') {
    if (pu.selftest && pu.selftest.at >= pushWait.since) {
      showPushResult(pu.selftest.ok ? 'ok' : 'bad', (pu.selftest.ok ? '<b>Listener test PASSED.</b> ' : '<b>Listener test FAILED.</b> ') + esc(pu.selftest.detail));
      pushWait = null;
    } else if (age > 45) { showPushResult('bad', '<b>No answer to the listener test.</b> The alert browser could not be reached. Press <b>Open the set-up window</b> once, then try again.'); pushWait = null; }
    return;
  }
  if (pushWait.kind === 'enable') {
    const eids = Object.keys(pu.trackers || {}).filter(id => pu.trackers[id].can_enable);
    if (eids.length && eids.every(id => (pu.trackers[id].signup_at || 0) >= pushWait.since && (pu.trackers[id].checked_at || 0) >= pushWait.since)) {
      const ok = eids.every(id => pu.trackers[id].signup_ok);
      showPushResult(ok ? 'ok' : 'bad', '<b>' + (ok ? 'Alerts turned on.' : 'Not turned on yet.') + '</b><br>' + eids.map(id => (pu.trackers[id].signup_ok ? '<span class="status-instock">&#10003;</span> ' : '<span class="status-unknown">&#10007;</span> ') + '<b>' + esc(PUSH_NAMES[id] || id) + '</b>: ' + esc(pu.trackers[id].signup_note || '')).join('<br>') +
        (ok ? '<br>Last step: on the site press <b>ALERT ME</b> on the products you want.' : ''));
      pushWait = null;
    } else if (age > 90) { showPushResult('bad', '<b>No answer.</b> The alert browser did not respond. Press <b>Open the set-up window</b> once (it starts the alert browser), then try again.'); pushWait = null; }
    return;
  }
  const ids = Object.keys(pu.trackers || {});
  const done = ids.length > 0 && ids.every(id => (pu.trackers[id].checked_at || 0) >= pushWait.since);
  if (done) {
    const lines = ids.map(id => {
      const s = pu.trackers[id];
      return (pushGood(s) ? '<span class="status-instock">&#10003;</span> ' : '<span class="status-unknown">&#10007;</span> ') + '<b>' + esc(PUSH_NAMES[id] || id) + '</b>: ' +
             (pushGood(s) ? 'ready (' + (s.alerts_seen || 0) + ' alerts received so far)' : esc(pushWhy(s)));
    });
    const allGood = ids.every(id => pushGood(pu.trackers[id]));
    showPushResult(allGood ? 'ok' : 'bad', '<b>' + (allGood ? 'All set.' : 'Not finished yet.') + '</b><br>' + lines.join('<br>') +
      (allGood ? '' : '<br>Press <b>Open the set-up window</b> to fix it, then <b>Check my setup</b> again.'));
    pushWait = null;
  } else if (age > 75) {
    showPushResult('bad', '<b>No answer.</b> The alert browser did not respond within a minute. Press <b>Open the set-up window</b> once (it starts the alert browser), then <b>Check my setup</b> again.');
    pushWait = null;
  }
}
async function saveDiscord(remove) {
  const u = remove ? '' : (document.getElementById('discordUrl').value || '').trim();
  let d = {msg: 'The program did not answer.'};
  try { d = await (await fetch('/api/discord', {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({webhook: u})})).json(); } catch (e) {}
  if (remove) document.getElementById('discordUrl').value = '';
  document.getElementById('discordMsg').innerText = d.msg || '';
}
async function testDiscord() {
  let d = {text: 'The program did not answer.'};
  try { d = await (await fetch('/api/discord-test', {method: 'POST'})).json(); } catch (e) {}
  document.getElementById('discordMsg').innerText = d.text || '';
}
const ENG_LABEL = {camoufox: 'Camoufox', firefox: 'Firefox', chrome: 'Chrome', msedge: 'Edge', chromium: 'built-in Chromium', 'real-chrome': 'your Chrome', 'real-msedge': 'your Edge', stealth: 'Hidden Chrome'};
const STORE_LABEL = {bestbuy: 'Best Buy', gamestop: 'GameStop', target: 'Target', walmart: 'Walmart', amazon: 'Amazon'};
async function testEngine(name) {
  try { engineShow(await (await fetch('/api/engine', {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({test: name})})).json()); } catch (e) {}
}
function engineShow(d) {
  const i = document.getElementById('ffInfo');
  if (!d || !d.engines) return;
  const cf = d.engines.camoufox || {}, tests = d.tests || {};
  const dot = c => '<span style="color:' + c + '">&#9679;</span> ';
  let st;
  if (cf.state === 'ready') st = dot('#1a7f37') + 'Extra browser Camoufox: ready (the program switches between its browsers by itself).';
  else if (cf.state === 'installing') st = dot('#b45309') + 'Extra browser Camoufox: installing (once, a few minutes)...';
  else if (cf.state === 'unavailable') st = dot('#b42318') + 'Extra browser Camoufox: could not be installed' + (cf.detail ? ' (' + cf.detail + ')' : '') + '.';
  else st = dot('#888') + 'Extra browser Camoufox: not installed yet.';
  const t = tests.camoufox;
  st += ' <button class="linkbtn" onclick="testEngine(&quot;camoufox&quot;)">Test it</button>';
  if (t) st += ' <span style="color:' + (t.state === 'ok' ? '#1a7f37' : t.state === 'failed' ? '#b42318' : '#b45309') + '">' +
    (t.state === 'running' ? 'testing... ' : t.state === 'ok' ? 'Test passed. ' : 'Test failed: ' + t.detail) + '</span>';
  const hc = d.engines.stealth || {}, ht = tests.stealth;
  st += '<br>' + dot(hc.state === 'ready' ? '#1a7f37' : hc.state === 'installing' ? '#b45309' : hc.state === 'unavailable' ? '#b42318' : '#888') +
    'Hidden Chrome (your Chrome without the signs of a program): ' + (hc.state === 'ready' ? 'ready - it reads, searches and buys too.' : hc.state === 'installing' ? 'installing (once, about a minute)...' :
    hc.state === 'unavailable' ? 'could not be installed' + (hc.detail ? ' (' + hc.detail + ')' : '') + '.' : 'not installed yet.') +
    ' <button class="linkbtn" onclick="testEngine(&quot;stealth&quot;)">Test it</button>';
  if (ht) st += ' <span style="color:' + (ht.state === 'ok' ? '#1a7f37' : ht.state === 'failed' ? '#b42318' : '#b45309') + '">' +
    (ht.state === 'running' ? 'testing... ' : ht.state === 'ok' ? 'Test passed. ' : 'Test failed: ' + ht.detail) + '</span>';
  if (i && i.dataset.h !== st) { i.innerHTML = st; i.dataset.h = st; }
}
async function saveDiscordIn(remove) {
  const el = document.getElementById('discordInMsg');
  const tok = remove ? '' : (document.getElementById('discordTok').value || '').trim();
  let d = {};
  try { d = await (await fetch('/api/discord-in', {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({token: tok})})).json(); } catch (e) {}
  if (remove || d.ok) document.getElementById('discordTok').value = '';
  el.innerText = d.msg || 'Could not save.';
}
async function checkDiscordIn() {
  const el = document.getElementById('discordInMsg'), iv = document.getElementById('discordInInvite');
  el.innerText = 'Checking...';
  let d = {};
  try { d = await (await fetch('/api/discord-in-check', {method: 'POST'})).json(); } catch (e) {}
  el.innerText = d.text || 'Could not check.';
  iv.innerHTML = d.invite ? 'Invite link: <a href="' + d.invite + '" target="_blank">open it and choose your new server</a>' : '';
}
async function discordInit() {
  try { engineShow(await (await fetch('/api/engine')).json()); } catch (e) {}
  const el = document.getElementById('discordMsg');
  if (!el) return;
  try { const d = await (await fetch('/api/discord')).json(); el.innerText = d.set ? 'Connected (address ending ' + d.tail + ').' : 'Not connected yet.'; } catch (e) {}
}
window.addEventListener('load', discordInit);
async function startWatch() {
  const r = await fetch('/api/start', {method: 'POST'});
  const d = await r.json();
  if (!d.ok) alert(d.error);
  poll();
}
// v90b: Stop / Close show their effect AT ONCE; if the program does not answer within 8 s, the page says how to close it
// from outside (stop_restalker.bat in the Restalker folder)
async function postQuick(url, body, ms) {
  const ctl = new AbortController(), to = setTimeout(() => ctl.abort(), ms || 8000);
  try { const r = await fetch(url, {method: 'POST', headers: body ? {'Content-Type': 'application/json'} : {}, body: body ? JSON.stringify(body) : undefined, signal: ctl.signal}); return await r.json(); }
  catch (e) { return null; } finally { clearTimeout(to); }
}
const NOANSWER = 'Restalker is not answering. Close it from outside: open the Restalker folder and double-click <b>stop_restalker.bat</b> (it closes Restalker and every browser it started; your own Chrome is not touched).';
async function stopWatch() {
  document.getElementById('statusText').innerHTML = '<b>STOPPING</b> - closing every browser of the program...';
  document.getElementById('stopBtn').disabled = true;
  const d = await postQuick('/api/stop', null, 8000);
  programClosed = true;
  document.getElementById('statusDot').className = 'dot off';
  if (!d) { document.getElementById('statusText').innerHTML = NOANSWER; return; }
  // v90b: after Stop the page stays usable for the diagnostics (every browser of the program is closed - the PC is free again)
  document.getElementById('statusText').innerHTML = '<b>STOPPED</b> - every browser of the program is closed. ' +
    '<a href="#" id="diagBtn2" onclick="document.getElementById(\\'diagBtn\\').click(); return false">Download diagnostics</a> &nbsp; ' +
    '<button onclick="quitApp()" style="background:#555;color:#fff;border:none">Close Restalker</button> &nbsp; (to watch again: Close Restalker, then open start_app.bat)';
  document.getElementById('startBtn').disabled = true;
  document.getElementById('stopBtn').disabled = true;
}
async function quitApp() {
  document.getElementById('statusText').innerHTML = '<b>CLOSING</b>...';
  const d = await postQuick('/api/quit', null, 8000);
  document.getElementById('statusText').innerHTML = d ? 'CLOSED - you can close this tab. To watch again, open start_app.bat.' : NOANSWER;
}
setInterval(poll, 1500);
poll();
// v62: closing this page closes the program (and every browser it started), unless the page is back within 20 s (a reload)
window.addEventListener('pagehide', () => { try { navigator.sendBeacon('/api/page-closed', ''); } catch (e) {} });
(function () {                         // v55: the top bar stays on screen; the table below it scrolls by itself with its column titles fixed
  const d = document.querySelector('.dash');
  const fit = () => {
    const pb = document.getElementById('pagebody');      // (the table area comes after this script on the page: looked up each time)
    if (d) document.documentElement.style.setProperty('--rib', d.offsetHeight + 'px');
    if (pb) { document.body.style.overflow = 'hidden'; document.body.style.marginBottom = '0'; pb.style.height = Math.max(200, window.innerHeight - pb.getBoundingClientRect().top - 4) + 'px'; }
  };
  window.addEventListener('resize', fit); document.addEventListener('DOMContentLoaded', fit); window.addEventListener('load', fit);
  fit(); try { new ResizeObserver(fit).observe(d); } catch (e) { setInterval(fit, 1000); }
})();
showAlertInfo();
loadPhone();
</script>
"""

TABS = """<div class="tabs">
<a href="/" class="{products_active}">Products</a>
<a href="/trackers" class="{trackers_active}">Trackers</a>
<a href="/browsers" class="{browsers_active}">Browsers</a>
</div>"""


# v97 (owner 2026-11-04: "a unified user interface that is similar to the products tab, so that the user can easily change between operating
# both tabs"): every tab has the same page - full width, the same top bar, the same table look (TABLE_CSS: the Products tab's own look)
TABLE_CSS = """<style>
  .sw { position: relative; display: inline-block; width: 34px; height: 18px; vertical-align: middle; margin-right: 6px; }
  .sw input { opacity: 0; width: 0; height: 0; margin: 0; }
  .sw span { position: absolute; cursor: pointer; inset: 0; background: #bbb; border-radius: 18px; transition: .15s; }
  .sw span:before { content: ""; position: absolute; height: 14px; width: 14px; left: 2px; top: 2px; background: #fff; border-radius: 50%; transition: .15s; }
  .sw input:checked + span { background: #2a2; }
  .sw input:checked + span:before { transform: translateX(16px); }
  .sw input:disabled + span { cursor: not-allowed; opacity: .55; }
  .rkt table { table-layout: fixed; width: 100%; border-collapse: collapse; margin: 0 0 8px; }
  .rkt th, .rkt td { font-size: 13px; padding: 5px 8px; vertical-align: middle; line-height: 1.3; border: 1px solid #d0d5db; text-align: left; }
  .rkt th { background: #f5f5f5; position: sticky; top: 0; z-index: 3; }
  .rkt tr.grp td { background: #e9eef5; border-top: 2px solid #9aa7b6; padding: 5px 8px; }
  .rkt tr.grp .gname { font-weight: bold; font-size: 14px; margin-right: 10px; }
  .rkt tr.grp button { font-size: 12px; padding: 2px 9px; margin: 2px 4px 2px 0; }
  .rkt .nm { font-weight: 600; }
  .rkt .note { color: #6e7781; font-size: 12px; }
  .rkt tr.off td { color: #8c959f; } .rkt tr.off .nm { color: #8c959f; }
  .rkt .ok { color: #1a7f37; font-weight: 600; } .rkt .bad { color: #b42318; font-weight: 600; } .rkt .warn { color: #b45309; }
  .rkt .lead { font-size: 13px; color: #444; margin: 2px 0 8px; }
  .rkt .folds { margin: 4px 0 10px; } .rkt .folds button.drop { margin-right: 6px; font-size: 13px; }
</style>"""


def page_shell(active, body):
    """One page of the program: title, top bar, tabs, notices, then the tab's own part (v97: the same frame for every tab)."""
    return (f"""<!doctype html><html><head><title>Restalker {KIT_VERSION}</title>{STYLE}{TABLE_CSS}<style>body {{ max-width: none; padding: 0 12px; }}</style></head><body>
<h1 class="top">Restalker <span style="font-size:0.6em;background:#1f6feb;color:#fff;border-radius:6px;padding:2px 9px;vertical-align:middle">{KIT_VERSION}</span> <button class="pill" id="updBtn" onclick="updClick()" style="font-size:13px;font-weight:normal;vertical-align:middle;margin-left:6px" title="Restalker looks for a new version by itself once an hour; press to look now. Installing replaces only program files - your products, settings, sign-ins and purchases are never touched.">Check for updates</button> <label id="updAutoL" style="font-size:12px;font-weight:normal;vertical-align:middle;margin-left:4px" title="On: a new version installs by itself (checked every hour), after any purchase in progress is finished. Off: you press Install."><span class="sw"><input type="checkbox" id="updAuto" onchange="updAutoSet(this.checked)"><span></span></span>auto-update</label></h1>
{DASHBOARD}
<div id="pagebody">
{TABS.format(products_active='active' if active == 'products' else '', trackers_active='active' if active == 'trackers' else '',
             browsers_active='active' if active == 'browsers' else '')}
{banner_html()}
{body}
</div>
</body></html>""")


def banner_html():
    warn = ""
    bad = old_files()
    if bad:
        warn = ('<div class="banner err"><b>Some program files are OLD</b> (' + ", ".join(bad) +
                '). Copy ALL the files from the newest kit into this folder, then close and restart. '
                'Watching is blocked until this is fixed.</div>')
    dv = disk_version()
    if dv and dv != KIT_VERSION:
        warn += ('<div class="banner err"><b>This window is running ' + KIT_VERSION + ', but the files in your folder are ' + dv +
                 '.</b> The newer files are NOT in use yet. Click Stop, close the black window, then open start_app.bat again '
                 'and check this heading says ' + dv + '.</div>')
    try:
        ep = amazon_buy.engine_problem()          # v57: the buyer_engine folder must match this version (diagnostics 56: it did not)
    except Exception:
        ep = None
    if ep:
        warn += '<div class="banner err"><b>Buying engine out of date.</b> ' + ep + '</div>'
    msg = request.args.get("msg")
    if not msg:
        return warn
    kind = "ok" if request.args.get("ok") == "1" else "err"
    return warn + f'<div class="banner {kind}">{msg}</div>'


@app.after_request
def _no_cache(resp):
    """Pages are never kept by the browser, so a restart always shows the newest page."""
    if resp.mimetype == "text/html":
        resp.headers["Cache-Control"] = "no-store"
    return resp


@app.route("/")
def index():
    return page_shell("products", matrix_ui.HTML)


def push_panel(cfg):
    """Buttons + the folded-away instructions for the 'alert' trackers (TrackaLacker, HotStock, Discord). Empty when none are listed."""
    pts = [t for t in cfg["trackers"] if t.get("kind") == "push"]
    if not pts:
        return ""
    links = ""
    for t in pts:
        links += f"<li><b>{t['name']}</b>: " + " &middot; ".join(
            f"<a href='{u}' target='_blank'>{u.split('//')[1][:60]}</a>" for u in (t.get("setup_urls") or [])) + "</li>"
    return f"""<div>
<div id="pushResult" class="presult" style="display:none"></div>
<div class="folds">
<button class="drop" onclick="toggleBox('howto', this)">How to set up the alert trackers &#9662;</button>
<button class="drop" onclick="toggleBox('recentBox', this)">Latest alerts &#9662;</button>
<span class="note" style="color:#6e7781;font-size:12px">TrackaLacker, HotStock and Discord send browser notifications; the program's own "alert browser" receives them (your normal Chrome is not touched).</span>
</div>
<div id="howto" class="dropbox">
<ol style="font-size:14px;line-height:1.6;margin-top:0">
<li>Click <b>Open the set-up window</b>. An ordinary Chrome window opens with the tracker pages. If a &quot;verify you are human&quot; box appears, tick it yourself.</li>
<li><b>TrackaLacker</b> tab: make a free account. Open your <b>notification settings</b>, find <b>Browser Push Notifications (Beta)</b>, click <b>Enable on this device</b>, click <b>Allow</b>, then press <b>Test Push</b>. Then on each product page you care about, press <b>Subscribe to Alerts</b>.</li>
<li><b>HotStock</b> tab: make a free account and sign in. Then sign up for the <b>Browser</b> alert channel (the &quot;Sign up&quot; next to <i>Browser</i>) and click <b>Allow</b>; without this step HotStock has no way to reach this window even though you are logged in. Then find the Magic Collector Booster products and press the red <b>ALERT ME</b> button on each. Leave that tab open. <b>Check my setup</b> will say &quot;signed up&quot; once it worked.</li>
<li>Click <b>Test the listener</b> (it should say PASSED), then <b>Check my setup</b>. Each tracker should show green ticks. Then click <b>Hide the alert browser</b>.</li>
<li>Click <b>Start watching</b> as usual. Leave the alert browser running (it hides itself).</li>
</ol>
<div class="hint">Free accounts are used, so these alerts arrive <b>after</b> the paid members' alerts. The results are labelled "free tier" for that reason.</div>
<div class="hint" style="background:#f1f8ff;border:1px solid #b6d4fe;border-radius:6px;padding:6px 10px"><b>Price limits - set the trackers HIGH.</b>
The trackers' own price limits cannot be set from this program (they are private settings inside each tracker's account), so do it the other way round:
in each tracker choose to be alerted at <b>any price</b> (or the highest limit it offers). This program then applies <b>your price caps from the table</b>
to every alert it receives: an alert above the cap is not counted or sent to your phone, and it is listed in the diagnostics as "above the limit".
Nothing is lost by setting the trackers high, and your caps live in one place (the table).</div>
<ul style="font-size:13px;color:#555">{links}</ul>
</div>
<div id="discordBox" class="dropbox">
<b>Discord</b> works best in a server of its own for this project (not your existing one):
<ol style="font-size:14px;line-height:1.6;margin:6px 0">
<li><b>Make the new server</b> (one time, 1 minute). In Discord press the <b>+</b> at the bottom of the server list &rarr; <b>Create My Own</b> &rarr; <b>For me and my friends</b> &rarr; name it (for example <i>Restock Alerts</i>) &rarr; <b>Create</b>. It is invite-only by default, so nobody can find it. Later, other people join through an invite link (server name &rarr; <b>Invite People</b>); they just read the channel.</li>
<li><b>Let this program post to it</b> (v99: the restocks it finds and confirms on the store page - store, price, product, link - once per restock; your purchases and problems only if you tick the box below).
 In the new server: the channel (for example <b>#general</b>) &rarr; <b>Edit Channel</b> (gear) &rarr; <b>Integrations</b> &rarr; <b>Webhooks</b> &rarr; <b>New Webhook</b> &rarr; <b>Copy Webhook URL</b>. Paste it here:
 <input id="discordUrl" placeholder="https://discord.com/api/webhooks/..." style="margin:4px 0">
 <button onclick="saveDiscord()">Save</button> <button onclick="testDiscord()">Send a test to Discord</button> <button onclick="saveDiscord(true)">Remove</button>
 <span id="discordMsg" style="font-size:13px"></span>
 <div style="margin:4px 0;font-size:13px"><label><input type="checkbox" id="dsShare" style="width:auto;margin:0 4px 0 0" onchange="dsSet()">share the restocks this program finds and confirms
 (each once; the other copies of Restalker that read this channel count them as a tracker)</label><br>
 <label><input type="checkbox" id="dsPersonal" style="width:auto;margin:0 4px 0 0" onchange="dsSet()">also post my purchases and problems there (only for a channel nobody else reads)</label>
 <span id="dsInfo" class="sub"></span></div></li>
<li><b>Let this program READ the server (other trackers' alerts - and other copies of Restalker - become another source).</b> Other trackers, and other people's copies of Restalker, post into the server; this program reads them and counts every message that names one of your products at a store you watch, under your price limit (its own posts are left out). One-time set-up, about 3 minutes, free:
 <ol type="a" style="margin:4px 0">
 <li>Open <b>discord.com/developers/applications</b> &rarr; <b>New Application</b> &rarr; name it <i>Restalker</i> &rarr; <b>Create</b>.</li>
 <li>Left menu <b>Bot</b> &rarr; scroll to <b>Privileged Gateway Intents</b> &rarr; turn <b>ON</b> <b>Message Content Intent</b> &rarr; <b>Save Changes</b>. (Without this every message arrives empty.)</li>
 <li>On the same page press <b>Reset Token</b> &rarr; <b>Copy</b>. Paste it here (it is a password: it stays on this PC):
  <input id="discordTok" type="password" placeholder="bot token" style="margin:4px 0">
  <button onclick="saveDiscordIn()">Save</button> <button onclick="checkDiscordIn()">Check</button> <button onclick="saveDiscordIn(true)">Remove</button>
  <span id="discordInMsg" style="font-size:13px"></span>
  <div id="discordInInvite" style="font-size:13px"></div></li>
 <li>Press <b>Check</b>. It shows a blue <b>invite link</b>: open it, choose your new server, <b>Authorize</b> (it only asks to see channels and read messages; it cannot post or change anything). Press <b>Check</b> again: it lists the channels it can read.</li>
 </ol>
 Messages this program posted itself (its own alert channel) are ignored here, so it does not matter if that channel is in the same server.</li>
<li><b>Get the trackers' alerts into your new server.</b> A tracker that has an <i>Announcement</i> channel in its own Discord: press <b>Follow</b> on that channel and choose a channel of your new server; Discord then copies every alert there by itself. A tracker that posts through a bot or webhook: invite it to, or point it at, a channel of your new server. Every channel the bot can see is read (up to 10).</li>
<li><b>Older, experimental way (not needed any more):</b> If a tracker's Discord has an <i>Announcement</i> channel, press <b>Follow</b> on it and choose a channel of your new server: Discord then copies every alert there, so all alerts are in one place. To have the program count them, scroll to <b>Manage trackers</b>, find <b>Discord (your servers)</b> and press <b>Resume</b>, sign in to discord.com in the set-up window, and set your new server's alert channel to notify you for <b>all messages</b>. It only counts a message whose notification shows the product, store and price in words.</li>
</ol>
</div>
<script>
async function dsLoad(d) {{
  try {{ d = d || await (await fetch('/api/discord-share')).json(); }} catch (e) {{ return; }}
  const a = document.getElementById('dsShare'), b = document.getElementById('dsPersonal'), i = document.getElementById('dsInfo');
  if (a) a.checked = !!d.share; if (b) b.checked = !!d.personal;
  if (i) i.innerText = ' This copy posts as "' + d.name + '"' + (d.shared ? '; restocks shared so far: ' + d.shared : '') + '.';
}}
async function dsSet() {{
  const body = {{share: document.getElementById('dsShare').checked, personal: document.getElementById('dsPersonal').checked}};
  try {{ dsLoad(await (await fetch('/api/discord-share', {{method: 'POST', headers: {{'Content-Type': 'application/json'}}, body: JSON.stringify(body)}})).json()); }} catch (e) {{}}
}}
dsLoad();
</script>
<div id="recentBox" class="dropbox"><b>Latest alerts that arrived</b> (everything, including ones that are not counted)
<pre id="pushRecent" style="font-size:12px;white-space:pre-wrap">No alerts have arrived yet.</pre></div>
</div>"""


@app.route("/trackers")
def trackers_page():
    """v97: the Trackers tab in the Products tab's look - one table, grouped by how each tracker reaches the program, a switch per tracker
    (the same switch as a store's), the alert browser's buttons in its own group's header, the long instructions folded away."""
    ensure_push_trackers()
    cfg = load(TRACKERS_PATH, "trackers", extra_keys=["excluded"])
    HOW = {"push": "browser alerts (one-time set-up)", "status_table": "public status page", "status_page": "public page, read directly",
           "event_page": "public feed, read directly", "discord_in": "your own Discord server (one-time bot set-up)"}
    groups = [("direct", "Read straight from their public pages", "nothing to set up", lambda t: t.get("kind") not in ("push", "discord_in")),
              ("push", "Alerts through the alert browser", "one-time set-up", lambda t: t.get("kind") == "push"),
              ("discord", "Your own Discord server", "one-time bot set-up", lambda t: t.get("kind") == "discord_in")]
    running = bool(STATE.get("running"))
    rows_html = ""
    for gid, gname, gnote, fits in groups:
        ts = [t for t in cfg["trackers"] if fits(t)]
        if not ts:
            continue
        n_on = sum(1 for t in ts if t.get("active", True))
        extra = ""
        if gid == "push":
            extra = ("<span style='margin-left:6px'>Alert browser: <b id='pushBrowser'>not open</b></span> &nbsp; "
                     "<button onclick=\"pushAct('setup')\" style='background:#1f6feb;color:#fff;border:none'>Open the set-up window</button>"
                     "<button onclick=\"pushAct('probe')\">Check my setup</button>"
                     "<button onclick=\"pushAct('selftest')\">Test the listener</button>"
                     "<button onclick=\"pushAct('enable')\" title='The alert browser opens HotStock&#39;s settings page and presses its own Enable browser alerts button.'>Turn on HotStock alerts for me</button>"
                     "<button onclick=\"pushAct('hide')\">Hide the alert browser</button>")
        if gid == "discord":
            extra = "<button class='drop' onclick=\"toggleBox('discordBox', this)\">Set up Discord &#9662;</button>"
        rows_html += (f"<tr class='grp'><td colspan='4'><span class='gname'>{gname}</span><span class='note'>{gnote} &middot; {n_on} of {len(ts)} on</span> "
                      f"{extra}</td></tr>")
        for t in ts:
            on = t.get("active", True)
            is_push = t.get("kind") == "push"
            note = t.get("claimed_note") or ""
            if on:
                live = (f"<td class='status-cell' id='pushstatus-{t['id']}'>alert browser not running yet</td>" if is_push
                        else f"<td class='status-cell' id='trstatus-{t['id']}'>{'not checked yet' if running else 'starts with Start watching'}</td>")
            else:
                live = "<td class='status-cell'>off</td>"
            rows_html += (f"<tr class='{'' if on else 'off'}'><td style='text-align:center'><label class='sw' title='{'On - press to switch it off' if on else 'Off - press to switch it on'}'>"
                          f"<input type='checkbox' {'checked' if on else ''} onchange=\"trkSet('{t['id']}', this.checked)\"><span></span></label></td>"
                          f"<td><span class='nm'>{t['name']}</span><br><span class='note'>{note}</span></td>"
                          f"<td>{HOW.get(t.get('kind'), 'public feed page')}</td>{live}</tr>")
    excluded_rows = ""
    for t in cfg["excluded"]:
        excluded_rows += (
            f"<tr class='excluded'><td>{t['id']}</td><td>{t['name']}</td>"
            f"<td>{t.get('reason', '')}</td>"
            f"<td><form method='post' action='/reinclude/{t['id']}' style='display:flex;gap:6px'>"
            f"<input name='feed_url' placeholder='paste its public feed URL' style='margin:0' required>"
            f"<button type='submit' style='white-space:nowrap'>Test &amp; move to active</button></form></td></tr>")
    on_n = sum(1 for t in cfg["trackers"] if t.get("active", True))
    folds = push_panel(cfg)
    body = f"""<div class="rkt">
<div class="lead"><b>{on_n} of {len(cfg['trackers'])} trackers on.</b> Trackers only help the program look sooner - it buys from its own reading of the store.
{'<span class="warn">A switch you change now takes effect the next time you press Start watching.</span>' if running else ''}</div>
<table><colgroup><col style="width:60px"><col style="width:42%"><col style="width:22%"><col></colgroup>
<tr><th>On</th><th>Tracker</th><th>How it reaches the program</th><th>Live status</th></tr>
{rows_html or '<tr><td colspan=4>No trackers.</td></tr>'}</table>
{folds}
<div class="folds"><button class="drop" onclick="toggleBox('manageBox', this)">Add a tracker &#9662;</button></div>
<div id="manageBox" class="dropbox">
<h3 style="margin-top:4px">Add a tracker</h3>
<div class="hint">Only a tracker with a public feed page (recent restocks, no log-in) can be added. The address is tested before it is saved.
If there is none, use "Mark as excluded" below instead. A new tracker starts with the next Start watching.</div>
<form method="post" action="/add-tracker">
  <div class="grid">
    <div><label>ID (short, unique, no spaces)</label><input name="id" required></div>
    <div><label>Display name</label><input name="name" required></div>
  </div>
  <label>Public feed URL</label>
  <input name="feed_url" required>
  <div class="grid">
    <div><label>Claimed latency in seconds (optional)</label><input name="claimed_latency_sec" type="number" step="0.1"></div>
    <div><label>Poll interval (seconds)</label><input name="interval_sec" value="2" type="number" step="0.5"></div>
  </div>
  <label>Claimed note (optional)</label>
  <input name="claimed_note">
  <button type="submit">Test &amp; add tracker</button>
</form>
<h3>Excluded trackers ({len(cfg['excluded'])})</h3>
<div class="hint">Trackers with no public feed on file. If you find one later, paste it and test - it only moves to the list if it loads.</div>
<table><tr><th>ID</th><th>Name</th><th>Reason</th><th></th></tr>
{excluded_rows or '<tr><td colspan=4>None yet.</td></tr>'}</table>
<form method="post" action="/exclude">
  <div class="grid">
    <div><label>ID</label><input name="id" required></div>
    <div><label>Name</label><input name="name" required></div>
  </div>
  <label>Reason</label>
  <input name="reason" required>
  <button type="submit">Mark as excluded</button>
</form>
</div>
</div>
<script>
async function trkSet(id, on) {{
  try {{ await fetch('/' + (on ? 'resume' : 'pause') + '-tracker/' + encodeURIComponent(id), {{method: 'POST'}}); }} catch (e) {{}}
  location.reload();
}}
</script>"""
    return page_shell("trackers", body)


def _browsers_report_rows():
    """v97: every browser the program runs - what it does, what it is doing now, what it costs the PC, and (for the other buying browsers)
    a switch. Measured costs come from cpu_monitor (only browsers that carry the program's mark can be measured one by one)."""
    import multibuy
    try:
        parts = cpu_monitor.parts_now() or {}
    except Exception:
        parts = {}
    cores = max(1, int((getattr(cpu_monitor, "_STATE", {}) or {}).get("cores") or (os.cpu_count() or 1)))

    def cost(*names):
        cpu = sum(float((parts.get("cpu") or {}).get(n) or 0.0) for n in names)
        mb = sum(float((parts.get("mb") or {}).get(n) or 0.0) for n in names)
        if not parts or not any(n in (parts.get("mb") or {}) for n in names):
            return None
        return {"cpu_pc": round(cpu / cores, 1), "mb": int(mb)}
    pur = amazon_buy.purchases_list(1000)

    def bought_by(name):
        return sum(1 for x in pur if name.lower() in str(x.get("by") or "").lower())
    st = multibuy.status()
    installed = set(multibuy._enabled_kinds()) if hasattr(multibuy, "_enabled_kinds") else set(multibuy.enabled_kinds())
    off = multibuy.off_kinds() if hasattr(multibuy, "off_kinds") else set()
    try:
        b = amazon_buy.snapshot(brief=True)
    except Exception:
        b = {}
    rows = [{"kind": "buyer", "name": "Buying browser", "fixed": True, "on": bool(b.get("on")),
             "does": "Restalker's own: buys at every store and checks the products set to Buy at Amazon. It is the one every purchase starts from.",
             "now": ("off - Buying is switched off" if not b.get("on") else ("checking out" if b.get("checkout") else ("ready" if b.get("connected") else str(b.get("browser") or "starting")))),
             "cost": cost("buyer"), "bought": None},
            {"kind": "reader", "name": "Store reader", "fixed": True, "on": True,
             "does": "Reads the store pages for the restock checks (never buys). The checks need it.",
             "now": "reading" if STATE.get("running") else "starts with Start watching", "cost": cost("reader"), "bought": None}]
    for k in multibuy.KINDS:
        w = st.get(k) or {}
        if k not in installed and k not in st:
            now = "not installed on this PC"
        elif k in off:
            now = "off"
        else:
            now = w.get("state") or ("starts with Start watching" if not STATE.get("running") else "starting")
            if w.get("busy"):
                now = "checking out now"
        rows.append({"kind": k, "name": multibuy.NAMES.get(k, k), "fixed": k not in installed and k not in off, "on": k not in off,
                     "does": "Checks out at the same moment as the buying browser (its own sign-ins), and reads Amazon, Best Buy and GameStop between checkouts.",
                     "now": now, "cost": cost("buy-" + k), "bought": bought_by(multibuy.NAMES.get(k, k)),
                     "signed": {multibuy.STORE_NAMES.get(s_, s_): v for s_, v in (w.get("signed") or {}).items()}})
    try:
        pu = push_listener.manager().snapshot()
    except Exception:
        pu = {}
    rows.append({"kind": "alerts", "name": "Alert browser", "fixed": True, "on": bool(pu.get("connected")),
                 "does": "Receives the TrackaLacker / HotStock / Discord browser alerts. Switched by those trackers on the Trackers tab.",
                 "now": "running" if pu.get("connected") else "not open", "cost": cost("alerts", "alerts-setup"), "bought": None})
    try:
        lp = loadplan.snapshot()
        total = {"cpu_pct_pc": lp.get("cpu_pct_pc"), "gb": lp.get("gb"), "profile": loadplan.PROFILES[lp["profile"]][0]}
    except Exception:
        total = {}
    return {"rows": rows, "total": total, "measured": bool(parts)}


@app.route("/api/browsers", methods=["GET", "POST"])
def api_browsers():
    if request.method == "POST":
        org = request.headers.get("Origin") or request.headers.get("Referer") or ""
        if org and not re.match(r"^https?://(127\.0\.0\.1|localhost)(:\d+)?(/|$)", org):
            return jsonify({"ok": False, "reason": "only this program's own page may change this"}), 403
        import multibuy
        b = request.get_json(silent=True) or {}
        if str(b.get("kind") or "") == "_boot":          # v117: close Restalker's browsers Windows reopens after a restart
            got = lifeline.boot_cleanup_set(os.path.dirname(os.path.abspath(__file__)), bool(b.get("on")))
            r = {"ok": True, "text": ("On: after a Windows restart, Restalker's own browsers are closed until you start Restalker."
                                      if b.get("on") else "Off: Windows may reopen Restalker's browsers after a restart.")
                 + ("" if got is not None or os.name != "nt" else " (Windows' list could not be changed)")}
        else:
            r = multibuy.set_on(str(b.get("kind") or ""), bool(b.get("on")))
        out = _browsers_report()
        out["result"] = r
        return jsonify(out)
    return jsonify(_browsers_report())


def _browsers_report():
    out = _browsers_report_rows()
    out["boot_cleanup"] = lifeline.boot_cleanup_on(os.path.dirname(os.path.abspath(__file__)))
    return out


@app.route("/browsers")
def browsers_page():
    body = """<div class="rkt">
<div class="lead" id="brTotal">...</div>
<table><colgroup><col style="width:60px"><col style="width:40%"><col style="width:24%"><col style="width:16%"><col></colgroup>
<tr><th>On</th><th>Browser</th><th>Now</th><th>Processor &middot; memory</th><th>Purchases</th></tr>
<tbody id="brRows"><tr><td colspan="5">loading...</td></tr></tbody></table>
<div class="hint">Switching a browser off saves its share of the processor and memory; it then neither reads nor buys (a checkout it is doing is finished first).
Fewer browsers = fewer looks at Amazon, Best Buy and GameStop, and fewer checkouts at the same moment. The buying browser and the store reader cannot be switched off -
to stop buying, use Buying ON/OFF at the top. <span id="brMsg" class="ok"></span></div>
<div class="hint" style="margin-top:8px"><label class="sw" style="vertical-align:middle"><input type="checkbox" id="brBoot" onchange="brSet('_boot', this.checked)"><span></span></label>
<b>After a Windows restart, close Restalker's browsers until Restalker is started</b> - Windows reopens open browsers by itself after a restart
(Restalker's too, but not Restalker). A small helper started at sign-in closes Restalker's OWN browsers for 6 minutes while Restalker is not
running - never your own browsers.</div>
</div>
<script>
function brCost(c) { return c ? c.cpu_pc + '% &middot; ' + (c.mb >= 1024 ? (c.mb / 1024).toFixed(1) + ' GB' : c.mb + ' MB') : '<span class="note">not measured</span>'; }
function brDraw(d) {
  const t = d.total || {};
  const bb = document.getElementById('brBoot'); if (bb && document.activeElement !== bb) bb.checked = d.boot_cleanup !== false;
  document.getElementById('brTotal').innerHTML = (t.cpu_pct_pc != null ? '<b>The program now uses ' + t.cpu_pct_pc + '% of the processor' + (t.gb != null ? ' and ' + t.gb + ' GB of memory' : '') + '.</b>'
    : '<b>Every browser the program runs.</b>') + (t.profile ? ' Speed setting: ' + esc(t.profile) + ' (top bar).' : '') +
    (d.measured ? '' : ' <span class="note">What each browser costs is shown after the first minute of watching.</span>');
  const row = r => {
    const sg = r.signed && Object.keys(r.signed).length ? '<br><span class="note">signed in: ' + Object.entries(r.signed).map(([k, v]) => esc(k) + (v === true ? ' &#10003;' : v === false ? ' &#10007;' : ' ?')).join(', ') + '</span>' : '';
    return '<tr class="' + (r.on ? '' : 'off') + '"><td style="text-align:center"><label class="sw" title="' + (r.fixed ? 'cannot be switched here' : (r.on ? 'On - press to switch it off' : 'Off - press to switch it on')) +
      '"><input type="checkbox"' + (r.on ? ' checked' : '') + (r.fixed ? ' disabled' : ' onchange="brSet(\\'' + r.kind + '\\', this.checked)"') + '><span></span></label></td><td><span class="nm">' +
      esc(r.name) + '</span>' + (r.fixed ? '<br><span class="note">' + esc(r.does) + '</span>' : '') + '</td><td>' + esc(r.now) + sg + '</td><td>' + brCost(r.cost) + '</td><td>' + (r.bought == null ? '' : r.bought) + '</td></tr>';
  };
  const rs = d.rows || [], fixed = rs.filter(r => ['buyer', 'reader', 'alerts'].includes(r.kind)), other = rs.filter(r => !['buyer', 'reader', 'alerts'].includes(r.kind));
  document.getElementById('brRows').innerHTML =
    '<tr class="grp"><td colspan="5"><span class="gname">Always on</span><span class="note">needed for watching and buying</span></td></tr>' + fixed.map(row).join('') +
    '<tr class="grp"><td colspan="5"><span class="gname">Other buying browsers</span><span class="note">each checks out at the same moment as the buying browser, with its own sign-ins, ' +
    'and reads Amazon, Best Buy and GameStop between checkouts &middot; ' + other.filter(r => r.on && r.now !== 'not installed on this PC').length + ' of ' + other.length + ' on</span></td></tr>' + other.map(row).join('');
}
async function brLoad() { try { brDraw(await (await fetch('/api/browsers')).json()); } catch (e) {} }
async function brSet(kind, on) {
  if (kind !== '_boot' && !on && !confirm('Switch this browser off? It then neither reads nor buys until you switch it on again.')) { brLoad(); return; }
  let d = null;
  try { d = await (await fetch('/api/browsers', {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({kind: kind, on: on})})).json(); } catch (e) {}
  if (d) { brDraw(d); const m = document.getElementById('brMsg'); m.innerText = (d.result && (d.result.text || d.result.reason)) || ''; m.className = d.result && d.result.ok ? 'ok' : 'bad'; }
}
brLoad(); setInterval(brLoad, 5000);
</script>"""
    return page_shell("browsers", body)


def try_burst_with_fallback(url, gap, attempts=6):
    """Test whether a URL survives sustained polling. Tries plain HTTP
    first (fast, no dependencies); if that fails, automatically retries
    with a real headless browser (see browser_fetch.py), since some
    sites that block scripted requests tolerate real browser traffic at
    the same frequency. Returns (ok, mode, text, detail) where mode is
    'http' or 'browser', and detail explains a failure or notes when
    browser-mode fallback itself needs one-time setup."""
    successes, attempts_made, text, err = burst_test(url, attempts=attempts, gap=gap)
    if successes == attempts_made:
        return True, "http", text, None

    browser = BrowserFetcher()
    try:
        b_successes, b_attempts, b_text, b_err = burst_test(
            url, attempts=attempts, gap=gap,
            fetch_fn=lambda u: browser.fetch(u, timeout=20.0))
    finally:
        browser.close()

    if b_successes == b_attempts:
        return True, "browser", b_text, None

    if b_err and PLAYWRIGHT_NOT_INSTALLED in b_err:
        detail = (f"plain requests failed ({successes}/{attempts_made} succeeded, last error: {err}). "
                  f"A real browser might get past this, but that needs a one-time setup first: "
                  f"pip install playwright --break-system-packages, then playwright install chromium. "
                  f"Run that and try adding this again.")
    else:
        detail = (f"failed under both plain requests ({successes}/{attempts_made}) and browser-mode "
                  f"({b_successes}/{b_attempts}, last error: {b_err}). This site is blocking sustained "
                  f"polling too aggressively for this tool to get accurate timing from it.")
    return False, None, None, detail


@app.route("/add-target", methods=["POST"])
def add_target():
    cfg = load(TARGETS_PATH, "targets")
    tid = request.form["id"].strip()
    url = request.form["url"].strip()
    interval = float(request.form.get("interval_sec") or 2)
    if any(t["id"] == tid for t in cfg["targets"]):
        return redirect(url_for("index", msg=f"ID '{tid}' already exists — pick a different one.", ok=0))

    # A single request succeeding proves nothing about whether this site
    # tolerates the sustained, rapid polling this study actually needs for
    # accurate sub-second timing — so test that directly, at roughly the
    # real polling cadence, before trusting it with hours of unattended
    # runtime. Falls back to a real headless browser automatically if
    # plain requests get blocked (see browser_fetch.py).
    gap = max(0.5, min(interval, 2.0))
    ok, mode, text, detail = try_burst_with_fallback(url, gap)
    if not ok:
        return redirect(url_for("index", msg=f"NOT added — '{tid}' {detail}", ok=0))
    status = detect_availability(text, hint=url)
    if status == "UNKNOWN":
        return redirect(url_for("index", msg=f"NOT added — '{tid}' loaded fine but doesn't publish "
                                              f"standard stock-status data. Try a different product/retailer.", ok=0))
    cfg["targets"].append({
        "id": tid, "url": url,
        "match_name": request.form["match_name"].strip(),
        "interval_sec": interval,
        "active": True,
        "fetch_mode": mode,
    })
    save(TARGETS_PATH, cfg)
    note = " (needed browser mode — plain requests were blocked)" if mode == "browser" else ""
    return redirect(url_for("index", msg=f"Added '{tid}' — currently detected as {status}, survived "
                                          f"sustained polling{note}.", ok=1))


@app.route("/delete-target/<target_id>", methods=["POST"])
def delete_target(target_id):
    cfg = load(TARGETS_PATH, "targets")
    cfg["targets"] = [t for t in cfg["targets"] if t["id"] != target_id]
    save(TARGETS_PATH, cfg)
    return redirect(url_for("index"))


@app.route("/pause-target/<target_id>", methods=["POST"])
def pause_target(target_id):
    cfg = load(TARGETS_PATH, "targets")
    for t in cfg["targets"]:
        if t["id"] == target_id:
            t["active"] = False
    save(TARGETS_PATH, cfg)
    return redirect(url_for("index"))


@app.route("/resume-target/<target_id>", methods=["POST"])
def resume_target(target_id):
    cfg = load(TARGETS_PATH, "targets")
    for t in cfg["targets"]:
        if t["id"] == target_id:
            t["active"] = True
    save(TARGETS_PATH, cfg)
    return redirect(url_for("index"))


@app.route("/add-tracker", methods=["POST"])
def add_tracker():
    cfg = load(TRACKERS_PATH, "trackers", extra_keys=["excluded"])
    tid = request.form["id"].strip()
    feed_url = request.form["feed_url"].strip()
    interval = float(request.form.get("interval_sec") or 2)
    if any(t["id"] == tid for t in cfg["trackers"]):
        return redirect(url_for("trackers_page", msg=f"ID '{tid}' already exists — pick a different one.", ok=0))

    # Same reasoning as products: our own detection speed is half of what
    # gets measured, so this feed page needs to tolerate rapid polling too,
    # not just load once. Falls back to browser mode automatically too.
    gap = max(0.5, min(interval, 2.0))
    ok, mode, text, detail = try_burst_with_fallback(feed_url, gap)
    if not ok:
        return redirect(url_for("trackers_page", msg=f"NOT added — '{tid}' {detail}", ok=0))
    latency = request.form.get("claimed_latency_sec")
    cfg["trackers"].append({
        "id": tid, "name": request.form["name"].strip(), "feed_url": feed_url,
        "claimed_latency_sec": float(latency) if latency else None,
        "claimed_note": request.form.get("claimed_note", "").strip() or None,
        "interval_sec": interval,
        "active": True,
        "fetch_mode": mode,
    })
    save(TRACKERS_PATH, cfg)
    note = " (needed browser mode — plain requests were blocked)" if mode == "browser" else ""
    return redirect(url_for("trackers_page", msg=f"Added '{tid}' — survived sustained polling{note}.", ok=1))


@app.route("/delete-tracker/<tracker_id>", methods=["POST"])
def delete_tracker(tracker_id):
    cfg = load(TRACKERS_PATH, "trackers", extra_keys=["excluded"])
    cfg["trackers"] = [t for t in cfg["trackers"] if t["id"] != tracker_id]
    save(TRACKERS_PATH, cfg)
    return redirect(url_for("trackers_page"))


@app.route("/pause-tracker/<tracker_id>", methods=["POST"])
def pause_tracker(tracker_id):
    cfg = load(TRACKERS_PATH, "trackers", extra_keys=["excluded"])
    for t in cfg["trackers"]:
        if t["id"] == tracker_id:
            t["active"] = False
    save(TRACKERS_PATH, cfg)
    return redirect(url_for("trackers_page"))


@app.route("/resume-tracker/<tracker_id>", methods=["POST"])
def resume_tracker(tracker_id):
    cfg = load(TRACKERS_PATH, "trackers", extra_keys=["excluded"])
    for t in cfg["trackers"]:
        if t["id"] == tracker_id:
            t["active"] = True
    save(TRACKERS_PATH, cfg)
    return redirect(url_for("trackers_page"))


@app.route("/exclude", methods=["POST"])
def exclude():
    cfg = load(TRACKERS_PATH, "trackers", extra_keys=["excluded"])
    cfg["excluded"].append({"id": request.form["id"].strip(), "name": request.form["name"].strip(),
                             "reason": request.form["reason"].strip()})
    save(TRACKERS_PATH, cfg)
    return redirect(url_for("trackers_page"))


@app.route("/reinclude/<tracker_id>", methods=["POST"])
def reinclude(tracker_id):
    """Move an excluded tracker back to active — but only after testing the
    feed URL you provide under sustained polling, same as adding a brand
    new one. Fixes the old 'move to active' button, which had no URL to
    restore since excluded entries never had one in the first place."""
    cfg = load(TRACKERS_PATH, "trackers", extra_keys=["excluded"])
    entry = next((t for t in cfg["excluded"] if t["id"] == tracker_id), None)
    if not entry:
        return redirect(url_for("trackers_page", msg=f"'{tracker_id}' not found in excluded list.", ok=0))
    feed_url = request.form["feed_url"].strip()
    ok, mode, text, detail = try_burst_with_fallback(feed_url, gap=2.0)
    if not ok:
        return redirect(url_for("trackers_page",
                                 msg=f"NOT moved — {detail} '{tracker_id}' stays excluded.", ok=0))
    cfg["excluded"] = [t for t in cfg["excluded"] if t["id"] != tracker_id]
    cfg["trackers"].append({
        "id": entry["id"], "name": entry["name"], "feed_url": feed_url,
        "claimed_latency_sec": None, "claimed_note": None, "interval_sec": 2, "active": True,
        "fetch_mode": mode,
    })
    save(TRACKERS_PATH, cfg)
    note = " (needed browser mode)" if mode == "browser" else ""
    return redirect(url_for("trackers_page", msg=f"Moved '{tracker_id}' to active — survived sustained polling{note}.", ok=1))


@app.route("/unexclude/<tracker_id>", methods=["POST"])
def unexclude(tracker_id):
    # kept for backward compatibility; superseded by /reinclude which
    # actually asks for and tests a feed URL before moving anything
    return redirect(url_for("trackers_page"))


_SELFTEST_PAGE = ("<html><head><title>starting</title></head><body>Listener self-test page (nothing to do here).<script>"
                  "navigator.serviceWorker.register('/push-selftest-sw.js',{scope:'/push-selftest'}).then(function(){"
                  "navigator.serviceWorker.ready.then(function(){document.title='ready';});}).catch(function(e){document.title='error';});"
                  "</script></body></html>")
_SELFTEST_SW = ("self.addEventListener('install',function(){self.skipWaiting();});"
                "self.addEventListener('activate',function(e){e.waitUntil(self.clients.claim());});"
                "self.addEventListener('push',function(e){var d={};try{d=e.data.json();}catch(x){}"
                "e.waitUntil(Promise.resolve(self.registration.showNotification(d.title||'test',{body:d.body||''})).catch(function(){}));});")


@app.route("/push-selftest")
def push_selftest_page():
    return Response(_SELFTEST_PAGE, mimetype="text/html")


@app.route("/push-selftest-sw.js")
def push_selftest_sw():
    return Response(_SELFTEST_SW, mimetype="application/javascript")


@app.route("/push/<action>", methods=["POST"])
def push_action(action):
    if action not in ("setup", "show", "hide", "probe", "selftest", "enable"):
        return jsonify({"ok": False, "error": "unknown action"})
    ensure_push_trackers()
    cfg = load(TRACKERS_PATH, "trackers", extra_keys=["excluded"])
    pts = [t for t in cfg["trackers"] if t.get("kind") == "push" and t.get("active", True)]
    if not pts:
        return jsonify({"ok": False, "error": "No alert trackers are active."})
    targets = [t for t in load(TARGETS_PATH, "targets")["targets"] if t.get("active", True)]
    mgr = push_listener.manager()
    mgr.configure(pts, targets, ALERTS_OUT, log, report)
    if action == "selftest":
        mgr.request("selftest", url=request.host_url.rstrip("/") + "/push-selftest")
        return jsonify({"ok": True})
    if action == "setup":
        urls = []
        for t in pts:
            urls += list(t.get("setup_urls") or [])
        mgr.request("setup", urls=urls)
    else:
        mgr.request(action)
    return jsonify({"ok": True})


@app.route("/api/status")
def api_status():
    _PAGE["last_poll"] = time.time()          # v62: the page is open (see _page_watch)
    with STATE_LOCK:
        running = STATE["running"]
    with LOG_LOCK:
        lines = list(LOG_LINES)
    with STATUS_LOCK:
        target_status = {k: dict(v) for k, v in STATUS["targets"].items()}
        tracker_status = {k: dict(v) for k, v in STATUS["trackers"].items()}
    return jsonify({
        "version": KIT_VERSION, "running": running, "logs": lines,
        "restocks": count_rows(GT_OUT), "alerts": count_rows(ALERTS_OUT),
        "target_status": target_status, "tracker_status": tracker_status,
        "push": push_listener.manager().snapshot(), "gaming": hotness.gaming(), "gaming_mode": hotness.mode(),
        "gaming_reason": hotness.auto_reason(), "load": _load_brief(), "push_dismissed": list(matrix.UI.get("push_dismissed") or []),
        "matrix_rev": _matrix_rev(), "finding": finder.busy(), "engines": browser_fetch.engine_report(),
        "buyer": _buyer_brief(), "restock_alerts": notify.restock_alerts_on(), "stores_health": _stores_health(),
        "update": {k: v for k, v in updater.brief().items() if k in ("available", "latest_version", "connected", "installing", "auto", "waiting")},
    })


def _stores_health():
    """v100: one word per store (ok / slowed / stalled / off) - only what holds for the whole store, never one product."""
    out = {}
    try:
        import sweep as _sw
        for st_ in ("amazon", "walmart", "bestbuy", "target", "gamestop"):
            if _sw._S.get(st_):
                out[st_] = _sw.health(st_)
    except Exception:
        pass
    return out


_STALL = {}            # store -> {"since": first seen stalled, "told": when the phone was told}
STALL_TELL_AFTER = 15 * 60.0
STALL_TELL_EVERY = 60 * 60.0


def _stall_step(now=None):
    """One look (see _stall_watch) -> the stores told about this time."""
    import sweep as _sw
    told = []
    if not STATE.get("running"):
        _STALL.clear()
        return told
    now = now or time.time()
    for st_, h in _stores_health().items():
        if h.get("state") != "stalled":
            if st_ in _STALL and _STALL[st_].get("told"):
                log(f"[health] {_sw.NAMES.get(st_, st_)}: its products are being read again.")
            _STALL.pop(st_, None)
            continue
        rec = _STALL.setdefault(st_, {"since": now, "told": 0.0})
        if now - rec["since"] >= STALL_TELL_AFTER and now - rec["told"] >= STALL_TELL_EVERY:
            rec["told"] = now
            nm = _sw.NAMES.get(st_, st_)
            amazon_buy._event("store:" + st_, nm, "CHECK", f"PROBLEM - {nm}: {h.get('text') or 'its products are not being read'}",
                              "Restocks there are not seen right now. The program keeps trying by itself; if this stays, open Restalker "
                              "(Remote Desktop) and look at that store's column - or press Stop and Start watching.", situation="remote")
            told.append(st_)
    return told


def _stall_watch():
    """v100: a store whose products have ALL gone unread for 15 minutes is a problem that needs you - sent to the phone (once an hour at
    most) and shown under Problems. It clears by itself when a product of that store is read again."""
    while True:
        time.sleep(30)
        try:
            _stall_step()
        except Exception as e:
            log(f"[health] check failed: {str(e)[:100]}")


def _buyer_brief():
    try:
        s = amazon_buy.snapshot()
        s["line"] = amazon_buy.summary_line(s)
        try:
            s["line_short"] = amazon_buy.short_line(s)
        except Exception:
            s["line_short"] = s["line"]
        return s
    except Exception as e:
        return {"on": False, "line": "status unavailable: " + str(e)[:100]}


@app.route("/api/logins", methods=["GET", "POST"])
def api_logins():
    """v90b: the stores' sign-ins, saved encrypted on this PC (logins.py). The password is never sent back, never logged."""
    import logins
    if request.method == "POST":
        b = request.get_json(silent=True) or {}
        st = str(b.get("store") or "")
        if b.get("remove"):
            logins.remove(st)
            log(f"[buyer] the saved {st} sign-in was removed by you.")
        else:
            r = logins.save(st, b.get("email"), b.get("password"))
            if not r.get("ok"):
                return jsonify(dict(logins.status(), ok=False, msg=r.get("reason")))
            log(f"[buyer] a {st} sign-in was saved by you (" + ("encrypted on this PC" if r.get("saved_to_disk") else "kept in memory until the program closes")
                + ") - the browsers sign themselves in with it when they are signed out.")
            try:
                import multibuy
                for w in list(multibuy._workers.values()):
                    w.auto_at.pop(st, None)
                    if w.state == "ready" and w.signed.get(st) is not True:
                        w.q.put({"account": True, "store": st})      # (signed out there: signs itself in now)
            except Exception:
                pass
            try:
                amazon_buy._autologin_at.pop(st, None)
            except Exception:
                pass
    return jsonify(dict(logins.status(), ok=True))


@app.route("/api/cardcode", methods=["GET", "POST"])
def api_cardcode():
    """v77: your card's security code, saved encrypted on this PC (Windows protection) so every checkout types it in by itself.
    The code itself is never sent back to this page, never logged."""
    import cardcode
    if request.method == "POST":
        b = request.get_json(silent=True) or {}
        if b.get("remove"):
            cardcode.remove()
            log("[buyer] the saved card security code was removed by you - checkouts ask you for it again.")
        else:
            r = cardcode.save(b.get("value"))
            if not r.get("ok"):
                return jsonify(dict(cardcode.status(), ok=False, msg=r.get("reason")))
            log("[buyer] a card security code was saved by you (encrypted on this PC) - checkouts type it in by themselves now."
                if r.get("saved_to_disk") else "[buyer] a card security code was given by you - kept in memory until the program closes.")
        try:
            threading.Thread(target=amazon_buy.push_card_code, daemon=True).start()
        except Exception:
            pass
    st = cardcode.status()
    msg = ("Saved - every checkout types it in by itself (encrypted on this PC; only your Windows account can read it)." if st["saved"] and st["on_disk"] else
           "Kept until the program closes (this PC cannot encrypt it, so it is not saved to a file)." if st["saved"] else
           "Not saved - a store that asks for it makes the checkout wait for you.")
    if st["paused"]:
        msg = "NOT USED NOW: " + st["paused"] + "."
    return jsonify(dict(st, ok=True, msg=msg))


@app.route("/api/amazon-buy", methods=["GET", "POST"])
def api_amazon_buy():
    """v54: Amazon auto-buy controls (switch, sign-in window, arm / disarm / buy again / shipping approval, emergency stop)."""
    res = None
    if request.method == "POST":
        org = request.headers.get("Origin") or request.headers.get("Referer") or ""
        if org and not re.match(r"^https?://(127\.0\.0\.1|localhost)(:\d+)?(/|$)", org):
            return jsonify({"ok": False, "reason": "only this program's own page may change auto-buy"}), 403
        if not request.is_json:
            return jsonify({"ok": False, "reason": "bad request"}), 400
        b = request.get_json(silent=True) or {}
        if b.get("action") in ("armgroup", "disarmgroup"):
            b["tid"] = b.get("tids") or []
        if "action" not in b and "on" in b:
            b["action"] = "on" if b.get("on") else "off"
        try:
            if b.get("action") == "cvv":            # the card security code for ONE waiting Best Buy checkout: passed on, never stored or logged
                res = amazon_buy.give_cvv(b.get("tid"), b.get("value"))
            elif b.get("action") == "onemore":      # v112b: the table's own "Buy one more" button = the phone message's button
                res = amazon_buy.buy_one_more(str(b.get("tid") or ""))
            else:
                res = amazon_buy.act(str(b.get("action") or ""), b.get("tid"))
        except Exception as e:
            res = {"ok": False, "reason": str(e)[:200]}
    out = _buyer_brief()
    out["result"] = res
    return jsonify(out)


def _load_brief():
    try:
        s = loadplan.snapshot()
        return {"profile": s["profile"], "label": loadplan.PROFILES[s["profile"]][0], "cpu_pct_pc": s["cpu_pct_pc"], "gb": s["gb"],
                "readers": s["readers_active"], "waiting": s["readers_extra_waiting"]}
    except Exception:
        return {}


@app.route("/api/loadplan", methods=["GET", "POST"])
def api_loadplan():
    """Speed versus PC load: the owner picks how much of the PC the program may use (see loadplan.py). More room = more readers at the same time."""
    if request.method == "POST":
        b = request.get_json(silent=True) or {}
        key = b.get("profile")
        if key in loadplan.PROFILES:
            loadplan.set_profile(key)
            with matrix.LOCK:
                matrix.UI["load_profile"] = key
            matrix.save_ui()
            log(f"[speed] Speed setting changed to {loadplan.PROFILES[key][0]} by you: up to {loadplan.PROFILES[key][1] * 100:.0f}% of the PC's processor and "
                f"{loadplan.PROFILES[key][2] * 100:.0f}% of its memory. Readers are added or rested to fit (reading is never slowed).")
    snap = loadplan.snapshot()
    try:
        rep = ground_truth_poller.speed_report()
        snap["stores"] = rep
        snap["delay_all"] = ground_truth_poller.speed_overall(rep)
    except Exception:
        snap["stores"], snap["delay_all"] = {}, None
    snap["gaming"] = hotness.gaming()
    try:
        snap["blocked"] = ground_truth_poller.blocked_report()[:30]        # v52: products held back from readers by a human-check page
        snap["housekeeping"] = hygiene.text()
    except Exception:
        snap["blocked"], snap["housekeeping"] = [], None
    try:
        snap["windows"] = audit.window_stats(GT_OUT)
    except Exception:
        snap["windows"] = None
    return jsonify(snap)


@app.route("/api/gaming", methods=["GET", "POST"])
def api_gaming():
    """Gaming mode: the program steps back so a game can have the PC (extra products are looked at much less often, drawn Target
    pages half as often, all browsers at the lowest priority and in 'efficiency mode'). The original products keep their pace.
    Three settings: auto (the program notices a game by itself - default), on (always), off (never)."""
    if request.method == "POST":
        b = request.get_json(silent=True) or {}
        mode = b.get("mode") or ("on" if b.get("on") else "auto")
        if mode not in ("auto", "on", "off"):
            mode = "auto"
        before = hotness.gaming()
        hotness.set_mode(mode)
        with matrix.LOCK:
            matrix.UI["gaming_mode"] = mode
            matrix.UI["gaming"] = (mode == "on")
        matrix.save_ui()
        log(f"[pace] Gaming mode set to {mode.upper()} by you. In effect now: {'ON - extra products are looked at less often and the browsers use the lowest priority' if hotness.gaming() else 'OFF'}"
            + (f" (automatic detection says: {hotness.auto_reason() or 'no game'})" if mode == "auto" else "") + ".")
    return jsonify({"on": hotness.gaming(), "mode": hotness.mode(), "reason": hotness.auto_reason()})


def _on_game_change(on, reason):
    """gamedetect.py noticed a game start / stop."""
    hotness.set_auto(on, reason)
    mode = hotness.mode()
    log(f"[pace] Gaming mode switched {'ON' if on else 'OFF'} automatically: {reason}." +
        (" Extra products are looked at less often and the browsers use the lowest priority." if on and mode == "auto" else "") +
        (f" (Your switch is set to {mode.upper()}, so it has no effect right now.)" if mode != "auto" else ""))


@app.route("/api/push-dismiss", methods=["POST"])
def api_push_dismiss():
    """'Do not remind me' for an alert tracker that is not set up (the set-up box at the top then stays away for it)."""
    b = request.get_json(silent=True) or {}
    tid = str(b.get("id", ""))
    if tid not in ("trackalacker", "hotstock") and not re.match(r"^[a-z0-9_]{2,40}$", tid):
        return jsonify({"ok": False})
    matrix.set_dismissed(tid, bool(b.get("on", True)))
    return jsonify({"ok": True, "dismissed": list(matrix.UI["push_dismissed"])})


ICON_DIR = "icons"
ICON_EXT = (".png", ".jpg", ".jpeg", ".webp", ".gif", ".svg")


def _icon_file(key):
    """The picture for a product row: one you put in the 'icons' folder (named like the_hobbit_box.png) wins; otherwise the
    product picture the program downloaded itself (icons/auto/)."""
    return thumbs.find_file(key)


@app.route("/icon/<path:name>")
def product_icon(name):
    sub = ""
    if name.startswith("auto/"):
        sub, name = "auto", name[5:]
    if "/" in name or "\\" in name or ".." in name or not name.lower().endswith(ICON_EXT):
        return Response("not found", status=404)
    path = os.path.join(ICON_DIR, sub, name) if sub else os.path.join(ICON_DIR, name)
    if not os.path.isfile(path):
        return Response("not found", status=404)
    from flask import send_file
    return send_file(os.path.abspath(path), max_age=0)


ALERT_PAGES = "alert_pages"
ALERT_PAGES_KEEP = 40
ALERT_PAGE_MAX = 400 * 1024


def _keep_alert_page(cap, tid, read_by):
    """v105: right after a tracker alert, the page our reader just read is kept (alert_pages/) - to see what we were shown when the
    tracker said it was in stock. Only a page the sweeper itself holds (the whole store page); the newest 40 files are kept."""
    try:
        import sweep as _sw
        f = _sw.FRESH.get(tid) or {}
        if f.get("kind") != "page" or not f.get("text") or (read_by and f.get("src") != read_by):
            return
        name = time.strftime("%Y%m%d-%H%M%S", time.localtime(f.get("at") or time.time())) + f"_{re.sub(r'[^A-Za-z0-9_]+', '_', tid)[:40]}_{len(cap['pages']) + 1}.html"
        cap["pages"].append(name)
        txt = str(f["text"])[:ALERT_PAGE_MAX]
        head = f"<!-- Restalker: kept {time.strftime('%Y-%m-%d %H:%M:%S')} after a tracker alert. Tracker said: {cap['said'][:200].replace('--', '-')} | read by: {str(f.get('src')).replace('--', '-')} -->\n"

        def w():
            try:
                os.makedirs(ALERT_PAGES, exist_ok=True)
                with open(os.path.join(ALERT_PAGES, name), "w", encoding="utf-8", errors="replace") as fh:
                    fh.write(head + txt)
                old = sorted(os.listdir(ALERT_PAGES))
                for o in old[:-ALERT_PAGES_KEEP]:
                    try:
                        os.remove(os.path.join(ALERT_PAGES, o))
                    except Exception:
                        pass
            except Exception:
                pass
        threading.Thread(target=w, daemon=True, name="alert-page").start()
    except Exception:
        pass


def _update_busy():
    """v101: an update never installs while something is being bought."""
    try:
        import multibuy
        if multibuy.busy():
            return "a buying browser is checking out"
    except Exception:
        pass
    try:
        if amazon_buy.snapshot(brief=True).get("checkout"):
            return "the buying browser is checking out"
    except Exception:
        pass
    try:                                 # v115: also while a purchase is being confirmed or its result looked up
        if amazon_buy._verifying:
            return "a purchase is being looked up in your Amazon orders"
        if any((c or {}).get("state") == "checking" for c in list(amazon_buy._checks.values())):
            return "an order result is being looked up"
        if amazon_buy.checkout_busy():
            return "a checkout is running"
    except Exception:
        pass
    return ""


PAGE_BACK_WAIT = 25.0


def _open_page_once(url, after_update, opener=None, wait=None):
    """Opens Restalker's page in your browser. v106 (owner 2026-11-06: "the program update works, but it actually opens a second tab"):
    after an update the page that was open reconnects by itself - a new tab is opened only if no page has come back within 25 s."""
    opener = opener or lifeline.open_user_browser
    if not after_update:
        threading.Timer(1.2, lambda: opener(url)).start()          # (your browser: never closed with the program)
        return "opened"
    t0 = time.time()

    def wait_then():
        while time.time() - t0 < (wait if wait is not None else PAGE_BACK_WAIT):
            if _PAGE["last_poll"] > t0:
                log("[update] the page that was open came back by itself - no new tab opened.")
                return
            time.sleep(0.5)
        log("[update] no page came back - opening Restalker's page.")
        opener(url)
    threading.Thread(target=wait_then, daemon=True, name="page-open").start()
    return "waiting"


def _update_shutdown():
    """v104: after an update is in place - the program closes the normal way (watchers, every browser, then itself with exit 0, so the
    black window closes without the "stopped because of a problem" message); the new version is already on its way (updater._restart)."""
    ev = STATE.get("stop_event")
    if ev is not None:
        ev.set()
    STATE["running"] = False
    log("[update] closing this copy for the new version...")
    _shutdown_everything(list(STATE.get("threads") or []), True)


@app.route("/api/update", methods=["GET", "POST"])
def api_update():
    """v101: updates from the release home (updater.py): GET = what is known; POST {action: check | install | back}."""
    if request.method == "POST":
        org = request.headers.get("Origin") or request.headers.get("Referer") or ""
        if org and not re.match(r"^https?://(127\.0\.0\.1|localhost)(:\d+)?(/|$)", org):
            return jsonify({"ok": False, "text": "only this program's own page may do this"}), 403
        a = str((request.get_json(silent=True) or {}).get("action") or "")
        if a == "check":
            updater.check()
            return jsonify(dict(updater.brief(), ok=True))
        if a == "install":
            r = updater.install(restart=True)
            return jsonify(dict(updater.brief(), ok=r["ok"], text=r["text"]))
        if a == "back":
            r = updater.go_back(restart=True)
            return jsonify(dict(updater.brief(), ok=r["ok"], text=r["text"]))
        if a in ("auto_on", "auto_off"):        # v115: automatic / manual updates
            updater.set_auto(a == "auto_on")
            if a == "auto_on" and updater.state.get("available"):
                threading.Thread(target=updater.auto_step, daemon=True, name="update-auto").start()
            return jsonify(dict(updater.brief(), ok=True, text="Automatic updates on." if a == "auto_on" else "Automatic updates off."))
        return jsonify({"ok": False, "text": "unknown action"})
    return jsonify(dict(updater.brief(), ok=True))


@app.route("/api/product-history")
def api_product_history():
    """v100: one product's restock waves with bought / not bought and a short reason (the window opened by its name on Products)."""
    key = (request.args.get("key") or "").strip()
    with CONFIG_LOCK:
        targets = load(TARGETS_PATH, "targets")["targets"]
    rows = [t for t in targets if t.get("id") and matrix.key_of(t) == key]
    if not key or not rows:
        return jsonify({"ok": False, "text": "unknown product"})
    try:
        import history
        byid = {t["id"]: t for t in rows}
        caps = [float(t["max_price"]) for t in rows if t.get("max_price") not in (None, "")]
        try:
            wanted = any(amazon_buy.wanted(amazon_buy._u_of(t)) for t in rows)
        except Exception:
            wanted = None
        waves = history.build(list(byid), [t.get("match_name", "") for t in rows],
                              lambda i: matrix.store_name(matrix.store_of(byid[i])) if i in byid else "",
                              min(caps) if caps else None, audit._read_csv(GT_OUT), amazon_buy.purchases_list(100000),
                              amazon_buy.buy_events_all(), wanted=wanted)
        return jsonify({"ok": True, "title": rows[0].get("match_name") or key, "waves": waves,
                        "since": _first_gt_time()})
    except Exception as e:
        log(f"[history] {key}: {str(e)[:120]}")
        return jsonify({"ok": False, "text": "the history could not be read just now"})


def _first_gt_time():
    try:
        with open(GT_OUT, encoding="utf-8", errors="replace") as f:
            f.readline()
            first = f.readline().split(",", 1)[0]
        import history
        return history._ts(first)
    except Exception:
        return None


@app.route("/api/matrix")
def api_matrix():
    with CONFIG_LOCK:
        targets = load(TARGETS_PATH, "targets")["targets"]
    m = matrix.build(targets)
    for p in m["products"]:
        f = _icon_file(p["key"])
        if f:
            try:
                v = int(os.path.getmtime(os.path.join(ICON_DIR, f)))
            except OSError:
                v = 0
            p["img"] = "/icon/" + f + "?v=" + str(v)
        p["searching"] = finder.busy(p["key"])
        for c in [x for c0 in (p.get("cells") or {}).values() if c0 for x in [c0] + (c0.get("more") or [])]:   # v75 (v109: every link of the cell)
            if c and c.get("found"):
                try:
                    import linkcheck
                    v = linkcheck.verified(c["id"])
                    c["checked"] = bool(v.get("by_you") and v.get("url") == c.get("url"))
                except Exception:
                    c["checked"] = False
    m["kinds"] = [{"slug": k, "label": lab} for k, lab in matrix.kind_options()]
    m["rev"] = _matrix_rev()
    return jsonify(m)


def _matrix_rev():
    """Changes whenever something in the table changed by itself (a picture arrived, the search found a link): the page then redraws."""
    return f"{matrix.REV[0]}.{thumbs.revision()}"


def _targets_snapshot():
    with CONFIG_LOCK:
        return list(load(TARGETS_PATH, "targets")["targets"])


def _live_list():
    # (no STATE_LOCK here: api_start holds it while it takes CONFIG_LOCK, and a table change holds CONFIG_LOCK - taking both would be a deadlock risk)
    return STATE.get("targets") if STATE.get("running") else None


def _live_apply(fn):
    """Runs fn(list) on the list of links the checkers are working from (when the program is running)."""
    lst = _live_list()
    if lst is not None:
        try:
            fn(lst)
        except Exception as e:
            log(f"[warn] could not update the running checkers: {type(e).__name__}: {str(e)[:100]}")


def _drop_live(ids):
    ids = set(ids)
    if not ids:
        return
    _live_apply(lambda lst: lst.__setitem__(slice(None), [t for t in lst if t["id"] not in ids]))
    for grp in list(ground_truth_poller.GROUPS.values()):
        grp[:] = [t for t in grp if t["id"] not in ids]
    mgr = push_listener.manager()
    with mgr.lock:
        mgr.targets = [t for t in mgr.targets if t["id"] not in ids]


def _to_cap(v):
    try:
        c = round(float(v), 2)
    except (TypeError, ValueError):
        return None
    return c if c > 0 else None


def _adopt_new_link(t):
    """A new link was saved: hand it to the running checkers (when the program is running). Returns (running, started)."""
    lst = _live_list()
    started = False
    if lst is not None:
        lst.append(t)
        started = tcg_index.adopt(t) if tcg_index.is_tcg(t) else ground_truth_poller.adopt_target(t)
        push_listener.manager().add_target(t)
    return lst is not None, started


TRACKER_LINKS_EVERY = 300.0


def tracker_links_add():
    """v109 (owner 2026-11-08: "yes we should be adding additional links for any product that has multiple pages ... ideally it should
    all be contained in the same cell"): a tracker that watches ANOTHER Amazon page of one of our products (tracker_feed_poller.PAGE_LINKS:
    the first Amazon link of its listing page / alert) -> that page is added to the product's Amazon square as one more link. Never a
    page you marked wrong; at most 4 links in a square; it is bought only after its own page shows this exact product (found_by=tracker).
    -> the links added."""
    import tracker_feed_poller as _tfp
    added = []
    for rec in list(_tfp.PAGE_LINKS.values()):
        a, tids = rec.get("asins") or [], rec.get("tids") or []
        if not a or not tids or rec.get("added"):
            continue
        asin = a[0]
        with CONFIG_LOCK:
            cfg = load(TARGETS_PATH, "targets")
            base = next((t for t in cfg["targets"] if t["id"] == tids[0] and t.get("active", True)), None)
            if base is None:
                continue
            key = matrix.key_of(base)
            url = f"https://www.amazon.com/dp/{asin}"
            here = [t for t in cfg["targets"] if matrix.key_of(t) == key and matrix.store_of(t) == "amazon" and t.get("active", True)]
            if any(matrix.same_page(t.get("url", ""), url) for t in here):
                rec["added"] = "one we watch now"
                continue
            ok, msg, t = _save_link_locked(cfg, key, "amazon", url, found_by="tracker", extra=True)
        if ok and t is not None:
            rec["added"] = f"added to the square as {t['id']}"
            added.append(t["id"])
            log(f"[link] {base.get('match_name') or key}: {rec.get('tracker')} watches another Amazon page of it ({asin}) - added to its Amazon "
                f"square as one more link ({t['id']}). It is bought only after its own page shows this exact product.")
            matrix.bump()
        else:
            rec["added"] = f"not added: {msg}"
    return added


def _tracker_links_watch():
    time.sleep(60)
    while True:
        try:
            if STATE.get("running"):
                tracker_links_add()
        except Exception as e:
            log(f"[link] tracker pages: {str(e)[:100]}")
        time.sleep(TRACKER_LINKS_EVERY)


def _arm_like_siblings(t, sibs):
    """v109: another page of a product that is set to Buy is set to Buy too (a moment later, outside the table's lock). One purchase per
    product still holds across all its pages; a page the program found is bought only after its own page shows this product."""
    def work():
        time.sleep(1.5)
        try:
            if any(amazon_buy.wanted(amazon_buy._u_of(x)) for x in sibs):
                r = amazon_buy.act("armgroup", [t["id"]]) or {}
                log(f"[link] {t['id']}: set to Buy like the product's other links" + ("" if r.get("ok", True) else f" - not now: {r.get('reason')}"))
        except Exception as e:
            log(f"[link] {t['id']}: could not be set to Buy like its other links ({str(e)[:80]})")
    threading.Thread(target=work, daemon=True, name="arm-extra").start()


def _save_link_locked(cfg, key, store, url, found_by=None, extra=False, tid=None):
    """Saves a link for a square (CONFIG_LOCK held by the caller). -> (ok, message, new_target_or_None).
    v109: extra = one MORE page of this product at this store (same square); tid = change THAT link (a square can hold several)."""
    ts = cfg["targets"]
    if found_by in ("search", "tracker") and matrix.link_norm(url) in set(matrix.bad_links(key)):
        return False, "You marked that link as the wrong product.", None
    if tid:
        cur = next((t for t in ts if t["id"] == tid and matrix.key_of(t) == key and matrix.store_of(t) == store), None)
        if cur is None:
            return False, "That link was not found.", None
        if any(matrix.same_page(t.get("url", ""), url) for t in ts if t["id"] != tid and matrix.key_of(t) == key
               and matrix.store_of(t) == store and t.get("active", True)):
            return False, "That page is in this square already.", None
    elif extra:
        cur = None
    else:
        cur = next((t for t in ts if matrix.key_of(t) == key and matrix.store_of(t) == store and t.get("active", True)), None)
    if cur is not None:
        cur["url"] = url
        cur.pop("found_by", None)
        cur.pop("sku", None)
        if found_by:
            cur["found_by"] = found_by
            cur.pop("by_you", None)
        else:
            cur["by_you"] = True                  # v75: a link YOU typed / pasted - the right product, never checked against the name                  # v75: the OLD page's item number never stays with a new link (it was taken for a wrong product)
        if store == "bestbuy" and matrix.sku_from_url(url):
            cur["sku"] = matrix.sku_from_url(url)
        save(TARGETS_PATH, cfg)

        def _chg(lst):
            for t in lst:
                if t["id"] == cur["id"]:
                    t["url"] = url
                    t.pop("found_by", None)
                    t.pop("sku", None)
                    t.pop("by_you", None)
                    for k in ("found_by", "by_you"):
                        if cur.get(k):
                            t[k] = cur[k]
                    if cur.get("sku"):
                        t["sku"] = cur["sku"]
        _live_apply(_chg)
        return True, "Link changed.", None
    t = matrix.new_link(ts, key, store, url, found_by=found_by, extra=extra)
    if t is None:
        if extra:
            return False, ("That page is in this square already." if any(matrix.same_page(x.get("url", ""), url) for x in ts if matrix.key_of(x) == key and matrix.store_of(x) == store)
                           else f"This square holds {matrix.MAX_LINKS} links already - remove one first."), None
        return False, "Could not add that link.", None
    if not found_by:
        t["by_you"] = True                        # v75: a link YOU gave
    ts.append(t)
    save(TARGETS_PATH, cfg)
    running, started = _adopt_new_link(t)
    if extra:
        _arm_like_siblings(t, [x for x in ts if matrix.key_of(x) == key and x["id"] != t["id"] and x.get("active", True)])
    if running and not started:
        return True, "Link saved. This store has no checker running yet, so it starts the next time you press Start watching.", t
    return True, "Link saved" + (" and being watched now." if running else ". It is watched when you press Start watching."), t


def _row_spec(key):
    """What to search for: {'match_name','kind','aliases'} of a row (from its links, or from the row you added)."""
    for t in _targets_snapshot():
        if matrix.key_of(t) == key and t.get("active", True):
            return {"match_name": t.get("match_name", ""), "kind": products.kind_of(t), "aliases": list(t.get("aliases") or [])}
    with matrix.LOCK:
        e = next((x for x in matrix.UI["extra_products"] if x["key"] == key), None)
    return {"match_name": e.get("match_name", ""), "kind": e.get("kind", "box"), "aliases": []} if e else None


def _search_tcg(key):
    """v46: finds a row's TCGplayer link in TCGplayer's catalogue copy (tcgcsv.com) and saves it into the TCG column."""
    spec = _row_spec(key)
    if not spec:
        return False
    theme, kind = matrix.split_key(key)

    def work():
        found = False
        try:
            link = tcg_index.find_link(theme, kind)
            if link and _row_spec(key) is not None:
                with CONFIG_LOCK:
                    cfg = load(TARGETS_PATH, "targets")
                    ok, msg, t = _save_link_locked(cfg, key, "tcg", link, found_by="search")
                if ok and t is not None:
                    found = True
                    thumbs.request(key)
                    log(f"[search] TCG: {matrix.title_of(theme)} -> {link}")
        except Exception as e:
            log(f"[search] TCG lookup for '{key}' failed: {type(e).__name__}: {str(e)[:100]}")
        matrix.mark_searched(key, "tcg", found)
        matrix.bump()
    threading.Thread(target=work, daemon=True, name="tcg-find").start()
    return True


def search_other_stores(key, force=False, only=None):
    """Looks for this product at every store that has no link for it yet (see finder.py). -> message.
    only: just these stores (v75: after you marked a link wrong). Links you marked wrong are never picked again."""
    spec = _row_spec(key)
    if not spec or not spec["match_name"]:
        return "That product was not found."
    spec = dict(spec, exclude=matrix.bad_links(key))
    if finder.too_general(spec):
        return ("Not searched at the other stores: the name '" + spec["match_name"] + "' is too general (any such product would match). "
                "Give the row the product's full name (brand and model) or paste the other stores' links yourself.")
    have = {matrix.store_of(t) for t in _targets_snapshot() if matrix.key_of(t) == key and t.get("active", True)}
    with matrix.LOCK:
        off = set(matrix.UI["stores_off"])
        done = dict(matrix.UI["searched"].get(key) or {})
    stores = [s for s in finder.STORES if s not in have and s not in off and (force or s not in done) and (only is None or s in only)]
    if only is not None and not stores:
        return "That store already has a link (or is switched off)."
    if only is None and "tcg" not in have and "tcg" not in off and (force or "tcg" not in done):
        _search_tcg(key)                                  # v46: the TCG price-index link comes from TCGplayer's own catalogue (own thread, light)
    if not stores:
        return "Every store already has a link (or was already searched)." if "tcg" in have else "Looking for the TCG price link."

    def add_cb(store, link):
        if _row_spec(key) is None:                       # the product was removed while the search was running
            return False
        with CONFIG_LOCK:
            cfg = load(TARGETS_PATH, "targets")
            ok, msg, t = _save_link_locked(cfg, key, store, link, found_by="search")
        if ok and t is not None:
            thumbs.request(key)
            matrix.bump()
        return bool(ok and t is not None)

    started = finder.start_search(key, spec, stores, add_cb, log=log, gaming_fn=hotness.gaming,
                                  mark_cb=lambda st, found: matrix.mark_searched(key, st, found),
                                  done_cb=lambda res: (matrix.bump(), log("[search] done: " + ", ".join(f"{k}: {v}" for k, v in res.items()))))
    if not started:
        return "Already searching for that product."
    log(f"[search] looking for '{spec['match_name']}' at: {', '.join(matrix.store_name(s) for s in stores)} (one store at a time, in the background).")
    return "Searching " + ", ".join(matrix.store_name(s) for s in stores) + " for it. Links found appear in the table by themselves."


def _buy_off_for(keys):
    """Auto-buy off for the Amazon links of these product rows (only where it is on)."""
    try:
        tids = [t["id"] for t in _targets_snapshot() if matrix.store_of(t) in ("amazon", "bestbuy", "target", "walmart", "gamestop") and matrix.key_of(t) in set(keys)]
        armed = {r["tid"] for r in amazon_buy.snapshot().get("rows", []) if r.get("armed") or r.get("wanted")}
        tids = [x for x in tids if x in armed]
        if tids:
            amazon_buy.act("disarmgroup", tids)
    except Exception as e:
        log(f"[buyer] could not switch auto-buy off with the product: {e}")


def _mx_apply(op, b):
    """One change from the table. Returns (ok, message). The switches live in ui_state.yaml, the links and caps in targets.yaml."""
    if op == "product":
        key = str(b.get("key", ""))
        matrix.set_product(key, bool(b.get("on")))
        if not b.get("on"):
            _buy_off_for([key])          # v55: a product that is not watched is not bought either
        return True, ""
    if op == "products":                 # v75: several products on / off (a group button - leaving bought / locked ones alone)
        keys = [str(k) for k in (b.get("keys") or [])][:500]
        for k in keys:
            matrix.set_product(k, bool(b.get("on")))
        if not b.get("on"):
            _buy_off_for(keys)
        return True, ""
    if op == "group":                    # v55: watch a whole group on / off
        name = str(b.get("group", ""))
        keys = [p["key"] for p in matrix.build(_targets_snapshot())["products"] if p.get("group") == name]
        for k in keys:
            matrix.set_product(k, bool(b.get("on")))
        if not b.get("on"):
            _buy_off_for(keys)
        return True, f"{name}: watching {'ON' if b.get('on') else 'OFF'} for {len(keys)} products." + ("" if b.get("on") else " (Auto-buy is off for them too.)")
    if op == "store":
        matrix.set_store(str(b.get("key", "")), bool(b.get("on")))
        if not b.get("on"):
            try:                                      # v58: a store switched off is not bought at either
                amazon_buy.act("disarmgroup", [t["id"] for t in _targets_snapshot() if matrix.store_of(t) == str(b.get("key", ""))])
            except Exception:
                pass
        return True, ""
    if op == "cell":
        matrix.set_cell(str(b.get("id", "")), bool(b.get("on")))
        if not b.get("on"):
            try:                                      # v58: a store switched off for a product is not bought there either
                amazon_buy.act("disarmgroup", [str(b.get("id", ""))])
            except Exception:
                pass
        return True, ""
    if op == "addstore":
        key = matrix.add_store(b.get("name", ""))
        return (True, f"Added the store column '{matrix.store_name(key)}'. Use '+ link' in a square to give it a product page.") if key else (False, "Type the store name first.")
    if op == "addproduct":
        kind = b.get("kind", "box")
        cap = _to_cap(b.get("cap"))
        name = (b.get("name") or "").strip()
        link = (b.get("link") or "").strip()
        if not name:
            return False, "Type the product name first."
        if cap is None:
            return False, "Type the price cap (a number above zero) first."
        if "kindlabel" in b:                    # v75: the category box - a choice from the list, or a new name you typed
            lab = re.sub(r"\s+", " ", str(b.get("kindlabel") or "")).strip()
            if not lab:
                return False, "Type or pick a category first (for example: Collector Booster Box, Sleeves, Cables)."
            kind = next((k for k, l in matrix.kind_options() if lab.lower() in (k.lower(), l.lower())), None) or matrix.add_kind(lab)
            if not kind:
                return False, "That category name cannot be used - use letters or numbers."
        if kind == "__new__":
            kind = matrix.add_kind(b.get("newkind", ""))
            if not kind:
                return False, "Type a name for the new category first (for example: Commander Deck)."
        if link and not re.match(r"^https?://[^\s/]+\.[^\s/]+", link):
            return False, "That does not look like a web link. Paste the full address (starting with https://) or leave the link empty."
        key = matrix.add_product(name, kind, cap)
        if not key:
            return False, "Could not add that product (check the name and the category)."
        msg = "Added the product row."
        if link:
            store = matrix.store_of({"url": link})
            with CONFIG_LOCK:
                cfg = load(TARGETS_PATH, "targets")
                ok, m2, t = _save_link_locked(cfg, key, store, link)
            msg += " " + m2
            if ok:
                thumbs.request(key)
        msg += " " + search_other_stores(key, force=True)
        matrix.bump()
        return True, msg
    if op == "wronglink":                # v75: you say this link is NOT the product -> removed, never bought, the right one is looked for
        tid = str(b.get("id", ""))
        with CONFIG_LOCK:
            cfg = load(TARGETS_PATH, "targets")
            t = next((x for x in cfg["targets"] if x["id"] == tid), None)
            if t is None:
                return False, "That link was not found."
            key, store = matrix.key_of(t), matrix.store_of(t)
            cfg["targets"] = [x for x in cfg["targets"] if x["id"] != tid]
            save(TARGETS_PATH, cfg)
        with matrix.LOCK:
            matrix.UI["cells_off"].discard(tid)
        matrix.add_bad_link(key, store, t.get("url", ""))
        try:
            import linkcheck
            linkcheck.confirm_by_you(t, False)
        except Exception:
            pass
        try:
            amazon_buy.act("disarmgroup", [tid])
        except Exception:
            pass
        msrp.forget([tid])
        _drop_live([tid])
        log(f"[link] {tid}: you marked it as the WRONG product - removed, never bought; looking for the right one at {matrix.store_name(store)}.")
        msg = search_other_stores(key, force=True, only=[store]) if store in finder.STORES else ""
        matrix.bump()
        return True, f"Marked as the wrong product and removed (never bought). {msg}".strip()
    if op == "rightlink":                # v75: you looked at a link the program found - it IS the product
        tid = str(b.get("id", ""))
        with CONFIG_LOCK:
            t = next((x for x in load(TARGETS_PATH, "targets")["targets"] if x["id"] == tid), None)
        if t is None:
            return False, "That link was not found."
        import linkcheck
        linkcheck.confirm_by_you(t, True)
        log(f"[link] {tid}: you checked it - it IS the right product (it may be bought).")
        matrix.bump()
        try:
            amazon_buy._wake.set()
        except Exception:
            pass
        return True, "Thanks - that link is the right product now (it may be bought)."
    if op == "searchrow":
        key = str(b.get("key", ""))
        matrix.unmark_searched(key)
        return True, search_other_stores(key, force=True)
    link_result, search_key = None, None
    with CONFIG_LOCK:
        cfg = load(TARGETS_PATH, "targets")
        ts = cfg["targets"]
        if op == "cap":
            cap = _to_cap(b.get("cap"))
            if cap is None:
                return False, "The price cap must be a number above zero. Nothing was changed."
            key = str(b.get("key", ""))
            matrix.set_cap(ts, key, cap)
            save(TARGETS_PATH, cfg)
            _live_apply(lambda lst: [(t.__setitem__("max_price", cap), t.pop("needs_cap", None)) for t in lst if matrix.key_of(t) == key])
            extra = " It is being watched now." if matrix.LAST_ACTIVATED[0] else ""
            return True, f"Price cap set to ${cap:g} at every store for this product." + extra
        if op == "link":
            key, store, url = str(b.get("key", "")), str(b.get("store", "")), (b.get("url") or "").strip()
            if not re.match(r"^https?://[^\s/]+\.[^\s/]+", url):
                return False, "That does not look like a web link. Paste the full address (starting with https://)."
            if not matrix.column_takes(store, url):
                return False, f"That link is not from {matrix.store_name(store)}. Nothing was saved."
            ok, msg, t = _save_link_locked(cfg, key, store, url, extra=bool(b.get("extra")), tid=(str(b.get("id")) if b.get("id") else None))
            if ok:
                thumbs.request(key)                    # look for its picture right away
                with matrix.LOCK:
                    user_row = any(e["key"] == key for e in matrix.UI["extra_products"]) and key not in matrix.UI["searched"]
                if user_row and t is not None:
                    search_key = key                   # (the search reads targets.yaml itself: started after this lock is released)
            link_result = (ok, msg)
        if op == "clearlink":
            tid = str(b.get("id", ""))
            n0 = len(ts)
            cfg["targets"] = [t for t in ts if t["id"] != tid]
            if len(cfg["targets"]) == n0:
                return False, "That link was not found."
            save(TARGETS_PATH, cfg)
            with matrix.LOCK:
                matrix.UI["cells_off"].discard(tid)
            matrix.save_ui()
            msrp.forget([tid])
            _drop_live([tid])
            return True, "Link removed. That square is blank now (not watched)."
        if op in ("rmproduct", "rmstore"):
            key = str(b.get("key", ""))
            if op == "rmproduct":
                gone = matrix.remove_product(ts, key)
                matrix.unmark_searched(key)
            else:
                gone = matrix.remove_store(ts, key)
            cfg["targets"] = [t for t in ts if t["id"] not in set(gone)]
            save(TARGETS_PATH, cfg)
            msrp.forget(gone)
            _drop_live(gone)
            return True, f"Removed ({len(gone)} link(s) deleted)."
    if link_result is not None:
        ok, msg = link_result
        if ok and search_key:
            msg += " " + search_other_stores(search_key)
        return ok, msg
    return False, "Unknown action."


@app.route("/api/matrix/<op>", methods=["POST"])
def api_matrix_op(op):
    b = request.get_json(silent=True) or {}
    try:
        ok, msg = _mx_apply(op, b)
    except Exception as e:
        log(f"[warn] table change '{op}' failed: {type(e).__name__}: {str(e)[:120]}")
        return jsonify({"ok": False, "msg": "That change failed; nothing was damaged. Details are in the log."})
    return jsonify({"ok": ok, "msg": msg})


@app.route("/api/start", methods=["POST"])
def api_start():
    bad = old_files()
    if bad:
        return jsonify({"ok": False, "error": "Some program files are old (" + ", ".join(bad) +
                        "). Copy ALL files from the newest kit into the folder and restart."})
    with STATE_LOCK:
        if STATE["running"]:
            return jsonify({"ok": False, "error": "Already running."})
        ensure_new_products()
        all_targets = load(TARGETS_PATH, "targets")["targets"]
        all_trackers = load(TRACKERS_PATH, "trackers", extra_keys=["excluded"])["trackers"]
        targets = [t for t in all_targets if t.get("active", True)]
        targets, tcg_targets = tcg_index.split(targets)         # v46: TCGplayer links are a price index (read for their price only), not shops to watch
        trackers = [t for t in all_trackers if t.get("active", True)]
        push_trackers = [t for t in trackers if t.get("kind") == "push"]
        discord_trackers = [t for t in trackers if t.get("kind") == "discord_in"]
        feed_trackers = [t for t in trackers if t.get("kind") not in ("push", "discord_in")]
        if not targets:
            return jsonify({"ok": False, "error": "Add or resume at least one active product first."})
        if not trackers:
            return jsonify({"ok": False, "error": "Add or resume at least one active tracker first."})
        try:
            recon.new_run()
        except Exception:
            pass
        stop_event = threading.Event()
        t1 = threading.Thread(target=ground_truth_poller.run,
                               args=(targets, GT_OUT, stop_event, log, report), daemon=True)
        t1.start()
        threads = [t1]
        if feed_trackers:
            t2 = threading.Thread(target=tracker_feed_poller.run,
                                   args=(feed_trackers, targets, ALERTS_OUT, stop_event, log, report), daemon=True)
            t2.start()
            threads.append(t2)
        if discord_trackers:
            t3 = threading.Thread(target=discord_source.run, args=(targets, ALERTS_OUT, stop_event, log, report), daemon=True, name="discord-in")
            t3.start()
            threads.append(t3)
        t4 = threading.Thread(target=tcg_index.run, args=(tcg_targets, stop_event, log, report, _targets_snapshot), daemon=True, name="tcg-index")
        t4.start()
        threads.append(t4)
        if push_trackers:
            mgr = push_listener.manager()
            mgr.configure(push_trackers, targets, ALERTS_OUT, log, report)
            mgr.set_recording(True)
            mgr.request("hide")
        STATE.update(running=True, stop_event=stop_event, threads=threads, started_at=time.time(), targets=targets)
        log(f"Started — watching {len(targets)} product(s) across {len(trackers)} tracker(s). Files: {file_versions()}")
    return jsonify({"ok": True})


@app.route("/api/phone-setup", methods=["GET", "POST"])
def api_phone_setup():
    """Phone alerts (free, via the ntfy app): POST makes a private topic name if there is none; GET only reports it."""
    topic = notify.make_topic() if request.method == "POST" else notify.phone_topic()
    return jsonify({"ok": True, "topic": topic})


@app.route("/api/phone-qr.svg")
def api_phone_qr():
    """QR code that makes the ntfy phone app subscribe to this PC's private topic (made here, nothing is sent anywhere)."""
    topic = notify.phone_topic()
    if not topic:
        return Response("no topic yet", status=404)
    import qrlite
    return Response(qrlite.svg("ntfy://ntfy.sh/" + topic, ec="M", scale=6), mimetype="image/svg+xml",
                    headers={"Cache-Control": "no-store"})


@app.route("/api/notify-test", methods=["POST"])
def api_notify_test():
    """Sends a test message by every way there is and reports what really happened on each (the page adds the browser one)."""
    return jsonify(notify.test_all("Restalker " + KIT_VERSION))


@app.route("/api/discord", methods=["GET", "POST"])
def api_discord():
    """The optional Discord channel (webhook) that gets the same messages as the phone."""
    if request.method == "POST":
        b = request.get_json(silent=True) or {}
        bad = notify.set_discord(b.get("webhook", ""))
        if bad:
            return jsonify({"ok": False, "msg": bad})
        return jsonify({"ok": True, "msg": "Saved. Press 'Send a test to Discord' to see it work." if notify.discord_webhook() else "Discord removed."})
    u = notify.discord_webhook()
    return jsonify({"ok": True, "set": bool(u), "tail": u[-6:] if u else ""})


@app.route("/api/discord-share", methods=["GET", "POST"])
def api_discord_share():
    """v99: what goes to the Discord channel - the restocks this program finds (shared with the other copies), and/or your own messages."""
    if request.method == "POST":
        b = request.get_json(silent=True) or {}
        if "share" in b:
            notify.set_flag(notify.SHARE_OFF_FILE, not b.get("share"))
        if "personal" in b:
            notify.set_flag(notify.PERSONAL_FILE, bool(b.get("personal")))
        log(f"[notify] Discord: restocks shared {'ON' if notify.share_on() else 'OFF'}, your purchases and problems there {'ON' if notify.personal_on() else 'OFF'} (set by you).")
    return jsonify({"ok": True, "share": notify.share_on(), "personal": notify.personal_on(), "name": notify.crowd_name(),
                    "shared": notify.status.get("crowd_shared", 0)})


@app.route("/api/discord-in", methods=["GET", "POST"])
def api_discord_in():
    """Discord as a SOURCE: the bot token of your own bot (read-only) that lets this program read your new server's channels."""
    if request.method == "POST":
        b = request.get_json(silent=True) or {}
        bad = discord_source.set_token(b.get("token", ""))
        if bad:
            return jsonify({"ok": False, "msg": bad})
        return jsonify({"ok": True, "msg": ("Saved. Press 'Check' to see what it can read. It starts reading the next time you press Start."
                                             if discord_source.configured() else "Removed.")})
    return jsonify(dict(discord_source.snapshot(), ok=True))


@app.route("/api/discord-in-check", methods=["POST"])
def api_discord_in_check():
    return jsonify(discord_source.check())


@app.route("/api/engine", methods=["GET", "POST"])
def api_engine():
    """Which browser the program's own store checks try first (Chrome / Camoufox / Firefox), what each extra browser is doing, and a one-press test.
    Camoufox and Firefox are separate copies the program installs."""
    if request.method == "POST":
        b = request.get_json(silent=True) or {}
        if "test" in b:
            name = str(b.get("test") or "").strip().lower()
            if name in browser_fetch.INSTALLS:
                browser_fetch.start_engine_test(name, log)
        else:
            v = str(b.get("first") or "").strip().lower()
            v = v if v in browser_fetch.INSTALLS else ""
            browser_fetch.set_first_engine(v)
            log(f"[info] 'Browser first' set to {v or 'Chrome (normal)'} by you (browsers that start from now on follow it).")
            if v:
                browser_fetch.start_engine_install(v, log)
    return jsonify(dict(browser_fetch.engine_report(), ok=True))


@app.route("/api/discord-test", methods=["POST"])
def api_discord_test():
    return jsonify(notify.test_discord("Restalker " + KIT_VERSION, "Test alert. You will get messages like this when a restock is logged."))


HELP_URL = "https://claude.ai/artifact/1weVZ4vkPQsKRD8JLC4d4B"     # v99: the guide and release notes (a document that changes without an update)
HELP_FILE = "help_link.txt"                                        # (another address put in this file is used instead)


def help_url():
    try:
        u = open(HELP_FILE, encoding="utf-8").read().strip()
        if re.match(r"^https://[^\s]{8,400}$", u):
            return u
    except Exception:
        pass
    return HELP_URL


@app.route("/api/help")
def api_help():
    return jsonify({"ok": True, "url": help_url()})


@app.route("/api/help-qr.svg")
def api_help_qr():
    """v99: QR code of the guide's address - a phone camera opens the guide (made here, nothing is sent anywhere)."""
    import qrlite
    return Response(qrlite.svg(help_url(), ec="M", scale=5), mimetype="image/svg+xml", headers={"Cache-Control": "no-store"})


@app.route("/api/export")
def api_export():
    """v99: a copy of Restalker to download - kind=new (for a new user: nothing of yours) or kind=move (for you on another PC: your data)."""
    import export
    kind = request.args.get("kind", "")
    if kind not in ("new", "move"):
        return Response("kind must be new or move", status=400)
    data, info = export.build(kind, products=request.args.get("products", "1") == "1", discord=request.args.get("discord") == "1")
    log(f"[export] a copy {'for a new user' if kind == 'new' else 'for your other PC'} was made: {info['files']} files, {info['bytes'] // 1024} KB"
        + ("" if kind == "move" else (" (with your product list)" if request.args.get("products", "1") == "1" else " (no product list)")))
    return Response(data, mimetype="application/zip", headers={"Content-Disposition": f'attachment; filename="{export.filename(kind)}"',
                                                               "Cache-Control": "no-store"})


@app.route("/api/restock-alerts", methods=["POST"])
def api_restock_alerts():
    """v96: restock / tracker-alert messages on or off (purchases and problems are always sent)."""
    on = bool((request.get_json(silent=True) or {}).get("on"))
    notify.set_restock_alerts(on)
    log(f"[notify] restock messages switched {'ON' if on else 'OFF (purchases and problems only)'} by you.")
    return jsonify({"ok": True, "on": notify.restock_alerts_on()})


@app.route("/api/popup-setting", methods=["POST"])
def api_popup_setting():
    on = bool((request.get_json(silent=True) or {}).get("on"))
    notify.set_popup(on)
    log(f"[notify] Windows pop-ups for real restocks switched {'ON' if on else 'OFF'} by you.")
    return jsonify({"ok": True, "on": notify.popup_enabled()})


@app.route("/api/stop", methods=["POST"])
def api_stop():
    """Stop = stop EVERYTHING that uses the PC: the watchers and every browser this program started.
    v90b (owner 2026-11-02: "I am still unable to download a copy of the diagnostics after stopping the program ... I needed to stop the
    Restalker quickly to avoid a crash, and now I want to know what went wrong"): the small page server stays up (a few MB, no browser),
    so the page still offers Download diagnostics; a copy is also saved to a file right away. "Close Restalker" ends the program."""
    # v90b (owner 2026-11-02: "the emergency stop and regular stop buttons do not work"): answers AT ONCE. Nothing here waits for a lock
    # another part may be holding; all the closing happens in the background, and every browser is ended by force after 25 s whatever hangs.
    ev = STATE.get("stop_event")
    if ev is not None:
        ev.set()
    STATE["running"] = False
    STATE["stopped_all"] = True
    try:
        amazon_buy._multi_hold(True, "Stop")
    except Exception:
        pass
    # v101: Stop is also the emergency stop - the buying browser ends THIS instant (in the background: the page never waits); nothing is
    # disarmed, so a Start brings everything back as it was
    threading.Thread(target=lambda: lifeline.run_limited(amazon_buy.halt_now, 8), daemon=True, name="halt-buyer").start()
    log("Stop pressed - buying stops this instant; closing the watchers and every browser this program started (the page stays open for the diagnostics)...")

    def work():
        got = STATE_LOCK.acquire(timeout=3)
        try:
            threads = list(STATE.get("threads") or [])
        finally:
            if got:
                STATE_LOCK.release()
        try:
            lifeline.run_limited(lambda: push_listener.manager().set_recording(False), 3)
        except Exception:
            pass
        _shutdown_everything(threads, False)
    threading.Thread(target=work, daemon=True, name="stop").start()
    threading.Timer(25.0, lambda: lifeline.run_limited(_kill_kit_processes, 8)).start()     # (whatever hangs: no browser is left after 25 s)
    return jsonify({"ok": True})


@app.route("/api/quit", methods=["POST"])
def api_quit():
    """v90b: closes the program itself (after Stop)."""
    ev = STATE.get("stop_event")
    if ev is not None:
        ev.set()
    STATE["running"] = False
    threads = list(STATE.get("threads") or [])
    log("Close Restalker pressed - the program closes.")
    if not os.environ.get("RK_TEST_NOEXIT"):
        lifeline.hard_deadline(12.0)                          # (v90b: gone within 12 s, whatever hangs)
    threading.Timer(0.5, _shutdown_everything, args=(threads, True)).start()
    return jsonify({"ok": True})


DIAG_SAVED = "restock-kit-diagnostics-saved.txt"


class _FileBuf:
    def __init__(self, path):
        self.path, self.tmp = path, path + ".tmp"
        self.f = open(self.tmp, "w", encoding="utf-8", errors="replace")

    def write(self, text):
        if text:
            self.f.write(str(text))

    def close(self):
        self.f.close()
        os.replace(self.tmp, self.path)


def save_diagnostics(why=""):
    """v90b: the diagnostics written to a file in the program's folder (at Stop, and every 2 hours) - there is always a recent copy, also
    after the program was closed or the PC crashed. Download it from the page ("last saved diagnostics") or open the file itself."""
    t0 = time.time()
    try:
        fb = _FileBuf(DIAG_SAVED)
        fb.write(f"(saved {why} at {datetime.now().strftime('%Y-%m-%d %H:%M:%S')})\n")
        try:
            _diag_build(fb)
        except Exception as e:
            fb.write(f"\n--- diagnostics could not be finished: {type(e).__name__}: {e} ---\n")
        fb.write(f"\n--- end of diagnostics (built in {time.time() - t0:.1f} s) ---\n")
        fb.close()
        log(f"[diagnostics] a copy was saved ({why}) to {os.path.abspath(DIAG_SAVED)}.")
        return True
    except Exception as e:
        log(f"[diagnostics] could not save a copy: {e}")
        return False


@app.route("/api/diagnostics-saved")
def api_diagnostics_saved():
    if not os.path.exists(DIAG_SAVED):
        return Response("No saved diagnostics yet (they are saved at Stop and every 2 hours).", mimetype="text/plain")
    return Response(open(DIAG_SAVED, encoding="utf-8", errors="replace").read(), mimetype="text/plain",
                    headers={"Content-Disposition": "attachment; filename=restock-kit-diagnostics-saved.txt", "Cache-Control": "no-store"})


def _diag_autosave():
    while True:
        time.sleep(2 * 3600)
        if STATE.get("stopped_all"):
            return
        save_diagnostics("automatically, every 2 hours")


def _kill_kit_processes():
    """Ends every browser/helper this program started (own children, plus any left over from an earlier run that carry the
    --rk-store= mark). Never touches the person's own Chrome."""
    try:
        import psutil
    except Exception:
        return
    me = psutil.Process()
    victims = []
    try:
        victims += me.children(recursive=True)
    except Exception:
        pass
    for p in psutil.process_iter(["pid", "cmdline"]):
        try:
            if p.pid != me.pid and any(str(x).startswith("--rk-store=") for x in (p.info.get("cmdline") or [])):
                victims.append(p)
                victims += p.children(recursive=True)
        except Exception:
            continue
    for v in victims:
        try:
            v.kill()
        except Exception:
            pass


def _shutdown_everything(threads, exit_program=True):
    """v62: every step has a time limit, and a hard limit ends the program within 15 s whatever hangs (the report: Stop left the
    program's browsers running in the background). v90b: exit_program=False (Stop) closes every browser but keeps the page server."""
    if exit_program and not os.environ.get("RK_TEST_NOEXIT"):
        lifeline.hard_deadline(15.0)
    deadline = time.time() + 5
    for t in threads:
        try:
            t.join(max(0.1, deadline - time.time()))
        except Exception:
            pass
    if os.environ.get("RK_TEST_NOEXIT") and exit_program:
        log("Everything is closed. Goodbye.")
        return
    lifeline.run_limited(push_listener.stop_browser, 4)
    lifeline.run_limited(amazon_buy.stop, 4)
    try:
        import multibuy
        lifeline.run_limited(multibuy.stop, 6)
    except Exception:
        pass
    lifeline.run_limited(_kill_kit_processes, 4)
    if not exit_program:
        log("Everything is stopped - every browser is closed. The page stays open: Download diagnostics, or Close Restalker.")
        threading.Thread(target=save_diagnostics, args=("when you pressed Stop",), daemon=True, name="diag-save").start()
        return
    log("Everything is closed. Goodbye.")
    if os.environ.get("RK_TEST_NOEXIT"):
        return
    lifeline.end_now(0)


_PAGE = {"last_poll": 0.0, "closed_at": 0.0}


def _page_watch():
    """v62: closing Restalker's page (the tab or the whole browser window) closes the program too - unless the page comes back within
    20 seconds (a reload, or another Restalker tab is still open)."""
    while True:
        time.sleep(2)
        c = _PAGE["closed_at"]
        if c and time.time() - c > 20 and _PAGE["last_poll"] < c + 1.0:
            _PAGE["closed_at"] = 0.0
            log("Restalker's page was closed - closing the watchers, every browser this program started, and the program itself...")
            with STATE_LOCK:
                threads = list(STATE.get("threads") or [])
                if STATE["stop_event"] is not None:
                    STATE["stop_event"].set()
                STATE["running"] = False
            _shutdown_everything(threads)
            return


@app.route("/msrp-how")
def msrp_how():
    """v63: how a 'calculated' MSRP is worked out, with the maker's own published price it comes from."""
    import html as _h
    key = request.args.get("key", "")
    m = msrp.for_row(key, {}) or {}
    theme, _, kind = key.partition("|")
    pk = msrp.for_row(f"{theme}|pack", {}) or {}
    n = msrp.PACKS_PER_BOX.get(kind or "box")
    title = _h.escape(theme.title() + " - " + (kind or "box").replace("_", " "))
    body = [f"<h2>{title}: MSRP ${m.get('value', 0):.2f}</h2>"]
    if m.get("how") == "calc" and pk and n:
        body.append(f"<p>Wizards of the Coast publishes the price of ONE pack: <b>${pk['value']:.2f}</b>. A box holds <b>{n}</b> packs.</p>"
                    f"<p style='font-size:20px'>{n} &times; ${pk['value']:.2f} = <b>${n * pk['value']:.2f}</b></p>")
    else:
        body.append(f"<p>{_h.escape(m.get('note') or '')}</p>")
    if m.get("source"):
        body.append(f"<p>Source of the pack price: <a href='{_h.escape(m['source'])}' target='_blank'>Wizards of the Coast - {_h.escape(m['source'])}</a> "
                    "(the prices are listed in that article).</p>")
    return ("<!doctype html><html><head><meta charset='utf-8'><title>MSRP - how it is worked out</title></head>"
            "<body style='font-family:Segoe UI,Arial,sans-serif;max-width:720px;margin:30px auto'>" + "".join(body) + "</body></html>")


@app.route("/api/page-closed", methods=["POST"])
def api_page_closed():
    _PAGE["closed_at"] = time.time()
    return jsonify({"ok": True})


_API_KEY_RE = re.compile(r"(apiKey|api_key|key)=([^&\s\"']+)", re.IGNORECASE)


def _redact_keys(text: str) -> str:
    """Some sources (e.g. the Best Buy API) require an API key embedded
    directly in the target URL. Diagnostics get shared outside this
    machine (e.g. for troubleshooting help) — strip key values so they
    never leave accidentally."""
    return _API_KEY_RE.sub(r"\1=***REDACTED***", text)


@app.route("/api/samples")
def api_samples():
    """A zip of the page copies in the 'samples' folder (for diagnosing misreads)."""
    import zipfile
    mem = io.BytesIO()
    with zipfile.ZipFile(mem, "w", zipfile.ZIP_DEFLATED) as z:
        if os.path.isdir(samples.DIR):
            for fn in sorted(os.listdir(samples.DIR)):
                z.write(os.path.join(samples.DIR, fn), fn)
        for extra in (GT_OUT, ALERTS_OUT):
            if os.path.exists(extra):
                z.write(extra, extra)
        z.writestr("README.txt", "Page copies saved by the restock kit. Send this zip along with the diagnostics.")
    return Response(mem.getvalue(), mimetype="application/zip",
                    headers={"Content-Disposition": "attachment; filename=restock-kit-samples.zip"})


class _StreamBuf:
    """v57: the diagnostics are sent while they are being written (the download starts at once and can never time out)."""
    def __init__(self):
        import queue
        self.q = queue.Queue()

    def write(self, text):
        if text:
            self.q.put(str(text))

    def close(self):
        self.q.put(None)


@app.route("/api/diagnostics")
def api_diagnostics():
    """v57: streamed - see _diag_build."""
    buf = _StreamBuf()

    def work():
        t0 = time.time()
        try:
            _diag_build(buf)
        except Exception as e:
            buf.write(f"\n--- diagnostics could not be finished: {type(e).__name__}: {e} ---\n")
        buf.write(f"\n--- end of diagnostics (built in {time.time() - t0:.1f} s) ---\n")
        buf.close()
    threading.Thread(target=work, daemon=True, name="diagnostics").start()

    def gen():
        while True:
            x = buf.q.get()
            if x is None:
                return
            yield x
    return Response(gen(), mimetype="text/plain",
                    headers={"Content-Disposition": "attachment; filename=restock-kit-diagnostics.txt", "Cache-Control": "no-store"})


def _diag_build(buf):
    """A single downloadable text file bundling everything useful for
    troubleshooting: current config, recent log history (persisted across
    restarts, not just this session), and data file sizes. API keys in
    any target URL are redacted before this ever touches disk-as-text or
    leaves the machine."""
    buf.write(f"Restalker {KIT_VERSION} — diagnostics\nGenerated: {datetime.now(timezone.utc).isoformat()}\n")
    buf.write(f"\n--- file versions (all must say {KIT_VERSION}) ---\n{file_versions()}\n")
    buf.write(f"\n--- CPU use of this program ---\n{cpu_monitor.summary()}\n")
    buf.write(f"\n--- where the program's own time goes (v62) ---\n{cpuprof.summary()}\n")
    buf.write(f"\n--- ending together (v62) ---\nbrowsers end with the program: {lifeline.status()}; clean-up helper running: "
              f"{bool(lifeline._JOB.get('reaper') and lifeline._JOB['reaper'].poll() is None)}\n")
    try:
        buf.write("\n--- AMAZON AUTO-BUY (Restalker's own buying browser) ---\n" + amazon_buy.diag_text())
    except Exception as e:
        buf.write(f"\n--- AMAZON AUTO-BUY LINK: could not be read: {e} ---\n")
    try:
        buf.write(f"\n--- RECORDINGS: what each store's pages really send (see recon folder) ---\n{_redact_keys(recon.report())}\n")
    except Exception as e:
        buf.write(f"\n--- RECORDINGS: could not be read: {e} ---\n")
    try:
        buf.write("\n--- ALERT LISTENER (TrackaLacker / HotStock browser-push alerts) ---\n")
        _sn = push_listener.manager().snapshot()
        for _id, _s in (_sn.get("trackers") or {}).items():
            _ev = _s.get("signup_evidence") or {}
            if _ev:
                buf.write(f"  {_id} last sign-up try saw: page={_ev.get('url')}; steps={_ev.get('steps')}; buttons={_ev.get('clickables')}; page text={_ev.get('words')!r}; "
                          f"permission {_ev.get('perm_before')}->{_ev.get('perm_after')}; console={_ev.get('console')}; requests={_ev.get('requests')}\n")
            buf.write(f"  {_id}: notifications={_s.get('permission')}; alert sign-ups found={_s.get('push_subscriptions')}; service workers={_s.get('service_workers')}; "
                      f"page kept open={_s.get('tab_open')}; alerts received={_s.get('alerts_seen')}; last alert={_s.get('last_alert_at')}; probe error={_s.get('probe_error')}\n")
        buf.write(json.dumps(_sn, indent=1, default=str)[:6000] + "\n")
        if os.path.exists(push_listener.EVENTS_CSV):
            with open(push_listener.EVENTS_CSV, encoding="utf-8", errors="replace") as f:
                rows = f.readlines()
            buf.write("push_events.csv (every alert that arrived; last 60):\n" + "".join(rows[:1] + rows[-60:] if len(rows) > 61 else rows))
        else:
            buf.write("push_events.csv: no alert has arrived yet.\n")
    except Exception as e:
        buf.write(f"(alert listener section failed: {e})\n")
    try:
        _txt, _ = audit.report(ALERTS_OUT, GT_OUT, "debug.log")
        buf.write("\n--- tracker alerts vs the program's own restocks (who was first; alerts the program did not match) ---\n" + _txt + "\n")
    except Exception as e:
        buf.write(f"(audit section failed: {e})\n")
    try:
        buf.write("\n--- how much earlier the trackers know, per store (v112: the whole record, not only 48 h) ---\n"
                  + audit.lead_by_store(ALERTS_OUT, GT_OUT) + "\n")
    except Exception as e:
        buf.write(f"(lead section failed: {e})\n")
    try:
        _nt, _ = audit.notify_report(ALERTS_OUT, notify.NOTIFY_CSV, push_listener.EVENTS_CSV)
        buf.write("\n--- messages sent to you vs tracker alerts (does every counted alert have its message? alerts that were not counted, and why) ---\n" + _nt + "\n")
        _lastm = ""
        if os.path.exists(notify.NOTIFY_CSV):
            with open(notify.NOTIFY_CSV, encoding="utf-8", errors="replace") as f:
                _rows = f.readlines()
            _lastm = "notifications.csv (last 25 messages):\n" + "".join(_rows[:1] + _rows[-25:] if len(_rows) > 26 else _rows)
        buf.write(_lastm + ("\n" if _lastm else ""))
        buf.write(f"restock messages: {'ON' if notify.restock_alerts_on() else 'OFF (purchases and problems only - v96)'}; messages with buttons sent "
                  f"{notify.status.get('buttons_sent', 0)}, sent without them because ntfy refused the buttons {notify.status.get('buttons_failed', 0)}"
                  + (f" ({notify.status.get('buttons_error')})" if notify.status.get('buttons_error') else "") + "\n" + phone_actions.report_text() + "\n"
                  + f"Discord channel (v99): {'set' if notify.discord_webhook() else 'not set'}; this copy posts as '{notify.crowd_name()}'; restocks shared "
                  f"{'ON' if notify.share_on() else 'OFF'} ({notify.status.get('crowd_shared', 0)} shared, {notify.status.get('crowd_skipped', 0)} left out because "
                  f"another copy had just shared them, {notify.status.get('crowd_failed', 0)} refused" + (f": {notify.status.get('crowd_error')}" if notify.status.get('crowd_error') else "")
                  + f"); your purchases and problems there {'ON' if notify.personal_on() else 'OFF'}\n")
    except Exception as e:
        buf.write(f"(messages section failed: {e})\n")
    try:
        _pl = amazon_buy.purchases_list(1000)
        buf.write(f"\n--- purchases (v97: purchases.csv, kept for good) ---\n{len(_pl)} purchases, ${sum((x.get('price') or 0) for x in _pl):,.2f} in all (item prices)\n" +
                  "".join(f"  {datetime.fromtimestamp(x['t'], timezone.utc).strftime('%m-%d %H:%M')} UTC {x['store']}: {x['product']} "
                          f"{('$%.2f' % x['price']) if x.get('price') is not None else ''} order {x.get('order') or '-'} by {x.get('by') or '-'}\n" for x in _pl[:15]))
    except Exception as e:
        buf.write(f"(purchases section failed: {e})\n")
    try:
        buf.write(amazon_buy.orders_text() + "\n")
    except Exception as e:
        buf.write(f"(order list section failed: {e})\n")
    try:
        import multibuy
        buf.write("\n--- other BUYING browsers (v76: Chrome / Edge / Hidden Chrome / Firefox / Camoufox check out at the same moment as the buying browser) ---\n" + multibuy.report() + "\n")
    except Exception as e:
        buf.write(f"(other buying browsers section failed: {e})\n")
    try:
        _er = browser_fetch.engine_report()
        buf.write("\n--- extra browsers for the store checks (Camoufox, Firefox, Hidden Chrome) ---\nbrowser tried first: " + (browser_fetch.first_engine() or "Chrome (normal)") + "\n" +
                  "".join(f"{k}: {v['state']} {v['detail']} | started {v['launches']}x, start failures {v['launch_fail']}, pages read {v['pages_ok']}/{v['pages']}"
                          + (f", last error: {v['last_error']}" if v.get("last_error") else "") + "\n" for k, v in _er["engines"].items()) +
                  "browser doing each store's checks (reads OK / failed):\n" +
                  "".join(f"  {k}: {v['engine']} ({v['ok']} OK, {v['fail']} failed" + (f", last error: {v['last_error']}" if v.get("last_error") else "") + ")\n" for k, v in _er["stores"].items()) +
                  "".join(f"  other browser {k}: pages read {v['pages_ok']}/{v['pages']}\n" for k, v in _er["used"].items()) +
                  "".join(f"test of {k}: {v['state']} - {v['detail']}\n" for k, v in _er["tests"].items()))
    except Exception as e:
        buf.write(f"(firefox section failed: {e})\n")
    try:
        buf.write("\n--- tracker alerts vs. what our readers saw right after (v105; the pages are kept in alert_pages/) ---\n" + steady.capture_text() + "\n")
        buf.write("\n--- each moment WE saw a product buyable: what every browser saw around it (v112; does any browser see restocks later or never?) ---\n"
                  + steady.own_capture_text() + "\n")
        buf.write("\n--- what the kept Amazon pages show: who sells it, at what price (v107) ---\n" + page_facts.report(ALERT_PAGES) + "\n")
        import tracker_feed_poller as _tfp
        buf.write("\n--- which Amazon listing each tracker watches vs. the one we watch (v107) ---\n" + _tfp.links_report() + "\n")
        buf.write("\n--- product squares vs. their readings (v101: which browser said what, last 2 hours) ---\n" +
                  steady.report_text({t.get("id"): t.get("id") for t in _targets_snapshot()}) + "\n")
    except Exception as e:
        buf.write(f"(squares section failed: {e})\n")
    try:
        import sweep as _sw
        buf.write("\n--- store sweepers (v64): one light reader per store through the buying browser ---\n" + _sw.report_text() + "\n")
        try:
            buf.write(_sw.aod_text(audit._read_csv(GT_OUT)[-4000:]) + "\n")
            if os.path.exists(_sw.OFFERS_CSV):
                with open(_sw.OFFERS_CSV, encoding="utf-8", errors="replace") as f:
                    _ol = f.readlines()
                buf.write("amazon_offers.csv (last 40 rows):\n" + "".join(_ol[:1] + _ol[-40:] if len(_ol) > 41 else _ol))
        except Exception as e:
            buf.write(f"(offers list lines failed: {e})\n")
    except Exception as e:
        buf.write(f"(sweeper section failed: {e})\n")
    try:
        buf.write("\n--- speed vs. PC load (v51) ---\n" + loadplan.text() + "\n")
        buf.write("\n--- memory housekeeping (v52) ---\n" + hygiene.text() + "\n")
        _sr = ground_truth_poller.speed_report()
        for _k, _v in _sr.items():
            buf.write(f"  {_k}: {_v['products']} products, {_v['readers']} readers; a product is looked at every "
                      f"{('%.1f s' % _v['avg_gap']) if _v['avg_gap'] is not None else 'not measured'} on average (slowest {('%.1f s' % _v['worst_gap']) if _v['worst_gap'] is not None else '-'}); "
                      f"a restock is noticed after about {('%.1f s' % _v['delay']) if _v['delay'] is not None else '-'} (a look takes {_v['read_s']:.1f} s)\n")
            _f = lambda x: ('%.1f s' % x) if isinstance(x, (int, float)) else '-'
            buf.write(f"     one reader's round per product (v62): {_f(_v.get('round_s'))} = before the look {_f(_v.get('pre_s'))} + the look itself "
                      f"{_f(_v.get('fetch_s'))} + after it (judging, saving) the rest\n")
        buf.write("measured on real restocks: " + audit.window_text(audit.window_stats(GT_OUT)) + "\n")
        buf.write("blocked products (v52): " + ground_truth_poller.blocked_text() + "\n")
        _so = ground_truth_poller.speed_overall(_sr)
        buf.write(f"all stores together: a restock is noticed after about {('%.1f s' % _so) if _so is not None else 'not measured yet'} on average by our own readers (goal: 1 s; trackers and Discord fill in when a store does not answer)\n")
    except Exception as e:
        buf.write(f"(speed section failed: {e})\n")
    try:
        buf.write("\n--- readers working at the same time (v44) ---\n")
        _tb = ground_truth_poller._TB
        buf.write(f"Target all-products request: {'WORKING' if hotness.is_cheap('target') else 'not working / not used'}; products known {len(_tb['tcins'])}; "
                  f"answers received {_tb['n_ok']}; failures in a row {_tb['fails']}; last reason: {_tb.get('why') or '-'}; resting until {('%.0f s from now' % (_tb['off_until'] - time.time())) if _tb['off_until'] > time.time() else 'no'}\n")
        for _store, _d in ground_truth_poller.lane_report().items():
            _bits = []
            for _ln, _ld in sorted(_d["lanes"].items()):
                _age = (time.time() - _ld["beat"]) if _ld.get("beat") else None
                _bits.append(f"reader {_ln + 1}: {_ld.get('state') or '-'}, {_ld.get('reads', 0)} reads, last moved {('%.0f s ago' % _age) if _age is not None else '-'}")
            buf.write(f"  readers at {_store} (all read at the same time; planned {_d['want']}): " + "; ".join(_bits) + f"; products asked for together with another in one request: {_d.get('batched', 0)}\n")
        for _store, _lst in ground_truth_poller.scout_report().items():
            for _sc in _lst:
                buf.write(f"  scout {_store}/{_sc['label']}: {_sc['state']}; reads {_sc['reads']}, errors {_sc['errors']}, human-check pages {_sc['blocks']}, "
                          f"stock sightings {_sc['sightings']}; last read {_sc['last_read_s_ago']} s ago; last problem: {_sc['last_why']}\n")
        if not ground_truth_poller.scout_report():
            buf.write("  (no scouts - the store's own extra readers above replace them)\n")
        for _store, _mem in ground_truth_poller.pool_report().items():
            for _m in _mem:
                buf.write(f"  main-checker browser {_store}/{_m['label']}: {'IN USE' if _m['current'] else ('ready' if _m['ready'] else 'resting %ss' % _m['rests_for'])}; "
                          f"ok {_m['ok']}, failed {_m['fail']}; last problem: {_m['last_why']}\n")
    except Exception as e:
        buf.write(f"(readers section failed: {e})\n")
    try:
        _ds = discord_source.snapshot()
        buf.write("\n--- Discord server as a source (v45) ---\n")
        buf.write(f"bot token saved: {'yes' if _ds['set'] else 'no (optional)'}; running: {_ds['running']}; status: {_ds['note']}; message-content setting: "
                  f"{'on' if _ds.get('intent') else ('OFF' if _ds.get('intent') is False else 'not checked')}\n")
        buf.write(f"channels read: {', '.join(_ds['channels']) or '(none)'}\n")
        buf.write(f"messages looked at {_ds['seen']}, counted as alerts {_ds['counted']}, empty in a row {_ds['empty_streak']}\n")
        for _r in _ds["recent"]:
            buf.write(f"  {_r['at']} UTC #{_r['channel']}: {_r['words'] or '(empty)'}  -> {_r['outcome']}\n")
    except Exception as e:
        buf.write(f"(discord section failed: {e})\n")
    try:
        buf.write("\n--- link check (is each link really its row's product?) ---\n" + linkcheck.summary() + "\n")
    except Exception as e:
        buf.write(f"(link check section failed: {e})\n")
    try:
        buf.write("\n--- TCG price index ---\n" + tcg_index.summary_text() + "\n")
    except Exception as e:
        buf.write(f"(TCG section failed: {e})\n")
    try:
        buf.write("\n--- product pictures ---\n" + thumbs.summary(_targets_snapshot()) + "\n")
    except Exception as e:
        buf.write(f"(pictures section failed: {e})\n")
    buf.write(f"\n--- targets.yaml ---\n{_redact_keys(open(TARGETS_PATH, encoding='utf-8', errors='replace').read()) if os.path.exists(TARGETS_PATH) else '(missing)'}\n")
    try:
        _cfg = load(TARGETS_PATH, "targets")["targets"]
        _by = {}
        for _t in _cfg:
            if _t.get("active", True):
                _k = (retailer_of(_t), "extra" if products.is_extra(_t) else "core")
                _by[_k] = _by.get(_k, 0) + 1
        _gf, _ga = hotness.governor()
        _gp = hotness._gov.get("pc")
        buf.write("\n--- products ---\nactive products by store: " + ", ".join(f"{a}:{b}={n}" for (a, b), n in sorted(_by.items())) +
                  f"\nreading is slowed by: nothing except Gaming mode (now x{_gf:g}). CPU load does NOT slow anything (v50). For information only: program average {_ga:.0f}% of one core, last 5 min; whole PC busy "
                  f"{('%.0f%%' % _gp) if _gp is not None else 'not measured'}, of which other programs {('%.0f%%' % hotness._gov['pc_other']) if hotness._gov.get('pc_other') is not None else 'not measured'}; Gaming mode {'ON' if hotness.gaming() else 'off'}).\n"
                  f"Gaming mode setting: {hotness.mode().upper()}; in effect: {'ON' if hotness.gaming() else 'off'}; automatic detection: "
                  f"{'game seen - ' + hotness.auto_reason() if hotness._game['auto'] else 'no game seen'} (checks made: {gamedetect.state()['checks']}).\n"
                  f"the only protection left (v50): when the whole PC has under {hotness.MEM_CRIT_GB:g} GB of free memory the EXTRA readers of each store rest (back at {hotness.MEM_RESUME_GB:g} GB); "
                  f"free memory now: {('%.1f GB' % hotness._gov['free_gb']) if hotness._gov.get('free_gb') is not None else 'not measured'}; extra readers resting for memory: {'YES' if hotness._shed['on'] else 'no'}.\n"
                  f"browser priority: {cpu_monitor.priority_text()}\n"
                  f"new_products.yaml: {'found' if os.path.exists(NEW_PRODUCTS_PATH) else 'missing'}; ids already added: {len(products.read_ids(MERGED_PATH))}\n")
    except Exception as e:
        buf.write(f"(products section failed: {e})\n")
    try:
        with CONFIG_LOCK:
            _m = matrix.build(load(TARGETS_PATH, "targets")["targets"])
        with STATUS_LOCK:
            _st = {k: dict(v) for k, v in STATUS["targets"].items()}
        with matrix.LOCK:
            _off = {k: sorted(v) for k, v in matrix.UI.items() if k in ("products_off", "stores_off", "cells_off")}
        buf.write(f"\n--- table (products x stores) ---\nswitches that are OFF: {_off}\n")
        for _p in _m["products"]:
            _cells = []
            for _s in _m["stores"]:
                _c0 = _p["cells"].get(_s["key"])
                if not _c0:
                    continue
                for _n, _c in enumerate([_c0] + (_c0.get("more") or [])):       # v109: every link of the cell (2nd, 3rd page: key+2, key+3)
                    _x = _st.get(_c["id"], {})
                    _on = _p["on"] and _s["on"] and _c["cell_on"]
                    _cells.append(f"{_s['key']}{'' if not _n else '+' + str(_n + 1)}={'ON' if _on else 'off'}/{_x.get('status', '-')}" + (f"/${_x['price']}" if _x.get("price") else "") + (f"/found-by-{_c.get('found_by') or 'search'}" if _c.get("found") else "") + (f"/human-check[{_x.get('block_why')}; browser {_x.get('browser')}; {_x.get('blocked_times')} times]" if _x.get("status") == "BLOCKED" else ""))
            _mi = _p.get("msrp")
            buf.write(f"{_p['title']} | {_p['label']} | kind {_p['kind']} | cap {_p['cap']} | MSRP " + (f"{_mi['value']} ({_mi['how']})" if _mi else "unknown") + " | " + ", ".join(_cells) + "\n")
        buf.write("\n--- prices seen vs MSRP (to set the price caps from real numbers) ---\n")
        buf.write(msrp.report_text([{"title": _p["title"], "label": _p["label"], "cap": _p["cap"], "msrp": _p.get("msrp"),
                                     "ids": [x["id"] for c in _p["cells"].values() if c for x in [c] + (c.get("more") or [])]} for _p in _m["products"]]) + "\n")
        buf.write("\n--- finding a product at the other stores ---\n" + finder.summary() + "\n"
                  + "rows already searched: " + json.dumps(matrix.UI.get("searched", {}))[:1500] + "\n")
    except Exception as e:
        buf.write(f"(table section failed: {e})\n")
    buf.write(f"\n--- trackers.yaml ---\n{_redact_keys(open(TRACKERS_PATH, encoding='utf-8', errors='replace').read()) if os.path.exists(TRACKERS_PATH) else '(missing)'}\n")
    buf.write(f"\n--- row counts ---\nground_truth.csv: {count_rows(GT_OUT)} restock event(s)\n"
              f"alerts.csv: {count_rows(ALERTS_OUT)} tracker mention(s)\n")
    for _p in (GT_OUT, ALERTS_OUT):
        if os.path.exists(_p + ".pending"):
            buf.write(f"WARNING: {_p}.pending exists - rows are waiting because {_p} could not be written to "
                      f"(is it open in Excel?). They are added automatically once it is closed.\n")
    with STATUS_LOCK:
        buf.write(f"\n--- live status snapshot ---\ntargets: {STATUS['targets']}\ntrackers: {STATUS['trackers']}\n")
    for title, path in (("ground_truth.csv (last 60 rows)", GT_OUT), ("alerts.csv (last 60 rows)", ALERTS_OUT)):
        buf.write(f"\n--- {title} ---\n")
        try:
            with open(path, encoding="utf-8", errors="replace") as f:
                rows = f.readlines()
            buf.write("".join(rows[:1] + rows[-60:] if len(rows) > 61 else rows))
        except Exception:
            buf.write("(none yet)\n")
    buf.write("\n--- key events from the whole log (starts, first reads, flips, blocks, restocks, mentions) ---\n")
    if os.path.exists(DEBUG_LOG_PATH):
        lines = []
        for _p in (DEBUG_LOG_PATH + ".1", DEBUG_LOG_PATH):
            if os.path.exists(_p):
                with open(_p, encoding="utf-8", errors="replace") as f:
                    lines += f.readlines()
        keys = ("[version]", "[pace]", "[notify]", "[watchdog]", "[evidence]", "RESTOCK DETECTED", "NEW MENTION", "[block]", "reading stock OK",
                "[error]", "[push]", "[search]", "[pictures]", "auto-upgraded", "[price", "Best Buy", "[diagnostic]", "[light]", "[stats]", "[info]", "[warn]")
        must = ("[version]", "[watchdog]", "[diagnostic]", "RESTOCK DETECTED", "NEW MENTION")
        key_lines = [l for l in lines if any(k in l for k in keys)]
        first_lines = [l for l in key_lines if any(k in l for k in must)]
        other_lines = [l for l in key_lines if not any(k in l for k in must)]
        buf.write("(A) every version / diagnostic / restock / mention line:\n")
        buf.write(_redact_keys("".join(l[:900] if len(l) > 900 else l for l in first_lines[-400:])))
        buf.write("\n(B) the latest 300 other key lines:\n")
        buf.write(_redact_keys("".join(l[:600] if len(l) > 600 else l for l in other_lines[-300:])))
        buf.write("\n--- recent log (last 500 lines from debug.log) ---\n")
        buf.write(_redact_keys("".join(lines[-500:])))
    else:
        buf.write("(no debug.log yet — nothing has run in this folder)\n")
    return None


STATUS_MEMORY = "last_readings.json"


def _status_memory_start():
    """v59b: the last real answer of every link is kept on disk (once a minute) and shown at once after a start ('last answer 3 min ago')
    while the readers get their first fresh look - no square starts empty."""
    try:
        with open(STATUS_MEMORY, encoding="utf-8") as f:
            saved = json.load(f)
        with STATUS_LOCK:
            for tid, lg in (saved or {}).items():
                if isinstance(lg, dict) and lg.get("status") in ("IN_STOCK", "OUT_OF_STOCK"):
                    STATUS.setdefault("targets", {}).setdefault(tid, {}).setdefault("last_good", lg)
    except Exception:
        pass

    def keep():
        while True:
            time.sleep(60)
            try:
                with STATUS_LOCK:
                    d = {tid: e["last_good"] for tid, e in STATUS.get("targets", {}).items() if isinstance(e.get("last_good"), dict)}
                tmp = STATUS_MEMORY + ".tmp"
                with open(tmp, "w", encoding="utf-8") as f:
                    json.dump(d, f)
                os.replace(tmp, STATUS_MEMORY)
            except Exception:
                pass
    threading.Thread(target=keep, daemon=True, name="status-memory").start()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--targets", default="targets.yaml")
    ap.add_argument("--trackers", default="trackers.yaml")
    ap.add_argument("--port", type=int, default=8001)
    args = ap.parse_args()

    global TARGETS_PATH, TRACKERS_PATH
    TARGETS_PATH = args.targets
    TRACKERS_PATH = args.trackers

    lifeline.start_reaper(os.path.dirname(os.path.abspath(__file__)))   # v62: a helper that ends the program's browsers when the program ends
    lifeline.bind_children_to_me()       # v62 (Windows): every browser / helper the program starts ends with it - also when its window is closed
    def _close_left():                   # v115: the command windows updates left open are closed (a minute after start: this one's too)
        _n = lifeline.close_leftover_windows(os.path.dirname(os.path.abspath(__file__)))
        if _n and _n > 0:
            print(f"[start] closed {_n} command window(s) left open by updates")
        # v117: after a Windows restart, Restalker's browsers Windows reopens are closed until Restalker is started (switch: Browsers tab)
        _b = lifeline.boot_cleanup_set(os.path.dirname(os.path.abspath(__file__)))
        if _b is None and os.name == "nt":
            print("[start] the after-restart helper could not be put in Windows' sign-in list")
    _tl = threading.Timer(60.0, lambda: lifeline.run_limited(_close_left, 20))
    _tl.daemon = True
    _tl.start()
    http_utils.lower_priority()          # keep the PC responsive: below-normal priority (browsers inherit it)
    try:                                 # the black console window also shows the version
        import ctypes
        ctypes.windll.kernel32.SetConsoleTitleW(f"Restalker {KIT_VERSION}")
    except Exception:
        pass
    print(f"Restalker {KIT_VERSION}")
    try:                                 # the black window shows only problems (the page and debug.log hold everything else)
        import logging
        logging.getLogger("werkzeug").setLevel(logging.ERROR)
    except Exception:
        pass
    ensure_push_trackers()               # TrackaLacker and HotStock (alert trackers) are always listed
    ensure_new_products()                # newly supported products are added to the list (once each)
    matrix.load_ui()                     # the table's switches
    ensure_row_kinds()                   # rows you added with an older version get their own category
    ensure_foundations_box()             # v65: Foundations = the Collector Booster BOX (once)
    hotness.set_mode(matrix.UI.get("gaming_mode", "auto"))
    loadplan.set_profile(matrix.UI.get("load_profile", "balanced"))
    gamedetect.start(_on_game_change, log)      # notices a game by itself (Gaming mode "auto")
    ensure_unified_caps()                # one price cap per product (once)
    focus_guard.start()                  # hidden program browsers never take your keyboard focus (Windows)
    amazon_buy.start(log, _describe_target, _targets_snapshot,          # v54: Restalker buys on Amazon by itself (its own buying browser); v56: and on Best Buy
                     lambda t, m, k, pop=False, meta=None, actions=None: notify.send(t, m, key=k, force=True, popup=(notify._popup if pop else None),
                                                                                    meta=meta, actions=actions),   # v57: purchases also pop up on the PC
                     status_fn=_verify_target)
    threading.Thread(target=_stall_watch, daemon=True, name="stall-watch").start()
    threading.Thread(target=_tracker_links_watch, daemon=True, name="tracker-links").start()     # v100
    # v96: the buttons on purchase / problem messages (the phone answers; the PC listens on its own private name - see phone_actions.py)
    try:
        updater.LOG, updater.BUSY, updater.SHUTDOWN = log, _update_busy, _update_shutdown
        updater.start()
    except Exception as e:
        log(f"[update] the update check could not start: {e}")
    phone_actions.start(log, amazon_buy.phone_do,
                        lambda t, m, actions=None: notify.send(t, m, force=True, actions=actions,
                                                               meta={"kind": "phone answer", "source": "phone button", "target": "", "price": None}),
                        lambda: bool(notify.phone_topic()))
    hygiene.start(log)                   # v52: memory housekeeping for runs of weeks and months
    _status_memory_start()               # v59b: every square shows its last real answer right after a start
    cpu_monitor.start(log)               # measures this program's CPU use, shown in the diagnostics
    browser_fetch.set_logger(log)
    browser_fetch.start_engine_install("camoufox", log)      # the free stealth browser: installed once in the background (the program keeps working meanwhile)
    browser_fetch.start_engine_install("firefox", log)      # v39: ordinary Firefox too - one more browser for the automatic switching (the program keeps working meanwhile)
    browser_fetch.start_engine_install("stealth", log)      # v76: Hidden Chrome's small add-on (patchright) - it then reads, searches and buys too
    cpuprof.start()
    thumbs.start(lambda: _targets_snapshot(), log)       # the product pictures shown in the table
    url = f"http://localhost:{args.port}"
    _open_page_once(url, updater.restarted_for_update())

    def _auto_start():
        # v61: watching starts by itself when the program opens (diagnostics 58: after a restart nothing was read until Start was pressed)
        try:
            with app.test_request_context():
                r = api_start()
            d = r.get_json() if hasattr(r, "get_json") else {}
            if not (d or {}).get("ok"):
                log(f"[info] watching did not start by itself: {(d or {}).get('error')}")
        except Exception as e:
            log(f"[warn] watching did not start by itself: {e}")
    threading.Timer(4.0, _auto_start).start()
    threading.Thread(target=_page_watch, daemon=True, name="page-watch").start()
    threading.Thread(target=_diag_autosave, daemon=True, name="diag-autosave").start()      # v90b: a saved copy every 2 hours
    print(f"Opening {url} in your browser...")
    app.run(host="127.0.0.1", port=args.port)


if __name__ == "__main__":
    main()
