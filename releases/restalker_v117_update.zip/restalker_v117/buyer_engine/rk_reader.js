/* Restalker v58 - reading store pages through the buying browser (read only).
 * Some stores refuse the program's watching browsers (diagnostics 57: Best Buy answered 0 of 93 tries, GameStop often sends nothing).
 * The buying browser is an ordinary browser window that you signed in to, so the store answers it. For such a store this keeps ONE
 * quiet background tab open on the store's own site and asks that tab to fetch a product page or the store's small data request -
 * the same request the store's own page makes. Nothing is clicked or typed; human checks are never answered.
 */
'use strict';
(() => {
  const tabs = {};                       // origin -> {id, at}
  const MAX_AGE = 30 * 60 * 1000;        // the reader tab is opened fresh every 30 minutes
  const stats = {ok: 0, failed: 0, last: null};
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  async function waitComplete(id, ms) {
    const t0 = Date.now();
    while (Date.now() - t0 < ms) {
      try { const t = await chrome.tabs.get(id); if (t.status === 'complete') return true; } catch { return false; }
      await sleep(250);
    }
    return false;
  }
  async function inject(id) {            // v64: the helper is put into the tab directly too (a tab opened before the engine started, or a store page whose own helper answers first)
    try { await chrome.scripting.executeScript({target: {tabId: id}, files: ['rk_fetch.js']}); return true; } catch { return false; }
  }
  async function ensure(origin) {
    const e = tabs[origin];
    if (e) {
      let alive = false;
      try { alive = !!(await chrome.tabs.get(e.id)); } catch {}
      if (alive && Date.now() - e.at < MAX_AGE) { await waitComplete(e.id, 30000); return e.id; }
      try { if (alive) await chrome.tabs.remove(e.id); } catch {}
      delete tabs[origin];
    }
    const t = await chrome.tabs.create({url: origin + '/', active: false});
    tabs[origin] = {id: t.id, at: Date.now()};
    await waitComplete(t.id, 45000);
    await sleep(600);                    // (the store's page settles; its content script is ready)
    await inject(t.id);
    return t.id;
  }
  async function fetchUrl(url, timeoutMs, cookies) {
    timeoutMs = Math.max(3000, Math.min(60000, Number(timeoutMs) || 25000));
    const t0 = Date.now();
    let origin;
    try { const h = new URL(url).hostname; origin = 'https://www.' + h.split('.').slice(-2).join('.'); } catch { return {ok: false, reason: 'not a web address'}; }   // (one tab per store: its main site)
    let id;
    try { id = await ensure(origin); } catch (e) { stats.failed++; return {ok: false, reason: 'reader tab: ' + String(e && e.message || e)}; }
    try { globalThis.RK_JANITOR && globalThis.RK_JANITOR.seen.set(id, Date.now()); } catch {}     // (v90: in use - the tab janitor leaves it)
    let r;
    for (let i = 0; i < 2; i++) {
      r = await Promise.race([
        chrome.tabs.sendMessage(id, {type: 'RK_FETCH', url, timeoutMs, cookies: cookies || null}).catch(e => ({ok: false, reason: String(e && e.message || e), noScript: true})),
        sleep(timeoutMs + 3000).then(() => ({ok: false, reason: 'no answer in time'}))]);
      if (r && r.noScript && i === 0) { await inject(id); await sleep(500); continue; }       // the page was still loading its helper: put it in, once more
      break;
    }
    if (!r || (r.noScript)) { try { await chrome.tabs.remove(id); } catch {} delete tabs[origin]; }
    if (r && r.ok) stats.ok++; else stats.failed++;
    stats.last = {url: url.slice(0, 120), ok: !!(r && r.ok), status: r && r.status, reason: r && r.reason, at: Date.now()};
    return {...(r || {ok: false, reason: 'no answer'}), ms: Date.now() - t0};
  }
  function status() {
    return {tabs: Object.fromEntries(Object.entries(tabs).map(([o, e]) => [o, {tab: e.id, ageSec: Math.round((Date.now() - e.at) / 1000)}])), ...stats};
  }
  globalThis.RestalkerReader = {CODE: 'v117', fetch: fetchUrl, status};
})();
