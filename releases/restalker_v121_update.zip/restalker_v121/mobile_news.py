"""Restalker Mobile (the Android app) news on your phone (v121).

Owner 2026-11-16: "when it's ready, you can send me an ntfy notification with the link to download the app".
The app's newest tested version is announced in the release home's mobile/latest.json (written only after the app passed all its tests).
Restalker reads that small file 2 minutes after it starts and then once an hour; when it names a version this Restalker has not told you
about yet, ONE phone message is sent through your own Restalker channel (tap it to download the app). It is told once per version
(mobile_told.txt); nothing is downloaded or installed on the PC.
"""
import json
import os
import threading
import time
import urllib.request

VERSION = "v121"
URL = "https://raw.githubusercontent.com/stevenmanuel01-cloud/Restalker/main/mobile/latest.json"
TOLD_FILE = "mobile_told.txt"
FIRST_WAIT = 120
EVERY = 3600
_st = {"started": False, "last": "", "told": 0, "error": ""}
LOG = None


def told():
    try:
        return int(open(TOLD_FILE, encoding="utf-8").read().strip() or 0)
    except Exception:
        return 0


def _fetch():
    req = urllib.request.Request(URL + "?t=%d" % int(time.time()), headers={"User-Agent": "Restalker/" + VERSION, "Cache-Control": "no-cache"})
    with urllib.request.urlopen(req, timeout=20) as r:
        return json.loads(r.read().decode("utf-8"))


def check(fetch=None, send=None, now=None):
    """Reads the app's latest.json; tells the phone once about a version not told yet. Returns the version told, or ''."""
    try:
        d = (fetch or _fetch)()
        code = int(d.get("code") or 0)
        ver = str(d.get("version") or "")[:12]
        apk = str(d.get("apk") or "")
        if not (code > 0 and ver and apk.startswith("https://github.com/stevenmanuel01-cloud/Restalker/releases/download/")):
            _st["error"] = "the app's latest.json is not complete"
            return ""
        _st["last"] = ver
        _st["error"] = ""
        if code <= told():
            return ""
        if send is None:
            import notify
            send = notify.send
        send("Restalker Mobile v%s is ready" % ver,
             "The phone app passed all its tests. Tap this message on your Android phone to download it, then open the file to install.",
             key=None, link=apk)
        with open(TOLD_FILE, "w", encoding="utf-8") as f:
            f.write(str(code))
        _st["told"] = code
        if LOG:
            LOG(f"[mobile] Restalker Mobile v{ver} announced on your phone (download link).")
        return ver
    except Exception as e:
        _st["error"] = str(e)[:120]
        return ""


def _loop():
    time.sleep(FIRST_WAIT)
    while True:
        check()
        time.sleep(EVERY)


def start(log=None):
    global LOG
    LOG = log
    if not _st["started"]:
        _st["started"] = True
        threading.Thread(target=_loop, daemon=True, name="mobile-news").start()


def status():
    return (f"phone app news (v121): newest app v{_st['last'] or '?'}; told up to version code {told()}"
            + (f"; last problem: {_st['error']}" if _st["error"] else ""))
