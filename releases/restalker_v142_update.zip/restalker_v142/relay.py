"""v141: the Restalker relay (a small Cloudflare server - relay/ in the release repository) from the PC.

- The race to checkout (owner, 2026-11-19: "Its a race to checkout, so whichever happens first is the winner and should lock the product
  normally"): right before Place order on Amazon, the PC claims the product for the owner's linked devices. The first device to claim it
  orders; the others stop. The group code is made from the link secret (no one else can guess it); the phone app makes the same one.
  When the relay cannot be asked, the rules before v141 decide (the PC goes first; never two orders).
- "Active now": a heartbeat every 15 minutes (the live count of working devices).
- Problem reports of a PC that is not the owner's go here (compiled once a day on Discord) - the owner's PC still sends to Claude.
- The Discord invite.
Nothing here can buy anything; nothing personal is sent (product codes, a random device code, the report text).
"""
import json
import os
import threading
import time
import urllib.error
import urllib.request

VERSION = "v142"
BASE = "https://restalker-relay.restalker.workers.dev"
LOG = None
_st = {"active": -1, "active_at": 0.0, "error": "", "claims": 0, "won": 0, "lost": 0, "unreachable": 0, "beat_at": 0.0, "invite": None,
       "invite_at": 0.0}
_held = {}              # asin -> when this PC claimed it
_lock = threading.Lock()


def _call(method, path, body=None, timeout=6.0, http=None):
    if http is not None:
        return http(method, path, body)
    if os.environ.get("RK_TEST_NOEXIT"):                 # (test runs never talk to the real relay)
        return None
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(BASE + path, data=data, method=method,
                                 headers={"Content-Type": "application/json", "User-Agent": "Restalker/" + VERSION})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            _st["error"] = ""
            return json.loads(r.read().decode() or "{}")
    except urllib.error.HTTPError as e:
        _st["error"] = f"HTTP {e.code}"
        try:
            return json.loads(e.read().decode() or "{}")
        except Exception:
            return None
    except Exception as e:
        _st["error"] = str(e)[:80]
        return None


def device():
    try:
        import crowd
        return crowd.my_id()
    except Exception:
        return ""


def group():
    """This link's group code (None when no phone / tablet is linked)."""
    try:
        import phonelink
        p = phonelink.parse_code(phonelink.load().get("code"))
        return phonelink.lock_group(p[1]) if p else None
    except Exception:
        return None


def claim(asin, http=None):
    """Right before Place order on Amazon: True = this PC orders, False = another of your devices has it, None = not asked."""
    g = group()
    if not g or not asin:
        return None
    _st["claims"] += 1
    r = _call("POST", "/v1/lock", {"c": device(), "g": g, "a": str(asin)}, timeout=4.0, http=http)
    if not r or r.get("ok") is not True:
        _st["unreachable"] += 1
        return None
    if r.get("granted"):
        _st["won"] += 1
        with _lock:
            _held[str(asin)] = time.time()
        return True
    _st["lost"] += 1
    if LOG:
        LOG(f"[relay] {asin}: another of your linked devices is placing this order (the shared lock) - not ordered here")
    return False


def release(asin, result, http=None, background=True):
    """How this PC's claimed checkout ended: "bought" (or maybe bought) keeps the others out for a day; anything else frees it."""
    with _lock:
        if _held.pop(str(asin), None) is None:
            return False
    g = group()
    if not g:
        return False

    def go():
        _call("POST", "/v1/release", {"c": device(), "g": g, "a": str(asin), "result": "bought" if result == "bought" else "failed"}, http=http)
    if background:
        threading.Thread(target=go, daemon=True, name="relay-release").start()
    else:
        go()
    return True


def holds(asin):
    with _lock:
        return str(asin) in _held


def heartbeat(force=False, http=None):
    """Every 15 minutes while sharing with the crowd is on: this device is working."""
    try:
        import crowd
        if not crowd.on():
            return None
    except Exception:
        pass
    now = time.time()
    if not force and now - _st["beat_at"] < 15 * 60:
        return None
    _st["beat_at"] = now
    r = _call("POST", "/v1/h", {"c": device()}, http=http)
    if r and r.get("ok"):
        _st["active"], _st["active_at"] = int(r.get("active") or 0), now
    return r


def report(title, note, text, http=None):
    """A report of a PC that is not the owner's -> the relay (compiled once a day for the Restalker team). -> True when taken."""
    r = _call("POST", "/v1/report", {"c": device(), "app": "pc", "ver": VERSION, "title": str(title)[:200], "note": str(note or "")[:1000],
                                     "text": str(text)[:250_000]}, timeout=30.0, http=http)
    return bool(r and r.get("ok"))


def invite(http=None):
    """The Restalker Discord invite (kept for a day)."""
    now = time.time()
    if _st["invite"] and now - _st["invite_at"] < 24 * 3600:
        return _st["invite"]
    r = _call("GET", "/v1/links", http=http)
    u = (r or {}).get("discord")
    if isinstance(u, str) and u.startswith("https://discord.gg/"):
        _st["invite"], _st["invite_at"] = u, now
    return _st["invite"]


def active():
    """Devices heard in the last 30 minutes (-1 = not known yet; kept for an hour)."""
    return _st["active"] if _st["active"] >= 0 and time.time() - _st["active_at"] < 3600 else -1


def invite_cached():
    """The invite without waiting (fetched in the background the first time)."""
    if not _st["invite"] and time.time() - _st.get("invite_try", 0) > 600:
        _st["invite_try"] = time.time()
        threading.Thread(target=invite, daemon=True, name="relay-invite").start()
    return _st["invite"]


def status_text():
    act = _st["active"]
    return (f"relay (v141): active now {act if act >= 0 else '?'}; race to checkout: claims {_st['claims']}, won {_st['won']}, "
            f"lost {_st['lost']}, relay not reached {_st['unreachable']}; linked group: {'yes' if group() else 'no'}"
            + (f"; last error {_st['error']}" if _st["error"] else ""))
