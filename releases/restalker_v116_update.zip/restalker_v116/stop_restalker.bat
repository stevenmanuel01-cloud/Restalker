@echo off
rem Restalker v90: closes Restalker and EVERY browser it started - also when its page does not answer any more.
rem (Double-click this file. Your own Chrome / Edge are never touched: only Restalker's program and the browsers it started.)
title Stop Restalker
echo Closing Restalker and every browser it started...
powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-NetTCPConnection -LocalPort 8001 -State Listen -ErrorAction SilentlyContinue | ForEach-Object { taskkill /F /T /PID $_.OwningProcess | Out-Null }; Get-CimInstance Win32_Process | Where-Object { $_.ProcessId -ne $PID -and ($_.CommandLine -like ('*--rk-' + 'store=*') -or $_.CommandLine -like '*%~dp0buyer_profile*' -or $_.CommandLine -like '*%~dp0reader_profile*' -or $_.CommandLine -like '*%~dp0browser_profile*') } | ForEach-Object { taskkill /F /T /PID $_.ProcessId | Out-Null }" >nul 2>&1
echo.
echo Done - Restalker is closed. To start it again, open start_app.bat.
ping 127.0.0.1 -n 4 >nul
