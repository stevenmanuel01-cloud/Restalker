"""The look and behaviour of the product-by-store table (the page part). The logic is in matrix.py."""
VERSION = "v116"

HTML = r"""
<style>
  .sw { position: relative; display: inline-block; width: 34px; height: 18px; vertical-align: middle; margin-right: 6px; }
  .sw input { opacity: 0; width: 0; height: 0; margin: 0; }
  .sw span { position: absolute; cursor: pointer; inset: 0; background: #bbb; border-radius: 18px; transition: .15s; }
  .sw span:before { content: ""; position: absolute; height: 14px; width: 14px; left: 2px; top: 2px; background: #fff; border-radius: 50%; transition: .15s; }
  .sw input:checked + span { background: #2a2; }
  .sw input:checked + span:before { transform: translateX(16px); }
  #mx { }
  #mx table { margin-bottom: 0 !important; }
  #mx tr.mxg td { background: #e9eef5; font-size: 13px; border-top: 2px solid #9aa7b6; padding: 4px 8px; }
  #mx tr.mxg .gname { font-weight: bold; font-size: 14px; cursor: pointer; user-select: none; }
  #mx tr.mxg .gsw { margin-left: 14px; white-space: nowrap; }
  #mx tr.mxg .gpart { color: #8a6d3b; font-size: 11px; }
  #mx td.mxbuy { font-size: 12px; }
  #mx td { overflow: hidden; }   /* v55: a long line in a square never spills into the next column */
  #mx td.mxbuy { padding: 1px 2px; }
  #mx .signin { font-size: 12px; font-weight: normal; margin-top: 2px; }
  #mx .signin .sin { font-weight: bold; cursor: pointer; }
  #mx .signin .sin.ok { color: #1a7f37; cursor: default; } #mx .signin .sin.bad { color: #fff; background: #d97706; padding: 1px 6px; border-radius: 4px; }
  #mx .signin .sin.go { color: #fff; background: #1a7f37; padding: 1px 6px; border-radius: 4px; }
  #mx .bstat { padding: 3px 5px; border-radius: 3px; white-space: normal !important; }
  #mx .bstat .mxl { white-space: normal !important; }
  #mx .bstat.armed { background: #fff1dc; box-shadow: inset 4px 0 0 #d97706; }
  #mx .bstat.live { background: #fff3a8; box-shadow: inset 5px 0 0 #b45309, 0 0 0 2px #f59e0b; animation: mxpulse 1.2s ease-in-out infinite; }
  @keyframes mxpulse { 50% { background: #ffe066; } }
  #mx .bstat b.arm { color: #b45309; } #mx .bstat b.dis { color: #6e7781; } #mx .bstat b.shop { color: #d97706; } #mx .bstat b.srch { color: #1a7f37; }
  #mx .bstat .need { margin-top: 2px; border-top: 1px dashed #d0d5db; padding-top: 2px; font-size: 11px; }
  #mx .bstat .need .bad { color: #b42318; }
  #mx .bstat.busy { background: #fff4d6; box-shadow: inset 4px 0 0 #b45309; }
  #mx .bstat.alert { background: #fde4e4; box-shadow: inset 4px 0 0 #b42318; }
  #mx .bstat.bought { background: #e6f0ff; box-shadow: inset 4px 0 0 #1f6feb; }
  #mx .bstat b.bad { color: #b42318; } #mx .bstat b.go { color: #b45309; } #mx .bstat b.ok { color: #1f6feb; }
  #mx .sw.buy input:checked + span { background: #d97706; }
  /* v57: one simple control per product and per group: Off | Watch | Buy */
  #mx .mode { display: inline-flex; flex: none; border: 1px solid #8c959f; border-radius: 6px; overflow: hidden; margin-right: 8px; vertical-align: middle; }
  #mx .mode button { border: 0; border-left: 1px solid #c4cad1; background: #fff; color: #333; font-size: 12px; padding: 3px 8px; cursor: pointer; margin: 0; line-height: 1.3; }
  #mx .mode button:first-child { border-left: 0; }
  #mx .mode button:hover { background: #eef1f4; }
  #mx .mode button.sel[data-m="off"] { background: #6e7781; color: #fff; }
  #mx .mode button.sel[data-m="watch"] { background: #2a9d2a; color: #fff; font-weight: bold; }
  #mx .mode button.sel[data-m="buy"] { background: #d97706; color: #fff; font-weight: bold; }
  #mx .mode button:disabled { color: #bbb; cursor: not-allowed; background: #f6f6f6; }
  #mx .mode.gmode { margin-left: 14px; }
  #mx .pname .mode { flex-direction: column; }
  #mx .pname .mode button { border-left: 0; border-top: 1px solid #c4cad1; padding: 2px 8px; }
  #mx .pname .mode button:first-child { border-top: 0; }
  #mx .bst { display: block; margin-top: 2px; color: #444; }
  #mx .bst b.on { color: #1a7f37; } #mx .bst b.go { color: #b45309; } #mx .bst b.bad { color: #b42318; } #mx .bst b.ok { color: #1f6feb; }
  #mx td.mxbuy button { font-size: 11px; padding: 1px 6px; margin: 2px 2px 0 0; }
  #mx table { table-layout: fixed; width: 100%; border-collapse: collapse; margin-bottom: 6px; }
  #mx td:not(.mxp):not(.mxmsrp):not(.mxcap) .mxs, #mx td:not(.mxp):not(.mxmsrp):not(.mxcap) .mxsub, #mx td:not(.mxp):not(.mxmsrp):not(.mxcap) .mxl { white-space: nowrap; }
  #mx th, #mx td { font-size: 13px; padding: 3px 6px; vertical-align: middle; line-height: 1.25; border: 1px solid #d0d5db; }
  #mx th { padding: 4px 6px; position: sticky; top: 0; z-index: 3; background: #f5f5f5; }
  #mx .ico { width: 51px; height: 51px; border-radius: 5px; background: #fff; vertical-align: middle; margin-right: 8px; flex: none; }
  #mx .pname { display: flex; align-items: center; }
  #mx .pname .sw { flex: none; }
  #mx .mxoff { opacity: .45; }
  #mx td.cin { background: #d9f5d9; box-shadow: inset 4px 0 0 #2a9d2a; }
  #mx td.cunk { background: #fde4e4; }
  #mx td.cin.mxoff, #mx td.cunk.mxoff { background: none; box-shadow: none; }
  #mx .mxs { font-size: 12px; color: #24292f; }
  #mx .mxs.status-instock { color: #146c14; font-weight: bold; }
  #mx .mxs.status-outofstock { color: #555; }
  #mx td.cover { background: #ffe9cc; box-shadow: inset 4px 0 0 #e08a00; }
  #mx td.cover.mxoff { background: none; box-shadow: none; }
  #mx .mxs.status-overcap { color: #a65c00; font-weight: bold; }
  #mx .mxs.status-index { color: #1d5fa8; font-weight: 600; }
  #mx .mxs.status-unknown { color: #444; font-weight: normal; }
  #mx .mxsub { font-size: 11px; color: #57606a; }
  #mx .mxl { font-size: 11px; color: #57606a; }
  #mx .mxl a, #mx a.mxadd, #mx a.mxx { cursor: pointer; color: #0969da; text-decoration: none; }
  #mx a.mxx { color: #a33; font-size: 11px; }
  #mx input.mxcapin { width: 74px; margin: 0; -moz-appearance: textfield; }
  #mx input.mxcapin::-webkit-inner-spin-button { -webkit-appearance: none; margin: 0; }
  #mx input.mxurl { width: 100%; margin: 2px 0; font-size: 12px; }
  #mx .kind { color: #6e7781; font-size: 11px; }
  #mx .auto { color: #7a5c00; background: #fff3c4; border-radius: 3px; padding: 0 4px; font-size: 10px; }
  #mx .mxprob { font-size: 11px; color: #b42318; white-space: normal; max-width: 220px; }
  #mx .mxprob:empty { display: none; }
  #mx td .mxacts { white-space: normal !important; }      /* v75: the links wrap inside the square - never cut off at its edge */
  #mx td .mxacts a, #mx td .mxcheck a { white-space: nowrap; }
  #mx .mxcheck a { cursor: pointer; color: #0969da; text-decoration: underline; }      /* v78: every choice in the yellow box looks clickable */
  #mx .mxcheck a.mxyes, #mx .mxcheck a.mxno { display: inline-block; margin: 2px 2px 0 0; padding: 1px 6px; border-radius: 3px; color: #fff; text-decoration: none; font-weight: bold; }
  #mx .mxcheck a.mxyes { background: #1a7f37; } #mx .mxcheck a.mxno { background: #b42318; }
  #mx .mxcheck { white-space: normal; font-size: 11px; background: #fff4c2; border: 1px solid #e0b400; border-radius: 3px; padding: 2px 4px; margin: 2px 0; }
  #mx .nf { color: #8a6d3b; font-size: 11px; }
  #mxmsg { min-height: 16px; font-size: 13px; margin: 2px 0; }
  #mxmsg.bad { color: #b00; } #mxmsg.good { color: #1a7f37; }
  .mxform { display: flex; gap: 8px; align-items: flex-end; flex-wrap: wrap; margin: 2px 0 6px; font-size: 13px; }
  .mxform label { display: block; font-size: 12px; color: #57606a; }
  .mxform input, .mxform select { margin: 0; padding: 5px; }
  /* v109: more pages of one product in one square */
  #mx .mxmore { border-top: 1px dashed #d0d7de; margin-top: 6px; padding-top: 5px; }
  #mx .mxpg { font-size: 11px; color: #57606a; margin-bottom: 2px; }
  /* v100: the product's restock history window */
  #mx .mxhist { cursor: pointer; text-decoration: underline dotted #9aa3ad; text-underline-offset: 3px; }
  #mx .mxhist:hover { color: #1d4ed8; }
  #mxHistBg { position: fixed; inset: 0; background: rgba(15,23,42,.45); z-index: 9000; display: flex; align-items: flex-start; justify-content: center; padding: 60px 16px; }
  #mxHistBox { background: #fff; color: #111; border-radius: 10px; box-shadow: 0 10px 40px rgba(0,0,0,.3); max-width: 640px; width: 100%; max-height: 75vh; overflow: auto; padding: 16px 18px; font-size: 14px; }
  #mxHistBox h3 { margin: 0 0 4px; font-size: 17px; }
  #mxHistBox .hx { float: right; cursor: pointer; border: 0; background: none; font-size: 20px; line-height: 1; color: #555; }
  #mxHistBox table { border-collapse: collapse; width: 100%; margin-top: 8px; }
  #mxHistBox td { border-top: 1px solid #e5e7eb; padding: 6px 6px; vertical-align: top; }
  #mxHistBox .hb { color: #15803d; font-weight: bold; white-space: nowrap; }
  #mxHistBox .hn { color: #b91c1c; font-weight: bold; white-space: nowrap; }
  #mxHistBox .hw { color: #555; font-size: 12px; }
</style>
<div id="mx"><div class="hint">Loading the table...</div></div>
<div id="mxmsg"></div>
<div class="mxform">
  <div><label>Add a product: name</label><input id="mxNewName" placeholder="e.g. Star Trek Commander Deck" style="width:250px"></div>
  <div><label>category (pick one, or type a new one)</label><input id="mxNewKind" list="mxKindList" placeholder="e.g. Collector Booster Box, Sleeves, Cables" style="width:230px" autocomplete="off">
    <datalist id="mxKindList"></datalist></div>
  <div><label>price cap $</label><input id="mxNewCap" type="number" step="0.01" style="width:90px"></div>
  <div><label>one product link (optional)</label><input id="mxNewLink" placeholder="https://www.target.com/p/..." style="width:260px"></div>
  <button data-act="addprod">Add product</button>
  <span style="width:24px"></span>
  <div><label>Add a store: name</label><input id="mxNewStore" placeholder="e.g. Costco" style="width:140px"></div>
  <button data-act="addstore">Add store</button>
</div>
<div class="hint" style="margin:0">Switches work at once; a link is watched only when its own, its product's and its store's switch are all on. Blank = not sold there = not watched. One price cap per product, same at every store.
<span style="background:#d9f5d9;padding:0 5px;border-left:3px solid #2a9d2a">green = in stock</span>
<span style="background:#fde4e4;padding:0 5px">pink = the page could not be read (or the store is blocking the program)</span>
&nbsp; MSRP = the published price, or one pack's price x packs in the box (12 for a Collector box, 30 for a Play Booster box). The MSRP column is fixed text - only the price cap can be typed.
"+x% > MSRP" in a square is how far the listed price is above that ("-x% < MSRP" below it). The TCG column is a price index: TCGplayer's market price, read once at start and then every 2 hours with a few small web requests (no browser; never watched for stock, never an alert); the other squares also say how far their price is from it ("+x% > TCG"). When you add a product the program looks for it at the other stores by itself; those links are marked "auto-found" - check them.</div>
<script>
let MX = null, MXRUN = false, MXLAST = {};
const MXOPEN = {};
function mxEsc(s) { return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;'); }
function mxSay(t, ok) { const el = document.getElementById('mxmsg'); if (!el) return; el.innerText = t || ''; el.className = ok ? 'good' : 'bad'; }
let MXREV = null;
async function mxLoad() {
  try { MX = await (await fetch('/api/matrix')).json(); MXREV = MX.rev; mxKinds(); mxDraw(); mxStatus(MXLAST); } catch (e) {}
}
function mxEditing() {
  const a = document.activeElement;
  return Object.keys(MXOPEN).length > 0 || !!(a && a.tagName === 'INPUT' && a.closest && a.closest('#mx'));
}
function mxRevCheck(rev) {               // called by the page every 1.5 s: redraw when something changed by itself (a picture arrived, a link was found)
  if (rev == null) return;
  if (MXREV === null) { MXREV = rev; return; }
  if (rev === MXREV || mxEditing()) return;
  mxLoad();
}
function mxKinds() {                      // v75: the category box takes a choice from the list OR any new name you type (never frozen)
  const dl = document.getElementById('mxKindList');
  if (!dl || !MX || !MX.kinds) return;
  const sig = MX.kinds.map(k => k.slug + ':' + k.label).join('|');
  if (dl.dataset.sig === sig) return;          // (rebuilt only when the list really changed - never while you type)
  dl.innerHTML = MX.kinds.map(k => '<option value="' + mxEsc(k.label) + '"></option>').join('');
  dl.dataset.sig = sig;
}
async function mxPost(op, body) {
  let d = {ok: false, msg: 'Could not reach the program.'};
  try {
    const r = await fetch('/api/matrix/' + op, {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify(body || {})});
    d = await r.json();
  } catch (e) {}
  if (d.msg) mxSay(d.msg, d.ok);
  await mxLoad();
  return d;
}
const MXCOL = {'the hobbit': ['#3d7a3a', '#f0e08a'], 'reality fracture': ['#7a3fc0', '#f7b4ff'], 'star trek': ['#1f4e9c', '#f6c94c']};
function mxHash(s) { let h = 0; for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) >>> 0; return h; }
function mxColors(theme) {
  if (MXCOL[theme]) return MXCOL[theme];
  const hue = mxHash(theme) % 360;
  return ['hsl(' + hue + ',45%,36%)', 'hsl(' + ((hue + 40) % 360) + ',75%,82%)'];
}
function mxMotif(theme, cx, cy, a, letter) {          // a small mark per set (plain shapes, not any official artwork)
  if (theme === 'the hobbit') return '<circle cx="' + cx + '" cy="' + cy + '" r="4.5" fill="none" stroke="' + a + '" stroke-width="1.8"/><circle cx="' + (cx + 1.4) + '" cy="' + cy + '" r="0.9" fill="' + a + '"/>';
  if (theme === 'reality fracture') return '<polyline points="' + (cx - 4) + ',' + (cy - 5) + ' ' + (cx + 1) + ',' + (cy - 1) + ' ' + (cx - 2) + ',' + (cy + 1) + ' ' + (cx + 4) + ',' + (cy + 5) + '" fill="none" stroke="' + a + '" stroke-width="1.8" stroke-linejoin="round"/>';
  if (theme === 'star trek') return '<polygon points="' + cx + ',' + (cy - 5.5) + ' ' + (cx + 1.5) + ',' + (cy - 1.5) + ' ' + (cx + 5.5) + ',' + cy + ' ' + (cx + 1.5) + ',' + (cy + 1.5) + ' ' + cx + ',' + (cy + 5.5) + ' ' + (cx - 1.5) + ',' + (cy + 1.5) + ' ' + (cx - 5.5) + ',' + cy + ' ' + (cx - 1.5) + ',' + (cy - 1.5) + '" fill="' + a + '"/>';
  return '<text x="' + cx + '" y="' + (cy + 3.5) + '" text-anchor="middle" font-size="10" font-weight="bold" fill="' + a + '">' + mxEsc(letter) + '</text>';
}
function mxIcon(p) {
  const theme = p.key.split('|')[0], kind = p.kind, cc = mxColors(theme), c = cc[0], a = cc[1];
  let g = '';
  if (kind === 'pack') {
    g = '<rect x="9" y="2.5" width="14" height="27" rx="2" fill="' + c + '"/><rect x="9" y="2.5" width="14" height="4" rx="1.5" fill="' + a + '" opacity=".55"/><rect x="9" y="25.5" width="14" height="4" rx="1.5" fill="' + a + '" opacity=".55"/>' +
        '<rect x="9" y="2.5" width="5" height="27" rx="2" fill="#fff" opacity=".15"/>' + mxMotif(theme, 16, 16, a, p.title.charAt(0));
  } else {
    g = '<polygon points="16,3 29,9.5 16,16 3,9.5" fill="' + c + '"/><polygon points="16,3 29,9.5 16,16 3,9.5" fill="#fff" opacity=".32"/>' +
        '<polygon points="3,9.5 16,16 16,29.5 3,23" fill="' + c + '"/><polygon points="29,9.5 16,16 16,29.5 29,23" fill="' + c + '"/><polygon points="29,9.5 16,16 16,29.5 29,23" fill="#000" opacity=".28"/>' +
        mxMotif(theme, 9.5, 18, a, p.title.charAt(0));
    if (kind === 'bundle') g += '<polygon points="14.5,16 17.5,16 17.5,29.2 14.5,29.2" fill="' + a + '"/><polygon points="16,3.2 17.6,4 17.6,9.5 14.4,9.5 14.4,4" fill="' + a + '" opacity="0"/>' +
        '<polygon points="9.5,6.2 16,9.4 22.5,6.2 16,3 " fill="' + a + '" opacity=".9"/><circle cx="16" cy="9" r="2" fill="' + a + '"/>';
  }
  return '<svg class="ico" viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="' + mxEsc(p.title + ' ' + p.label) + '"><title>' + mxEsc(p.title + ' - ' + p.label) + '</title>' + g + '</svg>';
}
function mxPicture(p) {
  if (p.img) return '<img class="ico" src="' + mxEsc(p.img) + '" alt="" title="' + mxEsc(p.title + ' - ' + p.label) + '" style="object-fit:contain" onerror="this.outerHTML=mxIcon(MXBYKEY[&quot;' + mxEsc(p.key) + '&quot;])">';
  return mxIcon(p);
}
let MXBYKEY = {};
function mxDraw() {
  if (!MX) return;
  const stores = MX.stores;
  MXBYKEY = {}; for (const q of MX.products) MXBYKEY[q.key] = q;
  // fixed minimum widths: a store column never gets narrower than MX_COL px (so the text in its squares never wraps onto another line);
  // with many stores the page simply scrolls sideways
  const MX_COL = 212, MX_P = 262, MX_M = 108, MX_C = 92, MX_B = 172;
  let h = '<table style="min-width:' + (MX_P + MX_M + MX_C + MX_B + MX_COL * stores.length) + 'px"><colgroup><col style="width:' + MX_P + 'px"><col style="width:' + MX_M + 'px"><col style="width:' + MX_C + 'px"><col style="width:' + MX_B + 'px">' +
          stores.map(() => '<col style="width:' + MX_COL + 'px">').join('') + '</colgroup><tr><th class="mxph" title="Off = ignored. Watch (lit: Searching) = alerts only. Buy (lit: Shopping) = alerts AND buys it at every store at or under the price cap (one each time it is chosen).">Product <span class="mxl">(Off / Searching / Shopping)</span></th><th class="mxmsrph" title="Published price, or one pack x packs per box">MSRP</th><th class="mxcaph" title="The most it may cost. Restocks over it are not alerted; auto-buy never pays more for the item.">Price cap</th>' +
          '<th class="mxbuyh" title="Line 1: armed or not. Line 2: Searching (alerts only) or Shopping (buys at the next restock under the cap). Line 3: anything that needs you.">Status<br><span class="mxl">armed &middot; mode &middot; needs you</span></th>';
  for (const s of stores) {
    if (s.key === 'tcg') {          // v58: TCG is only a price to compare with (no switch): read at start, then every 2 hours
      h += '<th><b>TCG market price</b><br><span class="mxl" title="TCGplayer\'s market price for the product. Read at start, then every 2 hours (no browser). Only for comparing - never watched for stock, never an alert.">for comparing &middot; every 2 h</span></th>';
      continue;
    }
    h += '<th class="' + (s.on ? '' : 'mxoff') + '"><label class="sw"><input type="checkbox" data-act="store" data-key="' + mxEsc(s.key) + '"' + (s.on ? ' checked' : '') +
         '><span></span></label><b>' + mxEsc(s.name) + '</b>' + (MXBUYSTORES.indexOf(s.key) >= 0 ? '<div class="signin" data-store="' + s.key + '"></div>' : '');
    if (MXOPEN['rs:' + s.key]) h += '<br><a class="mxx" data-act="rmstore2" data-key="' + mxEsc(s.key) + '">Really remove?</a> <a class="mxl" data-act="cancel" data-k="rs:' + mxEsc(s.key) + '">no</a>';
    else h += '<br><a class="mxx" data-act="rmstore" data-key="' + mxEsc(s.key) + '">remove store</a>';
    h += '</th>';
  }
  h += '</tr>';
  const groups = {};
  for (const q of MX.products) { const g = q.group || 'Other sets'; (groups[g] = groups[g] || []).push(q); }
  let curG = null;
  for (const p of MX.products) {
    const g = p.group || 'Other sets';
    if (g !== curG) {
      curG = g;
      const mem = groups[g], nOn = mem.filter(q => q.on).length, amz = mem.filter(q => MXBUYSTORES.some(k => q.cells[k]));
      const closed = !!MXCOLL[g];
      h += '<tr class="mxg"><td colspan="' + (4 + stores.length) + '"><span class="gname" data-act="gfold" data-g="' + mxEsc(g) + '">' + (closed ? '&#9656; ' : '&#9662; ') + mxEsc(g) + '</span> <span class="mxl">(' + mem.length + ' product' + (mem.length === 1 ? '' : 's') + ')</span>' +
           '<span class="mode gmode" data-g="' + mxEsc(g) + '" title="Off / Searching / Shopping for every product of this group">' +
           '<button data-act="gmode" data-m="off" data-g="' + mxEsc(g) + '">Off</button><button data-act="gmode" data-m="watch" data-g="' + mxEsc(g) + '">Watch</button>' +
           '<button data-act="gmode" data-m="buy" data-g="' + mxEsc(g) + '"' + (amz.length ? '' : ' disabled title="no store link in this group"') + '>Buy</button></span>' +
           ' <span class="gpart" data-gpart="' + mxEsc(g) + '"></span>' +
           '</td></tr>';
    }
    if (MXCOLL[g]) continue;
    const canBuy = MXBUYSTORES.some(k => p.cells[k]);
    h += '<tr class="' + (p.on ? '' : 'mxoff') + '"><td class="mxp"><div class="pname"><span class="mode" data-key="' + mxEsc(p.key) + '">' +
         '<button data-act="mode" data-m="off" data-key="' + mxEsc(p.key) + '" title="Ignore this product">Off</button>' +
         '<button data-act="mode" data-m="watch" data-key="' + mxEsc(p.key) + '" title="Alerts only - nothing is bought">Watch</button>' +
         '<button data-act="mode" data-m="buy" data-key="' + mxEsc(p.key) + '"' + (canBuy ? (p.cap ? ' title="Alert AND buy one at or under the price cap"' : ' title="Set a price cap first"') : ' disabled title="Needs a store link"') + '>Buy</button></span>' + mxPicture(p) + '<div><b class="mxhist" data-act="hist" data-key="' + mxEsc(p.key) + '" title="Its restocks: when, and bought or not">' + mxEsc(p.title) + '</b><br><span class="kind">' + mxEsc(p.label) + '</span>';
    if (MXOPEN['rp:' + p.key]) h += ' &middot; <a class="mxx" data-act="rmprod2" data-key="' + mxEsc(p.key) + '">Really remove?</a> <a class="mxl" data-act="cancel" data-k="rp:' + mxEsc(p.key) + '">no</a>';
    else h += ' &middot; <a class="mxx" data-act="rmprod" data-key="' + mxEsc(p.key) + '" title="remove this product row">remove</a>';
    const blanks = stores.filter(s => s.on && !p.cells[s.key]).length;
    if (p.searching) h += '<br><span class="nf">searching the other stores...</span>';
    else if (blanks > 0) h += '<br><a class="mxl" data-act="searchrow" data-key="' + mxEsc(p.key) + '" title="Opens each store\'s search page and adds the first result that really is this product">find at the other stores</a>';
    h += '</div></div></td>' + mxMsrpCell(p) + '<td class="mxcap">$<input class="mxcapin" type="number" step="0.01" data-act="cap" data-key="' + mxEsc(p.key) + '" value="' + (p.cap == null ? '' : p.cap) + '">' + mxCapNote(p) + '</td>';
    h += MXBUYSTORES.some(k => p.cells[k]) ? '<td class="mxbuy"><div class="bstat" data-key="' + mxEsc(p.key) + '"></div></td>'
                   : '<td class="mxbuy"><span class="mxl">no store link</span></td>';
    for (const s of stores) {
      const c = p.cells[s.key];
      const dim = (!p.on || !s.on || (c && !c.cell_on)) ? ' mxoff' : '';
      if (!c) {
        const ok = 'ab:' + p.key + ':' + s.key;
        if (MXOPEN[ok] !== undefined) {
          h += '<td>' + mxLinkBox(ok, '', p.key, s.key) + '</td>';
        } else {
          const sr = (p.searched || {})[s.key];
          h += '<td>' + (p.searching && s.on ? '<span class="nf">searching...</span>' : (sr && !sr.found ? '<span class="nf">not found by search</span><br>' : '')) +
               '<a class="mxadd" data-act="addlink" data-k="' + mxEsc(ok) + '">+ link</a></td>';
        }
        continue;
      }
      if (s.key === 'tcg') {           // v58: just the price (no switch)
        h += '<td><span class="mxs" data-id="' + mxEsc(c.id) + '" data-msrp="' + (p.msrp ? p.msrp.value : '') + '" data-tcg="" data-on="1">...</span><div class="mxl mxacts"><a href="' + mxEsc(c.url) + '" target="_blank">open</a> &middot; <a data-act="editlink" data-k="ed:' + mxEsc(c.id) + '" data-url="' + mxEsc(c.url) + '">change link</a></div>' +
             (MXOPEN['ed:' + c.id] !== undefined ? mxLinkBox('ed:' + c.id, c.url, p.key, s.key, c.id) : '') + '</td>';
        continue;
      }
      h += '<td class="' + dim.trim() + '"><label class="sw"><input type="checkbox" data-act="cell" data-id="' + mxEsc(c.id) + '"' + (c.cell_on ? ' checked' : '') +
           '><span></span></label><span class="mxs" data-id="' + mxEsc(c.id) + '" data-msrp="' + (p.msrp ? p.msrp.value : '') + '" data-tcg="' + (!c.index && p.cells.tcg ? p.cells.tcg.id : '') + '" data-on="' + ((p.on && s.on && c.cell_on) ? 1 : 0) + '">...</span><div class="mxprob" data-id="' + mxEsc(c.id) + '"></div><div class="mxl mxacts">';
      const ek = 'ed:' + c.id;
      if (MXOPEN[ek] !== undefined) h += mxLinkBox(ek, c.url, p.key, s.key, c.id);
      else {
        // v75: a link the program FOUND is flagged until you have looked at it (it is never bought before its page shows this product)
        if (c.found && !c.checked) h += '</div><div class="mxcheck">FOUND BY THE PROGRAM - right product? <a data-act="openin" data-url="' + mxEsc(c.url) + '">open it</a><br><a class="mxyes" data-act="rightlink" data-id="' + mxEsc(c.id) + '" title="This page IS this product - it may be bought">YES - right</a> <a class="mxno" data-act="wronglink2" data-id="' + mxEsc(c.id) + '" title="This page is NOT this product - removed, never bought, the right one is searched for">NO - wrong</a></div><div class="mxl mxacts">';
        else if (c.found) h += '<span class="auto" title="Found by the program; you checked it.">auto-found &#10003;</span> ';
        h += '<a href="' + mxEsc(c.url) + '" target="_blank" data-act="openin" data-url="' + mxEsc(c.url) + '" title="Opens in Restalker\'s own buying browser (signed in; the store answers it) - ' + mxEsc(c.url) + '">open</a> &middot; <a data-act="editlink" data-k="' + mxEsc(ek) + '" data-url="' + mxEsc(c.url) + '">change</a> &middot; ';
        if (MXOPEN['rl:' + c.id]) h += '<a class="mxx" data-act="rmlink2" data-id="' + mxEsc(c.id) + '">Really remove?</a> <a data-act="cancel" data-k="rl:' + mxEsc(c.id) + '">no</a>';
        else h += '<a class="mxx" data-act="rmlink" data-id="' + mxEsc(c.id) + '">remove</a>';
        // v75: "wrong product" - removed, never bought, and the program looks for the right page at this store by itself
        if (MXOPEN['wl:' + c.id]) h += '<br><a class="mxx" data-act="wronglink2" data-id="' + mxEsc(c.id) + '">Yes - wrong product, find the right one</a> <a data-act="cancel" data-k="wl:' + mxEsc(c.id) + '">no</a>';
        else h += ' &middot; <a class="mxx" data-act="wronglink" data-id="' + mxEsc(c.id) + '" title="This page is NOT this product: it is removed (never bought) and the program searches this store for the right one">wrong</a>';
        const amk = 'am:' + p.key + ':' + s.key;
        if ((c.more || []).length < 3) h += '<br><a class="mxl" data-act="addlink" data-k="' + mxEsc(amk) + '" title="The store sells this product on another page too: add that page here - both are watched and bought (still only one of the product)">+ another link</a>';
        if (MXOPEN[amk] !== undefined) h += '<br>' + mxLinkBox(amk, '', p.key, s.key);
      }
      h += '</div>';
      for (const m of (c.more || [])) h += mxMoreLink(p, s, m);
      h += '</td>';
    }
    h += '</tr>';
  }
  h += '</table>';
  document.getElementById('mx').innerHTML = h;
  if (MXBUY) mxBuy(MXBUY); else mxModes();
}
// v55: groups can be folded (remembered in this browser only)
let MXCOLL = {};
try { MXCOLL = JSON.parse(localStorage.getItem('rk_groups_folded') || '{}') || {}; } catch (e) { MXCOLL = {}; }
// v55: the Auto-buy column, filled from the buying status (/api/status -> buyer) every 1.5 s
let MXBUY = null;
const MXBUYSTORES = ['amazon', 'bestbuy', 'target', 'walmart', 'gamestop'], MXBUYNAME = {amazon: 'Amazon', bestbuy: 'Best Buy', target: 'Target', walmart: 'Walmart', gamestop: 'GameStop'};
// v58: ONE buying status per product (the store only shows up when something happens there). A store switched off for the
// product (its switch in the store's square, or the store's column switch) is not bought at.
// v109: a square can hold several pages of the product at that store (the first, then "more") - each read and bought on its own
function mxLinks(q, k) { const c = q.cells[k]; return c ? [c].concat(c.more || []) : []; }
function mxLines(q) {
  const on = {}; for (const st of (MX ? MX.stores : [])) on[st.key] = st.on;
  return MXBUYSTORES.filter(k => on[k] !== false).flatMap(k => mxLinks(q, k).filter(c => c.cell_on).map(c => ({store: k, tid: c.id})));
}
function mxSignin(b) {
  document.querySelectorAll('#mx .signin[data-store]').forEach(el => {
    const st = el.dataset.store, ss = b.shop_signed_in || {}, si = st === 'amazon' ? b.signed_in : (st in ss ? ss[st] : (st === 'bestbuy' ? b.bb_signed_in : null));
    let h;
    if (!b.on) h = '<span class="mxl">buying is OFF</span>';
    else if (b.visible && b.signin_store === st) h = '<a class="sin go" data-act="signin" data-s="done">Done - close that window</a>';
    else if (si === true) h = '<span class="sin ok" title="The buying browser is signed in and ready to buy here">&#10003; signed in' + (st === 'amazon' && b.account ? ' (' + mxEsc(b.account) + ')' : '') + '</span> <a class="mxl" data-act="signin" data-s="' + st + '" title="Open this store\'s sign-in page anyway">open</a>';
    else if (si === false) h = '<a class="sin bad" data-act="signin" data-s="' + st + '" title="Opens the buying browser on this store\'s sign-in page">Sign in</a>';
    else h = '<span class="mxl">checking sign-in...</span> <a class="sin" data-act="signin" data-s="' + st + '">Sign in</a>';
    // v75: the OTHER buying browsers (Chrome, Firefox, Camoufox) - each is signed in to the store on its own
    const ex = b.extra || {};
    if (b.on && Object.keys(ex).length) {          // v88: Amazon too
      h += '<div class="mxl mxacts" style="white-space:normal">' + Object.entries(ex).map(([k, w]) => {
        const sg = (w.signed || {})[st];
        // v90 (your report: every store column showed the browser "signing in" while you signed in at ONE store): the sign-in note is
        // shown only under the store you are signing in to; the other columns keep that browser's last known answer for them
        if (w.state === 'sign-in window open' && (!w.signin_store || w.signin_store === st)) return mxEsc(w.name) + ': <b>signing in here...</b> (close its window when done)';
        if (/^waiting for your sign-in/.test(w.state || '')) return '<b class="bad">' + mxEsc(w.name) + ': ' + mxEsc(w.state) + ' - its window is on your screen</b>';
        if (w.state !== 'ready' && w.state !== 'sign-in window open') return mxEsc(w.name) + ': ' + mxEsc(w.state);
        return sg === true ? '<span title="' + mxEsc(w.name) + ' is signed in here and buys too">' + mxEsc(w.name) + ' &#10003;</span>'
             : sg === false ? mxEsc(w.name) + ' <a data-act="extrasignin" data-k="' + mxEsc(k + ':' + st) + '" title="Opens ' + mxEsc(w.name) + ' on this store\'s sign-in page - sign in (tick Keep me signed in), then close it">sign in!</a>'
             : '<span title="' + mxEsc(w.name) + ' could not tell yet whether it is signed in here - it buys anyway">' + mxEsc(w.name) + ' ?</span> <a class="mxl" data-act="extrasignin" data-k="' + mxEsc(k + ':' + st) + '" title="Opens ' + mxEsc(w.name) + ' on this store\'s sign-in page">sign in</a>';
      }).join(' &middot; ') + '</div>';
    }
    if (el.dataset.h !== h) { el.innerHTML = h; el.dataset.h = h; }
  });
}
function mxBuy(b) {
  // v63: the Status column - line 1 armed / disarmed, line 2 Searching / Shopping (or the live checkout), line 3 anything that needs you
  MXBUY = b;
  mxSignin(b);
  const rows = {}; for (const r of (b.rows || [])) rows[r.tid] = r;
  const live = {}; for (const c of (b.checkout_now || [])) live[c.tid] = c;
  document.querySelectorAll('#mx .bstat[data-key]').forEach(el => {
    const q = MXBYKEY[el.dataset.key]; if (!q) return;
    const all = MXBUYSTORES.flatMap(k => mxLinks(q, k).map(c => ({store: k, tid: c.id, url: c.url, r: rows[c.id]}))).filter(x => x.r);
    const lines = all.filter(x => mxLines(q).some(y => y.tid === x.tid));
    const nm = x => MXBUYNAME[x.store] || x.store, f = (k) => all.find(x => k(x.r));
    const mode = mxProdMode(q);
    const armed = lines.some(y => y.r.armed || y.r.wanted) && mode === 'buy';
    let cls = '', l1 = '', l2 = '', l3 = [], hit;
    l1 = armed ? (b.on ? '<b class="arm">ARMED</b>' : '<b class="bad">ARMED - but buying is OFF in the top bar</b>') : '<b class="dis">Disarmed</b>';
    const nstores = new Set(lines.filter(y => y.r.wanted || y.r.armed).map(y => y.store)).size;
    l2 = mode === 'off' ? '<span class="mxl">Off</span>' : mode === 'buy' ? '<b class="shop">Shopping</b> <span class="mxl">' + (nstores ? 'at ' + nstores + ' store' + (nstores === 1 ? '' : 's') : '') + '</span>' : '<b class="srch">Searching</b> <span class="mxl">alerts only</span>';
    if ((hit = f(r => r.inprogress || r.needCvv || r.approval))) {
      // a hit: the live checkout - store, browser, step and the time since the restock was seen
      cls = 'live';
      const c = live[hit.tid] || {}, since = c.since || ((hit.r.hitAt || 0) / 1000);
      l1 = '<b class="go">CHECKING OUT NOW</b><br>store: <b>' + nm(hit) + '</b>';
      l2 = '<span class="mxel" data-since="' + (since || 0) + '">' + (since ? mxElapsed(since) : '') + '</span>' + (hit.r.price ? ' &middot; $' + Number(hit.r.price).toFixed(2) : '') +
           '<br><span class="mxl">' + mxEsc(c.step || hit.r.step || hit.r.status || 'starting').slice(0, 70) + '</span>' +
           // v114 (owner: "a link to pull up the active checkout page(s) for live monitoring (and intervention if necessary)")
           '<br><button data-act="buyx" data-a="' + (c.shown ? 'hideco' : 'showco') + '" data-tid="' + mxEsc('main|' + hit.tid) + '" title="' +
           (c.shown ? 'puts that window away again' : 'puts this live checkout page on your screen; nothing is pressed for you') + '">' + (c.shown ? 'Hide checkout' : 'Show checkout') + '</button>';
    }
    if ((hit = f(r => r.needCvv))) { cls = 'alert'; l3.push('<b class="bad">SECURITY CODE?</b> ' + nm(hit) + ' asks for your card\'s code - type it in the top bar'); }
    if ((hit = f(r => r.approval))) { cls = 'alert'; l3.push('<b class="bad">SHIPPING $' + Number(hit.r.approval.shipping || 0).toFixed(2) + ' at ' + nm(hit) + ' - OK?</b><br><button data-act="buyx" data-a="approve" data-tid="' + mxEsc(hit.tid) + '">Approve</button><button data-act="buyx" data-a="cancel" data-tid="' + mxEsc(hit.tid) + '">Cancel</button>'); }
    if (cls !== 'live' && cls !== 'alert') {
      if ((hit = f(r => r.frozen === 'bought'))) { cls = 'bought'; l1 = '<b class="ok">BOUGHT &#10003;</b>'; l3.push('at ' + nm(hit) + (hit.r.order ? ' &middot; order ' + mxEsc(hit.r.order) : '') + ' &middot; nothing more is bought for it ' +
        '<button data-act="onemore" data-tid="' + mxEsc(hit.tid) + '" data-name="' + mxEsc((q.title || '') + ' ' + (q.label || '')) + '">Buy one more</button>'); }
      else if ((hit = f(r => r.unclear && r.frozen !== 'unknown'))) { cls = 'busy'; l3.push('<b class="go">ORDER PLACED?</b> checking your ' + nm(hit) + ' orders...'); }
      else if ((hit = f(r => r.frozen === 'unknown'))) { cls = 'alert'; l3.push('<b class="bad">RESULT UNKNOWN</b> at ' + nm(hit) + ' - frozen. Choose Buy if nothing was ordered'); }
      const locked = all.filter(x => x.r.locked);
      if (locked.length) {
        cls = 'alert'; l1 = '<b class="bad">LOCKED</b>';
        l3.push(locked.map(nm).join(', ') + ': ' + locked[0].r.locked + ' checkouts in a row did not buy, so it stopped trying (frees the PC for the others). ' +
                '<button data-act="unlock" data-tids="' + mxEsc(locked.map(x => x.tid).join(',')) + '">Unlock</button>');
      }
      else if (armed) cls = 'armed';
    }
    // links the program is not sure about: you look at the page and say yes / no before that store can buy it
    for (const x of all.filter(x => x.r.problem)) {
      const c = {url: x.url};
      if (MXVER[x.tid]) l3.push('<b>' + nm(x) + ':</b> is the page you just opened exactly <b>' + mxEsc(q.title) + ' (' + mxEsc(q.label) + ')</b>? ' +
                               '<button data-act="verify" data-a="yes" data-tid="' + mxEsc(x.tid) + '">Yes, right product</button><button data-act="verify" data-a="no" data-tid="' + mxEsc(x.tid) + '">No</button>');
      else l3.push('<span class="bad">' + nm(x) + ': ' + mxEsc(x.r.problem).slice(0, 110) + '</span> <button data-act="verifyopen" data-tid="' + mxEsc(x.tid) + '" data-url="' + mxEsc(c ? c.url : '') + '">Check the ' + nm(x) + ' link</button>');
      if (cls !== 'live') cls = cls || 'alert';
    }
    const signedOut = lines.filter(y => (y.r.wanted || y.r.armed) && b.shop_signed_in && ((y.store === 'amazon' && b.signed_in === false) || (y.store !== 'amazon' && (b.shop_signed_in[y.store] === false))));
    if (signedOut.length) l3.push('<span class="bad">not signed in at ' + signedOut.map(nm).join(', ') + '</span> - use Sign in above that column');
    const x = '<div>' + l1 + '</div><div>' + l2 + '</div>' + (l3.length ? '<div class="need">' + l3.join('<br>') + '</div>' : '');
    if (el.dataset.h !== x) { el.innerHTML = x; el.dataset.h = x; }
    el.className = 'bstat' + (cls ? ' ' + cls : '');
  });
  // a link whose page does not show this row's exact product is never bought - said in its square too
  document.querySelectorAll('#mx .mxprob[data-id]').forEach(el => {
    const r = rows[el.dataset.id], why = r && r.problem;
    const x = why ? '<b>NOT BUYING HERE</b> - see Status' : '';
    if (el.dataset.h !== x) { el.innerHTML = x; el.dataset.h = x; }
  });
  mxModes();
}
const MXVER = {};
// v63: a store page opens in Restalker's own buying browser (signed in, the store answers it); only if that is not running, in this browser
async function mxOpenIn(url) {
  let d = null;
  try { d = await (await fetch('/api/amazon-buy', {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({action: 'openlink', tid: url})})).json(); } catch (e2) {}
  if (!(d && d.result && d.result.ok)) window.open(url, '_blank');
  else mxSay('Opened in Restalker\'s buying browser window. Press "Done - close that window" above the store column when finished.', true);
}
function mxElapsed(since) { const s = Math.max(0, Math.round(Date.now() / 1000 - since)); return Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0') + ' elapsed'; }
setInterval(() => document.querySelectorAll('#mx .mxel[data-since]').forEach(e => { const v = Number(e.dataset.since); if (v) e.textContent = mxElapsed(v); }), 1000);
// v57: which of Off / Watch / Buy is lit, for each product and each group
function mxProdMode(q) {
  if (!q.on) return 'off';
  const rows = {}; for (const r of ((MXBUY && MXBUY.rows) || [])) rows[r.tid] = r;
  if (MXPEND[q.key] && Date.now() - MXPEND[q.key].at < 4000) return MXPEND[q.key].m;          // (shown at once after a click)
  return MXBUYSTORES.some(k => mxLinks(q, k).some(c => rows[c.id] && rows[c.id].wanted)) ? 'buy' : 'watch';
}
// v63: the lit button says what is happening: Off | Searching (was Watch) | Shopping (was Buy)
function mxSel(bt, on) {
  bt.classList.toggle('sel', on);
  const t = bt.dataset.m === 'watch' ? (on ? 'Searching' : 'Watch') : bt.dataset.m === 'buy' ? (on ? 'Shopping' : 'Buy') : 'Off';
  if (bt.textContent !== t) bt.textContent = t;
}
function mxModes() {
  if (!MX) return;
  const byG = {};
  for (const q of MX.products) { const m = mxProdMode(q); MXBYKEY[q.key] = q; const g = q.group || 'Other sets'; (byG[g] = byG[g] || {off: 0, watch: 0, buy: 0, n: 0}); byG[g][m]++; byG[g].n++;
    document.querySelectorAll('#mx .mode[data-key="' + CSS.escape(q.key) + '"] button').forEach(bt => mxSel(bt, bt.dataset.m === m)); }
  document.querySelectorAll('#mx .mode.gmode').forEach(el => {
    // v75 (your rule): a group shows the HIGHEST level of its products (Buy, then Watch, then Off); "(mixed ...)" says the rest
    const c = byG[el.dataset.g] || {n: 0}, m = !c.n ? '' : c.buy ? 'buy' : c.watch ? 'watch' : 'off';
    const same = c.n && (c.buy === c.n || c.watch === c.n || c.off === c.n);
    el.querySelectorAll('button').forEach(bt => mxSel(bt, bt.dataset.m === m));
    const part = document.querySelector('#mx [data-gpart="' + CSS.escape(el.dataset.g) + '"]');
    if (part) { const t = same ? '' : '(mixed: ' + [c.buy ? c.buy + ' shopping' : '', c.watch ? c.watch + ' watching' : '', c.off ? c.off + ' off' : ''].filter(Boolean).join(', ') + ')'; if (part.innerText !== t) part.innerText = t; }
  });
}
let MXPEND = {};
function mxFrozen(q) {                    // v75: bought / locked / unknown result - a GROUP button leaves it alone (its own button still works)
  const rows = {}; for (const r of ((MXBUY && MXBUY.rows) || [])) rows[r.tid] = r;
  return MXBUYSTORES.some(k => mxLinks(q, k).some(c => rows[c.id] && (rows[c.id].purchased || rows[c.id].locked || rows[c.id].frozen)));
}
async function mxModeSet(keys, m, label) {
  let ps = keys.map(k => MXBYKEY[k]).filter(Boolean);
  if (ps.length > 1 && m !== 'off') {
    const skip = ps.filter(mxFrozen);
    ps = ps.filter(q => !mxFrozen(q));
    if (skip.length) mxSay('Left as they are (bought or locked - use the button next to one to change it): ' + skip.map(q => q.title).join(', '), true);
    if (!ps.length) { mxModes(); return; }
    keys = ps.map(q => q.key);
  }
  const all = [], buy = [];
  for (const q of ps) { for (const k of MXBUYSTORES) for (const c of mxLinks(q, k)) all.push(c.id); if (q.cap != null) for (const y of mxLines(q)) buy.push(y.tid); }
  if (m === 'buy') {
    if (!buy.length) { mxSay(ps.some(q => q.cap == null) ? 'Set a price cap first - Buy never pays more than the cap.' : 'Its Amazon / Best Buy squares are switched off.', false); mxModes(); return; }
    if (ps.length > 1 && !confirm('BUY every product of ' + (label || 'these') + ' by itself at the next restock, at or under its price cap?')) { mxModes(); return; }
    if (MXBUY && !MXBUY.on) {
      if (!confirm('Buying is switched OFF in the top bar. Switch buying ON now?')) { mxModes(); return; }
      await mxBuyPost({action: 'on'});
    }
  }
  // shown at once (the program confirms a moment later)
  for (const q of ps) MXPEND[q.key] = {m: (m === 'buy' && q.cap == null) ? (q.on ? 'watch' : 'off') : m, at: Date.now()};
  mxModes();
  if (m === 'off') {
    if (all.length) mxBuyPost({action: 'disarmgroup', tids: all});
    if (ps.length === 1) await mxPost('product', {key: ps[0].key, on: false}); else await mxPost('group', {group: label, on: false});
    return;
  }
  const req = m === 'buy' ? mxBuyPost({action: 'armgroup', tids: buy}) : (all.length ? mxBuyPost({action: 'disarmgroup', tids: all}) : null);
  if (ps.some(q => !q.on)) { if (ps.length === 1) mxPost('product', {key: ps[0].key, on: true}); else mxPost('products', {keys: ps.filter(q => !q.on).map(q => q.key), on: true}); }
  const d = req ? await req : null;
  const fr = (d && d.result && d.result.frozen) || [];
  if (m === 'buy' && fr.length) {
    if (ps.length === 1) {
      const x = fr[0];
      if (confirm(x.why === 'bought' ? x.product + ' was already BOUGHT. Buy ONE MORE?' : 'The last order of ' + x.product + ' has an UNKNOWN result. Buy it anyway (only if you know nothing was ordered)?'))
        for (const y of fr) await mxBuyPost({action: 'again', tid: y.tid});
      else { delete MXPEND[ps[0].key]; mxModes(); }
    } else mxSay(fr.length + ' already bought (or with an unknown result) stay frozen: ' + fr.map(y => y.product).join(', ') + '. Choose Buy next to one to buy another.', true);
  }
}
async function mxBuyPost(body) {
  let d = null;
  try { d = await (await fetch('/api/amazon-buy', {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify(body)})).json(); } catch (e) {}
  if (d && d.result && d.result.ok === false && d.result.reason) mxSay(d.result.reason, false);
  if (d) { if (typeof buyShow === 'function') buyShow(d); else mxBuy(d); }
  return d;
}
function mxMoney(v) { return '$' + Number(v).toFixed(2); }
// v100 (owner 2026-11-05: compare the cap "only ... to msrp. we might consider a small markup of maybe 5%"): a cap under MSRP + 5 % is
// pointed out (a store pricing a little above MSRP is then never bought) - only pointed out: the cap is yours and is not changed
const MX_CAP_MARKUP = 0.05;
function mxCapNote(p) {
  const m = p.msrp && p.msrp.value ? parseFloat(p.msrp.value) : 0, c = p.cap == null ? null : parseFloat(p.cap);
  if (!m || c == null || isNaN(c) || c >= m * (1 + MX_CAP_MARKUP) - 0.005) return '';
  const lim = m * (1 + MX_CAP_MARKUP);
  return '<div class="mxl" style="color:#b45309;white-space:normal" title="A store that prices this a little above MSRP (up to 5 % over, $' + lim.toFixed(2) +
    ') is not bought with this cap. Your cap is kept as it is.">' + (c < m ? 'under MSRP' : 'under MSRP + 5%') + ' ($' + lim.toFixed(2) + ')</div>';
}
// v100 (owner 2026-11-05: "a popular style information windows could list simplified product restock info. time date and bought or not
// bought along with super brief explanation"): click a product's name -> its restocks, newest first. Read only.
function mxHistClose() { const x = document.getElementById('mxHistBg'); if (x) x.remove(); }
async function mxHist(key) {
  mxHistClose();
  const p = (MX ? MX.products : []).find(q => q.key === key) || {title: key, label: ''};
  const bg = document.createElement('div');
  bg.id = 'mxHistBg';
  bg.innerHTML = '<div id="mxHistBox"><button class="hx" data-act="histclose" title="Close">&times;</button><h3>' + mxEsc(p.title) + ' <span class="hw">' + mxEsc(p.label || '') +
                 '</span></h3><div class="hw">Its restocks, newest first.</div><div id="mxHistBody" class="hw" style="margin-top:10px">reading...</div></div>';
  bg.addEventListener('click', ev => { if (ev.target === bg) mxHistClose(); });
  document.body.appendChild(bg);
  let d = null;
  try { d = await (await fetch('/api/product-history?key=' + encodeURIComponent(key))).json(); } catch (e) { d = null; }
  const body = document.getElementById('mxHistBody');
  if (!body) return;
  if (!d || !d.ok) { body.textContent = (d && d.text) || 'The history could not be read just now.'; return; }
  if (!d.waves.length) { body.textContent = 'No restock of it has been seen yet' + (d.since ? ' (since ' + new Date(d.since * 1000).toLocaleDateString() + ').' : '.'); return; }
  const two = n => (n < 10 ? '0' : '') + n;
  let h = '<table>';
  for (const w of d.waves) {
    const t = new Date(w.t * 1000);
    const when = t.toLocaleDateString(undefined, {weekday: 'short', month: 'short', day: 'numeric'}) + ' ' + (t.getHours() % 12 || 12) + ':' + two(t.getMinutes()) + (t.getHours() < 12 ? ' am' : ' pm');
    h += '<tr><td style="white-space:nowrap">' + mxEsc(when) + '</td><td>' + mxEsc((w.stores || []).join(', ') || '-') + (w.price ? ' &middot; $' + Number(w.price).toFixed(2) : '') +
         (w.source && w.source !== 'seen by Restalker' ? '<div class="hw">' + mxEsc(w.source) + '</div>' : '') + '</td><td>' +
         (w.bought ? '<span class="hb">&#10003; Bought</span>' : '<span class="hn">Not bought</span>') + '<div class="hw">' + mxEsc(w.why || '') + '</div></td></tr>';
  }
  body.innerHTML = h + '</table>';
  body.className = '';
}
document.addEventListener('keydown', e => { if (e.key === 'Escape') mxHistClose(); });
function mxMsrpCell(p) {
  const m = p.msrp;
  const how = !m ? 'unknown' : m.how === 'calc' ? 'calculated: ' + m.note : m.how === 'estimate' ? 'estimate: ' + m.note : 'published' + (m.note ? ': ' + m.note : '');
  let seen = '';
  const sn = p.seen || {};
  const pick = (sn.in && sn.in.n) ? ['in stock', sn.in] : ((sn.out && sn.out.n) ? ['listed', sn.out] : null);
  if (pick) {
    const pc = m ? ' (' + (((pick[1].avg / m.value - 1) * 100) >= 0 ? '+' : '') + Math.round((pick[1].avg / m.value - 1) * 100) + '%)' : '';
    seen = '<div class="mxl" title="Average ' + pick[0] + ' price seen over ' + pick[1].n + ' price(s); low ' + mxMoney(pick[1].min) + ', high ' + mxMoney(pick[1].max) + '">avg ' + pick[0] + ' ' + mxMoney(pick[1].avg) + pc + '</div>';
  }
  // v63: "published" opens the maker's own page that lists the price; "calculated" opens the page showing the sum and its source
  let word = mxEsc(m ? (m.how === 'calc' ? 'calculated' : m.how === 'estimate' ? 'estimate' : m.how === 'yours' ? 'yours' : 'published') : 'unknown');
  if (m && m.how === 'published' && m.source) word = '<a href="' + mxEsc(m.source) + '" target="_blank" title="Wizards of the Coast\'s own list of prices">published</a>';
  else if (m && m.how === 'calc') word = '<a href="/msrp-how?key=' + encodeURIComponent(p.key) + '" target="_blank" title="' + mxEsc(m.note) + ' - click for the sum and its source">calculated</a>';
  return '<td class="mxmsrp ' + (p.on ? '' : 'mxoff') + '" title="' + mxEsc(how) + '"><b>' + (m ? mxMoney(m.value) : '?') + '</b><div class="mxl">' +
         word + '</div>' + seen + '</td>';
}
// v109: one more page of the product at this store, in the same square (its own switch, square, problem line and links)
function mxMoreLink(p, s, m) {
  const on = (p.on && s.on && m.cell_on) ? 1 : 0, ek = 'ed:' + m.id;
  const asin = (String(m.url || '').match(/\/(?:dp|gp\/product)\/(B0[A-Z0-9]{8})/i) || [])[1];
  let h = '<div class="mxmore' + (m.cell_on ? '' : ' mxoff') + '"><div class="mxpg" title="The store sells this product on this page too - watched and bought like the first one (still only one of the product)">another page' + (asin ? ' &middot; ' + mxEsc(asin.toUpperCase()) : '') + '</div><label class="sw"><input type="checkbox" data-act="cell" data-id="' + mxEsc(m.id) + '"' + (m.cell_on ? ' checked' : '') +
          '><span></span></label><span class="mxs" data-id="' + mxEsc(m.id) + '" data-msrp="' + (p.msrp ? p.msrp.value : '') + '" data-tcg="' + (!m.index && p.cells.tcg ? p.cells.tcg.id : '') +
          '" data-on="' + on + '">...</span><div class="mxprob" data-id="' + mxEsc(m.id) + '"></div><div class="mxl mxacts">';
  if (MXOPEN[ek] !== undefined) return h + mxLinkBox(ek, m.url, p.key, s.key, m.id) + '</div></div>';
  if (m.found && !m.checked) h += '</div><div class="mxcheck">' + (m.found_by === 'tracker' ? 'FOUND ON A TRACKER\'S PAGE' : 'FOUND BY THE PROGRAM') + ' - right product? <a data-act="openin" data-url="' + mxEsc(m.url) + '">open it</a><br><a class="mxyes" data-act="rightlink" data-id="' + mxEsc(m.id) + '">YES - right</a> <a class="mxno" data-act="wronglink2" data-id="' + mxEsc(m.id) + '">NO - wrong</a></div><div class="mxl mxacts">';
  else if (m.found) h += '<span class="auto" title="Found by the program; you checked it.">auto-found &#10003;</span> ';
  h += '<a href="' + mxEsc(m.url) + '" target="_blank" data-act="openin" data-url="' + mxEsc(m.url) + '" title="' + mxEsc(m.url) + '">open</a> &middot; <a data-act="editlink" data-k="' + mxEsc(ek) + '" data-url="' + mxEsc(m.url) + '">change</a> &middot; ';
  h += MXOPEN['rl:' + m.id] ? '<a class="mxx" data-act="rmlink2" data-id="' + mxEsc(m.id) + '">Really remove?</a> <a data-act="cancel" data-k="rl:' + mxEsc(m.id) + '">no</a>'
                           : '<a class="mxx" data-act="rmlink" data-id="' + mxEsc(m.id) + '">remove</a>';
  return h + '</div></div>';
}
function mxLinkBox(k, url, pkey, skey, id) {
  const v = MXOPEN[k] === true ? url : MXOPEN[k];
  return '<input class="mxurl" data-k="' + mxEsc(k) + '" value="' + mxEsc(v) + '" placeholder="paste the product page link">' +
         '<button data-act="savelink" data-k="' + mxEsc(k) + '" data-key="' + mxEsc(pkey) + '" data-store="' + mxEsc(skey) + '">Save</button> ' +
         '<button data-act="cancel" data-k="' + mxEsc(k) + '">Cancel</button>';
}
function mxStatus(ts) {
  MXLAST = ts || {};
  document.querySelectorAll('#mx .mxs').forEach(el => {
    const id = el.dataset.id, s0 = MXLAST[id], td = el.closest('td');
    // v101: a real reading shows what the readings agree on (steady.py) - one browser shown another page no longer flips the square
    const s = (s0 && s0.show && (s0.status === 'IN_STOCK' || s0.status === 'OUT_OF_STOCK'))
      ? Object.assign({}, s0, {status: s0.show.status, price: s0.show.price, high_price: s0.show.high}) : s0;
    const msrp = parseFloat(el.dataset.msrp) || 0;
    let main = '', sub = '', cls = 'mxs', tc = '';
    if (el.dataset.on !== '1') { main = 'off'; }
    else if ((!s || !s.status) && s && s.last_good) { main = (s.last_good.status === 'IN_STOCK' ? 'IN STOCK' : 'out') + (s.last_good.price != null ? ' $' + s.last_good.price : ''); sub = timeAgo(s.last_good.at); cls += ' status-' + (s.last_good.status === 'IN_STOCK' ? 'instock' : 'outofstock'); }
    else if (!s || !s.status) { main = MXRUN ? 'reading now...' : 'not started'; }
    else {
      const hasP = s.price != null && s.price !== '' && !isNaN(parseFloat(s.price));
      const p = hasP ? ' $' + s.price : '';
      if (s.status === 'INDEX') {
        const mk = s.market != null ? s.market : s.price;
        main = mk != null ? '$' + Number(mk).toFixed(2) : 'no price'; cls += ' status-index';
        sub = '';
        if (msrp && mk) { const dm = (mk / msrp - 1) * 100; sub = (Math.abs(dm) < 0.5 ? '= MSRP' : (dm > 0 ? '+' : '') + Math.round(dm) + (dm > 0 ? '% > MSRP' : '% < MSRP')); }
      }
      else if (s.status === 'IN_STOCK') { main = 'IN STOCK' + p; cls += ' status-instock'; tc = 'cin'; }
      // v90 (your rule: green = can be bought now, orange = for sale but NOT under your cap, no colour = sold out): an offer over the cap
      // (or only other sellers' offers at Amazon) is shown as what it is - for sale, over the cap - instead of "out"
      else if (s.status === 'OUT_OF_STOCK' && s.high_price) { main = (hasP ? 'FOR SALE' + p + ' - over cap' : 'other sellers only - over cap'); cls += ' status-overcap'; tc = 'cover'; }
      else if (s.status === 'OUT_OF_STOCK') { main = 'out' + p; cls += ' status-outofstock'; }
      // v65 (your report): a store that refuses a check shows the LAST real answer and its age - not which browser was refused
      else if (s.last_good && s.last_good.high) { main = 'FOR SALE' + (s.last_good.price != null ? ' $' + s.last_good.price : '') + ' - over cap'; sub = timeAgo(s.last_good.at); cls += ' status-overcap'; tc = 'cover'; }
      else if (s.last_good) { main = (s.last_good.status === 'IN_STOCK' ? 'IN STOCK' : 'out') + (s.last_good.price != null ? ' $' + s.last_good.price : ''); sub = timeAgo(s.last_good.at); cls += s.last_good.status === 'IN_STOCK' ? ' status-instock' : ' status-outofstock'; }
      else if (s.status === 'BLOCKED') { main = 'no answer yet'; sub = 'store not answering'; cls += ' status-unknown'; tc = 'cunk'; }
      else { main = 'reading...'; cls += ' status-unknown'; }
      if (hasP && msrp && (s.status === 'IN_STOCK' || s.status === 'OUT_OF_STOCK')) {
        const d = (parseFloat(s.price) / msrp - 1) * 100;
        sub = Math.abs(d) < 0.5 ? '= MSRP' : (d > 0 ? '+' : '') + Math.round(d) + (d > 0 ? '% > MSRP' : '% < MSRP');
      }
      if (hasP && el.dataset.tcg && s.status !== 'INDEX') {
        const ti = MXLAST[el.dataset.tcg];
        const tm = ti && ti.status === 'INDEX' ? (ti.market != null ? ti.market : ti.price) : null;
        if (tm) { const dt = (parseFloat(s.price) / tm - 1) * 100; sub += (sub ? ' \u00b7 ' : '') + (Math.abs(dt) < 0.5 ? '= TCG' : (dt > 0 ? '+' : '') + Math.round(dt) + (dt > 0 ? '% > TCG' : '% < TCG')); }
      }
      if (s.status === 'IN_STOCK' || s.status === 'OUT_OF_STOCK' || s.status === 'INDEX') sub += (sub ? ' \u00b7 ' : '') + timeAgo(s.checked_at);
      // (v65: no browser names - only the answer, its price and how old it is)
    }
    const html = mxEsc(main) + (sub ? '<br><span class="mxsub">' + mxEsc(sub) + '</span>' : '');
    if (el.dataset.h !== html) { el.innerHTML = html; el.dataset.h = html; }
    el.className = cls;
    if (td) { td.classList.toggle('cin', tc === 'cin'); td.classList.toggle('cunk', tc === 'cunk'); td.classList.toggle('cover', tc === 'cover'); }
  });
}
document.addEventListener('change', e => {
  const a = e.target.dataset ? e.target.dataset.act : null;
  if (!a) return;
  if (a === 'prod') mxPost('product', {key: e.target.dataset.key, on: e.target.checked});
  else if (a === 'store') mxPost('store', {key: e.target.dataset.key, on: e.target.checked});
  else if (a === 'cell') mxPost('cell', {id: e.target.dataset.id, on: e.target.checked});
  else if (a === 'cap') mxPost('cap', {key: e.target.dataset.key, cap: e.target.value});
  else if (a === 'gwatch') mxPost('group', {group: e.target.dataset.g, on: e.target.checked});
});
document.addEventListener('input', e => {
  if (e.target.classList && e.target.classList.contains('mxurl')) MXOPEN[e.target.dataset.k] = e.target.value;
});
document.addEventListener('click', e => {
  const el = e.target.closest ? e.target.closest('[data-act]') : null;
  if (!el || el.tagName === 'INPUT' && el.type === 'checkbox') return;
  const a = el.dataset.act, d = el.dataset;
  if (a === 'signin') { mxBuyPost(d.s === 'done' ? {action: 'hide'} : {action: 'signin', tid: d.s}); return; }
  if (a === 'mode') { if (!el.disabled) mxModeSet([d.key], d.m); return; }
  if (a === 'hist') { mxHist(d.key); return; }
  if (a === 'histclose') { mxHistClose(); return; }
  if (a === 'unlock') { mxSay('Unlocked - back to normal.', true); mxBuyPost({action: 'armgroup', tids: d.tids.split(',')}); return; }
  if (a === 'onemore') {        // v112b: the same as the phone message's "Buy one more" button
    if (!confirm('Buy ONE MORE of ' + (d.name || 'this product').trim() + '? It was already bought once.')) return;
    mxBuyPost({action: 'onemore', tid: d.tid}).then(r => { const x = (r && r.result) || {}; if (x.ok) mxSay(x.text || 'Set to buy one more.', true); });
    return;
  }
  if (a === 'verifyopen') { MXVER[d.tid] = 1; mxOpenIn(d.url); if (MXBUY) mxBuy(MXBUY); return; }
  if (a === 'openin') { e.preventDefault(); mxOpenIn(d.url); return; }
  if (a === 'verify') { delete MXVER[d.tid]; mxBuyPost({action: d.a === 'yes' ? 'verify_yes' : 'verify_no', tid: d.tid}); mxSay(d.a === 'yes' ? 'Thanks - that link may be bought now.' : 'That square is switched off and never bought. Use "change link" to put in the right page.', d.a === 'yes'); return; }
  if (a === 'gmode') { if (!el.disabled) mxModeSet((MX ? MX.products : []).filter(q => (q.group || 'Other sets') === d.g).map(q => q.key), d.m, d.g); return; }
  if (a === 'gfold') { if (MXCOLL[d.g]) delete MXCOLL[d.g]; else MXCOLL[d.g] = 1; try { localStorage.setItem('rk_groups_folded', JSON.stringify(MXCOLL)); } catch (e2) {} mxDraw(); mxStatus(MXLAST); return; }
  if (a === 'buyx') {
    if (d.a === 'again' && !confirm('Buy ONE MORE of ' + (d.name || 'this product') + '? It was already bought once.')) return;
    if (d.a === 'markbought' && !confirm('You checked Amazon and this order WAS placed?')) return;
    if (d.a === 'marknot' && !confirm('You checked Amazon and there is NO order for it? (auto-buy can then be switched on again)')) return;
    mxBuyPost({action: d.a, tid: d.tid}); return;
  }
  if (a === 'addlink') { MXOPEN[d.k] = ''; mxDraw(); mxStatus(MXLAST); }
  else if (a === 'editlink') { MXOPEN[d.k] = d.url; mxDraw(); mxStatus(MXLAST); }
  else if (a === 'cancel') { delete MXOPEN[d.k]; mxDraw(); mxStatus(MXLAST); }
  else if (a === 'savelink') {
    const url = (MXOPEN[d.k] || '').trim();
    delete MXOPEN[d.k];
    const xtra = String(d.k || '').startsWith('am:'), lid = String(d.k || '').startsWith('ed:') ? String(d.k).slice(3) : '';
    mxPost('link', Object.assign({key: d.key, store: d.store, url: url}, xtra ? {extra: true} : {}, lid ? {id: lid} : {}));
  }
  else if (a === 'rmlink') { MXOPEN['rl:' + d.id] = true; mxDraw(); mxStatus(MXLAST); }
  else if (a === 'rmlink2') { delete MXOPEN['rl:' + d.id]; mxSay('Removing the link...', true); const td = el.closest('td'); if (td) td.style.opacity = '0.4'; mxPost('clearlink', {id: d.id}); }
  else if (a === 'extrasignin') { mxSay('Opening that browser on the store\'s sign-in page (on your screen). Sign in there, tick "Keep me signed in", then close it.', true); mxBuyPost({action: 'extrasignin', tid: d.k}); }
  else if (a === 'rightlink') { mxPost('rightlink', {id: d.id}); }
  else if (a === 'wronglink') { MXOPEN['wl:' + d.id] = true; mxDraw(); mxStatus(MXLAST); }
  else if (a === 'wronglink2') { delete MXOPEN['wl:' + d.id]; mxSay('Removing the wrong link and looking for the right one...', true); const td = el.closest('td'); if (td) td.style.opacity = '0.4'; mxPost('wronglink', {id: d.id}); }
  else if (a === 'rmprod') { MXOPEN['rp:' + d.key] = true; mxDraw(); mxStatus(MXLAST); }
  else if (a === 'rmprod2') { delete MXOPEN['rp:' + d.key]; mxPost('rmproduct', {key: d.key}); }
  else if (a === 'rmstore') { MXOPEN['rs:' + d.key] = true; mxDraw(); mxStatus(MXLAST); }
  else if (a === 'rmstore2') { delete MXOPEN['rs:' + d.key]; mxPost('rmstore', {key: d.key}); }
  else if (a === 'addprod') {
    mxPost('addproduct', {name: document.getElementById('mxNewName').value, kindlabel: document.getElementById('mxNewKind').value,
                          cap: document.getElementById('mxNewCap').value, link: document.getElementById('mxNewLink').value})
      .then(r => { if (r && r.ok) { for (const i of ['mxNewName', 'mxNewCap', 'mxNewLink', 'mxNewKind']) document.getElementById(i).value = ''; } });
  }
  else if (a === 'searchrow') { mxPost('searchrow', {key: d.key}); }
  else if (a === 'addstore') {
    mxPost('addstore', {name: document.getElementById('mxNewStore').value})
      .then(r => { if (r && r.ok) document.getElementById('mxNewStore').value = ''; });
  }
});
mxLoad();
</script>
"""
