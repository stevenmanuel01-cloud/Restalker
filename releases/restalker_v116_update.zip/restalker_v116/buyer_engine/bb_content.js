/* Restalker Best Buy checkout - page part (v56).
 * Runs on bestbuy.com pages inside Restalker's own buying browser. It never decides to buy: the background (bb_engine.js) asks it
 * to READ a page (product / cart / checkout / confirmation) or to press ONE named button, and every money rule is checked there.
 * Buttons are found by their visible words ("Add to Cart", "Checkout", "Place Your Order"), not by Best Buy's style names, which
 * change often. It never solves or gets around a human / identity check: such a page is only reported.
 * It never reads names, addresses or card numbers: only button words, prices, quantities and product names.
 */
'use strict';
(() => {
  if (globalThis.__RK_BB_CONTENT__) return;
  globalThis.__RK_BB_CONTENT__ = true;
  const norm = s => String(s || '').replace(/\s+/g, ' ').trim();
  const low = s => norm(s).toLowerCase();
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const money = s => { const m = String(s || '').replace(/,/g, '').match(/\$\s*(\d{1,6}(?:\.\d{2})?)/); return m ? Number(m[1]) : null; };
  const allMoney = s => [...String(s || '').replace(/,/g, '').matchAll(/\$\s*(\d{1,6}(?:\.\d{2})?)/g)].map(m => Number(m[1]));
  function shown(e) {
    if (!e || !e.getClientRects || !e.getClientRects().length) return false;
    const st = getComputedStyle(e);
    return st.visibility !== 'hidden' && st.display !== 'none' && Number(st.opacity || 1) > 0.05;
  }
  function label(e) { return norm(e.innerText || e.value || e.getAttribute('aria-label') || e.textContent || ''); }
  function clickables() { return [...document.querySelectorAll('button, a, input[type="submit"], input[type="button"], [role="button"]')].filter(shown); }
  function inRecs(e) {
    // carousels of OTHER products (recommendations, sponsored, recently viewed) are never used
    return !!e.closest('[class*="carousel" i], [data-testid*="carousel" i], [class*="recommend" i], [data-testid*="recommend" i], [aria-label*="sponsored" i], [class*="sponsored" i], [class*="recently" i]');
  }
  function button(re, {after = null, exclude = null} = {}) {
    const list = clickables().filter(e => re.test(low(label(e))) && !inRecs(e) && !(exclude && exclude(e)));
    if (after) {
      const later = list.filter(e => after.compareDocumentPosition(e) & Node.DOCUMENT_POSITION_FOLLOWING);
      if (later.length) return later[0];
    }
    return list[0] || null;
  }
  function disabled(e) { return !!(e && (e.disabled || e.getAttribute('aria-disabled') === 'true' || /disabled/i.test(e.className || ''))); }
  function press(e) { setTimeout(() => { try { e.scrollIntoView({block: 'center'}); } catch {} try { e.click(); } catch {} }, 30); }
  function bodyText() { return norm(document.body ? document.body.innerText : ''); }
  function challenge() {
    const t = low(bodyText()).slice(0, 20000);
    if (/\/identity\/(signin|verify|recovery|challenge)/i.test(location.pathname)) return 'Best Buy asks you to sign in or verify your account';
    if (/verify (that )?you are (a )?human|are you a robot|press (and|&) hold|unusual (activity|traffic)|access denied|request unsuccessful|reference #\d/.test(t)) return 'Best Buy shows a human / security check';
    return null;
  }
  async function until(fn, ms, every = 150) {
    const end = Date.now() + ms;
    for (;;) { const v = fn(); if (v) return v; if (Date.now() > end) return null; await sleep(every); }
  }
  // ---- the product page
  function pdpSku() {
    const t = bodyText();
    const m = t.match(/\bSKU:?\s*(\d{6,9})\b/i);
    if (m) return m[1];
    const h = document.documentElement.innerHTML;
    const counts = {};
    for (const x of h.matchAll(/"skuId"\s*:\s*"?(\d{6,9})"?/g)) counts[x[1]] = (counts[x[1]] || 0) + 1;
    const best = Object.entries(counts).sort((a, b) => b[1] - a[1])[0];
    return best ? best[0] : null;
  }
  function pdpPrice(h1) {
    const t = bodyText();
    let m = t.match(/your price for this item is \$\s*([\d,]+\.\d{2})/i);
    if (m) return Number(m[1].replace(/,/g, ''));
    for (const e of document.querySelectorAll('[aria-label*="price" i], [data-testid*="price" i], [class*="priceView" i], [class*="price-block" i], [class*="customer-price" i]')) {
      if (!shown(e) || inRecs(e)) continue;
      if (h1 && !(h1.compareDocumentPosition(e) & Node.DOCUMENT_POSITION_FOLLOWING)) continue;
      const v = money(e.getAttribute('aria-label') || '') ?? money(e.innerText);
      if (v) return v;
    }
    return null;
  }
  const BTN_IN = /^(add to cart|pre-?order|preorder|buy now)$/;
  const BTN_WAIT = /^please wait/;
  const BTN_OUT = /^(sold out|coming soon|unavailable nearby|check stores|not available|find a store|unavailable)$/;
  function pdpButton(h1) {
    const re = /^(add to cart|pre-?order|preorder|buy now|please wait.*|sold out|coming soon|unavailable nearby|check stores|not available|find a store|unavailable)$/;
    return button(re, {after: h1});
  }
  // v75 (your rules): SHIPPING is always chosen when the product page offers Pickup and Shipping (real bestbuy.com 2026-10-29: two
  // tiles role="radio", Pickup chosen by itself); and "Buy now" (it appears once Shipping is chosen; data-testid pdp-buy-now-<sku>)
  // goes straight to the checkout - it is used instead of Add to cart when it is there.
  async function pickShippingTile(atc) {
    let box = atc;
    for (let i = 0; box && box.parentElement && i < 8; i++) { const up = box.parentElement; if ((up.innerText || '').length > 3000) break; box = up; }
    const isShip = e => /^(shipping|ship to home|ship it|ship)\b/.test(low(label(e))) && !/not available|unavailable/.test(low(label(e)));
    const tiles = [...(box || document).querySelectorAll('[role="radio"], input[type="radio"], button, [role="button"], label')].filter(e => shown(e) && !inRecs(e));
    // (real bestbuy.com: the button's own box is tiny - the tiles are found on the page then, round choices only)
    const ship = tiles.find(isShip) || [...document.querySelectorAll('[role="radio"]')].find(e => shown(e) && !inRecs(e) && isShip(e));
    if (!ship) return {offered: false, pickupChosen: pickupChosen()};
    const onOf = e => !!e && (e.getAttribute('aria-checked') === 'true' || e.getAttribute('aria-pressed') === 'true' || e.checked === true ||
                     !!(e.querySelector && e.querySelector('input:checked')));
    // v75 (diagnostics 64: "Shipping could NOT be chosen" while the page DID switch to Shipping): the page draws the tiles anew after a
    // click, so the choice is read again from the page each time, never from the old element
    const now = () => onOf(ship) || [...document.querySelectorAll('[role="radio"], input[type="radio"]')].some(e => shown(e) && !inRecs(e) && isShip(e) && onOf(e));
    if (now()) return {offered: true, chosen: true, already: true};
    try { ship.click(); } catch {}
    await until(now, 5000);
    return {offered: true, chosen: now()};
  }
  function pickupChosen() {               // a Pickup choice that is ON (then Buy now would buy for pickup - never pressed)
    return [...document.querySelectorAll('[role="radio"], input[type="radio"]')].some(e => shown(e) && !inRecs(e) && /^(pickup|pick up|store pickup)\b/.test(low(e.type === 'radio' ? ((e.closest('label') || {}).innerText || '') : label(e))) &&
                                                                                  (e.getAttribute('aria-checked') === 'true' || e.checked === true));
  }
  function buyNowButton(h1) {
    const t = [...document.querySelectorAll('[data-testid^="pdp-buy-now"]')].find(e => shown(e) && !disabled(e));
    if (t) return t;
    const b = button(/^buy now$/, {after: h1});
    return b && !disabled(b) ? b : null;
  }
  function pdp() {
    const h1 = document.querySelector('h1');
    const b = pdpButton(h1);
    const words = b ? low(label(b)) : null;
    return {page: 'product', url: location.href, title: norm(h1 && h1.innerText), sku: pdpSku(), price: pdpPrice(h1), buyNow: !!buyNowButton(h1),
            button: words, buttonState: b && b.getAttribute('data-button-state'), enabled: !!b && !disabled(b),
            inStock: !!b && BTN_IN.test(words) && !disabled(b), queue: !!b && BTN_WAIT.test(words), soldOut: !!b && BTN_OUT.test(words),
            check: challenge(), ...shipInfo()};
  }
  // v59b: can it be SHIPPED? ("In store only" / "Shipping: Unavailable" items show an Add to Cart button too - for pickup)
  function shipInfo() {
    // the buy box only (the area around the product's own Add to Cart button) - never the recommendations further down
    const h1 = document.querySelector('h1'), b = pdpButton(h1);
    let box = b;
    for (let i = 0; box && box.parentElement && i < 8; i++) { const up = box.parentElement; if ((up.innerText || '').length > 2500) break; box = up; }
    const t = norm(box ? box.innerText : bodyText()).replace(/\s+/g, ' ');
    const storeOnly = /\bin[- ]store only\b|\bavailable (?:only )?in store\b|\bpickup only\b|\bnot available for shipping\b|\bshipping\s*[-:\u2013]?\s*(?:unavailable|not available)\b/i.test(t);
    const ships = /\bshipping\s*[-:\u2013]?\s*(?:free|\$\s*\d)|\bget it by\b|\bfree shipping\b/i.test(t);
    return {storeOnly, ships, fulfillment: (t.match(/(?:pickup|shipping|in[- ]store only)[^.]{0,60}/ig) || []).slice(0, 4)};
  }
  async function addToCart(maxQueueMs) {
    // press Add to Cart; if Best Buy puts the shopper in its queue ("Please Wait"), wait in line like a person and press again when it lets us
    const h1 = document.querySelector('h1');
    const end = Date.now() + Math.max(15000, maxQueueMs || 0);
    let pressed = 0, queued = false;
    while (Date.now() < end) {
      const c = challenge(); if (c) return {ok: false, check: c};
      // v83 (diagnostics 68: the Star Trek box pre-order at $479.99 was lost twice - Best Buy showed its "You're in line! Wait times vary"
      // window and the program read it as an error): while Best Buy's line window is up we wait in line like a person (never press again,
      // which could lose the place); when it lets us through, the button is pressed as usual
      if (inLine()) { queued = true; chrome.runtime.sendMessage({bbStatus: 'queue', words: 'in line'}).catch(() => {}); await sleep(1000); continue; }
      const b0 = pdpButton(h1), b = (b0 && /^buy now$/.test(low(label(b0))) && button(/^(add to cart|pre-?order|preorder)$/, {after: h1})) || b0;
      const w = b ? low(label(b)) : '';
      if (b && BTN_OUT.test(w)) return {ok: false, soldOut: true, words: w};
      if (added()) return {ok: true, queued, pressed};
      if (b && BTN_IN.test(w) && !disabled(b)) {
        if (pressed && Date.now() - lastPress < 6000) { await sleep(200); continue; }
        if (!pressed) await pickShippingTile(b);          // (v75: never added for store pickup)
        b.scrollIntoView({block: 'center'}); b.click(); pressed++; lastPress = Date.now();
        const ok = await until(() => added() || inLine() || (pdpButton(h1) && BTN_WAIT.test(low(label(pdpButton(h1))))) || cartError(), 8000);
        if (added()) return {ok: true, queued, pressed};
        if (inLine()) continue;
        const e = cartError(); if (e) return {ok: false, error: e};
        continue;
      }
      if (b && (BTN_WAIT.test(w) || disabled(b))) { queued = true; chrome.runtime.sendMessage({bbStatus: 'queue', words: w}).catch(() => {}); await sleep(1000); continue; }
      await sleep(300);
    }
    return {ok: false, error: queued ? 'still in Best Buy\'s queue when the waiting time ran out' : 'the Add to Cart button did not answer', queued};
  }
  let lastPress = 0;
  function added() {
    const t = low(bodyText()).slice(0, 60000);
    if (/added to (your )?cart|item added|1 item added|added to cart/.test(t) && button(/^(go to cart|view cart|checkout)$/)) return true;
    const n = document.querySelector('[data-testid*="cart-count" i], .dot, [class*="cart-count" i], [aria-label*="cart contains" i], [aria-label*="items in cart" i]');
    return !!(n && /\b[1-9]\d*\b/.test(n.getAttribute('aria-label') || n.innerText || '') && lastPress && /added/.test(t));
  }
  function inLine() {                     // v83: Best Buy's waiting-line window ("You're in line! Wait times vary based on product demand")
    const t = low(bodyText()).slice(0, 60000);
    return /you[\u2019']?re in line|you are in line|wait times vary based on (product )?demand|close wait modal/.test(t);
  }
  function cartError() {
    const t = low(bodyText()).slice(0, 60000);
    if (/you[\u2019']?re in line|you are in line|wait times vary based on (product )?demand/.test(t)) return null;      // (the line window: not an error)
    const m = t.match(/(something went wrong[^.]*|this item (is|was) (no longer|not) available[^.]*|limit (\d+ )?per (customer|order)[^.]*|unable to add[^.]*|item could not be added[^.]*)/);
    return m ? m[1].slice(0, 160) : null;
  }
  // ---- the cart
  function lineItems() {
    const rm = clickables().filter(e => /^(remove|remove item)$/.test(low(label(e))) || /^remove /.test(low(e.getAttribute('aria-label') || '')));
    const out = [];
    for (const b of rm) {
      let box = b, link = null;
      for (let i = 0; i < 10 && box && box !== document.body; i++) {
        box = box.parentElement;
        link = box && box.querySelector('a[href*="/product/"], a[href*="/site/"]');
        if (link) break;
      }
      if (!box || !link || out.some(o => o.box === box || o.box.contains(box) || box.contains(o.box))) continue;
      const t = norm(box.innerText);
      const q = box.querySelector('select[id*="quantity" i], select[aria-label*="quantity" i], select[name*="quantity" i], input[aria-label*="quantity" i], input[name*="quantity" i]');
      let qty = q ? Number(q.value) : null;
      if (!qty) { const m = t.match(/\b(?:qty|quantity):?\s*(\d+)\b/i); qty = m ? Number(m[1]) : null; }
      const sku = (t.match(/\bSKU:?\s*(\d{6,9})\b/i) || [])[1] || null;
      const prices = allMoney(t);
      out.push({box, remove: b, title: norm(link.innerText) || norm(link.getAttribute('aria-label')), href: link.getAttribute('href'), sku, qty,
                price: prices.length ? Math.max(...prices.filter(x => x > 0.5).slice(0, 3).concat([0])) || null : null});
    }
    return out;
  }
  function matches(item, want) {
    if (want.sku && item.sku) return String(item.sku) === String(want.sku);
    const t = low(item.title + ' ' + (item.href || ''));
    const toks = (want.tokens || []).map(low).filter(Boolean);
    if ((want.forbid || []).some(w => t.includes(low(w)))) return false;
    return toks.length > 0 && toks.every(k => k.split('|').some(x => t.includes(x) || t.includes(x.replace(/\s+/g, '-'))));
  }
  function cart(want) {
    const items = lineItems();
    const mine = items.filter(i => matches(i, want));
    const ship = fulfillment(mine[0] ? mine[0].box : document.body);
    return {page: 'cart', url: location.href, count: items.length, items: items.map(i => ({title: i.title.slice(0, 120), sku: i.sku, qty: i.qty, price: i.price, mine: matches(i, want)})),
            target: mine.length === 1 ? {title: mine[0].title.slice(0, 120), sku: mine[0].sku, qty: mine[0].qty, price: mine[0].price} : null,
            fulfillment: ship, checkout: !!button(/^(checkout|continue to checkout|proceed to checkout)$/), empty: /your cart is empty|cart is empty/.test(low(bodyText()).slice(0, 20000)),
            subtotal: rowAmount(/^(subtotal|item subtotal|items? subtotal|order subtotal)/), check: challenge()};
  }
  function fulfillment(box) {
    const opts = [...box.querySelectorAll('input[type="radio"]')].filter(r => r.closest('label') || r.id).map(r => {
      const lab = r.closest('label') || document.querySelector('label[for="' + CSS.escape(r.id) + '"]');
      return {r, words: low(lab ? lab.innerText : r.id)};
    });
    const ship = opts.find(o => /ship|deliver/.test(o.words)), pick = opts.find(o => /pick ?up|store/.test(o.words));
    return {ship: !!ship, shipChecked: !!(ship && ship.r.checked), pickup: !!pick, pickupChecked: !!(pick && pick.r.checked)};
  }
  async function chooseShipping(want, allowPickup) {
    const mine = lineItems().filter(i => matches(i, want))[0];
    const box = mine ? mine.box : document.body;
    const opts = [...box.querySelectorAll('input[type="radio"]')];
    const word = r => { const l = r.closest('label') || document.querySelector('label[for="' + CSS.escape(r.id || '_') + '"]'); return low(l ? l.innerText : r.id); };
    const ship = opts.find(r => /ship|deliver/.test(word(r)) && !r.disabled);
    if (ship) { if (!ship.checked) { ship.click(); await sleep(1500); } return {ok: true, how: 'shipping'}; }
    const pick = opts.find(r => /pick ?up|store/.test(word(r)) && !r.disabled);
    if (pick && allowPickup) { if (!pick.checked) { pick.click(); await sleep(1500); } return {ok: true, how: 'store pickup'}; }
    if (pick && !allowPickup) return {ok: false, error: 'only store pickup is offered (pickup is switched off in Restalker)'};
    const tile = await pickShippingTile(mine ? mine.box : null);          // (v75: Best Buy's newer pages: tiles role="radio")
    if (tile.offered) return tile.chosen ? {ok: true, how: 'shipping'} : {ok: false, error: 'Shipping could not be chosen'};
    const sw = clickables().find(e => !inRecs(e) && /^(change to|switch to|choose) shipping$|^ship (it )?instead$/.test(low(label(e))));
    if (sw) { sw.click(); await sleep(2500); return {ok: true, how: 'shipping (switched)'}; }
    return {ok: true, how: 'the page shows no choice (Best Buy\'s default)'};
  }
  async function removeMine(want) {
    const mine = lineItems().filter(i => matches(i, want))[0];
    if (!mine) return {ok: true, already: true};
    mine.remove.click();
    const gone = await until(() => !lineItems().some(i => matches(i, want)), 10000);
    return {ok: !!gone};
  }
  // ---- money rows (cart summary / checkout summary): find the label, read the amount on the same row
  function amountAt(t) {
    // the amount that directly follows a label: "$25.00", "FREE", "-$5.00" (a few characters of punctuation allowed in between)
    const m = String(t || '').match(/^[\s:.\-–]{0,4}(free\b|-?\s*\$\s*[\d,]+(?:\.\d{2})?)/i);
    if (!m) return null;
    if (/^free/i.test(m[1])) return 0;
    return Number(m[1].replace(/[\s$,]/g, ''));
  }
  function rowAmount(re) {
    const els = [...document.querySelectorAll('span, div, dt, dd, td, th, p, li, label, strong, b')].filter(e => shown(e) && e.children.length <= 3);
    for (const e of els) {
      const w = low(e.innerText);
      if (w.length > 60) continue;
      const m = w.match(re);
      if (!m || m.index !== 0) continue;
      const own = amountAt(w.slice(m[0].length));          // "ShippingFREE" / "Subtotal $323.88" in one element
      if (own !== null) return own;
      const lab = low(e.innerText);
      for (let row = e.parentElement, i = 0; row && i < 3; row = row.parentElement, i++) {
        const rt = low(row.innerText);
        if (rt.length > 140) break;
        const k = rt.indexOf(lab);
        if (k < 0) continue;
        const v = amountAt(rt.slice(k + lab.length));
        if (v !== null) return v;
      }
    }
    return null;
  }
  function cvvField() {
    return [...document.querySelectorAll('input#cvv, input#credit-card-cvv, input[name*="cvv" i], input[id*="cvv" i], input[autocomplete="cc-csc"], input[aria-label*="security code" i], input[placeholder*="security code" i], input[name*="securityCode" i], input[placeholder="CVV" i], input[placeholder*="CVV" i], input[aria-label*="CVV" i], input[aria-label*="CVC" i], input[placeholder*="CVC" i]')].filter(shown)[0] ||
      // v77 (Best Buy's checkout 2026-10-29: a "Security code" heading over a box that only says CVV): the box under that label
      (() => { for (const l of document.querySelectorAll('label, legend, span, div, p')) {
        if (!/^\s*(card )?security code\s*\*?\s*$/i.test(l.textContent || '') || !shown(l)) continue;
        const byFor = l.htmlFor ? document.getElementById(l.htmlFor) : null;
        const near = byFor || l.querySelector('input') || (l.parentElement && l.parentElement.querySelector('input:not([type=hidden]):not([type=checkbox]):not([type=radio])'));
        if (near && shown(near)) return near; } return null; })();
  }
  function setValue(el, v) {
    const d = Object.getOwnPropertyDescriptor(Object.getPrototypeOf(el), 'value');
    el.focus(); d.set.call(el, v);
    el.dispatchEvent(new Event('input', {bubbles: true})); el.dispatchEvent(new Event('change', {bubbles: true})); el.dispatchEvent(new Event('blur', {bubbles: true}));
  }
  function checkout(want) {
    const t = bodyText(), lt = low(t);
    const toks = (want.tokens || []).map(low).filter(Boolean);
    const identity = (want.sku && new RegExp('\\b' + want.sku + '\\b').test(t)) || (toks.length > 0 && toks.every(k => k.split('|').some(x => lt.includes(x))));
    const qtys = [...lt.matchAll(/\b(?:qty|quantity):?\s*(\d+)\b/g)].map(m => Number(m[1]));
    const sel = [...document.querySelectorAll('select[id*="quantity" i], select[aria-label*="quantity" i]')].map(s => Number(s.value));
    const allQ = qtys.concat(sel);
    const itemsN = (lt.match(/\b(?:items?|item subtotal)\s*\((\d+)\)/) || lt.match(/\((\d+) items?\)/) || [])[1];
    const place = button(/^(place (your )?order|place order|submit order)$/);
    const c = cvvField();
    const problems = [];
    // v78b (diagnostics 66, real target.com checkout: "no saved payment card" although Place your order was there and the order was fine
    // to place): a saved card shows as "ending in 1234", "*1234", "•••• 1234", "...1234" or with its expiry date; and the problem only
    // counts when the page really wants a card - a card-number box on the page, or the Place order button greyed out
    const cardShown = /ending in|(?:[*•·x]{1,}|\.{3})\s?\d{4}\b|\bexp(?:ires|iration|\.)?:?\s*\d{1,2}\s*\/\s*\d{2,4}/.test(lt);
    const cardBox = [...document.querySelectorAll('input[autocomplete="cc-number"], input[name*="cardnumber" i], input[name*="card-number" i], input[id*="cardnumber" i], input[aria-label*="card number" i], input[placeholder*="card number" i]')].some(shown);
    if (/add (a )?(new )?(payment|card)|enter (your )?card|select a payment/.test(lt) && !cardShown && (cardBox || !place || disabled(place))) problems.push('no saved payment card is selected');
    if (/add (a )?(new )?(shipping )?address|enter (your )?(shipping )?address/.test(lt) && !/ship to|shipping address/.test(lt)) problems.push('no shipping address is selected');
    // v75 (your rule: always shipping): an order set to store pickup is switched to shipping (or not placed)
    const pickup = /\bpick ?up (at|from|location|today|tomorrow|in store)\b|\bstore pickup\b|\bready for pickup\b/.test(lt) &&
                   !/\b(shipping address|ship to|shipped|arrives|delivery address|deliver(ed|y) to|get it by)\b/.test(lt);
    return {page: 'checkout', url: location.href, identity: !!identity, pickup,
            qtyOne: (allQ.length ? allQ.every(q => q === 1) : true) && (!itemsN || Number(itemsN) === 1), qtys: allQ.slice(0, 6), itemsN: itemsN ? Number(itemsN) : null,
            base: rowAmount(/^(item subtotal|subtotal|items? \(\d+\)|order subtotal|product subtotal)/), tax: rowAmount(/^(estimated |est\.? )?(sales )?tax/),
            shipping: rowAmount(/^(estimated )?(shipping|delivery)/), total: rowAmount(/^(order total|estimated total|total)\b/),
            fees: rowAmount(/(recycling|environmental|state) fee/), cvv: !!c, cvvFilled: !!(c && c.value && c.value.length >= 3),
            place: !!place, placeEnabled: !!place && !disabled(place), problems, check: challenge()};
  }
  function confirmation() {
    const t = bodyText(), lt = low(t).slice(0, 40000);
    const order = (t.match(/\b(BBY\d{2}-\d{6,})\b/) || t.match(/order (?:number|#):?\s*([A-Z0-9-]{8,})/i) || [])[1] || null;
    const ok = /thank you for (your|shopping)|your order (has been|is) (placed|confirmed)|order (is )?confirmed|we('ve| have) received your order/.test(lt) || /thank-?you|confirmation/i.test(location.pathname) && !!order;
    const failed = (lt.match(/(payment (was |has been )?declined[^.]*|unable to (process|place) (your )?(order|payment)[^.]*|there was a problem (with|placing) your order[^.]*|(this|an) item (in your cart )?is (no longer|not) available[^.]*|sold out[^.]{0,40}removed|(?:the )?(?:security code|cvv2?|cvc|card verification (?:code|number))[^.]{0,60}(?:incorrect|invalid|not valid|does(?:n't| not) match|wrong)[^.]*|(?:please )?enter a valid (?:security code|cvv2?|cvc)[^.]*|invalid (?:security code|cvv2?|cvc)[^.]*|(?:please )?(?:add|select|choose) a (?:payment|card|payment method)[^.]*)/) || [])[1] || null;   // (v77: + a security code the store turns down)
    return {page: 'confirm', url: location.href, placed: ok && !failed, order, failed: failed ? failed.slice(0, 160) : null, check: challenge()};
  }
  function fingerprint() {
    // what is on a page, WITHOUT personal data: button words, field names, headings and the url path (for the diagnostics)
    // v93 (diagnostics 76 carried a street address - the cart's "deliver to" button - and the greeting's name): such words are left out
    const personal = w => /\d{2,}\s+[a-z]/.test(w) || /\b(court|ct|street|st|avenue|ave|road|rd|drive|dr|lane|ln|way|blvd|boulevard|place|pl|circle|cir|terrace|parkway|pkwy|trail|hwy|highway|apt|suite|unit)\b.*\d|\d.*\b(court|street|avenue|road|drive|lane|way|boulevard|place|circle|terrace|parkway|trail|highway)\b/.test(w) || /@|\b\d{5}(?:-\d{4})?\b/.test(w);
    const masked = w => w.replace(/^(hi|hello|hey),?\s+[^,]+?(\s+account|$)/, '$1, [name]$2');
    const btns = [...new Set(clickables().map(e => masked(low(label(e)).slice(0, 40))).filter(w => w && w.length < 40 && !personal(w)))].slice(0, 60);
    const fields = [...document.querySelectorAll('input, select')].filter(shown).map(e => (e.type || e.tagName).toLowerCase() + ':' + (e.id || e.name || e.getAttribute('aria-label') || '').slice(0, 40)).slice(0, 40);
    const heads = [...document.querySelectorAll('h1, h2, h3')].filter(shown).map(e => norm(e.innerText).slice(0, 60)).filter(h => !personal(low(h))).slice(0, 15);
    const rows = ['subtotal', 'tax', 'shipping', 'total'].map(k => k + '=' + rowAmount(new RegExp('^(estimated |item |order )?' + k)));
    return {path: location.pathname, buttons: btns, fields, headings: heads, rows};
  }
  chrome.runtime.onMessage.addListener((m, sender, respond) => {
    if (!m || !m.bb) return;
    (async () => {
      try {
        // v62: this part is now loaded as the page starts (diagnostics 60: loaded "when the page is idle" it often never arrived in the
        // hidden buying window - "Receiving end does not exist"); every request still waits until the page's content is there
        if (document.readyState === 'loading' && m.bb !== 'ping') await new Promise(r => { document.addEventListener('DOMContentLoaded', r, {once: true}); setTimeout(r, 15000); });
        const want = m.want || {};
        if (m.bb === 'ping') return respond({ok: true, url: location.href, ready: document.readyState});
        if (m.bb === 'pdp') {
          await until(() => document.querySelector('h1') && pdpButton(document.querySelector('h1')) || challenge(), m.wait || 10000);
          let shipTile = null;
          if (m.ship && !challenge()) {            // (v75: Shipping chosen first; then Buy now may show up)
            const h1 = document.querySelector('h1');
            shipTile = await pickShippingTile(pdpButton(h1));
            if (shipTile.chosen && !shipTile.already) await until(() => buyNowButton(h1), 1500);
          }
          return respond({ok: true, ...pdp(), shipTile});
        }
        if (m.bb === 'buynow') {
          const h1 = document.querySelector('h1');
          const c0 = challenge(); if (c0) return respond({ok: false, check: c0});
          await pickShippingTile(pdpButton(h1));
          if (pickupChosen()) return respond({ok: false, error: 'Pickup is chosen and Shipping could not be chosen - Buy now not pressed'});
          const bn = buyNowButton(h1);
          if (!bn) return respond({ok: false, error: 'no Buy now button'});
          press(bn);
          return respond({ok: true, pressed: true});
        }
        if (m.bb === 'add') return respond(await addToCart(m.maxQueueMs || 0));
        if (m.bb === 'searchadd') {
          await until(() => button(/^add to cart$/), 10000);
          const b = clickables().filter(e => /^add to cart$/.test(low(label(e))) && !disabled(e))[0];
          if (!b) return respond({ok: false, error: 'no product with Add to Cart in the search results'});
          let box = b; for (let i = 0; i < 8 && box; i++) { box = box.parentElement; if (box && box.querySelector('a[href*="/product/"], a[href*="/site/"]')) break; }
          const link = box && box.querySelector('a[href*="/product/"], a[href*="/site/"]');
          const title = norm(link && link.innerText).slice(0, 120);
          lastPress = Date.now(); b.click();
          const ok = await until(() => added() || cartError(), 8000);
          return respond({ok: !!added(), title, href: link && link.getAttribute('href'), error: cartError()});
        }
        if (m.bb === 'cart') { await until(() => lineItems().length || /cart is empty/.test(low(bodyText())) || challenge(), m.wait || 10000); return respond({ok: true, ...cart(want)}); }
        if (m.bb === 'ship') return respond(await chooseShipping(want, !!m.allowPickup));
        if (m.bb === 'remove') return respond(await removeMine(want));
        if (m.bb === 'qty1') {
          const mine = lineItems().filter(i => matches(i, want))[0];
          const q = mine && mine.box.querySelector('select[id*="quantity" i], select[aria-label*="quantity" i], select[name*="quantity" i]');
          if (!q) return respond({ok: false, error: 'no quantity choice in the cart'});
          setValue(q, '1'); await sleep(2500);
          const again = lineItems().filter(i => matches(i, want))[0];
          return respond({ok: !!again && (again.qty === 1 || again.qty === null)});
        }
        if (m.bb === 'tocheckout') {
          // v78: the button may be drawn a moment after the cart items - waited for, up to 8 s
          const b = await until(() => { const x = button(/^(checkout|check ?out|continue to checkout|proceed to checkout)$/); return x && !disabled(x) ? x : null; }, m.wait || 8000);
          if (!b) return respond({ok: false, error: 'no Checkout button on the cart page'});
          respond({ok: true}); press(b); return;
        }
        if (m.bb === 'checkout') { await until(() => button(/^(place (your )?order|place order|submit order)$/) || challenge(), m.wait || 15000); await sleep(600); return respond({ok: true, ...checkout(want)}); }
        if (m.bb === 'cvv') {
          const c = cvvField(); if (!c) return respond({ok: false, error: 'no security-code field'});
          setValue(c, String(m.value || '')); await sleep(300);
          return respond({ok: !!(c.value && c.value.length >= 3)});
        }
        if (m.bb === 'place') {
          const b = button(/^(place (your )?order|place order|submit order)$/);
          if (!b || disabled(b)) return respond({ok: false, error: 'the Place Your Order button is missing or greyed out'});
          respond({ok: true, at: Date.now()}); press(b); return;
        }
        if (m.bb === 'confirm') return respond({ok: true, ...confirmation()});
        if (m.bb === 'text') { await sleep(m.settle || 0); return respond({ok: true, url: location.href, text: bodyText().slice(0, 300000)}); }
        if (m.bb === 'fingerprint') return respond({ok: true, ...fingerprint()});
        respond({ok: false, error: 'unknown request'});
      } catch (e) { try { respond({ok: false, error: String(e && e.message || e)}); } catch {} }
    })();
    return true;
  });
})();
