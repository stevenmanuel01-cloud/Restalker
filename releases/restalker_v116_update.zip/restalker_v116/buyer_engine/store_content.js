/* Restalker v68 - checkout page part for Target, Walmart and GameStop (made from Best Buy's bb_content.js; same requests, same answers).
 * Runs on those stores' pages inside Restalker's own buying browser. It never decides to buy: store_engine.js asks it to READ a page or
 * to press ONE named button (found by its visible words). Human / identity checks are only reported, never answered. It never reads
 * names, addresses or card numbers.
 */
'use strict';
(() => {
  if (globalThis.__RK_ST_CONTENT__) return;
  globalThis.__RK_ST_CONTENT__ = true;
  const STORE = /target\.com$/.test(location.hostname) ? 'Target' : /walmart\.com$/.test(location.hostname) ? 'Walmart' : 'GameStop';
  const norm = s => String(s || '').replace(/\s+/g, ' ').trim();
  const low = s => norm(s).toLowerCase();
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const money = s => { const m = String(s || '').replace(/,/g, '').match(/\$\s*(\d{1,6}(?:\.\d{2})?)/); return m ? Number(m[1]) : null; };
  const allMoney = s => [...String(s || '').replace(/,/g, '').matchAll(/\$\s*(\d{1,6}(?:\.\d{2})?)/g)].map(m => Number(m[1]));
  function shown(e) {
    if (!e || !e.getClientRects || !e.getClientRects().length) return false;
    const st = getComputedStyle(e);
    return st.visibility !== 'hidden' && st.display !== 'none' && Number(st.opacity || 1) > 0.05;
  }
  function label(e) { return norm(e.innerText || e.value || e.getAttribute('aria-label') || e.textContent || ''); }
  function clickables() { return [...document.querySelectorAll('button, a, input[type="submit"], input[type="button"], [role="button"]')].filter(shown); }
  function inRecs(e) {
    // carousels of OTHER products (recommendations, sponsored, recently viewed) are never used
    return !!e.closest('[class*="carousel" i], [data-testid*="carousel" i], [class*="recommend" i], [data-testid*="recommend" i], [aria-label*="sponsored" i], [class*="sponsored" i], [class*="recently" i]');
  }
  function button(re, {after = null, exclude = null} = {}) {
    const list = clickables().filter(e => re.test(low(label(e))) && !inRecs(e) && !(exclude && exclude(e)));
    if (after) {
      const later = list.filter(e => after.compareDocumentPosition(e) & Node.DOCUMENT_POSITION_FOLLOWING);
      if (later.length) return later[0];
    }
    return list[0] || null;
  }
  function disabled(e) { return !!(e && (e.disabled || e.getAttribute('aria-disabled') === 'true' || /disabled/i.test(e.className || ''))); }
  function press(e) { setTimeout(() => { try { e.scrollIntoView({block: 'center'}); } catch {} try { e.click(); } catch {} }, 30); }
  function bodyText() { return norm(document.body ? document.body.innerText : ''); }
  function challenge() {
    const t = low(bodyText()).slice(0, 20000);
    if (/\/(login|signin|sign-in|account\/login|identity|verify)/i.test(location.pathname) || /^login\./.test(location.hostname)) return STORE + ' asks you to sign in or verify your account';
    for (const d of document.querySelectorAll('[role="dialog"], [aria-modal="true"]')) {
      if (seen(d) && /sign in to your account|enter your password|sign in to continue|verify it'?s you/.test(low(d.innerText)) && d.querySelector('input[type="password"], input[type="email"], input[name*="email" i], input[name*="user" i]'))
        return STORE + ' asks you to sign in again (with your password) before checking out';
      // v78 (real target.com 2026-10-30, in your own Chrome too): Check out opens "Sign in to your account" with only CHOICES - Use a passkey /
      // Enter your password / Get a code (+ Keep me signed in) - no password box yet. Never answered: you are asked.
      if (seen(d) && /sign in to your account|sign in to continue|verify it'?s you/.test(low(d.innerText)) &&
          (d.querySelector('input[name*="keepMeSignedIn" i]') || /enter your password|use a passkey|get a code|keep me signed in/.test(low(d.innerText))))
        return STORE + ' asks you to sign in again before checking out (tick Keep me signed in)';
    }
    // v67: the strong words count anywhere; the weak ones ("please verify", "access denied", "unusual activity", "reference #") only on a
    // SHORT page - a real product page carries customer reviews, and a review saying "please verify the size" is not a human check
    if (/verify (that )?you are (a )?human|are you a robot|robot or human|press (and|&) hold|px-captcha/.test(t) || shownCheck()) return STORE + ' shows a human / security check';
    // v80 (diagnostics 67, GameStop to Firefox: "Sorry, you have been blocked" - Cloudflare's block page)
    if (/sorry, you have been blocked|you are unable to access|attention required! \| cloudflare|access to this page has been denied/.test(t.slice(0, 3000)) || /^(sorry, you have been blocked|access denied|attention required)/.test(low(document.title || ''))) return STORE + ' blocked this browser (block page)';
    const shop = !!document.querySelector('[itemprop="price"], [data-automation-id="atc"], [data-test="product-price"]') ||
                 clickables().some(e => /^(add to cart|continue to checkout|check ?out|place (your )?order|place order)$/.test(low(label(e))) || PLACE_RE.test(low(label(e))));
    if (!shop && t.length < 4000 && /unusual (activity|traffic)|access denied|request unsuccessful|reference #\d|please verify/.test(t)) return STORE + ' shows a human / security check';
    return null;
  }
  // v65 (diagnostics 61): Target's normal product page carries Google's INVISIBLE security frame ("recaptcha challenge expires in two
  // minutes" - hidden, 0 px). It was taken for a human check and every Target checkout stopped on the product page. Only a check
  // you could actually SEE counts: a visible, reasonably large frame, or the store's own check box.
  function seen(e) {
    try {
      const r = e.getBoundingClientRect(), cs = getComputedStyle(e);
      return r.width >= 120 && r.height >= 60 && cs.visibility !== 'hidden' && cs.display !== 'none' && Number(cs.opacity || 1) > 0.1 &&
             r.bottom > 0 && r.right > 0 && r.top < (innerHeight || 2000) + 400 && r.left < (innerWidth || 2000);
    } catch { return false; }
  }
  function shownCheck() {
    const px = document.querySelector('#px-captcha');
    if (px && (seen(px) || /\/blocked/.test(location.pathname))) return true;
    for (const f of document.querySelectorAll('iframe[src*="captcha" i], iframe[title*="challenge" i]')) if (seen(f)) return true;
    return false;
  }
  async function until(fn, ms, every = 150) {
    const end = Date.now() + ms;
    for (;;) { const v = fn(); if (v) return v; if (Date.now() > end) return null; await sleep(every); }
  }
  // ---- the product page
  // v69 (real gamestop.com): no h1 on the product page - the name is in h2.product-name
  function heading() {
    const h = document.querySelector('h1');
    if (h && norm(h.innerText)) return h;
    return [...document.querySelectorAll('[itemprop="name"], h2.product-name, .product-name, [class*="product-name" i], [data-test="product-title"], [class*="product-title" i]')].find(e => shown(e) && norm(e.innerText).length > 5) || h || null;
  }
  // v69 (real gamestop.com): the product page says item 20035029, the cart says 446237 (the same item) - both are known
  function pdpSkuAlt() {
    const out = [];
    const b = document.querySelector('.js-add-to-cart[data-gtmdata], [data-gtmdata*="productInfo"]');
    try { const g = JSON.parse(b.getAttribute('data-gtmdata')); if (g && g.productInfo) { if (g.productInfo.sku) out.push(String(g.productInfo.sku)); if (g.productInfo.productID) out.push(String(g.productInfo.productID)); } } catch {}
    const pid = document.querySelector('.js-add-to-cart[data-pid]');
    if (pid) out.push(String(pid.getAttribute('data-pid')));
    return [...new Set(out)];
  }
  function pdpSku() {
    // the store's own product number: Target TCIN (/A-12345678), Walmart item id (/ip/name/12345), GameStop (/12345.html)
    const u = location.pathname;
    const m = u.match(/\/A-(\d{6,})/) || u.match(/\/ip\/(?:[^/]+\/)?(\d{5,})/) || u.match(/\/(\d{5,})\.html/) || u.match(/\/products\/[^/]*\/(\d{5,})/);
    if (m) return m[1];
    const t = bodyText().match(/\b(?:TCIN|Item #|SKU|Item number):?\s*(\d{5,})\b/i);
    return t ? t[1] : null;
  }
  function pdpPrice(h1) {
    const t = bodyText();
    let m = t.match(/your price for this item is \$\s*([\d,]+\.\d{2})/i);
    if (m) return Number(m[1].replace(/,/g, ''));
    // v68 (real walmart.com): the page's OWN main price first ("Now $8.95" in itemprop="price"); the color / size choices carry
    // their own prices ("variant-tile-price-text-...": $15.99, $14.00 ...) and are never read as this product's price
    const variant = e => !!e.closest('[data-testid*="variant" i], [class*="variant" i], [data-testid*="swatch" i], [class*="swatch" i]');
    for (const sel of ['[itemprop="price"]', '[data-seo-id="hero-price"]', '[data-test="product-price"]', '[data-test="module-product-detail-price-v2"]', '[data-test="price-cdui"]', '[data-testid="price-wrap"]', '[data-testid="customer-price"]']) {
      for (const e of document.querySelectorAll(sel)) {
        if (!shown(e) || inRecs(e) || variant(e)) continue;
        if (h1 && !(h1.compareDocumentPosition(e) & Node.DOCUMENT_POSITION_FOLLOWING)) continue;
        const v = money(e.getAttribute('aria-label') || '') ?? money(e.innerText);
        if (v) return v;
      }
    }
    for (const e of document.querySelectorAll('[data-test="product-price"], [itemprop="price"], [data-testid*="price" i], [data-automation-id*="price" i], [aria-label*="price" i], [class*="actual-price" i], [class*="price-block" i], [class*="primary-price" i]')) {
      if (!shown(e) || inRecs(e) || variant(e)) continue;
      if (h1 && !(h1.compareDocumentPosition(e) & Node.DOCUMENT_POSITION_FOLLOWING)) continue;
      const v = money(e.getAttribute('aria-label') || '') ?? money(e.innerText);
      if (v) return v;
    }
    return null;
  }
  const BTN_IN = /^(add to cart|add to cart - ship|ship it|pre-?order( now)?|preorder|buy now)$/;
  const BTN_WAIT = /^please wait/;
  const BTN_OUT = /^(sold out|out of stock|coming soon|not available|unavailable|notify me|notify me when (it'?s )?available|get in-stock alert|get in stock alert)$/;
  // v68 (real walmart.com, 2026-10-29): every "Add to cart" button carries the name of ITS product in its description ("Add to cart -
  // Dragon Shield ... Gooseberry"); with our item already in the cart, the first "Add to cart" on the page was a SPONSORED product's.
  // A button or quantity control that names a different product is never used.
  function sameName(x, h1) {
    // the WHOLE name must be this product's (review: a 30-letter start matched another color of the same sleeves)
    const key = v => low(v).replace(/[^a-z0-9.\u2026]+/g, ' ').trim();
    const t = key(h1 && h1.innerText), y = key(x);
    if (!t || !y) return true;
    if (t === y) return true;
    const ws = v => [...new Set(v.split(' ').filter(Boolean))].sort().join(' ');
    return ws(t) === ws(y);                              // (same words, other order / punctuation) - never a shortened name
  }
  function namesOther(e, h1) {
    const m = low(e.getAttribute('aria-label') || '').match(/^(?:add to cart|add to bag|pre-?order|preorder|buy now)\s*(?:[-\u2013:]|for\b)?\s*(.+)$/);
    return !!(m && h1 && !sameName(m[1], h1));
  }
  function pdpButton(h1) {
    const re = /^(add to cart|add to cart - ship|ship it|pre-?order( now)?|preorder|buy now|please wait.*|sold out|out of stock|coming soon|not available|unavailable|notify me|notify me when (it'?s )?available|get in-stock alert|get in stock alert)$/;
    return button(re, {after: h1, exclude: e => namesOther(e, h1)});
  }
  // v75 (your rule): "Buy now" goes straight to the checkout - used instead of Add to cart when the product's own box has it
  function buyNowButton(h1) {
    const t = [...document.querySelectorAll('[data-testid*="buy-now" i], [data-automation-id*="buy-now" i]')].find(e => shown(e) && !disabled(e) && !inRecs(e) && /^buy now\b/.test(low(label(e))) && !namesOther(e, h1));
    if (t) return t;
    const b = button(/^buy now$/, {after: h1, exclude: e => namesOther(e, h1)});
    return b && !disabled(b) ? b : null;
  }
  function pickupChosen() {               // v75: a Pickup choice that is ON (then Buy now would buy for pickup - never pressed)
    return [...document.querySelectorAll('[role="radio"], input[type="radio"]')].some(e => shown(e) && !inRecs(e) && /^(pickup|pick up|store pickup)\b/.test(low(e.type === 'radio' ? ((e.closest('label') || {}).innerText || '') : label(e))) &&
                                                                                  (e.getAttribute('aria-checked') === 'true' || e.checked === true));
  }
  function pdpAddButton(h1) {             // (Add to cart itself - never "Buy now" by mistake)
    return button(/^(add to cart|add to cart - ship|ship it|pre-?order( now)?|preorder)$/, {after: h1, exclude: e => namesOther(e, h1)});
  }
  function pdp() {
    const h1 = heading();
    const b = pdpButton(h1);
    const words = b ? low(label(b)) : null;
    return {page: 'product', url: location.href, title: norm(h1 && h1.innerText), sku: pdpSku(), skuAlt: pdpSkuAlt(), price: pdpPrice(h1), buyNow: !!buyNowButton(h1),
            button: words, buttonState: b && b.getAttribute('data-button-state'), enabled: !!b && !disabled(b),
            inStock: !!b && BTN_IN.test(words) && !disabled(b), queue: !!b && BTN_WAIT.test(words), soldOut: !!b && BTN_OUT.test(words),
            inCart: !b && becameStepper(h1),       // v67: Walmart shows "- 1 +" instead of Add to cart when it is already in the cart
            vis: document.visibilityState,        // v68: is the page drawn (a page that is not drawn may not answer its buttons)
            check: challenge(), ...shipInfo()};
  }
  // v59b: can it be SHIPPED? ("In store only" / "Shipping: Unavailable" items show an Add to Cart button too - for pickup)
  function shipInfo() {
    // the buy box only (the area around the product's own Add to Cart button) - never the recommendations further down
    const h1 = heading(), b = pdpButton(h1);
    let box = b;
    for (let i = 0; box && box.parentElement && i < 8; i++) { const up = box.parentElement; if ((up.innerText || '').length > 2500) break; box = up; }
    const t = norm(box ? box.innerText : bodyText()).replace(/\s+/g, ' ');
    const storeOnly = /\bin[- ]store only\b|\bavailable (?:only )?in store\b|\bpickup only\b|\bnot available for shipping\b|\bshipping\s*[-:\u2013]?\s*(?:unavailable|not available)\b/i.test(t);
    const ships = /\bshipping\s*[-:\u2013]?\s*(?:free|\$\s*\d)|\bget it by\b|\bfree shipping\b/i.test(t);
    return {storeOnly, ships, fulfillment: (t.match(/(?:pickup|shipping|in[- ]store only)[^.]{0,60}/ig) || []).slice(0, 4)};
  }
  // v67: how many items the store's own header says are in the cart (Walmart "Cart contains 2 items", Target "cart, 2 items", ...)
  function cartCount() {
    for (const e of document.querySelectorAll('a[href*="/cart"], button[aria-label*="cart" i], [data-testid*="cart" i], [data-automation-id*="cart" i], [class*="cart-count" i], [class*="minicart" i]')) {
      const t = low((e.getAttribute('aria-label') || '') + ' ' + (e.innerText || ''));
      const m = t.match(/cart (?:contains|has|,)?\s*(\d+)\s*items?/) || t.match(/(\d+)\s*items? in (?:your |the )?cart/) || t.match(/^\s*cart\s*(\d+)\s*$/) || t.match(/^\s*(\d+)\s*cart\s*$/) || (e.matches('[class*="cart-count" i], [class*="minicart-quantity" i]') ? t.match(/^\s*(\d+)\s*$/) : null);
      if (m) return Number(m[1]);
    }
    return null;
  }
  // v67: Walmart (and others) do not say "added": the Add to cart button turns into a quantity control ("- 1 +", "Decrease quantity ...")
  function becameStepper(h1) {
    const b = pdpButton(h1);
    if (b && BTN_IN.test(low(label(b)))) return false;
    return clickables().some(e => {
      if (inRecs(e)) return false;
      const a = low((e.getAttribute('aria-label') || '') + ' ' + label(e));
      if (!/decrease quantity|increase quantity|remove one|add one|current quantity|quantity 1\b/.test(a)) return false;
      const m = low(e.getAttribute('aria-label') || '').match(/(?:decrease|increase) quantity,?\s+(.+?)(?:,\s*current quantity.*)?$/);
      return !m || sameName(m[1], h1);       // (v68: the quantity control of THIS product, not of a sponsored one)
    });
  }
  async function addToCart(maxQueueMs) {
    // press Add to Cart ONCE; if Best Buy puts the shopper in its queue ("Please Wait"), wait in line like a person and press when it lets us.
    // v67 (Walmart): success is the store's own sign - an "added" message, the cart count going up, or the button turning into a quantity
    // control. No sign within 15 s but no error either: the cart page (read next) decides. The button is NEVER pressed a second time
    // (a second press would put 2 in the cart).
    const h1 = heading();
    const end = Date.now() + Math.max(15000, maxQueueMs || 0);
    let pressed = 0, queued = false;
    while (Date.now() < end) {
      const c = challenge(); if (c) return {ok: false, check: c};
      const b0 = pdpButton(h1), b = (b0 && /^buy now$/.test(low(label(b0))) && pdpAddButton(h1)) || b0;
      const w = b ? low(label(b)) : '';
      if (b && BTN_OUT.test(w)) return {ok: false, soldOut: true, words: w};
      if (pressed && added()) return {ok: true, queued, pressed};
      if (b && BTN_IN.test(w) && !disabled(b) && !pressed) {
        await pickShippingTile(b);
        const before = cartCount();
        b.scrollIntoView({block: 'center'}); b.click(); pressed++; lastPress = Date.now();
        const sign = await until(() => added() || becameStepper(h1) || (before !== null && cartCount() !== null && cartCount() > before) || cartError() || challenge(), 6000);      // (v70b: real stores answer in 1-2 s; no answer -> the cart decides)
        const e = cartError(); if (e) return {ok: false, error: e};
        const c2 = challenge(); if (c2) return {ok: false, check: c2};
        return {ok: true, queued, pressed, confirmed: !!sign, vis: document.visibilityState,
                how: added() ? 'message' : becameStepper(h1) ? 'quantity control' : sign ? 'cart count' : 'no sign - the cart decides'};
      }
      if (pressed) return {ok: true, queued, pressed, confirmed: false, how: 'no sign - the cart decides'};
      if (b && (BTN_WAIT.test(w) || disabled(b))) { queued = true; chrome.runtime.sendMessage({bbStatus: 'queue', words: w}).catch(() => {}); await sleep(1000); continue; }
      await sleep(300);
    }
    return {ok: false, error: queued ? 'still in Best Buy\'s queue when the waiting time ran out' : 'the Add to Cart button did not answer', queued};
  }
  let lastPress = 0;
  // v67 (your rule: never store pickup): Walmart's product page has "Shipping / Pickup / Delivery" choices next to Add to cart, and the
  // item goes into the cart with the chosen one. Shipping is chosen when it is offered and not chosen yet.
  async function pickShippingTile(atc) {
    let box = atc;
    for (let i = 0; box && box.parentElement && i < 8; i++) { const up = box.parentElement; if ((up.innerText || '').length > 3000) break; box = up; }
    const isShip = e => /^(shipping|ship to home|ship it)\b/.test(low(label(e))) && !/not available|unavailable/.test(low(label(e)));
    const tiles = [...(box || document).querySelectorAll('button, [role="radio"], [role="button"], input[type="radio"], label')].filter(e => shown(e) && !inRecs(e));
    const ship = tiles.find(isShip) || [...document.querySelectorAll('[role="radio"]')].find(e => shown(e) && !inRecs(e) && isShip(e));   // (v75)
    if (!ship) return false;
    const onOf = e => !!e && (e.getAttribute('aria-checked') === 'true' || e.getAttribute('aria-pressed') === 'true' || e.checked === true ||
                     /selected|active|checked/.test(String(e.className || '')) || !!(e.querySelector && e.querySelector('input:checked')));
    // (v75: read again from the page each time - the page may draw the choice anew after the click)
    const on = () => onOf(ship) || [...document.querySelectorAll('[role="radio"], input[type="radio"]')].some(e => shown(e) && !inRecs(e) && isShip(e) && onOf(e));
    if (on()) return false;                 // (already Shipping - nothing pressed, no waiting)
    try { ship.click(); } catch {}
    await until(on, 2500);
    return true;
  }
  function added() {
    const t = low(bodyText()).slice(0, 60000);
    if (/added to (your )?cart|item added|1 item added|added to cart/.test(t) && button(/^(go to cart|view cart|checkout|check ?out|view cart (&|and) check ?out|continue to cart|view cart & checkout)$/)) return true;
    const n = document.querySelector('[data-testid*="cart-count" i], .dot, [class*="cart-count" i], [aria-label*="cart contains" i], [aria-label*="items in cart" i]');
    return !!(n && /\b[1-9]\d*\b/.test(n.getAttribute('aria-label') || n.innerText || '') && lastPress && /added/.test(t));
  }
  function cartError() {
    const t = low(bodyText()).slice(0, 60000);
    const m = t.match(/(something went wrong[^.]*|this item (is|was) (no longer|not) available[^.]*|limit (\d+ )?per (customer|order)[^.]*|unable to add[^.]*|item could not be added[^.]*)/);
    return m ? m[1].slice(0, 160) : null;
  }
  // ---- the cart
  // v67: Walmart / Target list "Saved for later" items under the cart, with their own Remove buttons - they are NOT in the cart
  function savedForLater() {
    return [...document.querySelectorAll('h1, h2, h3, h4, [role="heading"], button, span, div')].find(e => e.children.length <= 2 && /^saved for later\b|^save for later \(\d+\)|^saved items\b/.test(low(e.innerText || ''))) || null;
  }
  function stepperQty(box) {
    for (const e of box.querySelectorAll('[aria-label], input[type="number"], input[inputmode="numeric"]')) {
      const a = low(e.getAttribute('aria-label') || '');
      let m = a.match(/current quantity (?:is )?(\d+)/) || a.match(/quantity:? (\d+)\b/) || a.match(/qty:? (\d+)\b/);
      if (m) return Number(m[1]);
      if (e.matches('input') && /^\d+$/.test(String(e.value || ''))) return Number(e.value);
    }
    return null;
  }
  function lineItems() {
    const sfl = savedForLater();
    const rm = clickables().filter(e => /^(remove|remove item|delete)$/.test(low(label(e))) || /^(remove|delete) /.test(low(e.getAttribute('aria-label') || '')))
                           .filter(e => !(sfl && (sfl.compareDocumentPosition(e) & Node.DOCUMENT_POSITION_FOLLOWING)));
    const out = [];
    for (const b of rm) {
      let box = b, link = null;
      for (let i = 0; i < 10 && box && box !== document.body; i++) {
        box = box.parentElement;
        link = box && box.querySelector('a[href*="/p/"], a[href*="/ip/"], a[href*="/products/"], a[href*="/product/"]');
        if (link) break;
      }
      if (!box || !link || out.some(o => o.box === box || o.box.contains(box) || box.contains(o.box))) continue;
      const t = norm(box.innerText);
      const q = box.querySelector('select[id*="quantity" i], select[aria-label*="quantity" i], select[name*="quantity" i], input[aria-label*="quantity" i], input[name*="quantity" i]');
      let qty = q ? Number(q.value) : null;
      if (!qty) qty = stepperQty(box);
      if (!qty) { const sq = [...box.querySelectorAll('select')].find(x => /^\d+$/.test(String(x.value || ''))); if (sq) qty = Number(sq.value); }
      if (!qty) { const m = t.match(/\b(?:qty|quantity):?\s*(\d+)\b/i); qty = m ? Number(m[1]) : null; }
      const h = link.getAttribute('href') || '';
      const sku = (h.match(/\/A-(\d{6,})/) || h.match(/\/ip\/(?:[^/]+\/)?(\d{5,})/) || h.match(/\/(\d{5,})\.html/) || [])[1] || null;
      // v93/v94 (diagnostics 76: a Walmart cart line of $644.88 was read as "$64488.00" - Walmart draws the cents apart, in small raised
      // digits). The line's OWN price, in order of trust: "current price $X.XX" (the screen-reader words), then the line's price boxes,
      // then amounts in its words - never a was / save / shipping / fee / per-unit amount, never a crossed-out one, and only WITH cents
      // ("$644" + "88" drawn apart counts as $644.88). Nothing for sure -> no price (the checkout then reads the price again; never a guess).
      const tc = norm(box.textContent || '');
      const lbl = [...box.querySelectorAll('[aria-label]')].map(e => e.getAttribute('aria-label') || '').filter(x => /\$/.test(x)).join(' | ');
      const NOTMINE_BEFORE = /(was|save|saved|savings|you save|shipping|ship|delivery|fee|fees|deposit|list|reg\.?|regular|compare|off|discount|protection|plan|warranty)\s*(price)?\s*:?\s*-?\s*$/i;
      const NOTMINE_AFTER = /^\s*(\/|per\b|each\b|ea\b|off\b|\/oz|\/ct|\/count|savings)/i;
      const amounts = x => {
        const str = String(x || '').replace(/,/g, ''), out2 = [];
        for (const m of str.matchAll(/\$\s*(\d{1,6})(?:\.(\d{2})|\s+(\d{2}))(?![\d.])/g)) {
          const before = str.slice(Math.max(0, m.index - 28), m.index), after = str.slice(m.index + m[0].length, m.index + m[0].length + 12);
          if (NOTMINE_BEFORE.test(before) || NOTMINE_AFTER.test(after) || /[-\u2212\u2013]\s*$/.test(before)) continue;   // (v94: "-$40.00" is a saving)
          out2.push(Number(m[1] + '.' + (m[2] || m[3])));
        }
        return out2;
      };
      const curRx = [/current price:?\s*\$\s*([\d,]+\.\d{2})/i, /\bnow\s*\$\s*([\d,]+\.\d{2})/i];
      let cur = null;
      for (const src of [t, tc, lbl]) { for (const rx of curRx) { cur = cur || String(src).match(rx); } }
      const struck = e => !!e.closest('s, del, strike, [class*="strike" i], [class*="was-price" i], [data-testid*="was" i]');
      let prices = [];
      for (const e of box.querySelectorAll('[data-testid*="price" i], [data-automation-id*="price" i], [itemprop="price"], [class*="price" i]')) {
        if (struck(e) || /was|save|shipping|per |each|\/oz|\/ct/i.test(e.textContent || '') || /sav|discount|unit|strike|was|old|list/i.test(String(e.className || '') + ' ' + (e.getAttribute('data-testid') || ''))) continue;
        let v = amounts(norm(e.textContent || ''));
        if (!v.length) {               // "$644" and "88" in two boxes side by side inside the price box
          const kids = [...e.querySelectorAll('span, sup, div')];
          for (let k = 0; k + 1 < kids.length && !v.length; k++) {
            const m = norm(kids[k].textContent || '').match(/^\$\s*([\d,]{1,7})$/), c2 = norm(kids[k + 1].textContent || '').match(/^\.?(\d{2})$/);
            if (m && c2) v = [Number(m[1].replace(/,/g, '') + '.' + c2[1])];
          }
        }
        prices.push(...v);
        if (prices.length >= 3) break;
      }
      // (v94: from the words alone only ONE clear amount counts - two different ones and no price box = not sure = no price)
      const one = v => (new Set(v.map(x => x.toFixed(2)))).size === 1 ? v.slice(0, 1) : [];
      if (!prices.length) prices = one(amounts(t));
      if (!prices.length) prices = one(amounts(tc));
      if (!prices.length) prices = one(amounts(lbl));
      if (!prices.length) {          // "$644" and "88" in two boxes side by side anywhere in the line (not crossed out) -> $644.88
        for (const e of box.querySelectorAll('span, div, sup')) {
          if (struck(e)) continue;
          const own = norm(e.textContent || ''), nx = e.nextElementSibling;
          const m = own.match(/^\$\s*([\d,]{1,7})$/), c2 = nx ? norm(nx.textContent || '').match(/^\.?(\d{2})$/) : null;
          if (m && c2) { prices.push(Number(m[1].replace(/,/g, '') + '.' + c2[1])); if (prices.length >= 3) break; }
        }
      }
      out.push({box, remove: b, title: norm(link.innerText) || norm(link.getAttribute('aria-label')), href: link.getAttribute('href'), sku, qty,
                seller: ((t.match(/\b(?:sold (?:and shipped )?by|sold by)\s+([^\n|]{2,40}?)(?=\s{2}|\s*(?:\||$|fulfilled|shipped|free|arrives|\$))/i) || [])[1] || '').trim().slice(0, 40) || null,
                price: cur ? Number(cur[1].replace(/,/g, '')) : (prices.length ? Math.max(...prices.filter(x => x > 0.5).slice(0, 3).concat([0])) || null : null)});
    }
    return out;
  }
  function matches(item, want) {
    if (want.sku && item.sku) return String(item.sku) === String(want.sku) || (want.skuAlt || []).map(String).includes(String(item.sku));
    const t = low(item.title + ' ' + (item.href || ''));
    const toks = (want.tokens || []).map(low).filter(Boolean);
    if ((want.forbid || []).some(w => t.includes(low(w)))) return false;
    return toks.length > 0 && toks.every(k => k.split('|').some(x => t.includes(x) || t.includes(x.replace(/\s+/g, '-'))));
  }
  function cart(want) {
    const items = lineItems();
    const mine = items.filter(i => matches(i, want));
    const ship = fulfillment(mine[0] ? mine[0].box : document.body);
    return {page: 'cart', url: location.href, count: items.length, items: items.map(i => ({title: i.title.slice(0, 120), sku: i.sku, qty: i.qty, price: i.price, mine: matches(i, want)})),
            target: mine.length === 1 ? {title: mine[0].title.slice(0, 120), sku: mine[0].sku, qty: mine[0].qty, price: mine[0].price} : null,
            fulfillment: ship, checkout: !!button(/^(checkout|check ?out|continue to checkout|proceed to checkout|checkout now|i'm ready to check out)$/), empty: /your cart is empty|cart is empty/.test(low(bodyText()).slice(0, 20000)),
            subtotal: rowAmount(/^(subtotal|item subtotal|items? subtotal|order subtotal)/), check: challenge()};
  }
  function fulfillment(box) {
    const opts = [...box.querySelectorAll('input[type="radio"]')].filter(r => r.closest('label') || r.id).map(r => {
      const lab = r.closest('label') || document.querySelector('label[for="' + CSS.escape(r.id) + '"]');
      return {r, words: low(lab ? lab.innerText : r.id)};
    });
    const ship = opts.find(o => /ship|deliver/.test(o.words)), pick = opts.find(o => /pick ?up|store/.test(o.words));
    return {ship: !!ship, shipChecked: !!(ship && ship.r.checked), pickup: !!pick, pickupChecked: !!(pick && pick.r.checked)};
  }
  async function chooseShipping(want, allowPickup) {
    const mine = lineItems().filter(i => matches(i, want))[0];
    const box = mine ? mine.box : document.body;
    const opts = [...box.querySelectorAll('input[type="radio"]')];
    const word = r => { const l = r.closest('label') || document.querySelector('label[for="' + CSS.escape(r.id || '_') + '"]'); return low(l ? l.innerText : r.id); };
    const ship = opts.find(r => /ship|deliver/.test(word(r)) && !r.disabled);
    if (ship) { if (!ship.checked) { ship.click(); await sleep(1500); } return {ok: true, how: 'shipping'}; }
    const pick = opts.find(r => /pick ?up|store/.test(word(r)) && !r.disabled);
    if (pick && allowPickup) { if (!pick.checked) { pick.click(); await sleep(1500); } return {ok: true, how: 'store pickup'}; }
    if (pick && !allowPickup) return {ok: false, error: 'only store pickup is offered (pickup is switched off in Restalker)'};
    // v67: Walmart's cart switch is made of BUTTONS ("Pickup / Delivery / Shipping"), not round choices - Shipping is pressed if offered
    const tb = clickables().filter(e => !inRecs(e) && /^shipping$/.test(low(label(e))));
    for (const e of tb) {
      if (e.getAttribute('aria-pressed') === 'false' || e.getAttribute('aria-checked') === 'false' || e.getAttribute('aria-selected') === 'false') {
        e.click(); await sleep(2000); return {ok: true, how: 'shipping (the cart\'s switch)'};
      }
      if (e.getAttribute('aria-pressed') === 'true' || e.getAttribute('aria-checked') === 'true' || e.getAttribute('aria-selected') === 'true') return {ok: true, how: 'shipping (already chosen)'};
    }
    // v75 (your rule: always shipping): tiles ("Shipping – FREE ..." role="radio") and "Change to shipping" buttons
    const tiles = [...document.querySelectorAll('[role="radio"]')].filter(e => shown(e) && !inRecs(e) && /^(shipping|ship to home|ship it)\b/.test(low(label(e))));
    for (const e of tiles) {
      if (e.getAttribute('aria-checked') === 'true') return {ok: true, how: 'shipping (already chosen)'};
      e.click(); await until(() => e.getAttribute('aria-checked') === 'true', 2500); return {ok: true, how: 'shipping (tile)'};
    }
    const sw = clickables().find(e => !inRecs(e) && /^(change to|switch to|ship it instead|choose) shipping$|^ship (it )?instead$/.test(low(label(e))));
    if (sw) { sw.click(); await sleep(2500); return {ok: true, how: 'shipping (switched)'}; }
    return {ok: true, how: 'the page shows no choice (the store\'s default)'};
  }
  // v93: the lines of THIS product that are over the cap (or whose price cannot be read) are taken out of the cart - one line of it
  // (the cheapest within the cap) may stay. Walmart lists one product once per seller.
  // v93/v94: the product's lines in the cart (Walmart lists it once per seller) are made ONE: cap >= 0 -> the cheapest line within the
  // cap stays, the others go; cap < 0 -> every line of it goes. Only lines that carry THIS item number are ever touched (never another
  // product of yours), and with a cap it stops - removes nothing - when a line's price could not be read for sure.
  async function removeOver(want, cap) {
    const skuOk = i => !!(want.sku && i.sku && (String(i.sku) === String(want.sku) || (want.skuAlt || []).map(String).includes(String(i.sku))));
    let removed = 0;
    for (let round = 0; round < 4; round++) {
      const mine = lineItems().filter(i => matches(i, want));
      if (mine.some(i => !skuOk(i))) return {ok: false, removed, reason: 'a line of this product has no item number - nothing touched'};
      if (cap >= 0 && mine.some(i => i.price == null)) return {ok: false, removed, reason: 'a line\'s price could not be read - nothing touched'};
      const ok = cap >= 0 ? mine.filter(i => i.price <= cap + 0.001).sort((x, y) => x.price - y.price) : [];
      const keep = ok[0] || null;
      const drop = mine.filter(i => i !== keep);
      if (!drop.length) return {ok: true, removed, kept: keep ? {price: keep.price, seller: keep.seller} : null};
      if (cap >= 0 && !keep) return {ok: false, removed, reason: 'no line of it is within the cap'};
      const before = mine.length;
      drop[0].remove.click();
      await until(() => lineItems().filter(i => matches(i, want)).length < before, 10000);
      removed++;
    }
    return {ok: false, removed, reason: 'the cart did not change'};
  }
  async function removeMine(want) {
    // v94 (review): with an item number known, only a line carrying THAT number is ever taken out (never a similar item of yours that
    // only shares words with it)
    const exact = i => !want.sku || (i.sku && (String(i.sku) === String(want.sku) || (want.skuAlt || []).map(String).includes(String(i.sku))));
    const all = lineItems().filter(i => matches(i, want));
    const mine = all.filter(exact)[0];
    if (!mine) return all.length ? {ok: false, reason: 'the line has no item number - not touched'} : {ok: true, already: true};
    mine.remove.click();
    const gone = await until(() => !lineItems().some(i => matches(i, want)), 10000);
    return {ok: !!gone};
  }
  // ---- money rows (cart summary / checkout summary): find the label, read the amount on the same row
  function amountAt(t) {
    // the amount that directly follows a label: "$25.00", "FREE", "-$5.00" (a few characters of punctuation allowed in between)
    const m = String(t || '').match(/^[\s:.\-–]{0,4}(free\b|-?\s*\$\s*[\d,]+(?:\.\d{2})?)/i);
    if (!m) return null;
    if (/^free/i.test(m[1])) return 0;
    return Number(m[1].replace(/[\s$,]/g, ''));
  }
  function rowAmount(re) {
    const els = [...document.querySelectorAll('span, div, dt, dd, td, th, p, li, label, strong, b')].filter(e => shown(e) && e.children.length <= 3);
    for (const e of els) {
      const w = low(e.innerText);
      if (w.length > 60) continue;
      const m = w.match(re);
      if (!m || m.index !== 0) continue;
      // (v68, real walmart.com: a row may carry its label TWICE - "Seller shipping fee Seller shipping fee $8.95", the second for screen
      // readers - so the amount is read after the LAST copy of the label)
      let own = amountAt(w.slice(m[0].length));          // "ShippingFREE" / "Subtotal $323.88" in one element
      if (own === null) own = amountAt(w.slice(w.lastIndexOf(m[0]) + m[0].length));
      if (own !== null) return own;
      const lab = low(e.innerText);
      for (let row = e.parentElement, i = 0; row && i < 3; row = row.parentElement, i++) {
        const rt = low(row.innerText);
        if (rt.length > 140) break;
        const k = rt.lastIndexOf(lab);
        if (k < 0) continue;
        const v = amountAt(rt.slice(k + lab.length));
        if (v !== null) return v;
      }
    }
    return null;
  }
  // v68: the first of several labels that has an amount (real Walmart checkout: "Item (1) $14.99" (before savings) comes BEFORE
  // "Subtotal $8.95"; shipping is "Seller shipping fee $8.95"; tax "Estimated taxes")
  function firstAmount(list) { for (const re of list) { const v = rowAmount(re); if (v !== null) return v; } return null; }
  const PLACE_RE = /^(place (your )?order( for \$\s*[\d,]+(\.\d{2})?)?|place order now|submit order|confirm (&|and) pay)$/;
  function placeButton() {
    // real Walmart: <button data-automation-id="place-order-button">Place order for $18.68</button>
    const own = [...document.querySelectorAll('[data-automation-id="place-order-button"], [data-test="placeOrderButton"], #placeOrderButton')].filter(shown)[0];
    return own || button(PLACE_RE);
  }
  // v68: pop-ups on the checkout. Offers (real Walmart: "Get 30 days of Walmart+ for just $1" with "Confirm plan & add to order" /
  // "No thanks") are closed with their No-thanks / Close button - nothing else in them is ever pressed. A pop-up that may be about
  // the order itself (price changed, item unavailable, address, payment) stops the checkout (nothing is ordered).
  const OFFER = /walmart\+|membership|free trial|\btrial\b|\bplan\b|subscri|sign up|credit card|rewards card|cashrewards|cash back|protection plan|warranty|donat|round up|sam'?s club|survey|newsletter|text updates|download (the|our) app/;
  const ABOUT_ORDER = /price (has )?changed|no longer available|unavailable|out of stock|went wrong|problem|error|declined|verify|confirm your (address|card|payment)|address|payment method|card/;
  const CLOSE_RE = /^(no thanks|no, thanks|no thank you|not now|maybe later|skip|close|close dialog|close modal|dismiss|decline|x)$/;
  const ACCEPT_RE = /confirm plan|add to order|start (your |a )?(free )?trial|try (it )?(for|free)|join|sign up|subscribe|apply now|enroll|upgrade|claim|add protection|add plan|get (it|offer)|learn more/;
  function blocksPlace(d) {
    const p = placeButton();
    if (!p) return true;
    const r = p.getBoundingClientRect(), at = document.elementFromPoint(r.x + r.width / 2, r.y + r.height / 2);
    return !!(at && d.contains(at));
  }
  function popups() {
    return [...document.querySelectorAll('[role="dialog"], [role="alertdialog"], [aria-modal="true"]')].filter(d => seen(d) && !d.parentElement.closest('[role="dialog"], [role="alertdialog"], [aria-modal="true"]'));
  }
  async function dismissOffers() {
    const closed = [], unknown = [];
    for (const d of popups()) {
      const t = low(d.innerText).slice(0, 3000);
      if (d.querySelector('input#cvv, input[name*="cvv" i], input[id*="cvv" i], input[autocomplete="cc-csc"]') || /robot or human|verify (that )?you are/.test(t)) continue;
      const btns = [...d.querySelectorAll('button, [role="button"], a')].filter(shown).map(e => low(label(e) || e.getAttribute('aria-label')));
      const accept = btns.some(w => ACCEPT_RE.test(w));
      const isOffer = OFFER.test(t) && accept && !/price (has )?changed|no longer available|went wrong|declined|re-?enter|cvv|security code/.test(t) && !d.querySelector('input[type="password"], input[autocomplete^="cc-"]');
      if (!isOffer) { unknown.push({text: t.slice(0, 140), aboutOrder: ABOUT_ORDER.test(t) && blocksPlace(d)}); continue; }
      const b = [...d.querySelectorAll('button, [role="button"], a')].filter(shown).find(e => CLOSE_RE.test(low(label(e))) || CLOSE_RE.test(low(e.getAttribute('aria-label') || '')));
      if (!b) { unknown.push({text: t.slice(0, 140), aboutOrder: false, noClose: true}); continue; }
      closed.push(low(label(b) || b.getAttribute('aria-label')).slice(0, 30) + ' (' + t.slice(0, 50) + ')');
      b.click();
      await until(() => !d.isConnected || !seen(d), 3000);
    }
    return {closed, unknown};
  }
  function cvvField() {
    return [...document.querySelectorAll('input#cvv, input#credit-card-cvv, input[name*="cvv" i], input[id*="cvv" i], input[autocomplete="cc-csc"], input[aria-label*="security code" i], input[placeholder*="security code" i], input[name*="securityCode" i], input[placeholder="CVV" i], input[placeholder*="CVV" i], input[aria-label*="CVV" i], input[aria-label*="CVC" i], input[placeholder*="CVC" i]')].filter(shown)[0] ||
      // v77 (Best Buy's checkout 2026-10-29: a "Security code" heading over a box that only says CVV): the box under that label
      (() => { for (const l of document.querySelectorAll('label, legend, span, div, p')) {
        if (!/^\s*(card )?security code\s*\*?\s*$/i.test(l.textContent || '') || !shown(l)) continue;
        const byFor = l.htmlFor ? document.getElementById(l.htmlFor) : null;
        const near = byFor || l.querySelector('input') || (l.parentElement && l.parentElement.querySelector('input:not([type=hidden]):not([type=checkbox]):not([type=radio])'));
        if (near && shown(near)) return near; } return null; })();
  }
  function setValue(el, v) {
    const d = Object.getOwnPropertyDescriptor(Object.getPrototypeOf(el), 'value');
    el.focus(); d.set.call(el, v);
    el.dispatchEvent(new Event('input', {bubbles: true})); el.dispatchEvent(new Event('change', {bubbles: true})); el.dispatchEvent(new Event('blur', {bubbles: true}));
  }
  function checkout(want) {
    const t = bodyText(), lt = low(t);
    const toks = (want.tokens || []).map(low).filter(Boolean);
    // v67: Walmart's checkout shows the item as a PICTURE (its name only in the picture's description) - that counts as showing it too
    const pics = [...document.querySelectorAll('img[alt], [aria-label]')].map(e => low(e.getAttribute('alt') || e.getAttribute('aria-label') || '')).filter(x => x.length > 8).slice(0, 400);
    const named = s => toks.length > 0 && toks.every(k => k.split('|').some(x => s.includes(x)));
    const identity = (want.sku && new RegExp('\\b' + want.sku + '\\b').test(t)) || named(lt) || pics.some(named);      // (one picture must name it all)
    const qtys = [...lt.matchAll(/\b(?:qty|quantity):?\s*(\d+)\b/g)].map(m => Number(m[1]));
    const sel = [...document.querySelectorAll('select[id*="quantity" i], select[aria-label*="quantity" i]')].map(s => Number(s.value));
    const allQ = qtys.concat(sel);
    const itemsN = (lt.match(/\b(?:items?|item subtotal)\s*\((\d+)\)/) || lt.match(/\((\d+) items?\)/) || [])[1];
    const place = placeButton();
    const placeAmount = place ? money(label(place)) : null;      // v68: Walmart's button says "Place order for $18.68"
    const c = cvvField();
    const problems = [];
    // v78b (diagnostics 66, real target.com checkout: "no saved payment card" although Place your order was there and the order was fine
    // to place): a saved card shows as "ending in 1234", "*1234", "•••• 1234", "...1234" or with its expiry date; and the problem only
    // counts when the page really wants a card - a card-number box on the page, or the Place order button greyed out
    const cardShown = /ending in|(?:[*•·x]{1,}|\.{3})\s?\d{4}\b|\bexp(?:ires|iration|\.)?:?\s*\d{1,2}\s*\/\s*\d{2,4}/.test(lt);
    const cardBox = [...document.querySelectorAll('input[autocomplete="cc-number"], input[name*="cardnumber" i], input[name*="card-number" i], input[id*="cardnumber" i], input[aria-label*="card number" i], input[placeholder*="card number" i]')].some(shown);
    if (/add (a )?(new )?(payment|card)|enter (your )?card|select a payment/.test(lt) && !cardShown && (cardBox || !place || disabled(place))) problems.push('no saved payment card is selected');
    if (/add (a )?(new )?(shipping )?address|enter (your )?(shipping )?address/.test(lt) && !/ship to|shipping address/.test(lt)) problems.push('no shipping address is selected');
    // v67 (your rule: never store pickup): an order set to pick up at a store, with no shipping, is not placed
    const pickup = /\bpick ?up (at|from|location|today|tomorrow|in store)\b|\bstore pickup\b/.test(lt) && !/\b(shipping|ship to|shipped|arrives|delivery address|shipping address|deliver(ed|y) to)\b/.test(lt);
    if (pickup) problems.push('the order is set to store pickup (never allowed) - choose shipping in the cart');
    return {page: 'checkout', url: location.href, identity: !!identity, pickup,
            qtyOne: (allQ.length ? allQ.every(q => q === 1) : true) && (!itemsN || Number(itemsN) === 1), qtys: allQ.slice(0, 6), itemsN: itemsN ? Number(itemsN) : null,
            base: firstAmount([/^subtotal\b/, /^(item|items|order|product) subtotal/, /^items? \(\d+\)/]),
            tax: firstAmount([/^(estimated |est\.? )?(sales )?tax(es)?\b/]),
            shipping: firstAmount([/^seller shipping fee/, /^(estimated )?shipping( fees?| cost| & handling| and handling)?\b(?![,a-z])/, /^(estimated )?delivery( fee)?\b(?![,a-z])/, /^shipping fee/]),
            total: firstAmount([/^(estimated )?(order )?total\b/]),
            fees: rowAmount(/(recycling|environmental|state) fee/), cvv: !!c, cvvFilled: !!(c && c.value && c.value.length >= 3),
            place: !!place, placeEnabled: !!place && !disabled(place), placeAmount, problems, check: challenge(),
            popups: popups().map(d => low(d.innerText).slice(0, 100)), vis: document.visibilityState};
  }
  function confirmation() {
    const t = bodyText(), lt = low(t).slice(0, 40000);
    // v68: Walmart's order numbers look like 2000134-12345678 - also read when the page does not write "Order #" in front of it
    const order = (t.match(/order\s*(?:number|#|no\.?)\s*:?\s*#?\s*([A-Z0-9-]{6,})/i) || [])[1] ||
                  (STORE === 'Walmart' && /thank-?you|confirmation/i.test(location.pathname) ? (t.match(/\b(\d{7}-\d{8})\b/) || [])[1] : null) || null;
    // v68: the store's thank-you / confirmation PAGE itself means the order was placed (its exact words are not needed - Walmart's
    // page is /checkout/thankyou, shown only after an order)
    const ok = /thank you for (your|shopping)|thanks for (your order|shopping)|your order (has been|is|was) (placed|confirmed|received)|order (is )?(confirmed|placed)|we('ve| have) received your order/.test(lt) ||
               /\/checkout\/thank-?you|thank-?you|order-?confirmation|\/confirmation/i.test(location.pathname);      // (v78b: Target's is /co-thankyou)
    const failed = (lt.match(/(payment (was |has been )?declined[^.]*|unable to (process|place) (your )?(order|payment)[^.]*|there was a problem (with|placing) your order[^.]*|(this|an) item (in your cart )?is (no longer|not) available[^.]*|sold out[^.]{0,40}removed|(?:the )?(?:security code|cvv2?|cvc|card verification (?:code|number))[^.]{0,60}(?:incorrect|invalid|not valid|does(?:n't| not) match|wrong)[^.]*|(?:please )?enter a valid (?:security code|cvv2?|cvc)[^.]*|invalid (?:security code|cvv2?|cvc)[^.]*|(?:please )?(?:add|select|choose) a (?:payment|card|payment method)[^.]*)/) || [])[1] || null;   // (v77: + a security code the store turns down)
    return {page: 'confirm', url: location.href, placed: ok && !failed, order, failed: failed ? failed.slice(0, 160) : null, check: challenge(),
            cvv: !ok && !!cvvField() && !String(cvvField().value || '').trim()};   // v68: an EMPTY code field after Place order = a new question
  }
  function fingerprint() {
    // what is on a page, WITHOUT personal data: button words, field names, headings and the url path (for the diagnostics)
    // v93 (diagnostics 76 carried a street address - the cart's "deliver to" button - and the greeting's name): such words are left out
    const personal = w => /\d{2,}\s+[a-z]/.test(w) || /\b(court|ct|street|st|avenue|ave|road|rd|drive|dr|lane|ln|way|blvd|boulevard|place|pl|circle|cir|terrace|parkway|pkwy|trail|hwy|highway|apt|suite|unit)\b.*\d|\d.*\b(court|street|avenue|road|drive|lane|way|boulevard|place|circle|terrace|parkway|trail|highway)\b/.test(w) || /@|\b\d{5}(?:-\d{4})?\b/.test(w);
    const masked = w => w.replace(/^(hi|hello|hey),?\s+[^,]+?(\s+account|$)/, '$1, [name]$2');
    const btns = [...new Set(clickables().map(e => masked(low(label(e)).slice(0, 40))).filter(w => w && w.length < 40 && !personal(w)))].slice(0, 60);
    const fields = [...document.querySelectorAll('input, select')].filter(shown).map(e => (e.type || e.tagName).toLowerCase() + ':' + (e.id || e.name || e.getAttribute('aria-label') || '').slice(0, 40)).slice(0, 40);
    const heads = [...document.querySelectorAll('h1, h2, h3')].filter(shown).map(e => norm(e.innerText).slice(0, 60)).filter(h => !personal(low(h))).slice(0, 15);
    const rows = ['subtotal', 'tax', 'shipping', 'total'].map(k => k + '=' + rowAmount(new RegExp('^(estimated |item |order )?' + k)));
    return {path: location.pathname, buttons: btns, fields, headings: heads, rows};
  }
  chrome.runtime.onMessage.addListener((m, sender, respond) => {
    if (!m || !m.bb) return;
    (async () => {
      try {
        // v62: this part is now loaded as the page starts (diagnostics 60: loaded "when the page is idle" it often never arrived in the
        // hidden buying window - "Receiving end does not exist"); every request still waits until the page's content is there
        if (document.readyState === 'loading' && m.bb !== 'ping') await new Promise(r => { document.addEventListener('DOMContentLoaded', r, {once: true}); setTimeout(r, 15000); });
        const want = m.want || {};
        if (m.bb === 'ping') return respond({ok: true, url: location.href, ready: document.readyState, check: m.check ? challenge() : undefined});
        if (m.bb === 'pdp') {
          await until(() => { const h = heading(); return h && (pdpButton(h) || becameStepper(h)) || challenge(); }, m.wait || 20000);
          let shipTile = null;
          if (m.ship && !challenge()) {            // (v75: Shipping chosen first - a Buy now may show up then)
            const h1 = heading(), b = pdpButton(h1);
            if (b) { shipTile = await pickShippingTile(b); if (shipTile) await until(() => buyNowButton(h1), 1500); }
          }
          return respond({ok: true, ...pdp(), shipTile});
        }
        if (m.bb === 'buynow') {
          const h1 = heading();
          const c0 = challenge(); if (c0) return respond({ok: false, check: c0});
          const b = pdpButton(h1); if (b) await pickShippingTile(b);
          if (pickupChosen()) return respond({ok: false, error: 'Pickup is chosen and Shipping could not be chosen - Buy now not pressed'});
          const bn = buyNowButton(h1);
          if (!bn) return respond({ok: false, error: 'no Buy now button'});
          press(bn);
          return respond({ok: true, pressed: true});
        }
        if (m.bb === 'add') return respond(await addToCart(m.maxQueueMs || 0));
        if (m.bb === 'searchadd') {
          const isAdd = e => /^(add to cart|add|\+ ?add|add to cart - ship|ship it)$/.test(low(label(e))) || /^add to cart\b/.test(low(e.getAttribute('aria-label') || ''));
          await until(() => clickables().some(e => isAdd(e) && !inRecs(e)), 12000);
          const b = clickables().filter(e => isAdd(e) && !disabled(e) && !inRecs(e))[0];
          if (!b) return respond({ok: false, error: 'no product with Add to Cart in the search results'});
          let box = b; for (let i = 0; i < 8 && box; i++) { box = box.parentElement; if (box && box.querySelector('a[href*="/p/"], a[href*="/ip/"], a[href*="/products/"], a[href*="/product/"]')) break; }
          const link = box && box.querySelector('a[href*="/p/"], a[href*="/ip/"], a[href*="/products/"], a[href*="/product/"]');
          const title = norm(link && link.innerText).slice(0, 120);
          lastPress = Date.now(); b.click();
          const ok = await until(() => added() || cartError(), 8000);
          return respond({ok: !!added(), title, href: link && link.getAttribute('href'), error: cartError()});
        }
        if (m.bb === 'cart') { await until(() => lineItems().length || /cart is empty/.test(low(bodyText())) || challenge(), m.wait || 10000); return respond({ok: true, ...cart(want)}); }
        if (m.bb === 'ship') return respond(await chooseShipping(want, !!m.allowPickup));
        if (m.bb === 'remove') return respond(await removeMine(want));
        if (m.bb === 'removeover') return respond(await removeOver(want, Number(m.cap)));
        if (m.bb === 'qty1') {
          const mine = lineItems().filter(i => matches(i, want))[0];
          const q = mine && mine.box.querySelector('select[id*="quantity" i], select[aria-label*="quantity" i], select[name*="quantity" i]');
          if (!q) {
            // v67 (Walmart): a "- 1 +" quantity control - the minus is pressed until 1 (never to 0: that would remove it)
            for (let i = 0; i < 6; i++) {
              const cur = lineItems().filter(x => matches(x, want))[0];
              if (!cur || cur.qty === 1 || !cur.qty) break;
              const dec = [...cur.box.querySelectorAll('button, [role="button"]')].filter(shown).find(e => /decrease quantity|remove one|minus|^-$|^\u2212$/.test(low((e.getAttribute('aria-label') || '') + ' ' + label(e))));
              if (!dec || disabled(dec)) return respond({ok: false, error: 'no quantity choice in the cart'});
              dec.click(); await sleep(1800);
            }
            const again = lineItems().filter(i => matches(i, want))[0];
            return respond({ok: !!again && (again.qty === 1 || again.qty === null)});
          }
          setValue(q, '1'); await sleep(2500);
          const again = lineItems().filter(i => matches(i, want))[0];
          return respond({ok: !!again && (again.qty === 1 || again.qty === null)});
        }
        if (m.bb === 'tocheckout') {
          // v78 (diagnostics 65: Target's cart page draws its Check out button a moment AFTER the items): waited for, up to 8 s
          const CO = /^(checkout|check ?out|continue to checkout|proceed to checkout|checkout now|i'm ready to check out)$/;
          const b = await until(() => { if (challenge()) return 'check'; const x = button(CO); return x && !disabled(x) ? x : null; }, m.wait || 8000);
          if (b === 'check') return respond({ok: false, check: challenge(), error: challenge()});
          if (!b) return respond({ok: false, error: 'no Checkout button on the cart page'});
          respond({ok: true}); press(b); return;
        }
        if (m.bb === 'dismiss') { await until(() => placeButton() || challenge(), m.wait || 8000); await sleep(800); return respond({ok: true, ...(await dismissOffers())}); }
        if (m.bb === 'checkout') {
          // (v67: a page with a "Continue" step answers at once - the engine presses it and reads the next part)
          await until(() => placeButton() || challenge() ||
                            button(/^(continue|continue to payment|continue to review|review (your )?order|review order|save and continue|save & continue)$/), m.wait || 15000);
          await sleep(600); return respond({ok: true, ...checkout(want)});
        }
        if (m.bb === 'advance') {
          // v67: some checkouts show a "Continue" / "Review order" step before the Place order button. Pressing it never places an order.
          const sc = STORE === 'GameStop' ? button(/^(save (&|and) continue)$/) : null;
          if (placeButton() && !sc) return respond({ok: true, ready: true});
          if (sc && !disabled(sc)) { respond({ok: true, pressed: 'save & continue'}); press(sc); return; }
          const b = button(/^(continue|continue to payment|continue to review|review (your )?order|review order|save and continue|save & continue|confirm|use this address|ship here|deliver here)$/);
          if (!b || disabled(b)) return respond({ok: false, error: 'no Continue step'});
          respond({ok: true, pressed: low(label(b)).slice(0, 40)}); press(b); return;      // (it may open the next page: answered first)
        }
        if (m.bb === 'cvv') {
          const c = cvvField(); if (!c) return respond({ok: false, error: 'no security-code field'});
          setValue(c, String(m.value || '')); await sleep(300);
          return respond({ok: !!(c.value && c.value.length >= 3)});
        }
        if (m.bb === 'cvvsubmit') {
          // v68: the security-code question that appeared AFTER Place order: the code (typed by you) goes in, and the question's own
          // button (in the same pop-up / form) is pressed - it completes the SAME order, it is not a second order
          const c = cvvField(); if (!c) return respond({ok: false, error: 'no security-code field'});
          setValue(c, String(m.value || '')); await sleep(400);
          const box = c.closest('[role="dialog"], [role="alertdialog"], [aria-modal="true"]');      // (only a button in the SAME pop-up)
          if (!box) return respond({ok: false, error: 'the security-code question is not in a pop-up - nothing pressed'});
          const re = /^(place (your )?order( for \$\s*[\d,]+(\.\d{2})?)?|continue|submit|confirm|verify|done|use this card|ok)$/;
          const b = box && [...box.querySelectorAll('button, [role="button"], input[type="submit"]')].filter(shown).find(e => re.test(low(label(e))));
          if (!b || disabled(b)) return respond({ok: false, error: 'no button to send the security code'});
          respond({ok: true, pressed: low(label(b)).slice(0, 30)}); press(b); return;
        }
        if (m.bb === 'place') {
          const b = placeButton();
          if (!b || disabled(b)) return respond({ok: false, error: 'the Place Your Order button is missing or greyed out'});
          respond({ok: true, at: Date.now()}); press(b); return;
        }
        if (m.bb === 'confirm') return respond({ok: true, ...confirmation()});
        if (m.bb === 'text') { await sleep(m.settle || 0); return respond({ok: true, url: location.href, text: bodyText().slice(0, 300000)}); }
        if (m.bb === 'fingerprint') return respond({ok: true, ...fingerprint()});
        respond({ok: false, error: 'unknown request'});
      } catch (e) { try { respond({ok: false, error: String(e && e.message || e)}); } catch {} }
    })();
    return true;
  });
})();
