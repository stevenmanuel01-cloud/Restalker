globalThis.AMAZON_CATALOG = [
  {
    "id": "hobbit-cb-box",
    "set": "The Hobbit",
    "name": "The Hobbit Collector Booster Box (12 Packs)",
    "asin": "B0GWSDDFFJ",
    "url": "https://www.amazon.com/dp/B0GWSDDFFJ",
    "search": "https://www.amazon.com/s?k=Magic+The+Gathering+The+Hobbit+Collector+Booster+Box",
    "cap": 455.88,
    "monitor": false,
    "autoBuy": false,
    "tokens": [
      "the hobbit",
      "collector booster box",
      "12 packs"
    ],
    "enabled": true,
    "verified": true,
    "capSource": "Wizards MSRP"
  },
  {
    "id": "hobbit-cb-single",
    "set": "The Hobbit",
    "name": "The Hobbit Collector Booster (Single Pack)",
    "asin": "B0GWS9J9VT",
    "url": "https://www.amazon.com/dp/B0GWS9J9VT",
    "search": "https://www.amazon.com/s?k=Magic+The+Gathering+The+Hobbit+Collector+Booster",
    "cap": 37.99,
    "monitor": false,
    "autoBuy": false,
    "tokens": [
      "the hobbit",
      "collector booster"
    ],
    "forbid": [
      "box",
      "12 packs"
    ],
    "enabled": true,
    "verified": true,
    "capSource": "Wizards MSRP"
  },
  {
    "id": "hobbit-gift-bundle",
    "set": "The Hobbit",
    "name": "The Hobbit Gift Bundle",
    "asin": "B0GWS8DC8C",
    "url": "https://www.amazon.com/dp/B0GWS8DC8C",
    "search": "https://www.amazon.com/s?k=Magic+The+Gathering+The+Hobbit+Gift+Bundle",
    "cap": 89.99,
    "monitor": false,
    "autoBuy": false,
    "tokens": [
      "the hobbit",
      "gift bundle"
    ],
    "enabled": true,
    "verified": true,
    "capSource": "Wizards MSRP"
  },
  {
    "id": "reality-cb-box",
    "set": "Reality Fracture",
    "name": "Reality Fracture Collector Booster Box (12 Packs)",
    "asin": "B0GXC667JV",
    "url": "https://www.amazon.com/dp/B0GXC667JV",
    "search": "https://www.amazon.com/s?k=Magic+The+Gathering+Reality+Fracture+Collector+Booster+Box",
    "cap": 323.88,
    "monitor": false,
    "autoBuy": false,
    "tokens": [
      "reality fracture",
      "collector booster box",
      "12 packs"
    ],
    "enabled": true,
    "verified": true,
    "capSource": "Wizards MSRP"
  },
  {
    "id": "reality-cb-single",
    "set": "Reality Fracture",
    "name": "Reality Fracture Collector Booster (Single Pack)",
    "asin": "B0GXCC47X5",
    "url": "https://www.amazon.com/dp/B0GXCC47X5",
    "search": "https://www.amazon.com/s?k=Magic+The+Gathering+Reality+Fracture+Collector+Booster",
    "cap": 26.99,
    "monitor": false,
    "autoBuy": false,
    "tokens": [
      "reality fracture",
      "collector booster"
    ],
    "forbid": [
      "box",
      "12 packs"
    ],
    "enabled": true,
    "verified": true,
    "capSource": "Wizards MSRP"
  },
  {
    "id": "star-trek-cb-box",
    "set": "Star Trek",
    "name": "Star Trek Collector Booster Box (12 Packs)",
    "asin": "B0H6H2VXJB",
    "url": "https://www.amazon.com/dp/B0H6H2VXJB",
    "search": "https://www.amazon.com/s?k=Magic+The+Gathering+Star+Trek+Collector+Booster+Box",
    "cap": 455.88,
    "monitor": false,
    "autoBuy": false,
    "tokens": [
      "star trek",
      "collector booster box",
      "12 packs"
    ],
    "enabled": true,
    "verified": true,
    "capSource": "Wizards MSRP"
  },
  {
    "id": "star-trek-cb-single",
    "set": "Star Trek",
    "name": "Star Trek Collector Booster (Single Pack)",
    "asin": "B0H6H4TXPZ",
    "url": "https://www.amazon.com/dp/B0H6H4TXPZ",
    "search": "https://www.amazon.com/s?k=Magic+The+Gathering+Star+Trek+Collector+Booster",
    "cap": 37.99,
    "monitor": false,
    "autoBuy": false,
    "tokens": [
      "star trek",
      "collector booster"
    ],
    "forbid": [
      "box",
      "12 packs"
    ],
    "enabled": true,
    "verified": true,
    "capSource": "Wizards MSRP"
  },
  {
    "id": "star-trek-beam-bundle",
    "set": "Star Trek",
    "name": "Star Trek Beam Me Up Bundle",
    "asin": "B0H6H8KS14",
    "url": "https://www.amazon.com/dp/B0H6H8KS14",
    "search": "https://www.amazon.com/s?k=Magic+The+Gathering+Star+Trek+Beam+Me+Up+Bundle",
    "cap": 99.99,
    "monitor": false,
    "autoBuy": false,
    "tokens": [
      "star trek",
      "beam me up bundle"
    ],
    "enabled": true,
    "verified": true,
    "capSource": "Wizards MSRP"
  },
  {
    "id": "reality-secret-lair-bundle",
    "set": "Reality Fracture",
    "name": "Reality Fracture Secret Lair Bundle",
    "asin": "B0GXCKVJ6W",
    "url": "https://www.amazon.com/dp/B0GXCKVJ6W",
    "search": "https://www.amazon.com/s?k=Reality+Fracture+Secret+Lair+Bundle",
    "cap": 89.99,
    "monitor": false,
    "autoBuy": false,
    "tokens": [
      "reality fracture",
      "secret lair",
      "bundle"
    ],
    "enabled": true,
    "verified": true,
    "capSource": "Wizards MSRP"
  },
  {
    "id": "foundations-cb-single",
    "set": "Foundations",
    "name": "Foundations Collector Booster (Single Pack)",
    "asin": "B0D9MX1LMZ",
    "url": "https://www.amazon.com/dp/B0D9MX1LMZ",
    "search": "https://www.amazon.com/s?k=Foundations+Collector+Booster+Single+Pack",
    "cap": 24.99,
    "monitor": false,
    "autoBuy": false,
    "tokens": [
      "foundations",
      "collector booster"
    ],
    "enabled": true,
    "verified": true,
    "forbid": [
      "box",
      "12 packs"
    ],
    "capSource": "Wizards MSRP"
  },
  {
    "id": "kamigawa-neon-dynasty-cb-box",
    "set": "Kamigawa: Neon Dynasty",
    "name": "Kamigawa: Neon Dynasty Collector Booster Box (12 Packs)",
    "asin": "B09M8WPGK1",
    "url": "https://www.amazon.com/dp/B09M8WPGK1",
    "search": "https://www.amazon.com/s?k=Kamigawa+Neon+Dynasty+Collector+Booster+Box+12+Packs",
    "cap": null,
    "monitor": false,
    "autoBuy": false,
    "tokens": [
      "kamigawa",
      "neon dynasty",
      "collector booster"
    ],
    "enabled": true,
    "verified": true,
    "capSource": null
  },
  {
    "id": "lorwyn-eclipsed-cb-box",
    "set": "Lorwyn Eclipsed",
    "name": "Lorwyn Eclipsed Collector Booster Box (12 Packs)",
    "asin": "B0FP44WBMF",
    "url": "https://www.amazon.com/dp/B0FP44WBMF",
    "search": "https://www.amazon.com/s?k=Lorwyn+Eclipsed+Collector+Booster+Box+12+Packs",
    "cap": 323.88,
    "monitor": false,
    "autoBuy": false,
    "tokens": [
      "lorwyn eclipsed",
      "collector booster"
    ],
    "enabled": true,
    "verified": true,
    "capSource": "Wizards MSRP"
  },
  {
    "id": "secrets-strixhaven-cb-box",
    "set": "Secrets of Strixhaven",
    "name": "Secrets of Strixhaven Collector Booster Box (12 Packs)",
    "asin": "B0GFDD1RLS",
    "url": "https://www.amazon.com/dp/B0GFDD1RLS",
    "search": "https://www.amazon.com/s?k=Secrets+of+Strixhaven+Collector+Booster+Box+12+Packs",
    "cap": 323.88,
    "monitor": false,
    "autoBuy": false,
    "tokens": [
      "secrets of strixhaven",
      "collector booster"
    ],
    "enabled": true,
    "verified": true,
    "capSource": "Wizards MSRP"
  },
  {
    "id": "commander-masters-set-box",
    "set": "Commander Masters",
    "name": "Commander Masters Set Booster Box (24 Packs)",
    "asin": "B0BVT771M5",
    "url": "https://www.amazon.com/dp/B0BVT771M5",
    "search": "https://www.amazon.com/s?k=Commander+Masters+Set+Booster+Box+24+Packs",
    "cap": null,
    "monitor": false,
    "autoBuy": false,
    "tokens": [
      "commander masters",
      "set booster"
    ],
    "enabled": true,
    "verified": true,
    "forbid": [
      "collector booster"
    ],
    "capSource": null
  },
  {
    "id": "new-capenna-cb-box",
    "set": "Streets of New Capenna",
    "name": "Streets of New Capenna Collector Booster Box (12 Packs)",
    "asin": "B09SVPC9BH",
    "url": "https://www.amazon.com/dp/B09SVPC9BH",
    "search": "https://www.amazon.com/s?k=Streets+of+New+Capenna+Collector+Booster+Box+12+Packs",
    "cap": null,
    "monitor": false,
    "autoBuy": false,
    "tokens": [
      "streets of new capenna",
      "collector booster"
    ],
    "enabled": true,
    "verified": true,
    "capSource": null
  },
  {
    "id": "dominaria-united-cb-box",
    "set": "Dominaria United",
    "name": "Dominaria United Collector Booster Box (12 Packs)",
    "asin": "B09ZJS2TM2",
    "url": "https://www.amazon.com/dp/B09ZJS2TM2",
    "search": "https://www.amazon.com/s?k=Dominaria+United+Collector+Booster+Box+12+Packs",
    "cap": null,
    "monitor": false,
    "autoBuy": false,
    "tokens": [
      "dominaria united",
      "collector booster"
    ],
    "enabled": true,
    "verified": true,
    "capSource": null
  },
  {
    "id": "dominaria-remastered-cb-box",
    "set": "Dominaria Remastered",
    "name": "Dominaria Remastered Collector Booster Box (12 Packs)",
    "asin": "B0B9NJWP7M",
    "url": "https://www.amazon.com/dp/B0B9NJWP7M",
    "search": "https://www.amazon.com/s?k=Dominaria+Remastered+Collector+Booster+Box+12+Packs",
    "cap": null,
    "monitor": false,
    "autoBuy": false,
    "tokens": [
      "dominaria remastered",
      "collector booster"
    ],
    "enabled": true,
    "verified": true,
    "capSource": null
  },
  {
    "id": "kaldheim-cb-box",
    "set": "Kaldheim",
    "name": "Kaldheim Collector Booster Box (12 Packs)",
    "asin": "B08N25VNL5",
    "url": "https://www.amazon.com/dp/B08N25VNL5",
    "search": "https://www.amazon.com/s?k=Kaldheim+Collector+Booster+Box+12+Packs",
    "cap": null,
    "monitor": false,
    "autoBuy": false,
    "tokens": [
      "kaldheim",
      "collector booster"
    ],
    "enabled": true,
    "verified": true,
    "capSource": null
  },
  {
    "id": "modern-horizons-3-play-box",
    "set": "Modern Horizons 3",
    "name": "Modern Horizons 3 Play Booster Box (36 Packs)",
    "asin": "B0CTLT5DJQ",
    "url": "https://www.amazon.com/dp/B0CTLT5DJQ",
    "search": "https://www.amazon.com/s?k=Modern+Horizons+3+Play+Booster+Box+36+Packs",
    "cap": null,
    "monitor": false,
    "autoBuy": false,
    "tokens": [
      "modern horizons 3",
      "play booster"
    ],
    "enabled": true,
    "verified": true,
    "capSource": null
  },
  {
    "id": "wilds-eldraine-cb-box",
    "set": "Wilds of Eldraine",
    "name": "Wilds of Eldraine Collector Booster Box (12 Packs)",
    "asin": "B0C3T4VZN8",
    "url": "https://www.amazon.com/dp/B0C3T4VZN8",
    "search": "https://www.amazon.com/s?k=Wilds+of+Eldraine+Collector+Booster+Box+12+Packs",
    "cap": null,
    "monitor": false,
    "autoBuy": false,
    "tokens": [
      "wilds of eldraine",
      "collector booster"
    ],
    "enabled": true,
    "verified": true,
    "capSource": null
  },
  {
    "id": "double-masters-2022-cb-box",
    "set": "Double Masters 2022",
    "name": "Double Masters 2022 Collector Booster Box (4 Packs)",
    "asin": "B09ZJBSD6F",
    "url": "https://www.amazon.com/dp/B09ZJBSD6F",
    "search": "https://www.amazon.com/s?k=Double+Masters+2022+Collector+Booster+Box+4+Packs",
    "cap": null,
    "monitor": false,
    "autoBuy": false,
    "tokens": [
      "double masters 2022",
      "collector booster"
    ],
    "enabled": true,
    "verified": true,
    "capSource": null
  },
  {
    "id": "throne-eldraine-cb-box",
    "set": "Throne of Eldraine",
    "name": "Throne of Eldraine Collector Booster Box",
    "asin": "B07VQ2NF7D",
    "url": "https://www.amazon.com/dp/B07VQ2NF7D",
    "search": "https://www.amazon.com/s?k=Throne+of+Eldraine+Collector+Booster+Box",
    "cap": null,
    "monitor": false,
    "autoBuy": false,
    "tokens": [
      "throne of eldraine",
      "collector booster"
    ],
    "enabled": true,
    "verified": true,
    "capSource": null
  },
  {
    "id": "commander-masters-cb-box",
    "set": "Commander Masters",
    "name": "Commander Masters Collector Booster Box (4 Packs)",
    "asin": "B0BVTSXHG6",
    "url": "https://www.amazon.com/dp/B0BVTSXHG6",
    "search": "https://www.amazon.com/s?k=Commander+Masters+Collector+Booster+Box+4+Packs",
    "cap": null,
    "monitor": false,
    "autoBuy": false,
    "tokens": [
      "commander masters",
      "collector booster"
    ],
    "enabled": true,
    "verified": true,
    "capSource": null
  },
  {
    "id": "zendikar-rising-cb-box",
    "set": "Zendikar Rising",
    "name": "Zendikar Rising Collector Booster Box (12 Packs)",
    "asin": "B08D1NXYCS",
    "url": "https://www.amazon.com/dp/B08D1NXYCS",
    "search": "https://www.amazon.com/s?k=Zendikar+Rising+Collector+Booster+Box+12+Packs",
    "cap": null,
    "monitor": false,
    "autoBuy": false,
    "tokens": [
      "zendikar rising",
      "collector booster"
    ],
    "enabled": true,
    "verified": true,
    "capSource": null
  },
  {
    "id": "assassins-creed-cb-box",
    "set": "Assassin's Creed",
    "name": "Assassin's Creed Collector Booster Box (12 Packs)",
    "asin": "B0CTKW15QS",
    "url": "https://www.amazon.com/dp/B0CTKW15QS",
    "search": "https://www.amazon.com/s?k=Assassin+s+Creed+Collector+Booster+Box+12+Packs",
    "cap": null,
    "monitor": false,
    "autoBuy": false,
    "tokens": [
      "assassin's creed",
      "collector booster"
    ],
    "enabled": true,
    "verified": true,
    "capSource": null
  },
  {
    "id": "edge-eternities-cb-box",
    "set": "Edge of Eternities",
    "name": "Edge of Eternities Collector Booster Box (12 Packs)",
    "asin": "B0DTRPG4NC",
    "url": "https://www.amazon.com/dp/B0DTRPG4NC",
    "search": "https://www.amazon.com/s?k=Edge+of+Eternities+Collector+Booster+Box+12+Packs",
    "cap": 299.88,
    "monitor": false,
    "autoBuy": false,
    "tokens": [
      "edge of eternities",
      "collector booster"
    ],
    "enabled": true,
    "verified": true,
    "capSource": "Wizards MSRP"
  },
  {
    "id": "unfinity-cb-box",
    "set": "Unfinity",
    "name": "Unfinity Collector Booster Box (12 Packs)",
    "asin": "B09LM4YVG3",
    "url": "https://www.amazon.com/dp/B09LM4YVG3",
    "search": "https://www.amazon.com/s?k=Unfinity+Collector+Booster+Box+12+Packs",
    "cap": null,
    "monitor": false,
    "autoBuy": false,
    "tokens": [
      "unfinity",
      "collector booster"
    ],
    "enabled": true,
    "verified": true,
    "capSource": null
  },
  {
    "id": "baldurs-gate-cb-box",
    "set": "Commander Legends: Battle for Baldur's Gate",
    "name": "Commander Legends: Battle for Baldur's Gate Collector Booster Box (12 Packs)",
    "asin": "B09VB14M3X",
    "url": "https://www.amazon.com/dp/B09VB14M3X",
    "search": "https://www.amazon.com/s?k=Commander+Legends+Battle+for+Baldur+s+Gate+Collector+Booster+Box+12+Packs",
    "cap": null,
    "monitor": false,
    "autoBuy": false,
    "tokens": [
      "battle for baldur's gate",
      "collector booster"
    ],
    "enabled": true,
    "verified": true,
    "capSource": null
  },
  {
    "id": "tarkir-dragonstorm-cb-box",
    "set": "Tarkir: Dragonstorm",
    "name": "Tarkir: Dragonstorm Collector Booster Box (12 Packs)",
    "asin": "B0DSR23QV1",
    "url": "https://www.amazon.com/dp/B0DSR23QV1",
    "search": "https://www.amazon.com/s?k=Tarkir+Dragonstorm+Collector+Booster+Box+12+Packs",
    "cap": 299.88,
    "monitor": false,
    "autoBuy": false,
    "tokens": [
      "tarkir",
      "dragonstorm",
      "collector booster"
    ],
    "enabled": true,
    "verified": true,
    "capSource": "Wizards MSRP"
  },
  {
    "id": "final-fantasy-cb-box",
    "set": "FINAL FANTASY",
    "name": "FINAL FANTASY Collector Booster Box (12 Packs)",
    "asin": "B0DTS76B5L",
    "url": "https://www.amazon.com/dp/B0DTS76B5L",
    "search": "https://www.amazon.com/s?k=FINAL+FANTASY+Collector+Booster+Box+12+Packs",
    "cap": 800.0,
    "monitor": false,
    "autoBuy": false,
    "tokens": [
      "final fantasy",
      "collector booster"
    ],
    "enabled": true,
    "verified": true,
    "capSource": "Manual requested cap"
  },
  {
    "id": "brothers-war-cb-box",
    "set": "The Brothers' War",
    "name": "The Brothers' War Collector Booster Box (12 Packs)",
    "asin": "B0B8445Q39",
    "url": "https://www.amazon.com/dp/B0B8445Q39",
    "search": "https://www.amazon.com/s?k=The+Brothers+War+Collector+Booster+Box+12+Packs",
    "cap": null,
    "monitor": false,
    "autoBuy": false,
    "tokens": [
      "brothers' war",
      "collector booster"
    ],
    "enabled": true,
    "verified": true,
    "capSource": null
  },
  {
    "id": "custom-asin-product",
    "set": "Custom ASIN",
    "name": "Custom ASIN Product",
    "asin": "",
    "url": "",
    "search": "",
    "cap": null,
    "monitor": false,
    "autoBuy": false,
    "enabled": true,
    "verified": false,
    "customProduct": true,
    "tokens": [],
    "capSource": null
  }
];
