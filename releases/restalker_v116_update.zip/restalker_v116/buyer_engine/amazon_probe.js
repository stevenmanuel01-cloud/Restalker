// Restalker v57 - read-only checkout evidence for Amazon. It never clicks, types or changes anything.
// When a checkout stops with "identity not verified", Restalker shows this record so the reason can be seen:
// which of the product's words the checkout page shows, which are missing, and which "forbidden" words appear (with a few words around them).
// Only product lines are read. Addresses, names, emails, phone and card numbers are never recorded.
(function(){
 if(globalThis.__rkProbe)return;globalThis.__rkProbe=true;
 const KEY='rk:amazonProbe';
 const onCheckout=()=>/\/(checkout|gp\/buy|spc|buy\/)/i.test(location.pathname);
 const norm=s=>String(s||'').toLowerCase().replace(/[’']/g,"'").replace(/\s+/g,' ').trim();
 const shown=e=>{try{const r=e.getBoundingClientRect();return r.width>0&&r.height>0}catch{return false}};
 const txt=e=>String(e?.innerText||e?.textContent||'');
 const clean=s=>norm(s).replace(/[\w.+-]+@[\w-]+\.[\w.]+/g,'[email]').replace(/\b\d{5,}\b/g,'[number]').slice(0,240);
 const personal=e=>!!e.closest?.('[id*="address" i],[class*="address" i],[id*="payment" i],[class*="payment" i],[data-testid*="address" i],[data-testid*="payment" i]');
 let last='',started=Date.now(),timer=null;
 async function look(){
  if(!onCheckout()||Date.now()-started>5*60*1000){if(timer){clearInterval(timer);timer=null}return}
  let f=null;try{const r=await chrome.runtime.sendMessage({type:'FLOW_GET'});f=r?.flow||null}catch{}
  if(!f||!f.asin)return;
  const asin=String(f.asin).toUpperCase(),tokens=(f.tokens||[]).map(norm),forbid=(f.forbid||[]).map(norm);
  // product lines: links/images that name a product, quantity boxes
  const lines=[];
  for(const a of document.querySelectorAll('a[href*="/dp/"],a[href*="/gp/product/"],img[alt]')){
   if(!shown(a)||personal(a))continue;
   const t=a.tagName==='IMG'?a.getAttribute('alt'):txt(a);if(!t||t.trim().length<6)continue;
   lines.push(clean(t));if(lines.length>=12)break;
  }
  const asinHits=[...document.querySelectorAll(`[data-asin="${asin}"],[data-itemid*="${asin}" i],a[href*="${asin}" i],input[value*="${asin}" i]`)].filter(shown).length;
  const qty=[...document.querySelectorAll('select[name*="quantity"],input[name*="quantity"],select[data-a-selector="quantity"],input[data-testid*="quantity" i],.a-dropdown-prompt')].filter(shown).map(e=>norm(e.value||txt(e)).slice(0,10)).slice(0,6);
  // the page's product area (without address / payment boxes)
  let area='';
  for(const e of document.querySelectorAll('.order-item,.checkout-item,[data-testid*="item" i],[data-itemid],[data-asin]')){if(shown(e)&&!personal(e))area+=' '+txt(e);if(area.length>20000)break}
  if(!area.trim())area=lines.join(' ');
  const a=norm(area);
  const forbidSeen=[];
  for(const w of forbid){let i=a.indexOf(w),n=0;while(i>=0&&n<3){forbidSeen.push(w+': "…'+clean(a.slice(Math.max(0,i-60),i+w.length+60))+'…"');i=a.indexOf(w,i+1);n++}}
  const rec={at:Date.now(),productId:f.id,asin,step:String(f.step||''),page:location.pathname.slice(0,80),asinOnPage:asinHits,
   wordsFound:tokens.filter(t=>a.includes(t)),wordsMissing:tokens.filter(t=>!a.includes(t)),forbiddenSeen:forbidSeen.slice(0,8),
   quantityBoxes:qty,productLines:[...new Set(lines)].slice(0,8),
   // v85: what this page IS (diagnostics 65-70: every Amazon checkout since 10-29 stopped on /checkout/p/.../itemselect, a page the
   // checkout does not know): its headings and the words of its buttons / choices - never names, addresses, emails or numbers
   headings:[...document.querySelectorAll('h1,h2,h3,[role="heading"]')].filter(e=>shown(e)&&!personal(e)).map(e=>clean(txt(e))).filter(x=>x&&x.length<120).slice(0,10),
   buttons:[...document.querySelectorAll('button,input[type="submit"],input[type="button"],a[role="button"],span.a-button-text')].filter(e=>shown(e)&&!personal(e)).map(e=>clean(e.value||txt(e))).filter(x=>x&&x.length<60).slice(0,16),
   choices:[...document.querySelectorAll('input[type="radio"],input[type="checkbox"]')].filter(e=>!personal(e)).map(e=>{const l=e.closest('label')||document.querySelector('label[for="'+e.id+'"]');return clean(txt(l)).slice(0,60)+(e.checked?' [chosen]':'')}).filter(Boolean).slice(0,10)};
  const sig=JSON.stringify({...rec,at:0});
  if(sig===last)return;last=sig;
  try{await chrome.storage.local.set({[KEY]:rec})}catch{}
 }
 if(onCheckout()){setTimeout(look,250);setTimeout(look,1000);timer=setInterval(look,2000)}
})();
