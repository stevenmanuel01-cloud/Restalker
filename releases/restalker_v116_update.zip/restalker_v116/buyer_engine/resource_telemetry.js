/* v3.23.8: Passive resource evidence for buyer field diagnostics.
 * System CPU/RAM from supported Chrome extensions APIs are whole-computer totals,
 * NOT CPU/RAM attributed to the extension or its Amazon renderer tabs.
 * Sampling never requests product pages or changes checkout/purchase authority.
 */
'use strict';
(() => {
 const KEY='resourceTelemetryV3238', MAX=720;
 let history=[],stats={sampleAttempts:0,successfulCpuSamples:0,failedCpuSamples:0,failedMemorySamples:0,failedTabSamples:0,events:{},loopCount:0,loopTotalMs:0,loopMaxMs:0},previous=null,loaded=false,loading=null,busy=false,samplesSincePersist=0;
 const num=v=>v===null||v===undefined||v===''?null:(Number.isFinite(Number(v))?Number(v):null);
 const err=e=>String(e?.message||e||'unknown').slice(0,160);
 const round=v=>Number.isFinite(v)?Math.round(v*100)/100:null;
 function deltaCpu(current, prior){
  if(!current||!prior||current.length!==prior.length)return null;
  let busy=0,total=0;
  for(let i=0;i<current.length;i++){
   const t=current[i].total-prior[i].total,idle=current[i].idle-prior[i].idle;
   if(!Number.isFinite(t)||!Number.isFinite(idle)||t<=0||idle<0||idle>t)return null;
   total+=t;busy+=t-idle;
  }
  return total>0?round(Math.min(100,Math.max(0,100*busy/total))):null;
 }
 async function load(){
  if(loaded)return;
  if(loading)return loading;
  loading=(async()=>{try{const z=(await chrome.storage.local.get(KEY))[KEY];if(z&&Array.isArray(z.samples))history=z.samples.slice(-MAX);if(z&&z.stats)stats={...stats,...z.stats,events:{...(z.stats.events||{})}};if(z&&Array.isArray(z.lastCpuCounters))previous=z.lastCpuCounters;}catch{}loaded=true})();
  try{await loading}finally{loading=null}
 }
 function note(type){
  if(!type)return;
  if(['check_start','check_page_ready','availability_observed','detection_wake','submit_latched','purchase_success','detector_catalog_sync_ack'].includes(type))stats.events[type]=(stats.events[type]||0)+1;
 }
 function noteTick(ms){if(Number.isFinite(ms)){stats.loopCount++;stats.loopTotalMs+=ms;stats.loopMaxMs=Math.max(stats.loopMaxMs,ms)}}
 async function capture({catalog,ps,g}={}){
  await load();if(busy)return null;busy=true;
  const row={at:Date.now(),systemCpuPercent:null,systemMemoryTotalBytes:null,systemMemoryAvailableBytes:null,systemMemoryUsedPercent:null,logicalProcessors:null,amazonTabs:null,buyerOwnedTabs:null,monitoredProducts:null,armedProducts:null,checkoutActive:null,errors:[],observedEvents:{...stats.events}};
  stats.sampleAttempts++;
  try{
   try{
    if(!chrome.system?.cpu?.getInfo)throw Error('chrome.system.cpu unavailable');
    const cpu=await chrome.system.cpu.getInfo();
    const counters=(cpu.processors||[]).map(p=>({total:num(p.usage?.total),idle:num(p.usage?.idle)}));
    if(!counters.length||counters.some(x=>x.total===null||x.idle===null))throw Error('CPU counter data unavailable');
    row.logicalProcessors=num(cpu.numOfProcessors)||counters.length;
    row.systemCpuPercent=deltaCpu(counters,previous);previous=counters;
    if(row.systemCpuPercent!==null)stats.successfulCpuSamples++;
   }catch(e){stats.failedCpuSamples++;row.errors.push('cpu: '+err(e))}
   try{
    if(!chrome.system?.memory?.getInfo)throw Error('chrome.system.memory unavailable');
    const m=await chrome.system.memory.getInfo();const total=num(m.capacity),free=num(m.availableCapacity);
    if(total===null||total<=0||free===null||free<0)throw Error('Memory counters invalid');
    row.systemMemoryTotalBytes=total;row.systemMemoryAvailableBytes=free;
    row.systemMemoryUsedPercent=round(100*(1-free/total));
   }catch(e){stats.failedMemorySamples++;row.errors.push('memory: '+err(e))}
   try{
    const tabs=await chrome.tabs.query({});row.amazonTabs=tabs.filter(t=>/^https?:\/\/([^/]*\.)?amazon\.com\//i.test(t.url||'')).length;
    if(typeof catalog==='function'&&typeof ps==='function'){
     const items=await catalog();const states=await Promise.all(items.map(p=>ps(p)));
     const ids=new Set(states.map(s=>s.tabId).filter(Number.isInteger));row.buyerOwnedTabs=tabs.filter(t=>ids.has(t.id)).length;
     row.monitoredProducts=states.filter(s=>s.monitor&&!s.purchased&&!s.attempted).length;
     row.armedProducts=states.filter(s=>s.armed&&!s.purchased&&!s.attempted).length;
    }
    if(typeof g==='function')row.checkoutActive=!!(await g()).cartOwner;
   }catch(e){stats.failedTabSamples++;row.errors.push('tabs: '+err(e))}
   history.push(row);if(history.length>MAX)history=history.slice(-MAX);
   if(++samplesSincePersist>=4){await persist()}
   return row;
  }finally{busy=false}
 }
 async function persist(){await load();samplesSincePersist=0;try{await chrome.storage.local.set({[KEY]:{schema:'buyer-resource-v1',samples:history.slice(-MAX),stats,lastCpuCounters:previous}})}catch(e){stats.lastSaveError=err(e)}}
 function summary(){
  const cpu=history.map(r=>r.systemCpuPercent).filter(Number.isFinite),ram=history.map(r=>r.systemMemoryUsedPercent).filter(Number.isFinite);
  const summaryFor=arr=>({samples:arr.length,mean:arr.length?round(arr.reduce((a,b)=>a+b,0)/arr.length):null,max:arr.length?round(Math.max(...arr)):null,min:arr.length?round(Math.min(...arr)):null});
  return {schema:'buyer-resource-v1',coverage:{systemCpuMeasured:cpu.length>0,systemMemoryMeasured:ram.length>0,buyerProcessCpuMeasured:false,buyerProcessMemoryMeasured:false,chromeTotalCpuMeasured:false,detectorProcessMeasured:false},systemCpuPercent:summaryFor(cpu),systemMemoryUsedPercent:summaryFor(ram),buyerTickDurationMs:stats.loopCount?{count:stats.loopCount,mean:round(stats.loopTotalMs/stats.loopCount),max:round(stats.loopMaxMs)}:null,sampleFailures:{cpu:stats.failedCpuSamples,memory:stats.failedMemorySamples,tabs:stats.failedTabSamples},totalEventsObserved:{...stats.events},lastSample:history.at(-1)||null,samples:history.slice(-MAX),note:'CPU and RAM readings measure whole computer, not Buyer/Chrome process. Buyer contribution requires native process-level telemetry; null means NOT MEASURED.'};
 }
 async function exportData(){await load();return summary()}
 globalThis.MTGBuyerResourceTelemetry={create:()=>({load,capture,persist,note,noteTick,exportData}),_deltaCpu:deltaCpu};
})();
