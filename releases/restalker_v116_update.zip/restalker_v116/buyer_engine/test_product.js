// Dedicated test controls. August v3.23 checkout workflow retained, with exclusive checkout freeze and verified-price disambiguation.
'use strict';
(() => {
 const el=id=>document.getElementById(id),key='legacy_test_';let testId=localStorage.getItem(key+'id')||'',busy=false,sticky='';
 el('testAsin').value=localStorage.getItem(key+'asin')||'';
 el('testCap').value=localStorage.getItem(key+'cap')||'';
 el('testAdvanced').onclick=()=>{document.body.classList.toggle('advancedShown');el('testAdvanced').textContent=document.body.classList.contains('advancedShown')?'Hide other products / advanced':'Show other products / advanced'};
 const status=(text,error=false)=>{const e=el('testStatus');e.textContent=text;e.style.color=error?'#aa1d1d':'#153850';sticky=error?text:''};
 for(const id of ['testAsin','testCap'])el(id).addEventListener('input',()=>{sticky='';localStorage.setItem(key+(id==='testAsin'?'asin':'cap'),el(id).value)})
 const asin=()=>String(el('testAsin').value||'').trim().toUpperCase();
 const cap=()=>{const raw=String(el('testCap').value||'').trim();return raw===''?null:Number(raw)};
 const setBusy=x=>{busy=x;el('testAdd').disabled=x;el('testRefresh').disabled=x;el('testArm').disabled=x;el('testDisarm').disabled=x};
 const response=async req=>{const r=await chrome.runtime.sendMessage(req);if(!r?.ok)throw Error(r?.reason||'Operation was not confirmed');return r};
 el('testAdd').onclick=async()=>{if(busy)return;if(!/^B[A-Z0-9]{9}$/.test(asin()))return status('Enter a valid 10-character Amazon ASIN',true);if(cap()!==null&&(!Number.isFinite(cap())||cap()<=0))return status('Maximum item price must be a positive number',true);
  setBusy(true);status('Disarming all products, opening exact Amazon listing and verifying price…');
  try{const r=await response({type:'TEST_ADD_PRODUCT',asin:asin(),cap:cap()});testId=r.id;localStorage.setItem(key+'id',testId);await load();status('VERIFIED '+r.asin+' · '+(r.price===null?'live price unknown':'Amazon $'+r.price.toFixed(2))+' · '+(r.cap===null?'ENTER CAP':'cap $'+r.cap.toFixed(2))+' · NOT ARMED.')}catch(e){status('ADD FAILED: '+String(e?.message||e),true)}finally{setBusy(false)}
 };
 el('testRefresh').onclick=async()=>{if(busy)return;if(!testId)return status('Add & Verify the product first',true);setBusy(true);status('Refreshing exact Amazon product page and price…');try{await response({type:'TEST_REFRESH_PRODUCT',productId:testId});await load();status('Price check completed; see fresh observation below.')}catch(e){status('REFRESH FAILED: '+e.message,true)}finally{setBusy(false)}};
 el('testArm').onclick=async()=>{if(busy)return;if(!testId)return status('Add & Verify the product first',true);
  const s=D?.states?.[testId],verified=String(s?.customAsin||'')===asin()&&Array.isArray(s?.customTokens)&&s.customTokens.length>=2&&Number(s?.customMetadataVerifiedAt)>0;
  if(!verified)return status('Exact ASIN/title not verified. Add & Verify first.',true);
  if(cap()===null||!Number.isFinite(cap())||cap()<=0)return status('Enter a positive maximum product price first.',true);
  if(!confirm('Authorize ONE REAL AMAZON CHECKOUT for ASIN '+asin()+' at or below ITEM price $'+cap().toFixed(2)+'? Other products will be disarmed.'))return;
  setBusy(true);status('ARM confirmed. Refreshing page; checkout only after a new eligible observation…');
  try{if(Math.abs(Number(s?.cap)-cap())>.0001)await response({type:'TEST_SET_CAP',productId:testId,cap:cap()});await response({type:'TEST_ARM_PRODUCT',productId:testId});await load();status('ARMED: '+asin()+' · fresh listing check started. Real purchase is authorized if eligible.')}catch(e){status('ARM REJECTED: '+e.message,true)}finally{setBusy(false)}
 };
 el('testDisarm').onclick=async()=>{if(busy)return;if(!testId)return status('No selected test product',true);setBusy(true);try{await response({type:'TEST_DISARM_PRODUCT',productId:testId});await load();status('DISARMED. Price monitoring may continue; purchase disabled.')}catch(e){status('DISARM FAILED: '+e.message,true)}finally{setBusy(false)}};
 async function update(){if(busy||sticky||!testId)return;try{const r=await chrome.runtime.sendMessage({type:'GET_ALL'}),s=r?.states?.[testId];if(!s)return;const aged=s.lastCheck?Math.max(0,Math.round((Date.now()-s.lastCheck)/1000))+'s ago':'never';const next=s.monitor&&Number(s.nextCheckAt)>0?Math.max(0,Math.round((Number(s.nextCheckAt)-Date.now())/1000))+'s':'not scheduled';const title=String(s.customName||s.customAsin||'').slice(0,90);el('testStatus').textContent=(r?.global?.cartOwner===testId?'CHECKOUT LOCKED — ALL REFRESHES PAUSED':s.armed&&s.autoBuy?'ARMED — REAL CHECKOUT AUTHORIZED':'DISARMED — NO PURCHASE')+' | '+title+' | Price '+(Number.isFinite(s.price)?'$'+Number(s.price).toFixed(2):'not verified')+' | Last fresh check '+aged+' | Next '+next+' | '+String(s.status||'');}catch(e){el('testStatus').textContent='Test status unavailable: '+String(e?.message||e)}}
 setInterval(()=>void update(),1500);void update();
})();
