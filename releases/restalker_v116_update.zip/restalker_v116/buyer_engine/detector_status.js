'use strict';
// Read-only bridge indicator; isolated from existing checkout and button handlers.
(()=>{
 const label=document.getElementById('detectorLink');if(!label)return;
 let pending=false;
 async function paint(){
  if(pending)return;pending=true;
  try{
   const r=await chrome.runtime.sendMessage({type:'GET_ALL'}),b=r?.detectorBridge;
   if(!b){label.textContent='Detector: status unavailable';return}
   const live=b.connected===true&&b.lastSyncAck?.ok===true;
   label.textContent=live?'Detector: CONNECTED · '+String(b.lastSyncAck?.enabledProducts??'?')+' products synced · buyer low-rate standby':
     b.connected?'Detector: connected, catalog sync pending · buyer direct fallback':
     'Detector: DISCONNECTED · buyer direct fallback';
   label.style.fontWeight='bold';label.style.color=live?'#087a36':'#9a3412';
  }catch(e){label.textContent='Detector: status unavailable · buyer direct fallback'}finally{pending=false}
 }
 void paint();setInterval(()=>void paint(),10000);
})();
