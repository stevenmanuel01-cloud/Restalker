"""Restalker - after Windows restarts (v117).

Owner 2026-11-12: "the computer restarted but when it booted back up it automatically restarted all of my windows for the restalker without
actually starting the program ... is there a way to ensure this doesnt happen until the program is restarted?"

Windows reopens, after a restart, the browsers that were open (they ask Windows to - Chrome and Edge always do; Firefox too) - also
Restalker's own browsers, but not Restalker itself. This small helper is started once by Windows when you sign in (Restalker puts it in
Windows' list of programs started at sign-in; switch in the Browsers tab). For 6 minutes it closes Restalker's OWN browsers that Windows
reopened - only while Restalker is NOT running - then it ends. It never touches your own browsers: only a browser whose start line names
this folder (its own profile here) or carries Restalker's mark. It never starts Restalker and never touches anything else.
"""
import os
import socket
import sys
import time

VERSION = "v118"
HERE = os.path.dirname(os.path.abspath(__file__))
EXES = ("chrome.exe", "msedge.exe", "firefox.exe", "camoufox.exe")
WATCH = 360.0
EVERY = 10.0
PORT = 8001


STARTERS = ("python.exe", "pythonw.exe", "py.exe", "node.exe")     # what starts a browser when Restalker itself starts it


def ours(name, cmdline, folder=HERE, parent=""):
    """A browser of THIS Restalker that Windows reopened: its start line carries Restalker's mark or names this folder (its own profile
    lives here) - and it was NOT started by Restalker (a browser Restalker starts has Restalker's Python - or its Playwright helper - as
    its parent: never touched, even in the moment Restalker is starting)."""
    n = str(name or "").lower()
    if n not in EXES or str(parent or "").lower() in STARTERS or str(parent or "").lower() in EXES:
        return False                    # (a browser's own helper processes end with it: only its main process is closed)
    cl = str(cmdline or "").lower().replace("/", "\\")
    f = str(folder).lower().replace("/", "\\").rstrip("\\") + "\\"
    return "--rk-store=" in cl or "--rk-buyer-visible" in cl or f in cl


def restalker_running(procs, folder=HERE, port=PORT):
    """True when this Restalker is running (its page answers, or its program is among the running ones)."""
    try:
        with socket.create_connection(("127.0.0.1", port), timeout=1.5):
            return True
    except Exception:
        pass
    f = str(folder).lower().replace("/", "\\").rstrip("\\")
    for name, cl, cwd in procs:
        if str(name or "").lower().startswith("py") and "app.py" in str(cl or "").lower() and str(cwd or "").lower().replace("/", "\\").rstrip("\\") == f:
            return True
    return False


def _procs():
    import psutil
    out = []
    for p in psutil.process_iter(["pid", "name", "cmdline"]):
        try:
            cwd = ""
            if str(p.info.get("name") or "").lower().startswith("py"):
                try:
                    cwd = p.cwd()
                except Exception:
                    cwd = ""
            try:
                par = p.parent()
                pn = par.name() if par else ""
            except Exception:
                pn = ""
            out.append((p, p.info.get("name"), " ".join(p.info.get("cmdline") or []), cwd, pn))
        except Exception:
            continue
    return out


def _note(msg):
    try:
        with open(os.path.join(HERE, "boot_cleanup.log"), "a", encoding="utf-8") as f:
            f.write(time.strftime("%Y-%m-%d %H:%M:%S ") + msg + "\n")
    except Exception:
        pass


def main():
    if os.name != "nt" or os.path.exists(os.path.join(HERE, "boot_cleanup_off.txt")):
        return 0
    try:
        import psutil  # noqa: F401
    except Exception:
        _note("psutil is missing - nothing done")
        return 0
    end, closed = time.time() + WATCH, 0
    while time.time() < end:
        ps = _procs()
        if restalker_running([(n, c, w) for _p, n, c, w, _pn in ps], HERE, PORT):
            break                                   # (Restalker runs: its browsers are its own business)
        for p, n, c, _w, pn in ps:
            if ours(n, c, HERE, pn):
                try:
                    p.kill()
                    closed += 1
                except Exception:
                    pass
        time.sleep(EVERY)
    if closed:
        _note(f"closed {closed} Restalker browser process(es) Windows had reopened after the restart (Restalker was not running).")
    return 0


if __name__ == "__main__":
    sys.exit(main())
