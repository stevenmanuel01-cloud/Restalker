"""v96: buttons on the phone messages (the free ntfy app) - so a purchase or a problem can be answered from the phone without reaching the PC.

Owner 2026-11-04: "if a product is purchased, I would like the ability to choose to rearm immediately with a link. I don't want to have to
separately remote into the desktop and click the button manually ... when there is a problem, I also want that alert to give me a link to be
able to solve it directly".

How it works (nothing on the PC is opened to the internet):
- A message about a purchase or a problem carries up to 3 buttons. A button that changes something does not open a web page: the ntfy app
  itself sends a short text ("rk1 <ticket>") to a SECOND private ntfy name that only this PC listens to (notify_cmd.txt, made by itself).
- The PC listens to that name (one connection it opens itself, like a browser tab that stays open) and does exactly what the same button on
  Restalker's own page does (amazon_buy.phone_do). Then it answers on the phone: "Done - ..." or "Could not - why".
- Every ticket is random, works ONCE, and only for its own product and its own action, and only for a limited time. A tap that reaches the
  PC late (the PC was off) is not carried out for a money action - you are asked again.
- Money actions ask once more ("Yes - buy one more"), so a stray tap never buys anything.
- Never through these buttons: a card security code, a password, a "prove you are a person" check. For those the button opens Chrome
  Remote Desktop on the phone, where the window is already open on the PC.
- A button that only shows something (the store's order list, Remote Desktop) is an ordinary link."""
import json, os, re, secrets, threading, time, urllib.parse, urllib.request

VERSION = "v118"
CMD_FILE = "notify_cmd.txt"            # the PC's private listening name (made once; keep it private like notify_phone.txt)
STATE_FILE = "phone_actions.json"      # the tickets that are still valid, and how far the PC has read its listening name
SERVER = os.environ.get("RK_NTFY_SERVER") or "https://ntfy.sh"
REMOTE_URL = "https://remotedesktop.google.com/access"
TICKET_RX = re.compile(r"^\s*rk1 ([A-Za-z0-9_-]{22,64})\s*$")
# how long a button works (seconds)
TTL = {"more": 24 * 3600, "bought": 24 * 3600, "notbought": 24 * 3600, "approve": 15 * 60, "cancel": 15 * 60, "ping": 3600,
       "confirm": 10 * 60, "msrpbuy": 30 * 60}
# v118 (owner: "a button that allows for a one click purchase"): "Buy now" on an at-MSRP message buys with ONE tap (no second question).
# It still works only once, only for 30 minutes, and a tap that reaches the PC more than 10 minutes late is not carried out (the price
# may have changed): you get the button again.
ONE_TAP_LATE = {"msrpbuy"}
TWO_STEP = {"more", "notbought"}       # these ask "are you sure?" first (they can lead to a purchase)
LATE = 10 * 60                         # a tap that reaches the PC later than this is not carried out for a two-step action
MAX_TICKETS = 400
LOG = None                             # set by start(): writes a line to the log
DO = None                              # set by start(): (kind, tid) -> {"ok", "text"/"reason"} - the same as the page's buttons
SEND = None                            # set by start(): (title, msg, actions=None) -> sends a phone message
_lock = threading.Lock()
_tickets = {}                          # ticket -> {"k", "tid", "nm", "store", "exp", "used", "made", "extra"}
_seen_ids = []                         # ntfy message ids already handled (a reconnect can send one again)
_st = {"since": None, "connected": False, "connects": 0, "last_error": "", "taps": 0, "done": 0, "refused": 0, "unknown": 0,
       "late": 0, "last": "", "started": False}
_stop = threading.Event()


def _log(msg):
    try:
        if LOG:
            LOG("[phone] " + msg)
    except Exception:
        pass


def cmd_topic(make=True):
    """The PC's private listening name. Made once, kept in notify_cmd.txt."""
    try:
        t = open(CMD_FILE, encoding="utf-8").read().strip()
        if re.fullmatch(r"[A-Za-z0-9_-]{20,64}", t):
            return t
    except Exception:
        pass
    if not make:
        return ""
    t = "rkcmd-" + secrets.token_urlsafe(24).replace("-", "x").replace("_", "y")[:30]
    try:
        with open(CMD_FILE, "w", encoding="utf-8") as f:
            f.write(t + "\n")
    except Exception:
        return ""
    return t


def _save():
    try:
        with _lock:
            d = {"since": _st.get("since"), "seen": _seen_ids[-200:], "tickets": _tickets}
        tmp = STATE_FILE + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(d, f)
        os.replace(tmp, STATE_FILE)
    except Exception:
        pass


def _load():
    try:
        with open(STATE_FILE, encoding="utf-8") as f:
            d = json.load(f)
        now = time.time()
        with _lock:
            for k, v in (d.get("tickets") or {}).items():
                if isinstance(v, dict) and float(v.get("exp") or 0) > now and re.fullmatch(r"[A-Za-z0-9_-]{22,64}", k):
                    _tickets[k] = v
            _seen_ids[:] = [x for x in (d.get("seen") or []) if isinstance(x, str)][-200:]
            s = d.get("since")
            if isinstance(s, (int, float)) and now - s < 6 * 3600:
                _st["since"] = int(s)
    except Exception:
        pass


def _ticket(kind, tid, nm="", store="", extra=None, ttl=None):
    t = secrets.token_urlsafe(18)
    now = time.time()
    with _lock:
        for k in [k for k, v in _tickets.items() if float(v.get("exp") or 0) <= now]:
            _tickets.pop(k, None)
        while len(_tickets) >= MAX_TICKETS:
            _tickets.pop(min(_tickets, key=lambda k: _tickets[k].get("made", 0)), None)
        _tickets[t] = {"k": kind, "tid": tid, "nm": nm, "store": store, "exp": now + (ttl or TTL.get(kind, 3600)), "used": 0, "made": now,
                       "extra": extra or {}}
    _save()
    return t


def _http(label, ticket):
    topic = cmd_topic()
    if not topic:
        return None
    return {"action": "http", "label": label[:40], "url": SERVER + "/" + topic, "method": "POST", "body": "rk1 " + ticket, "clear": True}


def _view(label, url):
    return {"action": "view", "label": label[:40], "url": url, "clear": False}


def _orders_url(store):
    try:
        import multibuy
        for k, v in multibuy.STORES.items():
            if multibuy.STORE_NAMES.get(k, k).lower() == str(store or "").lower() or k == str(store or "").lower():
                return v.get("orders")
    except Exception:
        pass
    return None


def buttons(situation, tid, nm="", store="", extra=None):
    """The buttons of one message. situation: bought / approve / unclear / checking / remote / more. -> list (at most 3), may be empty."""
    if not tid and situation not in ("remote",):
        return []
    out = []
    try:
        if situation == "bought":
            out.append(_http("Buy one more", _ticket("more", tid, nm, store)))
            u = _orders_url(store)
            if u:
                out.append(_view(f"{store} orders", u))
        elif situation == "more":
            out.append(_http("Buy one more", _ticket("more", tid, nm, store)))
        elif situation == "approve":
            ship = (extra or {}).get("shipping")
            out.append(_http(("Approve " + ship + " shipping") if ship else "Approve shipping", _ticket("approve", tid, nm, store)))
            out.append(_http("Do not buy", _ticket("cancel", tid, nm, store)))
        elif situation == "unclear":
            out.append(_http("It was bought", _ticket("bought", tid, nm, store)))
            out.append(_http("Not ordered - buy again", _ticket("notbought", tid, nm, store)))
            u = _orders_url(store)
            if u:
                out.append(_view(f"{store} orders", u))
        elif situation == "checking":
            # (Restalker is still looking in your orders by itself: only "it was bought" - "not ordered" could buy a second one meanwhile)
            out.append(_http("It was bought", _ticket("bought", tid, nm, store)))
            u = _orders_url(store)
            if u:
                out.append(_view(f"{store} orders", u))
        elif situation == "remote":
            out.append(_view("Open Remote Desktop", REMOTE_URL))
        elif situation == "msrpbuy":
            out.append(_http("Buy now", _ticket("msrpbuy", tid, nm, store)))
            u = str((extra or {}).get("url") or "")
            if re.match(r"^https://[^\s]+$", u):
                out.append(_view(f"Open {store or 'the store'}", u))
    except Exception as e:
        _log(f"buttons could not be made ({str(e)[:80]}) - the message goes out without them")
        return []
    return [b for b in out if b][:3]


def test_buttons():
    """The button of the test message: tapping it shows that a tap reaches this PC."""
    b = _http("Test this button", _ticket("ping", "", "", "", extra={"at": time.time()}))
    return [b] if b else []


# ---------------------------------------------------------------- what a tap does

def _reply(title, msg, actions=None):
    try:
        if SEND:
            SEND(title, msg, actions)
    except Exception as e:
        _log(f"the answer to your tap could not be sent: {str(e)[:80]}")


_WHAT = {"more": "buy ONE MORE", "notbought": "mark it NOT ordered and buy it again", "bought": "mark it as bought",
         "approve": "approve the shipping", "cancel": "not buy it (shipping not approved)", "msrpbuy": "buy it now (at MSRP)"}


def handle(body, sent_at=None, msg_id=None):
    """One message on the PC's listening name. -> a short word for the log/tests: done / asked / refused / late / used / expired / unknown / dup."""
    now = time.time()
    if msg_id:
        with _lock:
            if msg_id in _seen_ids:
                return "dup"
            _seen_ids.append(msg_id)
            del _seen_ids[:-200]
    m = TICKET_RX.match(str(body or ""))
    if not m:
        _st["unknown"] += 1
        return "unknown"
    tk = m.group(1)
    with _lock:
        rec = _tickets.get(tk)
        if rec is None:
            _st["unknown"] += 1
            return "unknown"
        if rec.get("used"):
            return "used"
        if float(rec.get("exp") or 0) <= now:
            _tickets.pop(tk, None)
            return "expired"
        rec["used"] = now                       # (used at once: two taps, or a tap read twice, do it only once)
    _save()
    _st["taps"] += 1
    kind, tid, nm, store = rec["k"], rec.get("tid"), rec.get("nm") or rec.get("tid") or "", rec.get("store") or ""
    late = sent_at is not None and now - float(sent_at) > LATE
    if kind == "ping":
        _st["done"] += 1
        _reply("The button works", f"Restalker on your PC got your tap {max(0, int(now - float(sent_at or now)))} s after you pressed it.")
        _log("the test button was pressed on the phone - it reached the PC.")
        return "done"
    if kind in ONE_TAP_LATE and late:
        _st["late"] += 1
        _reply(f"Not bought - {nm}", f"Your tap reached the PC {int((now - float(sent_at)) / 60)} min late (it was not reachable), so nothing was "
                                     f"bought - the price may have changed. Tap again if you still want it:", buttons(kind, tid, nm, store))
        _log(f"{nm}: a tap ({_WHAT.get(kind)}) reached the PC late - not done, asked again.")
        return "late"
    if kind in TWO_STEP:
        if late:
            _st["late"] += 1
            _reply(f"Not done - {nm}", f"Your tap reached the PC {int((now - float(sent_at)) / 60)} min late (it was not reachable), so nothing was "
                                        f"done. Here is the button again:", buttons("more" if kind == "more" else "unclear", tid, nm, store))
            _log(f"{nm}: a tap ({_WHAT.get(kind)}) reached the PC late - not done, asked again.")
            return "late"
        c = _ticket("confirm", tid, nm, store, extra={"do": kind})
        q = (f"Buy ONE MORE of {nm}? It was already bought once. It is bought at the next restock, at or under its price cap."
             if kind == "more" else
             f"You checked your {store} orders and {nm} was NOT ordered? It is then bought at the next restock (at or under its price cap).")
        b = _http("Yes - " + ("buy one more" if kind == "more" else "buy it again"), c)
        _reply(f"Are you sure? - {nm}", q, [b] if b else None)
        _log(f"{nm}: '{_WHAT.get(kind)}' pressed on the phone - asking once more before doing it.")
        return "asked"
    if kind == "confirm":
        kind = (rec.get("extra") or {}).get("do") or ""
        if kind not in TWO_STEP:
            return "unknown"
    return _do(kind, tid, nm, store)


def _do(kind, tid, nm, store):
    try:
        r = DO(kind, tid) if DO else {"ok": False, "reason": "the program is still starting"}
    except Exception as e:
        r = {"ok": False, "reason": str(e)[:160]}
    r = r or {}
    if r.get("ok"):
        _st["done"] += 1
        _st["last"] = time.strftime("%H:%M:%S") + f" {kind} {tid}"
        _reply(f"Done - {nm}", r.get("text") or f"Done: {_WHAT.get(kind, kind)}.")
        _log(f"{nm}: '{_WHAT.get(kind, kind)}' chosen on the phone - done.")
        return "done"
    _st["refused"] += 1
    _reply(f"Could not - {nm}", f"Not done ({_WHAT.get(kind, kind)}): {r.get('reason') or 'no answer'}.")
    _log(f"{nm}: '{_WHAT.get(kind, kind)}' chosen on the phone - NOT done: {r.get('reason')}")
    return "refused"


# ---------------------------------------------------------------- listening (the PC opens the connection itself)

def _listen(have_phone):
    wait = 2.0
    while not _stop.is_set():
        topic = cmd_topic(make=False)
        if not topic or not have_phone():
            _st["connected"] = False
            _stop.wait(20.0)
            continue
        since = _st.get("since") or int(time.time() - 300)
        url = f"{SERVER}/{topic}/json?" + urllib.parse.urlencode({"since": str(int(since))})
        try:
            resp = urllib.request.urlopen(urllib.request.Request(url, headers={"User-Agent": "Restalker"}), timeout=100)
            _st["connected"] = True
            _st["connects"] += 1
            wait = 2.0
            for raw in resp:
                if _stop.is_set():
                    break
                try:
                    ev = json.loads(raw.decode("utf-8", "replace"))
                except Exception:
                    continue
                if ev.get("event") != "message":
                    continue
                t = ev.get("time")
                if isinstance(t, (int, float)):
                    _st["since"] = max(int(_st.get("since") or 0), int(t))
                try:
                    threading.Thread(target=handle, args=(ev.get("message"), t, ev.get("id")), daemon=True, name="phone-tap").start()
                except Exception:
                    pass
            _st["connected"] = False
        except Exception as e:
            _st["connected"] = False
            _st["last_error"] = str(e)[:120]
            _stop.wait(wait)
            wait = min(60.0, wait * 2)
        _save()


def start(log, do, send, have_phone):
    """Called once by app.py. log(msg); do(kind, tid) -> dict; send(title, msg, actions); have_phone() -> bool (a phone name is set up)."""
    global LOG, DO, SEND
    LOG, DO, SEND = log, do, send
    if _st["started"]:
        return
    _st["started"] = True
    _load()
    if have_phone():
        cmd_topic()                             # (made now, so the first purchase message already has its buttons)
    threading.Thread(target=_listen, args=(have_phone,), daemon=True, name="phone-listen").start()


def status():
    now = time.time()
    with _lock:
        valid = sum(1 for v in _tickets.values() if not v.get("used") and float(v.get("exp") or 0) > now)
    return dict(_st, valid_buttons=valid, listening_name_set=bool(cmd_topic(make=False)))


def report_text():
    s = status()
    return (f"phone buttons (v96): listening {'YES' if s['connected'] else 'no'} (connections {s['connects']}"
            + (f", last problem: {s['last_error']}" if s['last_error'] else "") + f"); buttons still valid {s['valid_buttons']}; taps received "
            f"{s['taps']} (done {s['done']}, could not {s['refused']}, reached the PC too late {s['late']}); unknown messages {s['unknown']}"
            + (f"; last: {s['last']}" if s['last'] else ""))
