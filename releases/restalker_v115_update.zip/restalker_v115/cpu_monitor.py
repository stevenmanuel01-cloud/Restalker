"""Measures how much of the PC this program (and the browsers it started) uses,
so it can be checked from the diagnostics instead of guessed. Needs 'psutil';
without it only the program's own part is measured."""
import os
import threading
import time

VERSION = "v115"

_STATE = {"samples": [], "mode": "starting", "cores": 1, "started": time.time(), "stores": {},
          "pc": [], "mine_mb": [], "mine_by_store": {}, "others": []}
_LOCK = threading.Lock()


def recent_avg(minutes=5):
    """Average of this program's CPU (% of one core) over the last few minute-samples; 0 when there are none yet."""
    with _LOCK:
        s = [x[0] for x in _STATE["samples"][-int(minutes):]]
    return (sum(s) / len(s)) if len(s) >= 3 else 0.0


def pc_busy_avg(minutes=3):
    """Average busy % of the WHOLE PC (all programs, all cores) over the last few minute-samples; None when not measured yet."""
    with _LOCK:
        s = [x[0] for x in _STATE["pc"][-int(minutes):]]
    return (sum(s) / len(s)) if len(s) >= 2 else None


def ram_gb():
    """Total memory of the PC in GB (None until the first look)."""
    with _LOCK:
        return _STATE.get("ram_gb")


def mine_gb(minutes=2):
    """v46: this program's memory (python + all its browsers) in GB, the highest of the last few minute-samples; None when not measured yet."""
    with _LOCK:
        s = [x[0] for x in _STATE["mine_mb"][-int(minutes):]]
    return (max(s) / 1024.0) if len(s) >= 2 else None


def pc_free_gb(minutes=2):
    """The LOWEST free memory (GB, whole PC) over the last few minute-samples; None when not measured yet."""
    with _LOCK:
        s = [x[2] for x in _STATE["pc"][-int(minutes):] if len(x) > 2]
    return min(s) if len(s) >= 2 else None


# ---- stay out of the way of a game: the browsers run at the LOWEST priority, so the PC always serves the game first ----
_PRIO = {"set": 0, "last": "", "errors": 0}


READER_PARTS = ("amazon", "bestbuy", "target", "walmart", "gamestop", "reader")      # the browsers that READ the stores (the others are fixed costs)


def parts_now(max_age=180.0):
    """v80: -> {"cpu": {part: % of one core}, "mb": {part: MB}, "py": % of one core} from the last minute-sample, or None when too old.
    Parts are the --rk-store marks: buyer, reader, the store names, other (the other buying browsers), alerts, pages, finder."""
    with _LOCK:
        c, m = _STATE.get("last_cpu"), _STATE.get("last_mb")
    now = time.time()
    if not c or not m or now - c["at"] > max_age or now - m["at"] > max_age:
        return None
    return {"cpu": dict(c["cpu"]), "mb": dict(m["mb"]), "py": c.get("py") or 0.0}


def part_mb(part):
    p = parts_now()
    return None if p is None else float(p["mb"].get(part, 0.0))


def _eco_mode(pid, on=True):
    """Windows 'efficiency mode' (runs the process on the PC's slow, low-power cores). Only used in Gaming mode."""
    if os.name != "nt":
        return False
    try:
        import ctypes
        from ctypes import wintypes
        k = ctypes.windll.kernel32
        h = k.OpenProcess(0x0200, False, int(pid))          # PROCESS_SET_INFORMATION
        if not h:
            return False

        class _PPT(ctypes.Structure):
            _fields_ = [("Version", wintypes.ULONG), ("ControlMask", wintypes.ULONG), ("StateMask", wintypes.ULONG)]
        st = _PPT(1, 1, 1 if on else 0)                     # execution-speed throttling on / off
        ok = k.SetProcessInformation(h, 4, ctypes.byref(st), ctypes.sizeof(st))   # 4 = ProcessPowerThrottling
        k.CloseHandle(h)
        return bool(ok)
    except Exception:
        return False


def game_cores(n):
    """v110: the logical processors this program and its browsers keep to while a game runs: the upper half (on a Ryzen 9 with two
    core groups that is the second group, with its own cache - the game keeps the first group and its cache to itself). None on a
    PC with fewer than 8 logical processors (too few to split)."""
    try:
        n = int(n or 0)
    except Exception:
        return None
    return list(range(n // 2, n)) if n >= 8 else None


_ECO = set()          # pids put in efficiency mode (switched back off when Gaming mode ends)
_AFF = set()          # pids kept to the game-time cores (given every core back when Gaming mode ends)


def apply_priorities(psutil, me, gaming=False, kids=None, cores=None):
    """Puts every browser process this program started (and, in Gaming mode, the program itself) at the lowest priority.
    Chrome sets its own priorities now and then, so this is repeated (cheap: only processes that differ are touched).
    v110: in Gaming mode they also keep to half of the processors (game_cores) and leave the other half - and its cache - to the
    game; when Gaming mode ends they get every processor back and efficiency mode is switched off again."""
    low = getattr(psutil, "IDLE_PRIORITY_CLASS", None) if os.name == "nt" else 10
    below = getattr(psutil, "BELOW_NORMAL_PRIORITY_CLASS", None) if os.name == "nt" else 5
    n = 0
    try:
        kids = kids if kids is not None else me.children(recursive=True)
    except Exception:
        kids = []
    try:
        cores = cores or psutil.cpu_count() or 1
    except Exception:
        cores = 1
    gc_ = game_cores(cores) if gaming else None
    every = list(range(int(cores)))
    alive = set()
    for k in list(kids) + [me]:
        pid = k.pid
        alive.add(pid)
        try:
            if k is not me and low is not None and k.nice() != low:
                k.nice(low)
                n += 1
            if os.name == "nt" and k is not me:
                if gaming:                                   # (again every round: Chrome sets its own now and then)
                    if _eco_mode(pid, True):
                        _ECO.add(pid)
                elif not gaming and pid in _ECO:
                    _eco_mode(pid, False)
                    _ECO.discard(pid)
            if gc_ and hasattr(k, "cpu_affinity"):
                if sorted(k.cpu_affinity()) != gc_:
                    k.cpu_affinity(gc_)
                _AFF.add(pid)
            elif pid in _AFF and hasattr(k, "cpu_affinity"):
                if len(k.cpu_affinity()) != len(every):
                    k.cpu_affinity(every)
                _AFF.discard(pid)
        except Exception:
            _PRIO["errors"] += 1
    _ECO.intersection_update(alive)
    _AFF.intersection_update(alive)
    try:
        want = low if gaming else below
        if want is not None and os.name == "nt" and me.nice() != want:
            me.nice(want)
            n += 1
    except Exception:
        _PRIO["errors"] += 1
    _PRIO["set"] += n
    _PRIO["last"] = (f"{len(kids)} browser processes at lowest priority" + (" + efficiency mode (Gaming mode)" if gaming else "")
                     + (f"; while the game runs this program keeps to processors {gc_[0]}-{gc_[-1]} of {cores} (the game has the others and their cache)"
                        if gc_ else ""))
    return n


# ---- v110: how much of the graphics card each program uses (owner 2026-11-08: "the program is still really lagging when i am playing a
# game" - diagnostics 88: Gaming mode was on, the program at the lowest priority, yet the game lagged; the browsers draw their pages on
# the same graphics card as the game and OBS, and that was never measured). Windows' own count (the one Task Manager shows), read with
# its built-in typeperf tool every 5 minutes, without a window, at the lowest priority. Read only.
GPU_EVERY = 300.0
_GPU = []             # [(t, ours %, {program: %})] newest last


def parse_gpu_csv(text):
    """typeperf's answer -> {pid: % of the graphics card} (per program: its busiest kind of GPU work, as Task Manager shows it)."""
    import csv
    import io
    import re
    rows = [r for r in csv.reader(io.StringIO(text or "")) if r]
    head = next((r for r in rows if "GPU Engine(" in "".join(r)), None)
    if not head:
        return {}
    i = rows.index(head)
    data = next((r for r in rows[i + 1:] if len(r) == len(head)), None)
    if not data:
        return {}
    per = {}
    for h, v in zip(head[1:], data[1:]):
        m = re.search(r"pid_(\d+)_.*?engtype_([^)\\]*)\)", h)
        if not m:
            continue
        try:
            x = float(str(v).strip() or 0)
        except Exception:
            continue
        d = per.setdefault(int(m.group(1)), {})
        d[m.group(2)] = d.get(m.group(2), 0.0) + x
    return {pid: min(100.0, max(d.values())) for pid, d in per.items() if d}


def _gpu_look(psutil, me):
    import subprocess
    r = subprocess.run(["typeperf", r"\GPU Engine(*)\Utilization Percentage", "-sc", "1"], capture_output=True, text=True, timeout=40,
                       creationflags=(0x08000000 | 0x00000040) if os.name == "nt" else 0)      # no window, lowest priority
    by_pid = parse_gpu_csv(r.stdout)
    if not by_pid:
        return None
    try:
        mine = {me.pid} | {k.pid for k in me.children(recursive=True)}
    except Exception:
        mine = {me.pid}
    ours, others = 0.0, {}
    for pid, x in by_pid.items():
        if pid in mine:
            ours += x
            continue
        if x < 0.5:
            continue
        try:
            nm = psutil.Process(pid).name()
        except Exception:
            nm = f"pid {pid}"
        others[nm] = others.get(nm, 0.0) + x
    snap = (time.time(), min(100.0, ours), others)
    with _LOCK:
        _GPU.append(snap)
        del _GPU[:-24]
    return snap


def gpu_text():
    with _LOCK:
        g = list(_GPU)
    if not g:
        return " GPU: not measured yet (Windows only, every 5 minutes)." if os.name == "nt" else ""
    last = g[-6:]
    avg = sum(x[1] for x in last) / len(last)
    tot = {}
    for _t, _o, oth in last:
        for k, v in oth.items():
            tot[k] = tot.get(k, 0.0) + v / len(last)
    top = sorted(tot.items(), key=lambda kv: -kv[1])[:5]
    return (f" GRAPHICS CARD (Windows' own count, every 5 min, last 30 min average, % of the card): this program's browsers {avg:.0f}% "
            f"(latest {g[-1][1]:.0f}%, highest {max(x[1] for x in g):.0f}%); other programs: "
            + (", ".join(f"{k} {v:.0f}%" for k, v in top) or "none above 1%") + ".")


def priority_text():
    return _PRIO["last"] or "not applied yet"


def summary():
    """One short text for the diagnostics."""
    with _LOCK:
        s = list(_STATE["samples"])
        mode, cores = _STATE["mode"], _STATE["cores"]
    if not s:
        return f"no samples yet ({mode})"
    tot = [x[0] for x in s]
    py = [x[1] for x in s]
    br = [x[2] for x in s]
    avg = sum(tot) / len(tot)
    with _LOCK:
        st = {k: list(v) for k, v in _STATE["stores"].items()}
    per = ""
    if st:
        # average over the last 30 minutes, per store (which store's browser costs what)
        parts = sorted(((sum(v[-30:]) / len(v[-30:]), k) for k, v in st.items()), reverse=True)
        per = " Browsers by store (last 30 min, % of one core): " + ", ".join(f"{k} {a:.0f}%" for a, k in parts) + "."
    return (f"{len(s)} samples, 1 per minute ({mode}). This program + its browsers, as % of ONE core: "
            f"average {avg:.0f}%, highest {max(tot):.0f}%, latest {tot[-1]:.0f}%  "
            f"(= average {avg / cores:.1f}% of the whole PC, {cores} cores). "
            f"Of the average: python {sum(py) / len(py):.0f}%, browsers {sum(br) / len(br):.0f}%." + per + _extra_text() + gpu_text())


def _extra_text():
    """Whole-PC load, memory, and which OTHER programs are busy - so 'my PC is slow' can be traced to its cause."""
    try:
        with _LOCK:
            pc = list(_STATE["pc"])
            mine = list(_STATE["mine_mb"])
            by = {k: list(v) for k, v in _STATE["mine_by_store"].items()}
            oth = list(_STATE["others"])
            by_exe = dict(_STATE.get("by_exe") or {})
        if not pc:
            return ""
        cpu = [x[0] for x in pc]
        used = [x[1] for x in pc]
        avail = [x[2] for x in pc]
        out = (f" WHOLE PC (all programs): busy average {sum(cpu) / len(cpu):.0f}%, highest {max(cpu):.0f}%, latest {cpu[-1]:.0f}%; "
               f"memory used latest {used[-1]:.0f}% (highest {max(used):.0f}%), free memory latest {avail[-1]:.1f} GB (lowest {min(avail):.1f} GB).")
        if mine:
            first = mine[:60]
            out += (f" THIS PROGRAM'S MEMORY: now {mine[-1][0]:.0f} MB (python {mine[-1][1]:.0f} MB, browsers {mine[-1][2]:.0f} MB); "
                    f"first hour average {sum(m[0] for m in first) / len(first):.0f} MB; highest {max(m[0] for m in mine):.0f} MB.")
            if by:
                top = sorted(((v[-1], k) for k, v in by.items() if v), reverse=True)
                out += " Browser memory by store now: " + ", ".join(f"{k} {a:.0f} MB" for a, k in top) + "."
        if by_exe:
            topx = sorted(by_exe.items(), key=lambda kv: -kv[1][1])[:8]
            out += " This program's processes now ([store] program: count, MB): " + "; ".join(f"{k}: {c}, {m:.0f} MB" for k, (c, m) in topx) + "."
        if oth:
            last30 = oth[-30:]
            cpu_sum, mem_last = {}, {}
            for snap in last30:
                for name, (c, m) in snap.items():
                    cpu_sum[name] = cpu_sum.get(name, 0.0) + c
            for name, (c, m) in last30[-1].items():
                mem_last[name] = m
            topc = sorted(((v / len(last30), k) for k, v in cpu_sum.items()), reverse=True)[:5]
            topm = sorted(((v, k) for k, v in mem_last.items()), reverse=True)[:5]
            out += (" OTHER PROGRAMS busiest (last 30 min average, % of one core): "
                    + (", ".join(f"{k} {a:.0f}%" for a, k in topc if a >= 1) or "none above 1%") + "."
                    + " Using most memory now: " + ", ".join(f"{k} {m:.0f} MB" for m, k in topm) + ".")
        return out
    except Exception as e:
        return f" (whole-PC part failed: {e})"


def _whole_pc(psutil, me, kids, owner, others):
    """One look at the whole PC: total load, memory, this program's memory, and the busiest other programs."""
    sys_cpu = psutil.cpu_percent(None)
    vm = psutil.virtual_memory()
    by_exe = {}
    py_mb = 0.0
    try:
        py_mb = me.memory_info().rss / 1048576.0
    except Exception:
        pass
    br_mb, by_store = 0.0, {}
    ours = {me.pid}
    for k in kids:
        ours.add(k.pid)
        try:
            m = k.memory_info().rss / 1048576.0
        except Exception:
            continue
        br_mb += m
        try:
            en = (k.name() or "?").lower()[:30]
        except Exception:
            en = "?"
        key = ("[" + owner.get(k.pid, "other") + "] " + en)
        c0 = by_exe.get(key, (0, 0.0))
        by_exe[key] = (c0[0] + 1, c0[1] + m)
        by_store[owner.get(k.pid, "other")] = by_store.get(owner.get(k.pid, "other"), 0.0) + m
    snap, alive = {}, set()
    for p in psutil.process_iter(["pid", "name"]):
        pid = p.info["pid"]
        alive.add(pid)
        if pid in ours or pid == 0:
            continue
        q = others.setdefault(pid, p)
        try:
            c = q.cpu_percent(None)
            m = q.memory_info().rss / 1048576.0
        except Exception:
            continue
        name = (p.info.get("name") or "?")[:40]
        a = snap.get(name, (0.0, 0.0))
        snap[name] = (a[0] + c, a[1] + m)
    for pid in list(others):
        if pid not in alive:
            others.pop(pid, None)
    keep = dict(sorted(snap.items(), key=lambda kv: -kv[1][0])[:8])
    for name, v in sorted(snap.items(), key=lambda kv: -kv[1][1])[:8]:
        keep[name] = v
    with _LOCK:
        _STATE["ram_gb"] = vm.total / 1073741824.0
        _STATE["by_exe"] = by_exe
        _STATE["pc"].append((sys_cpu, vm.percent, vm.available / 1073741824.0))
        _STATE["pc"] = _STATE["pc"][-720:]
        _STATE["mine_mb"].append((py_mb + br_mb, py_mb, br_mb))
        _STATE["mine_mb"] = _STATE["mine_mb"][-720:]
        for store, v in by_store.items():
            _STATE["mine_by_store"].setdefault(store, []).append(v)
            _STATE["mine_by_store"][store] = _STATE["mine_by_store"][store][-720:]
        _STATE["last_mb"] = {"at": time.time(), "mb": dict(by_store)}          # v80: memory of each part of the program, right now
        _STATE["others"].append(keep)
        _STATE["others"] = _STATE["others"][-720:]


def _tidy_memory():
    """Every 10 minutes: collect garbage and hand unused memory pages back to Windows."""
    try:
        import gc
        gc.collect()
    except Exception:
        pass
    try:
        import ctypes
        ctypes.windll.psapi.EmptyWorkingSet(ctypes.windll.kernel32.GetCurrentProcess())
    except Exception:
        pass


_CENSUS = {"last": None}


def _census(log_fn, me):
    """Every 30 minutes, if this program's python part is big: what kinds of objects it holds (to find a leak)."""
    rss = me.memory_info().rss / 1048576.0
    if rss < 650:       # v45 (was 500): more products = a bigger normal size
        return
    import gc, sys
    counts, sizes = {}, {}
    for o in gc.get_objects():
        t = type(o).__name__
        counts[t] = counts.get(t, 0) + 1
        if t in ("str", "bytes", "list", "dict", "tuple", "set", "bytearray"):
            try:
                sizes[t] = sizes.get(t, 0) + sys.getsizeof(o)
            except Exception:
                pass
    top = sorted(counts.items(), key=lambda kv: -kv[1])[:6]
    big = sorted(sizes.items(), key=lambda kv: -kv[1])[:5]
    prev = _CENSUS["last"] or {}
    grow = ", ".join(f"{k} {v / 1048576:.0f} MB ({(v - prev.get(k, v)) / 1048576:+.0f})" for k, v in big)
    _CENSUS["last"] = dict(sizes)
    del counts, sizes
    log_fn(f"[memory] python part {rss:.0f} MB. Most numerous objects: " + ", ".join(f"{k} {v}" for k, v in top)
           + f". Biggest by size (change since last look): {grow}.")


def start(log_fn=print, every=60.0):
    def loop():
        try:
            import psutil
        except Exception:
            psutil = None
        if psutil is None:
            _STATE["mode"] = "python part only - run 'py -m pip install psutil' to include the browsers"
            last_cpu, last_t = time.process_time(), time.time()
            while True:
                time.sleep(every)
                now_cpu, now_t = time.process_time(), time.time()
                pct = 100.0 * (now_cpu - last_cpu) / max(0.001, now_t - last_t)
                last_cpu, last_t = now_cpu, now_t
                with _LOCK:
                    _STATE["samples"].append((pct, pct, 0.0))
                    _STATE["samples"] = _STATE["samples"][-720:]
            return
        _STATE["mode"] = "psutil"
        _STATE["cores"] = psutil.cpu_count() or 1
        me = psutil.Process()

        def _sweep():
            while True:
                try:
                    g = False
                    try:
                        import hotness
                        g = hotness.gaming()
                    except Exception:
                        pass
                    apply_priorities(psutil, me, g)
                except Exception:
                    pass
                time.sleep(10.0)
        threading.Thread(target=_sweep, daemon=True, name="priority-sweeper").start()

        def _gpu_loop():
            time.sleep(60.0)
            fails = 0
            while os.name == "nt" and fails < 5:
                try:
                    fails = 0 if _gpu_look(psutil, me) else fails + 1
                except Exception:
                    fails += 1
                time.sleep(GPU_EVERY)
        threading.Thread(target=_gpu_loop, daemon=True, name="gpu-monitor").start()
        known = {}
        tags = {}      # pid -> store name (read from the --rk-store= mark the program puts on its browsers)
        me.cpu_percent(None)
        try:
            psutil.cpu_percent(None)
        except Exception:
            pass
        others = {}        # pid -> Process (kept so cpu_percent can compare with the last look)
        n = 0
        while True:
            time.sleep(every)
            try:
                kids = me.children(recursive=True)
            except Exception:
                kids = []
            py = me.cpu_percent(None)
            br = 0.0
            alive = set()
            use = {}
            for k in kids:
                alive.add(k.pid)
                p = known.setdefault(k.pid, k)
                if k.pid not in tags:
                    tags[k.pid] = None
                    try:
                        for a in p.cmdline():
                            if a.startswith("--rk-store="):
                                tags[k.pid] = a.split("=", 1)[1]
                                break
                    except Exception:
                        pass
                try:
                    use[k.pid] = p.cpu_percent(None)
                except Exception:
                    use[k.pid] = 0.0
                br += use[k.pid]
            # who owns each process: the nearest parent that carries a store mark; helper programs
            # that start a marked browser (the automation driver) are credited to that store
            ppid = {}
            for k in kids:
                try:
                    ppid[k.pid] = k.ppid()
                except Exception:
                    ppid[k.pid] = None
            owner = {}
            for pid in use:
                q, hops = pid, 0
                while q is not None and hops < 8 and tags.get(q) is None:
                    q, hops = ppid.get(q), hops + 1
                if q is not None and tags.get(q):
                    owner[pid] = tags[q]
            for pid, store in list(owner.items()):
                q, hops = ppid.get(pid), 0
                while q in ppid and hops < 3 and q not in owner:
                    owner[q] = store
                    q, hops = ppid.get(q), hops + 1
            by_store = {}
            for pid, v in use.items():
                by_store[owner.get(pid, "other")] = by_store.get(owner.get(pid, "other"), 0.0) + v
            for pid in list(known):
                if pid not in alive:
                    known.pop(pid, None)
                    tags.pop(pid, None)
            try:
                _whole_pc(psutil, me, kids, owner, others)
            except Exception:
                pass
            with _LOCK:
                _STATE["samples"].append((py + br, py, br))
                _STATE["samples"] = _STATE["samples"][-720:]
                for store, v in by_store.items():
                    _STATE["stores"].setdefault(store, []).append(v)
                    _STATE["stores"][store] = _STATE["stores"][store][-720:]
                _STATE["last_cpu"] = {"at": time.time(), "cpu": dict(by_store), "py": py}
            n += 1
            if n % 10 == 0:
                _tidy_memory()
            if n % 5 == 0:
                log_fn(f"[cpu] {summary()}")
            if n % 30 == 0:
                try:
                    _census(log_fn, me)
                except Exception:
                    pass

    threading.Thread(target=loop, daemon=True, name="cpu-monitor").start()
