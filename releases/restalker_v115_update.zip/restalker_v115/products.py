"""What a product IS (a box of packs, a single pack, or a bundle) and how an alert's wording is matched to it.

Why this exists: "The Hobbit Collector Booster" is the start of "The Hobbit Collector Booster Box", so a plain text search would credit
a BOX alert to the single PACK (and the other way round). Every watched product has a kind:
  box     - Collector Booster Box / Display (12 packs)     - matched exactly as before
  pack    - one Collector Booster pack                      - matches only when the words "box", "display", "bundle", "omega" do NOT follow
  bundle  - a bundle (Gift Bundle, Secret Lair Bundle, Beam Me Up Bundle) - matches its name or one of its other names ("aliases")

Also: new products are added to your product list from the file new_products.yaml (only ids you never had; one time only), so your own
targets.yaml is never overwritten.
"""
import os, re

VERSION = "v115"

_AFTER_PACK_NOT = r"(?!\s*(?:box|display|bundle|omega|case|value))"


def norm(text):
    """Make titles comparable across stores (same rules the tracker readers use)."""
    t = (text or "").lower()
    t = re.sub(r"[™®©|:\-–—,()]", " ", t)
    t = re.sub(r"\s+", " ", t).strip()
    return t.replace("booster display", "booster box")


_SLUG = re.compile(r"^[a-z][a-z0-9_]{1,40}$")
BUILTIN_KINDS = ("box", "pack", "bundle")


def kind_of(target):
    """box / pack / bundle, or the slug of a category you made yourself (commander_deck, play_booster_box, ...)."""
    k = (target.get("kind") or "").strip().lower()
    n = norm(target.get("match_name", ""))
    if k in ("", "box") and "collector" not in n:
        # a Play Booster Box / Commander Deck filed as a plain "box" (older versions did that) is NOT the Collector Booster Box:
        # they are different products, and sharing one row made their links and statuses overwrite each other.
        if "play booster" in n:
            return "play_booster_box"
        if "commander" in n:
            return "commander_deck"
    if k in BUILTIN_KINDS or _SLUG.match(k):
        return k
    if "bundle" in n:
        return "bundle"
    if n.endswith("collector booster") or n.endswith("collector booster pack"):
        return "pack"
    return "box"


def is_custom(kind):
    return kind not in BUILTIN_KINDS


def strip_brand(n):
    """'magic the gathering star trek commander deck' -> 'star trek commander deck' (alerts and stores leave the brand out)."""
    return re.sub(r"^(?:magic\s+the\s+gathering|magic\s+gathering|mtg)\s+", "", n or "").strip()


_PRICE_RE = re.compile(r"\$\s?(\d{1,4}(?:,\d{3})*(?:\.\d{1,2})?)")


def prices_in(text):
    out = []
    for m in _PRICE_RE.finditer(text or ""):
        try:
            out.append(float(m.group(1).replace(",", "")))
        except ValueError:
            pass
    return out


def price_ok(text, target):
    """False only when the text shows prices and every one of them is above this product's price cap (a reseller listing)."""
    mx = target.get("max_price")
    prices = prices_in(text)
    if mx is None or not prices:
        return True
    return any(p <= float(mx) for p in prices)


def is_extra(target):
    return str(target.get("tier", "")).lower() == "extra"


def names_of(target):
    """The wordings that mean this product (its own name first, then any other names it goes by in stores)."""
    out = []
    for raw in [target.get("match_name", "")] + list(target.get("aliases") or []):
        n = norm(raw)
        for v in (n, strip_brand(n)):
            if v and v not in out:
                out.append(v)
    return out


_CAT_WORDS = r"(?:collector booster box|collector booster pack|collector booster|play booster box|play booster display|play booster pack|play booster|set booster box|set booster display|set booster pack|set booster|draft booster box|draft booster display|draft booster|commander decks|commander deck|commander bundle|gift bundle|secret lair bundle|beam me up bundle|bundle|booster box|booster display|booster pack|box|display|deck)"
_AFTER_CUSTOM_NOT = r"(?!\s*(?:bundle|case|display|set of|collector))"


def category_words(target):
    """The words that say WHAT it is (not which set): 'commander deck', 'play booster box', ..."""
    n = strip_brand(norm(target.get("match_name", "")))
    th = theme_of(target)
    rest = n[len(th):].strip() if th and n.startswith(th) else ""
    return [w for w in rest.split() if w not in ("the", "of", "and")]


def title_matches(text_norm, target):
    """Does this (already normalised) text name this product? Boxes are matched exactly as they always were."""
    k = kind_of(target)
    for n in names_of(target):
        if k == "pack":
            if re.search(re.escape(n) + _AFTER_PACK_NOT, text_norm):
                return True
        elif is_custom(k):
            if re.search(re.escape(n) + _AFTER_CUSTOM_NOT, text_norm):
                return True
        elif n in text_norm:
            return True
    if is_custom(k):          # words in any order: 'Star Trek ... Commander Deck'
        th = theme_of(target).split()
        cat = category_words(target)
        if th and cat and all(re.search(r"\b" + re.escape(w) + r"\b", text_norm) for w in th + cat):
            if not re.search(r"\b(bundle|case)\b", text_norm) or any(w in ("bundle", "case") for w in cat):
                return True
    return False


def theme_of(target_or_name):
    """'the hobbit' / 'reality fracture' / 'star trek' - the set the product belongs to. For a category you made yourself
    (kind 'mystery_tin') its own words are taken off the end as well ('Bar Mystery Tin' -> 'bar')."""
    kind = ""
    if isinstance(target_or_name, dict):
        name = target_or_name.get("match_name", "")
        kind = (target_or_name.get("kind") or "").strip().lower()
    else:
        name = target_or_name
    n = strip_brand(norm(name))
    n = re.sub(r"\s*" + _CAT_WORDS + r"$", "", n)
    if kind and is_custom(kind) and _SLUG.match(kind):
        words = kind.replace("_", " ")
        for w in (words, words + "s"):
            if n.endswith(" " + w) or n == w:
                n = n[: len(n) - len(w)]
                break
    return n.strip()


# ------------------------------------------------------------------ adding the new products without touching targets.yaml

def merge_new_products(targets_cfg, new_cfg, already):
    """Adds the products of new_cfg that are not in targets_cfg and were never added before.
    Returns (list of ids added, set of ids now known). Nothing the user already has is changed."""
    have = {t["id"] for t in targets_cfg.get("targets", [])}
    added, known = [], set(already)
    for t in new_cfg.get("targets", []) or []:
        tid = t.get("id")
        if not tid or tid in known:
            continue
        known.add(tid)
        if tid in have:
            continue
        nt = dict(t)
        # v46: one price cap per product, the same at every store: a link added to a row you already have takes YOUR row's cap
        try:
            rk = f"{theme_of(nt)}|{kind_of(nt)}"
            sib = [x for x in targets_cfg.get("targets", []) if f"{theme_of(x)}|{kind_of(x)}" == rk and x.get("max_price") is not None]
            if sib:
                nt["max_price"] = min(float(x["max_price"]) for x in sib)
                nt.pop("needs_cap", None)
        except Exception:
            pass
        targets_cfg.setdefault("targets", []).append(nt)
        have.add(tid)
        added.append(tid)
    return added, known


def read_ids(path):
    try:
        with open(path, encoding="utf-8") as f:
            return {ln.strip() for ln in f if ln.strip() and not ln.startswith("#")}
    except Exception:
        return set()


def write_ids(path, ids):
    try:
        with open(path, "w", encoding="utf-8") as f:
            f.write("# products already added from new_products.yaml (so a product you delete is not added again)\n")
            for i in sorted(ids):
                f.write(i + "\n")
    except Exception:
        pass


# ---------------------------------------------------------------- v46: does a PAGE TITLE fit the kind of product a row is?
_NOT_COLLECTOR_BOX = re.compile(r"\b(commander deck|bundle|prerelease|pre release|jumpstart|starter|draft booster|play booster|set booster|"
                                r"theme booster|beyond booster|sample pack|pack lot|lot of|3 packs|6 packs|case of)\b")
_BOXWORD = re.compile(r"\b(booster box|booster display|collector box|display|box)\b")
_PACKWORD = re.compile(r"\b(booster pack|booster|pack|packs)\b")


def kind_fits(kind, title):
    """False only when the title CLEARLY names another kind of product (a Commander deck, a bundle, a single pack, a Play Booster box ...
    for a Collector Booster Box row, and so on). Used to keep a wrong link from raising alerts. Unknown / empty title = True."""
    t = norm(title)
    if not t:
        return True
    k = (kind or "box").strip().lower()
    if k == "box":
        if re.search(r"collector booster (box|display)", t):
            return True
        if _NOT_COLLECTOR_BOX.search(t):
            return False
        if not _BOXWORD.search(t) and _PACKWORD.search(t):
            return False
        return True
    if k == "pack":
        return not re.search(r"\b(booster box|display|box|case|bundle|deck|lot of|packs lot)\b", t)
    if k == "bundle":
        return "bundle" in t
    if k == "play_booster_box":
        if "play booster" in t:
            return not re.search(r"\b(bundle|commander deck|sample)\b", t) or bool(re.search(r"play booster (box|display)", t))
        return not re.search(r"collector|set booster|draft|bundle|commander deck|prerelease", t)
    if k == "set_booster_box":
        if "set booster" in t:
            return True
        return not re.search(r"collector|play booster|draft|bundle|commander deck|prerelease", t)
    if k == "commander_deck":
        return "commander" in t or "deck" in t
    return True


_SURE_BOX = re.compile(r"\b(box|boxes|display|case)\b|\b(12|24|30|36)\s*(ct\s*)?(collector\s*|play\s*|set\s*|draft\s*)?(booster\s*)?(packs|boosters)\b")


def kind_sure(kind, title):
    """v62: STRICT - does the product name SHOW that it is this row's kind of product? Used before anything is BOUGHT (kind_fits only
    asks 'is it clearly something else?'). Diagnostics 60: a single Collector Booster ('Collector Booster | 15 Magic Cards') was bought
    for a Collector Booster BOX row - a box must say box / display / case / '12 packs'; a pack must not say so; a bundle must say bundle.
    An empty name is NOT sure."""
    t = norm(title)
    if not t or not kind_fits(kind, title):
        return False
    k = (kind or "box").strip().lower()
    if k in ("box", "play_booster_box", "set_booster_box"):
        return bool(_SURE_BOX.search(t))
    if k == "pack":
        return not _SURE_BOX.search(t)
    if k == "bundle":
        return "bundle" in t
    return True


THEME_ALIASES = (("star trek", "beam me up"), ("star trek", "strange new worlds"))


def theme_words(theme):
    """v62: the word lists a page name must contain for this set (any one list is enough: the set's own words, or a shelf name of it)."""
    if not theme:
        return []
    out = [[re.sub(r"[^a-z0-9]", "", w) for w in re.split(r"\s+", norm(theme)) if len(w) > 2 and w not in ("the", "and")]]
    for _theme, _alias in THEME_ALIASES:
        if norm(theme) == _theme:
            out.append([re.sub(r"[^a-z0-9]", "", w) for w in _alias.split() if len(w) > 1])
    return [ws for ws in out if ws]


def theme_in_title(theme, title):
    """Every significant word of the set name appears in the title ('phyrexia all will be one' in the title). Empty title = True."""
    t = norm(title)
    if not t or not theme:
        return True
    for _theme, _alias in THEME_ALIASES:                    # (v47) a set sold under another name on the shelf
        if norm(theme) == _theme and _alias in t:
            return True
    words = [w for w in re.split(r"\s+", norm(theme)) if len(w) > 2 and w not in ("the", "and")]
    t = t.replace("'", "").replace("’", "")
    return all(re.sub(r"[^a-z0-9]", "", w) in re.sub(r"[^a-z0-9 ]", "", t) for w in words)
