"""v101: a product's square on the Products tab stays steady (owner 2026-11-05: "I noticed products flashing in stock and out of stock I
think based on cycling through multiple browsers. we need to be sure and static, so one of those browsers may not be reporting correctly").

Several browsers read the same product, one after the other. They do not always see the same page (one is shown the other sellers'
offer over your cap, the next one "currently unavailable"), so the square jumped between "for sale - over cap" and "out" with every
reading. Now (v103, owner 2026-11-06: "the default should be to show in stock at high prices and simply assume the other browsers are not
loading correctly. provided that the reporting browsers consistently shows it in stock"):
- each browser has its own steady answer: its last 2 readings agree (a fresh answer - not older than 3 of its own usual gaps, at least
  3 minutes);
- the square shows the MOST available of those answers: can be bought, then for sale over the cap, then sold out. So one browser that
  keeps seeing it for sale keeps the square "for sale", however many others say "sold out" (they did not load it right);
- "sold out" shows only when no browser has a steady "for sale" answer any more;
- a reading that can be BOUGHT shows at once (one reading is enough - and buying never waits for the square: it never did);
- every reading keeps which browser it came from, so the diagnostics name a browser that disagrees with the others.
Display only: nothing here decides a restock or a purchase."""
import collections
import threading
import time

VERSION = "v115"
WINDOW = 12
KEEP_FOR = 7200.0          # s
_L = threading.Lock()
_S = {}


def cls_of(status, high):
    if status == "IN_STOCK":
        return "in"
    if status == "OUT_OF_STOCK":
        return "over" if high else "out"
    return None


def _st(tid):
    s = _S.get(tid)
    if s is None:
        s = _S[tid] = {"recent": collections.deque(maxlen=WINDOW), "shown": None, "price": None, "since": 0.0,
                       "min": {},                                     # minute -> {browser: Counter(class)} (the last 2 hours)
                       "flips": collections.deque(maxlen=400),        # (t, from, to, browser now, browser before)
                       "shown_flips": collections.deque(maxlen=200),  # (t, from, to)
                       "last_raw": None, "last_src": None, "by": {},
                       "timed": collections.deque(maxlen=60)}         # v112: (t, browser, class, price) - for the own-detection capture
    return s


RANK = {"in": 3, "over": 2, "out": 1}
FRESH_MIN = 180.0


def _steady_of(b, now):
    """One browser's own steady answer while it keeps reading (fresh), or None. It changes only when 2 of its readings in a row agree
    (a buyable reading at once)."""
    r = b["r"]
    if not r or b.get("steady") is None:
        return None
    t = r[-1][0]
    gap = (t - r[-2][0]) if len(r) >= 2 else 0.0
    return b["steady"] if now - t <= max(FRESH_MIN, 3 * gap) else None


def decide(s, now, c=None):
    """The square: the most available steady answer of any browser; none steady -> what it showed (the very first reading: itself)."""
    best = None
    for b in s["by"].values():
        k = _steady_of(b, now)
        if k and (best is None or RANK[k] > RANK[best]):
            best = k
    return best or s["shown"] or c


# ---- v105: what our readers saw right after a tracker alert (KNOWN_ISSUES: trackers report Amazon at MSRP while our readers see
# only resellers). Every reading of the product in the CAP_FOR seconds after a tracker alert is kept with the tracker's words; app.py
# also keeps the page itself (alert_pages/). Read only - nothing here buys or decides anything.
CAP_FOR = 120.0
CAP_READS = 20
CAPTURES = collections.deque(maxlen=60)
_OPEN = {}


def _capture(tid, c, price, src, now):
    try:
        import hotness
        at, said = hotness.why_of(tid, since=now - CAP_FOR)
    except Exception:
        return None
    if not said:
        # v112: no tracker alert - a capture opened by our OWN buyable reading keeps recording every browser for CAP_FOR seconds
        cap = _OPEN.get(tid)
        if cap and cap.get("own") and now - cap["at"] <= CAP_FOR and len(cap["reads"]) < CAP_READS + OWN_BEFORE_N:
            cap["reads"].append((now, src, c, price))
            return cap
        return None
    cap = _OPEN.get(tid)
    if cap is None or cap["at"] != at:
        cap = _OPEN[tid] = {"tid": tid, "at": at, "said": said, "reads": [], "pages": []}
        CAPTURES.append(cap)
    if len(cap["reads"]) < CAP_READS and now - at <= CAP_FOR:
        cap["reads"].append((now, src, c, price))
        return cap
    return None


# ---- v112: what EVERY browser saw around a moment one of OUR readers saw the product buyable (owner 2026-11-10: "a deep dive into how
# other programs know things well before we do"; research: polling accounts may be shown less - "missing or blank offer lists even when
# listings exist" (FairGame) - and Amazon shows stock by delivery area, Prime and invitations). At a real restock this shows whether some
# browsers (signed in or not, polling hard or not) saw it later or never. Kept apart from the tracker alerts (they come far more often).
OWN_BEFORE = 20.0
OWN_BEFORE_N = 12
OWN_CAPTURES = collections.deque(maxlen=30)


def _own_capture(tid, s, now, src):
    cap = _OPEN.get(tid)
    if cap and now - cap["at"] <= CAP_FOR:
        return None                       # (a capture is already recording this product - a tracker's or our own)
    before = [(t, b, c, p) for t, b, c, p in s["timed"] if now - OWN_BEFORE <= t <= now][-(OWN_BEFORE_N + 1):]
    cap = _OPEN[tid] = {"tid": tid, "at": now, "said": f"OUR OWN reader saw it buyable ({src})", "own": True, "reads": before, "pages": []}
    OWN_CAPTURES.append(cap)
    return cap


def note(tid, status, high=False, price=None, src="", now=None):
    """One real reading of product tid -> what its square shows: {"status", "high", "price", "since"} (or None for a non-reading)."""
    c = cls_of(status, high)
    if c is None:
        return shown(tid)
    now = now or time.time()
    src = src or "?"
    with _L:
        s = _st(tid)
        _capture(tid, c, price, src, now)
        s["recent"].append((c, price, src))
        s["timed"].append((now, src, c, price))
        if c == "in":
            _own_capture(tid, s, now, src)
        m = int(now // 60)
        s["min"].setdefault(m, collections.defaultdict(collections.Counter))[src][c] += 1
        if len(s["min"]) > 125:
            for k in [k for k in s["min"] if k < m - 120]:
                s["min"].pop(k, None)
        if s["last_raw"] is not None and s["last_raw"] != c:
            s["flips"].append((now, s["last_raw"], c, src, s["last_src"]))
        s["last_raw"], s["last_src"] = c, src
        b = s["by"].setdefault(src, {"r": collections.deque(maxlen=3), "price": None, "steady": None})
        b["r"].append((now, c))
        if c == "in" or (len(b["r"]) >= 2 and b["r"][-2][1] == c):
            if b.get("steady") != c or price is not None:
                b["price"] = price
            b["steady"] = c
        cur = s["shown"]
        new = decide(s, now, c)
        if new != cur:
            if cur is not None:
                s["shown_flips"].append((now, cur, new))
            s["shown"], s["since"] = new, now
        # the price: the one a browser that sees it so has (newest reading first)
        s["price"] = price if (new == c and price is not None) else next(
            (bb["price"] for bb in s["by"].values() if _steady_of(bb, now) == new and bb["price"] is not None),
            s["price"] if new == cur else None)
        return _out(s)


def _out(s):
    if s["shown"] is None:
        return None
    return {"status": "IN_STOCK" if s["shown"] == "in" else "OUT_OF_STOCK", "high": s["shown"] == "over", "price": s["price"], "since": s["since"]}


def shown(tid):
    with _L:
        s = _S.get(tid)
        return _out(s) if s else None


WORDS = {"in": "can be bought", "over": "for sale over the cap", "out": "sold out"}


def _hm(t):
    return time.strftime("%H:%M:%S", time.localtime(t))


def capture_wants_page(tid, now=None):
    """-> the open capture of tid when its page should be kept now (the first 6 readings after the alert), else None."""
    now = now or time.time()
    with _L:
        cap = _OPEN.get(tid)
        if cap and now - cap["at"] <= CAP_FOR and len(cap["pages"]) < 6:
            return cap
    return None


def own_capture_text(limit=10):
    """v112 diagnostics: every moment one of OUR readers saw a product buyable - what each browser saw from 20 s before to 2 min after."""
    with _L:
        caps = [dict(c, reads=list(c["reads"]), pages=list(c["pages"])) for c in OWN_CAPTURES]
    if not caps:
        return "  none since the start (no reader of ours has seen a product buyable yet)"
    out = [f"  {len(caps)} moments kept (newest first). 'before' = readings in the 20 s before it, 'after' = the 2 minutes after:"]
    for c in caps[-limit:][::-1]:
        out.append(f"  {_hm(c['at'])} {c['tid']} - {c['said']}")
        by = collections.defaultdict(list)
        for t, src, k, p in c["reads"]:
            by[src].append((t - c["at"], k, p))
        for src, rs in sorted(by.items()):
            out.append(f"      {src}: " + ", ".join(f"{d:+.1f}s {WORDS[k]}" + (f" ${p:.2f}" if p else "") for d, k, p in rs[:10]))
        if c["pages"]:
            out.append("      pages kept: " + ", ".join(c["pages"]))
    return "\n".join(out)


def capture_text(now=None, limit=12):
    """Diagnostics: the tracker alerts and what every reader of ours saw in the 2 minutes after each."""
    now = now or time.time()
    with _L:
        caps = [dict(c, reads=list(c["reads"]), pages=list(c["pages"])) for c in CAPTURES]
    if not caps:
        return "  no tracker alert since the start (nothing to compare yet)"
    out = []
    n_buy = sum(1 for c in caps if any(r[2] == "in" for r in c["reads"]))
    out.append(f"  {len(caps)} tracker alerts kept; in {n_buy} of them a reader of ours saw it buyable within {CAP_FOR:.0f} s.")
    for c in caps[-limit:][::-1]:
        cn = collections.Counter(r[2] for r in c["reads"])
        prices = sorted({r[3] for r in c["reads"] if r[3]})
        first = min((r[0] for r in c["reads"]), default=None)
        out.append(f"  {_hm(c['at'])} {c['tid']} - the tracker said: {c['said'][:150]}")
        out.append(f"      our {len(c['reads'])} readings in the next {CAP_FOR:.0f} s" + (f" (the first {first - c['at']:.1f} s after)" if first else "") + ": "
                   + (", ".join(f"{WORDS[k]} {v}" for k, v in cn.most_common()) or "none")
                   + (f"; prices seen: {', '.join(f'${p:.2f}' for p in prices[:6])}" if prices else ""))
        by = collections.defaultdict(collections.Counter)
        for r in c["reads"]:
            by[r[1]][r[2]] += 1
        out.append("      by browser: " + " | ".join(f"{src}: " + ", ".join(f"{WORDS[k]} {v}" for k, v in cc.most_common()) for src, cc in list(by.items())[:8]))
        if c["pages"]:
            out.append("      pages kept: " + ", ".join(c["pages"]))
    return "\n".join(out)


def report_text(names=None, now=None, limit=12):
    """Diagnostics: products whose readings disagree - who said what, when the readings changed and when the square did (last 2 hours)."""
    now = now or time.time()
    rows = []
    with _L:
        items = [(tid, {k: (dict((a, collections.Counter(b)) for a, b in v.items()) if k == "min" else (list(v) if isinstance(v, collections.deque) else v))
                        for k, v in s.items()}) for tid, s in _S.items()]
    lo = int(now // 60) - 120
    for tid, s in items:
        by = collections.defaultdict(collections.Counter)
        for m, d in s["min"].items():
            if m >= lo:
                for src, cn in d.items():
                    by[src].update(cn)
        n = sum(sum(c.values()) for c in by.values())
        flips = [f for f in s["flips"] if now - f[0] <= KEEP_FOR]
        shf = [f for f in s["shown_flips"] if now - f[0] <= KEEP_FOR]
        if n < 4 or not flips:
            continue
        rows.append((len(flips), tid, n, by, flips, shf))
    rows.sort(key=lambda r: -r[0])
    out = []
    for _, tid, n, by, flips, shf in rows[:limit]:
        nm = (names or {}).get(tid, tid)
        tot = collections.Counter()
        for c in by.values():
            tot.update(c)
        out.append(f"  {nm}: {n} readings, they changed {len(flips)}x - the square changed {len(shf)}x. All readings: "
                   + ", ".join(f"{WORDS[k]} {v}" for k, v in tot.most_common()))
        for src, cn in sorted(by.items(), key=lambda kv: -sum(kv[1].values()))[:10]:
            out.append(f"      {src}: " + ", ".join(f"{WORDS[k]} {v}" for k, v in cn.most_common()))
        main = tot.most_common(1)[0][0]
        odd = collections.Counter(f[3] for f in flips if f[2] != main)     # who brought the odd reading
        if odd:
            out.append("      the odd readings came from: " + ", ".join(f"{src} {v}x" for src, v in odd.most_common(6)))
        pairs = collections.Counter(f"{WORDS[f[1]]} -> {WORDS[f[2]]}" for f in flips)
        out.append("      changes: " + ", ".join(f"{k} {v}x" for k, v in pairs.most_common(4)))
        out.append("      last readings that changed: " + " | ".join(f"{_hm(f[0])} {WORDS[f[2]]} ({f[3]}; before: {f[4]})" for f in flips[-5:]))
        if shf:
            out.append("      the square changed at: " + ", ".join(f"{_hm(f[0])} to {WORDS[f[2]]}" for f in shf[-8:]))
    return "\n".join(out) if out else "  every product's readings agree (no change between readings in the last 2 hours)"
