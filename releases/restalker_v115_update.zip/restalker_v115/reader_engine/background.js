/* Restalker v65 - the store reader's own browser (read only, never buys).
 * Diagnostics 61: reading the stores through the BUYING browser (Best Buy every 3 s, Walmart pages, Target data) got that browser
 * refused at the very moment it had to buy (Walmart "Robot or human?", Best Buy product pages not loading). The reading now happens in
 * this separate browser with its own profile; the buying browser only buys. Nothing here clicks, types, signs in or answers a check.
 */
'use strict';
importScripts('rk_reader.js');
(() => {
  const CODE = 'v115';
  let ws = null, connecting = false, lastErr = null;
  async function link() {
    try { const r = await fetch(chrome.runtime.getURL('reader_link.json'), {cache: 'no-store'}); return await r.json(); } catch { return {}; }
  }
  function send(m) { try { if (ws && ws.readyState === 1) { ws.send(JSON.stringify(m)); return true; } } catch (e) { lastErr = String(e && e.message || e); } return false; }
  async function onMessage(ev) {
    let m; try { m = JSON.parse(String(ev.data || '')); } catch { return; }
    if (m.type === 'heartbeat') { send({type: 'heartbeat_ack'}); return; }
    if (m.type !== 'command') return;
    const c = m.command && typeof m.command === 'object' ? m.command : {};
    let result;
    try {
      if (c.type === 'PAGE_FETCH') result = await globalThis.RestalkerReader.fetch(String(c.url || ''), c.timeoutMs, Array.isArray(c.cookies) ? c.cookies.slice(0, 8).map(String) : null);
      else if (c.type === 'READER_STATUS') result = {ok: true, ...globalThis.RestalkerReader.status()};
      else result = {ok: false, reason: 'the reader only reads (command not allowed: ' + String(c.type || '') + ')'};
    } catch (e) { result = {ok: false, reason: String(e && e.message || e)}; }
    send({type: 'command_result', cmdId: String(m.cmdId || '').slice(0, 80), result});
  }
  async function connect() {
    if (connecting || (ws && ws.readyState <= 1)) return;
    connecting = true;
    try {
      const l = await link();
      const port = Number(l.port) || 17861;
      const s = new WebSocket('ws://127.0.0.1:' + port + '/reader');
      ws = s;
      s.onopen = () => { connecting = false; send({type: 'hello', engine: 'restalker-reader', token: String(l.token || ''), code: CODE, name: chrome.runtime.getManifest().name}); };
      s.onmessage = ev => { void onMessage(ev); };
      s.onclose = () => { connecting = false; if (ws === s) ws = null; };
      s.onerror = () => { lastErr = 'link error'; };
      setTimeout(() => { connecting = false; }, 8000);
    } catch (e) { connecting = false; lastErr = String(e && e.message || e); }
  }
  try { chrome.alarms.create('rk-reader-link', {periodInMinutes: 0.5}); chrome.alarms.onAlarm.addListener(() => { void connect(); }); } catch {}
  try { chrome.runtime.onStartup.addListener(() => { void connect(); }); chrome.runtime.onInstalled.addListener(() => { void connect(); }); } catch {}
  setInterval(() => { void connect(); }, 3000);
  void connect();
})();
