"""v141: the Restalker relay (a small Cloudflare server - relay/ in the release repository) from the PC.

- The race to checkout (owner, 2026-11-19: "Its a race to checkout, so whichever happens first is the winner and should lock the product
  normally"): right before Place order on Amazon, the PC claims the product for the owner's linked devices. The first device to claim it
  orders; the others stop. The group code is made from the link secret (no one else can guess it); the phone app makes the same one.
  When the relay cannot be asked, the rules before v141 decide (the PC goes first; never two orders).
- "Active now": a heartbeat every 15 minutes (the live count of working devices).
- Problem reports of a PC that is not the owner's go here (compiled once a day on Discord) - the owner's PC sends its own directly.
- v145: presence of one person's linked devices (who is running now), with the heartbeat.
- The Discord invite.
- v147 (owner 2026-11-20: "The ntfy messages arent really needed anymore since the app can handle notifications ... the PC version
  should still be sending alerts to a users phone if they dont have a linked app"): what this PC and its linked phones / tablets tell
  each other (phonelink.py - sealed there, the relay cannot read it) and the crowd's sightings (crowd.py) go through the relay, not
  through the free message service - that service allows a home 250 messages a day for all its devices together, and the linked
  devices' updates alone used them up. ONE request a minute (sync) says "I am here", brings the active count, the linked devices'
  signs of life, and everything new on the channels this PC reads; the answer says when to ask again. ntfy stays for alerts to a
  phone without the Restalker app, for linked devices that still run an older version, and as the doorbell for "buy now".
Nothing here can buy anything; nothing personal is sent (product codes, a random device code, the report text).
"""
import json
import os
import threading
import time
import urllib.error
import urllib.request

VERSION = "v147"
BASE = "https://restalker-relay.restalker.workers.dev"
LOG = None
_st = {"active": -1, "active_at": 0.0, "error": "", "claims": 0, "won": 0, "lost": 0, "unreachable": 0, "beat_at": 0.0, "invite": None,
       "invite_at": 0.0}
_held = {}              # asin -> when this PC claimed it
_lock = threading.Lock()


def _call(method, path, body=None, timeout=6.0, http=None, raw=None):
    """raw: a text sent as it is (a sealed post) instead of a JSON body."""
    if http is not None:
        return http(method, path, raw if raw is not None else body)
    if os.environ.get("RK_TEST_NOEXIT"):                 # (test runs never talk to the real relay)
        return None
    data = raw.encode() if raw is not None else json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(BASE + path, data=data, method=method,
                                 headers={"Content-Type": "text/plain" if raw is not None else "application/json", "User-Agent": "Restalker/" + VERSION})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            _st["error"] = ""
            return json.loads(r.read().decode() or "{}")
    except urllib.error.HTTPError as e:
        _st["error"] = f"HTTP {e.code}"
        try:
            return json.loads(e.read().decode() or "{}")
        except Exception:
            return None
    except Exception as e:
        _st["error"] = str(e)[:80]
        return None


def device():
    try:
        import crowd
        return crowd.my_id()
    except Exception:
        return ""


def group():
    """This link's group code (None when no phone / tablet is linked)."""
    try:
        import phonelink
        p = phonelink.parse_code(phonelink.load().get("code"))
        return phonelink.lock_group(p[1]) if p else None
    except Exception:
        return None


def claim(asin, http=None):
    """Right before Place order on Amazon: True = this PC orders, False = another of your devices has it, None = not asked."""
    g = group()
    if not g or not asin:
        return None
    _st["claims"] += 1
    r = _call("POST", "/v1/lock", {"c": device(), "g": g, "a": str(asin)}, timeout=4.0, http=http)
    if not r or r.get("ok") is not True:
        _st["unreachable"] += 1
        return None
    if r.get("granted"):
        _st["won"] += 1
        with _lock:
            _held[str(asin)] = time.time()
        return True
    _st["lost"] += 1
    if LOG:
        LOG(f"[relay] {asin}: another of your linked devices is placing this order (the shared lock) - not ordered here")
    return False


def release(asin, result, http=None, background=True):
    """How this PC's claimed checkout ended: "bought" (or maybe bought) keeps the others out for a day; anything else frees it."""
    with _lock:
        if _held.pop(str(asin), None) is None:
            return False
    g = group()
    if not g:
        return False

    def go():
        _call("POST", "/v1/release", {"c": device(), "g": g, "a": str(asin), "result": "bought" if result == "bought" else "failed"}, http=http)
    if background:
        threading.Thread(target=go, daemon=True, name="relay-release").start()
    else:
        go()
    return True


def holds(asin):
    with _lock:
        return str(asin) in _held


def _took(r, now):
    """What every answer of the relay to "I am here" carries: the active count and this PC's linked devices' signs of life."""
    _st["active"], _st["active_at"] = int(r.get("active") or 0), now
    if isinstance(r.get("peers"), list):
        try:
            import phonelink
            beats = [(p.get("w"), float(p.get("at") or 0) / 1000.0) for p in r["peers"] if isinstance(p, dict) and isinstance(p.get("w"), str)]
            _st["peers"] = phonelink.take_presence(beats)
            _st["peers_at"] = now
        except Exception:
            pass


def post_ch(ch, text, http=None, timeout=12.0):
    """v147: a sealed post on a linked group's channel (ch) -> True when the relay took it."""
    r = _call("POST", "/v1/ch/" + str(ch), timeout=timeout, http=http, raw=str(text))
    ok = bool(r and r.get("ok") is True)
    _st["posts" if ok else "post_fails"] = _st.get("posts" if ok else "post_fails", 0) + 1
    return ok


def share(sightings, http=None):
    """v147: this PC's own sighting(s) for the crowd, straight to the relay -> True when taken."""
    r = _call("POST", "/v1/s", list(sightings)[:20], timeout=8.0, http=http)
    return bool(r and r.get("ok") is True)


def sync(reads=None, http=None, now=None):
    """v147: this PC's whole round with the relay in ONE request - "I am here" (the active count, the linked devices' signs of life)
    and what is new on the channels in [reads] ({channel: the last id read, "" = from the start}). The crowd's line is added when
    sharing is on, and what it brings is handed to crowd.py. -> {channel: [lines as ntfy hands them out]} or None (not reached)."""
    now = time.time() if now is None else now
    reads = dict(reads or {})
    body = {"c": device()}
    g = group()
    if g:
        try:
            import phonelink
            w = phonelink.who()
            if w:
                body["g"], body["w"] = g, w
        except Exception:
            pass
    crowd_on = False
    try:
        import crowd
        crowd_on = crowd.on()
        if crowd_on:
            reads["crowd"] = crowd.relay_since()
    except Exception:
        pass
    if not reads and not g and not crowd_on:
        return None
    body["r"] = reads
    _st["sync_try"] = now
    r = _call("POST", "/v1/sync", body, timeout=12.0, http=http)
    if not r or r.get("ok") is not True:
        _st["sync_fails"] = _st.get("sync_fails", 0) + 1
        if r and r.get("next"):
            _st["next"] = max(20, min(900, int(r["next"])))
        return None
    _st["sync_at"], _st["beat_at"], _st["syncs"] = now, now, _st.get("syncs", 0) + 1
    try:
        _st["next"] = max(20, min(900, int(r.get("next") or 60)))
    except Exception:
        _st["next"] = 60
    _took(r, now)
    m = r.get("m") if isinstance(r.get("m"), dict) else {}
    out = {k: [x for x in v if isinstance(x, dict)] for k, v in m.items() if isinstance(v, list)}
    if crowd_on and out.get("crowd"):
        try:                                             # (on its own thread: the look it starts must never hold up a link round -
            import crowd                                 # waited for only a moment)
            t = threading.Thread(target=crowd.relay_take, args=(out["crowd"],), daemon=True, name="crowd-relay-take")
            t.start()
            t.join(3)
        except Exception:
            pass
    return out


def sync_age(now=None):
    """Seconds since the last round that reached the relay (a big number when none yet)."""
    return (time.time() if now is None else now) - float(_st.get("sync_at") or 0)


def next_wait():
    """Seconds the relay asked to wait until the next round (60 when it has not said)."""
    return int(_st.get("next") or 60)


def pump(http=None, now=None):
    """crowd.py's loop, every 30 s: a PC WITHOUT linked devices still reads the crowd's line (and says "I am here") - every 3 minutes,
    or as the relay says. A linked PC does it with its link round every minute (phonelink.cycle), so nothing is asked twice."""
    now = time.time() if now is None else now
    try:
        import phonelink
        if phonelink.linked():
            return None
    except Exception:
        pass
    if now - float(_st.get("sync_try") or 0) < max(180, next_wait()):
        return None
    return sync({}, http=http, now=now)


def heartbeat(force=False, http=None):
    """Every 15 minutes while sharing with the crowd is on: this device is working.
    v145 (owner 2026-11-20: "Both of these devices are currently active ... Confirm the devices can see and report active links"): a PC
    with linked phones / tablets also gives its link group and a few sealed words about itself, and gets the other devices' beats back
    (phonelink.py, presence) - so "heard" no longer depends on the free message service alone. Linked: sent also while crowd sharing is
    off (nothing about restocks is in it). force = now, at most once a minute (the page was opened)."""
    g = group()
    try:
        import crowd
        if not crowd.on() and not g:
            return None
    except Exception:
        pass
    now = time.time()
    if now - _st["beat_at"] < (60 if force else 15 * 60):       # (v147: a round with the relay - sync - counts as the beat)
        return None
    _st["beat_at"] = now
    body = {"c": device()}
    if g:
        try:
            import phonelink
            w = phonelink.who()
            if w:
                body["g"], body["w"] = g, w
        except Exception:
            pass
    r = _call("POST", "/v1/h", body, http=http)
    if r and r.get("ok"):
        _took(r, now)
    return r


def report(title, note, text, http=None):
    """A report of a PC that is not the owner's -> the relay (compiled once a day for the Restalker team). -> True when taken."""
    r = _call("POST", "/v1/report", {"c": device(), "app": "pc", "ver": VERSION, "title": str(title)[:200], "note": str(note or "")[:1000],
                                     "text": str(text)[:250_000]}, timeout=30.0, http=http)
    return bool(r and r.get("ok"))


def invite(http=None):
    """The Restalker Discord invite (kept for a day)."""
    now = time.time()
    if _st["invite"] and now - _st["invite_at"] < 24 * 3600:
        return _st["invite"]
    r = _call("GET", "/v1/links", http=http)
    u = (r or {}).get("discord")
    if isinstance(u, str) and u.startswith("https://discord.gg/"):
        _st["invite"], _st["invite_at"] = u, now
    return _st["invite"]


def active():
    """Devices heard in the last 30 minutes (-1 = not known yet; kept for an hour)."""
    return _st["active"] if _st["active"] >= 0 and time.time() - _st["active_at"] < 3600 else -1


def invite_cached():
    """The invite without waiting (fetched in the background the first time)."""
    if not _st["invite"] and time.time() - _st.get("invite_try", 0) > 600:
        _st["invite_try"] = time.time()
        threading.Thread(target=invite, daemon=True, name="relay-invite").start()
    return _st["invite"]


def status_text():
    act = _st["active"]
    return (f"relay (v141): active now {act if act >= 0 else '?'}; race to checkout: claims {_st['claims']}, won {_st['won']}, "
            f"lost {_st['lost']}, relay not reached {_st['unreachable']}; linked group: {'yes' if group() else 'no'}"
            + (f"; linked devices heard there: {_st.get('peers', 0)} ({int((time.time() - _st['peers_at']) / 60)} min ago)" if _st.get("peers_at") else "")
            + (f"; rounds (v147, one request each): {_st.get('syncs', 0)} ok, {_st.get('sync_fails', 0)} failed, last "
               f"{int(sync_age() / 60) if _st.get('sync_at') else '?'} min ago, asks again every {next_wait()} s; sealed posts: {_st.get('posts', 0)} taken, "
               f"{_st.get('post_fails', 0)} not")
            + (f"; last error {_st['error']}" if _st["error"] else ""))
