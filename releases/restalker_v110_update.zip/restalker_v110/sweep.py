"""v64: one light, paced "sweeper" per store - every product read every few seconds, without loading pages that get blocked.

Why (diagnostics 60): a product was looked at only every 2-12 minutes. Whole pages were drawn by several browsers per store; that
was slow, cost the PC a lot, and those were the reads the stores refused. The stores' OWN small data requests, asked from
Restalker's signed-in buying browser, were answered in about a second with few or no refusals (Best Buy 152 of 152).

v65 (diagnostics 61): the sweepers read through the store reader's OWN browser (reader_browser.py), not the buying browser - the stores
had started refusing the buying browser at checkout after it read for them all day. The buying browser only buys.

What a sweeper does, per store, in the reader browser's quiet tab of that store (the same requests the store's own pages make):
  - Best Buy:  ONE request for all products (price + buy button of every product number)                 -> every few seconds
               a product whose button says "Add to cart" is checked on its product page (can it be shipped?) before it counts
  - Target:    ONE request for up to 24 products (Target's product summary with its online stock)        -> every few seconds
               products that answer leaves out: their own small stock request, now and then (a removed one: every 5 min)
  - GameStop:  ONE request per 20 products (the product-tile data GameStop's own pages ask for)           -> every few seconds
               a product turning "available" there is confirmed on its own product page before it counts; one product page is
               also compared with the tile data every 20 s, so a product whose tile data is wrong is read by its page
  - Walmart, Amazon: one product page at a time, the most overdue first (products set to Shopping, and products a tracker just
               alerted for, are kept freshest), and the store's own SEARCH page as an early signal (one search shows several of
               our products; one it shows buyable at a normal price has its own page read at once - the page decides).
Every answer goes into one shared table (FRESH); the store's main checker hands it on at once (alerts, buying, the table). While a
store's sweeper works, the products it answers for are NOT also loaded by the other browsers - the store sees one calm visitor.
(Walmart / Amazon: the other browsers may add a few calm reads - only after 10 good minutes and while the store has refused nothing
for an hour; the first refusal stops them for an hour.)

Pacing - fast AND not refused: each store has its own pace (seconds between two requests). After 20 good rounds it is quickened by
5 %; a slow or failed answer slows it for a moment; any sign of a refusal (403 / 429 / 435 / 503, a "prove you are human" page, a
'blocked' address) -> the sweeper rests 45 s (90 s when the first request after the rest is refused too) and goes on no faster than
1.5 x the refused pace for 30 minutes: the next refusal is avoided instead of found again. What was learned is kept in sweep_pace.json.
While a sweeper rests, the store's main checker reads gently with its own browser (and stops if that is refused too). Human checks
are never answered or gone around.
"""
import collections
import html as _html
import json
import os
import re
import threading
import time

VERSION = "v110"

MODES = {"bestbuy": "batch", "target": "batch", "gamestop": "batch", "walmart": "each", "amazon": "each"}
NAMES = {"bestbuy": "Best Buy", "target": "Target", "gamestop": "GameStop", "walmart": "Walmart", "amazon": "Amazon"}
#           first pace, fastest, slowest (seconds between two requests to the store). The first pace is what the stores answered calmly in
#           diagnostics 60 (or a little faster); a pace learned since (sweep_pace.json) is used instead.
PRIORS = {"bestbuy": (6.0, 3.0, 120.0), "target": (6.0, 3.0, 120.0), "gamestop": (5.0, 3.0, 120.0),
          "walmart": (5.0, 2.5, 120.0), "amazon": (8.0, 4.0, 180.0)}
PRIORS2 = (10.0, 6.0, 300.0)   # single product pages / product requests next to a store's all-products request
RAMP_AFTER = 20            # good rounds in a row before the pace is quickened ...
RAMP = 0.95                # ... by this factor
RAMP_QUIET = 600.0         # ... and never within this long after a refusal
SAFE_MARGIN = 1.5          # after a refusal at pace P, the pace stays at P * SAFE_MARGIN or slower ...
SAFE_FORGET = 1800.0       # ... until this long without a refusal (then that limit is relaxed by 10 %, again after each such stretch)
SAFE_KEEP = 21600.0        # a learned limit kept in sweep_pace.json is relaxed by 10 % per this long since it was learned
REST_FIRST = 45.0          # a refusal: the sweeper rests this long ...
REST_MAX = 90.0            # ... and when the first request after the rest is refused too (the store's penalty is still on), longer - at most this
#                            (requirement 24: a store is asked again within a minute and a half; one request per 90 s costs the store nothing)
SOFT_UP = 1.3              # a slow / failed answer (not a refusal): the pace is slowed for a moment ...
SOFT_MAX = 4.0             # ... at most this many times ...
SOFT_DOWN = 0.85           # ... and recovers with every good answer
REST_READ_GAP = 30.0       # while a sweeper rests: the main checker reads Shopping / tracker-alerted products at most this often each ...
REST_READ_ALL = 90.0       # ... the others at most this often each ...
REST_READ_STORE = 15.0     # ... and one read at a time, at most one every this many seconds for the whole store - and none at all once its own
#                            browser is refused too (then the refusal is about this PC, not about one browser: nothing is gained by asking),
#                            until the store answers the sweeper again (a store that counts all of this PC's visits would stay blocked)
PACE_FILE = "sweep_pace.json"
EACH_LANE_GAP = 10.0       # Walmart / Amazon: the store's extra readers (other browsers, other visitors) may add reads of products the sweeper
#                            could not keep fresh - all of them together at most one read every this many seconds ...
LANE_WARMUP = 600.0        # ... only after the sweeper has worked this long without a refusal (at the start everything is "not fresh" yet) ...
LANES_BAD_FOR = 86400.0    # ... and never again for a day at a store that refused while they helped (it counts this PC's visits together)
LANE_GATE_FOR = 3600.0     # ... and none for this long after ANY refusal at that store (sweeper or extra reader): a refusal means the store
#                            counts this PC's visits together, and more visitors would only be more refused pages
STARTUP_GRACE = 90.0       # seconds the store's extra readers wait for the sweeper at the start
HEALTHY_FOR = 45.0         # a sweeper with no good answer for this long (and at least 6 paces) is not counted on
WANT_POKED = 3.0           # each-at-a-time stores: how old a product's answer may get - a tracker alerted for it in the last minute
WANT_HOT = 10.0            # ... a tracker alerted in the last 15 minutes
WANT_SHOPPING = 10.0       # ... set to Shopping
WANT_ENGINE = 30.0         # ... set to Shopping at Amazon, while the buying browser checks it itself (it buys from its own checks)
WANT_SEARCHING = 30.0      # ... only searched (alerts)
STALE_X = 2.0              # an answer older than STALE_X * that is "stale": the store's other browsers may read the product too
OWN_FOR = 300.0            # a batch store's sweeper is counted on for a product it answered for within this long
UNREAD_AFTER = 3           # each-at-a-time stores: pages in a row without the stock -> the product is read by the other browsers ...
UNREAD_FOR = 600.0         # ... for this long
GS_AUDIT_EVERY = 20.0      # GameStop: one product page is compared with the tile data this often
GS_DOUBT_FOR = 1800.0      # a product whose tile data disagreed with its page is read by its page for this long
GS_DOUBT_EVERY = 60.0      # ... once per this many seconds
TG_MISSING_EVERY = 30.0    # Target: a product the all-products answer leaves out is read on its own this often ...
TG_MISSING_MAX = 300.0     # ... and, while it gives no answer (a removed product), at most this often
DEAD_RECHECK = 300.0
SEARCH_EVERY = 3           # Walmart / Amazon: one round in this many reads a search page of the store instead of one product page ...
SEARCH_MIN_COVER = 2       # ... when that search shows at least this many of our products (one request: several products)
SEARCH_REDISCOVER = 21600.0  # which search shows which products is found out again this often
SEARCH_DOUBT_AFTER = 3     # a product the search calls buyable while its page says not, this many times in a row: its search answers are ignored ...
SEARCH_DOUBT_FOR = 1800.0  # ... for this long
AMAZON_TOTAL = 24          # Amazon: the buying browser's own checks of Shopping products (they buy) plus the sweeper's pages, per minute at most
#                            (the buying engine itself allows 18 a minute); the sweeper takes only what the engine leaves
BUSY_MAX = 120.0           # a checkout pauses the sweeper of its store (and the page-by-page sweepers) at most this long

FRESH = {}                 # product (row id) -> {"status", "price", "at", "seq", "src", "text", "kind"}
LAST_READ = {}             # product -> when any reader last had a real answer for it
ANSWERED = {}              # v100: product -> when any reader last had a REAL answer (put / note_read only; health() goes by it)
LAST_PICK = {}             # product -> when a reader of the program last started reading it itself
_SEQ = [0]
_LOCK = threading.RLock()
_S = {}                    # store -> the sweeper's state
_PERSIST = {}              # store -> the poller's shared state of that store (to hand answers on at once, and to see what is claimed)
_THREADS = {}
_DEAD = {}                 # product -> until when it is treated as removed from the store (no answer for it)
_ENGINE = {}
LOG = [print]
_BLOCK_HTTP = re.compile(r"HTTP (403|405|412|429|430|435|503)\b", re.I)
_GONE_HTTP = re.compile(r"HTTP (404|410)\b")
_BLOCK_WORDS = ("make sure you're not a robot", "make sure you&#39;re not a robot", "enter the characters you see below",
                "type the characters you see", "automated access to amazon data", "attention required! | cloudflare",
                "access denied", "request unsuccessful. incapsula", "just a moment...")


def log(msg):
    try:
        LOG[0]("[sweep] " + msg)
    except Exception:
        pass


def enabled_for(store):
    if os.environ.get("RK_NO_SWEEP"):
        return False
    only = os.environ.get("RK_SWEEP_STORES", "").replace(" ", "")
    return store in MODES and (not only or store in only.split(","))


# ================================================================ pacing

class Pace:
    """The pace of one stream of requests to one store (see the module text)."""

    def __init__(self, store, name, start, floor, ceil, learned=None):
        now = time.time()
        self.store, self.name = store, name
        self.start, self.floor, self.ceil = start, floor, ceil
        self.calm = start              # the normal pace (seconds between two requests)
        self.slow = 1.0                # a short slowdown after slow / failed answers (decays)
        self.safe = 0.0                # never faster than this for now (learned from a refusal)
        self.good = 0
        self.rest = 0.0
        self.rest_until = 0.0
        self.last_block = 0.0
        self.safe_at = 0.0
        self.since_rest = 1            # good answers since the last rest ended (0: the next request is the first after a rest)
        self.last_ok = 0.0
        self.requests = self.ok_n = self.soft_n = self.blocks = self.probes = 0
        self.last_why = ""
        self.minute = collections.deque()
        self.events = collections.deque(maxlen=10)
        self.next_at = 0.0
        self.answered = False          # (set by a good answer during the current round)
        self.woke = False
        self.learned = False
        if learned:
            try:
                age = max(0.0, now - float(learned.get("at") or 0))
                sf = float(learned.get("safe") or 0) * (0.9 ** int(age // SAFE_KEEP))
                self.safe = sf if sf > floor else 0.0
                self.calm = max(floor, min(ceil, max(self.safe, float(learned.get("calm") or start))))
                self.last_block = float(learned.get("last_block") or 0)
                self.safe_at = now
                self.learned = True
            except Exception:
                pass

    @property
    def interval(self):
        return min(self.ceil, max(self.floor, self.calm * self.slow))

    def saved(self):
        return {"calm": round(self.calm, 2), "safe": round(self.safe, 2), "last_block": self.last_block, "at": time.time(), "blocks": self.blocks}

    def waiting(self, now=None):
        """True while no request may be sent (the rest after a refusal)."""
        return (now or time.time()) < self.rest_until

    def resting(self, now=None):
        """True while resting after a refusal - and until the first answer after the rest (the store may still be refusing)."""
        now = now or time.time()
        if now < self.rest_until:
            return True
        return self.since_rest == 0 and self.rest_until > 0 and now - self.rest_until < max(30.0, 3.0 * self.interval)

    def note_request(self):
        now = time.time()
        self.requests += 1
        self.minute.append(now)
        while self.minute and now - self.minute[0] > 60:
            self.minute.popleft()

    def per_minute(self):
        now = time.time()
        while self.minute and now - self.minute[0] > 60:
            self.minute.popleft()
        return len(self.minute)

    def ok(self):
        now = time.time()
        self.ok_n += 1
        self.last_ok = now
        self.since_rest += 1
        self.slow = max(1.0, self.slow * SOFT_DOWN)
        if self.safe and now - max(self.last_block, self.safe_at) > SAFE_FORGET:
            self.safe = self.safe * 0.9 if self.safe * 0.9 > self.floor else 0.0
            self.safe_at = now
            _save_soon()
        self.good += 1
        if self.good >= RAMP_AFTER:
            self.good = 0
            low = max(self.floor, self.safe)
            if self.calm > low and now - self.last_block > RAMP_QUIET:
                self.calm = max(low, self.calm * RAMP)
                _save_soon()

    def soft(self, why):
        self.soft_n += 1
        self.good = 0
        self.last_why = str(why)[:160]
        self.slow = min(SOFT_MAX, self.slow * SOFT_UP)

    def block(self, why):
        now = time.time()
        self.blocks += 1
        self.good = 0
        self.last_why = str(why)[:160]
        probe = self.since_rest == 0 and self.rest_until > 0
        if probe:
            # the first request after a rest was refused: the store's penalty is still on - only the rest gets longer
            self.probes += 1
            self.rest = min(REST_MAX, max(REST_FIRST, self.rest * 2))
        else:
            self.safe = min(self.ceil, max(self.safe, self.calm * SAFE_MARGIN))
            self.calm = max(self.calm, self.safe)
            self.rest = REST_FIRST
        self.safe_at = now
        self.last_block = now
        self.since_rest = 0
        self.rest_until = now + self.rest
        _save_soon()
        self.events.append(f"{time.strftime('%H:%M:%S')} refused ({str(why)[:70]}) - resting {self.rest:.0f} s" +
                           ("" if probe else f", then one request every {self.interval:.1f} s (no faster for a while)"))
        log(f"{NAMES.get(self.store, self.store)}{'' if self.name == 'main' else ' (' + self.name + ')'}: the store refused a request "
            f"({str(why)[:90]})" + (" - still refusing after the rest" if probe else "") + f". Resting {self.rest:.0f} s, then one request every "
            f"{self.interval:.1f} s. Never pushed, never answered.")

    def take(self, stop_event, wake=None):
        """Waits for this stream's turn. -> False when the program stops."""
        while True:
            if stop_event is not None and stop_event.is_set():
                return False
            now = time.time()
            due = max(self.next_at, self.rest_until)
            if now >= due:
                self.next_at = now + self.interval
                self.woke = False
                return True
            if wake is not None and now >= self.rest_until and self.since_rest > 0 and now - (self.next_at - self.interval) >= self.floor and wake():
                self.next_at = now + self.interval
                self.woke = True             # (a tracker just alerted: this look goes at once, no turn-taking)
                return True
            time.sleep(min(0.2, max(0.02, due - now)))


# ---------------------------------------------------------------- v82: a store's readers take turns (looks evenly spread)
# The sweeper and the other browsers that read a store each keep their own pace. Left alone, their looks bunch up (two looks a moment
# apart, then a long gap) - and a restock waits for the next look. Evenly spread, N readers that each look every P seconds leave at most
# P/N between two looks (P/2N on average). No reader looks more often than its own pace allows: a turn only ever waits.
_SLOT = {}                 # store -> when the last planned look of any of its readers starts
_SPREAD = {"waits": collections.Counter(), "waited": collections.Counter()}


def _spread(store, pace, stop_event=None):
    """Called right after pace.take(): waits (at most half of this reader's own pace) so this store's looks are evenly spread.
    -> False when the program stops."""
    if pace.woke or os.environ.get("RK_NO_SPREAD"):
        return True
    now = time.time()
    with _LOCK:
        ps = []
        st = _S.get(store)
        if st is not None and st.get("running"):
            ps.append(st["pace"])
        for (s_, k_), r in list(_HELPERS.items()):
            if s_ == store and r.get("running") and r.get("pace") is not None:
                ps.append(r["pace"])
        ps = [p for p in ps if not p.waiting(now)]
        if pace not in ps:
            ps.append(pace)
        if len(ps) < 2:
            _SLOT[store] = max(_SLOT.get(store, 0.0), now)
            return True
        gap = 1.0 / sum(1.0 / max(0.2, p.interval) for p in ps)
        at = max(now, _SLOT.get(store, 0.0) + gap)
        at = min(at, now + 0.5 * pace.interval)
        _SLOT[store] = max(_SLOT.get(store, 0.0), at)
    if at - now > 0.01:
        pace.next_at += at - now                 # (its own rhythm moves with it, so the readers settle into even turns)
        _SPREAD["waits"][store] += 1
        _SPREAD["waited"][store] += at - now
        while time.time() < at:
            if stop_event is not None and stop_event.is_set():
                return False
            time.sleep(min(0.05, max(0.0, at - time.time())))
    return True


def spread_text(store):
    n = _SPREAD["waits"].get(store, 0)
    if not n:
        return ""
    return f"readers taking turns (v82): {n} looks moved a little to keep the looks evenly spread (on average by {_SPREAD['waited'][store] / n:.2f} s)"


# ---------------------------------------------------------------- what was learned about each store's pace survives a restart

_SAVE = {"at": 0.0, "due": False, "lock": threading.Lock(), "data": None}


def _learned():
    if _SAVE["data"] is None:
        try:
            with open(PACE_FILE, encoding="utf-8") as f:
                _SAVE["data"] = json.load(f) or {}
        except Exception:
            _SAVE["data"] = {}
    return _SAVE["data"]


def _save_soon():
    _SAVE["due"] = True


def _save_now(force=False):
    if not _SAVE["due"] and not force:
        return
    if not force and time.time() - _SAVE["at"] < 30:
        return
    with _SAVE["lock"]:
        _SAVE["due"] = False
        _SAVE["at"] = time.time()
        d = dict(_learned())
        for s_, st in list(_S.items()):
            d[s_] = st["pace"].saved()
            d[s_ + ":2"] = st["pace2"].saved()
            if st.get("lanes_bad_until"):
                d[s_ + ":lanes_bad_until"] = st["lanes_bad_until"]
            if st.get("search_off_until"):
                d[s_ + ":search_off_until"] = st["search_off_until"]
            if _HSTATE.get(s_, {}).get("off_until"):
                d[s_ + ":helpers_off"] = _HSTATE[s_]["off_until"]
        for (s_, k_), r in list(_HELPERS.items()):
            if r.get("pace") is not None:
                d[f"{s_}:id:{k_}"] = r["pace"].saved()
        _SAVE["data"] = d
        try:
            tmp = PACE_FILE + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(d, f, indent=1)
            os.replace(tmp, PACE_FILE)
        except Exception:
            pass


# ================================================================ the shared table

def attach(store, persist):
    """The poller's shared state of a store: lets the sweeper hand a new answer to the store's main checker at once."""
    _PERSIST[store] = persist


def _poke(store, tid):
    p = _PERSIST.get(store)
    if p is None:
        return
    nd = p.setdefault("next_due", {})
    if tid in nd:
        nd[tid] = min(nd[tid], time.time())
    cv = p.get("wake_cv")                  # v82: wake the store's checkers now (they no longer find it on their next timer tick)
    if cv is not None:
        with cv:
            p["wake_n"] = p.get("wake_n", 0) + 1
            cv.notify_all()
    else:
        p["wake_n"] = p.get("wake_n", 0) + 1


_WHO = threading.local()      # v101: which browser of the program read it (a helper sets its name; the sweeper itself is the main reader)


def who_now():
    return getattr(_WHO, "name", "") or "main reader"


def put(t, status, price=None, src="", text=None, kind="data", at=None):
    """A new answer for product t. `text` is what the store's main checker reads (the compact record, or the whole page)."""
    now = time.time()
    src = f"{src} [{who_now()}]" if src else f"[{who_now()}]"
    at = at or now
    if text is None:
        if status not in ("IN_STOCK", "OUT_OF_STOCK"):
            return
        text = json.dumps({"rk_sweep": {"status": status, "price": price, "src": src}})
    tid = t["id"]
    store = _store(t)
    with _LOCK:
        _SEQ[0] += 1
        prev = FRESH.get(tid)
        FRESH[tid] = {"status": status, "price": price, "at": at, "seq": _SEQ[0], "src": src, "text": text, "kind": kind}
        LAST_READ[tid] = max(LAST_READ.get(tid, 0.0), at)
        ANSWERED[tid] = max(ANSWERED.get(tid, 0.0), at)
        st = _S.get(store)
        if st is not None:
            if prev:
                g = at - prev["at"]
                if g > 0:
                    st["gap"][tid] = g if tid not in st["gap"] else 0.85 * st["gap"][tid] + 0.15 * g
            st["answers"] += 1
            st["answered"][tid] = at
    _DEAD.pop(tid, None)
    _poke(store, tid)


def note_read(t):
    """A reader of the program (not the sweeper) just read product t itself: the sweeper does not need to read it again at once."""
    LAST_READ[t["id"]] = time.time()
    ANSWERED[t["id"]] = time.time()


def note_pick(t, lane=0):
    """A reader of the program is about to read product t itself (see role(): while a sweeper rests, gently; extra readers calmly)."""
    LAST_PICK[t["id"]] = time.time()
    LAST_READ[t["id"]] = max(LAST_READ.get(t["id"], 0.0), time.time() - 60.0)       # (being read: not "never read" for the sweeper's order)
    st = _S.get(_store(t))
    if st is not None:
        st["lane_pick"] = time.time()
        st["lane_pick_by"][lane] = time.time()
        if lane:
            if time.time() - st.get("lane_pick_x", 0.0) > 300:
                st["lane_pick_x_first"] = time.time()      # (the extra readers start helping now)
            st["lane_pick_x"] = time.time()
        st["lane_reads"] = st.get("lane_reads", 0) + (1 if lane else 0)


def note_lane_refused(store, why=""):
    """A reader of the program (its own browser) was refused by the store too - while the sweeper rests nothing more is asked of it."""
    st = _S.get(store)
    if st is not None and st["running"]:
        st["lane_refused"] = time.time()
        st["lane_refused_n"] = st.get("lane_refused_n", 0) + 1


def note_verdict(t, status):
    """The main checker's reading of a whole page the sweeper fetched (each-at-a-time stores): a page that does not show the stock
    several times in a row is left to the other browsers for a while."""
    st = _S.get(_store(t))
    if st is None:
        return
    u = st["unread"]
    if status == "UNKNOWN":
        n = u.get(t["id"], (0, 0.0))[0] + 1
        u[t["id"]] = (n, time.time() + UNREAD_FOR if n >= UNREAD_AFTER else 0.0)
        if n == UNREAD_AFTER:
            log(f"{NAMES.get(st['store'])}: '{t['id']}': its page did not show the stock {n} times in a row - the program's other browsers "
                f"read it for the next {UNREAD_FOR / 60:.0f} minutes (the sweeper tries again after that).")
    else:
        u.pop(t["id"], None)
    note_search_verdict(t, status)


def _unreadable(st, tid):
    v = st["unread"].get(tid)
    if v and v[1] and time.time() >= v[1]:
        st["unread"].pop(tid, None)               # (its time is over: the sweeper tries it again)
        return False
    return bool(v and v[1])


# ================================================================ what the poller asks

def _store(t):
    u = (t.get("url") or "").lower()
    for s in MODES:
        if s + ".com" in u:
            return s
    return ""


def resting(store):
    st = _S.get(store)
    return bool(st and st["running"] and st["pace"].resting())


def healthy(store):
    st = _S.get(store)
    if not st or not st["running"] or not st.get("reader"):
        return False
    p = st["pace"]
    now = time.time()
    if p.resting(now) or not p.last_ok:
        return False
    return now - p.last_ok < max(HEALTHY_FOR, 6.0 * p.interval)


def state(store):
    """'off' (no sweeper: the program reads as before), 'starting', 'ok', 'resting' (refused: the store is read gently), 'failing'."""
    st = _S.get(store)
    if not st or not st["running"]:
        return "off"
    now = time.time()
    if not st.get("reader"):
        if not st["pace"].ok_n and now - st["started"] < STARTUP_GRACE:
            return "starting"
        if st["pace"].ok_n and now - st.get("reader_lost", 0.0) < 10.0:
            return "failing"
        return "off"                 # (the reader browser is not there: the store's own browsers read as before)
    if st["pace"].resting(now):
        return "resting"
    if healthy(store):
        return "ok"
    if now - st["started"] < STARTUP_GRACE and not st["pace"].ok_n:
        return "starting"
    return "failing"


def _can_read(st, t):
    """True when this sweeper can answer for product t at all."""
    s = st["store"]
    if s == "bestbuy":
        return bool(t.get("sku"))
    if s == "target":
        return bool(re.search(r"/A-(\d{5,})", t.get("url") or ""))
    if s == "gamestop":
        return bool(_gs_id(t))
    return True


def owns(t):
    """True while the store's sweeper answers for product t (then the other browsers leave it alone)."""
    store = _store(t)
    st = _S.get(store)
    if not st or not healthy(store) or not _can_read(st, t):
        return False
    tid = t["id"]
    if time.time() < _DEAD.get(tid, 0.0):
        return True                  # (removed from the store: the sweeper looks at it now and then - nobody else needs to)
    if st["mode"] == "each":
        return not _unreadable(st, tid)
    a = st["answered"].get(tid)
    if a and time.time() - a < OWN_FOR:
        return True
    return st["rounds"] < 3          # (its first rounds: it has not had the chance yet)


def want_age(t, st=None):
    st = st or _S.get(_store(t))
    tid = t["id"]
    now = time.time()
    if st is not None and now - st["poked"].get(tid, 0.0) < 60:
        return WANT_POKED
    base = WANT_SEARCHING
    try:
        import hotness
        hot = hotness.is_hot(tid, now)
    except Exception:
        hot = False
    if hot:
        base = WANT_HOT
    elif _shopping(t):
        base = WANT_ENGINE if (st is not None and st["store"] == "amazon" and _engine_watches(t)) else WANT_SHOPPING
    try:
        import predict                    # v82: a product whose own history shows it restocks often / comes back soon gets more of the looks
        k = predict.weight(tid, now)
        if k > 1.0:
            return max(WANT_POKED, base / k)
    except Exception:
        pass
    return base


def stale(t):
    """True when product t's newest answer (from anybody) is older than it should be."""
    seen = max((FRESH.get(t["id"]) or {}).get("at", 0.0), LAST_READ.get(t["id"], 0.0))
    return time.time() - seen > STALE_X * want_age(t)


def role(t, lane, lanes_want):
    """What reader `lane` of the store does with product t:
    'read' (reads it itself, as before v64), 'consume' (the main checker hands on the sweeper's newest answer), 'skip'."""
    store = _store(t)
    s = state(store)
    if s == "starting":
        # the buying browser is starting: the products its sweeper will read wait for it (at most STARTUP_GRACE) instead of each store
        # opening its own browsers for a minute (the start was slow)
        return "skip" if _can_read(_S[store], t) else ("read" if lane == 0 or _S[store]["mode"] == "batch" else "skip")
    if s in ("off", "failing"):
        return "read"
    if s == "resting":
        # the store refused the sweeper a moment ago: nobody hammers it meanwhile. The main checker reads gently with its own browser (another
        # visitor to the store - it may still be let in): one product at a time, at most one every REST_READ_STORE seconds, Shopping and
        # tracker-alerted products first; and not at all once its own browser is refused too during this rest
        st = _S[store]
        if lane != 0:
            return "skip"
        if not _can_read(st, t):
            return "read"
        now = time.time()
        st["lane_gate"] = max(st.get("lane_gate", 0.0), now + LANE_GATE_FOR)
        if (st.get("lane_refused", 0.0) > min(st["pace"].last_block, st["pace"].last_ok or 0.0)
                or now - st.get("lane_pick", 0.0) < REST_READ_STORE):
            return "skip"
        gap = REST_READ_GAP if (_shopping(t) or want_age(t) <= WANT_HOT) else REST_READ_ALL
        return "read" if now - LAST_PICK.get(t["id"], 0.0) >= gap else "skip"
    if owns(t):
        # the sweeper answers for it: the main checker hands its answers on; nobody else loads it (the store sees ONE calm visitor -
        # extra readers would only add requests to the same store, which is what gets refused) - except at the page-by-page stores while the
        # store has refused nothing for an hour: there the extra readers may read, calmly, the products the sweeper could not keep fresh
        if lane == 0:
            return "consume"
        if (_lanes_open(store) and t.get("fetch_mode") == "browser" and time.time() - _S[store].get("lane_pick_x", 0.0) >= EACH_LANE_GAP
                and stale(t)):
            return "read"                   # (only a link read by a browser: a plain request from the program would only be refused)
        return "skip"
    if lane == 0:
        return "read" if lanes_want <= 1 else "skip"
    return "read"


def _lanes_open(store):
    """Page-by-page stores: may the extra readers help? Not within LANE_GATE_FOR of any refusal at that store."""
    st = _S.get(store)
    if not st or st["mode"] != "each":
        return False
    now = time.time()
    last = max(st["pace"].last_block, st["pace2"].last_block, st.get("lane_refused", 0.0))
    if now - st.get("lane_pick_x", 0.0) < 300 and last > st.get("lane_pick_x_first", now):
        # the store refused while the extra readers were helping: it counts this PC's visits together - no extra readers there for a day
        if now >= st.get("lanes_bad_until", 0.0):
            st["lanes_bad_until"] = now + LANES_BAD_FOR
            _save_soon()
            log(f"{NAMES.get(store, store)}: refused while the other browsers were helping - it counts all of this PC's visits together, so "
                f"for the next 24 hours only the sweeper reads it (the other browsers would only be refused too).")
    if now < st.get("lanes_bad_until", 0.0):
        return False
    return bool(now - last >= LANE_GATE_FOR and now >= st.get("lane_gate", 0.0) and st.get("ok_since") and now - st["ok_since"] >= LANE_WARMUP)


def lanes_needed(store, live):
    """How many readers the store needs while its sweeper works (None = as many as planned, as before)."""
    s = state(store)
    st = _S.get(store)
    if s in ("off", "failing") or st is None:
        return None
    if s in ("starting", "resting"):
        return 1                     # (starting: the sweeper is waited for; resting after a refusal: the store is read gently, by one reader)
    if _lanes_open(store) and any(owns(x) and stale(x) and x.get("fetch_mode") == "browser" for x in live):
        return None                  # (page-by-page store, nothing refused for an hour, products the sweeper cannot keep fresh: help, calmly)
    return 1 + (1 if any(not owns(x) for x in live) else 0)


# ================================================================ the store's own requests

def _fetch(st, pace, url, timeout=20.0, gone_ok=False, cookies=None):
    """One request through the reader browser's tab of this store (v65: its own browser, not the buying browser). -> (text, None) or (None, why). Refusals slow `pace`.
    v81: in a helper thread (see _helper_run) the request goes through that helper's browser (one of the other buying browsers) instead."""
    import amazon_buy
    ident = getattr(_TL, "ident", None)
    pace.note_request()
    st["requests"] += 1
    if ident:
        import multibuy
        text, err, final = multibuy.fetch(ident, st["store"], url, timeout=min(float(timeout), 8.0))
        if err and ("busy" in err or "no answer in time" in err):
            return None, err                      # (the browser was checking out: not the store's doing)
    elif hasattr(amazon_buy, "page_fetch_ex"):
        text, err, final = (amazon_buy.page_fetch_ex(url, st["store"], timeout=timeout, cookies=cookies) if cookies else
                            amazon_buy.page_fetch_ex(url, st["store"], timeout=timeout))
    else:
        text, err = amazon_buy.page_fetch(url, st["store"], timeout=timeout)
        final = None
    if err:
        e = str(err)
        if _BLOCK_HTTP.search(e):
            pace.block(e)
            _note_outcome(st["store"], ident or "reader", True)
            _note_refusal(st["store"], ident or "reader", e)
            return None, e
        if gone_ok and _GONE_HTTP.search(e):
            return None, "gone: " + e
        pace.soft(e)
        return None, e
    if final and re.search(r"/(blocked|captcha|errors/validatecaptcha)\b", final, re.I):
        pace.block("sent to " + final[:80])
        _note_outcome(st["store"], ident or "reader", True)
        _note_refusal(st["store"], ident or "reader", "sent to " + final[:60])
        return None, "refused"
    if not text or not text.strip():
        pace.soft("empty answer")
        return None, "empty answer"
    if len(text) < 60000:
        try:
            from stock_detect import human_check_reason
            hc = human_check_reason(text)
        except Exception:
            hc = None
        low = text[:20000].lower()
        if hc or (not text.lstrip().startswith(("{", "[")) and any(w in low for w in _BLOCK_WORDS)):
            pace.block("human check: " + (hc or next(w for w in _BLOCK_WORDS if w in low)))
            _note_outcome(st["store"], ident or "reader", True)
            _note_refusal(st["store"], ident or "reader", "human check")
            return None, "refused"
    pace.answered = True
    _note_outcome(st["store"], ident or "reader", False)
    return text, None


def _rows(store):
    try:
        import ground_truth_poller as gp
        import matrix
        return [t for t in list(gp.GROUPS.get(store) or []) if t.get("active", True) and not matrix.is_off(t)]
    except Exception:
        return []


def _shopping(t):
    try:
        import amazon_buy
        u = amazon_buy._u_of(t)
        return bool(u and amazon_buy.wanted(u))
    except Exception:
        return False


def _engine_view():
    """The buying browser's own Amazon checks (it checks the products set to Shopping by itself): {asin: record}, watching, slowed."""
    try:
        import amazon_buy
        c = amazon_buy._engine_client()
        if not c:
            return {}, False, False
        with amazon_buy._lock:
            cat = {a: dict(p) for a, p in c.catalog.items()}
            gm = bool(c.global_monitoring)
        now_ms = time.time() * 1000
        slowed = any(re.search(r"THROTTL|COOLDOWN|VERIFICATION|CAPTCHA", str(p.get("status") or ""), re.I) for p in cat.values()
                     if p.get("monitor") and p.get("lastCheck") and now_ms - float(p["lastCheck"]) < 300000)
        return cat, gm, slowed
    except Exception:
        return {}, False, False


def _engine_watches(t):
    try:
        import amazon_buy
        a = amazon_buy.asin_of(t.get("url"))
        cat, gm, _ = _ENGINE.get("view") or ({}, False, False)
        p = cat.get(a or "")
        return bool(gm and p and p.get("monitor"))
    except Exception:
        return False


def _pause_for_checkout(store):
    """v92: should this store's readers wait while a checkout runs there? (amazon_buy.readers_pause decides; not for Amazon / Best Buy /
    Walmart - in the restock waves those must keep looking: the next wave comes while this checkout is still running)."""
    try:
        import amazon_buy
        if store in amazon_buy.READ_DURING_CHECKOUT:
            return amazon_buy.readers_pause(store)
        return True
    except Exception:
        return True


def _pause_max():
    try:
        import amazon_buy
        return min(BUSY_MAX, float(amazon_buy.READ_PAUSE_MAX))
    except Exception:
        return BUSY_MAX


def _busy_stores():
    """The stores where a checkout runs right now."""
    try:
        import amazon_buy
        c = amazon_buy._engine_client()
        if not c:
            return set()
        out = set()
        with amazon_buy._lock:
            if c.cart_owner:
                out.add("amazon")
            for p in c.catalog.values():
                if p.get("inProgress") or p.get("submissionPending"):
                    out.add("amazon")
            for k, p in c.bb.items():
                if p.get("inProgress") or p.get("submissionPending"):
                    try:
                        out.add(amazon_buy._store_of_key(k) or "bestbuy")
                    except Exception:
                        out.add("bestbuy")
        return out
    except Exception:
        return set()


# ---------------------------------------------------------------- Best Buy

_BB_BUYABLE = ("ADD_TO_CART", "PRE_ORDER", "PREORDER")


def _bb_text(sku, rec):
    return json.dumps({"bb_button": {"sku": sku, **{k: rec.get(k) for k in ("state", "purchasable", "price")}}})


def _bestbuy(st, rows):
    import ground_truth_poller as gp
    import stock_detect as sd
    pace = st["pace"]
    rows = [t for t in rows if t.get("sku")]
    skus = list(dict.fromkeys(str(t["sku"]) for t in rows))
    if not skus:
        return 0
    origin = "https://www.bestbuy.com"
    got, missing = {}, set()
    for i in range(0, len(skus), 40):
        text, why = _fetch(st, pace, origin + "/api/3.0/priceBlocks?skus=" + ",".join(skus[i:i + 40]))
        if text is None:
            return None
        part = sd.parse_bestbuy_blocks(text)
        for mm in re.finditer(r"Failed to retrieve price for sku (\d{5,9})(.{0,200})", text):
            if mm.group(1) not in part:
                part[mm.group(1)] = {"state": "NO_PRICE", "purchasable": False, "price": None}
            if "NotFound" in mm.group(2) or "not found" in mm.group(2):
                missing.add(mm.group(1))
        got.update({k: v for k, v in part.items() if k in skus})
    if not got:
        pace.soft("Best Buy's answer had no product data")
        return None
    need = [k for k in skus if (got.get(k) or {}).get("state") in (None, "NO_PRICE")]
    fresh_need = set(need) - set(st.setdefault("bb_noprice", set()))
    st["bb_noprice"] = set(need)
    if need and not fresh_need and st["rounds"] % 3:
        for k in need:                                    # (between those requests: the button word last read for it stands)
            if k in st.setdefault("bb_last_bs", {}):
                got[k] = dict(st["bb_last_bs"][k])
        need = []
    if need:
        t2, _ = _fetch(st, pace, gp._bb_buttonstate_url(origin, need))
        if t2:
            for k, v in sd.parse_bestbuy_blocks(t2).items():
                if k in need and (v.get("state") or v.get("purchasable") is not None):
                    if v.get("price") is None and (got.get(k) or {}).get("price") is not None:
                        v["price"] = got[k]["price"]
                    got[k] = v
                    st.setdefault("bb_last_bs", {})[k] = dict(v)
    try:
        gp._BBE.update(data={k: dict(v) for k, v in got.items()}, ts=time.time(), ts_done=time.time(), err=None)     # (the older readers' copy)
    except Exception:
        pass
    n = 0
    now = time.time()
    for t in rows:
        sku = str(t["sku"])
        rec = dict(got.get(sku) or {"state": "NO_RECORD", "purchasable": False, "price": None})
        if sku in missing and rec.get("state") in ("NO_PRICE", "NO_RECORD"):
            _DEAD[t["id"]] = now + DEAD_RECHECK
        if rec.get("state") in _BB_BUYABLE:
            hit = gp._BBV.get(sku)
            if not hit or now - hit[0] > gp.BB_SHIP_KEEP:
                _bb_ship_later(st, sku, rec, rows)        # its product page says whether it can be shipped; until then the last answer stands
                continue
            r = hit[1]
            if r.get("ok") and r.get("storeOnly") and not r.get("ships"):
                rec.update(state="IN_STORE_ONLY", purchasable=False)
        else:
            gp._BBV.pop(sku, None)
        _bb_hint(st, t, sku, rec, now)
        status = sd._bb_button_verdict(rec.get("state"), rec.get("purchasable"))
        if status:
            put(t, status, rec.get("price"), "Best Buy data (all products, one request)", text=_bb_text(sku, rec))
            n += 1
    return n


BB_HINT_GAP = 120.0


def _bb_hint(st, t, sku, rec, now):
    """v83 (diagnostics 68): during Best Buy's waiting-line drop of the Star Trek box ($479.99 pre-order) its product page showed
    "Pre-order" while Best Buy's all-products data said SOLD_OUT / COMING_SOON / SEE_DETAILS - only a tracker alert started the
    checkout. Now a product whose data CHANGES from a sold-out word to one that is neither sold out nor buyable (SEE_DETAILS and the like)
    is handed to the buying browser at once: it reads the product page itself and buys only if the page says Pre-order / Add to Cart
    (and the product is set to Buy, under its cap). At most once per BB_HINT_GAP per product."""
    import stock_detect as sd
    state = rec.get("state")
    prev_all = st.setdefault("bb_prev_state", {})
    prev = prev_all.get(sku)
    prev_all[sku] = state
    if not prev or prev == state or state in (None, "NO_PRICE", "NO_RECORD"):
        return
    if sd._bb_button_verdict(state, None) is not None or prev not in sd._BB_STATES_OUT:
        return
    hint = st.setdefault("bb_hint_at", {})
    if now - hint.get(sku, 0.0) < BB_HINT_GAP:
        return
    hint[sku] = now
    st.setdefault("bb_hints", collections.deque(maxlen=10)).append(f"{time.strftime('%H:%M:%S')} {t['id']}: {prev} -> {state}")
    log(f"Best Buy '{t['id']}': its data changed from {prev} to {state} (Best Buy shows this during a waiting-line drop) - the buying "
        f"browser reads its product page now.")
    try:
        import hotness
        hotness.mark(t["id"])
    except Exception:
        pass
    tid = t["id"]

    def go():
        try:
            import amazon_buy
            amazon_buy._signal_one(tid, f"Best Buy data changed to {state} (a waiting-line drop shows this)")   # (this product only)
        except Exception as e:
            log(f"Best Buy '{tid}': could not hand it to the buying browser ({str(e)[:80]})")
    threading.Thread(target=go, daemon=True, name="sweep-bb-hint").start()


def _bb_ship_later(st, sku, rec, rows):
    q = st.setdefault("ship_q", {})
    if sku in q:
        return
    q[sku] = dict(rec, _at=time.time())
    if st.get("ship_th") and st["ship_th"].is_alive():
        return

    def work():
        import ground_truth_poller as gp
        while q:
            if st["pace"].resting():
                time.sleep(1.0)
                continue
            k = next(iter(q))
            r = q[k]
            try:
                st["ship_checks"] += 1
                rec = dict(r)
                gp._bb_ship_check({k: rec}, rows, LOG[0])
                # its answer is handed on at once (not a round later): shipped -> in stock; in store only -> not
                import stock_detect as sd
                status = sd._bb_button_verdict(rec.get("state"), rec.get("purchasable"))
                if status and time.time() - r.get("_at", time.time()) < 30:
                    for t in [x for x in rows if str(x.get("sku")) == k]:
                        put(t, status, rec.get("price"), "Best Buy data (all products, one request), its product page checked", text=_bb_text(k, rec),
                            at=r.get("_at"))
            except Exception as e:
                log(f"Best Buy {k}: product page check failed ({str(e)[:80]})")
            q.pop(k, None)
            time.sleep(2.0)                                  # (product pages are heavy: never several at once)
    st["ship_th"] = threading.Thread(target=work, daemon=True, name="sweep-bb-ship")
    st["ship_th"].start()


# ---------------------------------------------------------------- Target

def target_titles(text):
    try:
        items = json.loads(text)["data"]["product_summaries"]
    except Exception:
        return {}
    out = {}
    for it in items or []:
        try:
            out[str(it["tcin"])] = _html.unescape(str(it["item"]["product_description"]["title"]))
        except Exception:
            pass
    return out


TG_BIG = 24
_TG_PLACE = ("GuestLocation", "fiatsCookie", "visitorId")


def _tg_place(gp):
    """Target answers for a place (store, zip). The place your own Target pages use is taken from the buying browser's Target cookies
    (GuestLocation / fiatsCookie / visitorId - exactly what Target's own page sends), so the stock is the one your account sees. Not logged."""
    try:
        import amazon_buy
        ck = (amazon_buy._reader.get("cookies") or {}).get("target") or {}
    except Exception:
        ck = {}
    ctx = {}
    parts = str(ck.get("GuestLocation") or "").split("|")
    if len(parts) >= 4 and re.fullmatch(r"\d{5}", parts[0] or "") and re.fullmatch(r"[A-Z]{2}", parts[3] or ""):
        ctx.update(zip=parts[0], latitude=parts[1], longitude=parts[2], state=parts[3])
    m = re.search(r"DSI_(\d+)", str(ck.get("fiatsCookie") or ""))
    if m:
        ctx["store_id"] = m.group(1)
    v = str(ck.get("visitorId") or "")
    if re.fullmatch(r"[0-9A-Fa-f]{32}", v):
        ctx["visitor_id"] = v
    if ctx.get("zip") and ctx.get("store_id"):
        old = gp._TGT.get("ctx") or {}
        new = dict(old, **ctx)
        if {k: old.get(k) for k in ctx} != ctx:
            gp._TGT["ctx"] = new
            log("Target: the place your own Target pages use (your store and zip, from the buying browser) is used for the all-products request.")


def _tg_urls(gp, tcins, ctx, chunk):
    """Target's all-products requests (as in ground_truth_poller.target_batch_urls), `chunk` products per request."""
    import urllib.parse as up
    key = ctx.get("key") or gp.TARGET_KNOWN_KEY
    store, where, vid = gp._tgt_where(ctx)
    base = "https://redsky.target.com/redsky_aggregations/v1/web/product_summary_with_fulfillment_v1"
    return [f"{base}?key={key}&tcins={up.quote(','.join(tcins[i:i + chunk]), safe='')}&store_id={store}&{where}"
            f"&scheduled_delivery_store_id={store}&required_store_id={store}&has_required_store_id=true&channel=WEB&{vid}"
            for i in range(0, len(tcins), chunk)]


def _tg_text(tcin, status, price):
    prod = {"tcin": tcin, "fulfillment": {"shipping_options": {"availability_status": status}}}
    if price:
        prod["price"] = {"current_retail": price}
    return json.dumps({"data": {"product": prod}})


def _target(st, rows):
    import ground_truth_poller as gp
    pace = st["pace"]
    tc = {}
    for t in rows:
        m = re.search(r"/A-(\d{5,})", t.get("url") or "")
        if m:
            tc.setdefault(m.group(1), []).append(t)
    if not tc:
        return 0
    ctx = gp._TGT.get("ctx") or {}
    ask_place = time.time() - st.get("tg_place_at", 0.0) > 1800
    got, titles, ok_any = {}, {}, False
    chunk = st.get("tg_chunk") or (TG_BIG if len(tc) > 10 else 10)
    if st.get("tg_chunk") is None and st["rounds"] == 1 and len(tc) > 10:
        chunk = 10                                         # (the second round asks 10 at a time once, to compare - see below)
    for u in _tg_urls(gp, list(tc), ctx, chunk):
        text, why = _fetch(st, pace, u, cookies=_TG_PLACE if ask_place else None)
        if ask_place:
            ask_place = False
            st["tg_place_at"] = time.time()
            _tg_place(gp)
        if text is None:
            if not ok_any:
                return None
            continue
        part = gp.parse_target_summaries(text)
        if part:
            ok_any = True
        got.update(part)
        titles.update(target_titles(text))
    if not got:
        pace.soft("Target's answer had no product data")
        return None
    if st.get("tg_chunk") is None and len(tc) > 10:
        if st["rounds"] == 0:
            st["tg_first"] = set(got)
        elif st["rounds"] == 1:
            more = set(got) - st.get("tg_first", set())
            st["tg_chunk"] = 10 if more else TG_BIG
            log(f"Target: {'only 10 products per request answer all of them' if more else f'one request answers up to {TG_BIG} products'} "
                f"- {(len(tc) + st['tg_chunk'] - 1) // st['tg_chunk']} request(s) per round.")
    now = time.time()
    try:
        gp._TB.update(data=dict(got), ts=now, ts_done=now, fails=0, n_ok=gp._TB.get("n_ok", 0) + 1)          # (the older readers' copy)
        import hotness
        hotness.set_cheap("target", True)
    except Exception:
        pass
    n = 0
    for tcin, ts in tc.items():
        if tcin in got:
            status, price = got[tcin]
            for t in ts:
                put(t, status, price, "Target data (all products, one request)", text=_tg_text(tcin, status, price))
                n += 1
                if titles.get(tcin) and now - st["named"].get(t["id"], 0.0) > 1800:
                    st["named"][t["id"]] = now
                    _note_title(t, titles[tcin])
    st["missing"] = [x for x in tc if x not in got]
    _target_missing(st, tc)
    return n


def _target_missing(st, tc):
    """A product the all-products answer leaves out: its own small product request, one at a time, gently (its own pace: a refusal
    there does not stop the all-products answer)."""
    import ground_truth_poller as gp
    import stock_detect as sd
    if not st["missing"]:
        return
    mp = st["pace2"]
    now = time.time()
    if mp.waiting(now) or now < mp.next_at:
        return
    due = [x for x in st["missing"] if now >= st["miss_next"].get(x, 0.0)]
    if not due:
        return
    tcin = min(due, key=lambda x: st["miss_next"].get(x, 0.0))
    mp.next_at = now + mp.interval
    text, why = _fetch(st, mp, gp._tgt_ful_urls(tcin)[0], gone_ok=True)      # (Target's stock request for one product)
    k = st["miss_n"].get(tcin, 0)
    if text:
        mp.ok()
        hit = False
        u0 = tc[tcin][0]["url"]
        s2 = sd.detect_availability(text, u0)
        if s2 in ("IN_STOCK", "OUT_OF_STOCK"):
            p2 = sd.detect_price(text, u0)
            if s2 == "IN_STOCK" and p2 is None:
                t3, _w = _fetch(st, mp, gp._tgt_prod_url(tcin), gone_ok=True)      # (its price: the product request)
                p2 = sd.detect_price(t3, u0) if t3 else None
            for t in tc[tcin]:
                put(t, s2, p2, "Target stock request for this product (not in the all-products answer)", text=_tg_text(tcin, s2, p2))
            hit = True
        if hit:
            st["miss_n"][tcin] = 0
            st["miss_next"][tcin] = now + TG_MISSING_EVERY
            return
    st["miss_n"][tcin] = k + 1
    wait = min(TG_MISSING_MAX, TG_MISSING_EVERY * (2 ** min(k, 4)))
    st["miss_next"][tcin] = now + wait
    if k + 1 >= 2:
        for t in tc[tcin]:
            _DEAD[t["id"]] = now + wait + 5                 # (no answer twice: treated as removed from the store - looked at now and then)
    if k == 0 or (k + 1) % 20 == 0:
        log(f"Target {tcin}: not in the all-products answer and its own request gave no stock ({str(why or 'no stock in it')[:80]}) - "
            f"looked at again in {wait:.0f} s.")


# ---------------------------------------------------------------- GameStop

GS_TILE = "https://www.gamestop.com/on/demandware.store/Sites-gamestop-us-Site/default/Tile-GetProductsJSON?data={ids}&useTileImage=false"


def _gs_id(t):
    m = re.search(r"/(\d{5,})\.html", t.get("url") or "")
    return m.group(1) if m else None


def parse_gamestop_tiles(text):
    """GameStop's product-tile answer -> {id: (status, price, name)} under every id it names (the one asked for, its product id and
    its item number). A product counts as in stock only when it is both available and ready to order (or a pre-order)."""
    try:
        pj = (json.loads(text) or {}).get("productsJSON") or {}
    except Exception:
        return {}
    out = {}
    for key, rec in pj.items():
        try:
            av = rec.get("availability") if isinstance(rec.get("availability"), dict) else {}
            # (a tile without any availability is not orderable: counted as not in stock - a turn to "available" is checked on its page)
            avail = bool(av.get("available")) and (bool(av.get("readyToOrder")) or bool(av.get("preorder")))
            pr = rec.get("price") or {}
            price = None
            for k in ("sale", "base"):
                v = pr.get(k)
                if v not in (None, ""):
                    try:
                        price = float(str(v).replace("$", "").replace(",", ""))
                        break
                    except Exception:
                        pass
            val = ("IN_STOCK" if avail else "OUT_OF_STOCK", price, _html.unescape(str(rec.get("name") or "")))
            for alt in (key, rec.get("id"), rec.get("constructorVariationId"), rec.get("constructorItemId")):
                if alt not in (None, "") and str(alt) not in out:
                    out[str(alt)] = val
        except Exception:
            continue
    return out


def _effective_in(t, status, price):
    if status != "IN_STOCK":
        return False
    cap = t.get("max_price")
    try:
        return not (cap and price is not None and float(price) > float(cap))
    except Exception:
        return True


def _gs_page(st, t):
    """GameStop: product t's own page (its second pace). -> (status, price, text) or None."""
    import stock_detect as sd
    pp = st["pace2"]
    if pp.waiting():
        return None
    text, why = _fetch(st, pp, t["url"], timeout=25.0)
    if not text:
        return None
    s2 = sd.detect_availability(text, t["url"])
    if s2 not in ("IN_STOCK", "OUT_OF_STOCK"):
        pp.soft("the page did not show the stock")
        return None
    pp.ok()
    return s2, (sd.detect_price(text, t["url"]) if s2 == "IN_STOCK" else None), text


def _gamestop(st, rows):
    pace = st["pace"]
    by = {}
    for t in rows:
        i = _gs_id(t)
        if i:
            by.setdefault(i, []).append(t)
    if not by:
        return 0
    got = {}
    ids = list(by)
    t_read = time.time()
    for i in range(0, len(ids), 20):
        text, why = _fetch(st, pace, GS_TILE.format(ids="%2C".join(ids[i:i + 20])))
        if text is None:
            return None
        got.update(parse_gamestop_tiles(text))
    if not got:
        pace.soft("GameStop's answer had no product data")
        return None
    n = 0
    now = time.time()
    for pid, ts in by.items():
        # a product the tile answer leaves out three rounds in a row is treated as removed (looked at again now and then)
        if pid in got:
            st["absent"].pop(pid, None)
            continue
        k = st["absent"][pid] = st["absent"].get(pid, 0) + 1
        if k >= 3:
            for t in ts:
                if now >= _DEAD.get(t["id"], 0.0):
                    _DEAD[t["id"]] = now + DEAD_RECHECK
                    if t["id"] not in st["said_dead"]:
                        st["said_dead"].add(t["id"])
                        log(f"GameStop '{t['id']}': not in GameStop's product-tile answer (a removed product or a wrong link?) - not read by the "
                            f"other browsers; looked at again every {DEAD_RECHECK / 60:.0f} minutes.")
    conf = st["confirm"]
    doubt = st["doubt"]
    confirms = 2                                           # (at most two product pages per round - never a burst of page loads)
    for pid, ts in by.items():
        if pid not in got:
            continue
        status, price, name = got[pid]
        for t in ts:
            tid = t["id"]
            if name and now - st["named"].get(tid, 0.0) > 1800:
                st["named"][tid] = now
                _note_title(t, name)
            if time.time() < doubt.get(tid, 0.0):
                st["tile"][tid] = (status, price)
                continue                                   # (its tile data was wrong lately: its page decides - see the page checks below)
            prev = FRESH.get(tid)
            was_in = bool(prev and _effective_in(t, prev["status"], prev["price"]))
            if prev is not None and _effective_in(t, status, price) and not was_in:
                # turning available in the tile data: its own page must say so too (a first answer is no restock - it is not checked;
                # the page comparisons below find a product whose tile data is wrong)
                if confirms <= 0:
                    continue                               # (next round)
                confirms -= 1
                conf["asked"] += 1
                pg = _gs_page(st, t)
                if pg and pg[0] == "IN_STOCK":
                    conf["agreed"] += 1
                    st["tile"][tid] = (status, price)
                    put(t, "IN_STOCK", pg[1] if pg[1] is not None else price, "GameStop data, confirmed on its product page",
                        text=pg[2], kind="page", at=t_read)
                    n += 1
                    continue
                if pg and pg[0] == "OUT_OF_STOCK":
                    conf["disagreed"] += 1
                    doubt[tid] = time.time() + GS_DOUBT_FOR
                    st["tile"][tid] = (status, price)
                    st["doubt_next"][tid] = time.time() + GS_DOUBT_EVERY
                    st["events"].append(f"{time.strftime('%H:%M:%S')} {tid}: the tile data said available, its page says not - "
                                        f"its page decides for {GS_DOUBT_FOR / 60:.0f} min")
                    put(t, "OUT_OF_STOCK", None, "GameStop product page (its tile data said available)", text=pg[2], kind="page")
                    n += 1
                    continue
                conf["failed"] += 1
                k = st["unconfirmed"][tid] = st["unconfirmed"].get(tid, 0) + 1
                if k < 2:
                    continue                               # (asked again next round)
                put(t, "IN_STOCK", price, "GameStop data (its product page could not be read twice to confirm)", at=t_read)
                n += 1
                continue
            st["unconfirmed"].pop(tid, None)
            st["tile"][tid] = (status, price)
            put(t, status, price, "GameStop data (all products, one request)", at=t_read)
            n += 1
    _gs_pages(st, rows)
    return n


def _gs_pages(st, rows):
    """GameStop: products whose tile data disagreed with their page are read by their page (once a minute); and one product page is
    compared with its tile data every GS_AUDIT_EVERY seconds (a product whose tile data is wrong is found that way)."""
    pp = st["pace2"]
    now = time.time()
    if pp.waiting(now) or now < pp.next_at:
        return
    doubt = st["doubt"]
    cand = [t for t in rows if now < doubt.get(t["id"], 0.0) and now >= st["doubt_next"].get(t["id"], 0.0)]
    audit = False
    if cand:
        t = min(cand, key=lambda x: st["doubt_next"].get(x["id"], 0.0))
    else:
        if now - st["audit_at"] < GS_AUDIT_EVERY:
            return
        pool = [x for x in rows if x["id"] in st["tile"]]
        if not pool:
            return
        st["audit_i"] = (st["audit_i"] + 1) % len(pool)
        t = pool[st["audit_i"]]
        audit = True
        st["audit_at"] = now
    pp.next_at = now + pp.interval
    tid = t["id"]
    st["doubt_next"][tid] = now + GS_DOUBT_EVERY
    pg = _gs_page(st, t)
    if not pg:
        return
    tl = st["tile"].get(tid)
    a = st["audits"]
    if audit:
        a["n"] += 1
    if tl and tl[0] != pg[0]:
        if audit:
            a["disagreed"] += 1
        if now >= doubt.get(tid, 0.0):
            st["events"].append(f"{time.strftime('%H:%M:%S')} {tid}: its page says {pg[0]}, its tile data {tl[0]} - its page decides for "
                                f"{GS_DOUBT_FOR / 60:.0f} min")
            log(f"GameStop '{tid}': its product page says {pg[0]} but the tile data says {tl[0]} - this product is read by its page "
                f"for the next {GS_DOUBT_FOR / 60:.0f} minutes.")
        doubt[tid] = now + GS_DOUBT_FOR
        st["agree_run"].pop(tid, None)
        put(t, pg[0], pg[1], "GameStop product page", text=pg[2], kind="page")
    elif now < doubt.get(tid, 0.0):
        put(t, pg[0], pg[1], "GameStop product page", text=pg[2], kind="page")
        if tl and tl[0] == pg[0]:
            st["agree_run"][tid] = st["agree_run"].get(tid, 0) + 1
            if st["agree_run"][tid] >= 5:
                doubt.pop(tid, None)                       # (the tile data agreed with its page 5 times in a row: trusted again)
                st["agree_run"].pop(tid, None)
    else:
        LAST_READ[tid] = now


# ---------------------------------------------------------------- Walmart / Amazon: one product page at a time

def _claim(store, tid):
    p = _PERSIST.get(store)
    if p is None:
        return True
    lk = p.setdefault("claim_lock", threading.Lock())
    inf = p.setdefault("inflight", {})
    with lk:
        if tid in inf:
            return False
        inf[tid] = ("sweep", time.time())
        return True


def _unclaim(store, tid):
    p = _PERSIST.get(store)
    if p is None:
        return
    lk = p.setdefault("claim_lock", threading.Lock())
    inf = p.setdefault("inflight", {})
    with lk:
        if (inf.get(tid) or (None,))[0] == "sweep":
            inf.pop(tid, None)


def _each(st, rows):
    store = st["store"]
    pace = st["pace"]
    now = time.time()
    if store == "amazon":
        cat, gm, slowed = _ENGINE["view"] = _engine_view()
        if slowed and not st.get("eng_slowed"):
            st["eng_slowed"] = True
            pace.block("Amazon slowed down the buying browser's own checks - its checks (they buy) come first")
            return None
        if not slowed:
            st["eng_slowed"] = False
        # how many checks the buying browser made itself in the last minute (each one changes its 'last check' time)
        dq = st.setdefault("eng_checks", collections.deque())
        last = st.setdefault("eng_last", {})
        for a, p in cat.items():
            lc = p.get("lastCheck")
            if p.get("monitor") and lc and last.get(a) != lc:
                if a in last:
                    dq.append(now)
                last[a] = lc
        while dq and now - dq[0] > 60:
            dq.popleft()
        # the buying browser's own check says a product set to Shopping is buyable: read it now (the alert comes from our own read)
        try:
            import amazon_buy
            for t in rows:
                p = cat.get(amazon_buy.asin_of(t.get("url")) or "")
                # v65 (your report: the Hobbit box at Amazon was 3 min old while Best Buy was 3 s): the buying browser checks the products
                # set to buy at Amazon by itself, about once a minute - an OUT OF STOCK answer of its own check now goes into the table
                # too (it is a real reading of that very page). An IN STOCK one still has its page read at once (below), as before.
                if p and p.get("lastCheck") and re.match(r"(WAITING|OUT OF STOCK|.*UNAVAILABLE)", str(p.get("status") or "").upper()):
                    lc = float(p["lastCheck"]) / 1000.0
                    if 0 <= now - lc < 120 and lc > st.setdefault("eng_put", {}).get(t["id"], 0.0) and lc > (FRESH.get(t["id"]) or {}).get("at", 0.0):
                        st["eng_put"][t["id"]] = lc
                        put(t, "OUT_OF_STOCK", None, "Amazon: the buying browser's own check", at=lc)
                if p and p.get("lastCheck") and re.match(r"(ELIGIBLE|OVER CAP)", str(p.get("status") or "")):
                    lc = float(p["lastCheck"]) / 1000.0
                    if lc > st["eng_seen"].get(t["id"], 0.0) and lc > LAST_READ.get(t["id"], 0.0) - 1:
                        st["eng_seen"][t["id"]] = lc
                        st["poked"][t["id"]] = now
        except Exception:
            pass
    pool = [t for t in rows if not _unreadable(st, t["id"]) and now >= _DEAD.get(t["id"], 0.0)]
    if not pool:
        return 0
    try:
        import predict
        predict.note_products(store, [t["id"] for t in rows])
    except Exception:
        pass

    sq = st["sq"]
    relief = 1.0 + (SEARCH_RELIEF - 1.0) * _search_trust(sq) * 2 if sq.get("covered") else 1.0     # (trust 0.5 -> x3)
    relief = min(SEARCH_RELIEF, max(1.0, relief))

    def score(t):
        seen = max((FRESH.get(t["id"]) or {}).get("at", 0.0), LAST_READ.get(t["id"], 0.0))
        w = want_age(t, st)
        if t["id"] in sq.get("covered", ()) and w > WANT_POKED and now >= sq["doubt"].get(t["id"], 0.0):
            w *= relief                     # (a search that is relied on watches it - its own page is read less often)
        return (now - seen if seen else 1e7) / w
    for t in sorted(pool, key=score, reverse=True)[:6]:
        if _claim(store, t["id"]):
            break
    else:
        st["no_turn"] = st.get("no_turn", 0) + 1
        # v98 (diagnostics 78: for 5 hours the program's two own Amazon readers held BOTH products every moment - the sweeper, and with it
        # the other browsers and the offers list, never got a turn: 47 requests instead of ~11,000). Once the sweeper had no good answer for
        # a while it counted as "failing", so more readers were sent - which took its turns away for good. Now, while it is "failing" only
        # for want of a turn (its reader is there, nothing was refused), it reads the most overdue product anyway - at most one such read
        # every TURN_BACK_EVERY s, only at Amazon (Walmart judges the whole PC), never by the other browsers. One good answer and it is
        # healthy again: the readers step back by themselves.
        now2 = time.time()
        if (store in TURN_BACK_STORES and not getattr(_TL, "ident", None) and state(store) == "failing" and not pace.resting(now2)
                and now2 - st.get("forced_at", 0.0) >= TURN_BACK_EVERY):
            st["forced_at"] = now2
            st["turn_back"] = st.get("turn_back", 0) + 1
            t = sorted(pool, key=score, reverse=True)[0]
            if st["turn_back"] in (1, 10) or st["turn_back"] % 100 == 0:
                log(f"{NAMES.get(store, store)}: the sweeper had no turn (the program's own readers held every product) - it takes one back now "
                    f"({st['turn_back']}x so far); once it answers again those readers step back.")
            try:
                st["poked"].pop(t["id"], None)
                text, why = _fetch(st, pace, t["url"], timeout=25.0, gone_ok=True)
            except Exception as e:
                return None
            if text is None:
                return None
            put(t, None, None, NAMES.get(store, store) + " product page", text=text, kind="page")
            return 1
        return 0
    try:
        st["poked"].pop(t["id"], None)
        text, why = _fetch(st, pace, t["url"], timeout=25.0, gone_ok=True)
    finally:
        _unclaim(store, t["id"])
    if text is None and str(why).startswith("gone"):
        # the store says this page does not exist (a removed product, a wrong link): looked at again in a few minutes, by the sweeper only
        _DEAD[t["id"]] = time.time() + DEAD_RECHECK
        LAST_READ[t["id"]] = time.time()
        if t["id"] not in st["said_dead"]:
            st["said_dead"].add(t["id"])
            log(f"{NAMES[store]} '{t['id']}': the store says this page does not exist ({why[6:60]}) - looked at again every {DEAD_RECHECK / 60:.0f} minutes.")
        pace.answered = True
        return 0
    if text is None:
        return None
    put(t, None, None, NAMES.get(store, store) + " product page", text=text, kind="page")
    return 1


# ---------------------------------------------------------------- Walmart / Amazon: the store's own search page as an early signal
# One search page (e.g. "magic the gathering star trek") lists several of our products with their price and whether they can be bought.
# It is used ONLY to look sooner: a product it shows buyable at a normal price has its own product page read at once - the page decides
# (a search page can lag behind, or show another seller). Which search shows which of our products is found out by the sweeper itself.

BROAD = ("collector booster box", "collector booster", "play booster box", "bundle", "booster box", "commander deck")   # (kind words)
SEARCH_OFF_FOR = 6 * 3600.0  # v83: a refused search page stops the store's searches this long (product pages keep their own pace)
SEARCH_RELIEF = 3.0        # a product a trustworthy search shows is read by its own page this many times less often (the search watches it)


def _q_of(theme):
    import urllib.parse as up
    return up.quote_plus("magic the gathering " + theme)


def _candidates(rows):
    """The searches tried: one per set ('magic the gathering star trek') and a few broad ones by kind ('... collector booster box')."""
    try:
        import products
        themes = sorted({products.theme_of(t) for t in rows if products.theme_of(t)})
    except Exception:
        themes = []
    return themes + [b for b in BROAD if b not in themes]


def _pick_cover(sq, rows):
    """The fewest searches that show the most of our products (each must add at least SEARCH_MIN_COVER of them)."""
    left = {t["id"] for t in rows}
    chosen = []
    cover = {q: set(c) & left for q, c in sq["cover"].items()}
    while True:
        best = max(cover, key=lambda q: len(cover[q] & left), default=None)
        if best is None or len(cover[best] & left) < SEARCH_MIN_COVER:
            break
        chosen.append(best)
        left -= cover[best]
    sq["chosen"] = chosen
    sq["covered"] = {t["id"] for t in rows} - left
    return chosen


def _search_trust(sq):
    """How far the search pages can be relied on to show a restock (0..1): restocks it showed first vs. restocks of products it shows
    that only their own page found (it was late), and the times it called a product buyable that was not."""
    good, late, bad = sq["confirmed"], sq["late"], sq["false"]
    n = good + late + bad
    return 0.5 if n < 3 else good / n


def _search_url(store, theme):
    if store == "walmart":
        return "https://www.walmart.com/search?q=" + _q_of(theme)
    return "https://www.amazon.com/s?k=" + _q_of(theme) + "&rh=p_6%3AATVPDKIKX0DER"       # (sold by Amazon.com)


def _num(v):
    try:
        if isinstance(v, (int, float)):
            return float(v)
        m = re.search(r"([\d,]+\.\d{2}|\d+)", str(v or ""))
        return float(m.group(1).replace(",", "")) if m else None
    except Exception:
        return None


def parse_walmart_search(text):
    """Walmart's search page -> {item number: (status, price, seller)} (from the data the page carries, __NEXT_DATA__)."""
    m = re.search(r'<script[^>]*id="__NEXT_DATA__"[^>]*>(.*?)</script>', text or "", re.S)
    if not m:
        return {}
    try:
        data = json.loads(m.group(1))
    except Exception:
        return {}
    out = {}

    def visit(n, d=0):
        if d > 40:
            return
        if isinstance(n, dict):
            iid = n.get("usItemId")
            if iid and ("availabilityStatusV2" in n or "availabilityStatus" in n or "isOutOfStock" in n):
                av = n.get("availabilityStatusV2")
                v = str((av or {}).get("value") if isinstance(av, dict) else (av or n.get("availabilityStatus") or "")).upper()
                if not v and "isOutOfStock" in n:
                    v = "OUT_OF_STOCK" if n.get("isOutOfStock") else "IN_STOCK"
                status = "IN_STOCK" if v in ("IN_STOCK", "LIMITED_STOCK", "AVAILABLE") else "OUT_OF_STOCK" if v else None
                price = _num(n.get("price"))
                if price is None:
                    pi = n.get("priceInfo") or {}
                    price = _num((pi.get("currentPrice") or {}).get("price") if isinstance(pi.get("currentPrice"), dict) else pi.get("linePrice"))
                if status and str(iid) not in out:
                    out[str(iid)] = (status, price, str(n.get("sellerName") or ""))
            for v in n.values():
                visit(v, d + 1)
        elif isinstance(n, list):
            for v in n:
                visit(v, d + 1)
    visit(data)
    return out


def parse_amazon_search(text):
    """Amazon's search page -> {ASIN: (status, price)}: a result showing its own price counts as buyable, one without as not."""
    out = {}
    text = text or ""
    tags = list(re.finditer(r'<div\b[^>]*data-component-type="s-search-result"[^>]*>', text))
    for i, m in enumerate(tags):
        am = re.search(r'data-asin="([A-Z0-9]{10})"', m.group(0))
        if not am:
            continue
        body = text[m.end(): tags[i + 1].start() if i + 1 < len(tags) else m.end() + 30000][:30000]
        pm = re.search(r'<span class="a-price"[^>]*>\s*<span class="a-offscreen">\s*\$([\d,]+\.\d{2})', body)
        out.setdefault(am.group(1), ("IN_STOCK", float(pm.group(1).replace(",", ""))) if pm else ("OUT_OF_STOCK", None))
    return out


def _id_of(store, t):
    if store == "walmart":
        m = re.search(r"/ip/(?:[^/?]+/)?(\d+)", t.get("url") or "")
        return m.group(1) if m else None
    try:
        import amazon_buy
        return amazon_buy.asin_of(t.get("url"))
    except Exception:
        return None


def _search_round(st, rows):
    """-> None (not a search round), or the number of products answered (a search page was read)."""
    store = st["store"]
    sq = st["sq"]
    now = time.time()
    themes = _candidates(rows)
    if now - sq["found_at"] > SEARCH_REDISCOVER:
        sq["found_at"] = now
        sq["tried"] = {}
    todo = [th for th in themes if th not in sq["tried"]]
    active = sorted(_pick_cover(sq, rows), key=lambda th: sq["last"].get(th, 0.0))
    if todo:
        theme = todo[0]
    elif active:
        theme = active[0]
    else:
        return None
    ids = {_id_of(store, t): t for t in rows}
    # v83 (diagnostics 68): Walmart refused ONLY its search pages ("sent to /blocked?url=/search..." 243 times) while its product pages
    # answered - but each refused search slowed the product pages to one every 120 s (a restock was seen after ~7 minutes). Search pages
    # now have their own pace: a refused search stops the searches for SEARCH_OFF_FOR and leaves the product pages' pace alone.
    sp = st.get("space")
    if sp is None:
        sp = st["space"] = Pace(store, "search pages", *PRIORS[store])
    b0 = sp.blocks
    text, why = _fetch(st, sp, _search_url(store, theme), timeout=25.0, gone_ok=True)
    if sp.blocks > b0:
        st["search_off_until"] = time.time() + SEARCH_OFF_FOR
        _save_soon()
        log(f"{NAMES.get(store, store)}: the store refused a search page - searches stop for {SEARCH_OFF_FOR / 3600:.0f} h; product pages go on at "
            f"their own pace (one every {st['pace'].interval:.1f} s).")
    sq["tried"][theme] = now
    sq["last"][theme] = now
    sq["n"] += 1
    if text is None:
        return 0 if str(why).startswith("gone") else -1
    got = parse_walmart_search(text) if store == "walmart" else parse_amazon_search(text)
    found = [ids[k] for k in got if k in ids]
    sq["cover"][theme] = {t["id"] for t in found}
    _pick_cover(sq, rows)
    seen = sq["seen"]
    trig = []
    for t in found:
        status, price = got[_id_of(store, t)][:2]
        seen[t["id"]] = (now, status, price)
        prev = FRESH.get(t["id"])
        if _effective_in(t, status, price) and not (prev and prev.get("status") == "IN_STOCK") and now >= sq["doubt"].get(t["id"], 0.0):
            trig.append(t)
    if trig:
        sq["triggers"] += len(trig)
        for t in trig:
            st["poked"][t["id"]] = now            # (its product page is read next - right away for the first one)
        t = trig[0]
        if _claim(store, t["id"]):
            try:
                st["poked"].pop(t["id"], None)
                p2, w2 = _fetch(st, st["pace"], t["url"], timeout=25.0, gone_ok=True)
            finally:
                _unclaim(store, t["id"])
            if p2:
                st["search_check"][t["id"]] = now
                put(t, None, None, NAMES[store] + " product page (its search page showed it buyable)", text=p2, kind="page")
    return len(found)


def note_search_verdict(t, status):
    """The main checker's reading of a product page read because the store's search page showed it buyable: right, or not.
    And a page that shows a restock of a product the searches show, found without the search's help: the search was late."""
    st = _S.get(_store(t))
    if st is None or st["mode"] != "each":
        return
    now = time.time()
    was, was_at = st["last_page"].get(t["id"], (None, 0.0))
    st["last_page"][t["id"]] = (status, now)
    if t["id"] not in st["search_check"]:
        sq = st["sq"]
        seen = sq["seen"].get(t["id"])
        # a restock its own page found, while a search read AFTER the page's last 'out' still showed it not buyable: the search was late
        if status == "IN_STOCK" and was == "OUT_OF_STOCK" and seen and seen[0] > was_at and seen[1] != "IN_STOCK":
            sq["late"] += 1
        return
    st["search_check"].pop(t["id"], None)
    sq = st["sq"]
    if status == "IN_STOCK":
        sq["confirmed"] += 1
        sq["wrong"].pop(t["id"], None)
    elif status == "OUT_OF_STOCK":
        sq["false"] += 1
        k = sq["wrong"][t["id"]] = sq["wrong"].get(t["id"], 0) + 1
        if k >= SEARCH_DOUBT_AFTER:
            sq["doubt"][t["id"]] = time.time() + SEARCH_DOUBT_FOR
            sq["wrong"].pop(t["id"], None)
            log(f"{NAMES[st['store']]} '{t['id']}': its search result called it buyable {k} times while its page said not - its search "
                f"result is not used for {SEARCH_DOUBT_FOR / 60:.0f} minutes.")


# ---------------------------------------------------------------- v96: Amazon's offers list (the panel behind "See all buying options")
# Diagnostics 77: 21 times a tracker reported the Amazon box in stock 1-4 minutes BEFORE Amazon's product page showed it to us (our page was
# read every ~3 s and showed a $749.99 reseller in the main box all that time; when it finally showed Amazon's own offer we saw it within
# 3 s - and it was gone). 7 more tracker alerts never showed on the page at all. Likely: Amazon's own offer is listed among the offers
# (where other buyers add it to their cart directly) before - or without - winning the main box. This reads that offers list now and
# then, INSTEAD of a product page (no extra requests to Amazon), and records what it shows next to what the product page shows. It buys
# nothing and changes nothing by itself: when Amazon's own offer at or under the cap is in the list while the page shows no buyable
# offer, that product simply gets more of the looks for a minute, and the moment is written to amazon_offers.csv and the diagnostics -
# the evidence for buying straight from the list (the next step, only if the evidence holds).
TURN_BACK_STORES = ("amazon",)   # v98: where a sweeper without a turn takes one back (see _each)
TURN_BACK_EVERY = 10.0
AOD_EVERY = 4              # one in this many of the Amazon sweeper's OWN rounds (not the other browsers') reads one offers list
AOD_REGULAR = False        # v105: the regular offers-list reads are off - ~930 of them (diagnostics 79-83) never showed Amazon's own offer;
                           # the sweeper's page looks are worth more. Kept: one offers-list read right after a tracker alert (the evidence).
AOD_URL = "https://www.amazon.com/gp/product/ajax/aodAjaxMain/?asin={asin}&pc=dp"
AOD_OFF_AFTER = 6          # unreadable / failed answers in a row -> the offers list is not read for AOD_OFF_FOR (logged)
AOD_OFF_FOR = 6 * 3600.0
AOD_HELPERS_MIN = 2        # the regular offers-list reads only while at least this many other browsers read Amazon's pages too
OFFERS_CSV = "amazon_offers.csv"
AOD = {"reads": 0, "readable": 0, "unreadable": 0, "failed": 0, "bad_row": 0, "off_until": 0.0, "amazon_seen": 0, "ahead": 0,
       "last": {}, "aheads": collections.deque(maxlen=40), "said_off": False, "csv_rows": 0, "poke_read": {}}
_AMZ_SELLER = re.compile(r"^amazon(\.com)?(\s+services\s+llc)?$", re.I)
_MONEY = re.compile(r"\$\s*([\d,]+\.\d\d)")


class _NoSoft:
    """The pace seen by an offers-list request: a refusal still counts for the sweeper (a refusal is a refusal), a failed or odd answer
    does not slow the product pages down (the offers list is an extra, and its answer is judged here)."""

    def __init__(self, pace):
        self.p = pace
        self.answered = False

    def note_request(self):
        self.p.note_request()

    def block(self, why):
        self.p.block(why)

    def soft(self, why):
        pass


def parse_aod(text):
    """Amazon's offers list -> {"ok", "offers": [{"seller", "ships", "price", "new", "pinned"}], "why"}. ok False = not an offers list
    (nothing is concluded from it)."""
    try:
        from bs4 import BeautifulSoup
        soup = BeautifulSoup(text or "", "html.parser")
    except Exception as e:
        return {"ok": False, "offers": [], "why": f"could not be read ({type(e).__name__})"}
    box = soup.find(id=re.compile(r"^(aod-container|all-offers-display|aod-offer-list|aod-pinned-offer)$"))
    els = soup.find_all(id=re.compile(r"^aod-(pinned-)?offer$"))
    if not box and not els:
        return {"ok": False, "offers": [], "why": "no offers list in the answer"}
    out = []
    for el in els:
        def txt(i):
            x = el.find(id=i)
            return re.sub(r"\s+", " ", x.get_text(" ")).strip() if x else ""
        seller = txt("aod-offer-soldBy")
        seller = re.sub(r"^sold by\s*:?\s*", "", seller, flags=re.I).strip()
        seller = re.split(r"\s{2,}|\(|\d+% positive|\bjust launched\b", seller)[0].strip()
        ships = re.sub(r"^ships from\s*:?\s*", "", txt("aod-offer-shipsFrom"), flags=re.I).strip()
        price = None
        pe = el.find(id="aod-offer-price") or el
        for sp in pe.select("span.a-price:not(.a-text-price) span.a-offscreen"):
            m = _MONEY.search(sp.get_text(" "))
            if m:
                price = float(m.group(1).replace(",", ""))
                break
        if price is None:
            w, f = pe.select_one("span.a-price-whole"), pe.select_one("span.a-price-fraction")
            if w:
                try:
                    price = float(re.sub(r"[^\d]", "", w.get_text()) + "." + (re.sub(r"[^\d]", "", f.get_text()) if f else "00")[:2])
                except Exception:
                    price = None
        head = txt("aod-offer-heading").lower()
        new = False if re.search(r"\bused\b|renewed|refurbished|collectible|open box", head) else (True if re.search(r"\bnew\b", head) else None)
        out.append({"seller": seller[:60], "ships": ships[:60], "price": price, "new": new, "pinned": el.get("id") == "aod-pinned-offer"})
    return {"ok": True, "offers": out, "why": ""}


def _aod_amazon(offers):
    """Amazon's own new offer in the list (sold by Amazon) -> its price (lowest), else None."""
    ps = [o["price"] for o in offers if _AMZ_SELLER.match(o.get("seller") or "") and o.get("new") is not False and o.get("price")]
    return min(ps) if ps else None


def _aod_due(st, rows):
    """-> the product whose offers list is read this round, or None (a product page is read as usual)."""
    if getattr(_TL, "ident", None) or st["store"] != "amazon" or os.environ.get("RK_NO_AOD") or time.time() < AOD["off_until"]:
        return None
    now = time.time()
    if (_ENGINE.get("view") or ({}, False, False))[2]:
        return None                              # (Amazon is slowing the buying browser's own checks down: no extras now)
    import amazon_buy
    cands = [t for t in rows if amazon_buy.asin_of(t.get("url")) and not _unreadable(st, t["id"]) and now >= _DEAD.get(t["id"], 0.0)]
    if not cands:
        return None
    # a tracker alerted for it a moment ago: its page was read first (that decides a purchase), its offers list right after
    for t in cands:
        pk = st.setdefault("tpoked", {}).get(t["id"], 0.0)
        if pk and now - pk < 120 and AOD["poke_read"].get(t["id"], 0.0) < pk and LAST_READ.get(t["id"], 0.0) >= pk:
            return t
    if not AOD_REGULAR or st["each_n"] % AOD_EVERY != 1:
        return None
    # only while at least AOD_HELPERS_MIN other browsers read Amazon's pages too: the sweeper alone gives none of its page looks away
    if helpers_off("amazon") or sum(1 for (s_, k_), r_ in list(_HELPERS.items()) if s_ == "amazon" and r_.get("running")) < AOD_HELPERS_MIN:
        return None
    return min(cands, key=lambda t: (AOD["last"].get(t["id"]) or {}).get("at", 0.0))


def _aod_round(st, t):
    import amazon_buy
    store = st["store"]
    asin = amazon_buy.asin_of(t.get("url"))
    if not _claim(store, t["id"]):
        return 0
    np_ = _NoSoft(st["pace"])
    try:
        text, why = _fetch(st, np_, AOD_URL.format(asin=asin), timeout=15.0)
    finally:
        _unclaim(store, t["id"])
    if np_.answered:
        st["pace"].answered = True              # (the store answered: this round counts as a good one for the pace)
    now = time.time()
    AOD["reads"] += 1
    AOD["poke_read"][t["id"]] = now
    res = parse_aod(text) if text else {"ok": False, "offers": [], "why": str(why)[:80]}
    if not res["ok"]:
        AOD["failed" if text is None else "unreadable"] += 1
        if text is not None:
            AOD["bad_row"] += 1                  # (only answers that are not an offers list: a request that failed fails for the pages too)
        if AOD["bad_row"] >= AOD_OFF_AFTER:
            AOD["off_until"] = now + AOD_OFF_FOR
            AOD["bad_row"] = 0
            log(f"Amazon offers list (v96): {AOD_OFF_AFTER} answers in a row could not be read ({res['why'][:80]}) - not read for "
                f"{AOD_OFF_FOR / 3600:.0f} hours (the product pages go on as before).")
        return 0
    AOD["bad_row"] = 0
    AOD["readable"] += 1
    offers = res["offers"]
    amz = _aod_amazon(offers)
    others = [o["price"] for o in offers if o.get("price") and o.get("new") is not False and not _AMZ_SELLER.match(o.get("seller") or "")]
    try:
        cap = float(t.get("max_price")) if t.get("max_price") not in (None, "") else None
    except Exception:
        cap = None
    try:
        page = (amazon_buy.STATUS(t["id"]) if amazon_buy.STATUS else None) or {}
    except Exception:
        page = {}
    pst, ppr = page.get("status"), page.get("price")
    prev = AOD["last"].get(t["id"]) or {}
    ahead = bool(amz is not None and (cap is None or amz <= cap) and not (pst == "IN_STOCK" and ppr is not None and abs(float(ppr) - amz) < 0.02))
    rec = {"at": now, "amazon": amz, "n": len(offers), "low_other": min(others) if others else None, "page": pst, "page_price": ppr,
           "ahead": ahead}
    AOD["last"][t["id"]] = rec
    if amz is not None:
        AOD["amazon_seen"] += 1
    if ahead:
        AOD["ahead"] += 1
        st["poked"][t["id"]] = now               # (more of the looks go to its page for a minute - no extra requests)
        _poke(store, t["id"])
        if not prev.get("ahead"):
            AOD["aheads"].append((now, t["id"], amz, pst, ppr))
            log(f"[offers] '{t['id']}': Amazon's OWN offer ${amz:.2f} is in Amazon's offers list while the product page shows "
                f"{(pst or 'no answer').replace('_', ' ').lower()}" + (f" at ${float(ppr):.2f}" if ppr is not None else "") +
                " - its page is looked at more often now; written to amazon_offers.csv (nothing is bought from the list).")
    if (amz is not None) != (prev.get("amazon") is not None) or ahead != bool(prev.get("ahead")) or not prev:
        _aod_csv(t["id"], rec)
    return 1


def _aod_csv(tid, rec):
    try:
        new = not os.path.exists(OFFERS_CSV)
        with open(OFFERS_CSV, "a", encoding="utf-8", newline="") as f:
            if new:
                f.write("timestamp_utc,target_id,amazon_offer_in_list,amazon_price,offers_in_list,lowest_other_price,page_status,page_price,"
                        "amazon_offer_not_on_page\n")
            ts = time.strftime("%Y-%m-%dT%H:%M:%S", time.gmtime(rec["at"])) + "+00:00"
            f.write(",".join(str(x) for x in (ts, tid, "yes" if rec["amazon"] is not None else "no", rec["amazon"] if rec["amazon"] is not None else "",
                                               rec["n"], rec["low_other"] if rec["low_other"] is not None else "", rec["page"] or "",
                                               rec["page_price"] if rec["page_price"] is not None else "", "yes" if rec["ahead"] else "no")) + "\n")
        AOD["csv_rows"] += 1
    except Exception:
        pass


def aod_text(gt_rows=None):
    """The diagnostics' lines about the offers list. gt_rows: ground_truth.csv rows (to tell how long after each moment the page showed it)."""
    now = time.time()
    out = [f"Amazon offers list (v96, v105: only right after a tracker alert - the regular reads are off): read {AOD['reads']}, "
           f"readable {AOD['readable']}, not an offers list {AOD['unreadable']}, failed {AOD['failed']}"
           + (f"; OFF for {(AOD['off_until'] - now) / 3600:.1f} h more (answers could not be read)" if AOD["off_until"] > now else "")
           + f"; Amazon's own offer in the list: {AOD['amazon_seen']} reads; of those NOT buyable on the product page at that moment: {AOD['ahead']}"]
    for tid, r in sorted(AOD["last"].items()):
        out.append(f"   {tid}: {int(now - r['at'])} s ago - {r['n']} offers, Amazon's own " + (f"${r['amazon']:.2f}" if r["amazon"] is not None else "not listed")
                   + (f", lowest other seller ${r['low_other']:.2f}" if r["low_other"] is not None else "") + f"; the product page then: {r['page'] or '-'}"
                   + (f" ${float(r['page_price']):.2f}" if r["page_price"] is not None else ""))
    if AOD["aheads"]:
        rs = {}
        for row in gt_rows or []:
            try:
                if len(row) >= 3 and row[2] == "RESTOCK":
                    import datetime as _dt
                    rs.setdefault(row[1], []).append(_dt.datetime.fromisoformat(row[0].replace("Z", "+00:00")).timestamp())
            except Exception:
                pass
        out.append("   moments Amazon's own offer was in the list but not buyable on the page (newest last; 'page showed it' = the next restock the program logged):")
        for at, tid, amz, pst, ppr in list(AOD["aheads"])[-15:]:
            nxt = [x for x in rs.get(tid, []) if at <= x <= at + 900]
            out.append(f"   {time.strftime('%m-%d %H:%M:%S', time.gmtime(at))} UTC {tid}: Amazon ${amz:.2f} in the list; page said {pst or '-'}"
                       + (f" ${float(ppr):.2f}" if ppr is not None else "") + "; " + (f"page showed it {int(nxt[0] - at)} s later" if nxt else "page did not show it within 15 min"))
    return "\n".join(out)


def _each_round(st, rows):
    st["each_n"] += 1
    if st["store"] == "amazon":
        _t = _aod_due(st, rows)
        if _t is not None:
            return _aod_round(st, _t)            # v96: this round reads one product's offers list instead of a page
    sq = st["sq"]
    every = SEARCH_EVERY
    covered = sq.get("covered") or set()
    if rows and len(covered) >= 0.5 * len(rows) and _search_trust(sq) >= 0.4:
        every = 2                                          # (its search pages show most of our products: every other round)
    elif _search_trust(sq) < 0.25:
        every = 5                                          # (its search pages were often wrong or late: rarely)
    if st["each_n"] % every == 0 and not os.environ.get("RK_NO_SEARCH_SWEEP") and time.time() >= st.get("search_off_until", 0.0):
        r = _search_round(st, rows)
        if r == -1:
            return None                  # (the search page was not answered: this round is over - no second request at once)
        if r is not None:
            return r
    return _each(st, rows)


_DO = {"bestbuy": _bestbuy, "target": _target, "gamestop": _gamestop, "walmart": _each_round, "amazon": _each_round}


def _note_title(t, title):
    try:
        import linkcheck
        linkcheck.note_title(t, title, LOG[0])
    except Exception:
        pass


# ================================================================ the sweeper of one store

def _state(store):
    start, floor, ceil = PRIORS[store]
    lr = _learned()
    if store == "walmart" and not lr.get("walmart:v83_reset"):
        # v83: Walmart's slow pace (one page per 120 s) was learned from refused SEARCH pages, not product pages: it starts fresh once
        lr["walmart:v83_reset"] = time.time()
        for k_ in ("walmart", "walmart:2"):
            lr.pop(k_, None)
        _save_soon()
    _bad = float(lr.get(store + ":lanes_bad_until") or 0.0)
    return {"store": store, "mode": MODES[store], "pace": Pace(store, "main", start, floor, ceil, lr.get(store)),
            "pace2": Pace(store, "product pages" if store == "gamestop" else "single products", *PRIORS2, learned=lr.get(store + ":2")),
            "running": False, "reader": False, "reader_lost": 0.0, "started": time.time(), "rounds": 0, "requests": 0, "answers": 0,
            "gap": {}, "answered": {}, "unread": {}, "poked": {}, "poke_seen": {}, "named": {}, "eng_seen": {},
            "missing": [], "miss_next": {}, "miss_n": {}, "confirm": {"asked": 0, "agreed": 0, "disagreed": 0, "failed": 0},
            "unconfirmed": {}, "doubt": {}, "doubt_next": {}, "tile": {}, "agree_run": {}, "audit_at": 0.0, "audit_i": -1,
            "audits": {"n": 0, "disagreed": 0}, "events": collections.deque(maxlen=10), "ship_checks": 0, "busy_since": 0.0,
            "busy_n": 0, "round_ema": None, "said": False, "absent": {}, "said_dead": set(), "each_n": 0, "search_check": {}, "lane_pick_by": {},
            "lanes_bad_until": _bad, "search_off_until": float(lr.get(store + ":search_off_until") or 0.0),
            "sq": {"tried": {}, "found_at": time.time(), "cover": {}, "last": {}, "seen": {}, "doubt": {}, "wrong": {}, "n": 0, "triggers": 0,
                   "confirmed": 0, "false": 0, "late": 0, "chosen": [], "covered": set()}, "last_page": {}}


def _pokes(st, rows):
    """A tracker just alerted for a product of this store -> True (the sweeper reads at once instead of waiting out its pace)."""
    try:
        import hotness
        hit = False
        seen = st["poke_seen"]
        for t in rows:
            p = hotness.poked_since(t["id"], seen.get(t["id"], 0.0))
            if p:
                seen[t["id"]] = p
                st["poked"][t["id"]] = time.time()
                st.setdefault("tpoked", {})[t["id"]] = time.time()       # v96: a TRACKER alerted (its offers list is read right after its page)
                hit = True
        return hit
    except Exception:
        return False


def _run(store, stop_event):
    import amazon_buy
    st = _S[store]
    pace = st["pace"]
    st["running"] = True
    try:
        while not (stop_event is not None and stop_event.is_set()):
            ok_reader = amazon_buy.reader_ok(store)          # v65: the store reader's OWN browser (not the buying browser)
            if not ok_reader:
                if st["reader"]:
                    st["reader"] = False
                    st["reader_lost"] = time.time()
                time.sleep(1.0)
                continue
            st["reader"] = True
            busy = _busy_stores()
            if busy and store in busy:          # v86: only a checkout at THIS store pauses its readers (a Target page check no longer stops the Amazon readers)
                if not st["busy_since"]:
                    st["busy_since"] = time.time()
                    st["busy_n"] += 1
                    if not _pause_for_checkout(store):
                        st["busy_kept"] = st.get("busy_kept", 0) + 1
                if _pause_for_checkout(store) and time.time() - st["busy_since"] < _pause_max():
                    time.sleep(0.3)
                    continue                     # a checkout has priority (at most BUSY_MAX)
            else:
                st["busy_since"] = 0.0
            rows = _rows(store)
            if not rows:
                time.sleep(2.0)
                continue
            if not pace.take(stop_event, wake=lambda: _pokes(st, rows)):
                return
            if not pace.woke:
                # v108: a tracker alert is also noticed when the look was due anyway. Diagnostics 87: Amazon is read at its fastest
                # pace, so the wait never ran the check above - the offers-list read right after a tracker alert never happened.
                _pokes(st, rows)
            if not _spread(store, pace, stop_event):
                return
            t0 = time.time()
            pace.answered = False
            try:
                n = _DO[store](st, rows)
            except Exception as e:
                n = None
                pace.soft(f"{type(e).__name__}: {str(e)[:120]}")
            st["rounds"] += 1
            _save_now()
            if store == "amazon":
                # the buying engine's own checks a minute: those seen (a lower bound - two checks between two looks count once), and at
                # least 4 a minute per product it watches (its own budget allows 18 a minute)
                cat_, gm_, _sl = _ENGINE.get("view") or ({}, False, False)
                watched = len([1 for p_ in cat_.values() if p_.get("monitor")]) if gm_ else 0
                eng = max(len(st.get("eng_checks") or ()), min(18, 4 * watched))
                st["eng_rate"] = eng
                if eng:
                    # the buying browser checks Shopping products itself: the sweeper keeps the total under AMAZON_TOTAL a minute
                    pace.next_at = max(pace.next_at, t0 + 60.0 / max(3, AMAZON_TOTAL - eng))
            if n is not None:
                if pace.answered:
                    pace.ok()                    # (the store answered this round - also when no product changed hands)
                    if not st.get("ok_since") or st["ok_since"] < pace.last_block:
                        st["ok_since"] = time.time()
                dt = time.time() - t0
                st["round_ema"] = dt if st["round_ema"] is None else 0.9 * st["round_ema"] + 0.1 * dt
                if n > 0 and not st["said"]:
                    st["said"] = True
                    log(f"{NAMES[store]}: reading through the store reader's own browser - " + (
                        f"all {n} products with one request every {pace.interval:.1f} s" if st["mode"] == "batch" else
                        f"one product page every {pace.interval:.1f} s (the most overdue first; Shopping products kept freshest)") +
                        ". The other browsers of this store only fill in.")
    finally:
        st["running"] = False


# ================================================================ v81: more eyes on each store - the other buying browsers read too
# (owner 2026-10-30: "significantly decrease our latency ... relatively instantaneous for detecting an actual restock event in real time")
# Each store's sweeper reads all its products with one request at a time at the pace the store allows ONE visitor. The other buying
# browsers (Chrome, Edge, Hidden Chrome, Firefox, Camoufox - each its own visitor with its own cookies) sit idle between checkouts; each
# now also reads the store's data at its OWN pace (learned and kept like the sweeper's), so the store is looked at several times as
# often. Diagnostics 67 showed Target refusing the reader browser 63 times in 256 requests while your Chrome read Target 468 times
# without one refusal: the stores count per visitor, not per PC. Where a store does count the PC (two different browsers refused
# within 10 minutes), the helpers stop at that store for 6 hours by themselves. A checkout always goes first (the browser's job queue).
HELPER_STORES = ("bestbuy", "gamestop", "amazon")
# v83 (diagnostics 68, a day of v81): Best Buy, GameStop and Amazon answered the other browsers (Best Buy 100,000+ answers, 0 refused);
# Target refused every one of them at the first request and Walmart started blocking - those two judge the whole PC (its internet
# address), so more browsers only spend the PC's allowance there. The helpers no longer read Target and Walmart at all.
HELPER_START_X = 2.0        # (x/2) of the store's first pace: where a helper starts; it gets quicker with good answers, slower after a refusal
HELPER_FIRST = {"amazon": 15.0}       # (Amazon is the strictest: its helpers start gently)
HELPER_WINDOW = 600.0
HELPER_OFF_FOR = 6 * 3600.0
_TL = threading.local()
_HELPERS = {}               # (store, kind) -> {"th", "pace", "stop", "rounds", "since"}
_HSTATE = {}                # store -> {"off_until", "why", "refusals": deque[(time, who)]}
_HMGR = {"th": None}


def _hs(store):
    h = _HSTATE.get(store)
    if h is None:
        h = _HSTATE[store] = {"off_until": float(_learned().get(store + ":helpers_off") or 0.0), "why": "", "refusals": collections.deque(maxlen=50)}
    return h


def helpers_off(store):
    return _hs(store)["off_until"] > time.time() or bool(os.environ.get("RK_NO_HELPERS"))


HELPER_BAD_MIN = 6          # helper refusals in HELPER_WINDOW ...
HELPER_BAD_SHARE = 0.30     # ... that are this share (or more) of the helpers' requests there -> the store counts the PC's visits together


def _note_outcome(store, who, refused):
    """Every answered / refused request (reader and helpers), for the store-wide check below."""
    h = _hs(store)
    h.setdefault("log", collections.deque(maxlen=400)).append((time.time(), who, bool(refused)))


def _note_refusal(store, who, why=""):
    """v81: each helper learns its own pace from its own refusals (a few while it finds its pace are normal). When the helpers together are
    refused often - HELPER_BAD_MIN or more in HELPER_WINDOW and at least HELPER_BAD_SHARE of their requests there - the store counts this
    PC's visits together, not each visitor: the helpers stop at that store for HELPER_OFF_FOR (the sweeper goes on alone)."""
    h = _hs(store)
    now = time.time()
    h["refusals"].append((now, who))
    if who == "reader" or h["off_until"] > now:
        return
    lg = [x for x in h.get("log", ()) if now - x[0] < HELPER_WINDOW and x[1] != "reader"]
    bad = [x for x in lg if x[2]]
    if len(bad) >= HELPER_BAD_MIN and len(bad) >= HELPER_BAD_SHARE * len(lg):
        h["off_until"] = now + HELPER_OFF_FOR
        h["why"] = f"{len(bad)} of their {len(lg)} requests refused in {HELPER_WINDOW / 60:.0f} min ({str(why)[:60]})"
        log(f"{NAMES.get(store, store)}: the other browsers were refused {len(bad)} times in {len(lg)} requests within {HELPER_WINDOW / 60:.0f} minutes - this "
            f"store counts the PC's visits together, so they stop reading it for {HELPER_OFF_FOR / 3600:.0f} hours (the sweeper goes on alone).")
        _save_soon()


class _View:
    """A store's sweeper state for a helper thread: everything shared with the sweeper, except its own pace."""

    def __init__(self, base, pace):
        self.b, self.o = base, {"pace": pace}

    def __getitem__(self, k):
        return self.o[k] if k in self.o else self.b[k]

    def __setitem__(self, k, v):
        (self.o if k in self.o else self.b)[k] = v

    def get(self, k, d=None):
        return self.o[k] if k in self.o else self.b.get(k, d)

    def setdefault(self, k, d=None):
        return self.b.setdefault(k, d)

    def __contains__(self, k):
        return k in self.o or k in self.b


def _helper_run(store, kind, stop_event, hrec):
    import multibuy
    _WHO.name = multibuy.NAMES.get(kind, kind)
    st = _S[store]
    start_, floor_, ceil_ = PRIORS[store]
    # (each helper is its own visitor: it starts at the store's first pace - not at the reader browser's slowed one - and learns its own)
    pace = Pace(store, multibuy.NAMES.get(kind, kind), max(floor_, HELPER_FIRST.get(store, start_ * (HELPER_START_X / 2.0))), floor_, ceil_,
                _learned().get(f"{store}:id:{kind}"))
    hrec["pace"] = pace
    view = _View(st, pace)
    _TL.ident = kind
    try:
        while not (stop_event is not None and stop_event.is_set()) and not hrec["stop"].is_set():
            if helpers_off(store) or not st.get("running"):
                return
            if MODES[store] == "each" and st.get("lanes_bad_until", 0) > time.time():
                return                               # (that store counts the PC's visits together - see LANES_BAD_FOR)
            if kind not in multibuy.fetch_kinds(store):
                time.sleep(0.5)                      # (checking out / waiting for your sign-in / resting at that store after a block)
                continue
            busy = _busy_stores()
            if busy and store in busy and _pause_for_checkout(store):   # v92: Amazon / Best Buy / Walmart keep looking during a checkout
                time.sleep(0.3)
                continue                             # a checkout has priority
            rows = _rows(store)
            if not rows:
                time.sleep(2.0)
                continue
            if not pace.take(stop_event):
                return
            if not _spread(store, pace, stop_event):
                return
            pace.answered = False
            try:
                n = _DO[store](view, rows)
            except Exception as e:
                n = None
                pace.soft(f"{type(e).__name__}: {str(e)[:120]}")
            hrec["rounds"] += 1
            if n is not None and pace.answered:
                pace.ok()
                hrec["ok"] += 1
    finally:
        hrec["running"] = False


def _helpers_loop(stop_event):
    import multibuy
    said = set()
    while not (stop_event is not None and stop_event.is_set()):
        try:
            with multibuy._lock:
                kinds = [k for k, w in multibuy._workers.items() if w.state in ("ready",) and w.ctx is not None]
            for store in HELPER_STORES:
                st = _S.get(store)
                if not st or not st.get("running") or store not in getattr(multibuy, "READ_ORIGINS", multibuy.STORES):
                    continue
                if helpers_off(store):
                    for (s_, k_), r in list(_HELPERS.items()):
                        if s_ == store:
                            r["stop"].set()
                    continue
                for k in kinds:
                    r = _HELPERS.get((store, k))
                    if r and r["running"]:
                        continue
                    r = {"stop": threading.Event(), "rounds": 0, "ok": 0, "since": time.time(), "running": True, "pace": None}
                    r["th"] = threading.Thread(target=_helper_run, args=(store, k, stop_event, r), daemon=True, name=f"sweep-{store}-{k}")
                    _HELPERS[(store, k)] = r
                    r["th"].start()
                    if (store, k) not in said:
                        said.add((store, k))
                        log(f"{NAMES.get(store, store)}: {multibuy.NAMES.get(k, k)} reads this store too (its own visitor, its own pace; a checkout always goes first).")
        except Exception as e:
            log(f"[sweep] helpers: {str(e)[:120]}")
        time.sleep(5.0)


def helpers_text(store):
    h = _hs(store)
    now = time.time()
    parts = []
    for (s_, k), r in sorted(_HELPERS.items()):
        if s_ != store or not r.get("pace"):
            continue
        p = r["pace"]
        parts.append(f"{p.name} every {p.interval:.1f} s ({p.ok_n} good, {p.blocks} refused{', running' if r['running'] else ', stopped'})")
    off = f" - OFF for {(h['off_until'] - now) / 3600:.1f} h more ({h['why']})" if h["off_until"] > now else ""
    return ("other browsers reading too: " + ("; ".join(parts) if parts else "none (yet)") + off) if (parts or off) else ""


def start(stores, stop_event, log_fn=None):
    """Starts a sweeper for each store that has one."""
    if log_fn:
        LOG[0] = log_fn
    for s in stores:
        if not enabled_for(s):
            continue
        th, old_stop = _THREADS.get(s) or (None, None)
        if th and th.is_alive():
            if old_stop is stop_event:
                continue                          # (already running for this watching)
            th.join(5.0)                          # (the sweeper of the watching before ends within a second of its Stop)
        _save_now(force=True)
        _S[s] = _state(s)
        th = threading.Thread(target=_run, args=(s, stop_event), daemon=True, name=f"sweep-{s}")
        _THREADS[s] = (th, stop_event)
        th.start()
    if not os.environ.get("RK_NO_HELPERS") and (_HMGR["th"] is None or not _HMGR["th"].is_alive() or _HMGR.get("stop") is not stop_event):
        _HMGR["stop"] = stop_event
        _HMGR["th"] = threading.Thread(target=_helpers_loop, args=(stop_event,), daemon=True, name="sweep-helpers")
        _HMGR["th"].start()


# ================================================================ what the diagnostics show

def _pct(vals, q):
    if not vals:
        return None
    v = sorted(vals)
    return v[min(len(v) - 1, int(round(q * (len(v) - 1))))]


def store_report(store):
    st = _S.get(store)
    if not st:
        return None
    now = time.time()
    rows = _rows(store)
    p = st["pace"]
    ages = [now - FRESH[t["id"]]["at"] for t in rows if t["id"] in FRESH]
    gaps = [st["gap"][t["id"]] for t in rows if t["id"] in st["gap"]]
    return {"store": store, "mode": st["mode"], "state": state(store), "interval": p.interval, "safe": p.safe, "last_block": p.last_block, "requests": st["requests"],
            "ok": p.ok_n, "soft": p.soft_n, "blocks": p.blocks, "per_min": p.per_minute(), "resting": max(0.0, p.rest_until - now),
            "last_why": p.last_why, "products": len(rows), "owned": len([t for t in rows if owns(t)]), "with_answer": len(ages),
            "age_mid": _pct(ages, 0.5), "age_90": _pct(ages, 0.9), "age_worst": max(ages) if ages else None,
            "gap_avg": (sum(gaps) / len(gaps)) if gaps else None, "gap_worst": max(gaps) if gaps else None,
            "round_s": st["round_ema"], "rounds": st["rounds"], "busy_n": st["busy_n"], "busy_kept": st.get("busy_kept", 0),
            "p2": {"interval": st["pace2"].interval, "requests": st["pace2"].requests, "ok": st["pace2"].ok_n, "blocks": st["pace2"].blocks,
                   "soft": st["pace2"].soft_n},
            "confirm": dict(st["confirm"]), "audits": dict(st["audits"]), "doubt": [k for k, v in st["doubt"].items() if v > now],
            "missing": list(st.get("missing") or [])[:10], "unread": [k for k, v in st["unread"].items() if v[1] and v[1] > now],
            "search": {"n": st["sq"]["n"], "triggers": st["sq"]["triggers"], "confirmed": st["sq"]["confirmed"], "false": st["sq"]["false"],
                       "late": st["sq"]["late"], "trust": _search_trust(st["sq"]), "covered": len(st["sq"].get("covered") or ()),
                       "active": {th: len(st["sq"]["cover"].get(th, ())) for th in st["sq"].get("chosen") or []}, "tried": len(st["sq"]["tried"])},
            "search_off": max(0.0, st.get("search_off_until", 0.0) - now), "bb_hints": list(st.get("bb_hints") or ()),
            "ship_checks": st["ship_checks"], "events": list(p.events)[-5:] + list(st["pace2"].events)[-3:] + list(st["events"])[-5:]}


def summary():
    return {s: store_report(s) for s in sorted(_S)}


# ---- v100 (owner 2026-11-05: a store health strip "only if the store problem is noticed consistent across all products. I don't want to
# show slowed for only a single product this way if all other products load fine"): one word per STORE, never per product
STALL_MIN = 120.0          # every product of the store unanswered this long (and 3 of its normal looks) = stalled


def health(store, now=None):
    """-> {"state": ok | slowed | stalled | off, "text": plain words}. A store is "stalled" only when NONE of its products has a fresh
    answer from any browser; "slowed" only when the store itself refused faster reads (it then reads every product slower)."""
    now = now or time.time()
    st = _S.get(store)
    if not st or not st.get("running"):
        return {"state": "off", "text": "not watching"}
    rows = [t for t in _rows(store) if t.get("id")]
    if not rows:
        return {"state": "off", "text": "no products watched here"}
    p = st["pace"]
    normal = max(p.interval, p.floor) * max(1, len(rows) if st["mode"] == "each" else 1)
    ages = []
    for t in rows:
        f = FRESH.get(t["id"]) or {}
        last = max(float(f.get("at") or 0.0), ANSWERED.get(t["id"], 0.0))     # (real answers only - not a read that was only begun)
        ages.append(now - last if last else 1e9)
    newest = min(ages)
    started = st.get("started") or now
    if newest > max(STALL_MIN, 3 * normal) and now - started > max(STALL_MIN, 3 * normal):
        return {"state": "stalled", "text": f"no product read for {int(min(newest, now - started) // 60)} min", "age": newest}
    if p.resting(now) or (p.safe and p.safe > p.floor * 1.5):
        return {"state": "slowed", "text": f"the store refused faster reads - one look every {p.interval:.0f} s for now"}
    return {"state": "ok", "text": f"reading (each product every ~{normal:.0f} s)" if normal >= 1 else "reading"}


def report_text():
    if not _S:
        return "not started (it starts with the watching; it reads through the store reader's own browser)"
    f = lambda x: ("%.1f s" % x) if isinstance(x, (int, float)) else "-"
    out = []
    for s in sorted(_S):
        r = store_report(s)
        if not r:
            continue
        word = {"ok": "WORKING", "starting": "starting", "resting": "RESTING after a refusal", "failing": "NOT working right now",
                "off": "off (the reader browser is not there; the store's own browsers read)"}[r["state"]]
        out.append(f"{NAMES.get(s, s)}: {word} ({'all products per request' if r['mode'] == 'batch' else 'one product page per request'}); "
                   f"one request every {r['interval']:.1f} s" + (f" (no faster than {r['safe']:.1f} s for now - it was refused faster"
                                                     + (f", last refused {time.strftime('%m-%d %H:%M', time.localtime(r['last_block']))}" if r.get("last_block") else "")
                                                     + "; 10 % quicker after each 30 minutes without a refusal)" if r["safe"] else "") +
                   f"; {r['per_min']} requests in the last minute; {r['requests']} in all: {r['ok']} good rounds, {r['soft']} slow/failed, "
                   f"{r['blocks']} refused" + (f"; resting {r['resting']:.0f} s more" if r["resting"] else "") +
                   (f"; last problem: {r['last_why'][:100]}" if r["last_why"] else ""))
        out.append(f"   {r['with_answer']} of {r['products']} products have an answer ({r['owned']} left to the sweeper alone); time between two answers "
                   f"for one product: average {f(r['gap_avg'])}, slowest {f(r['gap_worst'])}; age of the answers now: middle {f(r['age_mid'])}, "
                   f"90 % under {f(r['age_90'])}, oldest {f(r['age_worst'])}; one round takes {f(r['round_s'])}")
        if s == "gamestop":
            c, a = r["confirm"], r["audits"]
            out.append(f"   turning available in the tile data, checked on the product page: {c['asked']} (agreed {c['agreed']}, page said not {c['disagreed']}, "
                       f"page unreadable {c['failed']}); pages compared with the tile data: {a['n']} (disagreed {a['disagreed']}); read by their page now: "
                       f"{', '.join(r['doubt']) or 'none'}; product pages: {r['p2']['requests']} requests, {r['p2']['blocks']} refused")
        if s == "amazon":
            st_ = _S.get(s) or {}
            out.append(f"   the buying browser's own checks of Shopping products (they buy), a minute: about {st_.get('eng_rate', 0)}; "
                       f"the sweeper keeps both together under {AMAZON_TOTAL} a minute")
        if s == "bestbuy" and r["ship_checks"]:
            out.append(f"   'Add to cart' products checked on their page (can they be shipped?): {r['ship_checks']}")
        if r["missing"]:
            out.append(f"   not in the all-products answer (asked for one by one, gently): {', '.join(r['missing'])}; single requests "
                       f"{r['p2']['requests']}, {r['p2']['blocks']} refused")
        if r["mode"] == "each":
            q = r["search"]
            act = q["active"]
            out.append(f"   its search pages as an early signal: {q['n']} read; the searches used ({q['covered']} of our products shown): "
                       + (", ".join(f"'{th}' ({n})" for th, n in sorted(act.items(), key=lambda x: -x[1])) or "none (yet)")
                       + f"; products shown buyable there -> their page read at once: {q['triggers']} (page agreed {q['confirmed']}, page said not {q['false']}); "
                       f"restocks only their page found (the search was late): {q['late']}; relied on: {q['trust'] * 100:.0f} %"
                       + (f"; STOPPED for {r['search_off'] / 3600:.1f} h more (the store refused a search page; product pages go on)" if r.get("search_off") else ""))
        if r.get("bb_hints"):
            out.append("   data changed from sold out to a waiting word -> buying browser told (v83): " + "; ".join(r["bb_hints"]))
        if r["unread"]:
            out.append(f"   pages without the stock (read by the other browsers for now): {', '.join(r['unread'])}")
        _st0 = _S.get(s) or {}
        if _st0.get("no_turn") or _st0.get("turn_back"):
            out.append(f"   rounds with every product being read by the program's own readers (no turn): {_st0.get('no_turn', 0)}; "
                       f"turns taken back (v98): {_st0.get('turn_back', 0)}")
        if r["busy_n"]:
            out.append(f"   checkouts here: {r['busy_n']} (v92: kept looking during {r.get('busy_kept', 0)} of them)")
        ht = helpers_text(s)
        if ht:
            out.append("   " + ht)
        sp = spread_text(s)
        if sp:
            out.append("   " + sp)
        for e in r["events"]:
            out.append("   " + e)
    try:
        import predict
        out.append(predict.report_text())
    except Exception as e:
        out.append(f"restock predictor: not available ({str(e)[:80]})")
    return "\n".join(out)
