"""When each set comes out (US release) - for ordering the Products table, newest / upcoming on top (v118).

Owner 2026-11-13: "I would like the program to automatically group the currently available products by year as we hit december 1 of each
year. Similarly, for new products that are added, (and for existing watched products) they should be organized on the page by date of
release, with the most recent date (or future date) on top and the oldest release date on the bottom".

Where the dates come from, in this order:
  1. Scryfall's public list of every Magic set (api.scryfall.com/sets - free, no account; read once a day in the background, kept in
     set_dates.json). It knows upcoming sets months ahead, so a product you add later is dated by itself.
  2. The dates below (checked 2026-11-13), for when Scryfall cannot be reached or names a set differently.
  3. Only the year (matrix.RELEASE_YEAR) - dated July 1 of that year.
  A product with no date at all (card sleeves, a misspelled set...) goes under "Other products", last.
Nothing here is bought or changed: it only decides the order and the groups of the table.
"""
import json
import os
import re
import threading
import time
import urllib.request
from datetime import date, datetime

VERSION = "v119"
CACHE = "set_dates.json"
SCRYFALL = "https://api.scryfall.com/sets"
EVERY = 24 * 3600
MAIN_TYPES = ("expansion", "core", "masters", "draft_innovation", "funny", "starter", "commander", "box", "arsenal", "from_the_vault",
              "spellbook", "premium_deck", "duel_deck", "planechase", "archenemy", "vanguard", "treasure_chest", "alchemy", "masterpiece")
# (checked 2026-11-13: Wargamer's release schedule, mtg.wiki; the 2023-2025 dates are the sets' US release days)
SEED = {
    "zhalfir": "2027-10-01", "kamigawa titanbreach": "2027-06-04", "marvel darkhold destiny": "2027-04-09", "nauctis the sunken realm": "2027-02-05",
    "nauctis": "2027-02-05",
    "star trek": "2026-11-13", "mystery booster commander edition": "2026-11-13", "reality fracture": "2026-10-02", "the hobbit": "2026-08-14",
    "marvel super heroes": "2026-06-26", "marvel superheroes": "2026-06-26", "secrets of strixhaven": "2026-04-24",
    "teenage mutant ninja turtles": "2026-03-06", "lorwyn eclipsed": "2026-01-23",
    "avatar the last airbender": "2025-11-21", "marvel's spider-man": "2025-09-26", "spider-man": "2025-09-26", "marvels spider-man": "2025-09-26",
    "edge of eternities": "2025-08-01", "final fantasy": "2025-06-13", "tarkir dragonstorm": "2025-04-11", "aetherdrift": "2025-02-14",
    "innistrad remastered": "2025-01-24",
    "foundations": "2024-11-15", "duskmourn": "2024-09-27", "duskmourn house of horror": "2024-09-27", "bloomburrow": "2024-08-02",
    "assassin's creed": "2024-07-05", "modern horizons 3": "2024-06-14", "outlaws of thunder junction": "2024-04-19", "fallout": "2024-03-08",
    "murders at karlov manor": "2024-02-09", "ravnica remastered": "2024-01-12",
    "the lost caverns of ixalan": "2023-11-17", "lost caverns of ixalan": "2023-11-17", "doctor who": "2023-10-13", "wilds of eldraine": "2023-09-08",
    "commander masters": "2023-08-04", "the lord of the rings tales of middle-earth": "2023-06-23", "lord of the rings tales of middle-earth": "2023-06-23",
    "march of the machine": "2023-04-21", "phyrexia all will be one": "2023-02-10", "dominaria remastered": "2023-01-13",
}
_lock = threading.Lock()
_st = {"sets": None, "fetched": 0.0, "error": "", "started": False}
LOG = None


def norm(name):
    """'The Lord of the Rings: Tales of Middle-earth' -> 'lord of the rings tales of middle earth' (one spelling for comparing)."""
    s = str(name or "").lower().replace("&", " and ")
    s = re.sub(r"magic(:)? the gathering", " ", s)
    s = re.sub(r"[^a-z0-9]+", " ", s).strip()
    s = re.sub(r"^the ", "", s)
    return re.sub(r"\s+", " ", s)


def _load():
    if _st["sets"] is None:
        try:
            d = json.load(open(CACHE, encoding="utf-8"))
            _st["sets"] = dict(d.get("sets") or {})
            _st["fetched"] = float(d.get("fetched") or 0)
        except Exception:
            _st["sets"] = {}
    return _st["sets"]


def parse_scryfall(data):
    """Scryfall's set list -> {normalized name: earliest release date 'YYYY-MM-DD'} (main set kinds only; tokens, promos, art cards... left out)."""
    out = {}
    for s in (data or {}).get("data") or []:
        try:
            if s.get("set_type") not in MAIN_TYPES or s.get("digital"):
                continue
            d = str(s.get("released_at") or "")
            if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", d):
                continue
            k = norm(s.get("name"))
            if k and (k not in out or d < out[k]):
                out[k] = d
        except Exception:
            continue
    return out


def refresh(force=False, fetch=None):
    """Reads Scryfall's set list (at most once a day). fetch: url -> parsed JSON (for tests)."""
    _load()
    if not force and time.time() - _st["fetched"] < EVERY:
        return False
    _st["fetched"] = time.time()
    try:
        if fetch:
            data = fetch(SCRYFALL)
        else:
            req = urllib.request.Request(SCRYFALL, headers={"User-Agent": "Restalker/" + VERSION, "Accept": "application/json"})
            with urllib.request.urlopen(req, timeout=30) as r:
                data = json.loads(r.read().decode("utf-8"))
        sets = parse_scryfall(data)
        if len(sets) < 50:
            raise ValueError(f"only {len(sets)} sets in the answer")
        with _lock:
            _st["sets"] = sets
            _st["error"] = ""
        tmp = CACHE + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump({"fetched": _st["fetched"], "sets": sets}, f)
        os.replace(tmp, CACHE)
        return True
    except Exception as e:
        _st["error"] = str(e)[:120]
        return False


def _loop():
    time.sleep(20)
    while True:
        try:
            if refresh() and LOG:
                LOG(f"[release dates] read {len(_st['sets'] or {})} Magic set release dates from Scryfall (the table is ordered by them)")
        except Exception:
            pass
        time.sleep(3600)


def start(log=None):
    global LOG
    LOG = log
    if not _st["started"]:
        _st["started"] = True
        threading.Thread(target=_loop, daemon=True, name="release-dates").start()


def _as_date(s):
    try:
        return datetime.strptime(str(s), "%Y-%m-%d").date()
    except Exception:
        return None


def date_of(theme, years=None):
    """The release date of a set (its table name, e.g. 'the hobbit') -> (date, how) or (None, ''). how: scryfall / known / year."""
    k = norm(theme)
    if not k:
        return None, ""
    sets = _load()
    if k in sets:
        return _as_date(sets[k]), "scryfall"
    for raw, d in SEED.items():
        if norm(raw) == k:
            return _as_date(d), "known"
    # a table name a little longer or shorter than the set's name ('marvel spider man' / 'marvels spider man')
    for name, d in sets.items():
        if len(k) >= 6 and len(name) >= 6 and (name == k or name.endswith(" " + k) or k.endswith(" " + name)):
            return _as_date(d), "scryfall"
    for name, y in (years or {}).items():
        if norm(name) == k:
            return date(int(y), 7, 1), "year"
    return None, ""


def season_start(today=None):
    """The day the current year of releases began: December 1 (a year's sets are folded into 'Released YYYY' on the next Dec 1)."""
    t = today or date.today()
    return date(t.year if t.month == 12 else t.year - 1, 12, 1)


def status():
    _load()
    n = len(_st["sets"] or {})
    when = time.strftime("%Y-%m-%d %H:%M", time.localtime(_st["fetched"])) if _st["fetched"] else "never"
    return f"release dates (v118): {n} sets known from Scryfall (last read {when})" + (f"; last error: {_st['error']}" if _st["error"] else "")
