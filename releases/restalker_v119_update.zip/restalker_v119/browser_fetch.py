"""
Headless-browser fetching — an automatic fallback for sites that block
plain HTTP requests but tolerate a real browser hitting the same URL at
the same frequency.

Why this sometimes works when raw requests don't: a bare HTTP client has
a distinctive fingerprint at the network level (TLS handshake details,
missing JS execution, no browser-only headers/ordering) that many bot
defenses key on specifically — separate from how *often* the requests
arrive. A real, real browser engine closes much of that gap.

This is NOT a guarantee. The most sophisticated bot-defense systems
(the tier Amazon and Best Buy specifically use) are built to detect
headless automation too, so this raises the ceiling, it doesn't remove
it — some sites will still block this exactly as they block plain
requests, and that's a real limit of any free, self-hosted approach.

One-time setup (only needed if you actually hit a site that requires
this fallback — most won't):
    pip install playwright --break-system-packages
    playwright install chromium
"""
import json
import os
import re
import threading
import time
VERSION = "v119"   # checked by app.py so a half-copied update is caught immediately


# ---- v38: one Playwright driver per thread, shared by every browser that thread opens (Playwright refuses a second one in the same thread:
# "using Playwright Sync API inside the asyncio loop"). A store's checker now keeps several browsers (Chrome, Edge, Camoufox, built-in) ready.
_PW_LOCAL = threading.local()



def _refusal_page(html):
    """v64: a short page asking to prove one is human is a refusal, not a page that 'did not load': it is handed on as it is, so the
    checker recognises it (and slows down / stops its other readers) instead of switching browsers and asking again."""
    try:
        import stock_detect
        return bool(stock_detect.human_check_reason(html))
    except Exception:
        return False


def shared_playwright():
    from playwright.sync_api import sync_playwright
    pw = getattr(_PW_LOCAL, "pw", None)
    if pw is None:
        pw = sync_playwright().start()
        _PW_LOCAL.pw = pw
        _PW_LOCAL.users = 0
    _PW_LOCAL.users += 1
    return pw


def release_playwright(pw):
    """One browser is done with the driver; it is stopped when the last one lets go."""
    if pw is None:
        return
    if getattr(_PW_LOCAL, "pw", None) is pw:
        _PW_LOCAL.users = max(0, getattr(_PW_LOCAL, "users", 1) - 1)
        if _PW_LOCAL.users > 0:
            return
        _PW_LOCAL.pw = None
    try:
        pw.stop()
    except Exception:
        pass


PLAYWRIGHT_NOT_INSTALLED = "PLAYWRIGHT_NOT_INSTALLED"


# Pictures, fonts, style sheets, video and ad/tracking scripts are what makes a browser
# work hard (and slows the PC). The stock text does not need any of them, so the
# program's own browsers refuse them. If a store stops answering that way, the
# browser-switch step turns this off for that store (full pages again).
_BLOCK_TYPES = {"image", "media", "font", "stylesheet", "imageset"}
_BLOCK_HOSTS = ("doubleclick", "googlesyndication", "google-analytics", "googletagmanager", "facebook.net",
                "facebook.com/tr", "amazon-adsystem", "criteo", "taboola", "outbrain", "hotjar", "fullstory",
                "scorecardresearch", "quantserve", "tiktok", "pinterest", "snapchat", "clarity.ms", "newrelic",
                "nr-data.net", "segment.io", "segment.com", "optimizely", "branch.io", "adsrvr", "adnxs",
                "bing.com/bat", "youtube.com", "yimg.com")


# ---- the recorder hooks (see recon.py): used only when a product page is due to be recorded ----
def _recon_prepare(fx, url):
    fx._recon = False
    fx.recon_resps = []
    try:
        import recon
        fx._recon = bool(recon.want(url))
    except Exception:
        fx._recon = False


def _recon_note(fx, r):
    try:
        if getattr(fx, "_recon", False) and len(fx.recon_resps) < 250 \
                and r.request.resource_type in ("xhr", "fetch", "document"):
            fx.recon_resps.append(r)
    except Exception:
        pass


def _recon_finish(fx, page, url, html):
    """Called after a page loaded. If it is being recorded: look a little (scroll, wait) so the page
    asks for its stock data, write down what it asked and answered, and return the (fuller) page text."""
    if not getattr(fx, "_recon", False):
        return html
    try:
        import recon
        try:
            page.evaluate("window.scrollTo(0, Math.max(600, document.body.scrollHeight / 3))")
            page.wait_for_timeout(2500)
            page.evaluate("window.scrollTo(0, 0)")
            page.wait_for_timeout(300)
            h2 = page.content()
            if len(h2) >= len(html) * 0.8:
                html = h2
        except Exception:
            pass
        fx._recon = False
        net = [recon.describe_response(r) for r in list(fx.recon_resps)]
        fx.recon_resps = []
        fx.recon_net = net
        recon.save(url, net, html)
    except Exception:
        pass
    fx._recon = False
    return html



# ---- extra browsers the program installs by itself: Camoufox (free, open-source Firefox made to look like an ordinary person's browser)
# and Playwright's plain Firefox. The PC's own Firefox cannot be remote-controlled, so these are separate copies.
FIRST_FILE = "engine_first.txt"            # holds "camoufox" or "firefox" when that browser should be tried first
INSTALLS = {
    "camoufox": {"state": "not installed yet", "detail": "", "tried": False},      # not installed yet / installing / ready / unavailable
    "firefox": {"state": "not installed yet", "detail": "", "tried": False},
    # v76: "Hidden Chrome" - your own Chrome, driven through patchright (a free add-on that removes the signs a store looks for to see that
    # a program drives the browser). Only the small add-on is installed; it uses the Chrome (or Edge) already on this PC.
    "stealth": {"state": "not installed yet", "detail": "", "tried": False},
}
FIREFOX = INSTALLS["firefox"]
CAMOUFOX = INSTALLS["camoufox"]
_FF_LOCK = threading.Lock()
_INSTALL_CMDS = {
    "camoufox": [["-m", "pip", "install", "-U", "camoufox"], ["-m", "camoufox", "fetch"]],
    "firefox": [["-m", "playwright", "install", "firefox"]],
    "stealth": [["-m", "pip", "install", "-U", "patchright"]],
}
STEALTH = INSTALLS["stealth"]


def stealth_ready():
    """v76: True when Hidden Chrome can be used (the add-on is there and Chrome or Edge is on this PC)."""
    try:
        import importlib.util
        have = importlib.util.find_spec("patchright") is not None
    except Exception:
        have = False
    if have and STEALTH["state"] != "ready":
        STEALTH["state"] = "ready"
    return have and bool(RealChromeFetcher.exe_for("chrome") or RealChromeFetcher.exe_for("edge"))


def first_engine():
    """'' (Chrome first, the default), 'camoufox' or 'firefox'."""
    try:
        v = open(FIRST_FILE, encoding="utf-8").read().strip().lower()
    except OSError:
        return ""
    return v if v in INSTALLS else ""


def set_first_engine(name):
    try:
        if name in INSTALLS:
            with open(FIRST_FILE, "w", encoding="utf-8") as f:
                f.write(name + "\n")
        elif os.path.exists(FIRST_FILE):
            os.remove(FIRST_FILE)
    except OSError:
        pass


def start_engine_install(name, log=None, runner=None):
    """Installs one extra browser in the background (once per run; a few minutes). Never blocks a check.
    runner(cmd) -> (returncode, text) can be replaced for tests (cmd is a list for python, or None for the default single step)."""
    st = INSTALLS[name]
    if runner is None and os.environ.get("RK_NO_ENGINE_INSTALL"):
        return False                       # (tests) never install anything for real
    if name == "stealth" and runner is None:
        try:
            import importlib.util
            if importlib.util.find_spec("patchright") is not None:
                st["state"] = "ready"      # (already there: nothing to install)
                return False
        except Exception:
            pass
    with _FF_LOCK:
        if st["tried"] or st["state"] in ("installing", "ready"):
            return False
        st["tried"] = True
        st["state"] = "installing"

    def _run(cmd):
        import subprocess
        import sys as _sys
        p = subprocess.run([_sys.executable] + cmd, capture_output=True, text=True, timeout=1800)
        return p.returncode, (p.stdout or "") + (p.stderr or "")

    def _go():
        ok, txt = True, ""
        try:
            for cmd in _INSTALL_CMDS[name]:
                rc, txt = (runner or _run)(cmd)
                if rc != 0:
                    ok = False
                    break
        except Exception as e:
            ok, txt = False, str(e)
        label = {"camoufox": "Camoufox", "firefox": "Firefox", "stealth": "Hidden Chrome"}.get(name, name)
        with _FF_LOCK:
            st["state"] = "ready" if ok else "unavailable"
            st["detail"] = "" if ok else (txt.strip().splitlines() or [""])[-1][:160]
        if log:
            try:
                log(f"[info] {label} is ready as a browser for the store checks." if ok else
                    f"[info] {label} could not be installed ({st['detail']}). The program keeps using the other browsers.")
            except Exception:
                pass
    threading.Thread(target=_go, daemon=True, name=name + "-install").start()
    return True


# ---- what each browser is really being used for (shown on the main page and in the diagnostics)
_USE_LOCK = threading.Lock()
USAGE = {}            # engine -> {launches, launch_fail, pages, pages_ok, last_at, last_error}
STORE_USE = {}        # store -> {engine, ok, fail, since, last_ok_at, last_error}
TESTS = {}            # engine -> {state: running / ok / failed, detail, at}
LOG_FN = [None]
STORE_NAMES = {"bestbuy": "Best Buy", "gamestop": "GameStop"}
ENGINE_NAMES = {"camoufox": "Camoufox", "firefox": "Firefox", "chrome": "Chrome", "msedge": "Edge", "chromium": "built-in Chromium",
                "real-chrome": "your Chrome", "real-msedge": "your Edge", "stealth": "Hidden Chrome", "stealth-chrome": "Hidden Chrome"}


def set_logger(fn):
    LOG_FN[0] = fn


def _say(msg):
    try:
        if LOG_FN[0]:
            LOG_FN[0](msg)
    except Exception:
        pass


def _u(engine):
    return USAGE.setdefault(engine, {"launches": 0, "launch_fail": 0, "pages": 0, "pages_ok": 0, "last_at": None, "last_error": ""})


def note_launch(engine, store="", ok=True, err=""):
    with _USE_LOCK:
        u = _u(engine)
        first = ok and u["launches"] == 0
        if ok:
            u["launches"] += 1
        else:
            u["launch_fail"] += 1
            u["last_error"] = str(err)[:160]
    if first and engine in ("camoufox", "firefox"):
        _say(f"[browser] {ENGINE_NAMES.get(engine, engine)} started for the first time" + (f" (for {STORE_NAMES.get(store, (store or 'a store').title())})" if store else "") + ": it is installed and working.")


def note_page(engine, store, ok, err=""):
    """One page / data read made by a browser of the program: counted per browser and per store."""
    engine = engine or "chrome"
    now = time.time()
    change = None
    with _USE_LOCK:
        u = _u(engine)
        u["pages"] += 1
        u["last_at"] = now
        if ok:
            u["pages_ok"] += 1
        else:
            u["last_error"] = str(err)[:160]
        if store:
            s = STORE_USE.setdefault(store, {"engine": engine, "ok": 0, "fail": 0, "since": now, "last_ok_at": None, "last_error": ""})
            if s["engine"] != engine:
                change = s["engine"]
                s["engine"], s["since"] = engine, now
            if ok:
                s["ok"] += 1
                s["last_ok_at"] = now
            else:
                s["fail"] += 1
                s["last_error"] = str(err)[:160]
    if change:
        _say(f"[browser] {STORE_NAMES.get(store, store.title())} is now checked with {ENGINE_NAMES.get(engine, engine)} (before: {ENGINE_NAMES.get(change, change)}).")


def engine_report():
    with _USE_LOCK:
        use = {k: dict(v) for k, v in USAGE.items()}
        stores = {k: dict(v) for k, v in STORE_USE.items()}
        tests = {k: dict(v) for k, v in TESTS.items()}
    engines = {}
    if STEALTH["state"] not in ("ready", "installing"):
        try:
            stealth_ready()            # (the add-on may be there from an earlier start)
        except Exception:
            pass
    for k, v in INSTALLS.items():
        engines[k] = {"state": v["state"], "detail": v["detail"], **(use.get(k) or {"launches": 0, "launch_fail": 0, "pages": 0, "pages_ok": 0, "last_at": None, "last_error": ""})}
    return {"first": first_engine(), "engines": engines, "stores": stores, "tests": tests,
            "used": {k: v for k, v in use.items() if k not in INSTALLS}}


def start_engine_test(name, log=None, opener=None):
    """Starts the engine once in the background, shows its identity and opens one harmless page. Result in TESTS[name].
    opener() -> (browser, closer) can be replaced for tests."""
    if name not in INSTALLS:
        return False
    with _USE_LOCK:
        if (TESTS.get(name) or {}).get("state") == "running":
            return False
        TESTS[name] = {"state": "running", "detail": "starting the browser (the first start can take up to a minute)...", "at": time.time()}
    label = ENGINE_NAMES.get(name, name)

    def _done(state, detail):
        with _USE_LOCK:
            TESTS[name] = {"state": state, "detail": detail, "at": time.time()}
        if log:
            try:
                log(f"[browser] {label} test: {'PASSED' if state == 'ok' else 'FAILED'} - {detail}")
            except Exception:
                pass

    def _go():
        pw = br = None
        try:
            if opener is not None:
                br = opener()
            elif name == "stealth":
                from patchright.sync_api import sync_playwright as _spw
                exe = RealChromeFetcher.exe_for("chrome") or RealChromeFetcher.exe_for("edge")
                if not exe:
                    raise RuntimeError("no Chrome or Edge on this PC - not installed")
                pw = _spw().start()
                br = pw.chromium.launch(executable_path=exe, headless=False, args=["--window-position=-32000,-32000"])
            else:
                from playwright.sync_api import sync_playwright
                pw = sync_playwright().start()
                if name == "camoufox":
                    from camoufox.sync_api import NewBrowser
                    br = NewBrowser(pw, headless=True, os="windows")
                else:
                    br = pw.firefox.launch(headless=True)
            note_launch(name, "", True)
            pg = br.new_page()
            pg.set_content("<title>engine test</title><p>hello</p>")
            ua = pg.evaluate("navigator.userAgent") or ""
            with _FF_LOCK:
                INSTALLS[name]["state"] = "ready"
            detail = "it starts and runs. It presents itself as: " + ua[:90]
            try:
                pg.goto("https://example.com", timeout=20000, wait_until="domcontentloaded")
                detail += f". It also opened a real web page (\"{pg.title()[:40]}\")."
            except Exception as e:
                detail += f". (It could not open a web page just now: {str(e).splitlines()[0][:70]}.)"
            _done("ok", detail)
        except Exception as e:
            low = str(e).lower()
            missing = isinstance(e, ImportError) or "executable" in low or "not installed" in low or "camoufox fetch" in low
            note_launch(name, "", False, str(e))
            _done("failed", ("it is not installed on this PC yet (" + INSTALLS[name]["state"] + ")" if missing else "it would not start: " + (str(e).splitlines() or [""])[0][:140]))
        finally:
            for o, fn in ((br, "close"), (pw, "stop")):
                try:
                    if o is not None:
                        getattr(o, fn)()
                except Exception:
                    pass
    threading.Thread(target=_go, daemon=True, name=name + "-test").start()
    return True


def _firefox_ua(version):
    major = (version or "130.0").split(".")[0]
    return f"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:{major}.0) Gecko/20100101 Firefox/{major}.0"



# ---- v51: several lighter reads at once, from the one open store tab -----------------------------------------------------------------
# One page.evaluate asks the store for a few product pages together (each started a little after the one before it, never in a burst);
# nothing is drawn and no store script runs, so this costs almost nothing. The answers wait in the browser object for a few seconds and
# light_get() hands them out instead of asking again.
PRE_TTL = 2.5          # seconds an early answer stays good (a look is never served an older one)
PRE_GAP_MS = 150       # milliseconds between the starts of the requests of one group
_LIGHT_MANY_JS = """async ([urls, ms, gap, cross, accept, json_only]) => {
    const one = async (u, i) => {
        if (gap > 0 && i > 0) await new Promise(r => setTimeout(r, gap * i));
        const c = new AbortController();
        const t = setTimeout(() => c.abort(), ms);
        try {
            const h = {'Accept': accept};
            const r = await fetch(u, json_only ? {credentials: cross ? 'omit' : 'include', signal: c.signal, headers: h}
                                               : {credentials: cross ? 'omit' : 'include', cache: 'no-store', signal: c.signal, headers: h});
            const body = await r.text();
            return {u: u, status: r.status, url: r.url, text: body};
        } catch (e) { return {u: u, status: 0, url: '', text: '', error: String(e).slice(0, 120)}; }
        finally { clearTimeout(t); }
    };
    return await Promise.all(urls.map(one));
}"""


def _light_interpret(res, origin, min_len=3000):
    """One in-page answer -> (text, None) or (None, why_not) - the same rules light_get() uses."""
    if res.get("error"):
        return None, res["error"]
    if res.get("status") != 200:
        return None, f"HTTP {res.get('status')}"
    got = (res.get("url") or "").lower()
    if got and origin and not got.startswith(origin):
        return None, "redirected away from the store"
    text = res.get("text") or ""
    if len(text) < min_len:
        return None, "answer too short"
    return text, None


def _pre_take(self, url):
    """An early answer for this URL if one is waiting and still fresh -> (text, err) or None."""
    pre = getattr(self, "_pre", None)
    if not pre:
        return None
    hit = pre.pop(url, None)
    if hit and time.time() - hit[0] <= PRE_TTL:
        return hit[1]
    return None


# ---- v52: why a program that runs for days grew by gigabytes -----------------------------------------------------------------------------
# Measured (real headless browsers): every full page load leaves ~400 small objects behind in the automation library for as long as the SAME
# tab stays open - 600 page loads = 244,000 objects; closing the tab gave every one of them back. The owner's v47 run held 4.9 million of them
# (3 GB in the program itself + ~680 MB in each automation helper). So (1) a tab is replaced by a new one in the same browser (cookies, logins
# and the saved profile stay) after PAGE_NAVS page loads or PAGE_SECS seconds - it happens at the start of a full page load, which opens a
# page anyway, so it costs nothing; (2) the "listen to every answer" hook is only attached when something needs it (Best Buy's learned data
# address, the recorder, Target's all-products capture) - without it a page load leaves ~10x fewer objects.
PAGE_NAVS = int(os.environ.get("RK_PAGE_NAVS", "100") or 100)
PAGE_SECS = float(os.environ.get("RK_PAGE_SECS", "900") or 900)
_FRESH = {"tabs": 0, "last": 0.0}      # how many tabs were replaced (for the diagnostics)


def _resp_text(resp):
    """'HTTP 200 from <server> (...)' from the answer page.goto() returned - no need to listen to every network answer for it."""
    try:
        if resp is None:
            return None
        h = resp.headers
        return (f"HTTP {resp.status} from {h.get('server', '?')}"
                f" (content-type {h.get('content-type', '?')[:30]}, length {h.get('content-length', '?')})")
    except Exception:
        return None


def _wants_events(fx):
    """Does anything need to hear every network answer of the next page load?"""
    return bool(getattr(fx, "capture", None)) or bool(getattr(fx, "_recon", False)) or getattr(fx, "store", "") == "bestbuy"


def _sync_listener(fx, page, handler):
    """Attach the 'every answer' hook to this tab only while it is needed; take it off again afterwards."""
    if page is None or handler is None:
        return
    try:
        on = getattr(page, "_rk_listening", False)
        want = _wants_events(fx)
        if want and not on:
            page.on("response", handler)
            page._rk_listening = True
        elif on and not want:
            page.remove_listener("response", handler)
            page._rk_listening = False
    except Exception:
        pass


def _wait_ready(page, ready, dcl_ms, idle_ms):
    """v52: instant verification. With `ready` (a function of the page's html), the page is looked at every 60 ms from the moment the store
    starts answering and handed back AS SOON AS ready(html) is true - no waiting for the page to finish loading or to go quiet (that used
    to add 1.5-2 s to every confirmation). If it never becomes true, the same total time as before is spent, then the page as it is.
    Without `ready` (None) nothing changes: returns None and the caller waits the old way."""
    if ready is None:
        return None
    hard = time.time() + (dcl_ms + idle_ms) / 1000.0
    dcl_at = None
    while True:
        try:
            html = page.content()
        except Exception:
            html = None
        try:
            if html and len(html) >= 3000 and ready(html):
                return html
        except Exception:
            pass
        now = time.time()
        if now >= hard:
            return html
        if dcl_at is None:
            try:
                st = page.evaluate("document.readyState")
            except Exception:
                st = None
            if st in ("interactive", "complete"):
                dcl_at = now
        elif now - dcl_at >= idle_ms / 1000.0:
            return html
        try:
            page.wait_for_timeout(60)
        except Exception:
            time.sleep(0.06)


def _tab_is_old(fx):
    return (getattr(fx, "_page", None) is not None
            and (getattr(fx, "_navs", 0) >= PAGE_NAVS or time.time() - getattr(fx, "_page_born", time.time()) > PAGE_SECS))


def tab_stats():
    return dict(_FRESH)


class BrowserFetcher:
    """Owns one real (headless) browser, kept open between checks so
    cookies persist (needed to stay past Amazon's 'Continue shopping'
    page and bot-defense checks). Prefers the REAL Chrome or Edge already
    installed on the PC (their network fingerprint is genuine, which
    sites like Best Buy look at), falling back to Playwright's own
    Chromium. One instance per polling thread."""

    CHANNELS = ["chrome", "msedge", "camoufox", "firefox", None]

    def __init__(self, offscreen=False, fresh=False, store=""):
        self.store = store      # which store this browser works for (also tags the browser so the CPU report can name it)
        # offscreen=True: run as a normal (not "headless") window parked far
        # off the screen. Some stores (Best Buy) stall headless browsers;
        # a real window placed out of sight is not stalled.
        self.offscreen = offscreen
        # fresh=True: a brand-new browser 'visit' (no cookies) for every check.
        # Best Buy answered the first few loads of a session and then stopped
        # answering that session; a new visit each time avoids that.
        self.fresh = fresh
        self._playwright = None
        self._browser = None
        self._ctx = None
        self._page = None
        self._navs = 0                 # v52: page loads in the current tab (see PAGE_NAVS)
        self._page_born = time.time()
        self._on_resp_fn = None
        self.engine = None
        self._no_http2 = False
        # which engine of CHANNELS we are on ("Firefox first" starts at Firefox when it is, or may yet become, available)
        _f = first_engine()
        self._idx = self.CHANNELS.index(_f) if (_f in self.CHANNELS and INSTALLS[_f]["state"] != "unavailable") else 0       # (v46: a Firefox-only fetcher asked for "camoufox first" raised ValueError)
        self.history = []      # short log of what was tried, for diagnostics
        self.block_heavy = not os.environ.get("RK_FULL_PAGES")
        self.blocked_count = 0

    def _launch(self):
        args = ["--disable-blink-features=AutomationControlled", "--mute-audio"]
        if self.store:
            args.append(f"--rk-store={self.store}")
        try:
            args += json.loads(os.environ.get("RK_FETCH_EXTRA_ARGS") or "[]")      # (v64: only the test lab sets this)
        except Exception:
            pass
        if self._no_http2:
            args.append("--disable-http2")
        tried = 0
        while tried < len(self.CHANNELS):
            ch = self.CHANNELS[self._idx % len(self.CHANNELS)]
            name = ch or "chromium"
            if ch in ("firefox", "camoufox"):
                st = INSTALLS[ch]
                try:
                    if ch == "camoufox":
                        from camoufox.sync_api import NewBrowser
                        self._browser = NewBrowser(self._playwright, headless=True, os="windows")
                    else:
                        self._browser = self._playwright.firefox.launch(headless=True)
                    self.engine = ch
                    with _FF_LOCK:
                        st["state"] = "ready"
                    note_launch(ch, self.store, True)
                    return
                except Exception as e:
                    missing = isinstance(e, ImportError) or "xecutable" in str(e) or "not installed" in str(e).lower() or "camoufox fetch" in str(e).lower()
                    self.history.append(f"{ch}: not installed yet" if missing else f"{ch}: {str(e)[:60]}")
                    note_launch(ch, self.store, False, "not installed yet" if missing else str(e))
                    if st["state"] not in ("installing", "unavailable") and missing:
                        start_engine_install(ch)
                    self._idx += 1
                    tried += 1
                    continue
            try:
                kw = dict(headless=True, args=args)
                if self.offscreen and not getattr(self, "_headed_failed", False):
                    kw = dict(headless=False, args=args + [
                        "--window-position=-32000,-32000", "--window-size=1280,800"])
                if ch:
                    kw["channel"] = ch
                self._browser = self._playwright.chromium.launch(**kw)
                self.engine = name
                note_launch(name, self.store, True)
                return
            except Exception as e:
                if self.offscreen and not getattr(self, "_headed_failed", False):
                    self._headed_failed = True   # no display? fall back to headless
                    continue
                self.history.append(f"{name}: not available on this PC")
                self._idx += 1
                tried += 1
        raise RuntimeError(f"{PLAYWRIGHT_NOT_INSTALLED}: no usable browser")

    def rotate(self, reason=""):
        """Current engine isn't getting through: switch to the next one
        (real Chrome -> Edge -> built-in Chromium -> back around)."""
        self.history.append(f"{self.engine}: failed ({reason[:80]})")
        self.history = self.history[-12:]
        if self.block_heavy:
            self.block_heavy = False      # maybe the store dislikes missing pictures: try full pages
            self.history.append("lean pages (no pictures/styles) turned off for this store")
        self._idx += 1
        self._reset(full=True)
        try:
            self._ensure()
        except RuntimeError as e:
            return None
        if self.engine in ("camoufox", "firefox"):
            self._heavy_since = time.time()
        return self.engine

    def _ensure(self):
        if self._browser is not None:
            return
        try:
            from playwright.sync_api import sync_playwright
        except ImportError:
            raise RuntimeError(PLAYWRIGHT_NOT_INSTALLED)
        if self._playwright is None:
            self._playwright = shared_playwright()
        try:
            self._launch()
        except RuntimeError:
            release_playwright(self._playwright)
            self._playwright = None
            raise

    def _fresh_page(self):
        """v52: a new tab in the SAME browser window/context (cookies and logins stay); the old tab is closed, which gives back everything the
        automation library had piled up for it. Returns True when it happened."""
        if self._ctx is None or self._page is None:
            return False
        old = self._page
        try:
            new = self._ctx.new_page()
        except Exception:
            return False
        self._page = new
        self._navs = 0
        self._page_born = time.time()
        self.__dict__.pop("_pre", None)
        try:
            old.close()
        except Exception:
            pass
        _FRESH["tabs"] += 1
        _FRESH["last"] = time.time()
        return True

    def _new_page(self):
        self._navs = 0
        self._page_born = time.time()
        if self.engine == "camoufox":
            # Camoufox makes its own, consistent identity (browser, system, screen, fonts): nothing is overridden here
            self._ctx = self._browser.new_context(locale="en-US")
            self._page = self._ctx.new_page()
            try:
                self._ctx.route("**/*", self._route)
            except Exception:
                pass
            return
        if self.engine == "firefox":
            ua = _firefox_ua(self._browser.version)
        else:
            ua = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                  f"(KHTML, like Gecko) Chrome/{self._browser.version} Safari/537.36")
        self._ctx = self._browser.new_context(
            user_agent=ua, viewport={"width": 1280, "height": 800}, locale="en-US")
        self._page = self._ctx.new_page()
        try:
            self._ctx.route("**/*", self._route)
        except Exception:
            pass

    def _route(self, route):
        try:
            r = route.request
            if self.block_heavy and (r.resource_type in _BLOCK_TYPES or any(h in r.url for h in _BLOCK_HOSTS)):
                self.blocked_count += 1
                route.abort()
            else:
                route.continue_()
        except Exception:
            try:
                route.continue_()
            except Exception:
                pass

    def _reset(self, full=False):
        for obj in (self._page, self._ctx):
            try:
                if obj:
                    obj.close()
            except Exception:
                pass
        self._page = self._ctx = None
        if full and self._browser:
            try:
                self._browser.close()
            except Exception:
                pass
            self._browser = None

    def _click_continue(self, page):
        """Amazon's 'Continue shopping' page: press its button."""
        try:
            btn = page.get_by_role("button", name="Continue shopping")
            if btn.count() == 0:
                btn = page.get_by_text("Continue shopping", exact=False)
            btn.first.click(timeout=3000)
            try:
                page.wait_for_load_state("domcontentloaded", timeout=8000)
            except Exception:
                pass
            return True
        except Exception:
            return False

    supports_ready = True      # v52: fetch(url, ready=f) may return as soon as f(html) is true (see _wait_ready)

    def _once(self, url, timeout, ready=None):
        if self.fresh and self._browser is not None:
            for obj in (self._page, self._ctx):
                try:
                    if obj:
                        obj.close()
                except Exception:
                    pass
            self._page = self._ctx = None
        if self._page is not None and not self.fresh and _tab_is_old(self):
            self._fresh_page()          # v52: a new tab in the same browser (see PAGE_NAVS)
        if self._page is None:
            self._new_page()
            if self.fresh:
                try:   # text is all we need; skipping pictures/fonts makes loads light and fast
                    self._ctx.route("**/*", lambda route: route.abort()
                                    if route.request.resource_type in ("image", "media", "font")
                                    else route.continue_())
                except Exception:
                    pass
        page = self._page
        # "commit" = the store started answering. Then give the page a few
        # seconds to build, but if it is slow, read what has arrived
        # instead of throwing the whole check away (Best Buy timed out
        # on every try before).
        self.last_response = None
        self.captured = []
        _recon_prepare(self, url)
        if self._on_resp_fn is None:
            def _on_resp(r, _self=self):
                try:
                    cap = getattr(_self, "capture", None)
                    if cap and cap in r.url:
                        _self.captured.append(r.url)
                except Exception:
                    pass
                _recon_note(_self, r)
                try:
                    if r.request.resource_type == "document" and _self.last_response is None:
                        _self.last_response = _resp_text(r)
                except Exception:
                    pass
            self._on_resp_fn = _on_resp
        _sync_listener(self, page, self._on_resp_fn)       # v52: only while something needs every answer
        self._t0 = time.time()
        self.dirty = True            # a heavy product page is open now (see park())
        self._navs += 1
        _resp = page.goto(url, timeout=timeout * 1000, wait_until="commit")
        if self.last_response is None:
            self.last_response = _resp_text(_resp)
        html = _wait_ready(page, ready, 6000, 1500)
        if html is None:
            try:
                page.wait_for_load_state("domcontentloaded", timeout=6000)
            except Exception:
                pass
            try:
                page.wait_for_load_state("networkidle", timeout=1500)
            except Exception:
                pass
            html = page.content()
        if len(html) < 3000 and not _refusal_page(html):
            raise RuntimeError("page did not load (almost empty)")
        low = html.lower()
        if len(html) < 20000 and "continue shopping" in low and "click the button below" in low:
            if self._click_continue(page):
                # now on whatever the button leads to; go to the product again
                page.goto(url, timeout=timeout * 1000, wait_until="domcontentloaded")
                try:
                    page.wait_for_load_state("networkidle", timeout=4000)
                except Exception:
                    pass
                html = page.content()
        html = _recon_finish(self, page, url, html)
        return html

    def fetch(self, url: str, timeout: float = 20.0, ready=None):
        """Returns (html, None) on success, (None, error_message) on
        failure — same calling convention as http_utils.fetch.
        v52: ready(html) -> True hands the page back the moment it shows what the caller is waiting for (see _wait_ready)."""
        if (self.engine in ("camoufox", "firefox") and "chrome" in self.CHANNELS and len(self.CHANNELS) > 2
                and time.time() - getattr(self, "_heavy_since", time.time()) > 600.0):
            # v48: Firefox / Camoufox only filled in while Chrome and Edge had trouble; after 10 minutes go back to the lighter Chrome (it rotates on again if it fails)
            self.history.append(f"{self.engine}: back to chrome (lighter)")
            self.history = self.history[-12:]
            self._idx = self.CHANNELS.index("chrome")
            self._heavy_since = time.time()
            self._reset(full=True)
        try:
            self._ensure()
        except RuntimeError as e:
            return None, str(e)
        for attempt in (1, 2):
            try:
                return (self._once(url, timeout, ready) if ready is not None else self._once(url, timeout)), None
            except Exception as e:
                msg = str(e)
                low = msg.lower()
                # Browser/page died, or the site rejects HTTP/2: rebuild once and retry.
                if attempt == 1 and ("closed" in low or "crash" in low or "http2" in low):
                    if "http2" in low:
                        self._no_http2 = True
                    try:
                        self._reset(full=True)
                        self._ensure()
                    except Exception as e2:
                        return None, str(e2)
                    continue
                where = getattr(self, "last_response", None)
                took = time.time() - getattr(self, "_t0", time.time())
                msg = (msg.split("\n")[0][:120] + f" | after {took:.0f}s the store had "
                       + (f"answered: {where}" if where else "sent NOTHING back (no response at all)"))
                self._reset()
                return None, msg
        return None, "browser fetch failed"

    # ---- lighter check -------------------------------------------------
    # A full page load runs all of the store's scripts, which is what keeps a PC busy.
    # Once one real page of the store is open in this browser, the product page can be
    # asked for again "from inside it" (same cookies, same browser, nothing drawn and no
    # scripts run) - the stock text is in what the store sends back.
    _LIGHT_JS = """async ([u, ms, cross]) => {
        const c = new AbortController();
        const t = setTimeout(() => c.abort(), ms);
        try {
            const r = await fetch(u, {credentials: cross ? 'omit' : 'include', cache: 'no-store', signal: c.signal,
                                      headers: {'Accept': 'text/html,application/xhtml+xml,application/json'}});
            const body = await r.text();
            return {status: r.status, url: r.url, text: body};
        } catch (e) { return {status: 0, url: '', text: '', error: String(e).slice(0, 120)}; }
        finally { clearTimeout(t); }
    }"""

    def clear_cache(self):
        """v52: empties this browser's page cache (NOT cookies, NOT logins) so a browser that stays open for weeks does not keep growing.
        Chrome / Edge / Playwright's Chromium only (Firefox-type browsers have no such switch; they are restarted by the regular upkeep)."""
        page = self._page
        if page is None or getattr(self, "engine", "") in ("camoufox", "firefox"):
            return False
        try:
            sess = page.context.new_cdp_session(page)
            try:
                sess.send("Network.clearBrowserCache")
            finally:
                try:
                    sess.detach()
                except Exception:
                    pass
            return True
        except Exception:
            return False

    def light_prefetch(self, urls, timeout=12.0, gap_ms=None):
        """v51: asks the store for several product pages AT ONCE from the open tab (see _LIGHT_MANY_JS). Returns how many answers are waiting."""
        page = self._page
        if page is None or not urls:
            return 0
        try:
            m = re.match(r"https?://[^/]+", urls[0])
            origin = m.group(0).lower() if m else ""
            cur = (page.url or "").lower()
            if not origin or not cur.startswith(origin):
                return 0
            res = page.evaluate(_LIGHT_MANY_JS, [list(urls), int(timeout * 1000), PRE_GAP_MS if gap_ms is None else int(gap_ms), False,
                                                 "text/html,application/xhtml+xml,application/json", False])
        except Exception:
            return 0
        pre = self.__dict__.setdefault("_pre", {})
        now = time.time()
        for r in res or []:
            try:
                pre[r["u"]] = (now, _light_interpret(r, origin))
            except Exception:
                pass
        return len(pre)

    def light_get(self, url, timeout=12.0, same_origin=True, min_len=3000):
        """Returns (text, None) or (None, why_not). Never loads a page itself.
        same_origin=False: the store's own data service on another address (the open tab
        is on the store's site, as it is when the store's page itself asks for it)."""
        _early = _pre_take(self, url)
        if _early is not None:
            return _early
        page = self._page
        if page is None:
            return None, "no page open yet"
        try:
            m = re.match(r"https?://[^/]+", url)
            origin = m.group(0).lower() if m else ""
            cur = (page.url or "").lower()
            if not origin or (same_origin and not cur.startswith(origin)) or not cur.startswith("http"):
                return None, "the open tab is not on this store's site"
            res = page.evaluate(self._LIGHT_JS, [url, int(timeout * 1000), not same_origin])
        except Exception as e:
            return None, str(e).split("\n")[0][:120]
        if res.get("error"):
            return None, res["error"]
        if res.get("status") != 200:
            return None, f"HTTP {res.get('status')}"
        got = (res.get("url") or "").lower()
        if got and not got.startswith(origin):
            return None, "redirected away from the store"
        text = res.get("text") or ""
        if len(text) < min_len:
            return None, "answer too short"
        return text, None

    # ---- sleeping between checks ------------------------------------------------------
    # A store's product page keeps running its own scripts (trackers, ads, bot checks) the whole time it stays open,
    # which is most of what a quiet browser costs. Between checks the tab is switched to the store's robots.txt (a plain
    # text page of the SAME site: no scripts, cookies stay, the lighter in-tab requests still work). The next full check
    # simply loads the product page again. Three failures in a row turn this off by itself.
    def park(self):
        page = self._page
        if page is None or getattr(self, "_park_off", False) or not getattr(self, "dirty", False):
            return False
        try:
            self.dirty = False
            cur = page.url or ""
            m = re.match(r"https?://[^/]+", cur)
            if not m or cur.lower().endswith("/robots.txt"):
                return False
            page.goto(m.group(0) + "/robots.txt", timeout=8000, wait_until="commit")
            self._navs = getattr(self, "_navs", 0) + 1
            self.parked_n = getattr(self, "parked_n", 0) + 1
            self._park_fail = 0
            return True
        except Exception:
            self._park_fail = getattr(self, "_park_fail", 0) + 1
            if self._park_fail >= 3:
                self._park_off = True
            return False

    def close(self):
        self._reset(full=True)
        if self._playwright:
            release_playwright(self._playwright)
            self._playwright = None


class CamoufoxFetcher(BrowserFetcher):
    """Best Buy's connection resets and silences (ERR_HTTP2_PROTOCOL_ERROR, "sent NOTHING back") hit the program's Chrome/Edge. Camoufox is a
    different kind of browser (Firefox-based, with its own consistent identity), so it is another way to look like an ordinary visitor.
    Same calling convention as RealChromeFetcher (warm / page_json / light_get / fetch), but only ever uses Camoufox."""
    CHANNELS = ["camoufox"]

    def __init__(self, store="", **kw):
        BrowserFetcher.__init__(self, store=store)
        self.start_failures = 0
        self.last_response = None
        self.learned_api = None
        self.warm_at = 0.0
        self.warm_url = None

    def fetch(self, url, timeout=25.0, ready=None):
        try:
            res = BrowserFetcher.fetch(self, url, timeout, ready)
        except Exception as e:
            self.start_failures += 1
            return None, f"Camoufox could not be used: {str(e)[:150]}"
        if res and res[1] and "not installed" in str(res[1]).lower():
            self.start_failures += 1
        else:
            self.start_failures = 0
        return res

    def warm(self, url, timeout=25.0):
        html, err = self.fetch(url, timeout=timeout)
        if err:
            return err
        self.warm_at = time.time()
        self.warm_url = url
        return None

    def page_json(self, api_url, timeout=12.0, credentials="include"):
        return RealChromeFetcher.page_json(self, api_url, timeout, credentials)

    def rotate(self, reason=""):
        """Same browser again, brand-new visit (cookies dropped)."""
        self.history.append(f"camoufox: restarted ({reason[:80]})")
        self.history = self.history[-12:]
        self._reset(full=True)
        try:
            self._ensure()
        except RuntimeError:
            return None
        return self.engine


class FirefoxFetcher(CamoufoxFetcher):
    """v39: the ordinary Firefox (installed by the program once, in the background) as one more browser in a store's rotation.
    Same calling convention as CamoufoxFetcher; only the engine differs."""
    CHANNELS = ["firefox"]

    def fetch(self, url, timeout=25.0, ready=None):
        res = CamoufoxFetcher.fetch(self, url, timeout, ready)
        if res and res[1] and str(res[1]).startswith("Camoufox could not be used"):
            return res[0], "Firefox could not be used" + str(res[1])[len("Camoufox could not be used"):]
        return res

    def rotate(self, reason=""):
        self.history.append(f"firefox: restarted ({reason[:80]})")
        self.history = self.history[-12:]
        self._reset(full=True)
        try:
            self._ensure()
        except RuntimeError:
            return None
        return self.engine


class RealChromeFetcher:
    """Best Buy stops answering browsers that a program steers (they carry
    automation markers) after a few page loads. This starts the PC's ordinary
    Chrome (or Edge) the normal way - no automation switches, its own saved
    profile so cookies and history build up like a person's - parked off
    screen, and only reads pages from it, like refreshing one tab.
    Same calling convention as BrowserFetcher."""

    def __init__(self, profile_dir="browser_profile", port=9333, store="", block_media=False):
        self.store = store
        self.block_media = block_media     # skip pictures / video / fonts (text is all that is read): much lighter
        self.start_failures = 0
        self.profile_dir = os.path.abspath(profile_dir)
        self.port = port
        self.engine = "real-chrome"
        self.history = []
        self.capture = None
        self.captured = []
        self._proc = None
        self._playwright = None
        self._browser = None
        self._page = None
        self._navs = 0              # v52: page loads in the current tab (see PAGE_NAVS)
        self._page_born = time.time()
        self._on_resp_fn = None
        self._exe_idx = 0
        self.last_response = None
        self.learned_api = None     # the page's own small data request (learned by watching it load)
        self.warm_at = 0.0          # when a bestbuy.com tab was last loaded
        self.warm_url = None

    @staticmethod
    def candidates():
        env = os.environ.get("RK_CHROME_EXE")
        if env:
            return [env]
        pf = [os.environ.get(k) for k in ("ProgramFiles", "ProgramFiles(x86)", "LocalAppData")]
        out = []
        for base in pf:
            if base:
                out.append(os.path.join(base, "Google", "Chrome", "Application", "chrome.exe"))
        for base in pf:
            if base:
                out.append(os.path.join(base, "Microsoft", "Edge", "Application", "msedge.exe"))
        # v44: more ordinary browsers of the same family (they take the same start switches); they come AFTER Chrome and Edge, so what
        # the first two entries mean does not change. Used as extra "scout" readers.
        for base in pf:
            if base:
                out.append(os.path.join(base, "BraveSoftware", "Brave-Browser", "Application", "brave.exe"))
        for base in pf:
            if base:
                out.append(os.path.join(base, "Vivaldi", "Application", "vivaldi.exe"))
        for base in pf:
            if base:
                out.append(os.path.join(base, "Programs", "Opera", "opera.exe"))
                out.append(os.path.join(base, "Opera", "opera.exe"))
        out += ["/usr/bin/google-chrome", "/usr/bin/chromium", "/usr/bin/chromium-browser"]
        seen, uniq = set(), []
        for p_ in out:
            if os.path.exists(p_) and p_.lower() not in seen:
                seen.add(p_.lower())
                uniq.append(p_)
        return uniq

    @classmethod
    def available(cls):
        return bool(cls.candidates())

    @classmethod
    def exe_for(cls, kind):
        """v76: the path of this PC's Google Chrome (kind 'chrome') or Microsoft Edge (kind 'edge'), or '' when it is not installed.
        (Tests: RK_CHROME_EXE / RK_EDGE_EXE.)"""
        env = os.environ.get("RK_EDGE_EXE" if kind == "edge" else "RK_CHROME_EXE")
        if env:
            return env if os.path.exists(env) else ""
        if kind == "edge" and os.environ.get("RK_CHROME_EXE"):
            return ""
        for p_ in cls.candidates():
            low = p_.lower().replace("\\", "/")
            if kind == "edge" and low.endswith("msedge.exe"):
                return p_
            if kind == "chrome" and ("/google/chrome/" in low or low.endswith("google-chrome") or (os.name != "nt" and low.endswith("/chromium"))):
                return p_
        return ""

    @classmethod
    def exe_index(cls, kind):
        """v76: where that browser is in candidates() (-1 when it is not installed)."""
        e = cls.exe_for(kind)
        try:
            return cls.candidates().index(e) if e else -1
        except ValueError:
            return -1

    def _alive(self):
        import urllib.request
        try:
            urllib.request.urlopen(f"http://127.0.0.1:{self.port}/json/version", timeout=1).read()
            return True
        except Exception:
            return False

    def _start(self):
        import subprocess
        cands = self.candidates()
        if not cands:
            raise RuntimeError("no Chrome or Edge found on this PC")
        exe = cands[self._exe_idx % len(cands)]
        # each browser (Chrome / Edge) keeps its own profile folder, so switching between them
        # gives Best Buy a genuinely separate visitor and never mixes two browsers' files
        prof = self.profile_dir + "_" + os.path.basename(exe).replace(".exe", "").lower()
        os.makedirs(prof, exist_ok=True)
        args = [exe, f"--remote-debugging-port={self.port}", f"--user-data-dir={prof}",
                "--no-first-run", "--no-default-browser-check", "--window-position=-32000,-32000",
                "--window-size=1280,900", "--disable-session-crashed-bubble", "--hide-crash-restore-bubble", "--mute-audio"]
        if self.store:
            args.append(f"--rk-store={self.store}")
        if getattr(self, "_no_http2", False):
            args.append("--disable-http2")
        if not os.environ.get("RK_FAT_BROWSER"):
            # v51: the PC's own Chrome / Edge, started without the things a reading-only browser never uses (background updates and
            # reporting, translation, casting, extension and sync services). Measured: about 5 % less memory per browser, no change in what
            # the store sees. (Nothing here touches the picture of the browser a store looks at: no GPU, window or header flags.)
            args += ["--disable-extensions", "--disable-sync", "--disable-background-networking", "--disable-component-update",
                     "--disable-default-apps", "--disable-breakpad", "--disable-domain-reliability", "--metrics-recording-only", "--no-pings",
                     "--disable-client-side-phishing-detection",
                     "--disable-features=Translate,MediaRouter,OptimizationHints,InterestFeedContentSuggestions,AutofillServerCommunication"]
        if os.environ.get("RK_CHROME_HEADLESS"):
            args += ["--headless=new", "--no-sandbox", "--disable-gpu"]
        args.append("about:blank")
        flags = (0x08000000 | 0x00004000) if os.name == "nt" else 0   # no console window, below-normal priority
        self._proc = subprocess.Popen(args, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                                      creationflags=flags)
        self.engine = "real-" + os.path.basename(exe).replace(".exe", "").lower()
        for _ in range(60):
            if self._alive():
                return
            time.sleep(0.5)
        raise RuntimeError("Chrome did not start in time")

    def _ensure(self):
        if self._page is not None:
            return
        from playwright.sync_api import sync_playwright
        if not self._alive():
            self._start()
        if self._playwright is None:
            self._playwright = shared_playwright()
        # v52: a stuck tab used to be followed by a brand-new connection to the browser while the old one stayed open for good (one more
        # pile of objects each time). The connection that still works is kept; only a dead one is let go.
        keep = False
        try:
            keep = self._browser is not None and self._browser.is_connected()
        except Exception:
            keep = False
        if not keep:
            if self._browser is not None:
                try:
                    self._browser.close()
                except Exception:
                    pass
            self._browser = self._playwright.chromium.connect_over_cdp(f"http://127.0.0.1:{self.port}")
        self._page = self._open_page()

    def _open_page(self):
        """A new tab in the browser's own (saved-profile) window - used when the browser is first connected and when an old tab is replaced."""
        ctx = self._browser.contexts[0] if self._browser.contexts else self._browser.new_context()
        page = ctx.new_page()
        self._navs = 0
        self._page_born = time.time()
        if self.block_media:
            try:
                page.route("**/*", lambda route: route.abort()
                           if route.request.resource_type in ("image", "media", "font")
                           else route.continue_())
            except Exception:
                pass

        def _on_resp(r, _self=self):
            _recon_note(_self, r)
            try:
                cap = getattr(_self, "capture", None)
                if cap and cap in r.url:
                    _self.captured.append(r.url)
            except Exception:
                pass
            try:
                if r.request.resource_type == "document" and _self.last_response is None:
                    _self.last_response = _resp_text(r)
                u = r.url
                if (r.request.resource_type in ("xhr", "fetch") and r.status == 200
                        and "pricebl" in u.lower() and "skus=" in u):
                    _self.learned_api = u
            except Exception:
                pass
        self._on_resp_fn = _on_resp
        _sync_listener(self, page, _on_resp)         # v52: only while something needs every answer (Best Buy, the recorder, Target's capture)
        return page

    def _fresh_page(self):
        """v52: replaces an old tab by a new one in the same browser (saved profile, cookies and logins stay). See PAGE_NAVS."""
        if self._page is None or self._browser is None:
            return False
        old = self._page
        try:
            new = self._open_page()
        except Exception:
            return False
        self._page = new
        self.__dict__.pop("_pre", None)
        try:
            old.close()
        except Exception:
            pass
        _FRESH["tabs"] += 1
        _FRESH["last"] = time.time()
        return True

    def warm(self, url, timeout=25.0):
        """Opens one real page on the store's own site (like opening a tab)
        so later small data requests are made from inside it, the way the
        site itself makes them. Returns None if it worked, else an error text."""
        html, err = self.fetch(url, timeout=timeout)
        if err:
            return err
        self.warm_at = time.time()
        self.warm_url = url
        return None

    def page_json(self, api_url, timeout=12.0, credentials="include"):
        """One small data request made from inside the already-open store
        page. Returns (http_status, text, error)."""
        if self._page is None:
            return None, None, "no open page"
        js = """async (u) => {
            const c = new AbortController();
            const t = setTimeout(() => c.abort(), %d);
            try {
                const r = await fetch(u, {credentials: '%s', signal: c.signal,
                                          headers: {'Accept': 'application/json'}});
                const body = await r.text();
                return {status: r.status, text: body};
            } catch (e) { return {status: 0, text: '', error: String(e).slice(0, 120)}; }
            finally { clearTimeout(t); }
        }""" % (int(timeout * 1000), credentials)
        try:
            res = self._page.evaluate(js, api_url)
        except Exception as e:
            return None, None, str(e).split("\n")[0][:120]
        if res.get("error"):
            return 0, "", res["error"]
        return res.get("status"), res.get("text"), None

    def clear_cache(self):
        """v52: empties this browser's page cache (NOT cookies, NOT logins) so a browser that stays open for weeks does not keep growing.
        Chrome / Edge / Playwright's Chromium only (Firefox-type browsers have no such switch; they are restarted by the regular upkeep)."""
        page = self._page
        if page is None or getattr(self, "engine", "") in ("camoufox", "firefox"):
            return False
        try:
            sess = page.context.new_cdp_session(page)
            try:
                sess.send("Network.clearBrowserCache")
            finally:
                try:
                    sess.detach()
                except Exception:
                    pass
            return True
        except Exception:
            return False

    def light_prefetch(self, urls, timeout=12.0, gap_ms=None):
        """v51: several product pages asked for AT ONCE from the open store tab (see _LIGHT_MANY_JS); light_get hands the answers out."""
        page = self._page
        if page is None or not urls:
            return 0
        try:
            m = re.match(r"https?://[^/]+", urls[0])
            origin = m.group(0).lower() if m else ""
            cur = (page.url or "").lower()
            if not origin or not cur.startswith(origin):
                return 0
            res = page.evaluate(_LIGHT_MANY_JS, [list(urls), int(timeout * 1000), PRE_GAP_MS if gap_ms is None else int(gap_ms), False,
                                                 "application/json", True])
        except Exception:
            return 0
        pre = self.__dict__.setdefault("_pre", {})
        now = time.time()
        for r in res or []:
            try:
                pre[r["u"]] = (now, _light_interpret(r, origin))
            except Exception:
                pass
        return len(pre)

    def light_get(self, url, timeout=12.0, same_origin=True, min_len=3000):
        """Same idea as BrowserFetcher.light_get: one request made from inside the already-open store tab
        (cookies included, nothing drawn). Returns (text, None) or (None, why_not)."""
        _early = _pre_take(self, url)
        if _early is not None:
            return _early
        page = self._page
        if page is None:
            return None, "no page open yet"
        try:
            m = re.match(r"https?://[^/]+", url)
            origin = m.group(0).lower() if m else ""
            cur = (page.url or "").lower()
            if not cur.startswith("http"):
                return None, "the open tab is not on a store page"
            if same_origin and not cur.startswith(origin):
                return None, "the open tab is not on this store's site"
        except Exception as e:
            return None, str(e).split("\n")[0][:100]
        code, text, err = self.page_json(url, timeout=timeout)
        if err and not same_origin:
            # the store's data service may not accept requests that carry cookies from another address: ask without
            code, text, err = self.page_json(url, timeout=timeout, credentials="omit")
        if err:
            return None, err
        if code != 200:
            return None, f"HTTP {code}"
        if not text or len(text) < min_len:
            return None, "answer too short"
        return text, None

    supports_ready = True      # v52: fetch(url, ready=f) may return as soon as f(html) is true (see _wait_ready)

    def fetch(self, url, timeout=25.0, ready=None):
        try:
            self._ensure()
            if _tab_is_old(self):
                self._fresh_page()      # v52: a new tab in the same browser (see PAGE_NAVS)
        except Exception as e:
            self._drop()
            self.start_failures += 1
            return None, f"real Chrome could not be started: {str(e)[:150]}"
        self.start_failures = 0
        self.last_response = None
        self.captured = []
        t0 = time.time()
        _recon_prepare(self, url)
        _sync_listener(self, self._page, self._on_resp_fn)       # v52: only while something needs every answer
        self.dirty = True            # a heavy product page is open now (see park())
        try:
            self._navs += 1
            _resp = self._page.goto(url, timeout=timeout * 1000, wait_until="commit")
            if self.last_response is None:
                self.last_response = _resp_text(_resp)
            html = _wait_ready(self._page, ready, 8000, 2000)
            if html is None:
                try:
                    self._page.wait_for_load_state("domcontentloaded", timeout=8000)
                except Exception:
                    pass
                try:
                    self._page.wait_for_load_state("networkidle", timeout=2000)
                except Exception:
                    pass
                html = self._page.content()
            if len(html) < 3000 and not _refusal_page(html):
                raise RuntimeError("page did not load (almost empty)")
            html = _recon_finish(self, self._page, url, html)
            return html, None
        except Exception as e:
            where = self.last_response
            msg = (str(e).split("\n")[0][:120] + f" | after {time.time() - t0:.0f}s the store had "
                   + (f"answered: {where}" if where else "sent NOTHING back (no response at all)"))
            # a stuck tab: replace it next time
            try:
                self._page.close()
            except Exception:
                pass
            self._page = None
            return None, msg

    def rotate(self, reason=""):
        """Not getting through: restart the browser (and try the other
        installed one - Chrome <-> Edge - next time)."""
        self.history.append(f"{self.engine}: failed ({reason[:80]})")
        self.history = self.history[-12:]
        self._exe_idx += 1
        if "hung up" in reason or "ERR_HTTP2" in reason or "ERR_CONNECTION" in reason:
            # a store that resets the modern (HTTP/2) connection is often fine with the plain older one: alternate between the two
            self._no_http2 = not getattr(self, "_no_http2", False)
            self.history.append("connection style: " + ("plain HTTP/1.1" if self._no_http2 else "HTTP/2"))
        self._drop(kill=True)
        try:
            self._ensure()
        except Exception:
            return None
        return self.engine

    def _drop(self, kill=False):
        try:
            if self._page:
                self._page.close()
        except Exception:
            pass
        self._page = None
        try:
            if self._browser:
                self._browser.close()       # v52: also without `kill` - a connection that is only forgotten stays open (and keeps its objects) for good
        except Exception:
            pass
        self._browser = None
        if kill and self._proc:
            try:
                self._proc.terminate()
            except Exception:
                pass
            self._proc = None
            time.sleep(1.0)

    # ---- sleeping between checks ------------------------------------------------------
    # A store's product page keeps running its own scripts (trackers, ads, bot checks) the whole time it stays open,
    # which is most of what a quiet browser costs. Between checks the tab is switched to the store's robots.txt (a plain
    # text page of the SAME site: no scripts, cookies stay, the lighter in-tab requests still work). The next full check
    # simply loads the product page again. Three failures in a row turn this off by itself.
    def park(self):
        page = self._page
        if page is None or getattr(self, "_park_off", False) or not getattr(self, "dirty", False):
            return False
        try:
            self.dirty = False
            cur = page.url or ""
            m = re.match(r"https?://[^/]+", cur)
            if not m or cur.lower().endswith("/robots.txt"):
                return False
            page.goto(m.group(0) + "/robots.txt", timeout=8000, wait_until="commit")
            self._navs = getattr(self, "_navs", 0) + 1
            self.parked_n = getattr(self, "parked_n", 0) + 1
            self._park_fail = 0
            return True
        except Exception:
            self._park_fail = getattr(self, "_park_fail", 0) + 1
            if self._park_fail >= 3:
                self._park_off = True
            return False

    def close(self):
        self._drop(kill=True)
        if self._playwright:
            release_playwright(self._playwright)
            self._playwright = None
        if self._proc:
            try:
                self._proc.terminate()
            except Exception:
                pass
            self._proc = None


class _CtxAsBrowser:
    """(v76) Lets a patchright window look like the connected browser RealChromeFetcher expects."""

    def __init__(self, ctx):
        self.ctx = ctx
        self._gone = False
        try:
            ctx.on("close", lambda *_: setattr(self, "_gone", True))
        except Exception:
            pass

    @property
    def contexts(self):
        return [self.ctx]

    def new_context(self):
        return self.ctx

    def is_connected(self):
        return not self._gone

    def close(self):
        self._gone = True
        try:
            self.ctx.close()
        except Exception:
            pass


class StealthChromeFetcher(RealChromeFetcher):
    """v76 "Hidden Chrome": the PC's own Chrome (Edge when there is no Chrome), started and driven through patchright, which removes the
    usual signs of a program-driven browser (the automation switch, the 'controlled by automated software' flag, the page-script hooks
    stores look for). Its own saved profile, parked off screen. Same calling convention as RealChromeFetcher; everything else (reading,
    small in-page data requests, parking, fresh tabs) is the same code."""

    def __init__(self, profile_dir="browser_profile_stealth", store="", block_media=False, **kw):
        RealChromeFetcher.__init__(self, profile_dir=profile_dir, port=0, store=store, block_media=block_media)
        self.engine = "stealth"
        self._spw = None

    def _alive(self):
        return self._browser is not None and self._browser.is_connected()

    def _start(self):
        raise RuntimeError("not used")

    def _ensure(self):
        if self._page is not None:
            return
        if self._browser is not None and not self._browser.is_connected():
            self._browser = None
        if self._browser is None:
            exe = RealChromeFetcher.exe_for("chrome") or RealChromeFetcher.exe_for("edge")
            if not exe:
                raise RuntimeError("no Chrome or Edge found on this PC")
            try:
                from patchright.sync_api import sync_playwright as _spw
            except ImportError:
                start_engine_install("stealth")
                raise RuntimeError("Hidden Chrome is not installed yet")
            if self._spw is None:
                self._spw = _spw().start()
            prof = self.profile_dir
            os.makedirs(prof, exist_ok=True)
            args = ["--window-position=-32000,-32000", "--window-size=1280,900", "--mute-audio",
                    "--disable-session-crashed-bubble", "--hide-crash-restore-bubble"]
            if getattr(self, "_no_http2", False):
                args.append("--disable-http2")
            try:
                args += json.loads(os.environ.get("RK_FETCH_EXTRA_ARGS") or "[]")      # (only the test lab sets this)
            except Exception:
                pass
            try:
                ctx = self._spw.chromium.launch_persistent_context(prof, executable_path=exe, headless=bool(os.environ.get("RK_CHROME_HEADLESS")),
                                                                   no_viewport=True, args=args)
            except Exception as e:
                note_launch("stealth", self.store, False, str(e))
                raise
            note_launch("stealth", self.store, True)
            with _FF_LOCK:
                STEALTH["state"] = "ready"
            self._browser = _CtxAsBrowser(ctx)
            for pg in list(ctx.pages):          # (the empty first tab)
                try:
                    if (pg.url or "").startswith("about:"):
                        self._spare = pg
                except Exception:
                    pass
        self._page = self._open_page()

    def rotate(self, reason=""):
        """Not getting through: a fresh start of the same Hidden Chrome (cookies kept in its profile)."""
        self.history.append(f"{self.engine}: failed ({reason[:80]})")
        self.history = self.history[-12:]
        if "hung up" in reason or "ERR_HTTP2" in reason or "ERR_CONNECTION" in reason:
            self._no_http2 = not getattr(self, "_no_http2", False)
        self._drop(kill=True)
        try:
            self._ensure()
        except Exception:
            return None
        return self.engine

    def close(self):
        self._drop(kill=True)
        if self._spw is not None:
            try:
                self._spw.stop()
            except Exception:
                pass
            self._spw = None


def _count_reads(cls, names):
    """Every page / data read by these methods is counted per browser and per store (see note_page)."""
    for n in names:
        orig = getattr(cls, n, None)
        if orig is None or getattr(orig, "_rk_counted", False):
            continue

        def make(orig):
            def counted(self, *a, **k):
                r = orig(self, *a, **k)
                try:
                    err = r[1] if isinstance(r, tuple) and len(r) > 1 else None
                    note_page(getattr(self, "engine", None) or "chrome", getattr(self, "store", ""), not err, err or "")
                except Exception:
                    pass
                return r
            counted._rk_counted = True
            return counted
        setattr(cls, n, make(orig))


_count_reads(BrowserFetcher, ("fetch", "light_get"))
_count_reads(RealChromeFetcher, ("fetch", "light_get", "page_json"))
_count_reads(StealthChromeFetcher, ("fetch", "light_get", "page_json"))
