"""Real product pictures for the table (free: the picture each store already shows on its own product page).

For every row of the table the program opens the product pages it already watches (plain web requests, one at a time, slowly),
finds the main product picture (the page's "og:image" / "twitter:image" / JSON-LD image, or Amazon's own big-picture field),
asks the store's picture server for a SMALL version, shrinks it to a thumbnail and keeps it in  icons/auto/.
A picture you put into  icons/  yourself (named like  the_hobbit_box.png ) always wins. If no store gives a picture, the table
keeps its drawn icon, and the program tries again later (never more than a few requests per hour).
"""
import io
import json
import os
import re
import threading
import time
import urllib.request
import urllib.parse

VERSION = "v119"
AUTO_DIR = os.path.join("icons", "auto")
THUMB_PX = 96                       # longest side of the kept picture
MAX_PAGE = 3_000_000                # bytes of a page to look at
MAX_IMG = 3_000_000                 # bytes of a picture to keep
TRY_AGAIN = (600.0, 3600.0, 21600.0)    # wait after the 1st / 2nd / 3rd+ failed attempt for a row
UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) "
      "Chrome/124.0 Safari/537.36")
OWN_FETCH_AFTER = 120.0          # seconds after start before the program opens product pages itself (the checkers usually supply the picture address first)
NO_OWN_PAGE = ("walmart",)       # stores whose pages this helper never requests itself (fragile); their pictures come from pages the checkers load
_T0 = [__import__("time").time()]
STORE_TRY_ORDER = ["target", "bestbuy", "gamestop", "walmart", "amazon"]     # the friendliest pages first

_state = {"tries": {}, "thread": None, "last": "", "made": 0, "cands": {}, "force": set()}      # row key -> (failures, next_try_time)
_lock = threading.Lock()
_wake = threading.Event()


def slug(text):
    return re.sub(r"[^a-z0-9]+", "_", (text or "").lower()).strip("_")


def base_name(key):
    theme, _, kind = key.partition("|")
    return slug(theme) + "_" + (kind or "box")


def find_file(key, folders=("icons", AUTO_DIR), exts=(".png", ".jpg", ".jpeg", ".webp", ".gif", ".svg")):
    """-> relative path under icons/ ('x.png' or 'auto/x.png') of the picture for this row, or None. Your own file wins."""
    b = base_name(key)
    for folder in folders:
        for e in exts:
            if os.path.isfile(os.path.join(folder, b + e)):
                return (b + e) if folder == "icons" else ("auto/" + b + e)
    return None


# ---------------------------------------------------------------- finding the picture on a page
def _attrs(tag):
    out = {}
    for m in re.finditer(r'([a-zA-Z_:-]+)\s*=\s*(?:"([^"]*)"|\'([^\']*)\')', tag):
        out[m.group(1).lower()] = (m.group(2) if m.group(2) is not None else m.group(3))
    return out


def _unescape(u):
    return (u or "").replace("&amp;", "&").replace("\\u0026", "&").replace("\\/", "/").strip()


def picture_urls(html, page_url=""):
    """Candidate picture addresses found in a product page, best first."""
    found = []
    for m in re.finditer(r"<meta\b[^>]*>", html or "", re.I):
        a = _attrs(m.group(0))
        key = (a.get("property") or a.get("name") or a.get("itemprop") or "").lower()
        if key in ("og:image", "og:image:url", "og:image:secure_url", "twitter:image", "twitter:image:src", "image") and a.get("content"):
            found.append(_unescape(a["content"]))
    for m in re.finditer(r'<link\b[^>]*rel\s*=\s*["\']image_src["\'][^>]*>', html or "", re.I):
        a = _attrs(m.group(0))
        if a.get("href"):
            found.append(_unescape(a["href"]))
    # Amazon puts the big pictures in the page's data
    for pat in (r'"hiRes"\s*:\s*"(https?:[^"]+)"', r'"large"\s*:\s*"(https?:[^"]+)"', r'data-old-hires\s*=\s*"(https:[^"]+)"',
                r'id="landingImage"[^>]*?src\s*=\s*"(https:[^"]+)"'):
        for m in re.finditer(pat, html or ""):
            found.append(_unescape(m.group(1)))
    # JSON-LD
    for m in re.finditer(r'<script[^>]*application/ld\+json[^>]*>(.*?)</script>', html or "", re.I | re.S):
        try:
            d = json.loads(m.group(1))
        except Exception:
            continue
        stack = [d]
        while stack:
            x = stack.pop()
            if isinstance(x, list):
                stack.extend(x)
            elif isinstance(x, dict):
                im = x.get("image")
                if isinstance(im, str):
                    found.append(im)
                elif isinstance(im, list):
                    found.extend(i for i in im if isinstance(i, str))
                elif isinstance(im, dict) and isinstance(im.get("url"), str):
                    found.append(im["url"])
                stack.extend(v for v in x.values() if isinstance(v, (dict, list)))
    out, seen = [], set()
    for u in found:
        if page_url:
            u = urllib.parse.urljoin(page_url, u)
        low = u.lower()
        if not low.startswith("http") or low in seen:
            continue
        if any(w in low for w in ("logo", "sprite", "placeholder", "unavailable.png", "favicon", "/icons/", "default-share", "social-share")):
            continue
        seen.add(low)
        out.append(u)
    return out


def page_title(html):
    """The product name a page shows (og:title, Amazon's productTitle, <h1>, <title>) - '' when none is found."""
    h = html or ""
    for m in re.finditer(r"<meta\b[^>]*>", h[:400000], re.I):
        a = _attrs(m.group(0))
        if (a.get("property") or a.get("name") or "").lower() in ("og:title", "twitter:title") and a.get("content"):
            return _unescape(a["content"])[:300]
    m = re.search(r'id="productTitle"[^>]*>(.*?)</span>', h, re.I | re.S)
    if m:
        return re.sub(r"<[^>]+>", " ", m.group(1)).strip()[:300]
    m = re.search(r"<h1\b[^>]*>(.*?)</h1>", h, re.I | re.S)
    if m:
        t = re.sub(r"<[^>]+>", " ", m.group(1)).strip()
        if t:
            return _unescape(t)[:300]
    m = re.search(r"<title[^>]*>(.*?)</title>", h, re.I | re.S)
    return _unescape(re.sub(r"<[^>]+>", " ", m.group(1)).strip())[:300] if m else ""


_BOXW = re.compile(r"\b(box|boxes|display|case|tin)\b", re.I)
_PACKW = re.compile(r"\b(booster\s+pack|pack|packs|blister|sleeved)\b", re.I)


def title_fits(kind, title):
    """v46: does this page's product name fit the row (a box row must not take a single pack's picture, and the other way round)?
    Unknown (no title) counts as fits - the picture is then judged by its shape."""
    t = (title or "").strip()
    if not t:
        return True
    k = (kind or "box").lower()
    if k == "pack":
        return not re.search(r"\b(box|boxes|display|case|bundle|deck)\b", t, re.I)
    if k.endswith("box") or k == "box":
        if _BOXW.search(t):
            return True
        return not _PACKW.search(t) and not re.search(r"\bbundle\b", t, re.I)
    if k == "bundle":
        return bool(re.search(r"\bbundle\b", t, re.I))
    return True


def shape_fits(kind, data):
    """v46: a box picture is not a tall thin pack. Needs Pillow; without it the shape is not judged."""
    k = (kind or "box").lower()
    if not (k.endswith("box") or k == "box"):
        return True
    try:
        from PIL import Image
        w, h = Image.open(io.BytesIO(data)).size
        return not (w > 0 and h / float(w) > 1.6)
    except Exception:
        return True


def small_version(u):
    """Asks the store's picture server for a small picture where the address allows it (less to download)."""
    try:
        if "scene7.com" in u:                                    # Target
            base = u.split("?")[0]
            return base + "?wid=%d&hei=%d&qlt=80&fmt=jpeg" % (THUMB_PX * 2, THUMB_PX * 2)
        if "media-amazon.com" in u or "images-na.ssl-images-amazon" in u:        # Amazon: ...._AC_SL1500_.jpg -> ..._AC_SL192_.jpg
            m = re.match(r"(.*?/images/I/[^./]+)(\._[^/]*_)?(\.[a-zA-Z]+)$", u)
            if m:
                return m.group(1) + "._AC_SL%d_" % (THUMB_PX * 2) + m.group(3)
        if "bbystatic.com" in u:                                 # Best Buy
            u2 = re.sub(r";maxHeight=\d+", ";maxHeight=%d" % (THUMB_PX * 2), u)
            u2 = re.sub(r";maxWidth=\d+", ";maxWidth=%d" % (THUMB_PX * 2), u2)
            return u2
        if "walmartimages.com" in u:
            u2 = re.sub(r"odnHeight=\d+", "odnHeight=%d" % (THUMB_PX * 2), u)
            return re.sub(r"odnWidth=\d+", "odnWidth=%d" % (THUMB_PX * 2), u2)
    except Exception:
        pass
    return u


# ---------------------------------------------------------------- downloading
def _get(url, limit, timeout=15.0, referer=None):
    req = urllib.request.Request(url, headers={
        "User-Agent": UA, "Accept": "text/html,application/xhtml+xml,image/avif,image/webp,image/*,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.9", **({"Referer": referer} if referer else {})})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        body = r.read(limit + 1)
        if len(body) > limit:
            raise ValueError("too big")
        return body, (r.headers.get("Content-Type") or "").lower(), r.geturl()


def _kind_of_image(b):
    if b[:8] == b"\x89PNG\r\n\x1a\n":
        return ".png"
    if b[:3] == b"\xff\xd8\xff":
        return ".jpg"
    if b[:6] in (b"GIF87a", b"GIF89a"):
        return ".gif"
    if b[:4] == b"RIFF" and b[8:12] == b"WEBP":
        return ".webp"
    return None


def make_thumb(data):
    """-> (bytes, extension). Shrinks with Pillow when it is installed, otherwise keeps the picture as it came."""
    ext = _kind_of_image(data)
    if ext is None:
        raise ValueError("not a picture")
    try:
        from PIL import Image
        im = Image.open(io.BytesIO(data))
        im.load()
        im = im.convert("RGBA") if im.mode in ("P", "LA", "RGBA") else im.convert("RGB")
        im.thumbnail((THUMB_PX, THUMB_PX))
        buf = io.BytesIO()
        if im.mode == "RGBA":
            im.save(buf, "PNG", optimize=True)
            return buf.getvalue(), ".png"
        im.save(buf, "JPEG", quality=85, optimize=True)
        return buf.getvalue(), ".jpg"
    except ImportError:
        if len(data) > 400_000:
            raise ValueError("picture too large and no way to shrink it (pip install pillow)")
        return data, ext


def note_page(key, store, url, html):
    """Called by the checkers with a product page they already loaded (free: no extra page request). Remembers where that
    page says its picture is, so the picture can be fetched from the store's picture server."""
    c = picture_urls(html, url)
    if c:
        title = page_title(html)
        if not title_fits(key.partition("|")[2], title):
            with _lock:
                _state["rejected"] = _state.get("rejected", 0) + 1
                _state["last"] = f"{key}: {store} page is '{title[:50]}' - not the right product shape, picture not used"
            return 0
        with _lock:
            _state["cands"].setdefault(key, {})[store] = (url, c[:4])
    return len(c)


def _save(key, store, data, ext):
    os.makedirs(AUTO_DIR, exist_ok=True)
    name = base_name(key) + ext
    for old in os.listdir(AUTO_DIR):                    # one file per row
        if old.startswith(base_name(key) + ".") and old != name:
            try:
                os.remove(os.path.join(AUTO_DIR, old))
            except Exception:
                pass
    tmp = os.path.join(AUTO_DIR, name + ".tmp")
    with open(tmp, "wb") as f:
        f.write(data)
    os.replace(tmp, os.path.join(AUTO_DIR, name))
    _state["last"] = f"{key}: picture from {store}"
    return "auto/" + name


def _download_first(key, store, page_url, cands, why):
    for cu in cands[:4]:
        for u in dict.fromkeys([small_version(cu), cu]):
            try:
                img, ct, _ = _get(u, MAX_IMG, referer=page_url)
                if not shape_fits(key.partition("|")[2], img):
                    why.append(f"{store}: picture is a tall thin pack, not a box")
                    break
                data, ext = make_thumb(img)
            except Exception as e:
                why.append(f"{store}: picture {str(e)[:50]}")
                continue
            return _save(key, store, data, ext)
    return None


def request(key):
    """A product or link was just added to this row: look for its picture right away (not at the next sweep), on any store's page."""
    with _lock:
        _state["tries"].pop(key, None)
        _state["force"].add(key)
    _wake.set()


def forget(key):
    """The kept picture of this row was wrong (it came from another product's page): delete it and fetch it again."""
    b = base_name(key)
    try:
        for f in os.listdir(AUTO_DIR):
            if f.startswith(b + "."):
                os.remove(os.path.join(AUTO_DIR, f))
    except OSError:
        pass
    request(key)


def revision():
    """Changes whenever a picture file is added or replaced (the page watches this to redraw the table by itself)."""
    try:
        return _state["made"] * 1000 + len(os.listdir(AUTO_DIR))
    except OSError:
        return _state["made"] * 1000


def rename_row(old_key, new_key):
    """A row got a new key (older rows were renamed by an update): keep its picture."""
    ob, nb = base_name(old_key), base_name(new_key)
    if ob == nb or not os.path.isdir(AUTO_DIR):
        return
    for f in os.listdir(AUTO_DIR):
        if f.startswith(ob + ".") and not any(x.startswith(nb + ".") for x in os.listdir(AUTO_DIR)):
            try:
                os.replace(os.path.join(AUTO_DIR, f), os.path.join(AUTO_DIR, nb + os.path.splitext(f)[1]))
            except OSError:
                pass


def fetch_row_picture(key, links, log_fn=None, own=True, allow_all=False):
    """links: [(store, url), ...] for this row. -> relative file name ('auto/x.jpg') or None.
    First the picture addresses the checkers already saw on pages they loaded; then the product pages themselves."""
    why = []
    # v58: TCGplayer's catalogue photo first - one clean photo per exact product (the stores' pages often show other items,
    # banners or a single pack). Its address comes straight from the TCG link's product number; no page is opened.
    for store, url in links:
        if store != "tcg":
            continue
        m = re.search(r"/product/(\d+)(?:/([^?#]*))?", url or "")
        if not m:
            continue
        slugtxt = (m.group(2) or "").replace("-", " ")
        theme = key.partition("|")[0]
        if slugtxt and (not title_fits(key.partition("|")[2], slugtxt) or not all(w in slugtxt.lower() for w in re.findall(r"[a-z0-9]+", theme.lower())[:3])):
            why.append("tcg: the TCG link's name does not fit this row")
            continue
        pid = m.group(1)
        for u in (f"https://tcgplayer-cdn.tcgplayer.com/product/{pid}_in_200x200.jpg", f"https://tcgplayer-cdn.tcgplayer.com/product/{pid}_200w.jpg",
                  f"https://tcgplayer-cdn.tcgplayer.com/product/{pid}_in_1000x1000.jpg"):
            try:
                img, ct, _ = _get(u, MAX_IMG, referer="https://www.tcgplayer.com/")
                if len(img) < 1500:
                    continue
                data, ext = make_thumb(img)
                return _save(key, "tcg", data, ext)
            except Exception as e:
                why.append(f"tcg: picture {str(e)[:50]}")
    with _lock:
        seen = dict(_state["cands"].get(key, {}))
    for store, (url, cands) in sorted(seen.items(), key=lambda kv: STORE_TRY_ORDER.index(kv[0]) if kv[0] in STORE_TRY_ORDER else 99):
        got = _download_first(key, store, url, cands, why)
        if got:
            return got
    links = sorted(links, key=lambda sl: STORE_TRY_ORDER.index(sl[0]) if sl[0] in STORE_TRY_ORDER else 99)
    for store, url in links:
        if store in seen or not own or (store in NO_OWN_PAGE and not allow_all):
            continue
        try:
            body, ctype, final = _get(url, MAX_PAGE)
            html = body.decode("utf-8", "replace")
        except Exception as e:
            why.append(f"{store}: page {str(e)[:50]}")
            continue
        cands = picture_urls(html, final or url)
        if not cands:
            why.append(f"{store}: no picture in the page")
            continue
        if not title_fits(key.partition("|")[2], page_title(html)):
            why.append(f"{store}: page is a different shape of product")
            continue
        got = _download_first(key, store, url, cands, why)
        if got:
            return got
    _state["last"] = f"{key}: none ({'; '.join(why[:4])})"
    return None


def rows_from(targets):
    """{row key: [(store, url), ...]} for every active link."""
    import matrix
    rows = {}
    for t in targets:
        if not t.get("active", True) or not t.get("url"):
            continue
        rows.setdefault(matrix.key_of(t), []).append((matrix.store_of(t), t["url"]))
    return rows


def pass_once(targets, log_fn=None, pause=3.0, stop=None, now=None):
    """One sweep: tries every row that has no picture yet and is due for a (re)try. Returns how many pictures were made."""
    made = 0
    now = now or time.time()
    with _lock:
        forced_now = set(_state["force"])
    for key, links in sorted(rows_from(targets).items(), key=lambda kv: kv[0] not in forced_now):     # rows you just added first
        if stop is not None and stop.is_set():
            break
        if find_file(key):
            continue
        with _lock:
            fails, nxt = _state["tries"].get(key, (0, 0.0))
        if now < nxt:
            continue
        got = None
        with _lock:
            forced = key in _state["force"]
            _state["force"].discard(key)
        try:
            got = fetch_row_picture(key, links, log_fn, own=forced or (time.time() - _T0[0] >= OWN_FETCH_AFTER), allow_all=forced)
        except Exception as e:
            _state["last"] = f"{key}: error {str(e)[:60]}"
        with _lock:
            if got:
                _state["tries"].pop(key, None)
                _state["made"] += 1
                made += 1
            else:
                f = fails + 1
                _state["tries"][key] = (f, time.time() + TRY_AGAIN[min(f, len(TRY_AGAIN)) - 1])
        if log_fn and got:
            log_fn(f"[pictures] {key}: product picture saved ({got}).")
        if stop is not None:
            if stop.wait(pause):
                break
        else:
            time.sleep(pause)
    return made


def _purge_once(tag=".v46_shapes"):
    """v46, one time: pictures kept so far were not checked against the product's shape (box or single pack), so they are fetched
    again with the check. Pictures you put into icons/ yourself are never touched."""
    marker = os.path.join(AUTO_DIR, tag)
    try:
        if os.path.exists(marker):
            return 0
        n = 0
        if os.path.isdir(AUTO_DIR):
            for f in os.listdir(AUTO_DIR):
                if f.startswith("."):
                    continue
                try:
                    os.remove(os.path.join(AUTO_DIR, f))
                    n += 1
                except OSError:
                    pass
        os.makedirs(AUTO_DIR, exist_ok=True)
        with open(marker, "w") as fh:
            fh.write("v46\n")
        return n
    except Exception:
        return 0


def start(get_targets, log_fn=None, every=90.0):
    """Background helper: now and every `every` seconds, looks for rows that still have no picture. Light: a few web requests."""
    with _lock:
        t = _state.get("thread")
        if t is not None and t.is_alive():
            return t
    stop = threading.Event()
    _purge_once()
    _purge_once(".v58_tcg_first")          # v58: every downloaded picture is fetched again, TCGplayer's catalogue photo first

    def loop():
        time.sleep(8.0)                      # let the program settle first
        while not stop.is_set():
            try:
                pass_once(get_targets(), log_fn, stop=stop)
            except Exception as e:
                _state["last"] = f"error {str(e)[:60]}"
            _wake.wait(every)
            _wake.clear()
    th = threading.Thread(target=loop, daemon=True, name="pictures")
    th.start()
    _state["thread"], _state["stop"] = th, stop
    return th


def summary(targets=None):
    rows = rows_from(targets or []) if targets else {}
    have = sum(1 for k in rows if find_file(k))
    own = sum(1 for k in rows if find_file(k) and not find_file(k).startswith("auto/"))
    with _lock:
        pending = {k: v for k, v in _state["tries"].items()}
    txt = f"{have} of {len(rows)} product rows have a picture ({own} yours, {have - own} downloaded); last: {_state['last'] or 'nothing tried yet'}"
    if pending:
        txt += "; waiting to retry: " + ", ".join(f"{k} (failed {v[0]}x)" for k, v in list(pending.items())[:8])
    return txt
