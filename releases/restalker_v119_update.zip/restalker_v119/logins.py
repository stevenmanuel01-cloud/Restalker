"""Restalker v90 - your store sign-ins, saved so every browser stays signed in by itself (owner 2026-11-02: "I just want it to already be
signed in and not ask me multiple times per session. The program should be able to save my login information and/or log me in
automatically every time").

  - you type each store's e-mail and password once in Restalker's page (Sign-ins (top bar)); they are saved ENCRYPTED with Windows'
    own protection (DPAPI, the same as the card code): only your Windows account on this PC can read them back;
  - they are never written to the log, the diagnostics, page samples or any file in plain text, never shown on the page again, and
    never put anywhere except into the sign-in page of THAT store (the page's own address is checked first: amazon.com for Amazon, ...);
  - a browser that finds itself signed out signs itself back in (one try per store and browser every 30 minutes - never again and
    again, so a store never locks your account);
  - a store that asks for more than the password (a code sent to your phone / e-mail, "verify it's you", a puzzle) is NEVER answered:
    that browser tells you once, and the others go on.
Without Windows' protection (not Windows) they are kept in memory only, until the program closes.
"""
import json
import os
import threading

VERSION = "v119"
HERE = os.path.dirname(os.path.abspath(__file__))
FILE = os.path.join(HERE, "store_logins.bin")
STORES = ("amazon", "bestbuy", "target", "walmart", "gamestop")
_lock = threading.Lock()
_mem = {"data": {}, "loaded": False}


def _dpapi(data, protect):
    try:
        import cardcode
        return cardcode._dpapi(data, protect)
    except Exception:
        return None


def _load():
    if _mem["loaded"]:
        return
    _mem["loaded"] = True
    try:
        raw = open(FILE, "rb").read()
    except OSError:
        return
    plain = _dpapi(raw, False)
    try:
        d = json.loads(plain.decode("utf-8")) if plain else {}
        _mem["data"] = {k: v for k, v in d.items() if k in STORES and isinstance(v, dict) and v.get("email") and v.get("password")}
    except Exception:
        _mem["data"] = {}


def _write():
    enc = _dpapi(json.dumps(_mem["data"]).encode("utf-8"), True)
    if not enc:
        return False
    try:
        tmp = FILE + ".tmp"
        with open(tmp, "wb") as f:
            f.write(enc)
        os.replace(tmp, FILE)
        return True
    except OSError:
        return False


def save(store, email, password):
    store = str(store or "").lower()
    email, password = str(email or "").strip(), str(password or "")
    if store not in STORES:
        return {"ok": False, "reason": "unknown store"}
    if len(email) < 3 or len(password) < 1:
        return {"ok": False, "reason": "type the e-mail (or phone number) and the password of your " + store + " account"}
    with _lock:
        _load()
        _mem["data"][store] = {"email": email, "password": password}
        disk = _write()
    return {"ok": True, "saved_to_disk": disk}


def remove(store):
    with _lock:
        _load()
        _mem["data"].pop(str(store or "").lower(), None)
        if _mem["data"]:
            _write()
        else:
            try:
                os.remove(FILE)
            except OSError:
                pass
    return {"ok": True}


def get(store):
    """(email, password) for a store's own sign-in page, or None."""
    with _lock:
        _load()
        v = _mem["data"].get(str(store or "").lower())
        return (v["email"], v["password"]) if v else None


def status():
    """What the page may show: which stores have a saved sign-in (never the password; the e-mail only shortened)."""
    with _lock:
        _load()
        out = {}
        for s in STORES:
            v = _mem["data"].get(s)
            if v:
                e = v["email"]
                at = e.find("@")
                short = (e[:2] + "***" + e[at:]) if at > 2 else (e[:2] + "***")
                out[s] = {"saved": True, "email": short}
            else:
                out[s] = {"saved": False}
        return {"stores": out, "on_disk": os.path.exists(FILE), "protected": os.name == "nt"}
