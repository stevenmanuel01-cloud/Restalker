"""Restalker v77 - the OTHER buying browsers (your rule, 2026-10-29: "all available BROWSERS for each store ... are all trying to checkout
at the same time. The first browser success wins").

Besides the buying browser (built-in Chromium with the buying engine), the program checks out with every other browser on this PC:
your Google Chrome (or Edge), Firefox and Camoufox - each with its OWN profile (you sign in to the stores once in each). When a restock
is found they all open the product page at the same moment. ONE of a product is still kept:
  - a store keeps one cart per account (shared by every browser signed in to it), so the cart of a store is used by ONE browser at a
    time - the others wait ready on the product page and go on the moment it is free (taken through the buying engine, the same turn
    its own checkout takes);
  - Place order is pressed by one browser at a time for a product (the same turn as every store and Amazon); once it is bought, every
    other browser stops.
Every rule of the buying engine is kept here too: exact product, quantity 1, item price at or under the cap, tax, fees, shipping (never
store pickup), Buy now when it is there; a password / human check is never answered (that browser stops, you are told); the card
security code is typed only from your saved code (v77: cardcode.py, encrypted on this PC; none saved -> that browser stops); 5 failed tries in a row lock that browser for that
link. The page reading and pressing is done by the SAME page parts the buying engine uses (buyer_engine/bb_content.js and
store_content.js), put into the page by Playwright.
"""
import json
import os
import queue
import re
import secrets
import shutil
import subprocess
import threading
import time

VERSION = "v119"
HERE = os.path.dirname(os.path.abspath(__file__))
ENGINE_DIR = os.path.join(HERE, "buyer_engine")
KINDS = ("chrome", "edge", "stealth", "firefox", "camoufox")
NAMES = {"chrome": "Chrome", "edge": "Edge", "stealth": "Hidden Chrome", "firefox": "Firefox", "camoufox": "Camoufox", "chromium": "Chromium (test)"}
STORE_NAMES = {"bestbuy": "Best Buy", "target": "Target", "walmart": "Walmart", "gamestop": "GameStop", "amazon": "Amazon"}
STORES = {
    "bestbuy": {"origin": "https://www.bestbuy.com", "cart": "https://www.bestbuy.com/cart", "orders": "https://www.bestbuy.com/profile/ss/orders",
                "signin": "https://www.bestbuy.com/identity/global/signin", "part": "bb_content.js", "flag": "__RK_BB_CONTENT__",
                "checkout": r"bestbuy\.com/checkout/", "signin_rx": r"bestbuy\.com/identity/", "steps_first": False},
    "target": {"origin": "https://www.target.com", "cart": "https://www.target.com/cart", "orders": "https://www.target.com/orders",
               "signin": "https://www.target.com/account", "part": "store_content.js", "flag": "__RK_ST_CONTENT__",
               "checkout": r"target\.com/(co-review|checkout|co-cart)", "signin_rx": r"target\.com/(login|account/sign|co-login|gsp/login)|login\.target\.com",
               "steps_first": False},
    "walmart": {"origin": "https://www.walmart.com", "cart": "https://www.walmart.com/cart", "orders": "https://www.walmart.com/orders",
                "signin": "https://www.walmart.com/account/login", "part": "store_content.js", "flag": "__RK_ST_CONTENT__",
                "checkout": r"walmart\.com/checkout", "signin_rx": r"walmart\.com/(account/login|account/signin|identity)", "steps_first": False},
    "gamestop": {"origin": "https://www.gamestop.com", "cart": "https://www.gamestop.com/cart/", "orders": "https://www.gamestop.com/account/order-history/",
                 "signin": "https://www.gamestop.com/login/", "part": "store_content.js", "flag": "__RK_ST_CONTENT__",
                 "checkout": r"gamestop\.com/(mrt/)?(checkout|spcheckout)", "signin_rx": r"gamestop\.com/(login|account/login|signin)", "steps_first": True},
}
# v88 (owner 2026-11-01: "incorporate it as you have for all other stores"): these browsers BUY at Amazon too - with the buying
# browser's own Amazon checkout (buyer_engine/amz_part.js), Buy now only (never the shared cart), ONE order per product (the latch)
STORES["amazon"] = {"origin": "https://www.amazon.com", "cart": "https://www.amazon.com/gp/cart/view.html",
                    "orders": "https://www.amazon.com/gp/css/order-history", "signin": "https://www.amazon.com/gp/sign-in.html",
                    "part": "amz_part.js", "flag": "__RK_AMZ_PART__", "checkout": r"amazon\.com/(checkout|gp/buy|gp/checkoutportal)",
                    "signin_rx": r"amazon\.com/ap/(signin|mfa|cvf)", "steps_first": False}
READ_ORIGINS = {k: v["origin"] for k, v in STORES.items()}      # v81: sites these browsers may read data from for the sweepers
LOCK_AFTER = 10            # failed tries in a row (per browser and link) before that browser stops trying that link
TRIES_PER_RESTOCK = 10     # tries one browser makes for one restock, back to back
TAX_SHARE, FEES_MAX, SHIP_MAX = 0.12, 6.0, 20.0     # v78: tax checked against item + shipping (GameStop taxes shipping)
CONFIRM_WAIT = 90.0

LOG = None                 # set by amazon_buy: log(text)
COMMAND = None             # set by amazon_buy: command(dict, timeout) -> dict (the buying engine)
_workers = {}
_lock = threading.RLock()
_events = []               # the last steps of every browser (diagnostics)
_fails = {}                # (kind, key) -> [count, last time]


def _log(msg):
    try:
        if LOG:
            LOG("[buy-browsers] " + msg)
    except Exception:
        pass


_LIMIT_WORDS = re.compile(r"limit", re.I)


def _note(browser, key, step, **kw):
    with _lock:
        _events.append({"at": time.time(), "browser": browser, "key": key, "step": str(step)[:200], **kw})
        del _events[:-300]
    # v118 (Buy 2 / 3: "ensure that product limits govern"): a store's limit seen by this browser -> that store is left out for the rest
    words = " ".join(str(x) for x in (step, kw.get("reason") or ""))
    if _LIMIT_WORDS.search(words):
        def tell(k=key, w=words, b=browser):
            try:
                from amazon_buy import qty_limit_seen
                qty_limit_seen(k, b, w)
            except Exception:
                pass
        threading.Thread(target=tell, daemon=True, name="buy-limit").start()


# v97 (owner 2026-11-04: "toggle on and off all browser sources ... a user doesn't have the same computing power, they may elect to toggle a
# particular browser on and off to save CPU"): each of these browsers can be switched off on the Browsers tab - then it neither reads nor
# buys and is not started at all (kept in browsers_off.json). A checkout it is doing when you switch it off is finished first.
OFF_FILE = "browsers_off.json"
_closing = {}              # kind -> the Worker still closing after it was switched off (no second copy on the same profile meanwhile)


def off_kinds():
    try:
        with open(OFF_FILE, encoding="utf-8") as f:
            d = json.load(f)
        return {k for k in (d.get("off") or []) if k in KINDS}
    except Exception:
        return set()


def set_on(kind, on):
    """Switches one of these browsers on or off (at once). -> {"ok", "text"/"reason"}"""
    if kind not in KINDS:
        return {"ok": False, "reason": "unknown browser"}
    off = off_kinds()
    (off.discard if on else off.add)(kind)
    try:
        tmp = OFF_FILE + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump({"off": sorted(off)}, f)
        os.replace(tmp, OFF_FILE)
    except Exception as e:
        return {"ok": False, "reason": f"could not be saved: {str(e)[:80]}"}
    nm = NAMES.get(kind, kind)
    if not on:
        with _lock:
            w = _workers.pop(kind, None)
        if w is not None:
            w.state = "turned off"
            with _lock:
                w.pending.clear()
            _closing[kind] = w
            w.q.put(None)                        # (it ends after the checkout it may be doing now, then closes)
            _log(f"{nm} switched OFF by you - it " + ("finishes the checkout it is doing, then closes" if w.busy else "closes now") +
                 " and is not started again until you switch it on.")
        else:
            _log(f"{nm} switched OFF by you.")
        return {"ok": True, "text": f"{nm} is off" + (" (it finishes its checkout first)" if w is not None and w.busy else "") + "."}
    _log(f"{nm} switched ON by you.")
    if _started["on"]:
        start()
    return {"ok": True, "text": f"{nm} is on" + ("" if kind in enabled_kinds() else " - but it is not installed on this PC") + "."}


_started = {"on": False}


def enabled_kinds():
    """The browsers that take part: env RK_EXTRA_BUYERS (tests / your choice) or every one installed - minus those you switched off (v97)."""
    return [k for k in _enabled_kinds() if k not in off_kinds()]


def _enabled_kinds():
    env = os.environ.get("RK_EXTRA_BUYERS")
    if env is not None:
        return [k for k in env.split(",") if k.strip()]
    if os.environ.get("RK_NO_EXTRA_BUYERS") or os.environ.get("RK_TEST_NOEXIT"):
        return []
    out = []
    try:
        import browser_fetch
        if browser_fetch.RealChromeFetcher.exe_for("chrome"):
            out.append("chrome")
        if browser_fetch.RealChromeFetcher.exe_for("edge"):          # v76: Edge buys too, with its own sign-ins (not only when Chrome is missing)
            out.append("edge")
        if browser_fetch.stealth_ready():                              # v76: Hidden Chrome (your Chrome without the signs of a program)
            out.append("stealth")
        elif browser_fetch.INSTALLS.get("stealth", {}).get("state") in ("not installed yet",):
            browser_fetch.start_engine_install("stealth", LOG)
        for k in ("firefox", "camoufox"):
            if browser_fetch.INSTALLS.get(k, {}).get("state") == "ready" or _installed(k):
                out.append(k)
    except Exception:
        pass
    return out


def _installed(kind):
    try:
        if kind == "camoufox":
            import importlib.util
            return importlib.util.find_spec("camoufox") is not None
        if kind == "firefox":
            base = os.environ.get("PLAYWRIGHT_BROWSERS_PATH") or os.path.join(os.path.expanduser("~"), "AppData", "Local", "ms-playwright")
            return os.path.isdir(base) and any(n.startswith("firefox") for n in os.listdir(base))
    except Exception:
        return False
    return False


def _part_source(store, token):
    """The buying engine's own page part for this store, made to answer Restalker directly (no extension): its `chrome` is a local stand-in."""
    st = STORES[store]
    src = open(os.path.join(ENGINE_DIR, st["part"]), encoding="utf-8").read()
    if store == "amazon":
        # v88: the buying browser's own Amazon checkout (catalog.js + logic.js + content.js) inside the Amazon part (amz_part.js)
        bundle = "\n;\n".join(open(os.path.join(ENGINE_DIR, f), encoding="utf-8").read() for f in ("catalog.js", "logic.js", "content.js"))
        bundle += "\n;globalThis.__rkAmzEntry = () => { const e = purchaseEntry(); return e ? e.kind : null; };\n"
        src = src.replace("/*__RK_AMZ_BUNDLE__*/", bundle)
    src = src.replace(st["flag"], "__rk_" + token + "_on")
    return ("(() => { const chrome = {runtime: {onMessage: {addListener(fn) { Object.defineProperty(window, '__rk_" + token + "', {value: fn}); }},"
            " sendMessage: () => Promise.resolve()}};\n" + src + "\n})();")


# v90b: the stores' own sign-in pages
AUTO_SIGNIN_URL = {"amazon": "https://www.amazon.com/gp/sign-in.html", "bestbuy": "https://www.bestbuy.com/identity/global/signin",
                   "target": "https://www.target.com/login", "walmart": "https://www.walmart.com/account/login", "gamestop": "https://www.gamestop.com/login/"}
STORE_HOSTS = {"amazon": "amazon.com", "bestbuy": "bestbuy.com", "target": "target.com", "walmart": "walmart.com", "gamestop": "gamestop.com"}
_NEEDS_YOU = re.compile(r"verification code|one[- ]time (pass)?code|enter (the|your) code|we('ve| have)? (just )?sent (you )?a code|code (was )?sent|"
                        r"verify (it'?s|that it'?s) you|two[- ]step|2[- ]step|passkey|approve the (notification|request)|solve this puzzle|"
                        r"captcha|press (&|and) hold|not a robot|unusual activity|account (is )?(locked|on hold)", re.I)
_BAD_PW = re.compile(r"(password|e-?mail).{0,40}(incorrect|is wrong|not (correct|recognized|valid))|incorrect (password|e-?mail)|"
                     r"(cannot|can't|couldn't) find an account|no account (found|with)", re.I)
_STEP_JS = """() => {
  const vis = e => { if (!e) return false; const r = e.getBoundingClientRect(), s = getComputedStyle(e); return r.width > 2 && r.height > 2 && s.visibility !== 'hidden' && s.display !== 'none'; };
  const q = sel => [...document.querySelectorAll(sel)].filter(vis);
  const pw = q('input[type=password]');
  const em = q('input[type=email], input[autocomplete=username], input[autocomplete=email], input[name*=email i], input[id*=email i], input[name*=user i], input[id*=user i], input[name=username], input[id=fld-e]')
               .filter(e => e.type !== 'password' && e.type !== 'hidden' && e.type !== 'checkbox');
  const otp = q('input[autocomplete=one-time-code], input[name*=otp i], input[id*=otp i], input[name*=verificationcode i]').length > 0;
  const txt = (document.body && document.body.innerText || '').slice(0, 5000);
  const choice = [...document.querySelectorAll('a, button, [role=button]')].filter(vis).some(x => /use (a |my |your )?password|enter (your )?password|sign in with (a |your )?password|password instead/i.test(x.innerText || ''));
  return {pw: pw.length, em: em.length, emEmpty: em.length ? !em[0].value : false, otp, txt, choice};
}"""


def _signin_steps(page, store, email, pw, url_fn, signin_rx, steps=8):
    """Fills the store's own sign-in page step by step (e-mail -> Continue -> password -> Sign in). -> (ok, why)."""
    host = STORE_HOSTS[store]
    for step in range(steps):
        time.sleep(1.5)
        u = url_fn() or ""
        try:
            from urllib.parse import urlparse
            h = (urlparse(u).hostname or "").lower()
        except Exception:
            h = ""
        if not (h == host or h.endswith("." + host)):
            return False, "the sign-in page is not on " + host + " (nothing was typed)"
        try:
            s = page.evaluate(_STEP_JS)
        except Exception:
            continue                                  # (the page is moving on)
        if s.get("otp") or _NEEDS_YOU.search(s.get("txt") or ""):
            return False, "the store asks for a code / a check that only you can answer"
        if _BAD_PW.search(s.get("txt") or ""):
            return False, "the store says the saved e-mail or password is not right - save it again"
        on_si = bool(re.search(signin_rx, u, re.I)) or bool(s.get("choice"))
        if not on_si and not s.get("pw"):
            return True, ""                           # (left the sign-in page; an e-mail box elsewhere - e.g. a newsletter - is never filled)
        try:
            for lab in ("keep me signed in", "remember me", "stay signed in"):
                cb = page.get_by_label(re.compile(lab, re.I))
                if cb.count() and cb.first.is_visible() and not cb.first.is_checked():
                    cb.first.check(timeout=2000)
        except Exception:
            pass
        acted = False
        try:
            if s.get("em") and s.get("emEmpty") and (on_si or s.get("pw")):
                page.locator("input[type=email]:visible, input[autocomplete=username]:visible, input[autocomplete=email]:visible, "
                             "input[name*=email i]:visible, input[id*=email i]:visible, input[name*=user i]:visible, input[id*=user i]:visible, "
                             "input[name=username]:visible, input[id=fld-e]:visible").first.fill(email, timeout=4000)
                acted = True
            if s.get("pw"):
                page.locator("input[type=password]:visible").first.fill(pw, timeout=4000)
                acted = True
            elif not acted:
                # (e-mail filled already, no password box: a "use your password" choice instead of a code)
                ch = page.get_by_text(re.compile(r"use (a |my |your )?password|enter (your )?password|sign in with (a |your )?password|password instead", re.I))
                if ch.count():
                    ch.first.click(timeout=4000)
                    continue
            btn = page.locator("button[type=submit]:visible, input[type=submit]:visible")
            if not btn.count():
                btn = page.get_by_role("button", name=re.compile(r"^\s*(sign in|continue|next|log in|login)\b", re.I))
            if btn.count():
                btn.first.click(timeout=4000)
            else:
                page.keyboard.press("Enter")
        except Exception:
            continue
    u = url_fn() or ""
    return (not re.search(signin_rx, u, re.I)), ("" if not re.search(signin_rx, u, re.I) else "the sign-in page did not let it through")


def _have_login(store):
    try:
        import logins
        return bool(logins.get(store))
    except Exception:
        return False


def _part_suffix(store):
    return "bb" if store == "bestbuy" else "amz" if store == "amazon" else "st"


class _JobQ:
    """v81: the jobs of one browser, most urgent first: a checkout (0) before a sign-in (1) before an account check (2) before a store
    read for the sweepers (3). A checkout never waits behind store reads."""

    def __init__(self):
        self._q = queue.PriorityQueue()
        self._n = 0
        self._l = threading.Lock()

    def put(self, job):
        pr = -1 if job is None else 3 if job.get("fetch") else 2 if job.get("account") else 1 if job.get("signin") else 0
        with self._l:
            self._n += 1
            n = self._n
        self._q.put((pr, n, job))

    def get(self, timeout=None):
        return self._q.get(timeout=timeout)[2]

    def empty(self):
        return self._q.empty()

    def waiting_fetches(self):
        with self._q.mutex:
            return sum(1 for x in self._q.queue if x[2] and x[2].get("fetch"))


class Stop(Exception):
    def __init__(self, kind, msg):
        super().__init__(msg)
        self.kind = kind


class Worker:
    """One browser, in its own thread (Playwright pages belong to the thread that made them)."""

    def __init__(self, kind):
        self.kind = kind
        self.name = NAMES.get(kind, kind)
        self.q = _JobQ()
        self.spages = {}           # v81: store -> a light page on that store's site, used only to read the store's data for the sweepers
        self.fetch_n = {}          # store -> reads done for the sweepers
        self.state = "starting"
        self.detail = ""
        self.signed = {}           # store -> True / False / None
        self.auto_at = {}          # v90b: store -> when this browser last signed itself in there
        self.si_asked = {}         # v95: store -> when you were last asked to sign this browser in there (once per SIGNIN_ASK_EVERY)
        self.busy = None           # key being bought now
        self.step = ""
        self.since = 0.0
        self.pw = None
        self.ctx = None
        self.page = None
        self.proc = None
        self.br = None
        self.token = secrets.token_hex(6)
        self.visible_for = None    # store whose sign-in window is open
        self.pending = {}          # key -> job (one waiting job per link)
        self._job = None
        self.rest_until = {}       # v80: store -> time until which this browser leaves that store alone (it was blocked there)
        self.view_want = None      # v114: your "Show" / "Hide" of this browser's checkout window, done by this browser's own thread
        self.view_on = False
        self.th = threading.Thread(target=self._run, daemon=True, name="buy-" + kind)
        self.th.start()

    # ---- the browser
    def _profile(self):
        d = os.path.join(HERE, "buyer_profile_" + self.kind)
        os.makedirs(d, exist_ok=True)
        return d

    def _launch(self, visible=False, url=None):
        k = self.kind
        if k == "stealth":
            from patchright.sync_api import sync_playwright
        else:
            from playwright.sync_api import sync_playwright
        if self.pw is None:
            self.pw = sync_playwright().start()
        extra = []
        try:
            import json
            extra = json.loads(os.environ.get("RK_EXTRA_BUYER_ARGS") or "[]")
        except Exception:
            extra = []
        if k in ("chrome", "edge"):
            import browser_fetch
            exe = browser_fetch.RealChromeFetcher.exe_for(k)
            if not exe:
                raise RuntimeError(self.name + " is not installed on this PC")
            port = 9400 + KINDS.index(k)
            args = [exe, f"--remote-debugging-port={port}", f"--user-data-dir={self._profile()}", "--no-first-run", "--no-default-browser-check",
                    "--disable-session-crashed-bubble", "--hide-crash-restore-bubble", "--mute-audio", "--window-size=1280,900",
                    "--disable-backgrounding-occluded-windows", "--disable-renderer-backgrounding", "--disable-background-timer-throttling",
                    "--disable-features=CalculateNativeWinOcclusion"] + extra
            # v90: parked = marked as Restalker's own window, so it can never take the keyboard focus from a window you are using (an
            # Explorer folder you just opened, say); a sign-in window you are meant to use is not marked
            args += ["--window-position=80,40"] if visible else ["--window-position=-32000,-32000", f"--rk-store=buy-{k}"]
            args.append(url or "about:blank")
            flags = 0x08000000 if os.name == "nt" else 0
            self.proc = subprocess.Popen(args, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, creationflags=flags)
            br = None
            for _ in range(60):
                try:
                    br = self.pw.chromium.connect_over_cdp(f"http://127.0.0.1:{port}")
                    break
                except Exception:
                    time.sleep(0.5)
            if br is None:
                raise RuntimeError(self.name + " did not start")
            self.br = br
            self.ctx = br.contexts[0]
        elif k == "stealth":             # v76: your Chrome (Edge when there is no Chrome) started through patchright - no automation signs
            import browser_fetch
            exe = browser_fetch.RealChromeFetcher.exe_for("chrome") or browser_fetch.RealChromeFetcher.exe_for("edge")
            if not exe:
                raise RuntimeError("no Chrome or Edge on this PC")
            args = ["--window-size=1280,900", "--mute-audio", "--disable-session-crashed-bubble", "--hide-crash-restore-bubble",
                    "--window-position=80,40" if visible else "--window-position=-32000,-32000"] + ([] if visible else ["--rk-store=buy-stealth"]) + extra
            self.ctx = self.pw.chromium.launch_persistent_context(self._profile(), executable_path=exe, headless=False, no_viewport=True, args=args)
        elif k == "firefox":
            self.ctx = self.pw.firefox.launch_persistent_context(self._profile(), headless=not visible, viewport={"width": 1280, "height": 900})
        elif k == "camoufox":
            from camoufox.sync_api import NewBrowser
            self.ctx = NewBrowser(self.pw, persistent_context=True, user_data_dir=self._profile(), headless=not visible, os="windows")
        elif k == "chromium":            # (tests: Playwright's own Chromium with its own profile)
            kw = {"executable_path": os.environ["RK_BUYER_EXE"]} if os.environ.get("RK_BUYER_EXE") else {}
            self.ctx = self.pw.chromium.launch_persistent_context(self._profile(), headless=not visible, args=["--no-sandbox"] + extra,
                                                                  ignore_https_errors=True, viewport={"width": 1280, "height": 900}, **kw)
        else:
            raise RuntimeError("unknown browser " + k)
        if k != "stealth":
            self.ctx.add_init_script(script=_part_source("bestbuy", self.token + "bb"))
            self.ctx.add_init_script(script=_part_source("target", self.token + "st"))
        # (Hidden Chrome: the page part is put in on the first question, in a private space of the page that the store's own scripts
        # cannot see - the way the buying engine's extension runs it)
        self.page = self.ctx.pages[0] if self.ctx.pages else self.ctx.new_page()
        if url and k not in ("chrome", "edge"):
            self.page.goto(url, wait_until="commit")
        self.state = "ready"

    def _close(self):
        self.spages = {}
        # v89: Chrome / Edge are asked to CLOSE THEMSELVES (as when you close the window) and given a few seconds to save - they used to be
        # cut off at once, and the stores' newest sign-in cookies (they renew them on every visit) could be lost with it
        br = getattr(self, "br", None)
        if br is not None and self.proc is not None:
            try:
                br.new_browser_cdp_session().send("Browser.close")
            except Exception:
                pass
            try:
                self.proc.wait(timeout=8)
            except Exception:
                pass
            self.br = None
        for x in (self.ctx,):
            try:
                if x is not None:
                    x.close()
            except Exception:
                pass
        self.ctx = self.page = None
        if self.proc is not None:
            try:
                self.proc.terminate()
            except Exception:
                pass
            self.proc = None

    # ---- the thread
    def _run(self):
        try:
            self._launch()
            _log(f"{self.name} is ready to buy (its own profile).")
            for s_ in STORES:                       # (which stores it is signed in to)
                self.q.put({"account": True, "store": s_})
        except Exception as e:
            self.state = "failed"
            self.detail = str(e)[:160]
            _log(f"{self.name} could not start for buying: {self.detail}")
            return
        while True:
            try:
                job = self.q.get(timeout=60)
            except queue.Empty:
                self._health()                   # v80: a browser that was closed (e.g. its window closed after a sign-in) comes back by itself
                continue
            if job is None:
                break
            try:
                if job.get("view"):
                    self._view_tick()
                    continue
                if job.get("fetch"):
                    self._fetch_job(job)
                    continue
                if job.get("signin"):
                    self._signin(job["store"])
                elif job.get("account"):
                    self._account(job["store"])
                else:
                    with _lock:
                        self.pending.pop(job["key"], None)
                    self._buy(job)
            except Exception as e:
                _log(f"{self.name}: {str(e)[:200]}")
                if self.ctx is None or "closed" in str(e).lower():
                    self._health()
            finally:
                self.busy = None
        self._close()
        try:
            self.pw.stop()
        except Exception:
            pass

    # ---- v81: reading a store's data for the sweepers (between checkouts; a checkout always goes first)
    def _spage(self, store):
        pg = self.spages.get(store)
        try:
            if pg is not None and not pg.is_closed():
                return pg
        except Exception:
            pass
        pg = self.ctx.new_page()
        try:
            pg.goto(READ_ORIGINS[store] + "/robots.txt", wait_until="domcontentloaded", timeout=20000)     # (a plain page of the store's own site)
        except Exception:
            pass
        self.spages[store] = pg
        return pg

    def _fetch_job(self, job):
        rep = job["reply"]
        if time.time() > job["until"]:
            return                                   # (the sweeper stopped waiting for it)
        try:
            pg = self._spage(job["store"])
            ms = int(max(1.0, job["until"] - time.time()) * 1000)
            r = pg.evaluate(
                """async ([u, ms]) => { try {
                     const url = new URL(u, location.href);
                     const site = h => h.split('.').slice(-2).join('.');
                     if (url.protocol !== 'https:' || site(url.hostname) !== site(location.hostname)) return {ok: false, reason: 'another site'};
                     const ctl = new AbortController(), to = setTimeout(() => ctl.abort(), ms);
                     const r = await fetch(url.href, {credentials: url.origin === location.origin ? 'include' : 'omit', cache: 'no-store', signal: ctl.signal});
                     let text = await r.text(); clearTimeout(to);
                     if (text.length > 2500000) text = text.slice(0, 2500000);
                     return {ok: true, status: r.status, url: r.url, text};
                   } catch (e) { return {ok: false, reason: String(e && e.message || e)}; } }""", [job["url"], ms]) if pg.url.startswith("http") else {"ok": False, "reason": "the store's site did not open"}
        except Exception as e:
            r = {"ok": False, "reason": str(e)[:160]}
            if "closed" in str(e).lower():
                self.spages.pop(job["store"], None)
        self.fetch_n[job["store"]] = self.fetch_n.get(job["store"], 0) + 1
        rep["r"] = r
        rep["ev"].set()

    def _alive(self):
        try:
            if self.ctx is None or self.page is None or self.page.is_closed():
                return False
            self.page.evaluate("1")
            return True
        except Exception:
            return False

    def _health(self):
        """v80 (diagnostics 67: Chrome and Hidden Chrome stayed 'ready' with a closed browser - 'Target page, context or browser has been
        closed' - and took part in nothing): a closed browser is started again and its sign-ins are read again."""
        if self.visible_for or self._alive():
            return
        if time.time() - getattr(self, "_health_at", 0.0) < (600 if self.state == "failed" else 20):
            return
        self._health_at = time.time()
        _log(f"{self.name} had closed - starting it again.")
        old = dict(self.signed)
        try:
            self._close()
            self._launch()
            self.detail = ""
            for s_ in STORES:
                self.signed[s_] = old.get(s_)
                self.q.put({"account": True, "store": s_})
        except Exception as e:
            self.state = "failed"
            self.detail = str(e)[:160]

    # ---- talking to the page part
    def _part_name(self, store):
        return "__rk_" + self.token + _part_suffix(store)

    def ask(self, store, msg, timeout=20.0):
        nm = self._part_name(store)
        end = time.time() + timeout
        last = None
        while time.time() < end:
            try:
                have = self.page.evaluate("n => typeof window[n] === 'function'", nm)
                if not have:
                    # (the init script runs on every new page; a page that was already open gets it here)
                    self.page.evaluate(_part_source(store, self.token + _part_suffix(store)))
                ms = int(max(1.0, end - time.time()) * 1000)
                return self.page.evaluate(
                    "([n, m, ms]) => new Promise(res => { const h = window[n]; if (!h) return res({ok: false, error: 'no page part'});"
                    " const to = setTimeout(() => res({ok: false, error: 'the page did not answer in time', timeout: true}), ms);"
                    " try { h(m, {}, v => { clearTimeout(to); res(v); }); } catch (e) { clearTimeout(to); res({ok: false, error: String(e)}); } })",
                    [nm, msg, ms]) or {"ok": False}
            except Exception as e:
                last = str(e)
                if "context was destroyed" in last or "navigat" in last.lower():
                    if msg.get("bb") in ("add", "place", "buynow", "tocheckout", "advance", "remove", "removeover", "qty1", "ship", "dismiss", "cvv", "cvvsubmit", "begin"):
                        return {"ok": False, "lost": True, "error": "the page moved on"}
                time.sleep(0.25)
        return {"ok": False, "error": last or "no answer"}

    def url(self):
        # (the page's own address - Playwright's copy was seen lagging behind a page that moved by itself)
        try:
            return self.page.evaluate("() => location.href") or self.page.url or ""
        except Exception:
            try:
                return self.page.url or ""
            except Exception:
                return ""

    def wait_url(self, pred, secs, start_secs=None):
        """Waits until the page's address fits; with start_secs, gives up early when the page does not move at all."""
        u0, t0 = self.url(), time.time()
        moved = False
        while time.time() - t0 < secs:
            u = self.url()
            if u != u0:
                moved = True
            if pred(u):
                return u
            if start_secs and not moved and time.time() - t0 > start_secs:
                return None
            time.sleep(0.1)
        return None

    def goto(self, url, timeout=25.0):
        self.page.goto(url, wait_until="commit", timeout=int(timeout * 1000))

    # ---- v90b: signing itself back in with your saved sign-in (logins.py) - one try per store every AUTO_SIGNIN_EVERY seconds
    AUTO_SIGNIN_EVERY = 1800.0

    def _auto_signin(self, store, here=False):
        """-> True (signed in now), False (could not - e.g. the store wants a code or a puzzle: never answered), None (no saved sign-in /
        tried a moment ago). The e-mail and password go ONLY into a page of that store's own address."""
        try:
            import logins
            cred = logins.get(store)
        except Exception:
            cred = None
        if not cred:
            return None
        if time.time() - self.auto_at.get(store, 0.0) < self.AUTO_SIGNIN_EVERY:
            return None
        self.auto_at[store] = time.time()
        st = STORES[store]
        email, pw = cred
        prev = self.state
        self.state = "signing itself in at " + STORE_NAMES[store]
        try:
            if not (here and re.search(st["signin_rx"], self.url() or "", re.I)):
                self.goto(AUTO_SIGNIN_URL.get(store) or st["signin"])
            self.wait_url(lambda x: bool(x) and x != "about:blank", 20)
            res = _signin_steps(self.page, store, email, pw, lambda: self.url(), st["signin_rx"])
        except Exception as e:
            res = (False, "the sign-in page did not work (" + str(e)[:80] + ")")
        finally:
            self.state = prev if prev != ("signing itself in at " + STORE_NAMES[store]) else "ready"
        ok, why = res
        if ok:
            self.signed[store] = True
            self.si_asked.pop(store, None)            # (v95: seen signed in -> it takes part at this store again)
            _log(f"{self.name} at {STORE_NAMES[store]}: signed itself in again with your saved sign-in.")
        else:
            _log(f"{self.name} at {STORE_NAMES[store]}: could not sign itself in - {why}. "
                 + ("It needs you once: press its 'sign in' under the store column." if "code" in why or "check" in why else "It tries again in 30 minutes."))
        return ok

    # ---- sign-in (you do it; the program never types a password)
    def _signin(self, store):
        st = STORES[store]
        _log(f"{self.name}: opening {STORE_NAMES[store]}'s sign-in page on your screen - sign in (tick 'Keep me signed in'), then close that window.")
        self._close()
        self.visible_for = store
        self.state = "sign-in window open"
        try:
            self._launch(visible=True, url=st["signin"])
            closed = threading.Event()
            try:
                self.ctx.on("close", lambda *_: closed.set())
            except Exception:
                pass
            t0 = time.time()
            while not closed.is_set() and time.time() - t0 < 1800:
                try:
                    if not self.ctx.pages:
                        break
                    self.ctx.pages[0].wait_for_timeout(500)
                except Exception:
                    break
        finally:
            self.visible_for = None
            self._close()
            self._launch()
        self._account(store)

    # v89 (owner 2026-11-01: "why do I have to sign in to every browser every single time this program loads?"; diagnostics 70: every
    # browser showed Best Buy=False at every start while Target / Walmart / GameStop stayed signed in): Best Buy sends even a signed-in
    # shopper to its password page for the ORDER HISTORY (it asks for the password again for that page only), so the old check - open the
    # order history - said "not signed in" every time, the browser was left out of every Best Buy checkout, and you were asked to sign in
    # again and again. Best Buy and Amazon are now checked by the greeting at the top of their home page ("Hi, <name>" / "Hello, <name>").
    # v90 (owner 2026-11-02: "each store has all browsers showing me signed in and out ... I keep signing into them but it doesn't seem to
    # stick"): Target, Walmart and GameStop do the same as Best Buy - after a while they ask for the password again for the ORDER pages only
    # (the cart and the checkout stay signed in), so the order-page check flipped to "NOT signed in" and back. All stores are now checked by
    # the greeting at the top of the home page. "NOT signed in" only when the page plainly offers "Sign in" and greets nobody; anything
    # unclear is "not known" (the browser still buys; if a store really wants a sign-in at the checkout, you are asked then).
    _GREET = {"bestbuy": (r"\bhi,\s*[a-z][a-z'-]{1,}", r"\bsign in\b(?!.*\bhi,)"),
              "amazon": (r"\bhello,\s*(?!sign in)[a-z][a-z'-]{1,}", r"\bhello,\s*sign in\b"),
              "target": (r"\bhi,\s*(?!there\b)[a-z][a-z'-]{1,}", r"\bsign in\b(?!.*\bhi,)"),
              "walmart": (r"\bhi,\s*(?!there\b)[a-z][a-z'-]{1,}", r"\bsign in or create account\b(?!.*\bhi,)"),
              "gamestop": (r"\bhi,\s*(?!there\b)[a-z][a-z'-]{1,}", None)}

    def _account_greet(self, store):
        st = STORES[store]
        yes, no = self._GREET[store]
        try:
            try:
                self.goto(st["origin"] + "/")
            except Exception:
                time.sleep(1.0)                       # (the page was still busy with the page before: once more)
                self.goto(st["origin"] + "/")
            self.wait_url(lambda x: x.startswith(st["origin"]), 20)
            txt = ""
            for _ in range(12):
                time.sleep(1.0)
                try:
                    txt = self.page.evaluate("() => { const h = document.querySelector('header, #nav-belt, #navbar, .shop-header, [data-testid*=header i]');"
                                             " return ((h && h.innerText) || (document.body && document.body.innerText) || '').slice(0, 6000).toLowerCase(); }") or ""
                except Exception:
                    continue                          # (the page was still moving on)
                if re.search(yes, txt):
                    self.signed[store] = True
                    self.si_asked.pop(store, None)            # (v95: seen signed in -> it takes part at this store again)
                    break
                if no and re.search(no, txt) and len(txt) > 200:
                    self.signed[store] = False
                    break
            else:
                self.signed[store] = None             # (not known: never keeps this browser out of a checkout, and you are not asked)
        except Exception as e:
            self.signed[store] = None
            self.detail = str(e)[:120]
        if self.signed.get(store) is False and not getattr(self, "_in_auto", False):
            self._in_auto = True
            try:
                if self._auto_signin(store):          # v90b: signed out -> signs itself back in with your saved sign-in
                    return
            finally:
                self._in_auto = False
        _log(f"{self.name} at {STORE_NAMES[store]}: " + {True: "signed in.", False: "looks NOT signed in (it still tries every checkout; press its 'sign in' under the store column to make sure).", None: "sign-in not known (it still buys; a sign-in window comes only if the store asks at the checkout)."}[self.signed.get(store)])

    def _account(self, store):
        st = STORES[store]
        if store in self._GREET:
            return self._account_greet(store)
        try:
            try:
                self.goto(st["orders"])
            except Exception:
                time.sleep(1.0)
                self.goto(st["orders"])
            u = self.wait_url(lambda x: x.startswith(st["origin"]) or re.search(st["signin_rx"], x or ""), 20) or self.url()
            time.sleep(1.5)
            u = self.url()
            if re.search(st["signin_rx"], u):
                self.signed[store] = False
            else:
                chk = self.ask(store, {"bb": "ping"}, 10)
                txt = self.page.evaluate("() => (document.body && document.body.innerText || '').slice(0, 20000).toLowerCase()")
                if re.search(r"sign in to (your|see)|returning customers|create (an )?account|forgot (your )?password", txt or "") and not re.search(r"order history|your orders|purchase history|sign out", txt or ""):
                    self.signed[store] = False
                else:
                    self.signed[store] = True if chk else None
                    if chk:
                        self.si_asked.pop(store, None)
        except Exception as e:
            self.signed[store] = None
            self.detail = str(e)[:120]
        _log(f"{self.name} at {STORE_NAMES[store]}: " + {True: "signed in.", False: "looks NOT signed in (it still tries every checkout; press its 'sign in' under the store column to make sure).", None: "sign-in not known."}[self.signed.get(store)])

    # ---- one restock, up to TRIES_PER_RESTOCK tries back to back
    def _buy(self, job):
        key, store = job["key"], job["store"]
        ep = job.get("detected") or 0
        f = _fails.get((self.kind, key))
        if f and len(f) > 2 and f[2] != ep:
            _fails.pop((self.kind, key), None)          # v78b: a NEW restock - this browser tries again (the lock was for the last one)
            f = None
        if f and f[0] >= LOCK_AFTER and time.time() - f[1] < 300:
            return
        # v90 (owner 2026-11-02: "Verify that this won't affect checkout in case the Restalker erroneously thinks I'm not logged in"): the
        # sign-in check NEVER keeps a browser out of a checkout. Each browser always tries; if the store really wants a sign-in at the
        # checkout, the browser stops there and you are asked (nothing is ever bought without the store's own sign-in).
        if (store != "amazon" and self.signed.get(store) is False and time.time() - self.si_asked.get(store, 0) < self.SIGNIN_ASK_EVERY
                and not _have_login(store)):
            # v95: THIS store asked this browser to sign in at its checkout (not a guess from a greeting), you were told once, and no
            # sign-in is saved for it -> it sits this store out until it is signed in (no page loads at a store that judges the whole
            # PC, no window, no message); the other browsers buy. A saved sign-in (Sign-ins (top bar)) ends this at once.
            _note(self.kind, key, "result", ok=False, kind="signin", reason="sits out - not signed in at " + STORE_NAMES[store])
            return
        if not self._alive():
            self._health()
        self.busy = key
        self._job = job
        self.since = job.get("detected") or time.time()
        for attempt in range(TRIES_PER_RESTOCK):
            try:
                res = self._try(job)
            except Stop as s:
                res = {"ok": False, "kind": s.kind, "reason": str(s)}
            except Exception as e:
                res = {"ok": False, "kind": "error", "reason": str(e)[:200]}
            _note(self.kind, key, "result", **{k: v for k, v in res.items() if k in ("ok", "kind", "reason", "order")})
            if res.get("kind") in ("overcap", "needyou", "identity", "soldout"):       # v78: told to the browsers waiting for this cart
                _cmd({"type": "BB_VERDICT", "cartStore": store, "key": key, "kind": res["kind"], "reason": res.get("reason"),
                      "owner": self.name + ":" + key}, 5)
            if res.get("ok"):
                _fails.pop((self.kind, key), None)
                _log(f"{self.name} BOUGHT {job.get('name') or key} at {STORE_NAMES[store]}" + (f" - order {res.get('order')}" if res.get("order") else "") + ".")
                return
            kind = res.get("kind")
            if kind == "check":
                # v80 (diagnostics 67: Firefox opened GameStop's page 5 times in 40 s and got "Sorry, you have been blocked" each time): a human
                # check or a block page -> this browser leaves that store alone for 30 minutes (going on only makes the block worse)
                self.rest_until[store] = time.time() + 1800
                _log(f"{self.name} at {STORE_NAMES[store]}: {res.get('reason')} - this browser leaves {STORE_NAMES[store]} alone for 30 minutes.")
                return
            if kind == "soldout":
                return            # v80: sold out / pre-order / coming soon = ONE look per restock signal (the buying browser keeps its own tries)
            if kind == "signin" and self._auto_signin(store):
                _log(f"{self.name} at {STORE_NAMES[store]}: signed itself in - trying the checkout again at once.")
                continue                                  # v90b: signed in again -> the next try right away
            if kind in ("other", "cancelled", "signin", "check", "unclear", "overcap", "needyou", "identity"):
                if kind == "signin":
                    self.signed[store] = False
                    _log(f"{self.name} at {STORE_NAMES[store]}: the store wants the password - this browser stops for {STORE_NAMES[store]} "
                         f"until you sign in it (its 'sign in' link under the store column). The other browsers go on.")
                elif kind not in ("other", "cancelled"):
                    _log(f"{self.name} at {STORE_NAMES[store]}: stopped - {res.get('reason')}")
                return
            n = (_fails.get((self.kind, key)) or [0, 0])[0] + (0 if kind == "soldout" else 1)
            _fails[(self.kind, key)] = [n, time.time(), ep]
            _log(f"{self.name} at {STORE_NAMES[store]}: try {attempt + 1} did not buy - {res.get('reason')}")
            if n >= LOCK_AFTER:
                _log(f"{self.name} at {STORE_NAMES[store]}: LOCKED for {job.get('name') or key} after {n} failed tries in a row.")
                return
            if not _still_wanted(job):
                return

    def _step(self, key, s):
        self.step = s
        _note(self.kind, key, s)
        self._view_tick()

    WINDOWED = ("chrome", "edge", "stealth", "chromium")

    def _view_tick(self):
        """v114 (owner, diagnostics 92: "when checkout is actively happening, there should be a link to pull up the active checkout page(s)
        for live monitoring (and intervention if necessary)"): your Show / Hide is done here, by this browser's own thread (its pages may
        only be used from it) - at its next step, while it waits for its turn to press Place order, or at once when it is idle. Firefox and
        Camoufox run without a window: nothing to show."""
        want = self.view_want
        if want is None:
            return
        self.view_want = None
        if self.kind not in self.WINDOWED or self.page is None or (not want and not self.view_on):
            return                       # (Show is always done again - the window may have been put away meanwhile)
        if self._show(want):
            self.view_on = want
            _log(f"{self.name}'s checkout window " + ("is on your screen now (live; closing it stops this browser's checkout - press Hide instead)."
                                                      if want else "is hidden again."))

    def _try_amazon(self, job):
        """v88: one Amazon checkout in this browser - the buying browser's own Amazon checkout (content.js) does the page work and every
        money check; this function hands it the product, keeps it running across the page changes, and answers its 'SUBMITTING' with the
        ONE-order latch (shared with the buying browser and the other browsers). Buy now / Pre-order only - never the shared cart."""
        key, store = job["key"], "amazon"
        owner = self.name + ":amz:" + key
        latched = False
        p = None if job.get("product") else _cmd({"type": "RK_RUNTIME_PRODUCT", "productId": job.get("pid")}, 8).get("product")
        p = p or job.get("product")              # v90: a listing the buying browser does not know yet - Restalker's own checks for it
        if not p or not p.get("asin"):
            raise Stop("page", "the buying engine did not give the product's checks")
        p = dict(p, cap=float(job["cap"]) if job.get("cap") else p.get("cap"))
        try:
            if not _still_wanted(job):
                raise Stop("cancelled", "not set to buy any more")
            self._step(key, "opening the product page")
            self.goto(job["url"])
            self.ask(store, {"bb": "reset"}, 10)
            r = {}
            for look in range(3):               # (a restock that is still drawing: looked at three times within a few seconds)
                r = self.ask(store, {"bb": "eligible", "product": p}, 12)
                if r.get("eligible") or (r.get("reason") or "") == "price above cap":
                    break
                time.sleep(0.7)
            self._step(key, f"product page read ({'buyable' if r.get('eligible') else r.get('reason') or 'not buyable'}, {r.get('kind') or 'no button'}"
                            + (f", ${r['price']:.2f}" if isinstance(r.get("price"), (int, float)) else "") + ")")
            if str(r.get("reason") or "") == "price above cap":
                raise Stop("overcap", f"price ${float(r.get('price') or 0):.2f} is over the cap ${float(p.get('cap') or 0):.2f}")
            if "not the product" in str(r.get("reason") or "") or "identity" in str(r.get("reason") or ""):
                raise Stop("identity", str(r.get("reason")))
            if not r.get("eligible"):
                raise Stop("soldout", "Amazon: " + str(r.get("reason") or "not buyable"))
            if r.get("kind") == "cart":
                raise Stop("soldout", "Amazon shows only Add to Cart here - the buying browser buys it (these browsers use Buy now only)")
            b = self.ask(store, {"bb": "begin", "product": p, "price": r.get("price"), "hit": int((job.get("detected") or time.time()) * 1000)}, 10)
            if b and b.get("ok") is False and not b.get("lost") and b.get("reason"):
                raise Stop("identity", str(b.get("reason")))
            self._step(key, "Buy now pressed")
            seen, t_end, said = 0, time.time() + 90, set()
            while time.time() < t_end:
                if not _still_wanted(job, allow_attempted=False) and not latched:
                    raise Stop("other", "it was ordered or switched off meanwhile")
                m = self.ask(store, {"bb": "msgs", "since": seen}, 4)
                if not m.get("ok"):
                    time.sleep(0.1)
                    continue
                new = m.get("msgs") or []
                seen = max([seen] + [int(x.get("n") or 0) for x in new])
                for x in new:
                    t, why = x.get("type"), str(x.get("reason") or "")
                    if t == "CHECKOUT_PRICE_EVIDENCE":
                        line = "checkout: " + why.lower().replace("_", " ")
                        if x.get("step"):           # v91: which step of Amazon's checkout, and what Amazon says there
                            line += " " + str(x.get("step"))[:60]
                        if x.get("label"):
                            line += " (pressed " + str(x.get("label"))[:30] + ")"
                        if why in ("CHECKOUT_STEP",) and x.get("headings"):
                            line += " - " + " / ".join(str(h)[:50] for h in (x.get("headings") or [])[:3])
                        if x.get("notes"):
                            line += ' - Amazon says: "' + str((x.get("notes") or [""])[0])[:140] + '"'
                        if line not in said:
                            said.add(line)
                            self._step(key, line)
                        continue
                    if t == "SUBMITTING":
                        ok, reason = False, ""
                        try:
                            self._latch(job, owner, key, max_wait=25)
                            ok = _still_wanted(job, allow_attempted=False)
                            reason = "" if ok else "ordered or switched off meanwhile"
                        except Stop as s_:
                            reason = str(s_)
                        if ok:
                            latched = True
                            self._step(key, "Place your order pressed - waiting for Amazon's confirmation")
                        self.ask(store, {"bb": "reply", "n": x.get("n"), "value": {"ok": ok, "reason": reason}}, 4)
                        if not ok and "ordered at" in reason:
                            raise Stop("other", reason)
                        continue
                    if t == "PURCHASE_SUCCESS":
                        _amz_done(job, self.name, "bought", x.get("orderNumber"), x.get("price"))
                        return {"ok": True, "order": x.get("orderNumber")}
                    if t == "SUBMISSION_UNCLEAR":
                        found = self._amz_order_check(job)
                        if found:
                            _amz_done(job, self.name, "bought", self._amz_found_order, x.get("price"))
                            return {"ok": True, "order": self._amz_found_order}
                        if found is None:
                            _amz_done(job, self.name, "unclear", None, x.get("price"))
                            return {"ok": False, "kind": "unclear", "reason": "Amazon did not confirm the order and the order list could not be read - Restalker checks again"}
                        raise Stop("failed", "Amazon did not confirm the order and it is not in your Amazon orders: " + why)
                    if t == "DEFINITE_SUBMISSION_FAILURE":
                        raise Stop("failed", "ORDER NOT PLACED - " + why)
                    if t == "ACTION_REQUIRED":
                        if re.search(r"sign ?in|password|login", why, re.I):
                            raise Stop("signin", "Amazon wants you to sign in in " + self.name)
                        if re.search(r"challenge|verification|captcha", why, re.I):
                            raise Stop("check", "Amazon shows a human / security check")
                        raise Stop("action", why)
                    if t == "SHIPPING_APPROVAL_REQUIRED":
                        raise Stop("needyou", "shipping costs need your OK (the buying browser asks you)")
                    if t == "FLOW_BLOCKED":
                        k = "soldout" if re.search(r"out of stock|unavailable|no longer|sold out|quantity is zero", why, re.I) else (
                            "overcap" if re.search(r"above cap|over the cap|price", why, re.I) else "page")
                        raise Stop(k, "Amazon checkout: " + why)
                self._view_tick()
                time.sleep(0.08)
            raise Stop("page", "the Amazon checkout did not finish within 90 s")
        finally:
            if latched and not getattr(self, "_amz_keep_latch", False):
                _cmd({"type": "BB_UNLATCH", "group": job.get("group"), "owner": owner}, 5)
            self._amz_keep_latch = False

    def _amz_order_check(self, job):
        """After an unclear result: is the product in this account's Amazon orders? True / False / None (could not read them).
        v114 (diagnostics 92): only an order that was NOT in the list before this checkout began counts (amazon_buy.order_verdict) - a
        "Buy one more" finds the product's first order too, and that was once taken for the new one. Can't compare -> None (unknown)."""
        self._amz_found_order = None
        since = float(job.get("detected") or 0) or self.since or time.time()
        try:
            from amazon_buy import attempt_started
            since = max(since, attempt_started(job["key"]) or 0)      # (the latest moment surely before this order)
        except Exception:
            pass

        def verdict(r):
            ids = r.get("ids") if isinstance(r.get("ids"), list) else ([] if not r.get("found") else None)
            if ids is None:
                return None                      # (an answer without the order numbers: cannot tell)
            try:
                from amazon_buy import order_verdict
                v, num = order_verdict(job["key"], ids, since)
            except Exception:
                return None
            if v == "found":
                self._amz_found_order = num
                return True
            return False if v == "none" else None
        last = None
        for wait in (12, 45):
            time.sleep(wait)
            try:
                self.goto(STORES["amazon"]["orders"])
                time.sleep(3)
                r = self.ask("amazon", {"bb": "orders", "asin": job["key"]}, 15)
                if not r.get("ok") or r.get("signin"):
                    continue
                last = verdict(r)
                if last:
                    return True
            except Exception:
                continue
        return last

    def _try(self, job):
        """One checkout. Mirrors buyer_engine/store_engine.js campaign()."""
        key, store = job["key"], job["store"]
        if store == "amazon":
            return self._try_amazon(job)
        st = STORES[store]
        owner = self.name + ":" + key
        is_co = lambda u: bool(re.search(st["checkout"], u or "", re.I)) and not re.search(r"thank|confirmation", u or "", re.I)
        is_si = lambda u: bool(re.search(st["signin_rx"], u or "", re.I))
        on_cart = lambda u: bool(re.search(r"/cart", re.sub(r"[?#].*", "", re.sub(r"^https?://[^/]+", "", u or "")), re.I)) and not is_co(u)
        want = {"sku": job.get("sku"), "tokens": list(job.get("tokens") or []), "forbid": list(job.get("forbid") or []), "name": job.get("name")}
        cap = float(job["cap"])
        cart_mine = latched = False
        try:
            if not _still_wanted(job):
                raise Stop("cancelled", "not set to buy any more")
            # 1) the product page - at the same moment as every other browser
            self._step(key, "opening the product page")
            self.goto(job["url"])
            # v78b (diagnostics 66): the page part waited up to 20 s for the buttons of a sold-out page and the question gave up at 20 s - "the page
            # did not answer in time", counted as failed tries, and those browsers were then locked out of the NEXT restock. Now it answers in 10 s.
            info = self.ask(store, {"bb": "pdp", "want": want, "ship": True, "wait": 10000}, 25)
            if info.get("check"):
                raise Stop("check", info["check"])
            if not info.get("ok"):
                raise Stop("page", "product page: " + str(info.get("error") or "unreadable"))
            if not (info.get("title") or "").strip() and not info.get("inStock"):
                raise Stop("page", "the product page was not drawn yet")
            self._step(key, f"product page read ({info.get('title', '')[:60]} - ${info.get('price')})")
            if info.get("sku"):
                want["sku"] = str(info["sku"])
            if info.get("skuAlt"):
                want["skuAlt"] = info["skuAlt"]
            if job.get("trusted") and not want["tokens"] and info.get("title"):
                ws = [w for w in re.findall(r"[a-z0-9]{3,}", re.sub(r"[™®©]", "", info["title"].lower())) if w not in ("the", "and", "for", "with", "new", "pack", "black", "white", "size", "count")]
                want["tokens"] = list(dict.fromkeys(ws))[:4]
            toks = [t.lower() for t in (job.get("tokens") or [])]
            title = (info.get("title") or "").lower()
            if toks and not all(any(x in title for x in t.split("|")) for t in toks):
                raise Stop("identity", "the page title does not match the product: " + (info.get("title") or "?")[:80])
            if any(w.lower() in title for w in (job.get("forbid") or [])):
                raise Stop("identity", "the page is a different kind of product")
            if info.get("soldOut"):
                raise Stop("soldout", "the store shows " + str(info.get("button")))
            if info.get("price") is not None and float(info["price"]) > cap + 0.001:
                raise Stop("overcap", f"price ${float(info['price']):.2f} is over the cap ${cap:.2f}")
            if not info.get("inStock") and not info.get("inCart"):
                raise Stop("soldout", "no Add to cart button (" + str(info.get("button")) + ")")
            # 2) the store's cart: one browser ADDS (the account has ONE cart); v87: the others do not wait their turn - the moment the
            #    item is in that shared cart they go to the checkout too, all at the same time; the first to reach Place order presses
            #    (one at a time, so still ONE order), the others press at once if it does not go through
            mode = self._take_cart(store, owner, job, info)
            cart_mine = mode != "shadow"
            via_buy_now = False
            if mode == "shadow":
                self._step(key, "the item is in the shared cart - going to the checkout at the same time as the other browser")
            if info.get("buyNow") and store != "target" and mode != "shadow":          # (v78b: Target's Buy now is a pop-up, not a way to the checkout)
                self._step(key, "pressing Buy now (straight to the checkout)")
                bn = self.ask(store, {"bb": "buynow"}, 8)
                if bn.get("check"):
                    raise Stop("check", bn["check"])
                u = self.wait_url(lambda x: is_co(x) or is_si(x) or on_cart(x), 15, start_secs=3) if bn.get("ok") or bn.get("lost") else None
                if u and is_si(u):
                    raise Stop("signin", STORE_NAMES[store] + " wants you to sign in again before checking out")
                if u and is_co(u):
                    via_buy_now = True
                elif u and on_cart(u):
                    pass
                else:
                    self._step(key, "Buy now did not open the checkout - using Add to cart")
            if not via_buy_now:
                if not on_cart(self.url()):
                    if not (info.get("inCart") and not info.get("inStock")):
                        self._step(key, "pressing Add to Cart")
                        a = self.ask(store, {"bb": "add", "maxQueueMs": 60000}, 90)
                        if a.get("check"):
                            raise Stop("check", a["check"])
                        if a.get("soldOut"):
                            raise Stop("soldout", "sold out while adding to the cart")
                        if not a.get("ok") and not a.get("lost") and not re.search(r"did not answer|in time|no confirmation", str(a.get("error") or "")):
                            raise Stop("page", "Add to Cart: " + str(a.get("error") or "no confirmation"))
                        time.sleep(0.5)
                    self._step(key, "cart")
                    self.goto(st["cart"])
                c = self.ask(store, {"bb": "cart", "want": want}, 15)
                if c.get("check"):
                    raise Stop("check", c["check"])
                tgt = c.get("target")
                mine_lines = [i for i in (c.get("items") or []) if i.get("mine")]
                if not tgt and len(mine_lines) > 1 and cart_mine:
                    # v93/v94 (diagnostics 76): the product is in the cart once per seller (Walmart) - the lines over the cap go, the
                    # cheapest within it stays. Only by the browser whose cart it is (never from another browser's shared cart), only when
                    # every line has this item number and a price that was read (the page part refuses otherwise - nothing is touched)
                    r = self.ask(store, {"bb": "removeover", "want": want, "cap": cap}, 30)
                    if not r.get("ok"):
                        raise Stop("cart", f"the product is in the cart {len(mine_lines)} times and could not be made one ({r.get('reason') or r.get('error') or 'no answer'})")
                    self._step(key, f"the product was in the cart from {len(mine_lines)} sellers - kept the one within the cap")
                    time.sleep(1.5)
                    c = self.ask(store, {"bb": "cart", "want": want}, 10)
                    tgt = c.get("target")
                self._step(key, f"cart read ({c.get('count')} item(s))")
                if not tgt:
                    raise Stop("page", f"the product is not in the cart ({c.get('count') or 0} item(s) there)")
                if c.get("count") != 1:
                    raise Stop("cart", f"the cart has {c.get('count')} different items - only this product may be in it")
                for _ in range(3):
                    if not tgt.get("qty") or tgt.get("qty") == 1:
                        break
                    self.ask(store, {"bb": "qty1", "want": want}, 12)
                    time.sleep(1.5)
                    c = self.ask(store, {"bb": "cart", "want": want}, 10)
                    tgt = c.get("target") or {}
                if tgt.get("qty") and tgt.get("qty") != 1:
                    raise Stop("cart", "the quantity in the cart is not 1")
                if tgt.get("price") is not None and float(tgt["price"]) > cap + 0.001:
                    raise Stop("overcap", f"the cart price ${float(tgt['price']):.2f} is over the cap ${cap:.2f}")
                sh = self.ask(store, {"bb": "ship", "want": want, "allowPickup": False}, 10)
                if not sh.get("ok"):
                    raise Stop("cart", sh.get("error") or "could not choose shipping")
                self._step(key, "going to the checkout")
                tc = self.ask(store, {"bb": "tocheckout"}, 12)
                if tc.get("check"):
                    self._signin_wait(store, key, tc["check"], is_co, is_si, on_cart)
                elif not tc.get("ok") and not tc.get("lost"):
                    raise Stop("page", tc.get("error") or "no Checkout button")
                # v78: a sign-in pop-up on the same page (Target) is seen within about a second, not after 25 s
                u, t_end, last_ping = None, time.time() + 25, 0.0
                while time.time() < t_end:
                    cur = self.url()
                    if is_co(cur):
                        u = cur
                        break
                    if is_si(cur):
                        u = self._signin_wait(store, key, STORE_NAMES[store] + " wants you to sign in again before checking out", is_co, is_si, on_cart)
                        break
                    if time.time() - last_ping > 0.9:
                        last_ping = time.time()
                        pz = self.ask(store, {"bb": "ping", "check": True}, 2)
                        if pz.get("check"):
                            u = self._signin_wait(store, key, pz["check"], is_co, is_si, on_cart)
                            break
                    time.sleep(0.15)
                if not u:
                    z = self.ask(store, {"bb": "cart", "want": want}, 5)
                    if z.get("check"):
                        u = self._signin_wait(store, key, z["check"], is_co, is_si, on_cart)
                    else:
                        raise Stop("page", "the checkout page did not open")
            # 3) the checkout
            self._step(key, "checkout page" + (" (Buy now)" if via_buy_now else ""))
            if store != "bestbuy":
                self.ask(store, {"bb": "dismiss"}, 15)
            k = self.ask(store, {"bb": "checkout", "want": want}, 25)
            if k.get("check"):
                raise Stop("signin" if "sign in" in k["check"].lower() else "check", k["check"])
            for _ in range(4):
                if not (k.get("ok") and (not k.get("place") or st["steps_first"])) or store == "bestbuy":
                    break
                adv = self.ask(store, {"bb": "advance"}, 15)
                if not adv.get("ok") or adv.get("ready"):
                    break
                time.sleep(3)
                k = self.ask(store, {"bb": "checkout", "want": want}, 25)
            if k.get("pickup"):
                self.ask(store, {"bb": "ship", "want": want, "allowPickup": False}, 10)
                time.sleep(2)
                k = self.ask(store, {"bb": "checkout", "want": want}, 25)
                if k.get("pickup"):
                    raise Stop("page", "the checkout stays on store pickup (never allowed)")
            if k.get("total") is None and k.get("placeAmount") is not None:
                k["total"] = k["placeAmount"]
            self._step(key, f"checkout read (item ${k.get('base')}, tax ${k.get('tax')}, shipping ${k.get('shipping')}, total ${k.get('total')})")
            if k.get("placeAmount") is not None and k.get("total") is not None and abs(k["placeAmount"] - k["total"]) > 0.011:
                raise Stop("page", "the Place order button and the total differ")
            if k.get("problems"):
                raise Stop("needyou", "; ".join(k["problems"]))
            if not k.get("identity"):
                raise Stop("identity", "the checkout page does not show this product")
            if not k.get("qtyOne"):
                raise Stop("cart", "the checkout does not show exactly one item")
            if k.get("base") is None:
                raise Stop("page", "the item price is not readable on the checkout page")
            if float(k["base"]) > cap + 0.001:
                raise Stop("overcap", f"checkout item price ${float(k['base']):.2f} is over the cap ${cap:.2f}")
            if k.get("tax") is not None and float(k["tax"]) > (float(k["base"]) + float(k.get("shipping") or 0)) * TAX_SHARE + 0.01:
                raise Stop("needyou", f"tax ${float(k['tax']):.2f} is more than {round(TAX_SHARE * 100)} % of item + shipping")
            if k.get("fees") is not None and float(k["fees"]) > FEES_MAX:
                raise Stop("needyou", "extra fees")
            if (k.get("shipping") or 0) > SHIP_MAX:
                raise Stop("needyou", "shipping over $20 - the buying browser asks you for that one")
            code = None
            if k.get("cvv") and not k.get("cvvFilled"):
                code = _card_code()          # v77: your saved code (encrypted on this PC) - typed into the store's own box, never logged
                if not code:
                    raise Stop("needyou", "the store asks for the card security code - save it in Restalker (Card code (top bar)) so every browser can type it")
                f = self.ask(store, {"bb": "cvv", "value": code}, 8)
                if not f.get("ok"):
                    raise Stop("page", "the security code could not be filled in")
                self._step(key, "security code typed in (your saved code)")
            if not k.get("place"):
                raise Stop("page", "no Place order button on the checkout page")
            # 4) Place order - one browser at a time for a product (the same turn as every store and Amazon)
            self._latch(job, owner, key)
            latched = True
            sx = STILL(key) if STILL else {}
            if sx.get("submissionPending") or sx.get("attempted") or sx.get("purchased"):
                raise Stop("other", "it was ordered (or is being ordered) by another browser")
            if not _still_wanted(job, allow_attempted=False):
                raise Stop("cancelled", "it was switched off or ordered meanwhile")
            _engine_state(job, "submitting", browser=self.name, price=k.get("base"))
            self._step(key, "Place order pressed - waiting for the store's confirmation")
            pl = self.ask(store, {"bb": "place"}, 8)
            if not pl.get("ok") and not pl.get("lost"):
                _engine_state(job, "failed", browser=self.name, reason=pl.get("error") or "Place order could not be pressed")
                raise Stop("page", pl.get("error") or "Place order could not be pressed")
            end = time.time() + CONFIRM_WAIT
            conf = None
            while time.time() < end:
                time.sleep(0.25)
                r = self.ask(store, {"bb": "confirm"}, 4)
                if not r or not r.get("ok"):
                    continue
                if r.get("failed"):
                    conf = r
                    break
                if r.get("cvv"):
                    code2 = None if code else _card_code()
                    if code2 and store != "bestbuy":          # v77: asked AFTER Place order (Walmart may): typed in once
                        code = code2
                        sub = self.ask(store, {"bb": "cvvsubmit", "value": code2}, 10)
                        self._step(key, "security code typed in after Place order" + ("" if sub.get("ok") else " - could not: " + str(sub.get("error") or "")))
                        end = time.time() + CONFIRM_WAIT
                        continue
                    conf = {"unclear": "the store asked for the card security code after Place order"}
                    break
                if r.get("placed") and r.get("order"):
                    conf = r
                    break
                if r.get("placed"):
                    conf = r
            if conf and conf.get("failed"):
                if code and _card_wrong(STORE_NAMES[store], conf["failed"]):
                    _log(f"{self.name} at {STORE_NAMES[store]}: the store turned down the saved card security code - it is not used again until you save it again.")
                _engine_state(job, "failed", browser=self.name, reason=conf["failed"])
                raise Stop("failed", "ORDER NOT PLACED - " + str(conf["failed"]))
            if conf and conf.get("placed"):
                _engine_state(job, "bought", browser=self.name, orderNumber=conf.get("order"))
                return {"ok": True, "order": conf.get("order")}
            _engine_state(job, "unclear", browser=self.name)
            return {"ok": False, "kind": "unclear", "reason": "the order may have been placed - Restalker looks in your orders"}
        except Stop as s:
            shadowing = False
            if cart_mine and s.kind not in ("signin", "check", "unclear", "overcap", "identity"):
                try:
                    shadowing = bool(_cmd({"type": "BB_SHADOWQ", "cartStore": store}, 3).get("active"))
                except Exception:
                    shadowing = False
            if cart_mine and not shadowing and s.kind not in ("signin", "check", "unclear"):
                try:                                   # nothing was ordered: this item leaves the cart again (only while this browser has the cart)
                    if not on_cart(self.url()):
                        self.goto(st["cart"])
                    for _ in range(3):
                        c = self.ask(store, {"bb": "cart", "want": want}, 8)
                        if not c.get("ok") or not any(i.get("mine") for i in (c.get("items") or [])):
                            break
                        self.ask(store, {"bb": "remove", "want": want}, 12)
                        time.sleep(1)
                except Exception:
                    pass
            raise
        finally:
            if latched:
                _cmd({"type": "BB_UNLATCH", "group": job.get("group"), "owner": owner}, 5)
            if cart_mine:
                _cmd({"type": "BB_CARTUNLOCK", "cartStore": store, "owner": owner}, 5)

    SIGNIN_WAIT = 300.0        # v78b: how long a browser waits (window on your screen) for you to sign in at a store's checkout

    def _show(self, on):
        """Brings this browser's own window onto your screen (on=True) or parks it off screen again. Only browsers with a window
        (Chrome / Edge / Hidden Chrome); never anything of yours."""
        try:
            cdp = self.ctx.new_cdp_session(self.page)
            wid = cdp.send("Browser.getWindowForTarget")["windowId"]
            b = {"left": 80, "top": 40, "width": 1280, "height": 900} if on else {"left": -32000, "top": -32000}
            cdp.send("Browser.setWindowBounds", {"windowId": wid, "bounds": dict(b, windowState="normal")})
            try:
                cdp.detach()
            except Exception:
                pass
            if on:
                try:
                    self.page.bring_to_front()
                except Exception:
                    pass
            return True
        except Exception:
            return False

    def _signin_wait(self, store, key, why, is_co, is_si, on_cart):
        """v78b (your report: "I only saw chrome windows pop up for signing into the checkout"): the store asks to sign in at its checkout ->
        this browser's OWN window comes onto your screen at that sign-in, you sign in there (tick Keep me signed in; the program never types a
        password), and this browser goes straight on to the checkout. Firefox / Camoufox run without a window: they stop, and their
        'sign in' link (under the store column) opens one. Returns the checkout address, or raises Stop('signin')."""
        auto = self._auto_signin(store, here=True)
        if auto:
            # v90b: signed itself in with your saved sign-in - back to the cart and on to the checkout (below), nobody is asked
            self._step(key, "signed itself in - going on to the checkout")
            try:
                self.goto(STORES[store]["cart"])
            except Exception:
                pass
        elif self.kind not in ("chrome", "edge", "stealth", "chromium"):
            raise Stop("signin", why)
        elif time.time() - self.si_asked.get(store, 0) < self.SIGNIN_ASK_EVERY:
            # v95 (diagnostics 77: 27 sign-in windows popped up in one night - each restock asked again; owner: "not ask me multiple
            # times per session"): asked ONCE; until this browser is signed in there it sits this store out quietly (the others buy)
            raise Stop("signin", why + f" - {self.name} sits out at {STORE_NAMES[store]} until it is signed in there (you were asked once)")
        if not auto:
            self.si_asked[store] = time.time()
        shown = False if auto else self._show(True)
        self.state = "waiting for your sign-in at " + STORE_NAMES[store]
        if not auto:
            self._step(key, f"{STORE_NAMES[store]} wants you to sign in - {self.name}'s window is on your screen: sign in there (tick Keep me signed in); it then goes on by itself")
            _log(f"{self.name} at {STORE_NAMES[store]}: the store asks you to sign in at its checkout - {self.name}'s window " +
                 ("is on your screen now" if shown else "is open") + ". Sign in there (tick 'Keep me signed in'); this browser then goes on to the checkout by itself."
                 + ("" if _have_login(store) else " (Save this store's sign-in under Sign-ins (top bar), and the browsers sign themselves in.)"))
        try:
            if ASK and not auto:
                ASK(key, (self._job or {}).get("name") or key, f"ACTION NEEDED - {self.name} at {STORE_NAMES[store]}: sign in at the checkout",
                    f"{self.name}'s window is on your screen at {STORE_NAMES[store]}'s sign-in. Sign in there and tick 'Keep me signed in' - "
                    "it then goes on to the checkout by itself (it waits 5 minutes). Away from the PC? Open the Chrome Remote Desktop app on your "
                    "phone (https://remotedesktop.google.com/access) and sign in in that window. The program never types your password.")
        except Exception:
            pass
        t_end, last_press = time.time() + (60 if auto else self.SIGNIN_WAIT), time.time() - (10 if auto else 0)
        try:
            while time.time() < t_end:
                if not _still_wanted({"key": key}, allow_attempted=False):
                    raise Stop("other", "it was ordered or switched off meanwhile")
                cur = self.url()
                if is_co(cur):
                    self.signed[store] = True
                    self.si_asked.pop(store, None)            # (v95: seen signed in -> it takes part at this store again)
                    self._step(key, "signed in - going on to the checkout")
                    return cur
                if not is_si(cur):
                    pz = self.ask(store, {"bb": "ping", "check": True}, 2)
                    if not pz.get("check") and on_cart(cur) and time.time() - last_press > 4:
                        last_press = time.time()             # (signed in, still on the cart: Check out once more)
                        self.ask(store, {"bb": "tocheckout", "wait": 3000}, 6)
                    elif not pz.get("check") and not on_cart(cur) and cur.startswith(STORES[store]["origin"]) and time.time() - last_press > 6:
                        last_press = time.time()             # (signed in, sent somewhere else: back to the cart)
                        try:
                            self.goto(STORES[store]["cart"])
                        except Exception:
                            pass
                time.sleep(0.5)
            self.signed[store] = False
            raise Stop("signin", why + " (nobody signed in within 5 minutes)")
        finally:
            self.state = "ready"
            if shown:
                self._show(False)

    SIGNIN_ASK_EVERY = 6 * 3600.0   # v95: you are asked to sign a browser in at a store at most once in this time
    SHADOW_AFTER = 2.0          # v87: seconds another browser has held the cart before this one looks whether the item is in it ...
    SHADOW_EVERY = 1.5          # ... and then this often

    def _take_cart(self, store, owner, job, info=None):
        """-> "mine" (this browser adds the item) or "shadow" (another browser has the cart and the item is already in it: this browser
        goes to the checkout too, without adding or removing anything)."""
        t0, told, last_look = time.time(), False, 0.0
        want = {"sku": job.get("sku") or (info or {}).get("sku"), "tokens": list(job.get("tokens") or []), "forbid": list(job.get("forbid") or []),
                "name": job.get("name")}
        while True:
            r = _cmd({"type": "BB_CARTLOCK", "cartStore": store, "owner": owner, "key": job["key"], "since": int((t0 - 2) * 1000)}, 5)
            if r.get("verdict"):               # v78: another browser just found something about THE PRODUCT here - not repeated
                v = r["verdict"]
                raise Stop("other", f"another browser ({str(v.get('owner') or '').split(':')[0]}) just found: {v.get('reason')}")
            if r.get("ok"):
                if told:
                    # v76: the browser that just let the cart go may have bought it a moment ago (its record arrives a little later):
                    # look once more before adding anything to the cart
                    time.sleep(0.5)
                    if _claimed_now(job) or not _still_wanted(job, allow_attempted=False):
                        _cmd({"type": "BB_CARTUNLOCK", "cartStore": store, "owner": owner}, 5)
                        raise Stop("other", "it was ordered meanwhile")
                    self._step(job["key"], f"the cart is free now - going on ({time.time() - t0:.1f} s)")
                return "mine"
            if r.get("reason") and not r.get("holder"):
                raise Stop("page", "the buying engine did not answer (" + str(r.get("reason")) + ")")
            if not told:
                told = True
                self._step(job["key"], f"ready - {str(r.get('holder')).split(':')[0]} is using the {STORE_NAMES[store]} cart; going on the moment it is free")
            if _claimed_now(job) or not _still_wanted(job, allow_attempted=False):
                raise Stop("other", "it was ordered or switched off meanwhile")
            now = time.time()
            if now - t0 >= self.SHADOW_AFTER and now - last_look >= self.SHADOW_EVERY and not os.environ.get("RK_NO_SHADOW"):
                last_look = now
                try:
                    if not re.search(r"/cart", self.url() or "", re.I):
                        self.goto(STORES[store]["cart"])
                    c = self.ask(store, {"bb": "cart", "want": want, "wait": 3000}, 6)
                    tgt = c.get("target") or {}
                    if c.get("check"):
                        raise Stop("check", c["check"])
                    if tgt and c.get("count") == 1 and (not tgt.get("qty") or tgt.get("qty") == 1):
                        _cmd({"type": "BB_SHADOW", "cartStore": store, "owner": owner}, 5)
                        return "shadow"
                except Stop:
                    raise
                except Exception:
                    pass
            if time.time() - t0 > 720:
                raise Stop("page", "the cart stayed busy")
            time.sleep(0.15)

    def _latch(self, job, owner, key, max_wait=720):
        t0, told = time.time(), False
        while True:
            if _HOLD["on"]:
                raise Stop("cancelled", "stopped by you (" + _HOLD["why"] + ")")     # v90b: never presses Place order after a stop
            r = _cmd({"type": "BB_LATCH", "group": job.get("group"), "owner": owner}, 5)
            if r.get("ok"):
                return
            if r.get("other"):
                raise Stop("other", "it was ordered at " + str(r["other"]))
            if r.get("reason") and not r.get("holder"):
                raise Stop("page", "the buying engine did not answer (" + str(r.get("reason")) + ")")
            if not told:
                told = True
                self._step(key, f"ready - {r.get('holder')} is placing the order this moment; pressed here at once if that one does not go through")
            if time.time() - t0 > max_wait:
                raise Stop("page", "waited too long for the other browser")
            self._view_tick()
            time.sleep(0.1)


def _cmd(c, timeout=5.0):
    try:
        if COMMAND is None:
            return {"ok": False, "reason": "no buying engine"}
        return COMMAND(c, timeout) or {"ok": False}
    except Exception as e:
        return {"ok": False, "reason": str(e)[:120]}


_claimed = {}              # v76: product group / link -> what a browser of this program did with it just now (bought / submitting / unclear)


def _amz_done(job, browser, state, order=None, price=None):
    """v88: an Amazon order placed (or maybe placed) by one of these browsers -> the buying browser's record of the product says so
    (Restalker then announces it and switches the product's auto-buy off - one per product), and no other browser presses again."""
    with _lock:
        for g in (job.get("group"), job["key"]):
            if g:
                _claimed[g] = (state, time.time())
    r = _cmd({"type": "RK_AMZ_EXTRA_STATE", "productId": job.get("pid"), "group": job.get("group"), "state": state, "browser": browser,
              "orderNumber": order, "price": price}, 10)
    if not r.get("ok"):
        _log(f"could not write the Amazon order state ({state}) for {job['key']}: {r.get('reason')} - asking again")
        def again():
            for _ in range(30):
                time.sleep(2)
                if _cmd({"type": "RK_AMZ_EXTRA_STATE", "productId": job.get("pid"), "group": job.get("group"), "state": state, "browser": browser,
                         "orderNumber": order, "price": price}, 10).get("ok"):
                    return
        threading.Thread(target=again, daemon=True).start()


def _engine_state(job, state, **kw):
    if state in ("bought", "submitting", "unclear"):
        with _lock:
            for g in (job.get("group"), job["key"]):
                if g:
                    _claimed[g] = (state, time.time())
    elif state == "failed":
        with _lock:
            for g in (job.get("group"), job["key"]):
                if g and (_claimed.get(g) or ("",))[0] == "submitting":
                    _claimed.pop(g, None)
    r = _cmd(dict({"type": "BB_EXTRA_STATE", "store": job["store"], "key": job["key"], "state": state}, **kw), 8)
    if not r.get("ok"):
        _log(f"could not write the order state ({state}) for {job['key']}: {r.get('reason')}")


def _card_code():
    try:
        import cardcode
        return cardcode.get()
    except Exception:
        return None


def _card_wrong(store_name, text):
    try:
        import cardcode
        if cardcode.looks_wrong(text) and cardcode.mark_wrong(store_name, text):
            _cmd({"type": "BB_SETCODE", "value": ""}, 5)
            return True
    except Exception:
        pass
    return False


def _claimed_now(job):
    """v76: True when another browser of this program bought it (or is pressing Place order / may have ordered) within the last 15 minutes."""
    with _lock:
        for g in (job.get("group"), job["key"]):
            c = _claimed.get(g) if g else None
            since = float(job.get("detected") or 0) or time.time() - 900       # (only for THIS restock - a link set to buy again starts fresh)
            if c and c[0] in ("bought", "unclear") and c[1] >= since - 1:
                return True
    return False


ASK = None                 # set by amazon_buy: (key, product name, title, text) -> an ACTION NEEDED message to you (PC + phone)
STILL = None               # set by amazon_buy: (key) -> {"wanted", "purchased", "attempted", "locked"}


def _still_wanted(job, allow_attempted=True):
    """False when the link was switched off, bought, locked - or (allow_attempted=False) ordered / maybe ordered by another browser.
    While another browser is PRESSING Place order for it (submissionPending) this browser keeps waiting: True."""
    if _HOLD["on"]:
        return False                              # v90b: emergency stop / buying OFF / Stop
    try:
        s = STILL(job["key"]) if STILL else {"wanted": True}
    except Exception:
        return True
    if s.get("purchased") or s.get("locked"):
        return False
    if s.get("submissionPending"):
        return True
    if not s.get("wanted"):
        return False
    if not allow_attempted and s.get("attempted"):
        return False
    return True


# ---------------------------------------------------------------- what Restalker calls
_late = {"on": False}


def start():
    """Starts every other buying browser (in the background)."""
    _started["on"] = True
    for k in enabled_kinds():
        old = _closing.get(k)
        if old is not None and old.th.is_alive():
            # (switched off a moment ago and still closing: started once it has closed - never two copies on one profile)
            def later(k=k, old=old):
                old.th.join(120)
                _closing.pop(k, None)
                if k in enabled_kinds() and _started["on"]:
                    start()
            threading.Thread(target=later, daemon=True, name="buy-restart-" + k).start()
            continue
        _closing.pop(k, None)
        with _lock:
            if k not in _workers or not _workers[k].th.is_alive():
                _workers[k] = Worker(k)
    if os.environ.get("RK_EXTRA_BUYERS") is None and "stealth" not in _workers and not _late["on"]:
        _late["on"] = True

        def _wait():          # v76: Hidden Chrome joins as soon as its small add-on has finished installing (first start only)
            try:
                import browser_fetch
                for _ in range(360):
                    if browser_fetch.INSTALLS.get("stealth", {}).get("state") in ("unavailable",):
                        return
                    if browser_fetch.stealth_ready():
                        start()
                        return
                    time.sleep(10)
            finally:
                _late["on"] = False
        threading.Thread(target=_wait, daemon=True, name="buy-stealth-wait").start()


def go(job):
    """A restock of a store link that is set to buy -> every other browser starts its checkout now (at the same moment)."""
    if job.get("store") not in STORES or _HOLD["on"]:
        return 0
    n = 0
    with _lock:
        ws = list(_workers.values())
    if str(job.get("source") or "").startswith("same product"):
        return 0          # v80: only a restock seen AT this store starts the other browsers there (another store's restock: the buying browser looks)
    for w in ws:
        if w.state != "ready":                    # (v90: whatever the sign-in check said - see _buy)
            continue
        if w.rest_until.get(job["store"], 0) > time.time():
            continue
        if w.busy == job["key"] or job["key"] in w.pending:
            continue
        f = _fails.get((w.kind, job["key"]))
        if f and f[0] >= LOCK_AFTER and time.time() - f[1] < 300 and (len(f) < 3 or f[2] == (job.get("detected") or 0)):
            continue
        with _lock:
            w.pending[job["key"]] = job
        w.q.put(dict(job))
        n += 1
    return n


_HOLD = {"on": False, "why": "", "at": 0.0}


def hold(on, why=""):
    """v90b: True = every one of these browsers stops at once: no new checkout starts, none presses Place order (emergency stop /
    buying OFF / Stop). False = they may buy again."""
    _HOLD.update(on=bool(on), why=str(why), at=time.time())
    if on:
        with _lock:
            for w in _workers.values():
                w.pending.clear()
        _log(f"[buy-browsers] every browser stops buying now ({why}).")


def busy_with(key):
    """v90: is any of these browsers checking out (or about to check out) this product link right now?"""
    with _lock:
        return any(w.busy == key or key in w.pending for w in _workers.values())


def signin(kind, store):
    w = _workers.get(kind)
    if not w or store not in STORES:
        return {"ok": False, "reason": "that browser is not running"}
    if w.busy:
        return {"ok": False, "reason": w.name + " is checking out right now - try again in a moment"}
    w.q.put({"signin": True, "store": store})
    return {"ok": True}


def check_accounts():
    try:
        start()               # (a browser installed since, or one that stopped)
    except Exception:
        pass
    for w in list(_workers.values()):
        if w.state == "ready" and not w.busy:
            for s in STORES:
                w.q.put({"account": True, "store": s})


def fetch_kinds(store):
    """v81: the other buying browsers that can read this store's data for the sweepers right now (started, not checking out, not
    waiting for your sign-in, not resting at that store after a block)."""
    if store not in READ_ORIGINS:
        return []
    now = time.time()
    with _lock:
        ws = list(_workers.items())
    return [k for k, w in ws if w.state == "ready" and not w.busy and not w.visible_for and w.rest_until.get(store, 0) <= now
            and w.ctx is not None and w.q.waiting_fetches() < 2]


def fetch(kind, store, url, timeout=8.0):
    """v81: one read of a store's data through browser `kind` (for the sweepers). -> (text, error, final address)."""
    w = _workers.get(kind)
    if not w or w.state != "ready" or w.busy:
        return None, "that browser is busy", None
    rep = {"ev": threading.Event(), "r": None}
    w.q.put({"fetch": True, "store": store, "url": url, "until": time.time() + timeout, "reply": rep})
    if not rep["ev"].wait(timeout + 2.0):
        return None, "no answer in time (the browser was busy)", None
    r = rep["r"] or {}
    if r.get("ok") and int(r.get("status") or 0) < 400:
        return r.get("text"), None, r.get("url")
    return None, (f"HTTP {r.get('status')}" if r.get("status") else (r.get("reason") or "no answer")), r.get("url")


def busy(store=None):
    """True while one of these browsers checks out (v86: at `store` only, when given)."""
    ws = [w for w in list(_workers.values()) if w.busy]
    if store is None:
        return bool(ws)
    try:
        from amazon_buy import _store_of_key
    except Exception:
        return bool(ws)
    return any(_store_of_key(str(w.busy).split(":", 1)[-1]) == store for w in ws)


def unlock(key):
    with _lock:
        _claimed.pop(key, None)
    for k in list(_fails):
        if k[1] == key:
            _fails.pop(k, None)


def view(kind, on):
    """v114: show (on=True) / hide this browser's checkout window. The browser's own thread does it (see Worker._view_tick)."""
    w = _workers.get(kind)
    if not w or w.state == "failed":
        return {"ok": False, "reason": "that browser is not running"}
    if kind not in Worker.WINDOWED:
        return {"ok": False, "reason": w.name + " runs without a window - there is nothing to show (its steps are listed under the store columns)"}
    w.view_want = bool(on)
    if not w.busy:
        w.q.put({"view": True})
    return {"ok": True, "browser": w.name}


def browser_pid(kind):
    """v114: the main process of browser `kind` (for putting its window in front of your others)."""
    w = _workers.get(kind)
    if w is not None and w.proc is not None:
        return w.proc.pid
    try:
        import psutil
        mark = f"--rk-store=buy-{kind}"
        for p in psutil.process_iter(["cmdline"]):
            cl = " ".join(p.info.get("cmdline") or [])
            if mark in cl and "--type=" not in cl:
                return p.pid
    except Exception:
        pass
    return None


def views():
    """v114: the browsers whose checkout window is on your screen now."""
    return [k for k, w in list(_workers.items()) if w.view_on]


def status():
    out = {}
    for k, w in list(_workers.items()):
        out[k] = {"name": w.name, "state": w.state, "detail": w.detail, "signed": dict(w.signed), "busy": w.busy, "step": w.step if w.busy else "",
                  "since": w.since if w.busy else None, "signin_store": w.visible_for,
                  "windowed": k in Worker.WINDOWED, "view": bool(w.view_on)}
    return out


def report():
    lines = [f"other buying browsers ({VERSION}): " + (", ".join(f"{w.name}={w.state}" for w in _workers.values()) or "none running")
             + "; switched off by you (v97 Browsers tab): " + (", ".join(NAMES.get(k, k) for k in sorted(off_kinds())) or "none")]
    for w in _workers.values():
        lines.append(f"  {w.name}: {w.state} {w.detail} | signed in: " + ", ".join(f"{STORE_NAMES[s]}={v}" for s, v in w.signed.items()))
    with _lock:
        ev = list(_events[-60:])
    for e in ev:
        lines.append("  " + time.strftime("%H:%M:%S", time.localtime(e["at"])) + f" {e['browser']} {e['key']}: {e['step']}"
                     + ("" if "ok" not in e else f" ok={e.get('ok')} {e.get('kind') or ''} {e.get('reason') or ''} {e.get('order') or ''}"))
    return "\n".join(lines)


def stop():
    _started["on"] = False
    for w in list(_workers.values()):
        w.q.put(None)
