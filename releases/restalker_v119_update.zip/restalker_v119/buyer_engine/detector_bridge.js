/* Restalker link (v58) for the field-proven August checkout buyer.
 * No checkout logic or content script is changed by this adapter.
 * Restalker emits advisory restock signals; the buyer independently reloads
 * and validates the exact ASIN before using existing purchase authorization.
 * v54/v55 add: identity (only Restalker's own engine is accepted by Restalker), live product state pushed on every change,
 * and Restalker's commands (arm, disarm, cap, global switches, emergency stop, buy again, shipping approval), which are
 * passed to the SAME handler the Buyer's own dashboard uses, so every existing safety check still applies.
 */
'use strict';
(() => {
  const ADDRESS = 'ws://127.0.0.1:17861/bridge';
  const ASIN = /^B[A-Z0-9]{9}$/;
  const SYNC_INTERVAL_MS = 10000;
  const EVENTS_MAX_AGE_MS = 600000;
  const ENGINE = 'restalker-buyer-engine';
  const CODE = 'v119';      // v58: the version of THIS file's code (Restalker compares it: a browser that still runs old cached code is restarted fresh)
  // Commands Restalker may send. Each goes through the Buyer's own message handler (same checks as its dashboard).
  const ALLOWED = new Set(['RK_RUNTIME_PRODUCT','RK_AMZ_EXTRA_STATE','ARM_PRODUCT','DISARM_PRODUCT','SET_PRODUCT','SET_GLOBAL','EMERGENCY_STOP','REARM_PURCHASED',
    'APPROVE_SHIPPING','CANCEL_SHIPPING','REFRESH_PRODUCT','EXPORT_DIAGNOSTICS','GET_ALL']);
  function create({catalog, ps, g, check, diag, setg, handle}) {
    let socket = null, interval = null, connecting = false, dirty = false, changeTimer = null;
    let lastError = null, lastSync = null, lastSyncAck = null, lastEventAt = 0, syncHash = null;
    let revision = 0, syncPending = false, syncPendingAt = 0, acceptedRevision = 0, connections = 0;
    const seen = new Map();
    function connected(){return socket?.readyState === 1}
    function active(){return connected()&&lastSyncAck?.ok===true}
    function status(){return {connected:connected(),connections,lastError,lastSync,lastSyncAck,lastEventAt,acceptedRevision,requestedRevision:revision,mode:'restalker-engine'}}
    function emit(type, values){try{void diag(type, values)}catch{}}
    // v90: nothing but the hello goes out before the hello (diagnostics 71: a state report sent a moment before the hello made Restalker
    // take the engine for the separate Buyer extension and refuse it - every time, for 20 minutes, so nothing could be bought)
    let helloSent=false;
    function send(m){if(!connected())return false;if(!helloSent&&m?.type!=='hello')return false;try{socket.send(JSON.stringify(m));return true}catch(e){lastError=String(e?.message||e);return false}}
    async function token(){const ctl=new AbortController(),to=setTimeout(()=>ctl.abort(),4000);try{const r=await fetch(chrome.runtime.getURL('restalker_link.json'),{cache:'no-store',signal:ctl.signal});const j=await r.json();return String(j.token||'')}catch{return ''}finally{clearTimeout(to)}}
    const num=v=>Number.isFinite(Number(v))&&v!==null&&v!==''?Number(v):null;
    async function snapshot(){
      const [items,global] = await Promise.all([catalog(),g()]);
      const states=await Promise.all(items.map(p=>ps(p)));
      // v55: the live checkout step (cart / checkout / shipping approval / submitted) of a product being bought
      const flowKeys=states.filter(s=>(s.inProgress||s.submissionPending||s.approval)&&Number.isInteger(s.tabId)).map(s=>'flow:'+s.tabId);
      const flows=flowKeys.length?await chrome.storage.local.get(flowKeys):{};
      const unique=new Set(),products=[];
      for(let i=0;i<items.length;i++){
        const p=items[i],s=states[i],asin=String(p.customProduct?(s.customAsin||p.asin||''):p.asin||'').toUpperCase();
        if(!ASIN.test(asin)||unique.has(asin))continue;
        unique.add(asin);
        const name=String(s.customName||p.name||('Amazon '+asin)).trim().slice(0,180);
        const cap=Number(s.cap);
        const a=s.approval;
        products.push({asin,id:p.id,set:p.set||'',custom:!!p.customProduct,name:name.length>=5?name:'Amazon '+asin,
          upc:/^\d{12,14}$/.test(String(s.customUpc||p.upc||''))?String(s.customUpc||p.upc):'',
          cap:Number.isFinite(cap)&&cap>0?cap:null,
          monitor:!!s.monitor&&!!s.enabled&&!s.purchased&&!s.attempted,
          autoBuy:!!s.autoBuy&&!!s.armed&&!s.purchased&&!s.attempted,
          armed:!!s.armed&&!s.purchased&&!s.attempted,
          purchased:!!s.purchased,attempted:!!s.attempted,inProgress:!!s.inProgress,submissionPending:!!s.submissionPending,
          status:String(s.status||'').slice(0,240),price:num(s.price),lastCheck:num(s.lastCheck),submitAt:num(s.submitAt),
          orderNumber:s.orderNumber?String(s.orderNumber).slice(0,40):null,
          step:(Number.isInteger(s.tabId)&&flows['flow:'+s.tabId]?.id===p.id)?String(flows['flow:'+s.tabId].step||'').slice(0,40):null,
          hitAt:num(s.hitDetectedAt),campaignAttempts:num(s.campaignAttempts),
          deliver:(s.deliver==='yes'||s.deliver==='no')?s.deliver:null,deliverAt:num(s.deliverAt),deliverNote:String(s.deliverNote||'').slice(0,120),   // v111
          approval:a?{base:num(a.base),tax:num(a.tax),shipping:num(a.shipping),total:num(a.total),created:num(a.created)}:null});
      }
      let bbProducts=[];try{bbProducts=globalThis.RestalkerShops?await globalThis.RestalkerShops.snapshot():[]}catch{}
      let amazonProbe=null;try{amazonProbe=(await chrome.storage.local.get('rk:amazonProbe'))['rk:amazonProbe']||null}catch{}
      return {bbProducts,amazonProbe,signinOpen:signinWin!==null,globalMonitoring:!!global.monitoring&&!global.emergencyStop,
        globalLivePurchase:!!global.liveGlobal&&!global.emergencyStop,
        emergencyStop:!!global.emergencyStop,cartOwner:global.cartOwner||null,
        phoneTopic:String(global.ntfyTopic||''),products};
    }
    async function sync(force=false){
      if(!connected())return false;
      if(syncPending){if(Date.now()-syncPendingAt<15000){dirty=true;return false}syncPending=false;syncHash=null;lastError='Restalker catalog ACK timed out; retrying'}
      let s;try{s=await snapshot()}catch(e){lastError='snapshot: '+String(e?.message||e);return false}
      if(!s.products.length){lastError='No valid ASINs to synchronize';return false}
      const hash=JSON.stringify(s);
      if(!force&&hash===syncHash)return true;
      revision=Math.max(Date.now(),revision+1,acceptedRevision+1);
      syncPending=true;syncPendingAt=Date.now();lastSync=new Date().toISOString();dirty=false;
      const sent=send({type:'catalog_sync',revision,...s});
      if(sent){syncHash=hash;emit('detector_catalog_sync_sent',{revision,products:s.products.length,active:s.products.filter(x=>s.globalMonitoring&&x.monitor).length})}
      else {syncPending=false;syncHash=null}
      return sent;
    }
    function ack(event, {ok=true,retryable=false,reason='',deduped=false}={}){
      return send({type:'ack',eventId:String(event.eventId||'').slice(0,100),
        amazonAsin:String(event.amazonAsin||''),ok,reason:String(reason).slice(0,300),retryable,deduped});
    }
    async function onRestock(event){
      if(event.store&&event.store!=='amazon'){   // v56/v60: Best Buy, Target, Walmart, GameStop restocks go to Restalker's shop checkouts
        if(!globalThis.RestalkerShops){ack(event,{ok:false,reason:'shop checkout missing'});return}
        const id=String(event.eventId||''),k=id+'|'+event.store+'|'+String(event.key||''),seenAt=seen.get(k);
        if(seenAt&&Date.now()-seenAt<EVENTS_MAX_AGE_MS){ack(event,{deduped:true,reason:'already accepted'});return}
        try{const r=await globalThis.RestalkerShops.onRestock(event);if(r.ok&&/dispatched/.test(r.reason||''))seen.set(k,Date.now());ack(event,r)}
        catch(e){ack(event,{ok:false,retryable:true,reason:'buyer handler exception: '+String(e?.message||e)})}
        return;
      }
      const asin=String(event.amazonAsin||'').toUpperCase(),id=String(event.eventId||'');
      if(!ASIN.test(asin)||!id||id.length>100){ack(event,{ok:false,reason:'invalid signal identity'});return}
      const eventAt=Date.parse(event.detectedAt||'');
      if(!Number.isFinite(eventAt)||Date.now()-eventAt>EVENTS_MAX_AGE_MS||eventAt>Date.now()+5000){ack(event,{ok:false,reason:'stale or future signal'});return}
      const key=id+'|'+asin,seenAt=seen.get(key);
      if(seenAt&&Date.now()-seenAt<EVENTS_MAX_AGE_MS){ack(event,{deduped:true,reason:'already accepted'});return}
      try{
        const [items,global]=await Promise.all([catalog(),g()]);
        const st=await Promise.all(items.map(p=>ps(p)));
        const i=items.findIndex((p,j)=>String(p.customProduct?(st[j].customAsin||p.asin||''):p.asin||'').toUpperCase()===asin);
        if(i<0){ack(event,{ok:false,retryable:!lastSyncAck?.ok,reason:'ASIN absent from buyer catalog'});return}
        const p=items[i],s=st[i];
        if(s.purchased||s.attempted){ack(event,{ok:true,reason:'target completed; manual rearm required'});return}
        if(!global.monitoring||!s.monitor||!s.enabled||global.emergencyStop){ack(event,{ok:true,reason:'monitor disabled'});return}
        if(global.cartOwner){
          if(global.cartOwner===p.id){ack(event,{ok:true,reason:'target already in checkout'});return}
          ack(event,{ok:false,retryable:true,reason:'other checkout owns buyer; retry after release'});return;
        }
        if(s.inProgress||s.submissionPending||s.approval){ack(event,{ok:true,reason:'target checkout already started'});return}
        lastEventAt=Date.now();
        // The original buyer's exact-ASIN check and checkout engine is the
        // ONLY authority to buy; detector prices never authorize purchase.
        const checked=await check(p,{force:true});
        if(!checked){ack(event,{ok:false,retryable:true,reason:'fresh Amazon validation deferred/failed'});return}
        seen.set(key,Date.now());
        emit('detector_signal_verified_dispatch',{asin,source:String(event.source||event.store||'detector').slice(0,100),eventId:id});
        ack(event,{ok:true,reason:'fresh Amazon check dispatched'});
      }catch(e){lastError=String(e?.message||e);ack(event,{ok:false,retryable:true,reason:'buyer handler exception: '+lastError})}
    }
    // ---- v54: Restalker's commands, through the Buyer's own handler (acting as its dashboard)
    function call(c){
      return new Promise(res=>{
        let done=false;const t=setTimeout(()=>{if(!done){done=true;res({ok:false,reason:'engine did not answer in time'})}},120000);
        const sender={id:chrome.runtime.id,url:chrome.runtime.getURL('dashboard.html')};
        try{handle(c,sender,r=>{if(!done){done=true;clearTimeout(t);res(r||{ok:false})}})}
        catch(e){if(!done){done=true;clearTimeout(t);res({ok:false,reason:String(e?.message||e)})}}
      });
    }
    async function account(){
      try{
        const r=await fetch('https://www.amazon.com/gp/css/homepage.html',{credentials:'include',cache:'no-store'});
        const t=(await r.text()).slice(0,400000);
        const m=t.match(/nav-link-accountList-nav-line-1[^>]*>\s*Hello,\s*([^<]{1,60})</i);
        const name=m?m[1].trim():null;
        const signin=/\/ap\/signin/i.test(r.url)||!name||/^sign in$/i.test(name);
        const check=/captcha|enter the characters you see/i.test(t);
        return {ok:true,signedIn:!signin&&!check,name:signin?null:name,challenge:check,httpStatus:r.status};
      }catch(e){return {ok:false,reason:String(e?.message||e)}}
    }
    // v55: after an unclear result, Restalker asks: is this product in the account's recent Amazon orders?
    // v114 (diagnostics 92: a "Buy one more" order was taken as placed because the product's FIRST order, 80 minutes earlier, was in the
    // list): the answer names EVERY order the product is in (orderIds); Restalker counts only an order that was not there before the
    // checkout began. ORDER_SNAPSHOT reads the list once for several products (what was there before - read when nothing is being bought).
    function ordersWith(t,asin){
      const nums=[...t.matchAll(/\b(\d{3}-\d{7}-\d{7})\b/g)].map(x=>[x.index,x[1]]),rx=new RegExp('(?:/dp/|/gp/product/|asin=)'+asin,'ig'),ids=[];let m;
      while((m=rx.exec(t))){let id=null;for(const [i,n] of nums){if(i<m.index)id=n;else break}if(id&&!ids.includes(id))ids.push(id)}
      return ids;
    }
    async function orderPage(start){
      const urls=start?['https://www.amazon.com/your-orders/orders?timeFilter=last30&startIndex='+Number(start)]:['https://www.amazon.com/your-orders/orders?timeFilter=last30','https://www.amazon.com/gp/css/order-history?orderFilter=last30'];
      let last=null;
      for(const u of urls){
        try{
          const r=await fetch(u,{credentials:'include',cache:'no-store'});const t=await r.text();
          if(/\/ap\/signin/i.test(r.url))return {ok:true,checked:false,reason:'not signed in to Amazon'};
          if(!/order/i.test(t)||t.length<2000){last='order page empty';continue}
          return {ok:true,checked:true,text:t};
        }catch(e){last=String(e?.message||e)}
      }
      return {ok:true,checked:false,reason:last||'order page unavailable'};
    }
    async function orderCheck(asin){
      asin=String(asin||'').toUpperCase();if(!ASIN.test(asin))return {ok:false,reason:'not a valid Amazon product code'};
      const pg=await orderPage();if(!pg.checked)return {ok:true,checked:false,reason:pg.reason};
      const ids=ordersWith(pg.text,asin);
      return {ok:true,checked:true,found:ids.length>0,orderNumber:ids[0]||null,orderIds:ids};
    }
    // v115: every page of the last 30 days (Amazon shows 10 orders a page), so Restalker can also check its purchase list against them.
    // complete = every order of the 30 days was seen (the last page was not full) - only then is the list compared.
    async function orderSnapshot(asins){
      const list=(Array.isArray(asins)?asins:[]).map(a=>String(a||'').toUpperCase()).filter(a=>ASIN.test(a)).slice(0,200);
      const pg=await orderPage();if(!pg.checked)return {ok:true,checked:false,reason:pg.reason};
      const idsOf=t=>[...new Set([...t.matchAll(/\b(\d{3}-\d{7}-\d{7})\b/g)].map(m=>m[1]))];
      const texts=[pg.text],seen=new Set(idsOf(pg.text)),first=seen.size;let complete=first<10;
      for(let i=1;!complete&&i<6;i++){
        const p2=await orderPage(i*first);if(!p2.checked)break;
        const ids=idsOf(p2.text),fresh=ids.filter(x=>!seen.has(x));
        if(!fresh.length)break;                     // (the same orders again: the page number was not taken - not known to be complete)
        fresh.forEach(x=>seen.add(x));texts.push(p2.text);
        if(ids.length<first)complete=true;
      }
      const orders={};for(const a of list){const all=[];for(const t of texts)for(const x of ordersWith(t,a))if(!all.includes(x))all.push(x);orders[a]=all}
      return {ok:true,checked:true,orders,complete,count:seen.size};
    }
    async function addAsin(asin){
      asin=String(asin||'').toUpperCase();if(!ASIN.test(asin))return {ok:false,reason:'not a valid Amazon product code'};
      const items=await catalog();
      for(const p of items){const s=await ps(p);if(String(p.customProduct?(s.customAsin||''):p.asin||'').toUpperCase()===asin)return {ok:true,productId:p.id,existing:true}}
      const made=await call({type:'ADD_CUSTOM_PRODUCT'});if(!made?.ok||!made.id)return {ok:false,reason:made?.reason||'could not add the product'};
      const set=await call({type:'SET_CUSTOM_ASIN',productId:made.id,asin});
      if(!set?.ok){
        // v90 (diagnostics 73: "metadata navigation timeout" 8 times in 6 minutes - the new listing was deleted and added again each
        // time, so a restock found it "not known" and nothing bought it): when the ASIN itself was taken and only the page's title could
        // not be read yet, the listing is KEPT - its first check reads the title from the page (the exact ASIN is checked as always)
        let kept=false;try{const q=(await catalog()).find(x=>x.id===made.id);if(q){const s=await ps(q);kept=String(s.customAsin||'').toUpperCase()===asin}}catch{}
        if(kept)return {ok:true,productId:made.id,meta:null,metaPending:true,reason:set?.reason||null};
        await call({type:'DELETE_CUSTOM_PRODUCT',productId:made.id});return {ok:false,reason:set?.reason||'could not verify the Amazon listing'}}
      return {ok:true,productId:made.id,meta:set.meta||null};
    }
    // v59b: signing in happens in ONE small separate window with only that store's sign-in page; the buying browser itself stays hidden
    let signinWin=null;
    try{chrome.windows.onRemoved.addListener(id=>{if(id===signinWin){signinWin=null;globalThis.__rkSigninWin=null;void sync(true)}})}catch{}
    async function signinOpen(url){
      if(!/^https:\/\/(www\.)?(amazon|bestbuy|target|walmart|gamestop)\.com\//.test(String(url||'')))return {ok:false,reason:'not a store sign-in page'};
      if(signinWin!==null){try{await chrome.windows.remove(signinWin)}catch{}signinWin=null}
      const w=await chrome.windows.create({url,type:'normal',focused:true,state:'normal',left:120,top:60,width:1100,height:880});
      signinWin=w.id;globalThis.__rkSigninWin=w.id;
      // v65 (test finding): Chrome put this window where the hidden window sits (off-screen, -32000) although a place on screen was
      // asked for - that is why the sign-in / link window "never opened". It is moved onto the screen and brought forward explicitly.
      for(let i=0;i<3;i++){try{await chrome.windows.update(w.id,{state:'normal',left:120,top:60,width:1100,height:880,focused:true,drawAttention:true});
        const n=await chrome.windows.get(w.id);if((n.left||0)>-5000&&(n.top||0)>-5000)break}catch{}await new Promise(r=>setTimeout(r,300))}
      return {ok:true,windowId:w.id};
    }
    // v114 (owner, diagnostics 92: "when checkout is actively happening, there should be a link to pull up the active checkout page(s) for live
    // monitoring (and intervention if necessary)"): the page of a live checkout comes onto your screen. An Amazon product's page shares its
    // window with this browser's other pages, so it is moved into a window of its own first (closing THAT window then stops only this
    // checkout, never the others). Nothing on the page is touched. Restalker puts the window off-screen again when you press Hide.
    const STORE_TAB={bestbuy:'bb:g',target:'tg:g',walmart:'wm:g',gamestop:'gs:g'};
    async function showCheckout(c){
      let tabId=null;
      if(c.productId){const q=(await catalog()).find(x=>x.id===String(c.productId));if(q){const s=await ps(q);if(Number.isInteger(s.tabId))tabId=s.tabId}}
      else if(STORE_TAB[c.store]){
        try{const k=STORE_TAB[c.store],v=(await chrome.storage.local.get(k))[k];if(v&&Number.isInteger(v.tab))tabId=v.tab}catch{}
        if(tabId===null){try{const wid=(globalThis.RestalkerWindows?.own?.()||{})[c.store];if(wid!=null){const ts=await chrome.tabs.query({windowId:wid,active:true});if(ts[0])tabId=ts[0].id}}catch{}}
      }
      if(tabId===null)return {ok:false,reason:'no checkout page is open for it right now'};
      let t;try{t=await chrome.tabs.get(tabId)}catch{return {ok:false,reason:'its checkout page was just closed'}}
      const box={left:140,top:70,width:1180,height:900};
      let wid=t.windowId,alone=false;
      try{const w=await chrome.windows.get(wid,{populate:true});alone=(w.tabs||[]).length===1&&w.id!==globalThis.__rkSigninWin}catch{}
      if(!alone){const nw=await chrome.windows.create({tabId,type:'normal',focused:true,state:'normal',...box});wid=nw.id}
      else await chrome.tabs.update(tabId,{active:true});
      // (as for the sign-in window, v65: Chrome may keep a window where the hidden one sits; it is moved onto the screen explicitly)
      for(let i=0;i<3;i++){try{await chrome.windows.update(wid,{state:'normal',...box,focused:true,drawAttention:true});
        const n=await chrome.windows.get(wid);if((n.left||0)>-5000&&(n.top||0)>-5000)break}catch{}await new Promise(r=>setTimeout(r,300))}
      return {ok:true,windowId:wid,ownWindow:!alone};
    }
    async function signinClose(){if(signinWin!==null){try{await chrome.windows.remove(signinWin)}catch{}signinWin=null}globalThis.__rkSigninWin=null;return {ok:true}}
    async function onCommand(m){
      const id=String(m.cmdId||'').slice(0,80),c=m.command&&typeof m.command==='object'?m.command:{};
      let result;
      try{
        if(c.type==='ACCOUNT_CHECK')result=await account();
        else if(c.type==='SET_TOPIC'){await setg({ntfyTopic:String(c.topic||'').slice(0,120)});result={ok:true}}
        else if(c.type==='ADD_ASIN')result=await addAsin(c.asin);
        else if(c.type==='ORDER_CHECK')result=await orderCheck(c.asin);
        else if(c.type==='ORDER_SNAPSHOT')result=await orderSnapshot(c.asins);
        else if(c.type==='SIGNIN_OPEN')result=await signinOpen(c.url);
        else if(c.type==='SIGNIN_CLOSE')result=await signinClose();
        else if(c.type==='SHOW_CHECKOUT')result=await showCheckout(c);
        else if(c.type==='PAGE_FETCH')result=globalThis.RestalkerReader?await globalThis.RestalkerReader.fetch(String(c.url||''),c.timeoutMs,Array.isArray(c.cookies)?c.cookies.slice(0,8).map(String):null):{ok:false,reason:'reader missing'};
        else if(c.type==='READER_STATUS')result={ok:true,...(globalThis.RestalkerReader?globalThis.RestalkerReader.status():{})};
        else if(String(c.type||'').startsWith('BB_'))result=globalThis.RestalkerShops?await globalThis.RestalkerShops.command(c):{ok:false,reason:'shop checkout missing'};
        else if(!ALLOWED.has(c.type))result={ok:false,reason:'command not allowed: '+String(c.type||'')};
        else result=await call(c);
      }catch(e){result={ok:false,reason:String(e?.message||e)}}
      // (page reads are many and change nothing: not recorded, no sync. v114 (diagnostics 92: "BB_LATCH ok=false" 1,280 times in 40 s - the
      // other browsers ask ten times a second while one of them places the order): a 'wait, X is placing it' answer changes nothing either)
      const quiet=c.type==='PAGE_FETCH'||c.type==='READER_STATUS'||(c.type==='BB_LATCH'&&!!result&&result.ok===false&&!!result.holder);
      if(!quiet)emit('restalker_command',{command:String(c.type||''),productId:c.productId||null,ok:!!result?.ok,reason:result?.reason||null});
      send({type:'command_result',cmdId:id,result});
      if(!quiet)void sync();
    }
    async function onMessage(ev){
      let m;try{m=JSON.parse(String(ev.data||''))}catch{return}
      if(m.type==='heartbeat')return;
      if(m.type==='catalog_sync_ack'){
        lastSyncAck={at:new Date().toISOString(),ok:m.ok===true,revision:m.revision,reason:m.reason||null,enabledProducts:m.enabledProducts??null};
        syncPending=false;
        if(m.ok){acceptedRevision=Math.max(acceptedRevision,Number(m.revision)||0);lastError=null}
        else {lastError='catalog sync rejected: '+String(m.reason||'unknown');syncHash=null;
          if(m.stale&&Number(m.currentRevision)>revision)revision=Number(m.currentRevision)}
        emit('detector_catalog_sync_ack',lastSyncAck);
        if(dirty)void sync();
        return;
      }
      if(m.type==='restock')void onRestock(m);
      if(m.type==='command')void onCommand(m);
    }
    async function connect(){
      if(connecting||connected())return;
      connecting=true;
      const tk=await token();               // v90: the key is read BEFORE connecting, so the hello goes out the moment the link opens
      let ws;try{ws=new WebSocket(ADDRESS)}catch(e){connecting=false;lastError=String(e?.message||e);return}
      socket=ws;helloSent=false;
      ws.onopen=()=>{connecting=false;connections++;lastError=null;lastSyncAck=null;syncHash=null;syncPending=false;
        send({type:'hello',engine:ENGINE,code:CODE,bbCode:String(globalThis.RestalkerBestBuy?.CODE||'')+(globalThis.RestalkerShops?.CODE===globalThis.RestalkerBestBuy?.CODE?'':'+shops'+String(globalThis.RestalkerShops?.CODE||'')),version:chrome.runtime.getManifest().version,name:chrome.runtime.getManifest().name,token:tk,init:globalThis.__RK_INIT||null});
        helloSent=true;
        void sync(true)};
      ws.onmessage=ev=>void onMessage(ev);
      ws.onerror=()=>{lastError='Restalker socket unavailable';};
      ws.onclose=()=>{connecting=false;syncHash=null;syncPending=false;lastSyncAck=null;if(socket===ws){socket=null;helloSent=false}};
    }
    function onChanged(changes){
      // every state change (a check, a checkout step, a purchase) reaches Restalker within a quarter of a second
      if(!connected())return;
      // v75: the diagnostics journal and telemetry are not product state - writing them never starts a new state report (diagnostics 64)
      if(changes&&Object.keys(changes).length&&Object.keys(changes).every(k=>/^(diag|rk:res|resource|telemetry|intel|ri:|perf|traffic|runtimeTraffic)/i.test(k)))return;
      if(changeTimer)clearTimeout(changeTimer);
      changeTimer=setTimeout(()=>{changeTimer=null;void sync()},250);
    }
    function start(){
      if(interval)return;
      try{if(globalThis.RestalkerShops){globalThis.RestalkerShops.setDiag(diag);void globalThis.RestalkerShops.startup().then(()=>sync(true))}}catch{}
      try{chrome.storage.onChanged.addListener(onChanged)}catch{}
      connect();
      interval=setInterval(()=>{if(!connected()){connect();return}void sync();
        const now=Date.now();for(const [k,t] of seen)if(now-t>EVENTS_MAX_AGE_MS)seen.delete(k);
      },SYNC_INTERVAL_MS);
    }
    function stop(){if(interval)clearInterval(interval);interval=null;try{socket?.close()}catch{}socket=null;connecting=false;syncPending=false}
    return {start,stop,status,connected,active,sync,onRestock,snapshot};
  }
  globalThis.MTGDetectorBridge={create};
})();
