/* Restalker v58 - the helper inside the reader tab (see rk_reader.js): fetches a page or data request of THIS store (same site only)
 * exactly like the store's own page does, and hands the text back. Read only. */
'use strict';
(() => {
  if (globalThis.__rkFetch) return; globalThis.__rkFetch = true;
  chrome.runtime.onMessage.addListener((m, sender, respond) => {
    if (!m || m.type !== 'RK_FETCH') return;
    (async () => {
      try {
        const u = new URL(m.url, location.href);
        const site = h => h.split('.').slice(-2).join('.');
        if (u.protocol !== 'https:' || site(u.hostname) !== site(location.hostname)) return respond({ok: false, reason: 'another site'});   // (same store only, e.g. redsky.target.com from www.target.com)
        const ctl = new AbortController(), to = setTimeout(() => ctl.abort(), m.timeoutMs || 25000);
        // v159: a request to the store's own data address (redsky.target.com from www.target.com) is sent the way the store's own page
        // sends it - WITH the browser's own cookies for that store (m.cred 'include'). Until v158 it went without them: a request
        // no real page of the store ever makes. When the browser itself does not allow it (the store's answer has no permission
        // for it), that is said (credFail) and the reader asks again without - see rk_reader.js.
        const same = u.origin === location.origin, cred = same ? 'include' : (m.cred === 'include' ? 'include' : 'omit');
        let r;
        try { r = await fetch(u.href, {credentials: cred, cache: 'no-store', signal: ctl.signal}); }
        catch (e) { clearTimeout(to); return respond({ok: false, reason: String(e && e.message || e), credFail: !same && cred === 'include' && !(e && e.name === 'AbortError')}); }
        let text = await r.text();
        clearTimeout(to);
        const cut = text.length > 2500000;
        if (cut) text = text.slice(0, 2500000);
        // v64: a few of the store's own place cookies when asked for by name (Target: which store / zip its pages use) - nothing else is read
        let picked = null;
        if (Array.isArray(m.cookies) && m.cookies.length) {
          picked = {};
          for (const part of document.cookie.split(';')) {
            const i = part.indexOf('='); const k = part.slice(0, i).trim();
            if (m.cookies.includes(k)) { let v = part.slice(i + 1).trim(); try { v = decodeURIComponent(v); } catch {} picked[k] = v.slice(0, 200); }
          }
        }
        respond({ok: true, status: r.status, url: r.url, text, cut, cookies: picked, sent: same ? 'same' : cred});
      } catch (e) { respond({ok: false, reason: String(e && e.message || e)}); }
    })();
    return true;
  });
})();
