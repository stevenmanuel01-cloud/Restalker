"""v101: updates from one central place (owner 2026-11-05: "yes let's move forward with a centralized github. we do need to solve the issue
though of what you upload there since it would either include my information, or would override and clear my information when I update.
the same would be for all other users, so only updating certain parts is important. ensuring that our architecture is set up to accept
updates without ever affecting individual users saved data").

How your data stays yours:
- An update holds PROGRAM files only, and lists each of them (MANIFEST.json, with a fingerprint per file). Only a name that is a program
  file can be in it: the .py files, stop_restalker.bat, msrp.yaml, new_products.yaml and the two engine folders. Anything else in an
  update - a product list, a purchase list, a sign-in, a setting, any .csv / .txt / .json / .bin at the top of the folder - refuses the
  WHOLE update before one file is touched.
- Nothing is ever deleted. A file the update does not list is never opened.
- Before an update, every data file is copied aside (_update/data_backup_<date>), and the program files it replaces too
  (_update/program_<old version>), so "Go back" restores the version before.
- The update is checked twice before it is used: the whole zip against the fingerprint the release names, and every file inside against
  its own fingerprint. A half-downloaded or changed file is never installed.
- It never installs while a checkout runs. It installs only when you press Install.
The release itself is built by the same rules (build_release below): it can only ever hold program files."""
import hashlib
import io
import json
import os
import re
import shutil
import subprocess
import sys
import threading
import time
import urllib.request
import zipfile

VERSION = "v159"
HERE = os.path.dirname(os.path.abspath(__file__))
SOURCE_FILE = "update_source.txt"           # optional: the address of latest.json (else UPDATE_URL)
UPDATE_URL = "https://raw.githubusercontent.com/stevenmanuel01-cloud/Restalker/main/latest.json"   # v102: the release home (public, program files only)
# v141 (owner, 2026-11-19: "my linked devices need to be considered the master/beta/administrator versions. When future changes are made,
# this should be pushed to my linked devices only ... rolled into a single wider update for all other users"): the owner's PC also reads
# this one - new versions go here first; latest.json (everyone) only when the owner says so
BETA_URL = "https://raw.githubusercontent.com/stevenmanuel01-cloud/Restalker/main/beta.json"
WORK = "_update"
CHECK_EVERY = 3600.0
MAX_ZIP = 60 * 1024 * 1024
PROGRAM_DIRS = ("buyer_engine", "reader_engine")
PROGRAM_TOP = ("stop_restalker.bat", "msrp.yaml", "new_products.yaml")
LOG = print
BUSY = None                                 # () -> a reason it must wait (a checkout runs), or "" (set by app.py)

state = {"checked_at": 0.0, "latest": None, "notes": "", "available": False, "error": "", "installing": False, "result": None,
         "last": None}
_lock = threading.Lock()


def vnum(v):
    m = re.fullmatch(r"v?(\d+)([a-z]?)", str(v or "").strip())
    return (int(m.group(1)), m.group(2)) if m else (0, "")


def source():
    try:
        u = open(os.path.join(HERE, SOURCE_FILE), encoding="utf-8").read().strip()
        if re.match(r"^https://[\w.-]+/\S+$", u):
            return u
    except Exception:
        pass
    return UPDATE_URL


def is_program_file(name):
    """The ONLY names an update may write. Everything else is yours."""
    n = str(name or "")
    if not n or n.startswith("/") or "\\" in n or ":" in n or any(p in ("", ".", "..") for p in n.split("/")):
        return False
    parts = n.split("/")
    if len(parts) == 1:
        return bool(re.fullmatch(r"[A-Za-z0-9_]+\.py", n)) or n in PROGRAM_TOP
    if parts[0] in PROGRAM_DIRS and len(parts) == 2:
        return bool(re.fullmatch(r"[A-Za-z0-9_.-]+\.(js|json|html|css|png)", parts[1]))
    return False


def data_files():
    """Your data in this folder (copied aside before every update): everything at the top that is not a program file, plus icons."""
    out = []
    for n in sorted(os.listdir(HERE)):
        p = os.path.join(HERE, n)
        if os.path.isfile(p) and not is_program_file(n) and os.path.getsize(p) < 200 * 1024 * 1024:
            out.append(n)
    return out


def _sha(b):
    return hashlib.sha256(b).hexdigest()


def _get(url, limit, timeout=30):
    req = urllib.request.Request(url, headers={"User-Agent": "Restalker-updater", "Cache-Control": "no-cache"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        b = r.read(limit + 1)
    if len(b) > limit:
        raise ValueError("too big")
    return b


FETCH = _get


def check(now=None, fresh=False):
    """Asks the release home what the newest version is. -> state (never raises). fresh: past any copy kept on the way (v118)."""
    url = source()
    if url and fresh:
        url += ("&" if "?" in url else "?") + "t=" + str(int(time.time()))
    now = now or time.time()
    with _lock:
        state["checked_at"] = now
        if not url:
            state.update(available=False, error="", latest=None)
            return dict(state)
    try:
        d = json.loads(FETCH(url, 256 * 1024, 20).decode("utf-8", "replace"))
        v = str(d.get("version") or "")
        if not vnum(v)[0] or not str(d.get("url") or "").startswith("https://") or not re.fullmatch(r"[0-9a-f]{64}", str(d.get("sha256") or "")):
            raise ValueError("the release note is incomplete")
        if url.startswith(UPDATE_URL):           # (v141: not when update_source.txt points elsewhere - the tests)
            _public_seen(v)                      # (v142: the version everyone has - this copy shows "b" when it is newer)
            b = _beta(fresh)
            if b and vnum(str(b.get("version"))) > vnum(v):
                d, v = b, str(b.get("version"))
        with _lock:
            state.update(latest=d, error="", notes=str(d.get("notes") or "")[:400], available=vnum(v) > vnum(VERSION))
    except Exception as e:
        with _lock:
            state.update(error=f"could not check for updates: {str(e)[:100]}")
    return dict(state)


def _beta(fresh=False):
    """v141: the owner's PC: the version waiting for the owner first (beta.json), when it is newer - else None."""
    try:
        import master
        if not master.is_master():
            return None
        u = BETA_URL + ("?t=" + str(int(time.time())) if fresh else "")
        b = json.loads(FETCH(u, 256 * 1024, 20).decode("utf-8", "replace"))
        if vnum(str(b.get("version") or ""))[0] and str(b.get("url") or "").startswith("https://") and re.fullmatch(r"[0-9a-f]{64}", str(b.get("sha256") or "")):
            return b
    except Exception:
        pass
    return None


def _verify(zbytes, rel):
    """-> (version, {name: bytes}) or raises with a plain reason. Nothing is written here."""
    if _sha(zbytes) != rel["sha256"]:
        raise ValueError("the download does not match the release's fingerprint (incomplete or changed) - nothing was installed")
    z = zipfile.ZipFile(io.BytesIO(zbytes))
    names = [i.filename for i in z.infolist() if not i.is_dir()]
    mf = [n for n in names if n.endswith("/MANIFEST.json") and n.count("/") == 1]
    if len(mf) != 1:
        raise ValueError("the update has no list of its files - nothing was installed")
    top = mf[0].split("/")[0]
    man = json.loads(z.read(mf[0]).decode("utf-8"))
    files = man.get("files") or {}
    if str(man.get("version")) != str(rel["version"]) or not files:
        raise ValueError("the update's list does not belong to this release - nothing was installed")
    bad = [n for n in files if not is_program_file(n)]
    if bad:
        raise ValueError(f"the update names a file that is not a program file ({bad[0][:60]}) - REFUSED, nothing was installed")
    extra = [n for n in names if n != mf[0] and (not n.startswith(top + "/") or n[len(top) + 1:] not in files)]
    if extra:
        raise ValueError(f"the update holds a file it does not list ({extra[0][:60]}) - REFUSED, nothing was installed")
    out = {}
    for n, h in files.items():
        try:
            b = z.read(top + "/" + n)
        except KeyError:
            raise ValueError(f"the update lists {n[:60]} but does not hold it - nothing was installed")
        if _sha(b) != h:
            raise ValueError(f"{n[:60]} does not match its fingerprint - nothing was installed")
        out[n] = b
    for must in ("app.py",):
        if must not in out:
            raise ValueError("the update has no app.py - nothing was installed")
    return str(rel["version"]), out


def install(restart=True):
    """Download, check, copy your data aside, put the new program files in place (all or none), restart. -> {"ok", "text"}"""
    with _lock:
        if state["installing"]:
            return {"ok": False, "text": "an update is being installed already"}
        rel = state.get("latest")
        if not rel or not state.get("available"):
            return {"ok": False, "text": "no newer version is known - press Check first"}
        state["installing"] = True
    try:
        why = BUSY() if BUSY else ""
        if why:
            return {"ok": False, "text": f"not now: {why}. Press Install again in a minute."}
        zb = FETCH(rel["url"], MAX_ZIP, 120)
        ver, files = _verify(zb, rel)
        stamp = time.strftime("%Y%m%d-%H%M%S")
        work = os.path.join(HERE, WORK)
        dback = os.path.join(work, f"data_backup_{stamp}")
        pback = os.path.join(work, f"program_{VERSION}_{stamp}")
        os.makedirs(dback, exist_ok=True)
        for n in data_files():
            try:
                shutil.copy2(os.path.join(HERE, n), os.path.join(dback, n))
            except Exception:
                pass
        if os.path.isdir(os.path.join(HERE, "icons")):
            try:
                shutil.copytree(os.path.join(HERE, "icons"), os.path.join(dback, "icons"))
            except Exception:
                pass
        stage = os.path.join(work, f"new_{ver}_{stamp}")
        for n, b in files.items():
            p = os.path.join(stage, *n.split("/"))
            os.makedirs(os.path.dirname(p), exist_ok=True)
            with open(p, "wb") as f:
                f.write(b)
        done, added = [], []
        try:
            for n in files:
                dst = os.path.join(HERE, *n.split("/"))
                if not os.path.exists(dst):
                    added.append(n)
                else:
                    bp = os.path.join(pback, *n.split("/"))
                    os.makedirs(os.path.dirname(bp), exist_ok=True)
                    shutil.copy2(dst, bp)
                os.makedirs(os.path.dirname(dst), exist_ok=True)
                os.replace(os.path.join(stage, *n.split("/")), dst)
                done.append(n)
        except Exception as e:
            _restore(pback, done)
            return {"ok": False, "text": f"the update could not be put in place ({str(e)[:80]}) - the version before is back, nothing changed"}
        rec = {"from": VERSION, "to": ver, "at": time.time(), "backup": os.path.relpath(pback, HERE), "data_backup": os.path.relpath(dback, HERE),
               "files": len(done), "added": added}
        with open(os.path.join(work, "last_update.json"), "w", encoding="utf-8") as f:
            json.dump(rec, f)
        shutil.rmtree(stage, ignore_errors=True)
        _prune(work)
        LOG(f"[update] {VERSION} -> {ver}: {len(done)} program files replaced; your data was not touched (a copy of it: {rec['data_backup']}).")
        with _lock:
            state["result"] = rec
        if restart:
            threading.Timer(1.5, _restart).start()
        return {"ok": True, "text": f"{ver} is installed ({len(done)} program files). Restalker restarts now - this page reloads by itself.", "to": ver}
    except Exception as e:
        LOG(f"[update] not installed: {str(e)[:160]}")
        return {"ok": False, "text": str(e)[:200]}
    finally:
        with _lock:
            state["installing"] = False


def _restore(pback, names):
    for n in names:
        bp = os.path.join(pback, *n.split("/"))
        dst = os.path.join(HERE, *n.split("/"))
        try:
            if os.path.exists(bp):
                shutil.copy2(bp, dst)
            else:
                os.remove(dst)                 # (a file this update added: gone again)
        except Exception:
            pass


def last():
    try:
        with open(os.path.join(HERE, WORK, "last_update.json"), encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return None


def go_back(restart=True):
    """The program files as they were before the last update (your data is not touched)."""
    rec = last()
    if not rec:
        return {"ok": False, "text": "there is no update to go back from"}
    pback = os.path.join(HERE, rec["backup"])
    if not os.path.isdir(pback):
        return {"ok": False, "text": "the copy of the version before is gone"}
    n = 0
    for a in rec.get("added") or []:            # (a program file the update added - nothing of yours)
        if is_program_file(a):
            try:
                os.remove(os.path.join(HERE, *a.split("/")))
            except Exception:
                pass
    for root, _, fs in os.walk(pback):
        for f in fs:
            rel = os.path.relpath(os.path.join(root, f), pback).replace("\\", "/")
            if is_program_file(rel):
                shutil.copy2(os.path.join(root, f), os.path.join(HERE, *rel.split("/")))
                n += 1
    try:
        os.remove(os.path.join(HERE, WORK, "last_update.json"))
    except Exception:
        pass
    LOG(f"[update] back to {rec['from']}: {n} program files restored.")
    if restart:
        threading.Timer(1.5, _restart).start()
    return {"ok": True, "text": f"Back to {rec['from']}. Restalker restarts now."}


def _prune(work, keep=3):
    """Only the newest 3 copies of each kind are kept."""
    try:
        for pre in ("data_backup_", "program_"):
            ds = sorted(d for d in os.listdir(work) if d.startswith(pre))
            for d in ds[:-keep]:
                shutil.rmtree(os.path.join(work, d), ignore_errors=True)
    except Exception:
        pass


# v115 (owner 2026-11-10: "The new window launched, but it did not close the previous CMD windows ... approximately 8 left open"):
# Windows' "start" opens a .bat in a window that STAYS open after the .bat ends (cmd /K). Two such windows were left by every update:
# this starter's own, and the first half of start_app.bat (it only re-opens itself minimized, then ends). Now start_app.bat is opened
# through "cmd /c" (its window closes when it ends) and this starter ends with "exit" (its window closes too). Windows left by earlier
# updates are closed when the program starts (lifeline.close_leftover_windows).
# v118b (owner 2026-11-14: "the latest update gave me a windows notification stating that the program did not shut down properly. I also
# had v117 and v118 cmd windows opened at the same time"): the starter waited a fixed 8 seconds; when the old copy took longer to close
# (every browser, then itself), the new copy's start_app.bat "closed the older copy" by force - so the old one ended with an error: its
# window said "stopped because of a problem" and stayed open. Now the starter waits until the old copy (its process number, @PID@) has
# really ended - at most 90 seconds - and only then starts the new one.
RESTART_BAT = """@echo off
rem Restalker update: starts the new version once the old one has closed (written by the update; safe to delete).
title Restalker - starting the new version
set N=0
:wait
tasklist /FI "PID eq @PID@" /NH 2>nul | find " @PID@ " >nul
if errorlevel 1 goto gone
set /a N=N+1
if %N% geq 90 goto gone
ping 127.0.0.1 -n 2 >nul
goto wait
:gone
ping 127.0.0.1 -n 3 >nul
cd /d "%~dp0.."
if exist "start_app.bat" (
  start "" /min cmd /c start_app.bat
) else (
  start "" /min py app.py
)
exit
"""
SHUTDOWN = None          # v104: set by app.py - closes the program the normal way (every browser, then itself, exit 0)


FLAG = "restarted_for_update.txt"
FLAG_FRESH = 300.0


def _flag_write():
    try:
        os.makedirs(os.path.join(HERE, WORK), exist_ok=True)
        with open(os.path.join(HERE, WORK, FLAG), "w") as f:
            f.write(str(time.time()))
    except Exception:
        pass


def restarted_for_update(now=None):
    """v106: -> True once, when this start is the restart after an update (the page that was open reconnects by itself: no second tab)."""
    p = os.path.join(HERE, WORK, FLAG)
    try:
        t = float(open(p).read().strip() or 0)
    except Exception:
        return False
    try:
        os.remove(p)
    except Exception:
        pass
    return 0 <= (now or time.time()) - t <= FLAG_FRESH


def _restart():
    """v104 (owner 2026-11-06: "the program started to install, but froze up. the program stopped completely"): v102/v103 started
    start_app.bat INSIDE the program's own Windows job - start_app.bat then closed the old copy, and Windows ended everything in that job
    with it: the new copy too. Now: a small starter (_update/restart.bat) is started OUTSIDE the job and the program's process tree; it
    waits 8 seconds and opens start_app.bat. Meanwhile the program closes itself the normal way (every browser, then itself, exit 0)."""
    if os.environ.get("RK_TEST_NOEXIT"):
        return
    _flag_write()
    try:
        if os.name == "nt":
            import lifeline
            work = os.path.join(HERE, WORK)
            os.makedirs(work, exist_ok=True)
            rb = os.path.join(work, "restart.bat")
            with open(rb, "w", encoding="ascii", newline="\r\n") as f:
                f.write(RESTART_BAT.replace("@PID@", str(os.getpid())))
            lifeline.release_reaper()
            if not lifeline.start_outside(rb, HERE):
                LOG("[update] could not start the new version by itself - close the black window and open start_app.bat")
                return
            LOG("[update] the new version starts in a few seconds - this copy closes now.")
        else:
            subprocess.Popen(["sh", "-c", 'sleep 4; exec "$0" "$@"', sys.executable] + sys.argv, cwd=HERE, start_new_session=True,
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, stdin=subprocess.DEVNULL)
        if SHUTDOWN:
            SHUTDOWN()
        else:
            os._exit(0)
    except Exception as e:
        LOG(f"[update] could not restart by itself ({e}) - close the black window and open start_app.bat")


# v115 (owner 2026-11-10: "i want an option to automatically update. There should be a toggle switch for the user to choose if they want
# automatic or manual updates. The program should check once every hour ... updates should wait until after any active purchases are
# complete"): AUTO_FILE holds your choice (yours: never replaced by an update, copied aside with your data). Automatic: a newer version
# found by the hourly check is installed by itself - only once nothing has been bought, checked or confirmed for QUIET seconds in a row
# (BUSY says why it waits). Manual (the default): as before - the button turns green and you press Install.
AUTO_FILE = "auto_update.txt"
QUIET = 120.0                               # seconds without any purchase activity before an automatic install
BUSY_POLL = 20.0


def auto_on():
    try:
        return open(os.path.join(HERE, AUTO_FILE), encoding="utf-8").read().strip().lower() == "on"
    except Exception:
        return False


def set_auto(on):
    with open(os.path.join(HERE, AUTO_FILE), "w", encoding="utf-8") as f:
        f.write("on" if on else "off")
    LOG(f"[update] automatic updates {'ON - a new version installs by itself once no purchase is running' if on else 'OFF - you press Install'}")
    return auto_on()


def auto_step(now=None, sleep=time.sleep, stop=None):
    """One automatic install, when allowed: switched on, a newer version known, and no purchase activity for QUIET seconds.
    -> "installed" | "waiting: <why>" | "" (nothing to do)."""
    if not auto_on() or not state.get("available") or state.get("installing"):
        return ""
    if not _auto_lock.acquire(blocking=False):
        return "waiting: already waiting"          # (the hourly check and your switch: one waits, never two)
    try:
        return _auto_wait(sleep, stop)
    finally:
        _auto_lock.release()


_auto_lock = threading.Lock()


def _auto_wait(sleep, stop):
    quiet_since = None
    while not (stop and stop.is_set()):
        if not auto_on():
            return ""
        why = BUSY() if BUSY else ""
        t = time.time()
        if why:
            if quiet_since is not None or not state.get("waiting"):
                LOG(f"[update] {(state.get('latest') or {}).get('version')} is ready - installs by itself after this: {why}")
            state["waiting"] = why
            quiet_since = None
        elif quiet_since is None:
            quiet_since = t
        elif t - quiet_since >= QUIET:
            state["waiting"] = ""
            LOG(f"[update] installing {(state.get('latest') or {}).get('version')} by itself (automatic updates are on; nothing is being bought)")
            r = install(restart=True)
            if not r.get("ok"):
                LOG(f"[update] the automatic install did not happen: {r.get('text')}")
                return "waiting: " + str(r.get("text"))
            return "installed"
        sleep(BUSY_POLL)
    return ""


# ---- v118 (owner 2026-11-13: "know if github can send a ping out to the program to notify it when an update is live, as this could
# reduce our need for checking ... The program should be as self-sufficient as possible"). GitHub cannot reach a home PC by itself, but
# when a release is published there, a small job on GitHub (.github/workflows/release-ping.yml in the release home) posts the version on
# Restalker's own ntfy release channel. Every Restalker keeps ONE quiet connection to that channel (like the phone-button listener) and
# hears it within seconds; it then checks latest.json itself, as always (the download is still checked against its fingerprint - a
# message there can only make it look sooner, never install anything). Automatic updates on: installed once no purchase is running.
# No phone message, nothing to tap. (v118b: with automatic updates on, this channel is the only way - no hourly check; off: hourly only.)
RELEASE_TOPIC = "restalker-releases-93590d22731021d1"
NTFY = os.environ.get("RK_NTFY_SERVER") or "https://ntfy.sh"
push = {"connected": False, "connects": 0, "heard": 0, "last": "", "error": ""}


def on_release(text, settle=30.0, tries=20, sleep=time.sleep):
    """The release channel said a version is out. Newer than this one -> checked now (and again every 30 s for up to 10 minutes, until
    the release home shows it - its copies on the way can lag a few minutes); automatic updates on -> installed when nothing is bought."""
    v = str(text or "").strip()
    if not vnum(v)[0] or vnum(v) <= vnum(VERSION):
        return "old"
    push["heard"] += 1
    push["last"] = time.strftime("%H:%M:%S") + " " + v
    LOG(f"[update] GitHub says {v} is out - checking now (no need to wait for the hourly check)")
    for i in range(tries):
        st = check(fresh=True)
        if st.get("available") and vnum((st.get("latest") or {}).get("version") or "") >= vnum(v):
            if auto_on():
                auto_step()
            return "found"
        sleep(settle)
    return "not yet"


MISSED_WINDOW = 3600                        # v130: a ping sent while this PC was restarting / offline is still heard (the last hour)
SAFETY_EVERY = 6 * 3600                     # v130: with automatic updates on, one fresh look every 6 h too, in case a ping never came


def release_listen(stop=None, opener=None):
    """One quiet connection to the release channel, opened again by itself when it drops (5 s, then up to 5 minutes apart).
    v130: the first connection also asks for the last hour's pings - on 2026-11-17 the v128 ping came while this PC restarted for
    v127 and was missed (an older or equal version in it is ignored, so hearing one twice does nothing)."""
    opener = opener or urllib.request.urlopen
    since, wait = str(int(time.time()) - MISSED_WINDOW), 5
    while not (stop and stop.is_set()):
        try:
            req = urllib.request.Request(f"{NTFY}/{RELEASE_TOPIC}/json?since={since}", headers={"User-Agent": "Restalker-updater/" + VERSION})
            with opener(req, timeout=120) as r:
                push.update(connected=True, connects=push["connects"] + 1, error="")
                wait = 5
                for line in r:
                    if stop and stop.is_set():
                        break
                    try:
                        m = json.loads(line.decode("utf-8", "replace") if isinstance(line, bytes) else line)
                    except Exception:
                        continue
                    if m.get("id"):
                        since = str(m["id"])
                    if m.get("event") == "message":
                        threading.Thread(target=on_release, args=(m.get("message"),), daemon=True, name="update-ping").start()
        except Exception as e:
            push["error"] = str(e)[:100]
        push["connected"] = False
        if stop and stop.is_set():
            break
        time.sleep(wait)
        wait = min(300, wait * 2)


def loop(stop=None, tick=30.0, first_wait=60.0, sleep=time.sleep):
    """v118b (owner 2026-11-14: "If automatic is checked, then let the program sync using the method with ntfy updates. If its not checked,
    then the simple once per hour method and changing the button on the UI to notify the user its ready is fine"):
    automatic ON  -> only the release channel (and one check when it is switched on / at start: a version published while the PC was
                     off is not on the channel any more); no hourly checks.
    automatic OFF -> the hourly check only (the button turns green); the channel is closed."""
    sleep(first_wait)
    lstop, last_hourly, last_safety = None, 0.0, 0.0
    while not (stop and stop.is_set()):
        try:
            if source() and auto_on():
                if lstop is None:
                    lstop = threading.Event()
                    threading.Thread(target=release_listen, args=(lstop,), daemon=True, name="update-listen").start()
                    check(fresh=True)          # v130: past any copy kept on the way (a stale copy hid v128 right after a restart)
                    last_safety = time.time()
                    threading.Thread(target=auto_step, kwargs={"stop": stop}, daemon=True, name="update-auto").start()
                elif time.time() - last_safety >= SAFETY_EVERY:
                    # v130: the ping for v129 never reached the channel (ntfy refused GitHub: "429 too many") - so a slow safety look
                    last_safety = time.time()
                    st = check(fresh=True)
                    if st.get("available"):
                        LOG(f"[update] the 6-hour safety look found {(st.get('latest') or {}).get('version')} (its ping was missed)")
                        threading.Thread(target=auto_step, kwargs={"stop": stop}, daemon=True, name="update-auto").start()
            else:
                if lstop is not None:
                    lstop.set()
                    lstop = None
                if source() and time.time() - last_hourly >= CHECK_EVERY:
                    last_hourly = time.time()
                    check()
        except Exception as e:
            LOG(f"[update] {str(e)[:100]}")
        sleep(tick)
    if lstop is not None:
        lstop.set()


def start():
    threading.Thread(target=loop, daemon=True, name="updater").start()


PUBLIC_FILE = "update_public.txt"


def _public_seen(v):
    if state.get("public") != v:
        state["public"] = v
        try:
            open(PUBLIC_FILE, "w", encoding="utf-8").write(v)
        except Exception:
            pass


def shown_version():
    """v142 (owner, 2026-11-19: "For beta versions, let's use a "b" at the end of the version number ... when we actually release a full
    version, we aren't confusing versions"): "v142b" while this copy is newer than the version everyone has (latest.json) - the owner's
    PC gets every version first; the same copy shows "v142" once it is released to everyone. Nothing is renumbered."""
    pub = state.get("public")
    if pub is None:
        try:
            pub = open(PUBLIC_FILE, encoding="utf-8").read().strip() or None
        except Exception:
            pub = None
        state["public"] = pub
    return VERSION + ("b" if pub and vnum(pub)[0] and vnum(VERSION) > vnum(pub) else "")


def brief():
    s = dict(state)
    s["shown"] = shown_version()
    s["connected"] = bool(source())
    s["version"] = VERSION
    s["latest_version"] = (s.get("latest") or {}).get("version")
    s.pop("latest", None)
    s["last"] = last()
    s["auto"] = auto_on()
    s["waiting"] = state.get("waiting") or ""
    s["push"] = dict(push)
    return s


# ---------------------------------------------------------------- building a release (by the same rules)
def build_release(src_dir, version, zip_url, notes=""):
    """-> (zip bytes, latest.json text). Takes ONLY program files from src_dir; refuses if a program file carries anything personal."""
    files = {}
    for n in sorted(os.listdir(src_dir)):
        if os.path.isfile(os.path.join(src_dir, n)) and is_program_file(n):
            files[n] = open(os.path.join(src_dir, n), "rb").read()
    for d in PROGRAM_DIRS:
        dd = os.path.join(src_dir, d)
        if os.path.isdir(dd):
            for n in sorted(os.listdir(dd)):
                if os.path.isfile(os.path.join(dd, n)) and is_program_file(d + "/" + n):
                    files[d + "/" + n] = open(os.path.join(dd, n), "rb").read()
    if "app.py" not in files:
        raise ValueError("no app.py")
    top = f"restalker_{version}"
    man = {"version": version, "files": {n: _sha(b) for n, b in files.items()}}
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        for n, b in files.items():
            z.writestr(f"{top}/{n}", b)
        z.writestr(f"{top}/MANIFEST.json", json.dumps(man, indent=1))
    zb = buf.getvalue()
    latest = {"version": version, "url": zip_url, "sha256": _sha(zb), "size": len(zb), "notes": notes, "files": len(files)}
    return zb, json.dumps(latest, indent=1)
