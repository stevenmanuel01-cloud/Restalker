"""
Shared HTTP fetching used by both watchers. Uses a fuller, more
browser-like header set (some sites reject bare/minimal requests
outright) and a short retry, and centralizes timeout/error handling so
both watchers behave consistently and don't spam identical warnings
every single poll.

Note on limits: some retailers (Amazon and Best Buy in particular) run
aggressive bot-detection that this — or any simple, free, no-account
tool — is not designed to get past. A "Read timed out" repeated on
every attempt for one specific site is usually that site's defense
working as intended, not a bug here. Test any new product/retailer
with check_target.py first (see README) before adding it to a real
study, so you find out in 5 seconds rather than after minutes of
confusing timeout spam in a running watcher.
"""
VERSION = "v107"   # checked by app.py so a half-copied update is caught immediately

import threading
import time
from urllib.parse import urljoin

import requests

HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
        "(KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36"
    ),
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
    "Accept-Language": "en-US,en;q=0.9",
    "Connection": "keep-alive",
    "Upgrade-Insecure-Requests": "1",
}


_local = threading.local()


def _session():
    """One cookie-keeping session per polling thread. Keeping cookies
    between checks is what lets us pass Amazon's 'Continue shopping'
    page once and then stay on the real product page."""
    sess = getattr(_local, "sess", None)
    if sess is None:
        sess = requests.Session()
        sess.headers.update(HEADERS)
        _local.sess = sess
    return sess


def looks_like_continue_page(text: str) -> bool:
    """Amazon's soft 'click to continue shopping' interstitial."""
    if not text or len(text) > 20000:
        return False
    low = text.lower()
    return "continue shopping" in low and "click the button below" in low


def _click_through(sess, url, text, timeout):
    """Submit the interstitial's own form (exactly what clicking the
    button does), so the session gets the cookie that lets it through."""
    try:
        from bs4 import BeautifulSoup
        soup = BeautifulSoup(text, "html.parser")
        form = soup.find("form")
        if form is None:
            return False
        action = urljoin(url, form.get("action") or url)
        data = {i.get("name"): i.get("value", "") for i in form.find_all("input") if i.get("name")}
        if (form.get("method") or "get").lower() == "post":
            sess.post(action, data=data, timeout=timeout)
        else:
            sess.get(action, params=data, timeout=timeout)
        return True
    except Exception:
        return False


def fetch(url: str, timeout: float = 15.0, retries: int = 1):
    """Returns (text, None) on success, or (None, error_message) on failure."""
    last_err = None
    for attempt in range(retries + 1):
        try:
            sess = _session()
            r = sess.get(url, timeout=timeout)
            text = r.text
            if looks_like_continue_page(text):
                if _click_through(sess, url, text, timeout):
                    text = sess.get(url, timeout=timeout).text
            return text, None
        except requests.RequestException as e:
            last_err = str(e)
            if attempt < retries:
                time.sleep(1)
    return None, last_err


def burst_test(url: str, attempts: int = 6, gap: float = 1.0, timeout: float = 10.0, fetch_fn=None):
    """Fire several requests at roughly the polling cadence we actually
    intend to use, back to back — the real question for a target that
    needs sub-second timing accuracy is not 'does it load once' but
    'does it tolerate being checked repeatedly, right now.' A site that
    blocks or throttles frequent requests will fail some of these even
    when a single one-off request succeeds fine.

    fetch_fn(url) -> (text, error) lets the caller swap in a different
    fetch method (e.g. browser_fetch.BrowserFetcher.fetch) to test
    whether THAT approach survives repeated polling even when plain
    HTTP doesn't. Defaults to the plain HTTP fetch() above.

    Returns (successes, attempts, last_good_text, last_error). Takes
    roughly `attempts * gap` seconds to run — a few seconds, once, at
    add time, not a big cost against catching an unusable target after
    it's already "trusted" and running unattended for hours."""
    if fetch_fn is None:
        fetch_fn = lambda u: fetch(u, timeout=timeout, retries=0)
    successes = 0
    last_good_text = None
    last_error = None
    for i in range(attempts):
        text, err = fetch_fn(url)
        if err:
            last_error = err
        else:
            successes += 1
            last_good_text = text
        if i < attempts - 1:
            time.sleep(gap)
    return successes, attempts, last_good_text, last_error


def lower_priority():
    """Run the whole program (and the browsers it starts, which inherit this) at
    below-normal priority, so the PC stays responsive for everything else."""
    import os
    try:
        if os.name == "nt":
            import ctypes
            k = ctypes.windll.kernel32
            k.SetPriorityClass(k.GetCurrentProcess(), 0x00004000)   # BELOW_NORMAL_PRIORITY_CLASS
        else:
            os.nice(5)
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Safe CSV writing. On Windows a file that is open in Excel cannot be added to, and a text with an
# unusual character used to crash the default (cp1252) writer. Here every row is written as UTF-8,
# and if the file cannot be written for ANY reason the row is kept in "<file>.pending" and added the
# next time the file is free - a restock row is never lost and the checker never stops.
import csv as _csv
import io as _io
import os as _os

_CSV_IO_LOCK = threading.Lock()


def append_csv_row(path, row):
    """Returns True if the row went into the file itself, False if it was kept aside (pending)."""
    buf = _io.StringIO()
    _csv.writer(buf).writerow(row)
    text = buf.getvalue()
    pend = path + ".pending"
    with _CSV_IO_LOCK:
        try:
            old = ""
            if _os.path.exists(pend):
                with open(pend, encoding="utf-8", errors="replace", newline="") as pf:
                    old = pf.read()
            with open(path, "a", encoding="utf-8", newline="") as f:
                f.write(old + text)
            if old:
                try:
                    _os.remove(pend)
                except OSError:
                    pass
            return True
        except Exception:
            try:
                with open(pend, "a", encoding="utf-8", newline="") as pf:
                    pf.write(text)
            except Exception:
                pass
            return False


def flush_pending_csv(path):
    """Adds rows kept aside earlier (call at start-up). Returns how many rows are still waiting."""
    pend = path + ".pending"
    with _CSV_IO_LOCK:
        try:
            if not _os.path.exists(pend):
                return 0
            with open(pend, encoding="utf-8", errors="replace", newline="") as pf:
                old = pf.read()
            with open(path, "a", encoding="utf-8", newline="") as f:
                f.write(old)
            _os.remove(pend)
            return 0
        except Exception:
            try:
                return len(open(pend, encoding="utf-8", errors="replace").read().splitlines())
            except Exception:
                return 0
