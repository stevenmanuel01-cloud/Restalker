/* Restalker Best Buy checkout - the deciding part (v56). Runs in the buying engine's background, next to the (unchanged) Amazon
 * checkout. Restalker sends a restock signal for an ARMED Best Buy product; this walks the real pages in one Best Buy tab:
 *   product page (exact product, in stock, price <= cap; Best Buy's queue is waited out like a person would)
 *   -> cart (ONLY that product, quantity 1, price <= cap, shipping chosen)
 *   -> checkout (same product, qty 1, item <= cap, tax <= 10 % of cap, shipping over $20 asks you, card security code asked from you if Best Buy wants it)
 *   -> Place Your Order (latched first: never pressed twice)
 *   -> confirmation (order number) - not seen within 90 s = "unconfirmed", then Restalker looks in your Best Buy orders.
 * One purchase per arming. A failure BEFORE Place Order leaves the product armed (it tries again at the next restock); 3 failures
 * in 10 minutes disarm it. A sign-in / identity / human check is never answered by the program: it stops and tells you.
 * Practice run (dryRun): the same steps on the real site, stops before Place Order and takes the item out of the cart again.
 */
'use strict';
(() => {
  const K = key => 'bb:' + key;
  const G = 'bbg';
  const CART = 'https://www.bestbuy.com/cart';
  const ORDERS = 'https://www.bestbuy.com/profile/ss/orders';
  const CONFIRM_WAIT_MS = 90000, APPROVAL_WAIT_MS = 600000, QUEUE_WAIT_MS = 1800000;
  const SHIP_MAX = 20, TAX_SHARE = 0.12, FEES_MAX = 3;      // v78: tax <= 12 % of item + shipping (diagnostics 65: GameStop taxes the shipping too - $2.11 on $16.99 + $7.99 was stopped)
  const FAIL_WINDOW_MS = 600000, FAIL_MAX = 10;      // v70b: the same as Restalker's lock (5 in a row) - never gives up earlier
  let diag = () => {};
  const secrets = {};                 // security codes typed in Restalker for ONE checkout: memory only, never stored, never logged
  const waiters = {};                 // key -> resolve() for "you answered" (security code / shipping approval)
  let running = null;                 // key of the checkout that owns the Best Buy tab
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  async function st(key) { return (await chrome.storage.local.get(K(key)))[K(key)] || null; }
  async function setp(key, patch) { const s = (await st(key)) || {key}; const n = {...s, ...patch, key}; await chrome.storage.local.set({[K(key)]: n}); return n; }
  async function g() { return (await chrome.storage.local.get(G))[G] || {}; }
  async function setg(patch) { const x = await g(); await chrome.storage.local.set({[G]: {...x, ...patch}}); }
  async function all() {                // (v75: from memory - never the whole storage)
    if (globalThis.RestalkerRecs) return globalThis.RestalkerRecs.byPrefix('bb:');
    const a = await chrome.storage.local.get(null);
    return Object.entries(a).filter(([k]) => k.startsWith('bb:')).map(([, v]) => v);
  }
  // ---- the one Best Buy tab
  async function tab() {
    const x = await g();
    let id = null;
    if (Number.isInteger(x.tab)) { try { const t = await chrome.tabs.get(x.tab); if (t && t.id) id = t.id; } catch {} }
    if (id === null) { const t = await chrome.tabs.create({url: 'about:blank', active: false}); id = t.id; await setg({tab: id}); }
    await onScreen(id);
    return id;
  }
  // v68 (found at Walmart, diagnostics 62 + the real walmart.com): a background tab is not drawn, and modern store pages may not answer
  // their buttons until they are drawn. The checkout tab is the ACTIVE tab of a window that is not minimised (still parked off-screen,
  // never focused - it never comes in front of your windows).
  async function onScreen(id) {
    try {                              // v75: in this store's OWN window - another store's checkout at the same moment never hides it
      if (globalThis.RestalkerWindows && globalThis.RestalkerWindows.checkoutWindow) { await globalThis.RestalkerWindows.checkoutWindow('bestbuy', id); return; }
    } catch {}
    try {
      const t = await chrome.tabs.get(id);
      const w = await chrome.windows.get(t.windowId);
      if (w.state === 'minimized' || w.id === globalThis.__rkSigninWin) {
        const all = await chrome.windows.getAll({windowTypes: ['normal']});
        let to = all.find(v => v.id !== globalThis.__rkSigninWin && v.state !== 'minimized' && ((v.left || 0) < -5000 || (v.top || 0) < -5000));
        if (!to) {
          try { to = await chrome.windows.create({focused: false, state: 'normal', left: -32000, top: -32000, width: 1280, height: 900}); }
          catch { to = await chrome.windows.create({focused: false, state: 'normal'}); }
        }
        await chrome.tabs.move(id, {windowId: to.id, index: -1});
      }
      await chrome.tabs.update(id, {active: true});
    } catch {}
  }
  // A page counts as "arrived" only after it really STARTED loading after we asked (status 'loading'), then finished, and its address
  // fits. (v56 test finding: the page we were leaving is already 'complete' and was taken for the new one.)
  function waitLoad(id, pred, ms = 30000, kick = null) {
    return new Promise(res => {
      let done = false, started = false;
      const fin = v => { if (done) return; done = true; clearTimeout(to); chrome.tabs.onUpdated.removeListener(fn); res(v); };
      const fn = (i, ch, t) => {
        if (i !== id) return;
        if (ch.status === 'loading' || ch.url) started = true;
        if (started && t.status === 'complete' && (!pred || pred(t.url || ''))) fin(t.url);
      };
      const to = setTimeout(() => fin(null), ms);
      chrome.tabs.onUpdated.addListener(fn);
      if (kick) Promise.resolve().then(kick).catch(() => fin(null));
    });
  }
  // v75: the cart page is read from the PATH (a checkout address may carry "cart" in its query)
  const onCart = u => { try { return /\/cart/i.test(new URL(u).pathname); } catch { return false; } };
  const blockedUrl = u => { try { return /^\/(blocked|captcha|challenge)/i.test(new URL(u).pathname); } catch { return false; } };
  const TW_SKIP = new Set(['the', 'and', 'for', 'with', 'new', 'pack', 'black', 'white', 'size', 'count']);
  const titleWords = t => [...new Set(String(t || '').toLowerCase().replace(/[™®©]/g, '').match(/[a-z0-9]{3,}/g) || [])].filter(w => !TW_SKIP.has(w)).slice(0, 4);
  // v75: like waitLoad, but gives up after startMs when the page does not even START to move (a Buy now that does nothing costs
  // 3 s, not 8) - once it moves, it waits up to ms for a page that fits
  // v75 (your rule: checkout is the top priority): the product page is used as soon as it is THERE - not after every picture and
  // advert on it finished loading (a few seconds on bestbuy.com). The page part answers once the page's content is in.
  // v75: the store's cart is used by one browser at a time (see RestalkerShops.cartLock); this browser waits ready until it is free
  async function takeCart(key, step) {
    const RS = globalThis.RestalkerShops;
    if (!RS || !RS.cartLock) return;
    let told = false;
    const t0 = Date.now();
    for (;;) {
      const v = RS.verdictFor ? RS.verdictFor('bestbuy', key, t0 - 2000, 'this browser:' + key) : null;      // (v78)
      if (v) throw new Stop(v.kind === 'needyou' ? 'fees' : v.kind, 'another browser (' + v.owner.split(':')[0] + ') just found: ' + v.reason);
      const h = RS.cartLock('bestbuy', 'this browser:' + key);
      if (!h) { if (told) await step('the cart is free now - going on (' + ((Date.now() - t0) / 1000).toFixed(1) + ' s)'); return; }
      if (!told) { told = true; await step('ready - another browser (' + String(h).split(':')[0] + ') is using the ' + 'Best Buy' + ' cart; going on the moment it is free'); }
      if (Date.now() - t0 > 12 * 60 * 1000) throw new Stop('page', 'the cart stayed busy');
      await sleep(150);
      const me = await st(key), gx = await g();
      // (v75: while another browser is pressing Place order for this link - "submitting" - this one keeps waiting: if that order does not go
      //  through, this browser goes on at once; bought or maybe bought -> it stops)
      if (me && me.submissionPending && !me.purchased) continue;
      if (!me || !me.armed || me.purchased || me.attempted || gx.emergencyStop || gx.live === false) throw new Stop(me && (me.purchased || me.attempted) ? 'other' : 'cancelled', me && (me.purchased || me.attempted) ? 'it was ordered by another browser' : 'auto-buy was switched off during the checkout');
    }
  }
  async function goFast(id, url, ms = 20000) {
    let started = false;
    const fn = (i, ch) => { if (i === id && (ch.status === 'loading' || ch.url)) started = true; };
    chrome.tabs.onUpdated.addListener(fn);
    try {
      await chrome.tabs.update(id, {url});
      const end = Date.now() + ms;
      while (Date.now() < end) {
        await sleep(100);
        let t = null; try { t = await chrome.tabs.get(id); } catch { return null; }
        if (started && !t.pendingUrl && String(t.url || '').startsWith('https://www.bestbuy.com')) return t.url;
      }
      return null;
    } catch (e) { diag('bb_nav_error', {url: String(url).replace(/\?.*/, ''), error: String(e && e.message || e)}); return null; }
    finally { chrome.tabs.onUpdated.removeListener(fn); }
  }
  async function waitNav(id, pred, startMs, ms, kick, failed) {
    const u00 = await urlOf(id);
    const p = waitLoad(id, pred, ms, kick);
    const t0 = Date.now();
    let moving = false;
    const watch = (async () => {
      while (Date.now() - t0 < startMs) {
        await sleep(200);
        if (failed && failed()) return 'failed';            // (v75: the press itself said no - nothing to wait for)
        // (v75: only a NEW address counts as moving - a store page keeps "loading" small parts all the time; diagnostics 64 waited 15 s)
        try { const t = await chrome.tabs.get(id); if ((t.url || '') !== u00 || (t.pendingUrl && t.pendingUrl !== u00)) { moving = true; return 'moving'; } } catch { return 'gone'; }
      }
      return 'still';
    })();
    const first = await Promise.race([p.then(v => ({v})), watch.then(w => ({w}))]);
    if (first.v !== undefined) return first.v;
    if ((first.w === 'still' || first.w === 'failed') && !moving) return null;
    return await p;
  }
  async function go(id, url, pred, ms) {
    const want = pred || (u => u.startsWith('https://www.bestbuy.com'));
    // (v75: a store's 'prove you are a person' page counts as arrived - it is then reported to you, never waited on for 30 s)
    return waitLoad(id, u => want(u) || blockedUrl(u), ms, () => chrome.tabs.update(id, {url}));
  }
  const CONTENT_FILE = 'bb_content.js';
  async function inject(id) {
    // v62: the page part is put into the page by the engine itself when it is not there (instead of waiting for the browser to do it)
    try { await chrome.scripting.executeScript({target: {tabId: id}, files: [CONTENT_FILE]}); return null; }
    catch (e) { return String(e && e.message || e); }
  }
  // v68: requests that PRESS something are delivered at most once (never sent again to the next page after the store moved on)
  const ONCE = new Set(['add', 'place', 'tocheckout', 'cvv', 'qty1', 'remove', 'ship', 'searchadd', 'buynow']);
  async function ask(id, msg, ms = 20000) {
    const end = Date.now() + ms, t0 = Date.now();
    let last = null, injected = false, injErr = null;
    const once = ONCE.has(msg && msg.bb);
    if (once || (msg && msg.ship)) await onScreen(id);          // (v75: the product page is DRAWN before Shipping is chosen on it)
    while (Date.now() < end) {
      try {
        const r = await Promise.race([chrome.tabs.sendMessage(id, msg), sleep(Math.max(1000, end - Date.now())).then(() => ({ok: false, error: 'the page did not answer in time'}))]);
        if (r) return r;
      } catch (e) {
        last = String(e && e.message || e);
        if (once && !/receiving end does not exist|could not establish connection|no tab with id/i.test(last)) return {ok: false, error: last, lost: true};
      }
      if (!injected && Date.now() - t0 > 1500) {          // (no answer at all: the page part is missing - it is added now)
        injected = true;
        const why = await inject(id);
        if (why) injErr = 'the page part could not be added: ' + why + ' (page: ' + (await urlOf(id)).replace(/\?.*/, '').slice(0, 90) + ')';
      }
      await sleep(250);
    }
    return {ok: false, error: (injErr || last || 'the page did not answer')};
  }
  async function settle(id) { await waitLoad(id, null, 3000); await sleep(300); }
  async function urlOf(id) { try { return (await chrome.tabs.get(id)).url || ''; } catch { return ''; } }
  const isCheckout = u => /bestbuy\.com\/checkout\//i.test(u) && !/thank-?you|confirmation/i.test(u);
  const isSignin = u => /bestbuy\.com\/identity\//i.test(u);
  // ---- one checkout
  class Stop extends Error { constructor(kind, msg, extra) { super(msg); this.kind = kind; this.extra = extra || {}; } }
  async function campaign(key, {dryRun = false, reason = 'restock'} = {}) {
    if (running && running !== key) return {ok: false, busy: true, reason: 'another Best Buy checkout is running'};
    if (running === key) return {ok: true, already: true};
    running = key;                      // (v70c: taken AT ONCE - two restock signals in the same moment once ran two checkouts = two orders)
    let p;
    try {
      p = await st(key);
      if (!p) { running = null; return {ok: false, reason: 'unknown Best Buy product'}; }
      if (!dryRun) {
        const x = await g();
        if (!p.armed || p.purchased || p.attempted || p.inProgress || p.submissionPending || x.emergencyStop || x.live === false) { running = null; return {ok: false, reason: 'not armed'}; }
      }
    } catch (e) { running = null; throw e; }
    const steps = [];
    const t0 = Date.now();
    const step = async (name, extra) => { steps.push({name, ms: Date.now() - t0, ...(extra || {})}); diag('bb_step', {key, dryRun, step: name, ms: Date.now() - t0, ...(extra || {})});
      if (!dryRun) await setp(key, {step: name, status: 'CHECKOUT — ' + name}); };
    const want = {sku: p.sku || null, tokens: p.tokens || [], forbid: p.forbid || [], name: p.name};
    const forbidden = title => (p.forbid || []).find(w => String(title || '').toLowerCase().includes(String(w).toLowerCase()));
    let latched = false, id = null;
    try {
      if (!dryRun) await setp(key, {inProgress: true, hitAt: Date.now(), campaignStartedAt: Date.now(), approval: null, needCvv: false, step: 'opening the product page', status: 'CHECKOUT — STARTING'});
      id = await tab();
      // 1) product page
      let addedVia = 'product page', viaBuyNow = false, c = null;
      if (p.mode === 'search') {
        if (!dryRun) await takeCart(key, step);
        await step('search page');
        if (!await go(id, p.url)) throw new Stop('page', 'the search page did not load');
        const r = await ask(id, {bb: 'searchadd'}, 20000);
        if (!r.ok) throw new Stop('page', 'search page: ' + (r.error || 'no item could be added'));
        want.tokens = []; want.sku = null; want.title = r.title; want.href = r.href; addedVia = 'search results (' + r.title + ')';
        await step('added to cart', {title: r.title});
      } else {
        await step('opening the product page');
        if (!await goFast(id, p.url)) throw new Stop('page', 'the product page did not load');
        let info = await ask(id, {bb: 'pdp', want, ship: !dryRun}, 15000);
        if (!info.ok && /error page/i.test(String(info.error || ''))) {
          // v65 (diagnostics 61): the page came back as the browser's own error page (the store did not answer the page load) -
          // loaded once more, the way a person presses reload, before the checkout gives up
          await step('product page did not load - loading it again');
          await sleep(1500);
          if (!await go(id, p.url)) throw new Stop('page', 'the product page did not load');
          info = await ask(id, {bb: 'pdp', want, ship: !dryRun}, 15000);
        }
        if (info.check) throw new Stop('check', info.check);
        if (!info.ok) throw new Stop('page', 'product page: ' + (info.error || 'unreadable'));
        await step('product page read', {title: (info.title || '').slice(0, 80), sku: info.sku, price: info.price, button: info.button});
        if (p.sku && info.sku && String(info.sku) !== String(p.sku) && !(p.skuAlt || []).includes(String(info.sku))) {
          // Best Buy moved products to new 8-digit numbers: the PAGE's own number is learned the first time its title matches the product
          const toks = (p.tokens || []).map(x => x.toLowerCase());
          if (p.trusted || (toks.length && toks.every(k => k.split('|').some(x => (info.title || '').toLowerCase().includes(x))))) { await setp(key, {skuAlt: [...(p.skuAlt || []), String(info.sku)]}); want.sku = String(info.sku); }
          else throw new Stop('identity', `this page is product ${info.sku}, not ${p.sku}`);
        }
        if (!p.sku && info.sku) { await setp(key, {sku: String(info.sku)}); want.sku = String(info.sku); }
        if (info.sku) want.sku = String(info.sku);
        // v75 (your rule): a link YOU gave is the right product - its page is not checked against the row's name. The cart and the
        // checkout then recognise the item by the page's own item number and the words of the page's own product name.
        if (p.trusted && !(p.tokens || []).length && info.title) want.tokens = titleWords(info.title);
        const toks = (p.tokens || []).map(x => x.toLowerCase());
        if (toks.length && !toks.every(k => k.split('|').some(x => (info.title || '').toLowerCase().includes(x)))) throw new Stop('identity', 'the page title does not match the product: ' + (info.title || '?').slice(0, 80));
        if (forbidden(info.title)) throw new Stop('identity', 'the page is a different kind of product ("' + forbidden(info.title) + '"): ' + (info.title || '?').slice(0, 80));
        if (info.soldOut) throw new Stop('soldout', 'Best Buy shows "' + info.button + '"');
        if (!dryRun && info.price != null && info.price > p.cap + 0.001) throw new Stop('overcap', `price $${info.price.toFixed(2)} is over the cap $${p.cap.toFixed(2)}`);
        if (!info.inStock && !info.queue) throw new Stop('soldout', 'no Add to Cart button (' + (info.button || 'none') + ')');
        if (info.shipTile && info.shipTile.offered) await step(info.shipTile.chosen ? 'Shipping chosen (not store pickup)' : 'Shipping could NOT be chosen on the product page');
        if (!dryRun) await takeCart(key, step);
        let skipAdd = false;
        // v75 (your rule): "Buy now" goes straight to the checkout (no cart step, no second item in the cart) - used when it is there
        if (info.buyNow && !dryRun && !info.queue) {
          await step('pressing Buy now (straight to the checkout)');
          await onScreen(id);
          let bn = null;
          const u0 = await waitNav(id, u => isCheckout(u) || isSignin(u) || onCart(u), 3000, 15000, async () => { bn = await ask(id, {bb: 'buynow'}, 8000); }, () => !!(bn && !bn.ok));
          if (bn && bn.check) throw new Stop('check', bn.check);
          if (u0 && isSignin(u0)) throw new Stop('signin', 'Best Buy wants you to sign in again before checking out');
          if (u0 && isCheckout(u0)) { viaBuyNow = true; addedVia = 'Buy now'; }
          else if (u0 && onCart(u0)) { skipAdd = true; addedVia = 'Buy now (it opened the cart)'; await step('Buy now opened the cart'); }
          else await step('Buy now did not open the checkout - using Add to cart' + (bn && bn.error ? ' (' + bn.error + ')' : ''));
        }
        if (!viaBuyNow && !skipAdd) {
          await step(info.queue ? 'in Best Buy\'s queue (Please Wait)' : 'pressing Add to Cart');
          await onScreen(id);
          const a = await ask(id, {bb: 'add', maxQueueMs: QUEUE_WAIT_MS}, QUEUE_WAIT_MS + 30000);
          if (a.check) throw new Stop('check', a.check);
          if (a.soldOut) throw new Stop('soldout', 'sold out while adding to the cart');
          if (a.lost) await step('added to cart', {how: 'the page changed - the cart decides'});
          else if (!a.ok) throw new Stop('page', 'Add to Cart: ' + (a.error || 'no confirmation'));
          else await step('added to cart', {queued: !!a.queued});
        }
      }
      if (!viaBuyNow) {
      // 2) cart
      await step('cart');
      if (!await go(id, CART, u => onCart(u))) throw new Stop('page', 'the cart did not load');
      c = await ask(id, {bb: 'cart', want}, 15000);
      if (c.check) throw new Stop('check', c.check);
      if (p.mode === 'search' && !c.target && c.items) { const mine = c.items.filter(i => want.title && i.title && want.title.toLowerCase().startsWith(i.title.toLowerCase().slice(0, 30))); if (mine.length === 1) { want.tokens = [mine[0].title.toLowerCase().slice(0, 30)]; c = await ask(id, {bb: 'cart', want}, 8000); } }
      await step('cart read', {items: c.count, target: c.target, subtotal: c.subtotal});
      if (!c.target) throw new Stop('page', 'the product is not in the cart (' + (c.count || 0) + ' item(s) there)');
      if (forbidden(c.target.title)) throw new Stop('identity', 'the cart item is a different kind of product: ' + c.target.title);
      if (c.count !== 1) throw new Stop('cart', `the Best Buy cart has ${c.count} different items - only this product may be in it`);
      if (c.target.qty && c.target.qty !== 1) {
        const q = await ask(id, {bb: 'qty1', want}, 12000);
        if (!q.ok) throw new Stop('cart', 'the quantity in the cart is ' + c.target.qty + ', not 1');
        // v75 (diagnostics 64: the price of TWO was then taken for the price of one - "over the cap"): the cart is read again
        await settle(id);
        c = await ask(id, {bb: 'cart', want}, 10000);
        if (!c.target || (c.target.qty && c.target.qty !== 1)) throw new Stop('cart', 'the quantity in the cart is ' + (c.target ? c.target.qty : '?') + ', not 1');
        await step('quantity set to 1', {price: c.target.price});
      }
      if (!dryRun && c.target.price != null && c.target.price > p.cap + 0.001) throw new Stop('overcap', `the cart price $${c.target.price.toFixed(2)} is over the cap $${p.cap.toFixed(2)}`);
      const sh = await ask(id, {bb: 'ship', want, allowPickup: !!(await g()).allowPickup}, 10000);
      if (!sh.ok) throw new Stop('cart', sh.error || 'could not choose shipping');
      await step('delivery chosen', {how: sh.how});
      // 3) checkout
      let tcErr = null;
      const u1 = await waitLoad(id, u => isCheckout(u) || isSignin(u), 30000, async () => { const tc = await ask(id, {bb: 'tocheckout'}, 12000); if (!tc.ok) tcErr = tc.error || 'no Checkout button'; });
      if (tcErr) throw new Stop('page', tcErr);
      if (!u1) throw new Stop('page', 'the checkout page did not open');
      if (isSignin(u1)) throw new Stop('signin', 'Best Buy wants you to sign in again before checking out');
      }
      await step(viaBuyNow ? 'checkout page (Buy now)' : 'checkout page');
      let k = await ask(id, {bb: 'checkout', want}, 25000);
      if (k.check) throw new Stop('check', k.check);
      if (k.pickup) {                          // v75 (your rule: always shipping): set to store pickup -> switched to shipping, read again
        const sh2 = await ask(id, {bb: 'ship', want, allowPickup: false}, 10000);
        await step('the checkout was set to store pickup - ' + (sh2 && sh2.ok ? 'switched to shipping' : 'shipping could not be chosen'));
        await settle(id);
        k = await ask(id, {bb: 'checkout', want}, 25000);
        if (k.check) throw new Stop('check', k.check);
        if (k.pickup) throw new Stop('page', 'the checkout stays on store pickup (never allowed) - not ordered');
      }
      await step('checkout read', {identity: k.identity, qtyOne: k.qtyOne, base: k.base, tax: k.tax, shipping: k.shipping, total: k.total, fees: k.fees, cvv: k.cvv, place: k.place});
      if (k.problems && k.problems.length) throw new Stop('action', k.problems.join('; '));
      if (!k.identity && p.mode !== 'search') throw new Stop('identity', 'the checkout page does not show this product');
      if (!k.qtyOne) throw new Stop('cart', 'the checkout does not show exactly one item');
      if (k.base == null) throw new Stop('page', 'the item price is not readable on the checkout page');
      if (!dryRun && k.base > p.cap + 0.001) throw new Stop('overcap', `checkout item price $${k.base.toFixed(2)} is over the cap $${p.cap.toFixed(2)}`);
      const capRef = dryRun ? Math.max(p.cap || 0, k.base) : p.cap;
      if (k.tax != null && k.tax > (Math.min(k.base, capRef) + (k.shipping || 0)) * TAX_SHARE + 0.01) throw new Stop('fees', `tax $${k.tax.toFixed(2)} is more than 12 % of item + shipping`);
      if (k.fees != null && k.fees > FEES_MAX) throw new Stop('fees', `extra fees $${k.fees.toFixed(2)}`);
      if (k.total != null && k.tax != null) {
        const sum = k.base + (k.tax || 0) + (k.shipping || 0) + (k.fees || 0);
        if (Math.abs(sum - k.total) > 0.06 && k.total > sum) throw new Stop('fees', `the total $${k.total.toFixed(2)} is more than item + tax + shipping ($${sum.toFixed(2)})`);
      }
      if (!k.place) throw new Stop('page', 'no Place Your Order button on the checkout page');
      // shipping over $20: ask you (dry run only reports it)
      if (!dryRun && (k.shipping || 0) > SHIP_MAX) {
        await setp(key, {approval: {base: k.base, tax: k.tax, shipping: k.shipping, total: k.total, created: Date.now()}, status: `ACTION REQUIRED — SHIPPING $${k.shipping.toFixed(2)}`, step: 'waiting for your shipping approval'});
        const ans = await waitFor(key, APPROVAL_WAIT_MS);
        await setp(key, {approval: null});
        if (ans !== 'approve') throw new Stop('cancelled', ans === 'cancel' ? 'you cancelled (shipping)' : 'shipping approval timed out');
        k = await ask(id, {bb: 'checkout', want}, 15000);
      }
      // the card's security code, if Best Buy asks for it: typed by you in Restalker for this one checkout
      if (k.cvv && !k.cvvFilled) {
        if (dryRun) await step('security code would be asked from you');
        else {
          if (!secrets[key] && globalThis.__rkCardCode) { secrets[key] = globalThis.__rkCardCode; await step('security code typed in by Restalker (your saved code)'); }   // v77: no waiting for you
          if (!secrets[key]) {
            await setp(key, {needCvv: true, status: 'WAITING FOR YOU — Best Buy asks for the card security code', step: 'waiting for the card security code'});
            const ans = await waitFor(key, APPROVAL_WAIT_MS);
            await setp(key, {needCvv: false});
            if (ans !== 'cvv' || !secrets[key]) throw new Stop('cancelled', ans === 'cancel' ? 'you cancelled' : 'no security code was typed in time');
          }
          const f = await ask(id, {bb: 'cvv', value: secrets[key]}, 8000);
          delete secrets[key];
          if (!f.ok) throw new Stop('page', 'the security code could not be filled in');
          await step('security code filled in');
        }
      }
      if (dryRun) {
        await step('READY TO PLACE THE ORDER - practice run stops here');
        await go(id, CART, u => onCart(u));
        const rm = await ask(id, {bb: 'remove', want}, 15000);
        await step(rm.ok ? 'item taken out of the cart again' : 'could NOT take the item out of the cart - please remove it yourself');
        return {ok: true, dryRun: true, steps, addedVia, removed: !!rm.ok};
      }
      // 4) Place Your Order - latched BEFORE the click: never pressed twice, and an unclear result is never retried by itself
      p = await st(key);
      const x = await g();
      if (!p.armed || p.purchased || p.attempted || x.emergencyStop || x.live === false) throw new Stop('cancelled', 'auto-buy was switched off during the checkout');
      // v60: one of a product - not one per store: never pressed while the same product is being / was ordered at another store
      const RS = globalThis.RestalkerShops;
      // v75 (your rule): every store races to THIS point at the same moment. The first one presses Place order; the others wait here,
      // ready. Bought there -> this one stops (its item leaves the cart again). Not bought there -> this one presses AT ONCE.
      let waited = 0;
      for (;;) {
        const holder = RS ? RS.tryLatch(p.group, 'bestbuy', key) : null;      // (taken at once, before anything else can run)
        if (!holder) {                          // (our turn: was it ordered somewhere meanwhile? then never pressed here)
          const other = RS ? await RS.otherOrdered(p, 'bestbuy', key) : null;
          if (other) { RS.release(p.group, key); throw new Stop('other', 'it was ordered at ' + other + ' (one per product)'); }
          break;
        }
        if (!waited) { waited = Date.now(); await step('ready - ' + holder + ' is placing the order this moment; pressed here at once if that one does not go through'); }
        if (Date.now() - waited > APPROVAL_WAIT_MS + 120000) throw new Stop('page', 'waited too long for ' + holder);
        await sleep(100);
        const me = await st(key), gx = await g();
        if (me && me.submissionPending && !me.purchased) continue;     // (v75: another browser is pressing Place order for this link right now)
        if (!me || !me.armed || me.purchased || me.attempted || gx.emergencyStop || gx.live === false) throw new Stop('cancelled', 'auto-buy was switched off during the checkout');
      }
      if (waited) {                            // (the checkout page is read again: still this product, still under the cap, the same total)
        const k2 = await ask(id, {bb: 'checkout', want}, 15000);
        const RSr = () => { try { RS.release(p.group, key); } catch {} };
        if (k2.check) { RSr(); throw new Stop('check', k2.check); }
        if (k2.total == null && k2.placeAmount != null) k2.total = k2.placeAmount;
        if (!k2.ok || !k2.place || k2.base == null || k2.base > p.cap + 0.001 || (k.total != null && k2.total != null && k2.total > k.total + 0.011) ||
            (k2.placeAmount != null && k2.total != null && Math.abs(k2.placeAmount - k2.total) > 0.011) || !k2.qtyOne) {
          RSr(); throw new Stop('page', 'the checkout page changed while waiting for the other store');
        }
        await step('checkout read again after waiting ' + ((Date.now() - waited) / 1000).toFixed(1) + ' s', {base: k2.base, total: k2.total});
      }
      latched = true;
      await setp(key, {attempted: true, armed: false, submissionPending: true, submitAt: Date.now(), price: k.base, status: 'SUBMITTING ORDER', step: 'Place Your Order pressed - waiting for Best Buy\'s confirmation'});
      const pl = await ask(id, {bb: 'place'}, 8000);
      if (!pl.ok) { latched = false; await setp(key, {attempted: false, submissionPending: false, armed: true}); throw new Stop('page', pl.error || 'Place Your Order could not be pressed'); }
      diag('bb_place_pressed', {key, ms: Date.now() - t0});
      // 5) confirmation
      const end = Date.now() + CONFIRM_WAIT_MS;
      let conf = null;
      while (Date.now() < end) {
        await sleep(250);                        // (v75: the answer is seen within a quarter second - a waiting store presses at once)
        const cur = await st(key);
        if (cur && cur.purchased) return {ok: true, order: cur.orderNumber, by: 'order history'};   // Restalker already found it in your orders
        const r = await ask(id, {bb: 'confirm'}, 4000);
        if (!r || !r.ok) continue;
        if (r.failed) { conf = {failed: r.failed}; break; }
        if (r.placed && r.order) { conf = r; break; }
        if (r.placed) conf = r;                  // thank-you words seen; keep looking a little for the order number
        if (conf && Date.now() > end - CONFIRM_WAIT_MS + 15000) break;
      }
      if (conf && conf.failed) {
        if (/security code|\bcvv\b|\bcvc\b|\bcsc\b|card (verification|code)/i.test(String(conf.failed))) globalThis.__rkCardCode = null;   // v77: a turned-down saved code is never typed again by itself
        await setp(key, {attempted: false, submissionPending: false, inProgress: false, armed: false, step: null, status: 'ORDER NOT PLACED — Best Buy says: ' + conf.failed});
        diag('bb_order_failed', {key, reason: conf.failed});
        return {ok: false, failed: conf.failed};
      }
      if (conf && conf.placed) {
        await setp(key, {purchased: true, submissionPending: false, inProgress: false, orderNumber: conf.order || null, step: null, status: 'PURCHASE SUCCESS' + (conf.order ? ' — order ' + conf.order : '')});
        diag('bb_purchase_success', {key, order: conf.order, ms: Date.now() - t0});
        return {ok: true, order: conf.order};
      }
      if ((await st(key) || {}).purchased) return {ok: true};
      await setp(key, {submissionPending: false, inProgress: false, step: null, status: 'ORDER MAY HAVE BEEN SUBMITTED — CHECK BEST BUY'});
      diag('bb_submission_unclear', {key, ms: Date.now() - t0, url: (await urlOf(id)).replace(/\?.*/, '')});
      return {ok: false, unclear: true};
    } catch (e) {
      const kind = e instanceof Stop ? e.kind : 'error', msg = String(e && e.message || e);
      let fp = null;
      try { if (id) { fp = await ask(id, {bb: 'fingerprint'}, 4000); } } catch {}
      diag('bb_stopped', {key, dryRun, kind, reason: msg, steps: steps.map(s => s.name), page: fp && fp.ok ? fp : null});
      try { if (!dryRun && !/^another browser/.test(String(msg)) && globalThis.RestalkerShops && globalThis.RestalkerShops.verdict) globalThis.RestalkerShops.verdict('bestbuy', key, kind, msg, 'this browser:' + key); } catch {}
      if (dryRun) {
        let removed = null;
        if (id && !['cart', 'check', 'signin'].includes(kind)) { try { await go(id, CART, u => onCart(u)); removed = !!(await ask(id, {bb: 'remove', want}, 12000)).ok; } catch {} }
        return {ok: false, dryRun: true, kind, reason: msg, steps, page: fp && fp.ok ? fp : null, removed};
      }
      if (latched) {
        await setp(key, {submissionPending: false, inProgress: false, step: null, status: 'ORDER MAY HAVE BEEN SUBMITTED — CHECK BEST BUY (' + msg.slice(0, 80) + ')'});
        return {ok: false, unclear: true};
      }
      // nothing was ordered. Take the item out of the cart again if it got there and the reason was money / identity / cart
      if (id && !['cart', 'check', 'signin', 'soldout'].includes(kind) && (!globalThis.RestalkerShops || !globalThis.RestalkerShops.cartHolder || globalThis.RestalkerShops.cartHolder('bestbuy') === 'this browser:' + key)) {   // nothing was ordered: the item leaves the cart again (v75: only while THIS browser has the cart)
        try { if (!onCart(await urlOf(id))) await go(id, CART, u => onCart(u)); await ask(id, {bb: 'remove', want}, 12000); } catch {}
      }
      const cur = await st(key) || {};
      const fails = (cur.fails || []).filter(t => Date.now() - t < FAIL_WINDOW_MS).concat(['soldout', 'overcap', 'other'].includes(kind) ? [] : [Date.now()]);
      const needYou = ['check', 'signin', 'action', 'cart', 'identity'].includes(kind);
      const giveUp = needYou || kind === 'cancelled' || kind === 'other' || fails.length >= FAIL_MAX;
      const label = {other: 'NOT BOUGHT — ' + msg, soldout: 'NOT BOUGHT — sold out again', overcap: 'NOT BOUGHT — OVER CAP', check: 'ACTION REQUIRED — ' + msg, signin: 'ACTION REQUIRED — ' + msg,
                     action: 'ACTION REQUIRED — ' + msg, cart: 'ACTION REQUIRED — ' + msg, identity: 'ACTION REQUIRED — check the Best Buy link: ' + msg, cancelled: 'PURCHASE CANCELLED — RE-ARM REQUIRED (' + msg + ')'}[kind] || ('FAILED — ' + msg);
      await setp(key, {inProgress: false, step: null, approval: null, needCvv: false, fails, armed: giveUp ? false : cur.armed,
                       status: (cur.purchased || cur.submissionPending) ? cur.status : giveUp && !needYou && kind !== 'cancelled' && kind !== 'other' ? label + ' — ' + FAIL_MAX + ' tries failed; MANUAL RE-ARM REQUIRED' : (kind === 'soldout' || kind === 'overcap' ? label + ' (still armed)' : label + (giveUp ? '' : ' (still armed)'))});
      return {ok: false, kind, reason: msg};
    } finally {
      running = null;
      delete secrets[key];
      try { if (globalThis.RestalkerShops) globalThis.RestalkerShops.release(p && p.group, key); } catch {}
      try { if (globalThis.RestalkerShops) globalThis.RestalkerShops.cartUnlock('bestbuy', 'this browser:' + key); } catch {}
      if (!dryRun) { const s = await st(key); if (s && s.inProgress && !s.submissionPending) await setp(key, {inProgress: false}); }
    }
  }
  function waitFor(key, ms) {
    return new Promise(res => { const to = setTimeout(() => { delete waiters[key]; res('timeout'); }, ms); waiters[key] = v => { clearTimeout(to); delete waiters[key]; res(v); }; });
  }
  // ---- order history (after an unclear result) and the sign-in check
  async function readPage(url, settle = 3500) {
    let t = null;
    // v62: waits for the page to finish - or at most 15 s, then reads what is there (a store page that keeps loading adverts must not
    // count as "did not load")
    const ready = new Promise(r => { const fn = (i, ch, tt) => { if (t && i === t.id && tt.status === 'complete' && tt.url && tt.url !== 'about:blank') { chrome.tabs.onUpdated.removeListener(fn); r(tt.url); } }; chrome.tabs.onUpdated.addListener(fn); setTimeout(() => { chrome.tabs.onUpdated.removeListener(fn); r(null); }, 15000); });
    t = await chrome.tabs.create({url, active: false});
    try {
      let u = await ready;
      if (!u) { const cur = await urlOf(t.id); if (cur && /^https:/.test(cur)) u = cur; }
      if (!u) return {ok: false, error: 'page did not load'};
      if (isSignin(u)) return {ok: true, signin: true, url: u};
      const r = await ask(t.id, {bb: 'text', settle}, 20000);
      return r.ok ? {ok: true, url: u, text: r.text} : r;
    } finally { try { await chrome.tabs.remove(t.id); } catch {} }
  }
  // v59b: is an item that Best Buy's data calls buyable really buyable for us (can it be SHIPPED)? The product page is looked at in a
  // separate quiet tab (never the checkout tab), read only.
  let checkTab = null, checkBusy = Promise.resolve();
  async function pdpCheck(url) {
    if (!/^https:\/\/www\.bestbuy\.com\//.test(url)) return {ok: false, reason: 'not a Best Buy product page'};
    const run = async () => {
      let id = null;
      try { if (checkTab !== null && (await chrome.tabs.get(checkTab))) id = checkTab; } catch {}
      if (id === null) { const t = await chrome.tabs.create({url: 'about:blank', active: false}); id = checkTab = t.id; }
      const u = await go(id, url, null, 30000);
      if (!u) return {ok: false, reason: 'the product page did not load'};
      const r = await ask(id, {bb: 'pdp', wait: 8000}, 15000);
      if (!r || !r.ok) return {ok: false, reason: (r && r.error) || 'the page did not answer'};
      return {ok: true, sku: r.sku || null, inStock: !!r.inStock, storeOnly: !!r.storeOnly, ships: !!r.ships, button: r.button, price: r.price, title: r.title, fulfillment: r.fulfillment, check: r.check};
    };
    const p = checkBusy.then(run, run);
    checkBusy = p.catch(() => {});
    return p;
  }
  async function orderCheck(key) {
    const p = await st(key);
    if (!p) return {ok: false, reason: 'unknown product'};
    const r = await readPage(ORDERS, 5000);
    if (!r.ok) return {ok: true, checked: false, reason: r.error};
    if (r.signin) return {ok: true, checked: false, reason: 'not signed in to Best Buy'};
    const t = r.text.toLowerCase(), toks = (p.tokens || []).map(x => x.toLowerCase());
    const skus = [p.sku, ...(p.skuAlt || [])].filter(Boolean).map(String);
    let i = -1;
    for (const s of skus) { i = t.indexOf(s); if (i >= 0) break; }
    if (i < 0 && toks.length) { const k0 = t.indexOf(toks[0]); if (k0 >= 0 && toks.every(k => k.split('|').some(x => t.slice(Math.max(0, k0 - 400), k0 + 600).includes(x)))) i = k0; }
    if (i < 0) return {ok: true, checked: true, found: false};
    const before = r.text.slice(Math.max(0, i - 3000), i + 400), ids = [...before.matchAll(/\b(BBY\d{2}-\d{6,})\b/g)];
    return {ok: true, checked: true, found: true, orderNumber: ids.length ? ids[ids.length - 1][1] : null};
  }
  // v62: signed in? The store's own order page is OPENED in a quiet background tab, exactly as when you open it yourself (diagnostics 60:
  // the small request for it failed every time at Best Buy and GameStop - "Failed to fetch" - so they always showed "NOT signed in").
  // A sign-in page = not signed in; the order page itself = signed in; a page that cannot be judged = unknown (never "not signed in").
  const SIGNIN_WORDS = /\b(sign in|log in|signin|login)\b[^.]{0,60}\b(password|email|e-mail)\b|forgot (your )?password|sign in to (see|view|track) (your )?orders?/;
  const ACCOUNT_WORDS = /\b(order history|your orders|my orders|purchase history|order details|orders placed|track (your )?(order|package)|sign out|log ?out)\b/;
  let accountBusy = null;
  async function account() {
    if (accountBusy) return accountBusy;
    accountBusy = (async () => {
      const r = await readPage(ORDERS, 2500);
      if (!r.ok) return {ok: true, signedIn: null, reason: 'the order page did not open (' + (r.error || '?') + ')', how: 'page'};
      if (r.signin) return {ok: true, signedIn: false, how: 'page', url: (r.url || '').replace(/\?.*/, '').slice(0, 90)};
      const t = String(r.text || '').toLowerCase();
      if (/verify (that )?you are (a )?human|are you a robot|robot or human|press (and|&) hold|access denied|request unsuccessful/.test(t))
        return {ok: true, signedIn: null, reason: 'the store showed a human check on its order page (not answered)', how: 'page'};
      if (ACCOUNT_WORDS.test(t)) return {ok: true, signedIn: true, how: 'page'};
      if (SIGNIN_WORDS.test(t)) return {ok: true, signedIn: false, how: 'page', url: (r.url || '').replace(/\?.*/, '').slice(0, 90)};
      if (t.length < 200) return {ok: true, signedIn: null, reason: 'the order page was empty', how: 'page'};
      // the store kept us on its order page (it sends anyone not signed in to its sign-in page) and asks for no password: signed in
      return {ok: true, signedIn: true, how: 'page (stayed on the order page)'};
    })();
    try { return await accountBusy; } finally { accountBusy = null; }
  }
  // ---- what Restalker can ask
  async function command(c) {
    const key = String(c.key || '');
    if (c.type === 'BB_SET') {          // product data from Restalker's table (link, name words, cap, Best Buy number)
      const cur = await st(key) || {};
      const moved = !!c.url && String(c.url) !== String(cur.url || '');       // (v75: a NEW link - the old page's item number is forgotten)
      const v = {url: String(c.url || cur.url || ''), name: String(c.name || cur.name || ''), tokens: Array.isArray(c.tokens) ? c.tokens.map(String).slice(0, 8) : (cur.tokens || []),
                 sku: c.sku ? String(c.sku) : (moved ? null : (cur.sku || null)), forbid: Array.isArray(c.forbid) ? c.forbid.map(String).slice(0, 6) : (cur.forbid || []),
                 group: c.group ? String(c.group) : (cur.group || null), amazonPid: c.amazonPid ? String(c.amazonPid) : (cur.amazonPid || null),
                 trusted: c.trusted === undefined ? !!cur.trusted : !!c.trusted};     // v75: a link YOU gave - its page is the product
      if (moved) v.skuAlt = [];
      if (c.cap != null) { const cap = Number(c.cap); if (!(cap > 0)) return {ok: false, reason: 'invalid cap'}; if (cur.inProgress || cur.submissionPending) return {ok: false, reason: 'checkout running'}; v.cap = cap; }
      await setp(key, v); return {ok: true};
    }
    if (c.type === 'BB_ARM') {
      const p = await st(key);
      if (!p || !p.url || !(p.cap > 0)) return {ok: false, reason: 'the product needs its Best Buy link and a price cap'};
      if (p.purchased || p.attempted || p.submissionPending) return {ok: false, reason: 'Already purchased, attempted or order unresolved. Do not re-purchase automatically'};
      await setp(key, {armed: true, fails: [], status: 'ARMED — AUTO BUY ON'}); await setg({emergencyStop: false}); return {ok: true};
    }
    if (c.type === 'BB_DISARM') {
      const p = await st(key);
      if (p && (p.inProgress || p.submissionPending)) { if (waiters[key]) waiters[key]('cancel'); }
      if (p) await setp(key, {armed: false, status: p.purchased ? p.status : 'PRODUCT DISARMED'});
      return {ok: true};
    }
    if (c.type === 'BB_BUY_AGAIN') {
      const p = await st(key);
      if (!p || !p.purchased) return {ok: false, reason: 'No confirmed prior purchase to re-authorize'};
      if (!c.confirmedAdditionalPurchase) return {ok: false, reason: 'confirm the additional purchase'};
      await setp(key, {priorPurchases: [...(p.priorPurchases || []), {order: p.orderNumber, at: p.submitAt, price: p.price}], purchased: false, attempted: false,
                       submissionPending: false, inProgress: false, orderNumber: null, armed: true, fails: [], status: 'RE-ARMED FOR ONE ADDITIONAL PURCHASE'});
      return {ok: true};
    }
    if (c.type === 'BB_EXTRA_STATE') {    // v75: an order placed by one of Restalker's OTHER buying browsers - written here, so every rule sees it
      const p = await st(key); if (!p) return {ok: false, reason: 'unknown product'};
      const who = String(c.browser || 'another browser').slice(0, 30), stt = String(c.state || '');
      if (stt === 'submitting') await setp(key, {attempted: true, submissionPending: true, extraPrevArmed: !!p.armed, armed: false, submitAt: Date.now(), price: c.price ?? p.price ?? null, status: 'SUBMITTING ORDER — ' + who});
      else if (stt === 'bought') await setp(key, {purchased: true, attempted: true, submissionPending: false, inProgress: false, orderNumber: c.orderNumber || null, status: 'PURCHASE SUCCESS — ' + who + (c.orderNumber ? ' — order ' + c.orderNumber : '')});
      else if (stt === 'unclear') await setp(key, {submissionPending: false, inProgress: false, status: 'ORDER MAY HAVE BEEN SUBMITTED — CHECK ' + 'Best Buy'.toUpperCase() + ' (' + who + ')'});
      else if (stt === 'failed') await setp(key, {attempted: false, submissionPending: false, armed: !!p.extraPrevArmed, status: 'ORDER NOT PLACED — ' + who + ': ' + String(c.reason || '').slice(0, 120)});
      return {ok: true};
    }
    if (c.type === 'BB_MARK') {
      const p = await st(key); if (!p) return {ok: false, reason: 'unknown product'};
      if (c.bought) await setp(key, {purchased: true, attempted: true, orderNumber: c.orderNumber || p.orderNumber || null, status: c.status || 'PURCHASE SUCCESS — confirmed'});
      else await setp(key, {purchased: false, attempted: false, submissionPending: false, inProgress: false, armed: false, status: 'NOT ORDERED — checked by you'});
      return {ok: true};
    }
    if (c.type === 'BB_ANSWER') {       // security code / shipping approval / cancel, typed or pressed in Restalker
      if (c.answer === 'cvv') { const v = String(c.value || '').replace(/\D/g, ''); if (v.length < 3 || v.length > 4) return {ok: false, reason: 'the security code has 3 or 4 digits'}; secrets[key] = v; }
      if (!waiters[key]) return {ok: false, reason: 'nothing is waiting for an answer'};
      waiters[key](c.answer === 'cvv' ? 'cvv' : c.answer === 'approve' ? 'approve' : 'cancel');
      return {ok: true};
    }
    if (c.type === 'BB_GLOBAL') { const v = {}; if ('live' in c) v.live = !!c.live; if ('allowPickup' in c) v.allowPickup = !!c.allowPickup; if (c.emergencyStop) v.emergencyStop = true; await setg(v);
      if (c.emergencyStop) for (const p of await all()) { if (!p.submissionPending && !p.attempted) await setp(p.key, {armed: false, status: p.purchased ? p.status : 'EMERGENCY STOP — DISARMED'}); if (waiters[p.key]) waiters[p.key]('cancel'); }
      return {ok: true}; }
    if (c.type === 'BB_PRACTICE') {     // practice run: the whole checkout on the real site, stops before Place Your Order, empties the cart again
      if (running) return {ok: false, reason: 'a Best Buy checkout is running'};
      const tmp = 'practice';
      await setp(tmp, {url: String(c.url || ''), name: String(c.name || 'practice item'), tokens: Array.isArray(c.tokens) ? c.tokens : [], sku: c.sku ? String(c.sku) : null,
                       cap: Number(c.cap) || 100000, mode: c.mode === 'search' ? 'search' : 'product', armed: false, practice: true});
      const r = await campaign(tmp, {dryRun: true});
      await chrome.storage.local.remove(K(tmp));
      const res = {at: Date.now(), ...r};
      await setg({practice: res});
      return {ok: true, result: res};
    }
    if (c.type === 'BB_PDP_CHECK') return pdpCheck(String(c.url || ''));
    if (c.type === 'BB_ORDER_CHECK') return orderCheck(key);
    if (c.type === 'BB_ACCOUNT') return account();
    if (c.type === 'BB_FORGET') { const p = await st(key); if (p && !p.inProgress && !p.submissionPending) await chrome.storage.local.remove(K(key)); return {ok: true}; }
    return {ok: false, reason: 'unknown Best Buy command'};
  }
  async function onRestock(ev) {
    const key = String(ev.key || '');
    const p = await st(key);
    if (!p) return {ok: false, retryable: false, reason: 'ASIN absent from buyer catalog'};
    if (p.purchased || p.attempted) return {ok: true, reason: 'target completed; manual rearm required'};
    const x = await g();
    if (!p.armed || x.emergencyStop || x.live === false) return {ok: true, reason: 'monitor disabled'};
    if (running === key || p.inProgress) return {ok: true, reason: 'target checkout already started'};
    if (running) return {ok: false, retryable: true, reason: 'other checkout owns buyer; retry after release'};
    campaign(key, {reason: 'restock'}).catch(e => diag('bb_campaign_error', {key, reason: String(e && e.message || e)}));
    return {ok: true, reason: 'fresh Amazon check dispatched'};
  }
  async function snapshot() {
    return (await all()).filter(p => !p.practice).map(p => ({key: p.key, store: 'bestbuy', name: p.name, sku: p.sku, cap: p.cap ?? null, armed: !!p.armed && !p.purchased && !p.attempted,
      purchased: !!p.purchased, attempted: !!p.attempted, inProgress: !!p.inProgress, submissionPending: !!p.submissionPending, status: String(p.status || '').slice(0, 240),
      step: p.step || null, price: p.price ?? null, orderNumber: p.orderNumber || null, submitAt: p.submitAt || null, hitAt: p.hitAt || null,
      approval: p.approval || null, needCvv: !!p.needCvv}));
  }
  async function startup() {
    // like the Amazon checkout: after a browser start nothing is left half-way. A pressed Place Order without an answer = unconfirmed.
    const s = await chrome.storage.session.get('bbRecovered');
    if (s.bbRecovered) return;
    for (const p of await all()) {
      if (p.practice) { await chrome.storage.local.remove(K(p.key)); continue; }
      if (p.submissionPending) await setp(p.key, {submissionPending: false, inProgress: false, armed: false, status: 'ORDER STATE UNCERTAIN AFTER BROWSER RESTART — CHECK BEST BUY'});
      else if (p.inProgress) await setp(p.key, {inProgress: false, armed: false, approval: null, needCvv: false, status: 'PURCHASE INTERRUPTED — RE-ARM REQUIRED'});
      else if (p.armed) await setp(p.key, {armed: false, status: 'DISARMED AFTER BROWSER RESTART'});
    }
    await setg({tab: null});
    await chrome.storage.session.set({bbRecovered: true});
  }
  globalThis.RestalkerBestBuy = {CODE: "v107", command, onRestock, snapshot, startup, setDiag: fn => { diag = fn; }, running: () => running};
})();
