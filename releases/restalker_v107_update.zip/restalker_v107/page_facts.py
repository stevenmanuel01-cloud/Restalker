"""v107: the few facts of a kept Amazon page that tell who really sells it (KNOWN_ISSUES: trackers report Amazon at MSRP while our
readers see only resellers - diagnostics 86: 10 tracker alerts, 200 readings by 6 browsers, never buyable).

For each page kept after a tracker alert (alert_pages/), the diagnostics show: the price in the buy box, who sells it and who ships it,
the availability line, which buttons there are (Add to Cart / Buy Now / See All Buying Options), how many other offers Amazon lists,
and whether Amazon knew a delivery address (only "set" or "not set" - never the address itself). Read only."""
import os
import re

VERSION = "v107"


def _txt(el, n=90):
    if el is None:
        return ""
    t = re.sub(r"\s+", " ", el.get_text(" ")).strip()
    return t[:n]


def amazon(html):
    """-> {"price", "sold_by", "ships_from", "availability", "add_to_cart", "buy_now", "see_all", "offers", "no_featured", "deliver"}"""
    from stock_detect import get_soup
    soup = get_soup(html, True)
    out = {"title": bool(soup.find(id="productTitle"))}
    price = ""
    for sel in ("#corePriceDisplay_desktop_feature_div .a-offscreen", "#corePrice_feature_div .a-offscreen", "#apex_desktop .a-offscreen",
                "#desktop_buybox .a-price .a-offscreen", "#buybox .a-price .a-offscreen"):
        el = soup.select_one(sel)
        if el and _txt(el):
            price = _txt(el, 20)
            break
    out["price"] = price
    sold = soup.select_one("#merchantInfoFeature_feature_div .offer-display-feature-text-message") or soup.find(id="sellerProfileTriggerId") \
        or soup.find(id="merchant-info")
    ships = soup.select_one("#fulfillerInfoFeature_feature_div .offer-display-feature-text-message")
    out["sold_by"] = _txt(sold, 60)
    out["ships_from"] = _txt(ships, 60)
    out["availability"] = _txt(soup.find(id="availability"), 70)
    out["add_to_cart"] = bool(soup.find(id="add-to-cart-button"))
    out["buy_now"] = bool(soup.find(id="buy-now-button"))
    out["see_all"] = bool(soup.find(id="buybox-see-all-buying-choices") or soup.find(id="buybox-see-all-buying-choices-announce"))
    m = re.search(r"New\s*\((\d+)\)\s*from\s*(\$[\d,]+\.\d\d)", soup.get_text(" "))
    out["offers"] = f"{m.group(1)} new offers from {m.group(2)}" if m else ""
    box = " ".join(_txt(soup.find(id=b), 2000).lower() for b in ("desktop_buybox", "buybox", "rightCol") if soup.find(id=b))
    out["no_featured"] = "no featured offers" in box
    d = soup.find(id="glow-ingress-line2") or soup.find(id="contextualIngressPtLabel_deliveryShortLine")
    dt = _txt(d, 80).lower()
    out["deliver"] = "" if not d else ("not set (Amazon guesses the area from the internet address)" if ("select your address" in dt or "update location" in dt or not dt)
                                       else "set (an address is chosen; not shown here)")
    return out


def line(f):
    parts = []
    parts.append(f"price {f['price'] or '-'}")
    parts.append(f"sold by {f['sold_by'] or '-'}")
    if f["ships_from"]:
        parts.append(f"ships from {f['ships_from']}")
    if f["availability"]:
        parts.append(f"'{f['availability']}'")
    b = [n for n, k in (("Add to Cart", "add_to_cart"), ("Buy Now", "buy_now"), ("See All Buying Options", "see_all")) if f[k]]
    parts.append("buttons: " + (", ".join(b) if b else "none"))
    if f["offers"]:
        parts.append(f["offers"])
    if f["no_featured"]:
        parts.append("'No featured offers'")
    if f["deliver"]:
        parts.append(f"delivery address {f['deliver']}")
    if not f["title"]:
        parts.append("(not a product page)")
    return "; ".join(parts)


def report(folder="alert_pages", limit=10):
    """Diagnostics: the newest kept Amazon pages, one line each."""
    try:
        names = sorted((n for n in os.listdir(folder) if "_amazon_" in n and n.endswith(".html")), reverse=True)[:limit]
    except Exception:
        return "  no pages kept yet"
    if not names:
        return "  no Amazon page kept yet"
    out = []
    sellers = {}
    for n in names:
        try:
            html = open(os.path.join(folder, n), encoding="utf-8", errors="replace").read()
            head = html.split("\n", 1)[0]
            m = re.search(r"read by: ([^>]*?) -->", head)
            f = amazon(html)
            sellers[f["sold_by"] or "-"] = sellers.get(f["sold_by"] or "-", 0) + 1
            out.append(f"  {n[:15]} {n[16:].rsplit('_', 1)[0]} ({m.group(1) if m else '?'}): {line(f)}")
        except Exception as e:
            out.append(f"  {n}: could not be read ({str(e)[:60]})")
    out.insert(0, f"  the newest {len(names)} kept Amazon pages - sold by: " + ", ".join(f"{k} {v}x" for k, v in sorted(sellers.items(), key=lambda kv: -kv[1])))
    return "\n".join(out)
