#!/usr/bin/env python3
"""
Ground-truth restock poller.

This is your independent reference clock: it hits each product's real
retailer page directly, on a tight interval, and logs the exact moment
the stock status flips from OUT_OF_STOCK -> IN_STOCK. Every tracker's
alert timestamp gets compared against this log, never against another
tracker.

Stock status is detected automatically from the page's own standard
machine-readable product data (see stock_detect.py) — no manual button
text needed.

Self-healing: a target's fetch_mode ("http" or "browser") starts from
whatever app.py's add-time burst test decided, but this module doesn't
just trust that forever. If a target fails 3 times in a row DURING a
live run, it automatically tries a real browser right then — before
giving up to backoff — and if that works, switches the target to
browser mode permanently (persisted back to targets.yaml via `report`,
so it stays fixed across restarts too) with no action needed from
whoever's running it. Only if browser mode ALSO fails does it fall back
to exponential backoff as a last resort.

Usually run automatically by app.py — see README. Standalone use:
    python ground_truth_poller.py --config targets.yaml --out ground_truth.csv
"""
import argparse
import csv
import json
import os
import collections
import re
import threading
import time
from datetime import datetime, timezone

from stock_detect import (detect_availability, diagnose, status_evidence, is_human_check_page, human_check_reason, detect_price,
                          target_api_url, target_fulfillment_urls, json_clues, TARGET_KNOWN_KEY, _tgt_where, parse_bestbuy_blocks, price_clues, amazon_other_sellers_only)
from http_utils import fetch, append_csv_row, flush_pending_csv
from browser_fetch import BrowserFetcher, CamoufoxFetcher, INSTALLS as ENGINE_INSTALLS
try:
    from browser_fetch import FirefoxFetcher
except Exception:
    FirefoxFetcher = None
try:
    from browser_fetch import RealChromeFetcher
except Exception:          # an older browser_fetch.py
    RealChromeFetcher = None
try:
    from browser_fetch import StealthChromeFetcher, stealth_ready
except Exception:          # an older browser_fetch.py
    StealthChromeFetcher, stealth_ready = None, (lambda: False)
import samples
import recon
import hotness
import products
import matrix
import thumbs
import linkcheck
import hygiene
import sweep


_PRESSURE_LOCK = threading.Lock()
_PRESSURE_LAST = [0.0]      # v52: when a reader last restarted its browser because the program was over its memory limit (one at a time)


def _can_park(store_name):
    """May this store's tab rest between checks? Not Best Buy (its small data requests need a freshly opened page), and not
    Target while its small stock request is working (that request is made from inside the open page)."""
    if os.environ.get("RK_NO_PARK") or store_name == "bestbuy":
        return False
    if store_name == "target" and _TGT.get("tmpl"):
        return False
    return True


def _sleep_or_stop(seconds, stop_event):
    """Sleep in small chunks so a stop request takes effect within ~0.5s
    instead of waiting out a multi-second sleep. Returns True if stopped."""
    end = time.time() + seconds
    while time.time() < end:
        if stop_event is not None and stop_event.is_set():
            return True
        time.sleep(min(0.5, max(0, end - time.time())))
    return False


def _wake_or_stop(persist, seconds, stop_event, seen):
    """v82: like _sleep_or_stop, but ends the moment the store's sweeper hands on a new answer (sweep.put -> wake_n goes up), instead of
    when a timer runs out - the hand-off from the sweeper to the checker (alerts, buying) no longer waits up to half a second."""
    cv = persist.get("wake_cv")
    if cv is None:
        return _sleep_or_stop(seconds, stop_event)
    with cv:
        if persist.get("wake_n", 0) == seen and not (stop_event is not None and stop_event.is_set()):
            cv.wait(min(seconds, 0.5))
    return stop_event is not None and stop_event.is_set()


class _LegacyBrowser:
    """Creates its one BrowserFetcher only the first time it's actually
    needed, and never more than once per run() call regardless of how
    many targets end up using it."""
    def __init__(self, store="", lane=0):
        self._instance = None
        self._store = store
        self._fallback = False
        self._lane = lane          # v50: 0 = the store's main checker; 1, 2 ... = the extra readers that work at the same time

    def get(self):
        if self._store == "bestbuy" and self._instance is not None:
            _want = _BBP.get("engine", "chrome")
            if _want != ("camoufox" if isinstance(self._instance, CamoufoxFetcher) else "chrome"):
                try:
                    self._instance.close()          # Best Buy is to be looked at with the other kind of browser now
                except Exception:
                    pass
                self._instance = None
                _BBP["need_warm"] = True
        if self._instance is None:
            try:
                bb = (self._store == "bestbuy")
                if bb and _BBP.get("engine") == "camoufox" and ENGINE_INSTALLS["camoufox"]["state"] == "ready":
                    self._instance = CamoufoxFetcher(store=self._store)
                    return self._instance
                tg = (self._store == "target") and not os.environ.get("RK_TARGET_HIDDEN") and not self._fallback
                wm = (self._store == "walmart") and not os.environ.get("RK_WALMART_HIDDEN") and not self._fallback
                if bb and RealChromeFetcher is not None and RealChromeFetcher.available():
                    # Best Buy: use the PC's ordinary Chrome/Edge, started normally
                    # (no automation markers) with its own saved profile.
                    self._instance = RealChromeFetcher(profile_dir="browser_profile_bestbuy", port=9333,
                                                       store=self._store)
                elif tg and RealChromeFetcher is not None and RealChromeFetcher.available():
                    # Target's bot check blocked every data request its page made in the hidden-mode browser
                    # (HTTP 435), so the page never got its price / stock. The PC's ordinary Chrome, parked off
                    # screen, is what a normal visitor looks like.
                    self._instance = RealChromeFetcher(profile_dir="browser_profile_target", port=9334,
                                                       store=self._store, block_media=True)
                elif wm and RealChromeFetcher is not None and RealChromeFetcher.available():
                    # Walmart showed "prove you are human" pages to the program's automation-started browser while the same pages open
                    # normally in an ordinary Chrome. The PC's ordinary Chrome, started like a person starts it (own saved profile, parked off
                    # screen), is what worked for Target and Best Buy.
                    self._instance = RealChromeFetcher(profile_dir="browser_profile_walmart", port=9336,
                                                       store=self._store, block_media=True)
                else:
                    self._instance = BrowserFetcher(offscreen=bb, fresh=bb, store=self._store)
                    try:                      # v63: reader 1, 2, 3 ... of this store start with Chrome, Edge, Camoufox, Firefox, built-in Chromium
                        if not bb:
                            self._instance._idx = self._lane % len(BrowserFetcher.CHANNELS)
                    except Exception:
                        pass
            except TypeError:           # an older browser_fetch.py
                self._instance = BrowserFetcher()
        elif (self._store in ("target", "walmart") and not self._fallback and isinstance(self._instance, RealChromeFetcher)
              and getattr(self._instance, "start_failures", 0) >= 3):
            # the ordinary Chrome will not start here: go back to the hidden-mode browser
            self._fallback = True
            try:
                self._instance.close()
            except Exception:
                pass
            self._instance = BrowserFetcher(store=self._store)
        return self._instance

    def close(self):
        if self._instance:
            self._instance.close()

    def park(self):
        """Between checks: put the tab on a plain text page of the same store (see browser_fetch.park) so it stops costing CPU."""
        inst = self._instance
        if inst is not None and hasattr(inst, "park"):
            try:
                return inst.park()
            except Exception:
                return False
        return False

    def clear_cache(self):
        """v52: the page cache of this reader's open browser(s) is emptied (cookies and logins stay). Returns how many browsers did it."""
        n = 0
        for inst in self._open_instances():
            try:
                if hasattr(inst, "clear_cache") and inst.clear_cache():
                    n += 1
            except Exception:
                pass
        return n

    def _open_instances(self):
        return [self._instance] if self._instance is not None else []

    def recycle(self):
        """Close the browser and forget it, so the next check opens a brand-new one."""
        inst, self._instance = self._instance, None
        if inst:
            inst.close()



# ---- v38: a small pool of browsers per store, switched automatically ---------------------------------------------------------------
# For the stores that push back (Target, Walmart, Best Buy) the program keeps SEVERAL different browsers ready: the PC's Chrome, the PC's Edge
# (each with its own saved profile), Camoufox once it is installed, and the built-in browser as the last choice. When a read fails, a page
# cannot be read, or a store shows a "prove you are human" page, the SAME check is made again at once with the next browser that is ready,
# and the browser that failed sits out for a while (45 s, then 2, 5, 10, 15 min for repeated failures; 15+ min after a human-check page) and is
# brought back afterwards. While a store has had trouble, the browsers are also taken in turns (every POOL_ROTATE_EVERY seconds) so no single
# one looks like it is asking all the time. The program still never clicks, solves or goes around a "prove you are human" page.
POOL_STORES = ("target", "walmart", "bestbuy")
LANE_ENGINES = ("chrome", "firefox", "camoufox", "edge", "stealth", "builtin")      # v63: reader 1, 2, 3 ... of a store each start with the next one
POOL_COOL = (45.0, 120.0, 300.0, 600.0, 900.0)       # seconds a browser sits out after its 1st, 2nd, 3rd ... failure in a row
POOL_BLOCK_COOL = 900.0                                # after a human-check page (doubles for the next one, at most 30 min)
POOL_NONBLOCK_MAX = 120.0                             # v49: longest rest of a browser after an ordinary failure (a human-check page still rests 15+ min)
LIGHT_RETURN_AFTER = 120.0                           # v48: seconds on Firefox / Camoufox before going back to Chrome / Edge as soon as one is ready
POOL_ROTATE_EVERY = 150.0                              # while a store has had trouble: another ready browser takes over this often
POOL_TROUBLE_WINDOW = 1800.0                           # "had trouble" = a failure within this many seconds
POOL_SOFT_IGNORE = 120.0                               # a failure that is not clearly the browser's fault is ignored when it read something this recently
_POOLS = {}                                            # store -> its _LazyBrowser (the Best Buy helpers need to reach it)
_POOL_PORTS = {"bestbuy": 9333, "target": 9334, "walmart": 9336}
_POOL_PROFILES = {"bestbuy": "browser_profile_bestbuy", "target": "browser_profile_target", "walmart": "browser_profile_walmart"}
_POOL_STORE_NAMES = {"bestbuy": "Best Buy", "target": "Target", "walmart": "Walmart"}
_BROWSERISH = ("ERR_", "NOTHING back", "HTTP 403", "HTTP 429", "HTTP 435", "HTTP 5", "Timeout", "could not be started", "human", "closed")


class _Member:
    def __init__(self, kind, prio, label):
        self.kind, self.prio, self.label = kind, prio, label
        self.inst = None
        self.cool_until = 0.0
        self.strikes = 0
        self.blocks = 0
        self.ok_streak = 0
        self.ok = 0
        self.fail = 0
        self.last_fail_at = 0.0
        self.last_ok_at = 0.0
        self.last_used = 0.0
        self.last_why = ""
        self.was_cooling = False


def _fmt_wait(sec):
    sec = max(0, int(sec))
    return f"{sec} s" if sec < 100 else f"{round(sec / 60)} min"


class _LazyBrowser(_LegacyBrowser):
    """Creates its browser(s) only when needed. Stores in POOL_STORES get a pool of browsers that are switched automatically (see above);
    every other store keeps its one browser exactly as before."""

    def __init__(self, store="", lane=0):
        _LegacyBrowser.__init__(self, store, lane)
        self._pool = bool(store in POOL_STORES and not os.environ.get("RK_NO_POOL"))
        self._members = []
        self._cur = None
        self._rot_at = time.time()
        self._rot_logs = 0
        self._plock = threading.RLock()
        # v63: every reader of a store starts with a DIFFERENT browser - Chrome, Firefox, Camoufox, Edge, the built-in one - so all of them read
        # at the same time (the report: "everything seems to use Chrome"); a reader only moves to another browser when its own one fails
        self._prefer = LANE_ENGINES[lane % len(LANE_ENGINES)]
        if self._pool and lane == 0:
            _POOLS[store] = self

    # ---- members
    def _sync(self):
        hidden = os.environ.get("RK_TARGET_HIDDEN") if self._store == "target" else os.environ.get("RK_WALMART_HIDDEN") if self._store == "walmart" else None
        want = []
        if RealChromeFetcher is not None and not hidden:
            try:
                c = RealChromeFetcher.candidates()
            except Exception:
                try:
                    c = ["chrome"] if RealChromeFetcher.available() else []
                except Exception:
                    c = []
            if c:
                want.append(("chrome", 0, "your " + _exe_label(c[0])))
            if len(c) >= 2:
                try:
                    _ei = RealChromeFetcher.exe_index("edge")
                except Exception:
                    _ei = -1
                want.append(("edge", 1, "your " + _exe_label(c[_ei if 0 < _ei < len(c) else 1])))
            try:            # v76: Hidden Chrome (your Chrome driven so the store cannot see a program drives it) - a reader of its own
                if StealthChromeFetcher is not None and stealth_ready():
                    want.append(("stealth", 4, "Hidden Chrome"))
            except Exception:
                pass
        if ENGINE_INSTALLS["camoufox"]["state"] == "ready":
            want.append(("camoufox", 2, "Camoufox"))
        if self._store != "bestbuy" and ENGINE_INSTALLS["firefox"]["state"] == "ready" and FirefoxFetcher is not None:
            want.append(("firefox", 3, "Firefox"))
        if self._store != "bestbuy" or not want:          # Best Buy's grouped reading needs a Chrome-type page; the built-in one only when nothing else exists
            want.append(("builtin", 9, "the built-in browser"))
        have = {m.kind for m in self._members}
        for kind, prio, label in want:
            if kind not in have:
                self._members.append(_Member(kind, prio, label))

    def _build(self, m):
        s = self._store
        bm = s in ("target", "walmart")
        prof, port, edge_port = _POOL_PROFILES.get(s, "browser_profile_" + s), _POOL_PORTS.get(s, 9337), _POOL_PORTS.get(s, 9337) + 50
        if self._lane:          # v50: an extra reader has its own browser process, its own saved profile and its own port
            prof, port = f"{prof}_lane{self._lane}", lane_port(s, self._lane)
            edge_port = port + 5
        if m.kind == "chrome":
            return RealChromeFetcher(profile_dir=prof, port=port, store=s, block_media=bm)
        if m.kind == "edge":
            f = RealChromeFetcher(profile_dir=prof, port=edge_port, store=s, block_media=bm)
            try:
                ei = RealChromeFetcher.exe_index("edge")          # v76: Edge itself when it is installed (not just "the second browser")
            except Exception:
                ei = -1
            f._exe_idx = ei if ei > 0 else 1
            return f
        if m.kind == "stealth":
            return StealthChromeFetcher(profile_dir=prof + "_stealth", store=s, block_media=bm)
        if m.kind == "camoufox":
            return CamoufoxFetcher(store=s)
        if m.kind == "firefox":
            return FirefoxFetcher(store=s)
        return BrowserFetcher(offscreen=(s == "bestbuy"), fresh=(s == "bestbuy"), store=s)

    def _ready(self, now, exclude=None, max_prio=99):
        return [m for m in self._members if m is not exclude and m.cool_until <= now and m.prio <= max_prio]

    def _pick(self, exclude=None, now=None, max_prio=99):
        """The ready browser to use next: this reader's own browser kind when it is ready (v63), else the one with the fewest recent failures."""
        now = now or time.time()
        c = self._ready(now, exclude, max_prio)
        return min(c, key=lambda m: (0 if m.kind == self._prefer else 1, m.strikes, m.prio, m.last_used)) if c else None

    def soonest_ready(self):
        """Seconds until some browser of this store is ready again (0 = one is ready now)."""
        now = time.time()
        with self._plock:
            self._sync()
            if not self._members:
                return 0.0
            return max(0.0, min(m.cool_until for m in self._members) - now)

    def _on_switch(self):
        """What the store's checker has learned about the OLD browser's open page must be learned again with the new one."""
        if self._lane:
            return              # v50: an extra reader's browser has nothing to do with what the store's main checker has learned
        if self._store == "bestbuy":
            _BBP["need_warm"] = True
            _BBP["fresh_visitor"] = False
            _BBP["pause_until"] = 0.0
            _BBP["ts"] = 0.0
        elif self._store == "target":
            _TGT["tmpl"], _TGT["mode"], _TGT["fails"], _TGT["retry_at"] = None, None, 0, 0.0

    def _switch(self, old, new, text, log):
        with self._plock:
            self._cur = new
            self._instance = new.inst
            self._rot_at = time.time()
        if old is not None and old.inst is not None:
            try:
                old.inst.park()            # the browser that is sitting out stops costing CPU
            except Exception:
                pass
        self._on_switch()
        if log:
            try:
                log(text)
            except Exception:
                pass

    # ---- the one the checks use
    def get(self):
        if not self._pool:
            return _LegacyBrowser.get(self)
        with self._plock:
            self._sync()
            now = time.time()
            m = self._cur
            if m is not None and m.kind in ("chrome", "edge", "stealth") and m.inst is not None and getattr(m.inst, "start_failures", 0) >= 3:
                m.cool_until, m.strikes = now + 1800.0, max(m.strikes, 4)       # this browser will not even start: leave it alone for a while
                m.last_why = "would not start"
                self._fallback = True
                try:
                    m.inst.close()
                except Exception:
                    pass
                m.inst = None
                self._cur = m = None
            if m is None or (m.cool_until > now and any(x.cool_until <= now for x in self._members)):
                m = self._pick(now=now) or min(self._members, key=lambda x: x.cool_until)
                self._cur = m
            if m.kind != self._prefer and now - self._rot_at > LIGHT_RETURN_AFTER and m.cool_until <= now:
                # v63: a reader that had to fill in with another browser goes back to ITS OWN kind once that one is ready again
                lt = [x for x in self._ready(now, m) if x.kind == self._prefer]
                if lt:
                    nl = lt[0]
                    self._switch(m, nl, None, None)
                    m = nl
                    self._cur = m
                    self._light_back = getattr(self, "_light_back", 0) + 1
            if m.inst is None:
                try:
                    m.inst = self._build(m)
                except Exception as e:
                    m.cool_until, m.strikes, m.last_why = now + 600.0, m.strikes + 1, "could not be opened: " + str(e)[:60]
                    nxt = self._pick(exclude=m, now=now)
                    if nxt is None:
                        raise
                    self._cur = nxt
                    return self.get()
            m.last_used = now
            self._instance = m.inst
            return m.inst

    def note_result(self, ok, why="", block=False, soft=False, log=None):
        """Tells the pool how the last check went with the current browser. A failure puts that browser out for a while and, when another one
        is ready, switches to it at once. Returns True when it switched (the caller then repeats the check immediately)."""
        if not self._pool:
            return False
        now = time.time()
        with self._plock:
            m = self._cur
            if m is None:
                return False
            if ok:
                m.ok += 1
                m.last_ok_at = now
                m.ok_streak += 1
                if m.ok_streak >= 5 and (m.strikes or m.blocks):
                    m.strikes = max(0, m.strikes - 1)
                    m.blocks = max(0, m.blocks - 1)
                    m.ok_streak = 0
                return False
            why = str(why or "")
            browserish = block or any(k in why for k in _BROWSERISH)
            if (soft or not browserish) and now - m.last_ok_at < POOL_SOFT_IGNORE:
                return False                       # it read something a moment ago: this is that product's problem, not the browser's
            m.fail += 1
            m.ok_streak = 0
            m.last_fail_at = now
            m.last_why = why[:120]
            m.strikes += 1
            if block:
                m.blocks += 1
                cool = min(1800.0, POOL_BLOCK_COOL * (2 ** (m.blocks - 1)))
            else:
                cool = min(POOL_COOL[min(m.strikes - 1, len(POOL_COOL) - 1)], POOL_NONBLOCK_MAX)      # v49: a hang-up or time-out is not a human-check: back within 2 minutes, not 5-15
            m.cool_until = now + cool
            m.was_cooling = True
            nxt = self._pick(exclude=m, now=now)
            sname = _POOL_STORE_NAMES.get(self._store, self._store.title())
            if nxt is None:
                if log:
                    log(f"[browser] {sname}: {m.label} {'was shown a human-check page' if block else 'could not read it (' + why[:60] + ')'}, and no other browser is ready right now "
                        f"(they are all resting; the first is back in {_fmt_wait(self.soonest_ready())}).")
                return False
        if nxt.inst is None:
            try:
                with self._plock:
                    nxt.inst = self._build(nxt)
            except Exception:
                nxt.cool_until, nxt.strikes = now + 600.0, nxt.strikes + 1
                return self.note_result(False, why, block, soft, log)
        self._switch(m, nxt, f"[browser] {sname}: {m.label} {'was shown a human-check page' if block else 'could not read it (' + why[:60] + ')'} - switched at once to {nxt.label}. "
                             f"{m.label[:1].upper() + m.label[1:]} sits out {_fmt_wait(cool)} and is brought back after that.", log)
        return True

    def maybe_rotate(self, log=None):
        """While this store has had trouble lately, the ready browsers take turns, so no single one is the only one asking."""
        if not self._pool:
            return False
        now = time.time()
        with self._plock:
            if now - self._rot_at < POOL_ROTATE_EVERY:
                return False
            self._rot_at = now
            if not any(now - m.last_fail_at < POOL_TROUBLE_WINDOW for m in self._members if m.last_fail_at):
                return False
            cur = self._cur
            c = self._ready(now, cur, max_prio=1) or self._ready(now, cur, max_prio=8)        # v48: take turns between Chrome and Edge; heavier browsers only if neither is ready
            if not c:
                return False
            nxt = min(c, key=lambda m: (m.last_used, m.prio))
        if nxt.inst is None:
            try:
                with self._plock:
                    nxt.inst = self._build(nxt)
            except Exception:
                nxt.cool_until, nxt.strikes = now + 600.0, nxt.strikes + 1
                return False
        back = nxt.was_cooling and nxt.strikes > 0
        nxt.was_cooling = False
        self._rot_logs += 1
        sname = _POOL_STORE_NAMES.get(self._store, self._store.title())
        txt = None
        if back or self._rot_logs <= 2 or self._rot_logs % 20 == 0:
            txt = f"[browser] {sname}: {'back from its rest - ' if back else ''}{nxt.label} takes its turn now (the browsers take turns while this store is giving trouble)."
        self._switch(cur, nxt, txt, log)
        return True

    def _open_instances(self):
        if not self._pool:
            return _LegacyBrowser._open_instances(self)
        with self._plock:
            return [m.inst for m in self._members if m.inst is not None]

    def report(self):
        now = time.time()
        with self._plock:
            return [{"label": m.label, "kind": m.kind, "current": m is self._cur, "ready": m.cool_until <= now, "rests_for": max(0, int(m.cool_until - now)),
                     "strikes": m.strikes, "ok": m.ok, "fail": m.fail, "last_why": m.last_why, "open": m.inst is not None} for m in self._members]

    # ---- the rest of what the checkers call
    def close(self):
        if not self._pool:
            return _LegacyBrowser.close(self)
        for m in list(self._members):
            try:
                if m.inst is not None:
                    m.inst.close()
            except Exception:
                pass

    def park(self):
        if not self._pool:
            return _LegacyBrowser.park(self)
        m = self._cur
        inst = m.inst if m is not None else None
        if inst is not None and hasattr(inst, "park"):
            try:
                return inst.park()
            except Exception:
                return False
        return False

    def recycle(self):
        if not self._pool:
            return _LegacyBrowser.recycle(self)
        for m in list(self._members):
            inst, m.inst = m.inst, None
            if inst is not None:
                try:
                    inst.close()
                except Exception:
                    pass
        self._instance = None


def pool_report():
    """For the diagnostics: every store's browsers, which one is in use, which are resting and why."""
    out = {}
    for k, lz in list(_POOLS.items()):
        try:
            out[k] = lz.report()
        except Exception:
            pass
    return out


# ---- v44: SCOUTS - several different browsers reading the same store AT THE SAME TIME ---------------------------------------------------
# The store's main checker (above) uses one browser at a time. For the stores that are read through a browser page (Walmart; Target only
# while its all-products request is not working) the program now also runs "scouts": other browsers (Edge, Camoufox, Firefox, Brave, Vivaldi,
# Opera - whichever are on the PC) that each keep reading the store's products over and over, starting at different products, so every
# product is looked at by several browsers within a few seconds and there is never a gap when one browser is resting or slow.
# A scout only WATCHES: when it sees a product IN STOCK that the main checker does not, it makes the main checker look at that product
# at once (the same "look now" the tracker alerts use). The main checker's own read is what is recorded and alerted, so a scout's
# half-loaded page can never create a false restock. A scout that is shown a "prove you are human" page rests for a long while (it never
# tries to get past it) and the others carry on. No proxies, no hidden address: the same PC, the same internet connection.
SCOUT_STORES = ()                # v50: the readers that work at the same time are now the store's own LANES (see below), which record what they read;
#                                  scouts are off unless asked for (RK_SCOUT_STORES=walmart,target)
SCOUT_GAP = 2.5                  # seconds a scout waits between its own reads (it reads one page after another)
SCOUT_MAX = 2                    # most scouts per store (RK_MAX_SCOUTS). v46: was 4 - together with the main checker that is 3 readers per store
SCOUT_POKE_HOT = 90.0            # seconds a product stays at full speed after a scout saw it in stock
SCOUT_POKE_GAP = 20.0            # a scout does not "look now" for the same product more often than this
_SCOUTS = {}                     # store -> [_Scout]
_SCOUT_LOCK = threading.Lock()
_SCOUT_NAMES = {"chrome": "Chrome", "msedge": "Edge", "brave": "Brave", "vivaldi": "Vivaldi", "opera": "Opera", "chromium": "Chromium",
                "chromium-browser": "Chromium", "google-chrome": "Chrome"}


def _exe_label(path):
    b = os.path.basename(path or "").lower().replace(".exe", "")
    return _SCOUT_NAMES.get(b, b.title() or "Chrome")


class _Scout:
    def __init__(self, store, kind, exe_idx, label, n):
        self.store, self.kind, self.exe_idx, self.label, self.n = store, kind, exe_idx, label, n
        self.key = f"{kind}:{exe_idx}"
        self.port = 9500 + 20 * (0 if store == "walmart" else 1) + n
        self.thread = None
        self.state = "starting"
        self.reads = 0
        self.errs = 0
        self.strikes = 0
        self.blocks = 0
        self.ok_streak = 0
        self.cool_until = 0.0
        self.last_read = 0.0
        self.last_why = ""
        self.sightings = 0
        self.retired_until = 0.0


def _scout_kinds():
    """-> [(kind, exe_idx, label)]: the browsers that can be scouts right now, most different from the main ones first."""
    try:
        cands = RealChromeFetcher.candidates() if RealChromeFetcher is not None else []
    except Exception:
        cands = []
    out = []
    if len(cands) >= 2:
        out.append(("chromium", 1, _exe_label(cands[1])))
    # v46: a second, ordinary-browser reader first (light); Camoufox next (it read Target well, but is a heavy browser);
    # the plain Firefox is not used as a reader any more (it used a lot of memory and could not read pages as a reader)
    for i in range(2, len(cands)):
        out.append(("chromium", i, _exe_label(cands[i])))
    try:
        if ENGINE_INSTALLS["camoufox"]["state"] == "ready":
            out.append(("camoufox", 0, "Camoufox"))
    except Exception:
        pass
    try:
        if StealthChromeFetcher is not None and stealth_ready():
            out.append(("stealth", 0, "Hidden Chrome"))         # v76
    except Exception:
        pass
    if not out and cands:
        out.append(("chromium", 0, _exe_label(cands[0])))      # only one ordinary browser on this PC: a second window with its own profile
    return out


def _scout_build(sc):
    s = sc.store
    if sc.kind == "chromium":
        f = RealChromeFetcher(profile_dir=f"browser_profile_{s}_scout{sc.n}", port=sc.port, store=s, block_media=True)
        f._exe_idx = sc.exe_idx
        return f
    if sc.kind == "camoufox":
        return CamoufoxFetcher(store=s)
    if sc.kind == "stealth":
        return StealthChromeFetcher(profile_dir=f"browser_profile_{s}_scout{sc.n}_stealth", store=s, block_media=True)
    return FirefoxFetcher(store=s)


def _scout_sleep(sec, stop_event):
    return _sleep_or_stop(sec, stop_event)


def _scout_run(sc, stop_event, log_fn):
    fetcher = None
    pick_i = sc.n * 2                    # each scout starts at a different product
    last_poke = {}
    seen_in = {}
    try:
        while stop_event is None or not stop_event.is_set():
            now = time.time()
            if os.environ.get("RK_NO_SCOUTS"):
                sc.state = "switched off"
                if _scout_sleep(5, stop_event):
                    return
                continue
            _ok, _why = hotness.scouts_may_run(sc.n)
            if hotness.all_scouts_rest():
                _ok, _why = False, "program memory is over the hard limit"
            if not _ok and not hotness.gaming():
                sc.state = f"resting ({_why})"
                if fetcher is not None:
                    try:
                        fetcher.close()
                    except Exception:
                        pass
                    fetcher = None
                if _scout_sleep(10, stop_event):
                    return
                continue
            if hotness.gaming():
                sc.state = "resting (gaming mode)"
                if fetcher is not None:
                    try:
                        fetcher.park()
                    except Exception:
                        pass
                if _scout_sleep(5, stop_event):
                    return
                continue
            if now < max(sc.cool_until, sc.retired_until):
                sc.state = f"resting {_fmt_wait(max(sc.cool_until, sc.retired_until) - now)} ({sc.last_why[:40]})"
                if _scout_sleep(1.0, stop_event):
                    return
                continue
            if sc.store == "target" and hotness.is_cheap("target"):
                sc.state = "not needed (Target's all-products request works)"
                if fetcher is not None:
                    try:
                        fetcher.close()
                    except Exception:
                        pass
                    fetcher = None
                if _scout_sleep(5, stop_event):
                    return
                continue
            live = [x for x in list(GROUPS.get(sc.store, [])) if not matrix.is_off(x)]
            if not live:
                sc.state = "nothing to watch"
                if _scout_sleep(3, stop_event):
                    return
                continue
            # the original products every time round; an added ("extra") product on every 4th turn
            core = [x for x in live if not products.is_extra(x)]
            extras = [x for x in live if products.is_extra(x)]
            pick_i += 1
            if extras and (pick_i % 16 == 0 or not core):         # v46: readers look at the original products; an added one only every 16th turn
                t = extras[(pick_i // 16) % len(extras)]
            else:
                t = core[pick_i % len(core)] if core else live[pick_i % len(live)]
            tid, url = t["id"], t["url"]
            try:
                if fetcher is None:
                    sc.state = "opening"
                    fetcher = _scout_build(sc)
                sc.state = "reading"
                text, err = fetcher.fetch(url, timeout=22.0)
            except Exception as e:
                text, err = None, f"{type(e).__name__}: {str(e)[:80]}"
            sc.last_read = time.time()
            if err or not (text and text.strip()):
                sc.errs += 1
                sc.strikes += 1
                sc.ok_streak = 0
                sc.last_why = str(err or "empty answer")[:80]
                sc.cool_until = time.time() + POOL_COOL[min(sc.strikes - 1, len(POOL_COOL) - 1)]
                if any(k in sc.last_why for k in LOCAL_NET_ERRORS):
                    sc.cool_until = time.time() + 20.0
                    sc.strikes = max(0, sc.strikes - 1)
                if getattr(fetcher, "start_failures", 0) >= 3:
                    sc.retired_until = time.time() + 1800.0
                    sc.last_why = "would not start"
                try:
                    fetcher.close()
                except Exception:
                    pass
                fetcher = None
                if sc.strikes in (1, 3, 5):
                    log_fn(f"[scout] {_POOL_STORE_NAMES.get(sc.store, sc.store)}: {sc.label} could not read a page ({sc.last_why}); it rests "
                           f"{_fmt_wait(sc.cool_until - time.time())} - the other browsers carry on.")
                continue
            why = human_check_reason(text)
            if why:
                sc.blocks += 1
                sc.strikes += 1
                sc.last_why = "human-check page"
                sc.cool_until = time.time() + min(1800.0, POOL_BLOCK_COOL * (2 ** (sc.blocks - 1)))
                log_fn(f"[scout] {_POOL_STORE_NAMES.get(sc.store, sc.store)}: {sc.label} was shown a 'prove you are human' page; it rests "
                       f"{_fmt_wait(sc.cool_until - time.time())} (not trying to get past it). The other browsers carry on.")
                try:
                    fetcher.close()
                except Exception:
                    pass
                fetcher = None
                continue
            sc.reads += 1
            sc.ok_streak += 1
            if sc.ok_streak >= 5 and sc.strikes:
                sc.strikes -= 1
                sc.ok_streak = 0
            sc.state = "reading"
            body = (_RENDERED + text) if sc.store == "target" else text
            try:
                st = detect_availability(body, hint=url)
            except Exception:
                st = "UNKNOWN"
            if st == "IN_STOCK":
                try:
                    pr = detect_price(body, url)
                except Exception:
                    pr = None
                persist = (_WD.get(sc.store) or {}).get("persist") or {}
                main_sees = (persist.get("last_status") or {}).get(tid)
                if main_sees != "IN_STOCK" and time.time() - last_poke.get(tid, 0) >= SCOUT_POKE_GAP:
                    last_poke[tid] = time.time()
                    sc.sightings += 1
                    hotness.mark(tid, SCOUT_POKE_HOT)
                    log_fn(f"[scout] {_POOL_STORE_NAMES.get(sc.store, sc.store)}: {sc.label} sees '{tid}' IN STOCK"
                           f"{' at $%.2f' % pr if pr else ''} - the main checker is looking at it right now.")
            gap = SCOUT_GAP                    # v50: never stretched because of CPU load
            wd_p = (_WD.get(sc.store) or {}).get("persist") or {}
            if any(v > time.time() for v in (wd_p.get("backoff_until") or {}).values()):
                gap *= 3.0            # the main checker is resting after a block: stay gentle, but keep the data coming
            if hotness.is_hot(tid):
                gap = min(gap, 1.0)
            if _scout_sleep(gap, stop_event):
                return
    finally:
        try:
            if fetcher is not None:
                fetcher.close()
        except Exception:
            pass
        sc.state = "stopped"


def _scout_manager(stores, stop_event, log_fn):
    """Starts a scout for each usable browser (and later ones as soon as they are installed), per store."""
    cap = int(os.environ.get("RK_MAX_SCOUTS", SCOUT_MAX))
    announced = set()
    while stop_event is None or not stop_event.is_set():
        if not os.environ.get("RK_NO_SCOUTS"):
            for store in stores:
                if not GROUPS.get(store):
                    continue
                with _SCOUT_LOCK:
                    lst = _SCOUTS.setdefault(store, [])
                    have = {sc.key for sc in lst}
                    for kind, idx, label in _scout_kinds():
                        if len(lst) >= cap:
                            break
                        if kind == "camoufox" and store == "walmart":
                            continue                      # v46: Walmart showed it a 'prove you are human' page every time - not worth a heavy browser
                        if f"{kind}:{idx}" in have:
                            continue
                        sc = _Scout(store, kind, idx, label, len(lst))
                        sc.thread = threading.Thread(target=_scout_run, args=(sc, stop_event, log_fn), daemon=True,
                                                     name=f"scout-{store}-{sc.key}")
                        lst.append(sc)
                        sc.thread.start()
                        if (store, sc.key) not in announced:
                            announced.add((store, sc.key))
                            log_fn(f"[scout] {_POOL_STORE_NAMES.get(store, store)}: {label} now reads the products too, at the same time as the main checker.")
        if _sleep_or_stop(15.0, stop_event):
            return


def scout_report():
    """For the diagnostics: every scout, what it is doing and how many reads it has made."""
    out = {}
    for store, lst in list(_SCOUTS.items()):
        out[store] = [{"label": sc.label, "kind": sc.kind, "state": sc.state, "reads": sc.reads, "errors": sc.errs,
                       "blocks": sc.blocks, "sightings": sc.sightings, "last_read_s_ago": (int(time.time() - sc.last_read) if sc.last_read else None),
                       "last_why": sc.last_why} for sc in lst]
    return out



# ---- v50: LANES - several readers at the same store, all working at the same time ---------------------------------------------------
# Until v49 a store's checker read ONE page at a time: with 30 products at a store, every product waited for the 29 pages read before it
# (each a full browser page load), so each product was looked at only every few minutes. Now each store has several readers ("lanes").
# Every lane is a complete checker with its OWN browser (its own process, its own saved profile, its own port; Chrome and Edge take turns),
# and they all work from the same list of products: whichever lane is free takes the product that has waited longest (a product a tracker
# just alerted for goes first), nobody else reads that product while it is being read, and page loads start at least LANE_STAGGER seconds
# apart. A product is still never looked at more often than its own interval (the 2 s of the table), so a single product page is not hit
# any harder - the store is simply covered N times sooner. What a lane reads is recorded exactly like the main checker's reads.
# What limits the number of lanes: the number of products at the store, and the PC's memory (about one extra lane per 3 GB of memory).
# It is NEVER slowed down because of CPU load. In Gaming mode, or when the PC has almost no free memory left, the extra lanes rest
# (their browsers are closed) and the store's main checker carries on alone.
LANES = {"walmart": 4, "amazon": 4, "gamestop": 4, "target": 3}      # readers per store (the main checker is one of them)
LANES_OTHER = 2                                                       # a store the owner added himself
LANES_ONE = ("bestbuy",)                                              # Best Buy: its products are read with one shared request, and it hangs up on more
LANE_START_GAP = 3.0             # seconds between the starts of one store's lanes
LANE_STAGGER = 1.0               # the longest spacing between two reads STARTING at one store; the real spacing is (how long a read takes) / (number of readers),
#                                  so the starts are spread evenly over a read instead of all happening together - and never slower than the readers can go
CLAIM_STALE = 150.0              # a product claimed by a lane for longer than this (a hung page) is given to another lane
GB_PER_EXTRA_LANE = 3.0          # memory budgeted for one extra reader (a browser and its pages)
FLICKER_WINDOW = 45.0            # a product that read IN STOCK a moment ago must read OUT twice before it counts as sold out (readers can disagree for a few seconds)
LANE_PRIORITY = ("walmart", "amazon", "gamestop", "target")
SWEEP_IDLE = 10.0                # v64: a product the sweeper answers for is looked at again after this long if no new answer came (a new answer: at once)
SWEEP_IDLE_CLOSE = 300.0         # v64: the main checker's own browser is closed after this long of only handing on the sweeper's answers
_LANE_PORT_BASE = {"target": 9700, "walmart": 9800}


def lane_port(store, lane):
    """The remote-control port of an extra reader's Chrome (its Edge uses this port + 5)."""
    return _LANE_PORT_BASE.get(store, 9900) + 10 * max(1, int(lane))


def _lane_wish(store, n_products):
    env = os.environ.get("RK_LANES", "").replace(" ", "")
    want = 1 if store in LANES_ONE else LANES.get(store, LANES_OTHER)
    if env:
        try:
            if env.isdigit():
                want = int(env) if store not in LANES_ONE else 1
            else:
                for part in env.split(","):
                    k, _, v = part.partition("=")
                    if k == store and v.isdigit():
                        want = int(v)
        except Exception:
            pass
    return max(1, min(want, max(1, n_products)))


def lane_plan(counts):
    """{store: number of products} -> {store: number of readers (lanes) it gets}. Every store gets its main checker; the extra readers
    are handed out one round at a time (walmart, amazon, gamestop, target first) while the PC's memory allows."""
    wish = {s_: _lane_wish(s_, n) for s_, n in counts.items()}
    plan = {s_: 1 for s_ in wish}
    ram = None
    try:
        import cpu_monitor
        ram = cpu_monitor.ram_gb()
    except Exception:
        ram = None
    budget = int(ram / GB_PER_EXTRA_LANE) if ram else 10 ** 6
    order = sorted(wish, key=lambda s_: (LANE_PRIORITY.index(s_) if s_ in LANE_PRIORITY else len(LANE_PRIORITY), s_))
    for rnd in range(2, max(wish.values() or [1]) + 1):
        for s_ in order:
            if wish[s_] >= rnd and budget > 0:
                plan[s_] = rnd
                budget -= 1
    return plan


def _lane_guarded(targets, out_path, stop_event, log_fn, report, persist, lane):
    """Keeps one extra reader alive (like _guarded does for the main checker)."""
    errors_in_a_row = 0
    while stop_event is None or not stop_event.is_set():
        t_begin = time.time()
        try:
            _run_one(targets, out_path, stop_event, log_fn, report, persist, lane=lane)
            return              # stopped, or a fresh reader took this place over
        except Exception as e:
            errors_in_a_row = errors_in_a_row + 1 if time.time() - t_begin < 120 else 1
            wait = min(60, 5 * errors_in_a_row)
            log_fn(f"[error] reader {lane + 1} for store '{_store_key(targets[0]['url'])}' hit {type(e).__name__}: {str(e)[:200]} - restarting in {wait}s")
            if _sleep_or_stop(wait, stop_event):
                return


def _lane_manager(store, group, persist, out_path, stop_event, log_fn, report):
    """Starts the store's extra readers one after the other (so their first page loads are staggered), keeps them alive, and replaces one that
    got stuck. How many there are is decided by lane_plan (products at the store, memory)."""
    threads = {}
    announced = False
    while stop_event is None or not stop_event.is_set():
        if not persist.get("ready"):
            if _sleep_or_stop(0.5, stop_event):
                return
            continue
        counts = {}
        for st_, g_ in list(GROUPS.items()):
            counts[st_] = len([x for x in list(g_) if not matrix.is_off(x)])
        _plan = lane_plan(counts)
        want = _plan.get(store, 1)
        try:
            _need = sweep.lanes_needed(store, [x for x in list(group) if not matrix.is_off(x)])
            if _need is not None:
                want = max(1, min(want, _need))     # v64: the sweeper reads this store's products: the other readers only fill in
        except Exception:
            pass
        persist["lanes_want"] = want
        try:
            import loadplan
            loadplan.set_wishes(_plan, mains=len([c for c in counts.values() if c]))      # v51: the owner's speed setting decides how many of the extra readers have room
            loadplan.tick(active_readers())
        except Exception:
            pass
        started_one = False
        for lane in range(1, want):
            th = threads.get(lane)
            wdl = (_WD.get(store, {}).get("lanes") or {}).get(lane) or {}
            stuck = bool(th and th.is_alive() and wdl.get("beat") and time.time() - wdl["beat"] > WD_STALE + 60)
            if th is None or not th.is_alive() or stuck:
                if stuck:
                    log_fn(f"[watchdog] reader {lane + 1} of '{store}' has not moved for {time.time() - wdl['beat']:.0f}s - starting a fresh one.")
                    persist.setdefault("lane_owner", {})[lane] = None
                th = threading.Thread(target=_lane_guarded, args=(group, out_path, stop_event, log_fn, report, persist, lane),
                                      daemon=True, name=f"poll-{store}-lane{lane + 1}")
                threads[lane] = th
                persist.setdefault("lane_threads", {})[lane] = th
                th.start()
                started_one = True
                if not announced:
                    announced = True
                    log_fn(f"[readers] {_POOL_STORE_NAMES.get(store, store.title())}: {want} readers in all - each with its own browser - read the "
                           f"products at the same time (staggered), instead of one page after another.")
                if _sleep_or_stop(LANE_START_GAP, stop_event):
                    return
        if _sleep_or_stop(1.0 if started_one else 2.0, stop_event):
            return


def active_readers():
    """v51: how many readers (a main checker + extra readers) are reading right now, all stores together."""
    n, now = 0, time.time()
    for store, wd in list(_WD.items()):
        p = wd.get("persist") or {}
        if not p.get("ready"):
            continue
        n += 1
        for ln, d in list((wd.get("lanes") or {}).items()):
            st = str(d.get("state", ""))
            if st and not st.startswith(("resting", "starting", "not needed")) and now - (d.get("beat") or 0) < 90:
                n += 1
    return n


def speed_report():
    """v51: per store, how often a product is really looked at when ALL of the store's readers are counted together (this is what
    decides how long a restock can go unnoticed). delay = half the time between two looks + the time a look takes."""
    out = {}
    for store, wd in list(_WD.items()):
        p = wd.get("persist") or {}
        gaps = p.get("gap_ema") or {}
        live = [x for x in list(GROUPS.get(store, [])) if not matrix.is_off(x)]
        vals = [gaps[x["id"]] for x in live if gaps.get(x["id"], 0) > 0]
        if not live:
            continue
        readers = 1
        for ln, d in list((wd.get("lanes") or {}).items()):
            st = str(d.get("state", ""))
            if st and not st.startswith(("resting", "starting", "not needed")) and time.time() - (d.get("beat") or 0) < 90:
                readers += 1
        rd = float(p.get("read_ema", 0.0) or 0.0)
        _swst = sweep.state(store)
        if _swst == "ok":
            try:
                _rr = sweep.store_report(store) or {}
                rd = float(_rr.get("round_s") or rd)       # v64: the store is read by its sweeper - one look = one sweeper round
                readers = 1
            except Exception:
                pass
        avg = (sum(vals) / len(vals)) if vals else None
        worst = max(vals) if vals else None
        out[store] = {"products": len(live), "measured": len(vals), "readers": readers, "avg_gap": avg, "worst_gap": worst, "read_s": rd,
                      "delay": None if avg is None else avg / 2.0 + min(rd, avg),
                      "per_product": None if avg is None else avg / max(1, len(live)),
                      "batched": int(p.get("batch_reads", 0)),
                      "round_s": p.get("cyc_ema"), "pre_s": p.get("pre_ema"), "fetch_s": p.get("fetch_ema"), "sweep": _swst}
    return out


def speed_overall(rep=None):
    """-> average time (seconds) until a restock would be noticed by our own readers, over all products; None when not measured yet."""
    rep = rep if rep is not None else speed_report()
    num = den = 0.0
    for v in rep.values():
        if v.get("delay") is not None and v.get("measured"):
            num += v["delay"] * v["measured"]
            den += v["measured"]
    return (num / den) if den else None


def lane_report():
    """For the diagnostics: per store, how many readers there should be, which are running and how much each has read."""
    out = {}
    for store, wd in list(_WD.items()):
        p = wd.get("persist") or {}
        lanes = {0: {"beat": wd.get("beat"), "reads": (p.get("lane_reads") or {}).get(0, 0)}}
        for ln, d in (wd.get("lanes") or {}).items():
            lanes[ln] = {"beat": d.get("beat"), "reads": (p.get("lane_reads") or {}).get(ln, 0), "state": d.get("state", "")}
        lanes[0]["state"] = wd.get("state", "")
        out[store] = {"want": p.get("lanes_want", 1), "lanes": lanes, "batched": int(p.get("batch_reads", 0))}
    return out


# A browser that has been open for hours keeps growing (measured: about +0.5 GB per hour over all stores). These stores get a
# brand-new browser every few hours, at a quiet moment (never while a product is in stock), staggered so only one store
# is ever restarting at a time. The first checks after a restart take a few seconds longer than usual.
RECYCLE_STORES = ("amazon", "gamestop", "walmart")
_RELIEF = {"last": {}, "n": 0, "said": 0.0}          # v46: when each store's browser was last restarted early because the program's memory was high


def _memory_relief(log_fn, now=None):
    """v50: only when the WHOLE PC is running short of memory (under MEM_RELIEF_GB free): one store's browser at a time is restarted early (the same
    quiet restart as the 3-hourly one: never while something is in stock), at most one per 5 minutes. -> the store asked to restart, or None.
    (v46-v49 also did this whenever the program itself held more than 12-16 GB - that limit is gone.)"""
    now = now or time.time()
    try:
        import cpu_monitor
        gb = cpu_monitor.mine_gb(2)
        free = cpu_monitor.pc_free_gb(2)
    except Exception:
        gb, free = None, None
    if free is None or free >= hotness.MEM_RELIEF_GB:
        return None
    if now - max(_RELIEF["last"].values() or [0.0]) < 300.0:
        return None
    cands = [st for st in RECYCLE_STORES if _WD.get(st) and not (_WD[st].get("persist") or {}).get("owner") is None]
    if not cands:
        return None
    store = min(cands, key=lambda st: _RELIEF["last"].get(st, 0.0))
    _RELIEF["last"][store] = now
    _RELIEF["n"] += 1
    _WD[store]["recycle_now"] = True
    if now - _RELIEF["said"] > 600:
        _RELIEF["said"] = now
        log_fn(f"[memory] the PC has only {free:.1f} GB of free memory (this program holds {gb if gb is not None else 0:.1f} GB): "
               f"{store}'s browser is being restarted early, and the extra readers rest while memory is this low.")
    return store
RECYCLE_FIRST = {"amazon": 5400.0, "gamestop": 7200.0, "walmart": 9000.0}     # seconds after start: 1.5 h, 2 h, 2.5 h
RECYCLE_EVERY = 10800.0                                                        # then every 3 h

# Switching to another browser opens a new browser window, so it is rationed: at most this many switches per product per 3 hours.
ROTATE_MAX = 3
ROTATE_WINDOW = 10800.0
LOCAL_NET_ERRORS = ("ERR_NAME_NOT_RESOLVED", "ERR_INTERNET_DISCONNECTED", "ERR_NETWORK_CHANGED", "ERR_PROXY_CONNECTION_FAILED")


# ---- lighter checks for stores whose page already carries the stock in what the store sends ----
# A full page load makes the browser run all of the store's scripts, which is what loads the PC.
# Once one real page is open, the product page is asked for again from inside that tab (same
# cookies, nothing drawn, no scripts run). This is trusted only after it has agreed with the full
# page, is re-compared every few minutes, and any possible restock is double-checked with a full
# page. Anything odd and the program goes straight back to full pages by itself.
LIGHT_STORES = ("amazon", "gamestop", "walmart")
LIGHT_VERIFY_EVERY = 60.0    # seconds between full-page comparisons (per product)
PARK_MIN_GAP = 6.0           # when the next look at this store is at least this far away, its tab rests on a plain page meanwhile
EXTRA_VERIFY_EVERY = 300.0   # the same for an added "extra" product (looked at rarely, so a full page every look would cost more than it saves)
LIGHT_MIN_OK = 3             # agreements needed before the lighter way is used
EXTRA_MIN_OK = 1             # the same for an added "extra" product (it is looked at rarely, so three comparisons would take minutes of double work)
LIGHT_OFF_FILE = "light_off2.txt"   # stores where the lighter check once MISSED an in-stock moment
LIGHT_STRIKES_OFF = 3        # unusable light answers in a row before pausing it
LIGHT_OFF_SECS = 900.0
LIGHT_MISS_OFF = 1800.0      # after the lighter check missed an in-stock moment: full pages for this product
LIGHT_MISSES_FOREVER = 3     # ... and after this many misses, off for the whole store until the line in the file is deleted
BB_NOSKU_EVERY = 90.0         # v46: seconds between looks at a Best Buy link that has no product number (only the whole page can be read)
TARGET_PAGES_EVERY = 0.0     # v50: was 15 s between whole-page Target looks while no small request works - nobody asked for that slowdown
LIGHT_BAD_OFF = 3600.0       # after repeated disagreement with the full page
PREFETCH_N = int(os.environ.get("RK_PREFETCH", "5") or 5)      # v51: one reader asks for up to this many product pages AT ONCE from its open tab (1 = one at a time)


def _light_off_stores():
    try:
        with open(LIGHT_OFF_FILE, encoding="utf-8") as f:
            return {ln.split("#")[0].strip().lower() for ln in f if ln.split("#")[0].strip()}
    except Exception:
        return set()


def _light_disable_store(store):
    try:
        if store not in _light_off_stores():
            with open(LIGHT_OFF_FILE, "a", encoding="utf-8") as f:
                f.write(f"{store}   # the lighter check missed an in-stock moment here; delete this line to try it again\n")
    except Exception:
        pass


def _light_state(store=""):
    off = float("inf") if store and store in _light_off_stores() else 0.0
    return {"ok": 0, "strikes": 0, "bad_verify": 0, "off_until": off, "last_verify": 0.0,
            "conf_price": None, "n_light": 0, "n_full": 0, "said_on": False}


def _light_verdict(text, url):
    try:
        st = detect_availability(text, hint=url)
        pr = detect_price(text, url) if st == "IN_STOCK" else None
    except Exception:
        return "UNKNOWN", None
    return st, pr


def _light_bad(text):
    try:
        return (not text) or len(text) < 3000 or is_human_check_page(text)
    except Exception:
        return True


def _same_price(a, b, mx=None):
    if a is None or b is None or abs(a - b) < 0.005:
        return True
    # two different prices that are BOTH above the price limit are the same thing to us:
    # either way the item does not count as restocked
    return bool(mx) and a > mx and b > mx


def _tab_on_store(bf, url):
    """True when the browser's open tab is on the store's own site (or when the browser object does not say, as in older fakes)."""
    if not hasattr(bf, "_page"):
        return True
    try:
        page = bf._page
        if page is None:
            return False
        m = re.match(r"https?://[^/]+", url)
        origin = m.group(0).lower() if m else ""
        return bool(origin) and (page.url or "").lower().startswith(origin)
    except Exception:
        return False


def product_gap(x):
    """v51: the fewest seconds between two looks at this product (all of a store's readers together): the table's own number for the product,
    lowered to the speed level's floor (loadplan.PRODUCT_GAP) when that is smaller. Best Buy keeps its own pace."""
    base = float(x.get("interval_sec", 2) or 2)
    try:
        import loadplan
        lim = loadplan.product_gap()
    except Exception:
        lim = None
    if lim is not None and base > lim and _store_key(x.get("url") or "") != "bestbuy":
        return lim
    return base


def _light_ready(t, L, now):
    """v51: would _smart_read answer a look at this product with the lighter read (no full page needed first)?"""
    if not L:
        return False
    _mn = EXTRA_MIN_OK if products.is_extra(t) else LIGHT_MIN_OK
    _ve = EXTRA_VERIFY_EVERY if products.is_extra(t) else LIGHT_VERIFY_EVERY
    return L.get("ok", 0) >= _mn and now >= L.get("off_until", 0.0) and (now - L.get("last_verify", 0.0)) <= _ve * 0.85


def _engine_kind(browser):
    """Which kind of browser (chrome / edge / camoufox / firefox / builtin ...) this reader is using right now."""
    try:
        c = getattr(browser, "_cur", None)
        if c is not None and getattr(c, "kind", None):
            return c.kind
        inst = getattr(browser, "_instance", None)
        return str(getattr(inst, "engine", None) or type(inst).__name__)
    except Exception:
        return "?"


def _pb_block(persist, tid, lane, kind, until):
    """v52 (item 7): remembers, per product, which readers (and which kind of browser) were shown a human-check page and when each will look again.
    A product that is blocked for EVERY reader is only looked at on those probe times (slow), which also frees the PC for the products that read fine."""
    pb = persist.setdefault("pb", {})
    e = pb.setdefault(tid, {"lanes": {}, "n": 0, "since": time.time(), "good": None, "last_ok": 0.0})
    e["n"] += 1
    e["lanes"][lane] = {"until": until, "engine": kind, "n": e["lanes"].get(lane, {}).get("n", 0) + 1, "at": time.time()}


def _pb_ok(persist, tid, lane, kind):
    """A good read: this reader is no longer blocked for the product; the kind of browser that read it is remembered as one that works."""
    pb = persist.get("pb")
    e = pb.get(tid) if pb else None
    if not e:
        return
    e["last_ok"] = time.time()
    e["good"] = kind
    if e["lanes"].pop(lane, None) is not None and not e["lanes"]:
        pb.pop(tid, None)


def blocked_report(persist_by_store=None):
    """-> list of {store, product, readers_blocked, readers, probe_in, engines, good} for the page and the diagnostics."""
    out = []
    now = time.time()
    for store, wd in list(_WD.items()):
        pe = (wd or {}).get("persist") or {}
        pb = pe.get("pb") or {}
        want = max(1, pe.get("lanes_want", 1))
        for tid, e in list(pb.items()):
            live = {ln: v for ln, v in e["lanes"].items() if v["until"] > now}
            if not live:
                continue
            out.append({"store": store, "product": tid, "readers_blocked": len(live), "readers": want,
                        "everywhere": len(live) >= want, "probe_in": max(0, int(min(v["until"] for v in live.values()) - now)),
                        "engines": sorted({v["engine"] for v in live.values()}), "good": e.get("good"), "times": e["n"]})
    out.sort(key=lambda r: (-int(r["everywhere"]), r["store"], r["product"]))
    return out


def blocked_text():
    rep = blocked_report()
    if not rep:
        return "No product is being held back from any reader because of a human-check page right now."
    lines = [f"{len(rep)} product(s) were shown a human-check page; the readers affected leave them alone and look again on a slowing schedule "
             f"(2, 5, 10, 15, 20, 30 min); the other readers keep reading them:"]
    for r in rep[:25]:
        lines.append(f"  {r['store']}/{r['product']}: {r['readers_blocked']} of {r['readers']} readers held back ({'ALL - the product is only probed' if r['everywhere'] else 'the rest keep reading it'}); "
                     f"next look in {r['probe_in']} s; browsers blocked: {', '.join(r['engines'])}; browser that last worked: {r['good'] or '-'}; shown {r['times']}x")
    return "\n".join(lines)


VERIFY_TIMES = {}      # v52: store -> the last confirmation times (seconds from "the lighter check saw it in stock" to "a full page agrees")


def _verify_note(store, secs):
    d = VERIFY_TIMES.setdefault(store, collections.deque(maxlen=60))
    d.append(float(secs))


def _confirms(html, url, price, mx):
    """v52: does this (maybe still loading) page already show the same in-stock price the lighter check saw?"""
    s, p = _light_verdict(html, url)
    return s == "IN_STOCK" and p is not None and _same_price(p, price, mx)


def _smart_read(t, browser, L, log_fn):
    """Returns (text, err, read_ts). read_ts is set when a lighter read first saw the item in
    stock and a full page then confirmed it (the moment it was seen is the earlier one)."""
    url, tid = t["url"], t["id"]
    bf = browser.get()
    if (os.environ.get("RK_NO_LIGHT") or _store_key(url) not in LIGHT_STORES
            or not hasattr(bf, "light_get")):
        L["n_full"] += 1
        text, err = bf.fetch(url)
        return text, err, None
    now = time.time()
    if now < L["off_until"]:
        L["n_full"] += 1
        text, err = bf.fetch(url)
        return text, err, None
    if not _tab_on_store(bf, url):
        # v50: this reader's browser has not opened a page of the store yet (a new reader, or a browser that was just switched / restarted):
        # the lighter way needs an open store page, so this look is a full page - and it does not count against the product's light check
        L["n_full"] += 1
        text, err = bf.fetch(url)
        return text, err, None

    def full(ready=None):
        L["n_full"] += 1
        if ready is not None and getattr(bf, "supports_ready", False):
            return bf.fetch(url, ready=ready)          # v52: handed back the moment the page shows the in-stock price (see browser_fetch._wait_ready)
        return bf.fetch(url)

    _verify_every = EXTRA_VERIFY_EVERY if products.is_extra(t) else LIGHT_VERIFY_EVERY
    _min_ok = EXTRA_MIN_OK if products.is_extra(t) else LIGHT_MIN_OK
    if L["ok"] < _min_ok or now - L["last_verify"] > _verify_every:
        # compare the lighter way with the full page (the full page is what is used for this check).
        # A mismatch is tried once more at once: two reads a moment apart can honestly differ when the
        # store changes in between.
        ftext = None
        for attempt in (1, 2):
            ftext, ferr = full()
            if ferr or not ftext:
                return ftext, ferr, None
            L["last_verify"] = time.time()
            fs, fp = _light_verdict(ftext, url)
            if fs == "OUT_OF_STOCK":
                L["last_full_out"] = L["last_verify"]      # a time when a FULL page was known to read out of stock
            L["conf_price"] = fp if (fs == "IN_STOCK" and fp is not None) else None
            if fs == "UNKNOWN":
                return ftext, None, None        # nothing to compare against right now
            ltext, lerr = bf.light_get(url)
            why, missed = None, False
            if lerr or _light_bad(ltext):
                why = f"no usable answer ({lerr or 'blank or challenge page'})"
            else:
                ls, lp = _light_verdict(ltext, url)
                if ls != fs or not _same_price(fp, lp, t.get("max_price")):
                    why = f"read {ls} (${lp}) while the full page read {fs} (${fp})"
                missed = (fs == "IN_STOCK" and ls == "OUT_OF_STOCK")
            if why is None or attempt == 2 or (lerr and not ltext and attempt == 1 and "HTTP" in str(lerr)):
                break
        if missed:
            # the dangerous case: the store's page says in stock but the lighter check was blind to it
            store = _store_key(url)
            L["misses"] = L.get("misses", 0) + 1
            if L["misses"] >= LIGHT_MISSES_FOREVER:
                _light_disable_store(store)          # keeps happening: off for good (until the line is deleted)
                L["off_until"] = float("inf")
            else:
                L["off_until"] = time.time() + LIGHT_MISS_OFF      # a pause for this product, then try again
            L["ok"], L["said_on"] = 0, False
            # the lighter "out of stock" reads since the last full-page OUT were wrong, so the
            # timing window must start there, not at the last lighter read
            L["wipe_to"] = L.get("last_full_out") or (time.time() - 600.0)
            _how = ("for good" if L["misses"] >= LIGHT_MISSES_FOREVER else f"for {int(LIGHT_MISS_OFF // 60)} min")
            log_fn(f"[light] '{tid}': WARNING - the lighter check missed an in-stock moment that the full page "
                   f"saw (time #{L['misses']}). Full pages only for this product {_how}. This restock is "
                   f"recorded from the full page, so its timing window is wider than usual.")
            return ftext, None, None
        if why is None:
            L["ok"] += 1
            L["bad_verify"] = 0
            if L["ok"] >= _min_ok and not L["said_on"]:
                L["said_on"] = True
                log_fn(f"[light] '{tid}': the lighter check agrees with the full page - using it from now on "
                       f"(a full page is still read every {int(_verify_every)} s to compare).")
        else:
            L["ok"] = 0
            L["bad_verify"] += 1
            if L["bad_verify"] in (1, 2):
                log_fn(f"[light] '{tid}': the lighter check did not match the full page - {why}.")
            if L["bad_verify"] >= 2:
                L["off_until"] = time.time() + LIGHT_BAD_OFF
                L["bad_verify"] = 0
                L["said_on"] = False
                log_fn(f"[light] '{tid}': going back to full pages for {int(LIGHT_BAD_OFF // 60)} min, then trying again.")
        return ftext, None, None

    ltext, lerr = bf.light_get(url)
    t_ans = time.time()
    verdict = ("UNKNOWN", None)
    if not lerr and not _light_bad(ltext):
        verdict = _light_verdict(ltext, url)
    st, pr = verdict
    if st == "UNKNOWN":
        L["strikes"] += 1
        if L["strikes"] >= LIGHT_STRIKES_OFF:
            L["strikes"] = 0
            L["off_until"] = time.time() + LIGHT_OFF_SECS
            L["ok"] = 0
            L["said_on"] = False
            log_fn(f"[light] '{tid}': the lighter check gave no usable answer {LIGHT_STRIKES_OFF} times in a row "
                   f"({lerr or 'unreadable'}) - full pages for {int(LIGHT_OFF_SECS // 60)} min.")
        L["conf_price"] = None
        text, err = full()
        return text, err, None
    L["strikes"] = 0
    _mx = t.get("max_price")
    if st == "IN_STOCK" and pr is not None and L["conf_price"] != pr and not (_mx and pr > _mx):
        # a possible restock: have a full page confirm it before it is believed - v52: AT ONCE (the full page is asked for the instant the
        # lighter check sees it, and it is accepted the moment it shows the same in-stock price - it is not waited for until it has finished
        # loading, which used to add 1.5-2 s to every confirmation)
        _vt0 = time.time()
        ftext, ferr = full(ready=lambda h: _confirms(h, url, pr, _mx))
        _vdur = time.time() - _vt0
        if ferr or not ftext:
            L["conf_price"] = pr            # the full page would not load: trust the lighter read
            L["n_light"] += 1
            return ltext, None, t_ans
        fs, fp = _light_verdict(ftext, url)
        if fs == "IN_STOCK" and fp is not None and _same_price(fp, pr, _mx):
            L["conf_price"] = pr
            _verify_note(_store_key(url), _vdur)
            log_fn(f"[light] '{tid}': in stock at ${pr:.2f} seen by the lighter check and confirmed by a full page in {_vdur:.1f} s.")
            return ftext, None, t_ans
        L["ok"] = 0                          # the two disagreed: compare again before trusting the light way
        L["conf_price"] = None
        log_fn(f"[light] '{tid}': the lighter check said in stock (${pr}) but the full page read {fs} (${fp}) - "
               f"using the full page and re-comparing.")
        return ftext, None, None
    if not (st == "IN_STOCK" and pr is not None):
        L["conf_price"] = None
    L["n_light"] += 1
    return ltext, None, t_ans


VERSION = "v104"   # shown in the log so it is obvious which copy of this file is running
_CSV_LOCK = threading.Lock()
CSV_HEADER = ["timestamp_utc", "target_id", "event", "url", "window_start_utc", "window_sec", "price"]


def _ensure_csv(out_path):
    """Create ground_truth.csv with the current columns. The previous
    6-column file is upgraded in place (nothing is lost); any other layout
    is kept aside (renamed), never overwritten."""
    if os.path.exists(out_path):
        try:
            with open(out_path, newline="", encoding="utf-8", errors="replace") as f:
                rows = list(csv.reader(f))
        except Exception:
            rows = []
        first = rows[0] if rows else []
        if first == CSV_HEADER:
            return
        if first == CSV_HEADER[:-1]:
            with open(out_path, "w", newline="", encoding="utf-8") as f:
                w = csv.writer(f)
                w.writerow(CSV_HEADER)
                for r in rows[1:]:
                    w.writerow(r + [""] * (len(CSV_HEADER) - len(r)))
            return
        os.replace(out_path, out_path.replace(".csv", "") + "_old_" +
                   datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S") + ".csv")
    with open(out_path, "w", newline="", encoding="utf-8") as f:
        csv.writer(f).writerow(CSV_HEADER)



# ---- watchdog: a store whose checker stops moving (a hung page or browser) is restarted by itself ----
# In diagnostics #24 the Amazon and Target checkers stopped for 9 hours while the other stores kept going. Nothing in
# the program noticed, because the program was waiting for the browser to answer and the browser never did.
WD_STALE = 300.0          # seconds a store's checker may go without starting a new round before it counts as stuck
WD_REPLACE_AFTER = 90.0   # ... if closing its browser did not free it, a fresh checker is started this much later
_WD = {}                  # store -> {"beat": time of last round, "browser": its _LazyBrowser, "owner": thread id, ...}


def kill_store_browsers(store):
    """Ends every browser this program started for one store (they carry a --rk-store=<store> mark).
    Whatever the checker was waiting for then fails at once instead of never. Returns how many were ended."""
    n = 0
    try:
        import psutil
    except Exception:
        psutil = None
    if psutil is None:
        return 0
    mark = f"--rk-store={store}"
    for p in psutil.process_iter(["pid", "cmdline"]):
        try:
            cl = p.info.get("cmdline") or []
            if mark in cl:
                for c in p.children(recursive=True):
                    try:
                        c.kill()
                    except Exception:
                        pass
                p.kill()
                n += 1
        except Exception:
            continue
    return n


def _watchdog_check(groups, threads, out_path, stop_event, log_fn, report, now=None):
    now = now or time.time()
    for store, group in groups.items():
        wd = _WD.get(store)
        if not wd:
            continue
        idle = now - wd["beat"]
        if idle < WD_STALE:
            wd.pop("stage", None)
            continue
        stage = wd.get("stage", 0)
        if stage == 0:
            n = 0
            try:
                n = kill_store_browsers(store)
            except Exception:
                pass
            wd["stage"], wd["stage_at"] = 1, now
            wd["count"] = wd.get("count", 0) + 1
            log_fn(f"[watchdog] the '{store}' checker has not started a new check for {idle:.0f}s (a page or its browser is "
                   f"stuck). Ended its browser ({n} process(es)) so it can restart on its own. (time #{wd['count']})")
        elif stage == 1 and now - wd["stage_at"] > WD_REPLACE_AFTER:
            wd["stage"], wd["stage_at"] = 2, now
            log_fn(f"[watchdog] the '{store}' checker is still stuck after its browser was ended - starting a fresh checker for it.")
            th = threading.Thread(target=_guarded, args=(group, out_path, stop_event, log_fn, report, wd.get("persist")),
                                  daemon=True, name=f"poll-{store}-2")
            wd["beat"] = now
            th.start()
            threads.append(th)
        elif stage == 2 and now - wd["stage_at"] > WD_STALE:
            wd["stage"] = 0


def run(targets, out_path, stop_event=None, log_fn=print, report=None):
    """Polls every target in its OWN thread, so one slow or blocked site
    (a browser load can take many seconds) can never delay the checks on
    the others — each store is watched at its own steady pace."""
    _ensure_csv(out_path)
    flush_pending_csv(out_path)
    groups = {}
    targets = [t for t in targets if _store_key(t.get("url") or "") != "tcgplayer"]      # v46: TCGplayer links are a price index (tcg_index.py), not a shop to watch
    for t in targets:
        groups.setdefault(_store_key(t["url"]), []).append(t)
    GROUPS.clear()
    GROUPS.update(groups)
    log_fn(f"[version] checker {VERSION}: polling {len(targets)} target(s) at {len(groups)} store(s) "
           f"({', '.join(f'{k}:{len(v)}' for k, v in groups.items())}); each store has a main checker plus extra readers, each with its own browser, "
           f"reading at the same time: {', '.join(f'{k}:{v}' for k, v in lane_plan({k: len(g) for k, g in groups.items()}).items())}.")
    threads = []
    lane_threads = []
    try:
        sweep.start(list(groups), stop_event, log_fn)       # v64: one light, paced reader per store (sweep.py) - before the readers start
    except Exception as e:
        log_fn(f"[warn] the store sweepers could not start ({type(e).__name__}: {str(e)[:120]}) - reading as before.")
    for store, group in groups.items():
        _persist = {}
        sweep.attach(store, _persist)            # v64: the store's sweeper hands its answers to this store's main checker at once
        th = threading.Thread(target=_guarded, args=(group, out_path, stop_event, log_fn, report, _persist),
                              daemon=True, name=f"poll-{store}")
        th.start()
        threads.append(th)
        if not os.environ.get("RK_NO_LANES"):
            lth = threading.Thread(target=_lane_manager, args=(store, group, _persist, out_path, stop_event, log_fn, report),
                                   daemon=True, name=f"lanes-{store}")
            lth.start()
            lane_threads.append(lth)
    scout_threads = []
    with _SCOUT_LOCK:
        _SCOUTS.clear()
    _sstores = [x for x in (os.environ.get("RK_SCOUT_STORES", ",".join(SCOUT_STORES)).replace(" ", "").split(",")) if x in groups]
    if _sstores and not os.environ.get("RK_NO_SCOUTS"):
        _sth = threading.Thread(target=_scout_manager, args=(_sstores, stop_event, log_fn), daemon=True, name="scouts")
        _sth.start()
        scout_threads.append(_sth)
    try:
        next_wd = time.time() + 15
        last_tick = time.time()
        while any(th.is_alive() for th in threads):
            if stop_event is not None and stop_event.is_set():
                break
            time.sleep(0.5)
            now_t = time.time()
            if now_t - last_tick > 60:
                # this whole program was paused (the PC slept): that is not a stuck store, so start counting afresh
                for _w in _WD.values():
                    _w["beat"] = now_t
                    _w.pop("stage", None)
            last_tick = now_t
            if time.time() >= next_wd:
                next_wd = time.time() + 15
                try:
                    _watchdog_check(groups, threads, out_path, stop_event, log_fn, report)
                except Exception as e:
                    log_fn(f"[warn] watchdog problem: {type(e).__name__}: {str(e)[:100]}")
                try:
                    _memory_relief(log_fn)
                except Exception as e:
                    log_fn(f"[warn] memory guard problem: {type(e).__name__}: {str(e)[:100]}")
        for th in threads:
            th.join(timeout=30)
        for th in lane_threads + scout_threads + [sc.thread for lst in list(_SCOUTS.values()) for sc in lst if sc.thread]:
            th.join(timeout=10)
        for _wd in list(_WD.values()):
            for _th in list(((_wd.get("persist") or {}).get("lane_threads") or {}).values()):
                _th.join(timeout=10)
    except KeyboardInterrupt:
        if stop_event is not None:
            stop_event.set()
        log_fn("Stopped.")


_TGT = {"tmpl": None, "fails": 0, "retry_at": 0.0, "said": False, "mode": None}
_RENDERED = "<!--rk-rendered-->"


def _tgt_api_url(tcin):
    return re.sub(r"tcin=\d+", f"tcin={tcin}", _TGT["tmpl"])


def _target_discover(url, browser, log_fn):
    """Target's own page asks Target's product-data service for the item's
    stock. Load the page once in a real browser, note the exact request it
    makes (address, key and settings included), and then repeat that same
    small request directly - fast and light - for every Target product."""
    bf = browser.get()
    bf.capture = "target.com"
    html, err = bf.fetch(url)
    if not err:
        # Target fills in the stock only once the page is "looked at": scroll a little and
        # give it a few seconds, then read which requests the page made.
        try:
            page = getattr(bf, "_page", None)
            if page is not None:
                page.evaluate("window.scrollTo(0, Math.max(600, document.body.scrollHeight / 3))")
                page.wait_for_timeout(3500)
                page.evaluate("window.scrollTo(0, 0)")
                page.wait_for_timeout(500)
        except Exception:
            pass
    urls = list(getattr(bf, "captured", []))
    bf.capture = None
    interesting = [u for u in urls if re.search(r"redsky|/api/|fulfillment|pdp_|availability", u)]
    pick = ([u for u in interesting if "pdp_client_v1" in u and "redsky" in u]
            or [u for u in interesting if "fulfillment" in u and "redsky" in u])
    if not pick:
        seen = []
        for u in interesting:
            short = re.sub(r"\?.*", "", u)[:90]
            if short not in seen:
                seen.append(short)
        _TGT["disc_fails"] = _TGT.get("disc_fails", 0) + 1
        if _TGT["disc_fails"] <= 3:
            log_fn(f"[diagnostic] Target page made {len(urls)} requests to target.com; data-like ones: {seen[:10]}")
        if not _TGT.get("clue_said"):
            # one-time look at the page's own data request, so the next version knows where the stock word is
            _TGT["clue_said"] = True
            try:
                for u in [u for u in urls if "sapphire-api" in u][:1]:
                    ptxt, perr = fetch(u)
                    log_fn(f"[diagnostic] Target page-data request from Python: "
                           f"{perr or ('%d characters' % len(ptxt or ''))}; has: {json_clues(ptxt or '', 500)}")
                    # the same address with the stock words only, to see whether the stock word is in it
                    if ptxt:
                        words = sorted(set(re.findall(r'"(?:availability_status|availabilityStatus|inventory_status)"\s*:\s*"([A-Z_]+)"', ptxt)))
                        log_fn(f"[diagnostic] Target page-data stock words seen: {words[:8]}")
            except Exception as e:
                log_fn(f"[diagnostic] Target page-data look failed: {str(e)[:80]}")
    return html, err, pick


def _target_get_json(tcin, browser, tmpl=None):
    """One small data request for this product: straight from Python, or (if Target refuses that)
    from inside an open Target page, the way the page itself asks."""
    api = re.sub(r"tcin=\d+", f"tcin={tcin}", tmpl) if tmpl else _tgt_api_url(tcin)
    if _TGT.get("mode") == "inpage":
        bf = browser.get()
        if not hasattr(bf, "light_get"):
            return None, "this browser cannot ask from inside a page"
        return bf.light_get(api, same_origin=False, min_len=40)
    return fetch(api)


def _target_json_ok(text, url):
    try:
        return bool(text and text.lstrip().startswith("{")
                    and ('"fulfillment"' in text or _TGT.get("kind") == "learned")
                    and detect_availability(text, hint=url) != "UNKNOWN")
    except Exception:
        return False


def _target_with_price(text, tcin, browser, url):
    """The availability request has no price. When it says IN STOCK, ask the product request for the
    price too (one more tiny request, only at that moment) and put it into the same answer."""
    try:
        if detect_availability(text, hint=url) != "IN_STOCK":
            return text
        ptext, perr = _target_get_json(tcin, browser, _tgt_prod_url(tcin))
        a, b = json.loads(text), json.loads(ptext)
        pr = b["data"]["product"].get("price")
        if pr:
            a["data"]["product"]["price"] = pr
            return json.dumps(a)
    except Exception:
        pass
    return text


def _tgt_ctx_from_net(net):
    """What Target's own page used for this visitor (store, zip, state, place, visitor id, key): read from the
    page's own requests, so our small requests look like the page's."""
    import urllib.parse as up
    ctx = {}
    for d in net or []:
        u = d.get("url", "")
        if "target.com" not in u or "?" not in u:
            continue
        q = up.parse_qs(up.urlsplit(u).query)
        for k_out, k_in in (("store_id", "store_id"), ("zip", "zip"), ("state", "state"), ("latitude", "latitude"),
                            ("longitude", "longitude"), ("visitor_id", "visitor_id"), ("key", "key")):
            if k_in in q and q[k_in] and k_out not in ctx and q[k_in][0]:
                ctx[k_out] = q[k_in][0]
        if "store_id" not in ctx and "purchasable_store_ids" in q:
            ctx["store_id"] = q["purchasable_store_ids"][0].split(",")[0]
    return ctx


def _tgt_prod_url(tcin):
    ctx = _TGT.get("ctx") or {}
    try:
        return target_api_url(tcin, ctx.get("key") or TARGET_KNOWN_KEY, ctx=ctx)
    except TypeError:
        return target_api_url(tcin)


def _tgt_ful_urls(tcin):
    ctx = _TGT.get("ctx") or {}
    try:
        return target_fulfillment_urls(tcin, ctx.get("key") or TARGET_KNOWN_KEY, ctx=ctx)
    except TypeError:
        return target_fulfillment_urls(tcin)


def _recon_target_once(url, tcin, browser, log_fn):
    """Once per run: open the Target page in a way that is recorded (every request it makes and what
    they answer), then ask the stock request for a few OTHER products shown on that page, so the words
    for 'in stock' are seen even while ours are sold out. Read-only; nothing monitored changes."""
    if _TGT.get("recon_done"):
        return
    _TGT["recon_done"] = True
    try:
        bf = browser.get()
        html, err = bf.fetch(url)
        net = list(getattr(bf, "recon_net", []) or [])
        _TGT["net"] = net
        _TGT["ctx"] = _tgt_ctx_from_net(net)
        n435 = sum(1 for d in net if d.get("status") == 435)
        log_fn(f"[diagnostic] Target page in {getattr(bf, 'engine', 'browser')}: {len(net)} requests noted, "
               f"{n435} of them answered by Target's bot check (HTTP 435); place used by the page: "
               f"store {(_TGT['ctx'] or {}).get('store_id')}, zip {(_TGT['ctx'] or {}).get('zip')}.")
        if err or not html:
            log_fn(f"[diagnostic] Target recording: page not read ({str(err)[:100]})")
            return
        item_id = recon._reg.get(recon._norm(url), ("target", ""))[0]
        rel = recon.related_ids(html, "target", tcin)[:4]
        res = {"own": tcin, "related_found": rel, "tries": []}
        for i, r in enumerate(rel):
            cands = [("availability", u) for u in _tgt_ful_urls(r)] + [("product", _tgt_prod_url(r))]
            for kind, u in cands:
                text, e = fetch(u)
                mode = "plain"
                if (e or not text) and i == 0 and hasattr(bf, "light_get"):
                    text, e = bf.light_get(u, same_origin=False, min_len=40)
                    mode = "inpage"
                res["tries"].append({"tcin": r, "kind": kind, "mode": mode, "err": (str(e)[:120] if e else None),
                                     "says": (detect_availability(text, hint=u) if text else None),
                                     "stock_fields": recon.key_values(text or "", 12),
                                     "head": (text or "")[:350]})
                time.sleep(0.3)
        recon.save_extra(item_id, "control_target", res)
        n_ok = sum(1 for x in res["tries"] if x.get("says") not in (None, "UNKNOWN"))
        log_fn(f"[diagnostic] Target recording: {len(net)} page requests noted; other products on the page: "
               f"{rel}; stock request answered usefully {n_ok} of {len(res['tries'])} times.")
    except Exception as e:
        log_fn(f"[diagnostic] Target recording failed: {str(e)[:100]}")


_TARGET_HOST = "target.com"


def _target_learn_from_net(net, tcin):
    """If the page itself made a data request for this product whose answer carries a stock word,
    that exact request becomes the one used (the product number swapped per item)."""
    best = None
    for d in net or []:
        u, b = d.get("url", ""), d.get("body")
        if not b or d.get("status") != 200 or _TARGET_HOST not in u or ("tcin=" + tcin) not in u:
            continue
        try:
            if detect_availability(b, hint=u) == "UNKNOWN":
                continue
        except Exception:
            continue
        score = (2 if "fulfillment" in u else 1)
        if best is None or score > best[0]:
            best = (score, u)
    return best[1] if best else None


def _target_try_known(url, tcin, browser, log_fn):
    """Target's public product-data requests (known web key). Tried first: tiny requests
    instead of a whole page. Only used if the answer is really readable."""
    saved = (_TGT["tmpl"], _TGT.get("kind"))
    cands = [("product", _tgt_prod_url(tcin))] + [("availability", u) for u in _tgt_ful_urls(tcin)]
    notes = []
    for mode in ("inpage", "plain"):        # from inside the open Target tab first: it carries Target's own cookies
        _TGT["mode"] = mode
        if mode == "inpage":
            bf = browser.get()
            if not hasattr(bf, "light_get"):
                notes.append("inpage: not available")
                continue
            page = getattr(bf, "_page", None)
            if page is None or "target.com" not in (getattr(page, "url", "") or ""):
                bf.fetch(url)                   # open one real Target page to ask from
        for kind, tmpl in cands:
            text, err = _target_get_json(tcin, browser, tmpl)
            if _target_json_ok(text, url):
                _TGT["tmpl"], _TGT["kind"] = tmpl, kind
                if not _TGT["said"]:
                    _TGT["said"] = True
                    log_fn(f"[info] Target: reading stock with one small {kind} request per check "
                           f"({'from Python' if mode == 'plain' else 'from inside an open Target page'}) - no page loads.")
                return True
            if err:
                notes.append(f"{mode}/{kind}#{cands.index((kind, tmpl))}: {str(err)[:70]}")
            else:
                notes.append(f"{mode}/{kind}#{cands.index((kind, tmpl))}: no stock word; "
                             f"{json_clues(text, 330, stock_only=True) or json_clues(text, 200)}")
    _TGT["tmpl"], _TGT["kind"], _TGT["mode"] = saved[0], saved[1], None
    _TGT["known_tries"] = _TGT.get("known_tries", 0) + 1
    if _TGT["known_tries"] <= 3:
        recon.save_extra(recon._reg.get(recon._norm(url), ("target", ""))[0], "target_known_try",
                         {"try": _TGT["known_tries"], "ctx_used": {k: v for k, v in (_TGT.get("ctx") or {}).items() if k != "key"},
                          "notes": notes[:12]})
    if not _TGT.get("known_said"):
        _TGT["known_said"] = True
        log_fn("[diagnostic] Target's known product-data requests did not work:")
        for n in notes[:10]:
            log_fn("[diagnostic]   " + n[:420])
    return False


def _target_rendered(html, tcin, url, browser, log_fn):
    """The drawn page, with the price added from Target's product request when the page shows 'Add to cart'
    but no price (the price part of the page can be blocked while the rest is drawn)."""
    text = _RENDERED + html
    try:
        if detect_availability(text, hint=url) == "IN_STOCK" and detect_price(text, url) is None:
            bf = browser.get()
            api = _tgt_prod_url(tcin)
            ptext, perr = (bf.light_get(api, same_origin=False, min_len=40) if hasattr(bf, "light_get") else (None, "n/a"))
            if not ptext:
                ptext, perr = fetch(api)
            pr = detect_price(ptext, url) if ptext and ptext.lstrip().startswith("{") else None
            if pr:
                text += ('<script type="application/ld+json">{"@type":"Product","offers":{"@type":"Offer","price":"%.2f",'
                         '"priceCurrency":"USD"}}</script>' % pr)
            elif not _TGT.get("pricefail_said"):
                _TGT["pricefail_said"] = True
                log_fn(f"[diagnostic] Target: the page shows 'Add to cart' without a price and the product request gave "
                       f"no price either ({str(perr)[:80] if perr else 'no price in the answer'}).")
    except Exception:
        pass
    return text


# ---------------------------------------------------------------------------------------------------------------------
# v44: Target - ONE small request answers EVERY Target product at once (the same request Target's own product-list
# pages make: product_summary_with_fulfillment_v1, up to 10 products per request, public web key). It is asked every
# ~2 seconds no matter how many products are watched; each product's check then reads its answer from that.
# If it ever stops working the older flow below (small per-product request, then the drawn page) takes over by itself.
# ---------------------------------------------------------------------------------------------------------------------
TARGET_BATCH_GAP = 2.0           # seconds between batch requests (one request covers all products)
TARGET_BATCH_MAX = 10            # products per request (what Target's own page asks for)
_TB = {"tcins": [], "urls": {}, "ts": 0.0, "ts_done": 0.0, "data": {}, "fails": 0, "off_until": 0.0, "said": False,
       "fail_said": 0, "missing_said": set(), "lock": threading.Lock(), "inpage_ok": None, "n_ok": 0}
_TBL = threading.local()


def target_batch_register(url):
    """Remember a Target product (called for every Target link the checker is given)."""
    m = re.search(r"/A-(\d{5,})", url or "")
    if m and m.group(1) not in _TB["tcins"]:
        _TB["tcins"].append(m.group(1))
        _TB["urls"][m.group(1)] = url
    return m.group(1) if m else None


def target_batch_urls(tcins, key=TARGET_KNOWN_KEY, ctx=None):
    """The batch requests (<= TARGET_BATCH_MAX products each)."""
    import urllib.parse as up
    store, where, vid = _tgt_where(ctx)
    base = "https://redsky.target.com/redsky_aggregations/v1/web/product_summary_with_fulfillment_v1"
    out = []
    for i in range(0, len(tcins), TARGET_BATCH_MAX):
        chunk = tcins[i:i + TARGET_BATCH_MAX]
        out.append(f"{base}?key={key}&tcins={up.quote(','.join(chunk), safe='')}&store_id={store}&{where}"
                   f"&scheduled_delivery_store_id={store}&required_store_id={store}&has_required_store_id=true"
                   f"&channel=WEB&{vid}")
    return out


def parse_target_summaries(text):
    """Target's product-summary answer -> {tcin: (status, price)}; status is IN_STOCK / OUT_OF_STOCK (the ONLINE shipping
    status, the same one the older request used). A product with no online status is left out (it is read the older way)."""
    try:
        obj = json.loads(text)
        items = obj["data"]["product_summaries"]
    except Exception:
        return {}
    out = {}
    for it in items or []:
        try:
            tcin = str(it.get("tcin") or "")
            ful = it.get("fulfillment") or {}
            ship = ful.get("shipping_options") or {}
            st = str(ship.get("availability_status") or "").upper()
            if st in ("IN_STOCK", "LIMITED_STOCK", "PRE_ORDER_SELLABLE"):
                status = "IN_STOCK"
            elif st in ("OUT_OF_STOCK", "UNAVAILABLE", "NOT_SOLD_ONLINE", "PRE_ORDER_UNSELLABLE", "NOT_AVAILABLE"):
                status = "OUT_OF_STOCK"
            else:
                continue
            pr = it.get("price") or {}
            price = None
            for k in ("current_retail", "current_retail_min", "reg_retail"):
                try:
                    v = pr.get(k)
                    v = float(str(v).replace("$", "").replace(",", "")) if v not in (None, "") else None
                except Exception:
                    v = None
                if v:
                    price = v
                    break
            if tcin:
                out[tcin] = (status, price)
        except Exception:
            continue
    return out


def _target_batch_once(browser, log_fn):
    """One round of batch request(s) for all known Target products. -> number of products answered."""
    ctx = _TGT.get("ctx") or {}
    urls = target_batch_urls(list(_TB["tcins"]), ctx.get("key") or TARGET_KNOWN_KEY, ctx)
    got, why = {}, None
    if _TB["inpage_ok"] is False and time.time() - _TB.get("inpage_at", 0.0) > 900.0:
        _TB["inpage_ok"] = None            # v46: it was tried once and failed; Target's bot check may have cleared since - try again every 15 min
    for u in urls:
        res = {}
        if _ab_reader_ok("target"):
            text, err = _ab_page_fetch(u, "target")         # v58b: the buying browser's Target tab (Target answers it)
            res = parse_target_summaries(text) if (text and not err) else {}
        if not res:
            text, err = fetch(u)
            res = parse_target_summaries(text) if (text and not err) else {}
        if not res and browser is not None and _TB["inpage_ok"] is not False:
            try:
                bf = browser.get()
                if hasattr(bf, "light_get"):
                    page = getattr(bf, "_page", None)
                    if page is None or "target.com" not in (getattr(page, "url", "") or ""):
                        bf.fetch(next(iter(_TB["urls"].values())))
                    t2, e2 = bf.light_get(u, same_origin=False, min_len=40)
                    r2 = parse_target_summaries(t2) if (t2 and not e2) else {}
                    if _TB["inpage_ok"] is None:
                        _TB["inpage_ok"] = bool(r2)
                        _TB["inpage_at"] = time.time()
                    if r2:
                        res, err = r2, None
                    elif e2:
                        err = f"in-page: {str(e2)[:60]}" + (f" / plain: {str(err)[:40]}" if err else "")
            except Exception as e:
                err = err or str(e)[:80]
        if not res:
            _TB["why"] = str(err or "empty answer")[:120]
            why = why or (str(err)[:90] if err else (json_clues(text or "", 160, stock_only=True) if text else "empty answer"))
        got.update(res)
    return got, why


def _target_batch_text(tcin, browser, log_fn):
    """The batch answer for one product, as the small JSON the rest of the program already understands; None = use the older way."""
    _TBL.served = False
    if os.environ.get("RK_NO_TARGET_BATCH") or not _TB["tcins"]:
        return None
    now = time.time()
    if now < _TB["off_until"]:
        return None
    if now - _TB["ts"] >= TARGET_BATCH_GAP and sweep.state("target") not in ("ok", "resting"):     # v64: (the sweeper asks for it)
        with _TB["lock"]:
            if time.time() - _TB["ts"] >= TARGET_BATCH_GAP:       # someone else may have just refreshed it
                _TB["ts"] = time.time()
                got, why = _target_batch_once(browser, log_fn)
                if got:
                    _TB["data"] = got
                    _TB["ts_done"] = time.time()
                    _TB["fails"] = 0
                    _TB["n_ok"] += 1
                    hotness.set_cheap("target", True)
                    if not _TB["said"]:
                        _TB["said"] = True
                        log_fn(f"[info] Target: reading ALL {len(got)} products with one small request every "
                               f"{TARGET_BATCH_GAP:g}s (no page loads).")
                else:
                    _TB["fails"] += 1
                    if _TB["fails"] >= 3:
                        wait = 60 * min(8, _TB["fails"] - 2)
                        _TB["off_until"] = time.time() + wait
                        hotness.set_cheap("target", False)
                        if _TB["fail_said"] < 3:
                            _TB["fail_said"] += 1
                            log_fn(f"[warn] Target: the all-products request did not work ({why}); using the older way for "
                                   f"{wait // 60} min, then trying again.")
    d = _TB["data"].get(tcin)
    if not d or time.time() - _TB["ts_done"] > 30:
        if d is None and _TB["ts_done"] and tcin not in _TB["missing_said"]:
            _TB["missing_said"].add(tcin)
            log_fn(f"[diagnostic] Target: product {tcin} was not in the all-products answer; it is read the older way.")
        return None
    status, price = d
    prod = {"tcin": tcin, "fulfillment": {"shipping_options": {"availability_status": status}}}
    if price:
        prod["price"] = {"current_retail": price}
    _TBL.served = True
    return json.dumps({"data": {"product": prod}})


def _target_fetch(url, log_fn, browser):
    m = re.search(r"/A-(\d{5,})", url)
    if not m:
        return fetch(url)
    tcin = m.group(1)
    target_batch_register(url)
    _bt = _target_batch_text(tcin, browser, log_fn)
    if _bt:
        return _bt, None
    now = time.time()
    _recon_target_once(url, tcin, browser, log_fn)
    if not _TGT["tmpl"] and now >= _TGT["retry_at"]:
        _target_try_known(url, tcin, browser, log_fn)
        if not _TGT["tmpl"]:
            lu = _target_learn_from_net(_TGT.get("net"), tcin)
            if lu:
                _TGT["tmpl"], _TGT["mode"] = lu, "plain"
                _TGT["kind"] = "learned"
                text, err = _target_get_json(tcin, browser)
                if err or not _target_json_ok(text, url):
                    _TGT["mode"] = "inpage"
                    text, err = _target_get_json(tcin, browser)
                if err or not _target_json_ok(text, url):
                    _TGT["tmpl"], _TGT["kind"], _TGT["mode"] = None, None, None
                else:
                    _TGT["kind"] = "availability" if "fulfillment" in lu else "product"
                    _TGT["said"] = True
                    log_fn("[info] Target: learned the stock request from what the page itself asked: "
                           + recon.redact(lu)[:200])
    if _TGT["tmpl"]:
        text, err = _target_get_json(tcin, browser)
        if not err and _target_json_ok(text, url):
            _TGT["fails"] = 0
            if _TGT.get("kind") == "availability":
                text = _target_with_price(text, tcin, browser, url)
            return text, None
        _TGT["fails"] += 1
        if _TGT["fails"] >= 3:
            log_fn("[warn] Target's product-data request stopped working; re-learning it.")
            _TGT["tmpl"], _TGT["fails"], _TGT["mode"] = None, 0, None
    if not _TGT["tmpl"] and now >= _TGT["retry_at"]:
        html, err, pick = _target_discover(url, browser, log_fn)
        if pick:
            _TGT["tmpl"] = pick[0]
            _TGT["kind"] = "product"
            _TGT["mode"] = "plain"
            _TGT["retry_at"] = 0
            if not _TGT["said"]:
                _TGT["said"] = True
                shown = re.sub(r"key=[0-9a-f]+", "key=...", pick[0])
                log_fn(f"[info] Target: learned the stock request from the page: {shown[:160]}")
            text, err = fetch(_tgt_api_url(tcin))
            if not err and text and text.lstrip().startswith("{") and '"fulfillment"' in text:
                return text, None
        else:
            wait_s = 300 * min(6, 2 ** max(0, _TGT.get("disc_fails", 1) - 1))     # 5, 10, 20, 30 min ... then every 30 min
            _TGT["retry_at"] = now + wait_s
            if _TGT.get("disc_fails", 1) <= 3:
                log_fn(f"[warn] Target: could not find the page's stock request; reading the rendered page "
                       f"instead for {wait_s // 60} min (slower).")
        if html and not err:
            return _target_rendered(html, tcin, url, browser, log_fn), None
        return None, err or "Target page could not be read"
    # fallback while the request is being re-learned: the rendered page
    html, err = browser.get().fetch(url)
    if err:
        return None, err
    return _target_rendered(html, tcin, url, browser, log_fn), None


_BB = {"ts": 0.0, "data": {}, "err": None, "key": None, "key_read": 0.0, "said": False}


def _bestbuy_key():
    """Free key from developer.bestbuy.com, pasted into bestbuy_key.txt."""
    if time.time() - _BB["key_read"] < 30:
        return _BB["key"]
    _BB["key_read"] = time.time()
    key = None
    try:
        with open("bestbuy_key.txt", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith("#"):
                    key = line.split()[0]
                    break
    except Exception:
        key = None
    _BB["key"] = key if key and len(key) >= 16 and "PASTE" not in key.upper() else None
    return _BB["key"]


def _redact(s):
    return re.sub(r"(?i)(api[_-]?key|key)=[^&\s\"')]+", r"\1=REDACTED", s or "")


def _bestbuy_api_fetch(t, key, skus, log_fn):
    """One request for ALL Best Buy products every ~2.2 s (well inside the
    free limits), answering each product from it."""
    now = time.time()
    if now - _BB["ts"] > 2.2:
        _BB["ts"] = now
        url = ("https://api.bestbuy.com/v1/products(sku%20in(" + ",".join(skus) + "))"
               f"?apiKey={key}&format=json&show=sku,name,orderable,onlineAvailability,onlineAvailabilityUpdateDate,salePrice")
        text, err = fetch(url)
        _BB["data"], _BB["err"] = {}, None
        _BB["ts_done"] = time.time()
        if err:
            _BB["err"] = _redact(err)
        else:
            try:
                import json as _json
                parsed = _json.loads(text)
                for p in parsed.get("products", []):
                    _BB["data"][str(p.get("sku"))] = p
                    # How fresh is Best Buy's official data compared with what we see? Written
                    # to the log whenever Best Buy's own "availability last updated" stamp changes.
                    upd = p.get("onlineAvailabilityUpdateDate")
                    if upd and _BB.setdefault("upd", {}).get(str(p.get("sku"))) != upd:
                        first = str(p.get("sku")) not in _BB["upd"]
                        _BB["upd"][str(p.get("sku"))] = upd
                        if not first:
                            log_fn(f"[info] Best Buy API: availability of {p.get('sku')} was updated by Best Buy at "
                                   f"{upd} (we read it at {datetime.now(timezone.utc).isoformat()[:19]} UTC); "
                                   f"now orderable={p.get('orderable')}.")
                if not _BB["data"]:
                    _BB["err"] = "no products came back: " + _redact(text[:160])
            except Exception:
                _BB["err"] = "unexpected reply: " + _redact((text or "")[:160])
        if _BB["err"] and not _BB.get("err_said"):
            _BB["err_said"] = True
            log_fn(f"[warn] Best Buy official service problem: {_BB['err']}")
        if not _BB["err"] and not _BB["said"]:
            _BB["said"] = True
            log_fn("[info] Best Buy: reading stock and price from Best Buy's official service.")
    p = _BB["data"].get(str(t.get("sku")))
    if not p:
        return None, f"Best Buy official service: {_BB['err'] or 'no data for this product'}"
    import json as _json
    return _json.dumps({"products": [p]}), None


# ---------------------------------------------------------------- Best Buy, light
# Best Buy cuts the connection of anyone who loads its full product pages over
# and over (our diagnostics: fine for ~14 loads each, then every load failed for
# many minutes). The product page itself only asks Best Buy for one tiny piece
# of data to draw the price and the Buy button. So: open ONE ordinary page in
# the PC's own Chrome, then ask that small question for ALL Best Buy products in
# a single request every few seconds, from inside that page, like the page does.
# If Best Buy pushes back, we rest (never push through).
_BBP = {"ts": 0.0, "ts_done": 0.0, "data": {}, "err": None, "tmpl": None,
        "fails": 0, "pauses": 0, "streak": 0, "pause_until": 0.0, "need_warm": False,
        "unusable": 0, "mode": "json", "pages_until": 0.0, "states_seen": set(),
        "said_ok": False, "calls": 0, "fresh_visitor": False, "every": 2.5, "last_change": 0.0,
        "engine": "chrome", "engine_pauses": 0}
BB_SWITCH_AFTER = 3       # this many rests in a row with the same browser: Best Buy is tried with the other kind of browser (Chrome <-> Camoufox)
BB_JSON_EVERY = 2.5       # fastest pace (seconds) between the one grouped request; slows itself only if Best Buy pushes back
BB_SPEEDUP_AFTER = 300    # seconds of clean answers before speeding up one step
BB_WARM_EVERY = 6 * 3600  # reopen the page only every 6 h (or when its requests fail): every re-open risked Best Buy hanging up
BB_PRICE_KEEP = 20.0      # seconds a price read stays good while the item stays buyable (saves repeat price requests)
BB_PRICE_FAILS_PAGES = 8   # price requests failing this many times in a row (for a buyable item) -> slow full pages
BB_PAGES_EVERY = 45.0     # fallback: one full page per product this often
# v33: back to the v31 rests. v32 shortened them (15 s / 1 min) and Walmart and Best Buy then blocked everything: a store that has just said
# "no" answers a quick return with a longer "no". A long rest lets the store forget; the trackers' alerts still make the program look at once afterwards.
BB_REST_BASE = 45         # first rest (seconds) when Best Buy stops answering; doubles each time up to BB_REST_MAX (v51: was 120 / 900)
BB_REST_MAX = 300
BB_REST_MIN = 10.0        # v51: the shortest rest while another browser is about to be ready (was 30 s)
NET_REST_BASE = 10        # v51: a reader that was hung up on rests this long (doubling), while its browser is switched; the OTHER readers keep reading (was 60 s - 10 min for the whole store)
NET_REST_MAX = 80
NET_STORE_REST_BASE = 30  # v51: only when most of a store's readers were hung up within a minute does the whole store rest (30 s, doubling, at most 4 min)
NET_STORE_REST_MAX = 240
SKIP_WAIT_MAX = 30.0      # v51: a reader whose browsers are all resting asks again after at most this long (was 60 s), using the one that is back first
BLOCK_PAUSE_STEP = 300    # "prove you are human" page: pause this store 5, 10, 15 ... min (at most BLOCK_PAUSE_MAX)
BLOCK_PAUSE_MAX = 1800
BLOCK_PROBE = (120, 300, 600, 900, 1200, 1800)    # v52: a reader that was shown a human-check page for a product leaves THAT product alone for 2, then 5, 10, 15, 20, 30 min
#                                                   (it is then looked at once with whichever browser is ready; the store's other readers keep reading it meanwhile)
BLOCK_PROBE_SPREAD = 37.0                         # v52: the readers' probe times differ by this many seconds per reader, so they never all ask together
BLOCK_RECOVER_SEC = 900   # after this long without a new block the store is checked faster again, one step at a time


def _bb_light_ok():
    return RealChromeFetcher is not None and RealChromeFetcher.available()


def _bb_origin(url):
    m = re.match(r"(https?://[^/]+)", url or "")
    return m.group(1) if m else "https://www.bestbuy.com"


def _bb_buttonstate_url(origin, skus):
    """Best Buy's page also asks a second small service for just the buy-button word of each
    product (ADD_TO_CART / SOLD_OUT / COMING_SOON ...). Used when the price request cannot answer
    (it errors for items that are not on sale right now)."""
    import json as _j
    import urllib.parse as _up
    path = [["shop", "buttonstate", "v5", "item", "skus", [int(x) for x in skus], "conditions", "NONE",
             "destinationZipCode", "10001", "storeId", "", "context", "cyp", "addAll", "false"]]
    return origin + "/api/tcfb/model.json?paths=" + _up.quote(_j.dumps(path, separators=(",", ":"))) + "&method=get"


def _bb_trouble(why, log_fn, hard=False):
    st = _BBP
    st["fails"] += 1
    st["streak"] = 0
    st["err"] = why
    if hard or st["fails"] >= 3:
        lz = _POOLS.get("bestbuy")
        if lz is not None and getattr(lz, "_pool", False):
            # v38: another browser first. The one that failed sits out; the next ready one takes over at once, and no rest is needed.
            st["fails"] = 0
            st["need_warm"] = True
            st["ts"] = 0.0
            if lz.note_result(False, why=why, block=("human" in str(why).lower()), log=log_fn):
                st["switched"] = True
                return True
            # every browser is resting: the first one that is back decides when to try again (never sooner than the usual rest)
        rest = min(BB_REST_MAX, BB_REST_BASE * (2 ** min(st["pauses"], 3)))
        if lz is not None and getattr(lz, "_pool", False):
            rest = max(BB_REST_MIN, min(rest, lz.soonest_ready() + 2.0))
        st["pauses"] += 1
        st["pause_until"] = time.time() + rest
        st["need_warm"] = True
        st["fresh_visitor"] = True       # after resting, come back as a fresh browser session
        st["engine_pauses"] = st.get("engine_pauses", 0) + 1
        if st["engine_pauses"] >= BB_SWITCH_AFTER and not (_POOLS.get("bestbuy") is not None and getattr(_POOLS["bestbuy"], "_pool", False)):
            st["engine_pauses"] = 0
            if st.get("engine", "chrome") == "chrome":
                if ENGINE_INSTALLS["camoufox"]["state"] == "ready":
                    st["engine"] = "camoufox"
                    log_fn("[info] Best Buy kept resetting the connection of the PC's Chrome/Edge: trying Camoufox (a different kind of browser) for Best Buy now.")
            else:
                st["engine"] = "chrome"
                log_fn("[info] Best Buy did not like Camoufox either: going back to the PC's Chrome/Edge for Best Buy.")
        st["fails"] = 0
        st["every"] = min(15.0, st["every"] * 2)     # come back at a gentler pace, speed up again later
        st["last_change"] = time.time()
        log_fn(f"[block] Best Buy stopped answering ({why[:110]}). Resting {rest / 60:.0f} min, then trying "
               f"again every {st['every']:g}s with a fresh browser visit. (Not trying to push through.)")
    return False


def _bb_buttonstate_read(bf, origin, qskus, st, log_fn, primary):
    """Best Buy's second small service: the buy-button word of each product (ADD_TO_CART / SOLD_OUT / ...).
    Returns {sku: {state, purchasable, price}} or None. A price is only fetched for items that can be bought."""
    skus = list(qskus)
    got = None
    bcode, bbody, be = bf.page_json(_bb_buttonstate_url(origin, skus))
    st["calls"] += 1
    if not be and bcode == 200 and bbody:
        st["last_raw"] = {"service": "buttonstate", "text": bbody[:3000]}
        bp = parse_bestbuy_blocks(bbody)
        bmine = {k: v for k, v in bp.items() if k in skus and (v.get("state") or v.get("purchasable") is not None)}
        if not st.get("said_bs"):
            st["said_bs"] = True
            log_fn(f"[diagnostic] Best Buy button-word request answered HTTP {bcode} (first 400 characters): "
                   f"{bbody[:400]!r}")
        if bmine:
            # a price is only needed once an item can be bought: ask the price service for those
            _in_states = ("ADD_TO_CART", "BUY_NOW", "PRE_ORDER", "PREORDER", "ADD_TO_CART_PRE_ORDER")
            pcache = st.setdefault("pcache", {})
            for k, v in bmine.items():
                if v.get("state") not in _in_states:
                    pcache.pop(k, None)              # not buyable now: the next buyable moment gets a fresh price
                elif v.get("price") is None and k in pcache and time.time() - pcache[k][1] < BB_PRICE_KEEP:
                    v["price"] = pcache[k][0]        # still buyable and priced a moment ago
            need = [k for k, v in bmine.items() if v.get("price") is None and v.get("state") in _in_states]
            if need and time.time() >= st.get("price_next", 0.0):
                pc, pb, pe = bf.page_json(origin + "/api/3.0/priceBlocks?skus=" + ",".join(need))
                priced = False
                if not pe and pc == 200 and pb:
                    for k, v in parse_bestbuy_blocks(pb).items():
                        if k in bmine and v.get("price"):
                            bmine[k]["price"] = v["price"]
                            pcache[k] = (v["price"], time.time())
                            priced = True
                if priced:
                    st["price_gap"] = 2.5
                    st["price_fails"] = 0
                else:
                    st["price_fails"] = st.get("price_fails", 0) + 1
                    if st["price_fails"] >= BB_PRICE_FAILS_PAGES:
                        st["price_fails"], st["bs_ok"] = 0, False
                        st["mode"], st["pages_until"] = "pages", time.time() + 1800
                        log_fn("[info] Best Buy: the price request keeps failing for an item that looks buyable - "
                               "reading full pages instead, slowly (one per product every 45 s) for 30 min, "
                               "then trying the small requests again.")
                    # the price service is not answering: ask it less and less often (the button word
                    # keeps being read at the normal pace, so the moment of the restock is still exact)
                    st["price_gap"] = min(30.0, st.get("price_gap", 2.5) * 2)
                    st["price_next"] = time.time() + st["price_gap"]
                    if not st.get("said_price_slow"):
                        st["said_price_slow"] = True
                        log_fn("[warn] Best Buy: an item looks buyable but the price request did not answer "
                               f"({pe or ('HTTP %s' % pc)}); asking for the price less often until it does.")
            got = bmine
            if primary:
                st["bs_ok"] = True
                if st["tmpl"] != "buttonstate":
                    st["tmpl"] = "buttonstate"
                    log_fn(f"[info] Best Buy: reading the buy-button word with one small request for all "
                           f"{len(skus)} products (no key needed).")
    elif not st.get("said_bs"):
        st["said_bs"] = True
        log_fn(f"[diagnostic] Best Buy button-word request did not work: {be or ('HTTP %s' % bcode)}; "
               f"{(bbody or '')[:200]!r}")
    return got


def _recon_bb_once(bf, origin, skus, log_fn, item_id):
    """Once per run: record the raw answers of Best Buy's two small services for our products AND for
    a few other products shown on the page (some of which are in stock), so the exact words Best Buy
    uses for 'can be bought' versus 'sold out' are known. Read-only."""
    if _BBP.get("recon_done"):
        return
    _BBP["recon_done"] = True
    try:
        html = bf._page.content() if getattr(bf, "_page", None) is not None else ""
        rel = [x for x in recon.related_ids(html, "bestbuy", "") if x not in skus][:12]
        res = {"own": skus, "related_found": rel, "calls": []}
        for label, ss in (("own", skus), ("related", rel)):
            if not ss:
                continue
            for name, u in (("priceBlocks", origin + "/api/3.0/priceBlocks?skus=" + ",".join(ss)),
                            ("buttonstate", _bb_buttonstate_url(origin, ss))):
                code, body, e = bf.page_json(u)
                parsed = {}
                try:
                    if body and not e:
                        parsed = {k: v for k, v in parse_bestbuy_blocks(body).items()}
                except Exception:
                    pass
                res["calls"].append({"set": label, "service": name, "http": code, "err": e,
                                     "parsed": parsed, "head": (body or "")[:3500]})
                time.sleep(0.4)
        recon.save_extra(item_id, "control_bestbuy", res)
        log_fn(f"[diagnostic] Best Buy recording: other products on the page: {len(rel)}; "
               + "; ".join(f"{c['set']}/{c['service']}: HTTP {c['http']}" for c in res["calls"]))
    except Exception as e:
        log_fn(f"[diagnostic] Best Buy recording failed: {str(e)[:100]}")


def _bestbuy_page_fetch(t, targets, browser, log_fn):
    """Answers one Best Buy product from a shared, grouped reading.
    Returns (text, error); the time the data was really read is _BBP['ts_done']."""
    st = _BBP
    now = time.time()
    skus = [str(x["sku"]) for x in targets if x.get("sku")]
    if now < st["pause_until"]:
        return None, f"Best Buy is resting ({int(st['pause_until'] - now)}s left)"
    if now - st["ts"] >= st["every"]:
        st["ts"] = now
        bf = browser.get()
        origin = _bb_origin(t["url"])
        if st["need_warm"] or bf._page is None or now - bf.warm_at > BB_WARM_EVERY:
            if st.get("fresh_visitor") and getattr(browser, "_pool", False):
                st["fresh_visitor"] = False        # the pool keeps a separate profile per browser: nothing to rotate here
            if st.get("fresh_visitor"):
                st["fresh_visitor"] = False
                try:
                    nxt = bf.rotate("Best Buy hung up")
                    log_fn(f"[info] Best Buy: coming back with a fresh browser session ({nxt or 'same browser'}).")
                except Exception:
                    pass
            err = bf.warm(t["url"])
            if err:
                _bb_trouble(err, log_fn, hard=("ERR_HTTP2" in err or "ERR_CONNECTION" in err or "NOTHING" in err))
                return None, f"Best Buy page did not open: {err[:100]}"
            st["need_warm"] = False
            _recon_bb_once(bf, origin, skus, log_fn, t["id"])
        templates = []
        if st["tmpl"]:
            templates.append(st["tmpl"])
        learned = getattr(bf, "learned_api", None)
        if learned:
            tm = re.sub(r"skus=[^&]*", "skus={SKUS}", learned)
            if tm not in templates:
                templates.append(tm)
        default = origin + "/api/3.0/priceBlocks?skus={SKUS}"
        if default not in templates:
            templates.append(default)
        got, last_problem, hard = None, "no reply", False
        if st.get("bs_ok"):
            templates = []            # the button-word service has been the one that works: go straight to it
        for tm in templates:
            code, body, e = bf.page_json(tm.replace("{SKUS}", ",".join(skus)))
            st["calls"] += 1
            if e or code != 200 or not body:
                last_problem = e or f"HTTP {code}"
                hard = hard or code in (403, 429) or code == 0
                continue
            st["last_raw"] = {"service": "priceBlocks", "text": body[:3000]}
            parsed = parse_bestbuy_blocks(body)
            # Best Buy's price service answers "Failed to retrieve price for sku N" for items with no price
            # listed right now (sold out / not for sale). That is how an unavailable item shows here.
            for mm in re.finditer(r"Failed to retrieve price for sku (\d{5,9})", body):
                if mm.group(1) in skus and mm.group(1) not in parsed:
                    parsed[mm.group(1)] = {"state": "NO_PRICE", "purchasable": False, "price": None}
            mine = {k: v for k, v in parsed.items() if k in skus}
            if mine:
                got = mine
                if st["tmpl"] != tm:
                    st["tmpl"] = tm
                    log_fn(f"[info] Best Buy: reading stock and price with one small request for all "
                           f"{len(skus)} products (no key needed).")
                break
            last_problem = "reply had no product data: " + body[:500].replace("\n", " ")
            if not st.get("said_reply"):
                st["said_reply"] = True
                log_fn(f"[diagnostic] Best Buy price request answered (first 500 characters): {body[:500]!r}")
        if got is None:
            got = _bb_buttonstate_read(bf, origin, skus, st, log_fn, True)
        elif any(v.get("state") == "NO_PRICE" for v in got.values()):
            # the price service says "no price" for sold-out items - but also for items that are only
            # not priceable through it. Ask the buy-button word for those, so a real restock is never hidden.
            nop = [k for k, v in got.items() if v.get("state") == "NO_PRICE"]
            bm = _bb_buttonstate_read(bf, origin, nop, st, log_fn, False)
            if bm:
                for k, v in bm.items():
                    if k in got and v.get("state"):
                        got[k] = v
        if got is None:
            st["unusable"] += 1
            st["bs_ok"] = False
            # re-opening the page is what makes Best Buy hang up, so only do it when the small request itself
            # could not be made; an answer that arrived (just without product data) means the page is fine
            if hard or last_problem.startswith("HTTP") or not last_problem.startswith("reply had no product data"):
                st["need_warm"] = True
            if hard:
                _bb_trouble(last_problem, log_fn, hard=True)
            else:
                st["err"] = last_problem
                if st["unusable"] % 8 == 0 and getattr(_POOLS.get("bestbuy"), "_pool", False):
                    _bb_trouble(last_problem, log_fn, hard=True)       # eight unusable answers in a row: this browser is not getting through
                if st["unusable"] in (1, 5, 40):
                    log_fn(f"[warn] Best Buy small data request not usable ({last_problem[:300]}).")
                if st["unusable"] >= 40:
                    st["mode"] = "pages"
                    st["pages_until"] = time.time() + 1800
                    st["unusable"] = 0
                    log_fn("[info] Best Buy: small data request keeps failing - reading full pages instead, "
                           "slowly (one per product every 45 s) for 30 min, then trying the small request again.")
            return None, f"Best Buy: {last_problem}"
        st["data"], st["err"], st["ts_done"] = got, None, time.time()
        st["unusable"], st["fails"] = 0, 0
        st["streak"] += 1
        if st["streak"] >= 20:
            st["pauses"] = 0
            st["engine_pauses"] = 0
        if st["every"] > BB_JSON_EVERY and time.time() - st["last_change"] > BB_SPEEDUP_AFTER:
            st["every"] = max(BB_JSON_EVERY, st["every"] / 1.5)
            st["last_change"] = time.time()
            log_fn(f"[info] Best Buy has answered cleanly for a while - speeding up to every {st['every']:.1f}s.")
        for k, v in got.items():
            key = v.get("state")
            if key and key not in st["states_seen"]:
                st["states_seen"].add(key)
                log_fn(f"[info] Best Buy button state seen for {k}: {key} (price {v.get('price')}).")
    rec = st["data"].get(str(t.get("sku")))
    _ab = st.setdefault("absent", {})
    if not rec and st["data"] and not st["err"]:
        # Best Buy answered for the other products but has no record at all for this one (not on sale yet, or not sold by Best Buy):
        # that is "cannot be bought", not "unreadable". The moment Best Buy lists it, the real button word is read again.
        _k = str(t.get("sku"))
        _ab[_k] = _ab.get(_k, 0) + 1
        if _ab[_k] >= 3:
            if _ab[_k] == 3:
                log_fn(f"[info] Best Buy has no listing data for product number {_k} (not on sale yet, or not sold by Best Buy): "
                       f"counted as out of stock until Best Buy lists it.")
            rec = {"state": "NO_RECORD", "purchasable": False, "price": None}
    elif rec:
        _ab.pop(str(t.get("sku")), None)
    if not rec:
        return None, f"Best Buy: {st['err'] or 'no data for this product yet'}"
    import json as _json
    return _json.dumps({"bb_button": {"sku": str(t.get("sku")), **rec}}), None


# ---------------------------------------------------------------------------------------------------------------------
# v58: stores that refuse the watching browsers are read through the BUYING browser (a normal browser window you signed in to):
# one quiet tab on the store's own site fetches the page or the store's small data request, exactly as the store's own page does.
# Best Buy (0 of 93 reads in diagnostics 57) and GameStop always go that way first; Target and Walmart use it whenever their own
# browsers fail or are all resting - so a product with a link is always read by SOME browser.
# ---------------------------------------------------------------------------------------------------------------------
ENGINE_FIRST_STORES = ("bestbuy", "walmart", "gamestop")      # v58b: read by the buying browser FIRST (a light request, ~1 s, instead of
                                                               # drawing a whole page for 12-20 s); its own browsers answer whenever that page
                                                               # does not show the stock. Target: its all-products request (see _target_batch_once).
_ENG_UNREAD = {}                                               # store -> [answers in a row the stock could not be read from, off-until time]


def _eng_first_ok(store):
    if store == "bestbuy":
        return True
    return time.time() >= _ENG_UNREAD.get(store, [0, 0.0])[1]


def _eng_unreadable(store, log_fn):
    """The buying browser's copy of this store's page does not show the stock (some stores draw it only in a full browser): after 10 such
    answers in a row that store is read by its own browsers only, for 30 minutes."""
    st = _ENG_UNREAD.setdefault(store, [0, 0.0])
    st[0] += 1
    if st[0] >= 10:
        st[0], st[1] = 0, time.time() + 1800
        log_fn(f"[info] {store}: the buying browser's quick read does not show the stock on this store's pages - its own browsers read it alone for 30 min.")
ENGINE_FALLBACK_STORES = ("bestbuy", "gamestop", "target", "walmart")
_BBE = {"ts": 0.0, "ts_done": 0.0, "data": {}, "err": None, "lock": threading.Lock(), "said": False, "every": BB_JSON_EVERY}


def _ab_reader_ok_once(store):
    """v64: may the buying browser be asked for ONE extra look (learning a Best Buy number, confirming a very low price)? Yes, unless the
    store refused a request a moment ago."""
    try:
        import amazon_buy as _ab
        return _ab.reader_ok(store) and not sweep.resting(store)
    except Exception:
        return False


def _ab_reader_ok(store):
    """The buying browser may be asked to read for the store's readers. v64: not while the store's sweeper uses it (it is the store's
    one buying-browser visitor, at its own pace) or rests after a refusal (then nothing else asks the store through it either)."""
    try:
        import amazon_buy as _ab
        return _ab.reader_ok(store) and sweep.state(store) not in ("ok", "resting")
    except Exception:
        return False


def _ab_readers_pause(store):
    """v92: wait for a checkout at this store? (Amazon / Best Buy / Walmart: no - they keep looking during a checkout.)"""
    try:
        import amazon_buy as _ab
        return _ab.readers_pause(store)
    except Exception:
        return False


def _ab_pause_max():
    try:
        import amazon_buy as _ab
        return float(_ab.READ_PAUSE_MAX)
    except Exception:
        return 30.0


def _ab_page_fetch(url, store):
    try:
        import amazon_buy as _ab
        return _ab.page_fetch(url, store)
    except Exception as e:
        return None, f"buying browser: {str(e)[:80]}"


_BBV = {}            # sku -> (time, result of the product-page look)
BB_SHIP_KEEP = 120.0


def _bb_ship_check(got, targets, log_fn):
    """v59b: Best Buy's data says 'Add to Cart' also for items that are IN STORE ONLY (the button is for pickup). Every item that looks
    buyable is checked once on its product page by the buying browser: if it cannot be shipped it counts as OUT of stock."""
    urls = {str(x.get("sku")): x.get("url") for x in targets if x.get("sku")}
    for sku, rec in got.items():
        if rec.get("state") not in ("ADD_TO_CART", "PRE_ORDER", "PREORDER") or not urls.get(sku):
            if rec.get("state") not in ("ADD_TO_CART", "PRE_ORDER", "PREORDER"):
                _BBV.pop(sku, None)          # (sold out again: the next 'buyable' moment is checked fresh)
            continue
        hit = _BBV.get(sku)
        if not hit or time.time() - hit[0] > BB_SHIP_KEEP:
            try:
                import amazon_buy as _ab
                r = _ab.bb_pdp_check(urls[sku])
            except Exception as e:
                r = {"ok": False, "reason": str(e)[:80]}
            hit = _BBV[sku] = (time.time(), r)
            if r.get("ok") and r.get("title"):
                try:                              # v62: the product name on the page confirms (or rejects) the link before anything is bought
                    _tt = next((x for x in targets if str(x.get("sku")) == sku), None)
                    if _tt:
                        linkcheck.note_title(_tt, r.get("title"), log_fn)
                except Exception:
                    pass
            if r.get("ok"):
                log_fn(f"[info] Best Buy {sku}: product page says " + ("IN STORE ONLY (cannot be shipped) - counted as OUT of stock"
                       if r.get("storeOnly") and not r.get("ships") else "it can be shipped") + f" ({'; '.join(r.get('fulfillment') or [])[:160]})")
        r = hit[1]
        if r.get("ok") and r.get("storeOnly") and not r.get("ships"):
            rec.update(state="IN_STORE_ONLY", purchasable=False)
        elif r.get("ok") and r.get("check"):
            pass                                  # (a human-check page: the data's answer stands; never answered by the program)


_SKU_TRY = {}


def _bb_learn_sku(t, log_fn, report=None):
    """A Best Buy link without its product number (SKU) can only be read slowly as a whole page. The buying browser opens the page once,
    reads 'SKU: 12345678' and the link then joins the fast all-products request (and is saved, so it is known at the next start too)."""
    tid = t.get("id")
    if time.time() - _SKU_TRY.get(tid, 0) < 300 or not _ab_reader_ok_once("bestbuy"):
        return
    _SKU_TRY[tid] = time.time()
    try:
        import amazon_buy as _ab
        r = _ab.bb_pdp_check(t["url"])
    except Exception as e:
        r = {"ok": False, "reason": str(e)[:80]}
    sku = str(r.get("sku") or "")
    if r.get("ok") and re.fullmatch(r"\d{5,9}", sku):
        t["sku"] = int(sku)
        log_fn(f"[info] Best Buy link '{tid}': product number {sku} learned from its page - it is now read with the fast request.")
        if report:
            report("target", tid, learned_sku=int(sku))
    else:
        log_fn(f"[info] Best Buy link '{tid}': its product number could not be read yet ({r.get('reason') or 'no SKU on the page'}) - trying again in 5 min.")


def _bb_engine_fetch(t, targets, log_fn):
    """All Best Buy products with one small request (Best Buy's own price/stock request), made by the buying browser's Best Buy tab."""
    skus = [str(x["sku"]) for x in targets if x.get("sku") and _store_key(x.get("url", "")) == "bestbuy"]
    origin = _bb_origin(t["url"])
    if time.time() - _BBE["ts"] >= _BBE["every"] and skus:
        with _BBE["lock"]:
            if time.time() - _BBE["ts"] >= _BBE["every"]:
                _BBE["ts"] = time.time()
                got, why = {}, None
                body, err = _ab_page_fetch(origin + "/api/3.0/priceBlocks?skus=" + ",".join(skus), "bestbuy")
                if body and not err:
                    parsed = parse_bestbuy_blocks(body)
                    for mm in re.finditer(r"Failed to retrieve price for sku (\d{5,9})", body):
                        if mm.group(1) in skus and mm.group(1) not in parsed:
                            parsed[mm.group(1)] = {"state": "NO_PRICE", "purchasable": False, "price": None}
                    got = {k: v for k, v in parsed.items() if k in skus}
                    if not got:
                        why = "reply had no product data: " + body[:160].replace("\n", " ")
                else:
                    why = err
                need = [k for k in skus if (got.get(k) or {}).get("state") in (None, "NO_PRICE")]
                if need:
                    b2, e2 = _ab_page_fetch(_bb_buttonstate_url(origin, need), "bestbuy")
                    if b2 and not e2:
                        for k, v in parse_bestbuy_blocks(b2).items():
                            if k in need and (v.get("state") or v.get("purchasable") is not None):
                                if v.get("price") is None and (got.get(k) or {}).get("price") is not None:
                                    v["price"] = got[k]["price"]
                                got[k] = v
                    elif not got:
                        why = why or e2
                if got:
                    _bb_ship_check(got, targets, log_fn)
                    _BBE.update(data=got, ts_done=time.time(), err=None)
                    if not _BBE["said"]:
                        _BBE["said"] = True
                        log_fn(f"[info] Best Buy: read through the buying browser - all {len(skus)} products with one small request "
                               f"every {_BBE['every']:g}s (Best Buy refuses the watching browsers).")
                else:
                    _BBE["err"] = why or "no answer"
    rec = _BBE["data"].get(str(t.get("sku")))
    if rec and time.time() - _BBE["ts_done"] < 60:
        return json.dumps({"bb_button": {"sku": str(t.get("sku")), **rec}}), None
    if _BBE["data"] and not rec and time.time() - _BBE["ts_done"] < 60:
        rec = {"state": "NO_RECORD", "purchasable": False, "price": None}      # Best Buy has no listing data for it: cannot be bought now
        return json.dumps({"bb_button": {"sku": str(t.get("sku")), **rec}}), None
    return None, f"Best Buy via the buying browser: {_BBE['err'] or 'no data yet'}"


def _price_ref(t):
    """The product's normal price for the believability check: its MSRP, else its price cap."""
    try:
        import msrp as _ms
        m = _ms.for_row(matrix.key_of(t), matrix.UI.get("msrp"))
        if m and m.get("value"):
            return f"MSRP ${float(m['value']):.2f}"
    except Exception:
        pass
    return f"price cap ${float(t.get('max_price') or 0):.2f}"


def _price_not_believable(t, price):
    """v58: True when a price is under 35 % of the product's MSRP (or of its price cap when no MSRP is known)."""
    try:
        import msrp as _ms
        m = _ms.for_row(matrix.key_of(t), matrix.UI.get("msrp"))
        ref = float(m["value"]) if (m and m.get("value")) else float(t.get("max_price") or 0)
        return bool(ref and price is not None and float(price) < 0.35 * ref)
    except Exception:
        return False


_LOWV = {}


def _verify_low_price(t, text, price, browser):
    """-> (price, how) from an independent second source, or (None, why). The store's own data field counts as confirmation;
    otherwise the page is read again by another browser (the buying browser first) and its price compared."""
    tid = t.get("id")
    hit = _LOWV.get(tid)
    if hit and time.time() - hit[2] < 30 and abs(hit[0] - price) < 0.01:
        return hit[1]
    res = (None, "no second read possible")
    try:
        if (text or "").lstrip().startswith("{"):
            res = (price, "the store's own data (price field of this product)")          # structured data for this product number
        else:
            st = _store_key(t["url"])
            for how, get in (("a second read by the buying browser", lambda: _ab_page_fetch(t["url"], st) if _ab_reader_ok_once(st) else (None, "buying browser not ready")),
                             ("a second read by another browser", lambda: browser.get().fetch(t["url"]) if browser is not None else (None, "no browser")),
                             ("a plain second request", lambda: fetch(t["url"]))):
                h2, e2 = get()
                if h2 and not e2:
                    from stock_detect import detect_price_structured as _dps
                    p2 = _dps(h2, t["url"])          # (the product's own data field - not a number from the page text)
                    if p2 is not None:
                        res = (p2, how)
                        break
                res = (None, f"{how}: {str(e2 or 'no price in the product data')[:60]}")
    except Exception as e:
        res = (None, str(e)[:80])
    _LOWV[tid] = (price, res, time.time())
    return res


def now_gap(a, b):
    return b - a


def _store_key(url):
    """'www.target.com' -> 'target': products at the same store share one
    checker, one browser and one request budget."""
    host = url.lower().split("/")[2] if "//" in url else url.lower()
    parts = [p for p in host.split(".") if p not in ("www", "com", "net", "org", "co", "us")]
    return parts[-1] if parts else host


GROUPS = {}        # store -> the list its checker works from (a link added while running is appended here)


def adopt_target(t):
    """A link added in the table while the program is running: its store's checker starts looking at it. False = no checker
    for that store yet (a brand-new store column is picked up the next time you press Start watching)."""
    grp = GROUPS.get(_store_key(t["url"]))
    if grp is None:
        return False
    if not any(x["id"] == t["id"] for x in list(grp)):
        grp.append(t)
    return True


def _adopt_one(x, next_due, last_status, store_name, log_fn):
    """Start-up bookkeeping for a link that appeared while the program was already running."""
    last_status.setdefault(x["id"], None)
    if products.is_extra(x):
        calm = hotness.extra_calm(store_name) or 0          # v50: 0 unless Gaming mode is on
        next_due[x["id"]] = time.time() + 1.5 + (calm * 0.5 if calm else 0)
        recon.register(x["url"], x["id"], store_name, every=4 * 3600.0, skip_first=True)
    else:
        next_due[x["id"]] = time.time() + 1.0
        recon.register(x["url"], x["id"], store_name)
    log_fn(f"[switch] {store_name}: now also watching {x['id']}.")


def _guarded(targets, out_path, stop_event=None, log_fn=print, report=None, persist=None):
    """Keeps one store's checker alive: if anything unexpected goes wrong
    it is written to the log and the checker restarts after a few seconds,
    instead of the thread dying silently."""
    persist = persist if persist is not None else {}   # what each product last read etc. - kept across restarts, so no restock is lost to one
    errors_in_a_row = 0
    while stop_event is None or not stop_event.is_set():
        t_begin = time.time()
        try:
            _run_one(targets, out_path, stop_event, log_fn, report, persist)
            return
        except Exception as e:
            errors_in_a_row = errors_in_a_row + 1 if time.time() - t_begin < 120 else 1
            wait = min(60, 5 * errors_in_a_row)
            log_fn(f"[error] checker for store '{_store_key(targets[0]['url'])}' hit {type(e).__name__}: {str(e)[:200]} - restarting in {wait}s")
            if _sleep_or_stop(wait, stop_event):
                return


def _run_one(targets, out_path, stop_event=None, log_fn=print, report=None, persist=None, lane=0):
    """targets: list of target dicts (id, url, ...). Runs until stop_event
    is set (or forever, if stop_event is None — use Ctrl+C standalone).
    report(kind, item_id, **fields), if given, is called every poll with
    ('target', id, status=..., checked_at=...), and on an automatic
    fetch_mode upgrade with ('target', id, fetch_mode='browser',
    auto_upgraded=True) so app.py can persist it to disk.
    v50: lane = 0 is the store's main checker; lane 1, 2 ... are extra readers that run this same loop at the same time with their own
    browsers. All lanes of a store share everything below (kept in `persist`) and take turns on the products: a product is claimed
    by one lane while it is being read."""
    browser = _LazyBrowser(_store_key(targets[0]["url"]) if targets else "", lane)
    persist = persist if persist is not None else {}
    last_status = persist.setdefault("last_status", {})
    for _t in targets:
        last_status.setdefault(_t["id"], None)
    price_unread = persist.setdefault("price_unread", {})
    n_checks, n_err = persist.setdefault("n_checks", {}), persist.setdefault("n_err", {})
    last_check_start, gap_ema = persist.setdefault("last_check_start", {}), persist.setdefault("gap_ema", {})
    last_price_note = persist.setdefault("last_price_note", {})
    warn_state = persist.setdefault("warn_state", {})
    unparseable_state = persist.setdefault("unparseable_state", {})
    browser_confirmed_unhelpful = persist.setdefault("browser_confirmed_unhelpful", set())
    claim_lock = persist.setdefault("claim_lock", threading.Lock())
    inflight = persist.setdefault("inflight", {})         # product id -> (lane, since): being read right now
    lane_reads = persist.setdefault("lane_reads", {})
    out_pending = persist.setdefault("out_pending", {})   # product id -> time of its first OUT read after an IN read (see FLICKER_WINDOW)
    backoff_until = persist.setdefault("backoff_until", {})
    last_oos_ts = persist.setdefault("last_oos_ts", {})
    bad_streak = {}        # consecutive failed/unreadable checks per target
    lane_rest_until = [0.0]      # v51: THIS reader rests (after a hang-up) - the store's other readers carry on
    lane_backoff = {}            # v51: product -> before this time THIS reader does not ask for it again (human-check page, all its browsers resting); the other readers still do
    lane_net = {"k": 0, "skips": 0}
    lane_queue = collections.deque()      # v51: products this reader already claimed and asked for together with the one it is reading (see PREFETCH_N)

    def _drop_queue():
        """Gives the products this reader had lined up back to the store's other readers."""
        while lane_queue:
            _id = lane_queue.popleft()
            with claim_lock:
                if (inflight.get(_id) or (None,))[0] == lane:
                    inflight.pop(_id, None)
                    next_due[_id] = min(next_due.get(_id, 0.0), time.time())
    lane_blocks = {}             # v51: human-check pages this reader was shown, per product
    worked_with = {}       # engine that last produced a readable status
    interval_now = persist.setdefault("interval_now", {})
    blocks = persist.setdefault("blocks", {})
    last_block_at = persist.setdefault("last_block_at", {})
    diag_logged = persist.setdefault("diag_logged", set())
    last_switch_log = persist.setdefault("last_switch_log", {})
    hold_log = persist.setdefault("hold_log", {})
    unread_run = persist.setdefault("unread_run", {})        # unreadable checks in a row per target (for slowing down pages that cannot be read)
    pace_state = persist.setdefault("pace_state", {})        # last pacing state per target (normal / calm / hot / expected / unreadable)
    hist = hotness.History(out_path, os.path.join(os.path.dirname(out_path) or ".", "alerts.csv"))
    rot_hist = persist.setdefault("rot_hist", {})            # when each target last switched browsers (a switch opens a new browser window, so it is rationed)
    net_pauses = persist.setdefault("net_pauses", {})
    light_st = persist.setdefault("light_st", {})
    store_name = _store_key(targets[0]["url"]) if targets else ""
    me = threading.get_ident()
    wd = _WD.setdefault(store_name, {})
    next_due = persist.setdefault("next_due", {})
    persist.setdefault("wake_cv", threading.Condition())   # v82: the sweeper wakes this store's checkers the moment it has a new answer
    sweep_seen = persist.setdefault("sweep_seen", {})      # v64: product -> the sweeper answer this store's main checker last handed on
    real_read_at = [time.time()]                          # v64: when this reader last read a page itself (its browser is closed when idle)
    t_start = time.time()
    if lane == 0:
        for _t in targets:
            if products.is_extra(_t):
                recon.register(_t["url"], _t["id"], store_name, every=4 * 3600.0, skip_first=True)
            else:
                recon.register(_t["url"], _t["id"], store_name)
        if store_name == "target":
            for _t in targets:
                target_batch_register(_t["url"])        # v44: the all-products request knows every Target link from the start
        persist["owner"] = me
        wd.update(beat=time.time(), browser=browser, persist=persist)
        _wl = wd
        # Each product has its own due time, so products at one store are spread
        # out evenly (never fired in a burst) and each keeps its own pace.
        # v50: an added ("extra") product is treated exactly like an original one.
        for i, x in enumerate(targets):
            if x["id"] not in next_due:
                next_due[x["id"]] = t_start + i * product_gap(x) / max(1, len(targets))
        persist["ready"] = True
    else:
        persist.setdefault("lane_owner", {})[lane] = me
        _wl = wd.setdefault("lanes", {}).setdefault(lane, {})
        _wl.update(beat=time.time(), state="starting")
        while not persist.get("ready"):
            if _sleep_or_stop(0.5, stop_event):
                return

    held = [None]          # the product this reader has claimed (see `inflight`)

    def _release():
        _id = held[0]
        if _id is not None:
            held[0] = None
            with claim_lock:
                if (inflight.get(_id) or (None,))[0] == lane:
                    inflight.pop(_id, None)

    idle_closed = False
    poke_seen = persist.setdefault("poke_seen", {})        # product -> time of the last tracker alert already acted on
    pic_seen = persist.setdefault("pic_seen", {})          # product -> when its page was last searched for the product picture
    next_flush = time.time() + 30
    stats = persist.setdefault("stats", {})
    next_stats = time.time() + 600
    next_cache = time.time() + hygiene.CACHE_EVERY * 0.5 + 97.0 * lane      # v52 (see below)
    next_pressure = time.time() + 120.0 + 31.0 * lane
    rec_every = float(os.environ.get("RK_RECYCLE_EVERY", RECYCLE_EVERY))
    rec_first = float(os.environ.get("RK_RECYCLE_FIRST", RECYCLE_FIRST.get(store_name, rec_every)))
    next_recycle = (time.time() + rec_first + 600.0 * lane) if store_name in RECYCLE_STORES else float("inf")      # (the readers of a store are restarted at different times)
    try:
        while stop_event is None or not stop_event.is_set():
            _wake_seen = persist.get("wake_n", 0)
            _release()
            _wl["beat"] = time.time()
            if lane == 0:
                if persist.get("owner") != me:
                    return           # a fresh checker took this store over (the watchdog replaced this stuck one)
            else:
                if persist.get("lane_owner", {}).get(lane) != me:
                    return           # a fresh reader took this place over
                _ok, _why = hotness.lanes_may_run(lane, store=store_name)
                if lane >= persist.get("lanes_want", 1):
                    _ok, _why = False, "not needed right now"
                if (store_name == "target" and hotness.is_cheap("target") and not os.environ.get("RK_LANES_TARGET_ALWAYS")
                        and not _TB["missing_said"] and sweep.state("target") in ("off", "failing")):
                    # v62: only while it really covers EVERY Target product (diagnostics 60: products missing from that answer were
                    # read by one reader alone, once every ~10 minutes - "last answer 1 h ago")
                    _ok, _why = False, "Target's all-products request works"
                if not _ok:
                    _drop_queue()
                    _wl["state"] = f"resting ({_why})"
                    if browser._instance is not None or getattr(browser, "_members", None):
                        try:
                            browser.recycle()          # its browser is closed: it costs nothing while it rests
                        except Exception:
                            pass
                    if _sleep_or_stop(3.0, stop_event):
                        return
                    continue
            if time.time() >= next_recycle or (lane == 0 and wd.get("recycle_now") and store_name in RECYCLE_STORES):
                wd.pop("recycle_now", None) if lane == 0 else None
                if any(v == "IN_STOCK" for v in last_status.values()):
                    next_recycle = time.time() + 120          # something is in stock right now: not a good moment, ask again soon
                else:
                    next_recycle = time.time() + rec_every
                    try:
                        log_fn(f"[maintenance] {store_name}: opening a fresh browser (the old one grows the longer it stays open). "
                               f"Checks resume in a few seconds.")
                        browser.recycle()
                        for _k in list(light_st):
                            light_st[_k] = _light_state(store_name)       # the new tab has not compared anything yet
                        if lane == 0:
                            for _x in targets:
                                if _x["id"] in next_due:
                                    next_due[_x["id"]] = min(next_due[_x["id"]], time.time() + 0.5)
                    except Exception as _e:
                        log_fn(f"[maintenance] {store_name}: could not restart the browser ({_e}); carrying on with the old one.")
            # v52: housekeeping for a program that runs for months (see hygiene.py): this reader empties its browser's page cache now and then
            # (cookies and logins stay), and - only while the whole program is over its memory limit - restarts its browser, one reader at a
            # time, at a quiet moment.
            if time.time() >= next_cache and (browser._instance is not None or getattr(browser, "_members", None)):
                next_cache = time.time() + hygiene.CACHE_EVERY + 97.0 * lane
                try:
                    hygiene.note_cache_clear(browser.clear_cache())
                except Exception:
                    pass
            if hygiene.pressure() and time.time() >= next_pressure and not any(v == "IN_STOCK" for v in last_status.values()):
                with _PRESSURE_LOCK:
                    _ok_p = time.time() - _PRESSURE_LAST[0] >= 45.0
                    if _ok_p:
                        _PRESSURE_LAST[0] = time.time()
                next_pressure = time.time() + (1500.0 if _ok_p else 20.0)
                if _ok_p and (browser._instance is not None or getattr(browser, "_members", None)):
                    try:
                        log_fn(f"[maintenance] {store_name}: reader {lane + 1} opens a fresh browser (the program is over its memory limit).")
                        browser.recycle()
                        hygiene.note_recycle()
                        for _k in list(light_st):
                            light_st[_k] = _light_state(store_name)
                        for _x in targets:
                            if _x["id"] in next_due:
                                next_due[_x["id"]] = min(next_due[_x["id"]], time.time() + 0.5)
                    except Exception as _e:
                        log_fn(f"[maintenance] {store_name}: could not restart the browser ({_e}).")
            if lane == 0 and time.time() >= next_stats:
                next_stats = time.time() + 600
                for _id, _sd in list(stats.items()):
                    if _sd.get("n"):
                        log_fn(f"[stats] {_id}: last 10 min: {_sd['n']} checks, reads IN={_sd['IN']} OUT={_sd['OUT']} "
                               f"unreadable={_sd['UNK']}, failed={_sd['ERR']}, longest gap between good reads "
                               f"{_sd['maxgap']:.1f}s")
                    stats[_id] = {"IN": 0, "OUT": 0, "UNK": 0, "ERR": 0, "n": 0, "maxgap": 0.0, "last_ok": _sd.get("last_ok")}
            if lane == 0 and time.time() >= next_flush:
                next_flush = time.time() + 30
                if os.path.exists(out_path + ".pending"):
                    flush_pending_csv(out_path)          # rows kept aside while the file was locked
            _now_s = time.time()
            for _x in list(targets):
                if _x["id"] not in next_due:          # a link added in the table while running
                    with claim_lock:
                        if _x["id"] not in next_due:
                            _adopt_one(_x, next_due, last_status, store_name, log_fn)
            live = [x for x in list(targets) if x["id"] in next_due and not matrix.is_off(x)]       # the table's switches: off = not looked at
            if not live:
                if not idle_closed and browser._instance is not None:
                    idle_closed = True
                    try:
                        browser.recycle()
                        log_fn(f"[switch] {store_name}: everything here is switched off, so its browser was closed.")
                    except Exception:
                        pass
                if _sleep_or_stop(0.5, stop_event):
                    return
                continue
            idle_closed = False
            for _x in live:        # a tracker just alerted for this product: look at it NOW, not when its calm pause ends
                _pokeat = hotness.poked_since(_x["id"], poke_seen.get(_x["id"], 0.0))
                if _pokeat:
                    poke_seen[_x["id"]] = _pokeat
                    if backoff_until.get(_x["id"], 0) <= _now_s and next_due.get(_x["id"], 0) > _now_s:
                        _early = next_due[_x["id"]] - _now_s
                        next_due[_x["id"]] = _now_s
                        if _early > 5:
                            log_fn(f"[pace] '{_x['id']}': a tracker just alerted - looking now instead of waiting another {_early:.0f}s.")
            _dues = {x["id"]: max(next_due[x["id"]], backoff_until.get(x["id"], 0), lane_backoff.get(x["id"], 0), lane_rest_until[0]) for x in live}
            # v50: take the product that has waited longest (a product a tracker just alerted for goes first) - and claim it, so no other reader
            # of this store reads the same product at the same moment.
            _picked, _sleep_for, _start_at = None, 0.2, 0.0
            _from_queue = False
            _roles = {}
            if lane_queue:
                # v51: a product this reader lined up with its last group of early answers: it is already claimed
                _qid = lane_queue.popleft()
                with claim_lock:
                    _mine = (inflight.get(_qid) or (None,))[0] == lane
                _qx = next((x for x in live if x["id"] == _qid), None)
                if _mine and _qx is not None:
                    _picked, _from_queue = _qx, True
                    held[0] = _qid
                elif _mine:
                    with claim_lock:
                        inflight.pop(_qid, None)
            if _picked is None:
                with claim_lock:
                    for _k, _v in list(inflight.items()):
                        if _now_s - _v[1] > CLAIM_STALE:
                            inflight.pop(_k, None)             # its reader is stuck: the product goes to the next free reader
                    _pool_live = live
                    if lane > 0 and store_name == "target" and hotness.is_cheap("target") and _TB["missing_said"] and sweep.state("target") == "off":
                        # v62: an extra Target reader only takes the products the all-products answer does not cover
                        _pool_live = [x for x in live if (re.search(r"/A-(\d+)", x.get("url", "")) or [None, None])[1] in _TB["missing_said"]]
                    try:
                        # v64: while the store's sweeper works, the main checker hands on its answers and the other readers only read what
                        # it does not answer for (or, page-by-page stores, what it could not keep fresh) - see sweep.role
                        _lw = persist.get("lanes_want", 1)
                        _roles = {x["id"]: sweep.role(x, lane, _lw) for x in _pool_live}
                        _pool_live = [x for x in _pool_live if _roles.get(x["id"]) != "skip"]
                    except Exception:
                        _roles = {}
                    _free = [x for x in _pool_live if x["id"] not in inflight]
                    _ready = [x for x in _free if _dues[x["id"]] <= _now_s]
                    if _ready:
                        _hotr = [x for x in _ready if hotness.is_hot(x["id"], _now_s)]
                        _picked = min(_hotr or _ready, key=lambda x: _dues[x["id"]])
                        inflight[_picked["id"]] = (lane, _now_s)
                        held[0] = _picked["id"]
                        next_due[_picked["id"]] = _now_s + interval_now.get(_picked["id"], product_gap(_picked))
                        _n = max(1, persist.get("lanes_want", 1))
                        _gap = 0.0 if (_hotr or _n <= 1 or _roles.get(_picked["id"]) == "consume") else min(LANE_STAGGER, persist.get("read_ema", 0.5) / _n)      # page loads of one store start evenly spread
                        _start_at = max(_now_s, persist.get("last_start", 0.0) + _gap)
                        persist["last_start"] = _start_at
                    elif _free:
                        _sleep_for = min(_dues[x["id"]] for x in _free) - _now_s
                    else:
                        _sleep_for = 0.5                   # (v64: nothing this reader may take right now - e.g. the sweeper reads everything)
            _batch_urls = []
            if (_picked is not None and not _from_queue and PREFETCH_N > 1 and store_name in LIGHT_STORES and not os.environ.get("RK_NO_LIGHT")
                    and _picked.get("fetch_mode") == "browser" and _roles.get(_picked["id"], "read") == "read"):
                # v51: if this look can be the lighter kind, line up the other due products that can be too and ask for ALL of them at once
                # from the open tab (each request starts a little after the one before): a reader then covers several products in the time
                # one page answer takes. A product keeps its own interval; nothing is drawn, so the PC hardly notices.
                try:
                    _bf = browser.get()
                    _nb = time.time()
                    if (hasattr(_bf, "light_prefetch") and _tab_on_store(_bf, _picked["url"])
                            and _light_ready(_picked, light_st.get(_picked["id"]), _nb)):
                        with claim_lock:
                            _cands = sorted([x for x in live if x["id"] != _picked["id"] and x["id"] not in inflight and _dues[x["id"]] <= _nb
                                             and _roles.get(x["id"], "read") == "read"
                                             and x.get("fetch_mode") == "browser" and _tab_on_store(_bf, x["url"])
                                             and _light_ready(x, light_st.get(x["id"]), _nb)], key=lambda x: _dues[x["id"]])[:PREFETCH_N - 1]
                            for _x in _cands:
                                inflight[_x["id"]] = (lane, _nb)
                                next_due[_x["id"]] = _nb + interval_now.get(_x["id"], product_gap(_x))
                                lane_queue.append(_x["id"])
                        if _cands:
                            _batch_urls = [_picked["url"]] + [x["url"] for x in _cands]
                            persist["batch_reads"] = persist.get("batch_reads", 0) + len(_cands)
                except Exception:
                    _batch_urls = []
            if _picked is None:
                _wl["state"] = "waiting for the next due product"
                if (_roles and lane == 0 and time.time() - real_read_at[0] > SWEEP_IDLE_CLOSE and sweep.state(store_name) == "ok"
                        and (browser._instance is not None or any(getattr(m_, "inst", None) is not None for m_ in getattr(browser, "_members", []) or []))):
                    real_read_at[0] = time.time()
                    try:
                        browser.recycle()          # v64: the sweeper reads this store: the main checker's own browser is closed (opened again when needed)
                        log_fn(f"[sweep] {store_name}: the main checker's own browser was closed - the sweeper reads this store; it opens again when needed.")
                    except Exception:
                        pass
                if _sleep_for >= PARK_MIN_GAP and _can_park(store_name):
                    browser.park()
                if _wake_or_stop(persist, max(0.02, min(_sleep_for, 0.5)), stop_event, _wake_seen):
                    return
                continue
            t = _picked
            _swr = None
            if _roles.get(t["id"]) == "consume":
                # v64: the sweeper's newest answer for this product is handed on (nothing is loaded here); nothing new -> later
                _swr = sweep.FRESH.get(t["id"])
                if _swr is None or _swr["seq"] == sweep_seen.get(t["id"]):
                    next_due[t["id"]] = time.time() + SWEEP_IDLE
                    _wl["state"] = "handing on the sweeper's answers"
                    continue
            # v62: where a reader's time goes (for the diagnostics): one whole round per product, and the parts of it
            _pk_now = time.time()
            if _swr is None:
                real_read_at[0] = _pk_now
                sweep.note_pick(t, lane)
                _lp = persist.setdefault("lane_pick", {})
                if _lp.get(lane):
                    _cy = min(600.0, _pk_now - _lp[lane])
                    persist["cyc_ema"] = _cy if "cyc_ema" not in persist else 0.9 * persist["cyc_ema"] + 0.1 * _cy
                _lp[lane] = _pk_now
            _wl["state"] = f"reading {t['id']}"
            lane_reads[lane] = lane_reads.get(lane, 0) + 1
            if _start_at - time.time() > 0.01:
                if _sleep_or_stop(_start_at - time.time(), stop_event):
                    return
            if _batch_urls:
                _wl["state"] = f"reading {t['id']} and {len(_batch_urls) - 1} more at once"
                try:
                    _bf.light_prefetch(_batch_urls)
                except Exception:
                    pass
            # v59b: a checkout has priority over every other look - the readers wait (at most 2 minutes) until it is over
            _cw = time.time()
            while _swr is None and _ab_readers_pause(store_name) and time.time() - _cw < _ab_pause_max() and not (stop_event and stop_event.is_set()):
                _wl["state"] = "paused - a checkout is running"
                time.sleep(0.5)
            for t in [t]:
                target_id = t["id"]
                t_check = time.time()
                _pre = min(600.0, t_check - _pk_now)
                if _swr is None:
                    persist["pre_ema"] = _pre if "pre_ema" not in persist else 0.9 * persist["pre_ema"] + 0.1 * _pre
                _bpool = browser if (getattr(browser, "_pool", False) and _swr is None) else None
                if _bpool is not None:
                    _bpool.maybe_rotate(log_fn)
                    _wait = _bpool.soonest_ready()
                    _eng_store = _store_key(t["url"])
                    _eng_cover = _eng_store in ENGINE_FALLBACK_STORES and _ab_reader_ok(_eng_store)
                    if _wait > 0 and not hotness.is_hot(target_id, time.time()) and not _eng_cover:
                        # every browser of this store is resting (see _LazyBrowser): asking again with one of them would only repeat what just failed.
                        # The first one that is back decides when this product is looked at next (a product a tracker just alerted for is still looked at).
                        # v51: not for the whole store and not for a minute: THIS reader asks again soon (3 s, 6 s ... at most SKIP_WAIT_MAX) with whichever
                        # of its browsers is back first; the store's other readers have browsers of their own and keep reading meanwhile.
                        lane_net["skips"] += 1
                        lane_backoff[target_id] = time.time() + min(_wait, SKIP_WAIT_MAX, 3.0 * min(lane_net["skips"], 10)) + 0.5
                        if report:
                            report("target", target_id, checked_at=time.time(), note=f"this reader's browsers are all resting; the first is back in {_fmt_wait(_wait)} (the other readers carry on)")
                        continue
                lane_net["skips"] = 0
                _eng_tried = False
                if _swr is not None:
                    # v64: the sweeper's answer (the store's own data for this product, or its whole page) - read like any other answer
                    text, err = _swr["text"], None
                    api_mode, light_mode, eng_done, _eng_tried = True, False, True, True
                    data_ts = _swr["at"]
                    is_bb = _store_key(t["url"]) == "bestbuy" and t.get("sku")
                    _st_key = _store_key(t["url"])
                    sweep_seen[target_id] = _swr["seq"]
                    next_due[target_id] = time.time() + SWEEP_IDLE
                    if report:
                        report("target", target_id, engine="buying browser")
                for _try in range(0 if _swr is not None else 3):
                    api_mode = False
                    light_mode = False
                    data_ts = None
                    eng_done = False
                    if _store_key(t["url"]) == "bestbuy" and not t.get("sku"):
                        _bb_learn_sku(t, log_fn, report)            # v59b: a new Best Buy link learns its product number at once
                    is_bb = _store_key(t["url"]) == "bestbuy" and t.get("sku")
                    _st_key = _store_key(t["url"])
                    _pool_resting = _bpool is not None and _bpool.soonest_ready() > 0
                    if not _eng_tried and _ab_reader_ok(_st_key) and ((_st_key in ENGINE_FIRST_STORES and _eng_first_ok(_st_key)) or (_pool_resting and _st_key in ENGINE_FALLBACK_STORES)):
                        _eng_tried = True
                        if is_bb:
                            text, err = _bb_engine_fetch(t, live, log_fn)
                            data_ts = _BBE.get("ts_done")
                            api_mode = True
                        else:
                            text, err = _ab_page_fetch(t["url"], _st_key)
                        eng_done = bool(text and not err and text.strip())
                        if eng_done and not is_bb:
                            # only a page that really shows the stock counts (a human-check page or a page without the stock goes to the other browsers)
                            if human_check_reason(text) or detect_availability(text, t["url"]) == "UNKNOWN":
                                eng_done = False
                                _eng_unreadable(_st_key, log_fn)
                            else:
                                _ENG_UNREAD.setdefault(_st_key, [0, 0.0])[0] = 0
                    bb_key = _bestbuy_key() if is_bb else None
                    if is_bb and _BBP["mode"] == "pages" and time.time() >= _BBP["pages_until"]:
                        _BBP["mode"] = "json"
                        interval_now.pop(target_id, None)
                        log_fn("[info] Best Buy: trying the small data request again.")
                    if eng_done:
                        pass
                    elif bb_key:
                        api_mode = True
                        text, err = _bestbuy_api_fetch(t, bb_key,
                                                       [str(x["sku"]) for x in live if x.get("sku")], log_fn)
                        data_ts = _BB.get("ts_done")
                    elif is_bb and _bb_light_ok() and _BBP["mode"] == "json":
                        light_mode = True
                        text, err = _bestbuy_page_fetch(t, live, browser, log_fn)
                        data_ts = _BBP.get("ts_done")
                    elif is_bb and _bb_light_ok() and _BBP["mode"] == "pages":
                        interval_now[target_id] = max(interval_now.get(target_id, 0), BB_PAGES_EVERY)
                        next_due[target_id] = time.time() + interval_now[target_id]
                        text, err = browser.get().fetch(t["url"])
                    elif _store_key(t["url"]) == "bestbuy" and not t.get("sku"):
                        # v46: a Best Buy link with no product number (marketplace listings) can only be read as a whole page, which Best Buy often
                        # refuses to a steered browser (HTTP/2 error). Looked at gently - once every BB_NOSKU_EVERY seconds - so it costs little.
                        interval_now[target_id] = max(interval_now.get(target_id, 0), BB_NOSKU_EVERY)
                        next_due[target_id] = time.time() + interval_now[target_id]
                        text, err, smart_ts = _smart_read(t, browser, light_st.setdefault(target_id, _light_state("bestbuy")), log_fn)
                        data_ts = smart_ts
                    elif lane > 0 and store_name == "target":
                        # an extra Target reader (only working while the all-products request does not): the whole page, drawn
                        _h, err = browser.get().fetch(t["url"])
                        text = (_RENDERED + _h) if (_h and not err) else _h
                    elif t.get("fetch_mode") == "browser":
                        text, err, smart_ts = _smart_read(t, browser,
                                                          light_st.setdefault(target_id, _light_state(_store_key(t["url"]))),
                                                          log_fn)
                        data_ts = smart_ts
                    elif _store_key(t["url"]) == "target":
                        text, err = _target_fetch(t["url"], log_fn, browser)
                        if getattr(_TBL, "served", False):
                            api_mode = True
                            data_ts = _TB.get("ts_done")
                        elif not _TGT["tmpl"]:
                            # no small request works right now, so each look is a whole page (heavy on the PC):
                            # look less often until a small request works again
                            next_due[target_id] = max(next_due[target_id], time.time() + TARGET_PAGES_EVERY)
                    else:
                        text, err = fetch(t["url"])
                    # v58: the store's own browsers could not read it: the buying browser reads it instead (once per look)
                    if not eng_done and not _eng_tried and (err or not (text and text.strip())) and _st_key in ENGINE_FALLBACK_STORES \
                            and _ab_reader_ok(_st_key) and not any(k in str(err or "") for k in LOCAL_NET_ERRORS):
                        _eng_tried = True
                        if is_bb:
                            _t2, _e2 = _bb_engine_fetch(t, live, log_fn)
                        else:
                            _t2, _e2 = _ab_page_fetch(t["url"], _st_key)
                        if _t2 and not _e2 and _t2.strip() and (is_bb or not human_check_reason(_t2)):
                            text, err, eng_done = _t2, None, True
                            if is_bb:
                                api_mode, data_ts = True, _BBE.get("ts_done")
                    if eng_done:
                        if report:
                            report("target", target_id, engine="buying browser")
                        break
                    # v38: a pool store (Target / Walmart / Best Buy) whose read failed, could not be read or showed a human-check page is
                    # asked again AT ONCE with the next ready browser; the one that failed sits out for a while (see _LazyBrowser).
                    if _bpool is None or _try >= 2:
                        break
                    _bk = human_check_reason(text) if (not err and text) else None
                    _empty = (not err) and not (text and text.strip())
                    if not err and not _bk and not _empty:
                        _bpool.note_result(True)
                        break
                    if err and any(k in str(err) for k in LOCAL_NET_ERRORS):
                        break                      # the PC's own internet is down: another browser cannot fix that
                    if light_mode:
                        if _BBP.pop("switched", False):
                            continue               # Best Buy's helper already switched browsers: ask again
                        break
                    if _bpool.note_result(False, why=_bk or err or "empty answer", block=bool(_bk), log=log_fn):
                        continue
                    break

                resp_ts = time.time()
                if _swr is None:
                    _fx = min(600.0, resp_ts - t_check)
                    persist["fetch_ema"] = _fx if "fetch_ema" not in persist else 0.9 * persist["fetch_ema"] + 0.1 * _fx
                    _dur = min(30.0, resp_ts - t_check)
                    persist["read_ema"] = _dur if "read_ema" not in persist else 0.8 * persist["read_ema"] + 0.2 * _dur
                wipe_to = (light_st.get(target_id) or {}).pop("wipe_to", None)
                if wipe_to:
                    last_oos_ts[target_id] = wipe_to
                if not err and data_ts and 0 <= resp_ts - data_ts < 60 and (api_mode or light_mode or t.get("fetch_mode") == "browser"):
                    resp_ts = data_ts      # the moment the data was really read, not when we looked at it again

                # A response with no exception but zero actual content is
                # NOT "loaded fine" — real pages aren't empty. This is far
                # more likely a soft rate-limit or silent block (especially
                # if it starts happening after hours of normal polling)
                # than a page that genuinely has nothing on it. Treat it
                # the same as a connection failure — retry with backoff and
                # try browser mode — rather than the one-shot "confirmed,
                # this page has no data" verdict meant for pages that
                # return real, substantial content with no usable fields.
                if not err and not (text and text.strip()):
                    err = "empty response (0 bytes) — likely a soft rate-limit, not a real empty page"
                    text = None

                # A "prove you are human" page (press-and-hold etc.). We never
                # try to solve or get around these. The one honest response
                # is to check less often: this store is paused for a while,
                # then resumes at a slower pace, and the diagnostics record
                # the pace so we learn what each store tolerates.
                _why_block = human_check_reason(text) if not err else None
                if _swr is None and (_why_block or (err and re.search(r"\b(403|429|435)\b|ERR_HTTP2_PROTOCOL_ERROR", str(err)))
                                     or (err and sweep.resting(store_name))):
                    # v64: (while the store's sweeper rests: its other readers stop too). While it rests, ANY failed read counts: a store
                    # that refuses often answers with a small page that is not recognisable as a refusal ("page did not load") - reading
                    # on would only keep the store's block going
                    sweep.note_lane_refused(store_name, _why_block or err)
                if _why_block:
                    blocks[target_id] = blocks.get(target_id, 0) + 1
                    lane_blocks[target_id] = lane_blocks.get(target_id, 0) + 1
                    base = product_gap(t)
                    cur = interval_now.get(target_id, base)
                    # v51: the product is slowed for everybody only when a SECOND reader (another browser) is shown the page too; one reader's
                    # page says something about that browser, not about the product
                    _blk = persist.setdefault("block_lanes", {}).setdefault(target_id, {})
                    _blk[lane] = time.time()
                    _many = len([1 for _ln, _tt in _blk.items() if time.time() - _tt < 600]) >= 2
                    if _many or persist.get("lanes_want", 1) <= 1:
                        interval_now[target_id] = min(120.0, max(10.0, cur * 2))
                    cooldown = BLOCK_PROBE[min(len(BLOCK_PROBE), max(1, lane_blocks[target_id])) - 1] + BLOCK_PROBE_SPREAD * lane
                    _pb_block(persist, target_id, lane, _engine_kind(browser), time.time() + cooldown)
                    if _bpool is not None:
                        cooldown = max(cooldown, min(BLOCK_PAUSE_MAX, int(_bpool.soonest_ready())))     # every browser is resting: wait for the first one back
                    last_block_at[target_id] = time.time()
                    if persist.get("lanes_want", 1) <= 1:
                        backoff_until[target_id] = time.time() + cooldown          # the only reader: the product waits
                    else:
                        lane_backoff[target_id] = time.time() + cooldown          # v51: this reader's pause; the other readers (their own browsers) carry on
                    log_fn(f"[block] '{target_id}' showed a 'prove you are human' page (time #{blocks[target_id]}; {_why_block}) "
                           f"while checking every {cur:g}s. This reader leaves this product alone for {cooldown // 60} min, then "
                           f"resumes every {interval_now.get(target_id, cur):g}s; the store's other readers (other browsers) carry on. (Not trying to get around the check.)")
                    if t.get("fetch_mode") != "browser" and _store_key(t["url"]) in ("walmart", "amazon", "gamestop", "bestbuy"):
                        # plain requests are what this store dislikes; a normal browser window (as the other
                        # products of this store already use) is the way a person would look at the page
                        t["fetch_mode"] = "browser"
                        log_fn(f"[info] '{target_id}': switching from plain requests to the browser for the next checks "
                               f"(same as the other {_store_key(t['url'])} products).")
                    if report:
                        report("target", target_id, status="BLOCKED", checked_at=time.time(),
                               fetch_mode=t.get("fetch_mode", "http"), blocked_times=blocks[target_id],
                               interval_now=interval_now.get(target_id, base), last_block_utc=datetime.now(timezone.utc).isoformat(),
                               block_why=_why_block, browser=getattr(getattr(browser, "_instance", None), "engine", None))
                    continue

                if not err and text and not _why_block:
                    try:
                        _pb_ok(persist, target_id, lane, _engine_kind(browser))
                        if lane_blocks.get(target_id) and time.time() - last_block_at.get(target_id, 0) >= BLOCK_RECOVER_SEC:
                            lane_blocks[target_id] = max(0, lane_blocks[target_id] - 1)       # a quiet stretch: the next probe interval is one step shorter again
                    except Exception:
                        pass
                if not err and text and target_id in interval_now and not is_bb \
                        and time.time() - last_block_at.get(target_id, 0) >= BLOCK_RECOVER_SEC:
                    # a quiet stretch after a block: check faster again, one step at a time (it must not stay slow for the whole session)
                    _base = product_gap(t)
                    _new = max(_base, interval_now.get(target_id, _base) / 2)
                    last_block_at[target_id] = time.time()
                    blocks[target_id] = max(0, blocks.get(target_id, 0) - 1)
                    if _new <= _base * 1.01:
                        interval_now.pop(target_id, None)
                        log_fn(f"[info] '{target_id}': no block for a while - back to checking every {_base:g}s.")
                    else:
                        interval_now[target_id] = _new
                        log_fn(f"[info] '{target_id}': no block for a while - checking every {_new:g}s again.")
                if not err and text and (lane_net["k"] or persist.get("net_store_k")):
                    lane_net["k"] = 0                      # the store answers again: the next hang-up starts with the short rest
                    persist["net_store_k"] = 0

                if err and light_mode:
                    # the light reader does its own resting / retrying; just say UNKNOWN for now
                    status = "UNKNOWN"
                    n_checks[target_id] = n_checks.get(target_id, 0) + 1
                    n_err[target_id] = n_err.get(target_id, 0) + 1
                    if report:
                        report("target", target_id, status=status, checked_at=time.time(), fetch_mode="light",
                               engine="real-chrome (light)", checks=n_checks[target_id], errors=n_err[target_id],
                               avg_seconds_between_checks=round(gap_ema.get(target_id, 0), 2),
                               note=str(err)[:120])
                    continue

                if err and any(c in err for c in ("ERR_HTTP2_PROTOCOL_ERROR", "ERR_CONNECTION_RESET",
                                                  "ERR_CONNECTION_CLOSED", "ERR_EMPTY_RESPONSE")):
                    # The site hung up on this reader. v51: only THIS reader rests (briefly, 10 s doubling to 80 s) and it comes back with a
                    # different browser; the store's other readers keep reading with theirs. The whole store rests only when most of its readers
                    # were hung up within a minute (then 30 s, doubling to 4 min) - before v51 one hang-up stopped the whole store for 1-10 minutes.
                    k = lane_net["k"]
                    rest = min(NET_REST_MAX, NET_REST_BASE * (2 ** min(k, 3)))
                    lane_net["k"] = k + 1
                    _nh = persist.setdefault("net_hits", {})
                    _nh[lane] = time.time()
                    _hit = len([1 for _tt in _nh.values() if time.time() - _tt < 60])
                    _all = max(1, persist.get("lanes_want", 1))
                    _store_rest = 0.0
                    if _all <= 1 or _hit >= max(2, (_all + 1) // 2):
                        _sk = persist.get("net_store_k", 0)
                        _store_rest = min(NET_STORE_REST_MAX, NET_STORE_REST_BASE * (2 ** min(_sk, 3)))
                        persist["net_store_k"] = _sk + 1
                        for x in targets:
                            backoff_until[x["id"]] = time.time() + _store_rest
                    lane_rest_until[0] = time.time() + rest
                    if _bpool is None and hasattr(browser.get(), "rotate"):
                        try:
                            browser.get().rotate("hung up")       # a different kind of browser next time (Chrome <-> Edge <-> the built-in one)
                        except Exception:
                            pass
                    if lane_net["k"] <= 2 or lane_net["k"] % 10 == 0:
                        log_fn(f"[block] {store_name}: the site hung up on reader {lane + 1} ({err[:60]}). " +
                               (f"Most readers were hung up, so the whole store rests {_store_rest:.0f} s. " if _store_rest else
                                f"This reader rests {rest:.0f} s and comes back with another browser; the other readers carry on. ") +
                               "(Not trying to push through.)")
                    if report:
                        report("target", target_id, status="UNKNOWN", checked_at=time.time(),
                               fetch_mode=t.get("fetch_mode", "http"), blocked_times=k + 1, interval_now=rest)
                    continue

                if err:
                    fails = warn_state.get(target_id, 0) + 1
                    warn_state[target_id] = fails
                    if fails == 1 or fails % 30 == 0:
                        log_fn(f"[warn] fetch failed for '{target_id}' ({fails}x so far): {err}")

                    if fails == 3 and t.get("fetch_mode") != "browser":
                        # Don't just back off yet — try a real browser
                        # right now, since that's often exactly what a
                        # site that blocks plain requests doesn't block.
                        b_text, b_err = browser.get().fetch(t["url"])
                        if not b_err and not (b_text and b_text.strip()):
                            b_err = "empty response (0 bytes)"
                        if not b_err:
                            log_fn(f"[info] '{target_id}' failed {fails}x via plain requests — "
                                   f"auto-upgraded to browser mode, which works. Continuing with that.")
                            t["fetch_mode"] = "browser"
                            warn_state[target_id] = 0
                            if report:
                                report("target", target_id, fetch_mode="browser", auto_upgraded=True)
                            text, err = b_text, None
                        else:
                            log_fn(f"[info] '{target_id}' failed {fails}x via plain requests; tried a "
                                   f"real browser too, still blocked ({b_err}). Backing off.")

                    if err:
                        fails = warn_state.get(target_id, 0)
                        if fails >= 3:
                            # v51: a failing page is asked for again after 5, 10, 20, 40, 60 s (was 15 s - 5 min). With several readers only THIS
                            # reader waits; the others (their own browsers) keep asking for it.
                            delay = min(60, 5 * (2 ** min(fails - 3, 4)))
                            if persist.get("lanes_want", 1) > 1:
                                lane_backoff[target_id] = time.time() + delay
                            else:
                                backoff_until[target_id] = time.time() + delay
                        status = "UNKNOWN"
                    else:
                        status = detect_availability(text, hint=t["url"])
                        unparseable_state[target_id] = 0
                else:
                    warn_state[target_id] = 0
                    status = detect_availability(text, hint=t["url"])

                # A page that loads fine but never yields a readable status
                # used to be treated as unfixable ("content format problem,
                # browser mode won't help") — that assumption was wrong. A
                # lot of sites inject their real stock data via JavaScript
                # AFTER the initial page arrives, which a plain HTTP fetch
                # never sees but a real rendered browser does. So: actually
                # try the browser before concluding anything is unfixable.
                if (status == "UNKNOWN" and not err and t.get("fetch_mode") != "browser" and not api_mode and not light_mode
                        and _store_key(t["url"]) != "target"
                        and target_id not in browser_confirmed_unhelpful):
                    b_text, b_err = browser.get().fetch(t["url"])
                    b_status = detect_availability(b_text, hint=t["url"]) if not b_err else "UNKNOWN"
                    if b_status != "UNKNOWN":
                        log_fn(f"[info] '{target_id}' loaded fine via plain requests but had no "
                               f"readable stock data — a real browser DOES find it (the data was "
                               f"likely added by JavaScript after the page first loads). "
                               f"Auto-upgraded to browser mode permanently.")
                        t["fetch_mode"] = "browser"
                        status = b_status
                        unparseable_state[target_id] = 0
                        if report:
                            report("target", target_id, fetch_mode="browser", auto_upgraded=True)
                    else:
                        browser_confirmed_unhelpful.add(target_id)
                        log_fn(f"[warn] '{target_id}' loaded fine but has no readable stock data via "
                               f"EITHER plain requests or a real browser — confirmed, not assumed. "
                               f"This page genuinely doesn't publish data this tool can read. Swap "
                               f"this product out via the Products tab.")
                        # Capture real evidence instead of guessing why — this
                        # lands in debug.log, which diagnostics downloads
                        # include, so the actual page content (or lack of it,
                        # or a bot-block page) can be inspected directly
                        # rather than inferred from a one-line error.
                        plain_diag = diagnose(text, hint=t["url"])
                        browser_diag = diagnose(b_text, hint=t["url"])
                        log_fn(f"[diagnostic] '{target_id}' plain-HTTP page: {plain_diag}")
                        log_fn(f"[diagnostic] '{target_id}' browser-rendered page: {browser_diag}")

                # --- method ladder: never sit on a method that isn't working.
                # Evidence from earlier runs: Amazon and Best Buy blocked
                # from the very first check, so after a few bad checks in a
                # row we switch to the next browser (real Chrome, Edge,
                # built-in) and record what each one did.
                if t.get("fetch_mode") == "browser" and not api_mode and not light_mode and browser._instance is not None:
                    bf = browser.get()
                    if err and any(k in str(err) for k in LOCAL_NET_ERRORS):
                        bad_streak[target_id] = 0      # this PC's internet is down: another browser cannot fix that, so don't open one
                    elif status == "UNKNOWN" or err:
                        bad_streak[target_id] = bad_streak.get(target_id, 0) + 1
                        if bad_streak[target_id] >= 3:
                            bad_streak[target_id] = 0
                            why = err or "page loaded but no stock info"
                            if (target_id, getattr(bf, 'engine', 'browser')) not in diag_logged and text:
                                diag_logged.add((target_id, getattr(bf, 'engine', 'browser')))
                                try:
                                    log_fn(f"[diagnostic] '{target_id}' page seen with {getattr(bf, 'engine', 'browser')}: "
                                           f"{diagnose(text, hint=t['url'])}")
                                except Exception:
                                    pass
                            _now = time.time()
                            _h = [x for x in rot_hist.get(target_id, []) if _now - x < ROTATE_WINDOW]
                            rot_hist[target_id] = _h
                            if target_id in browser_confirmed_unhelpful or len(_h) >= (ROTATE_MAX if err else 1):
                                # Switching browsers again would only open yet another browser window, and switching has not
                                # helped so far: keep the current browser and try again later instead of restarting one every minute.
                                if _now - hold_log.get(target_id, 0) > 1800:
                                    hold_log[target_id] = _now
                                    log_fn(f"[info] '{target_id}': still no stock info - not switching browsers again for now "
                                           f"(switching has not helped; it keeps checking with the current browser).")
                            else:
                                _h.append(_now)
                                if _bpool is not None:
                                    nxt = "another ready browser" if _bpool.note_result(False, why=why, soft=True, log=log_fn) else None
                                else:
                                    nxt = bf.rotate(why) if hasattr(bf, "rotate") else None
                                backoff_until.pop(target_id, None)   # new browser: try it right away
                                warn_state[target_id] = 0
                                if _now - last_switch_log.get(target_id, 0) > 60:
                                    last_switch_log[target_id] = _now
                                    log_fn(f"[info] '{target_id}': {why[:80]} - switching browser to "
                                           f"{nxt or 'none available'}. History: {getattr(bf, 'history', [])[-4:]}")
                    else:
                        bad_streak[target_id] = 0
                        if worked_with.get(target_id) != getattr(bf, 'engine', 'browser'):
                            worked_with[target_id] = getattr(bf, 'engine', 'browser')
                            log_fn(f"[info] '{target_id}': reading stock OK using {getattr(bf, 'engine', 'browser')}.")
                    if report:
                        ls_ = light_st.get(target_id) or {}
                        report("target", target_id, engine=getattr(bf, 'engine', 'browser'), tried=list(getattr(bf, "history", [])[-6:]),
                               light_reads=ls_.get("n_light", 0), full_reads=ls_.get("n_full", 0),
                               light_state=("paused" if time.time() < ls_.get("off_until", 0) else
                                            "on" if ls_.get("ok", 0) >= LIGHT_MIN_OK else "comparing"))

                # Price check. Trackers only alert on restocks at (or near) the
                # normal price, so "in stock" from an individual reseller at a
                # much higher price must NOT count as a restock. Each product
                # has a `max_price` in targets.yaml; above it we treat the
                # product as still out of stock.
                price = None
                high_price = False
                price_unreadable = False
                max_price = t.get("max_price")
                low_unconfirmed = False
                if status == "IN_STOCK" and text:
                    price = detect_price(text, t["url"])
                    if price is not None and max_price and _price_not_believable(t, price):
                        # v58b: a price far below the product's normal price is CHECKED, not ignored (a real bargain must not be missed,
                        # a number from another item on the page must not alert): a second, independent read decides.
                        _vp, _vhow = _verify_low_price(t, text, price, browser)
                        if _vp is not None and abs(_vp - price) <= max(0.05, 0.02 * price):
                            log_fn(f"[price] '{target_id}': UNUSUALLY LOW price ${price:.2f} ({_price_ref(t)}) CONFIRMED by {_vhow} - it counts.")
                        elif _vp is not None:
                            log_fn(f"[price] '{target_id}': the first read said ${price:.2f}, but {_vhow} says ${_vp:.2f} - using ${_vp:.2f}. "
                                   f"Clues of the first read: {price_clues(text, t['url'])[:300]}")
                            price = _vp
                        else:
                            low_unconfirmed = True
                            log_fn(f"[price] '{target_id}': UNUSUALLY LOW price ${price:.2f} ({_price_ref(t)}) could not be confirmed yet ({_vhow}) - "
                                   f"it is checked again at the next look (seconds).")
                    if max_price:
                        if price is None and "amazon." in t["url"].lower() and amazon_other_sellers_only(text):
                            # only "See All Buying Options" (other sellers), no Add to Cart and no
                            # price of its own: nobody sells it at a normal price right now. That is
                            # NOT a restock, and it counts as out of stock for timing purposes.
                            status = "OUT_OF_STOCK"
                            high_price = True
                            if last_price_note.get(target_id) != "others":
                                last_price_note[target_id] = "others"
                                log_fn(f"[price] '{target_id}' shows only other sellers' offers (no Add to Cart, no "
                                       f"price of its own) - treated as NOT restocked.")
                        elif price is None:
                            status = "UNKNOWN"
                            price_unreadable = True
                            n = price_unread.get(target_id, 0) + 1
                            price_unread[target_id] = n
                            if n == 1 or n % 100 == 0:
                                log_fn(f"[price] '{target_id}' looks in stock but its price could not be read "
                                       f"({n}x) - not counting it, because it might be a reseller's price.")
                            if n in (1, 3, 10) or n % 20 == 0:
                                log_fn(f"[price-clues] '{target_id}' (read #{n}): {price_clues(text, t['url'])[:700]}")
                        elif low_unconfirmed:
                            status = "UNKNOWN"
                            price_unreadable = True
                        elif price > float(max_price):
                            status = "OUT_OF_STOCK"
                            high_price = True
                            if last_price_note.get(target_id) != "high":
                                last_price_note[target_id] = "high"
                                log_fn(f"[price] '{target_id}' is listed at ${price:.2f}, above the ${float(max_price):.2f} limit - "
                                       f"treated as NOT restocked (reseller / marked-up listing).")
                        else:
                            price_unread[target_id] = 0
                            if last_price_note.get(target_id) != "ok":
                                last_price_note[target_id] = "ok"
                                log_fn(f"[price] '{target_id}' is in stock at ${price:.2f}, within the ${float(max_price):.2f} limit.")

                # Keep real page copies (first of each kind) for diagnosing misreads.
                if text:
                    if status == "IN_STOCK":
                        kind = "in_stock_ok_price"
                    elif high_price:
                        kind = "in_stock_HIGH_price"
                    elif price_unreadable:
                        kind = "in_stock_price_unreadable"
                    elif status == "UNKNOWN":
                        kind = "unreadable"
                    else:
                        kind = "out_of_stock"
                    samples.save(target_id, kind, text, f"status={status} price={price} url={t['url']}")
                elif err:
                    samples.save(target_id, "fetch_error", f"<pre>{err}</pre>", f"url={t['url']}")

                n_checks[target_id] = n_checks.get(target_id, 0) + 1
                if err:
                    n_err[target_id] = n_err.get(target_id, 0) + 1
                lc = last_check_start.get(target_id)
                last_check_start[target_id] = t_check
                if lc:
                    gap_ema[target_id] = (gap_ema.get(target_id, now_gap(lc, t_check)) * 0.9
                                          + now_gap(lc, t_check) * 0.1)

                try:
                    sd = stats.setdefault(target_id, {"IN": 0, "OUT": 0, "UNK": 0, "ERR": 0, "n": 0, "maxgap": 0.0, "last_ok": None})
                    sd["n"] += 1
                    if err:
                        sd["ERR"] += 1
                    elif status == "IN_STOCK":
                        sd["IN"] += 1
                    elif status == "OUT_OF_STOCK":
                        sd["OUT"] += 1
                    else:
                        sd["UNK"] += 1
                    if not err and status != "UNKNOWN":
                        if sd["last_ok"]:
                            sd["maxgap"] = max(sd["maxgap"], t_check - sd["last_ok"])
                        sd["last_ok"] = t_check
                except Exception:
                    pass
                try:
                    recon.note_read(target_id, status, price, err)
                    if recon.watching(target_id):
                        recon.watch_note(target_id, {
                            "item": target_id, "status": status, "price": price, "err": err,
                            "store_raw": (_BBP.get("last_raw") if store_name == "bestbuy" else None),
                            "stock_fields": recon.key_values(text or "", 40),
                            "page_words": recon.phrases(text or "", 12),
                            "text": recon._clean(text or "")[:1500]})
                except Exception:
                    pass
                if report:
                    _en = ("buying browser" if locals().get("eng_done") else
                           "store data request" if (locals().get("api_mode") or t.get("fetch_mode") != "browser") else _engine_kind(browser))
                    report("target", target_id, status=status, checked_at=time.time(),
                           fetch_mode=t.get("fetch_mode", "http"), engine=_en,
                           price=price, high_price=high_price,
                           read_by=(str(_swr.get("src") or "") if _swr is not None else f"{_en} (this reader's own read)")[:120],
                           checks=n_checks[target_id], errors=n_err.get(target_id, 0),
                           avg_seconds_between_checks=round(gap_ema.get(target_id, 0), 2))
                try:
                    if _swr is not None:
                        if _swr.get("kind") == "page":
                            sweep.note_verdict(t, status if not price_unreadable else "IN_STOCK")      # (a page without the stock: see sweep.py)
                    elif not err and status != "UNKNOWN":
                        sweep.note_read(t)                 # v64: read by this reader itself: the sweeper need not read it again at once
                except Exception:
                    pass

                if status == "UNKNOWN" and not err:
                    streak = unparseable_state.get(target_id, 0) + 1
                    unparseable_state[target_id] = streak
                    if streak > 1 and streak % 50 == 0:
                        log_fn(f"[warn] '{target_id}' still unreadable after {streak} checks "
                               f"(confirmed: a real browser doesn't find data here either).")

                # The product picture for the table: the page just loaded says where it is (no extra request; looked at once per product)
                try:
                    if text and len(text) > 5000 and time.time() - pic_seen.get(target_id, 0.0) > 1800:
                        pic_seen[target_id] = time.time()
                        thumbs.note_page(matrix.key_of(t), _store_key(t["url"]), t["url"], text)
                        linkcheck.note(t, text, log_fn, switch_off=lambda _id: (matrix.set_cell(_id, False), matrix.bump()))       # v46: is this really the product of its row?
                except Exception:
                    pass

                # Pacing: do not work the PC hard for a product that cannot be read, or that is quiet and not expected to restock.
                try:
                    if status == "UNKNOWN" and not err:
                        unread_run[target_id] = unread_run.get(target_id, 0) + 1
                    elif status != "UNKNOWN":
                        unread_run[target_id] = 0
                    _fl, _st = hotness.pace_floor(_store_key(t["url"]), t.get("fetch_mode", "http"), status,
                                                  unread_run.get(target_id, 0), target_id, hist,
                                                  heavy=bool(text and text.startswith(_RENDERED)), extra=products.is_extra(t))
                    if _fl:
                        next_due[target_id] = max(next_due[target_id], time.time() + _fl)
                    _pk = (_st, round(_fl) if _st == "calm" else 0)
                    if _pk != pace_state.get(target_id, ("normal", 0)):
                        pace_state[target_id] = _pk
                        _msg = {"calm": "quiet and nothing expected right now - looking every %gs (full speed again when a tracker alerts, "
                                        "it is in stock, or the history says a restock is due)" % (_fl or hotness.CALM_EVERY),
                                "unreadable": "cannot be read - looking once every %gs instead of constantly" % hotness.UNREADABLE_EVERY,
                                "instock": "in stock - looking every %gs (full speed again when a tracker alerts)" % (_fl or hotness.EXTRA_INSTOCK_EVERY),
                                "hot": "full speed", "expected": "full speed (history shows restocks around this time of day)",
                                "normal": "normal speed"}.get(_st, _st)
                        log_fn(f"[pace] '{target_id}': {_msg}")
                        if report:
                            report("target", target_id, pace=_st)
                except Exception:
                    pass

                prev = last_status[target_id]
                # Target's drawn page (used only while no small request works) can show "Add to cart" for a
                # moment before the stock has loaded: believe an IN-STOCK read from it only on the second
                # look in a row, so a half-loaded page can never create a false restock.
                _pend = persist.setdefault("tgt_pending", {})
                if text and text.startswith(_RENDERED) and status == "IN_STOCK" and prev != "IN_STOCK":
                    if not _pend.get(target_id):
                        _pend[target_id] = True
                        log_fn(f"[info] '{target_id}': Target's drawn page says in stock - waiting for a second look "
                               f"before counting it (that page can show 'Add to cart' before the stock has loaded).")
                        status = "UNKNOWN"
                        next_due[target_id] = time.time() + 1.5      # the second look comes at once, not a full cycle later
                else:
                    _pend[target_id] = False
                if status != "UNKNOWN" and text and (prev is None or (status == "IN_STOCK" and prev != "IN_STOCK")):
                    try:
                        log_fn(f"[evidence] '{target_id}' reads {status}{' (price $%.2f)' % price if price else ''}: {status_evidence(text, t['url'])[:700]}")
                    except Exception:
                        pass
                # v50: several readers (each its own browser) can disagree for a few seconds while a store changes. A product that read IN STOCK a
                # moment ago must read OUT twice before it counts as sold out - otherwise IN / OUT / IN would be logged as two restocks.
                _flicker = False
                if status == "IN_STOCK":
                    persist.setdefault("last_in_ts", {})[target_id] = resp_ts
                    out_pending.pop(target_id, None)
                elif (status == "OUT_OF_STOCK" and prev == "IN_STOCK" and persist.get("lanes_want", 1) > 1 and not out_pending.get(target_id)
                      and resp_ts - persist.setdefault("last_in_ts", {}).get(target_id, 0.0) < FLICKER_WINDOW):
                    out_pending[target_id] = resp_ts
                    next_due[target_id] = min(next_due.get(target_id, 0.0), time.time() + 1.0)
                    _flicker = True
                if status == "OUT_OF_STOCK" and not _flicker:
                    last_oos_ts[target_id] = resp_ts
                if status != "UNKNOWN" and status != prev and not _flicker:
                    if prev is not None:
                        recon.force(t["url"], 2 if status == "IN_STOCK" else 1)   # record the next page loads too
                    if prev is not None and status == "IN_STOCK":
                        ts = datetime.fromtimestamp(resp_ts, timezone.utc).isoformat()
                        w0 = last_oos_ts.get(target_id)
                        w0_iso = datetime.fromtimestamp(w0, timezone.utc).isoformat() if w0 else ""
                        wsec = round(resp_ts - w0, 3) if w0 else ""
                        log_fn(f"[{ts}] RESTOCK DETECTED: {target_id} (happened within the last {wsec}s)" + (f" price ${float(price):.2f}" if price else ""))
                        samples.save(target_id, "RESTOCK_moment", text or "", f"price={price} window={wsec}", force=True)
                        try:
                            recon.save_extra(target_id, "restock_moment", {
                                "price": price, "window_sec": wsec, "status": status,
                                "stock_fields": recon.key_values(text or "", 40),
                                "page_words": recon.phrases(text or "", 15),
                                "store_raw": (_BBP.get("last_raw") if store_name == "bestbuy" else None),
                                "text": recon._clean(text or "")[:6000]})
                        except Exception:
                            pass
                        if not append_csv_row(out_path, [ts, target_id, "RESTOCK", t["url"], w0_iso, wsec, price if price else ""]):
                            log_fn(f"[error] {out_path} could not be written to (is it open in Excel?). This restock row is "
                                   f"saved in {out_path}.pending and is added automatically when the file is free. "
                                   f"Close the file in Excel to fix it.")
                    last_status[target_id] = status
    except KeyboardInterrupt:
        log_fn("Stopped.")
    finally:
        _release()
        _drop_queue()
        browser.close()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", required=True, help="targets.yaml path")
    ap.add_argument("--out", default="ground_truth.csv")
    args = ap.parse_args()

    import yaml
    with open(args.config) as f:
        cfg = yaml.safe_load(f)
    run(cfg["targets"], args.out)


if __name__ == "__main__":
    main()
