"""Speed versus PC load (v51).

The owner's rule: nothing may be SLOWED to save the PC (every reader keeps reading as fast as its product allows). If the PC
cannot carry everything, the program uses FEWER READERS - the extra browsers that read a store at the same time - until it fits.
How much of the PC the program may use is one setting with four named levels, shown on the page together with what each level
costs and gives on THIS PC (numbers measured live; estimates until the first measurement).

What this module does
  * measures what the program (python + all its browsers) really uses, every few seconds (psutil);
  * learns the cost of one reader (processor share and memory) from that measurement;
  * works out how many extra readers fit under the chosen level's ceilings (processor % of the whole PC, memory % of the PC's memory);
  * hands the extra readers out in a fixed order (the same order they start in): `lane_allowed(store, lane)`;
  * starts them GRADUALLY (one more every RAMP_EVERY seconds while the measurements stay under the ceilings) so a start can never
    flood the PC, and takes one away at once when a ceiling is passed.
Every store's first (main) reader is never taken away by this module.
"""
import os
import threading
import time

VERSION = "v104"

# name -> (label, processor ceiling as a share of the WHOLE PC, memory ceiling as a share of the PC's memory, one line for the page)
PROFILES = {
    "full": ("Full speed", 0.85, 0.65, "Up to 4 readers per store (3 at Target). Uses most of the PC; fine for an idle PC, can make a game stutter."),
    "balanced": ("Balanced (recommended)", 0.60, 0.45, "Up to 3 readers per store. Leaves room for everything else you do."),
    "light": ("Light", 0.35, 0.30, "Up to 2 readers per store. Use it when the PC is busy with other work."),
    "minimum": ("Minimum", 0.15, 0.18, "One reader per store. Slowest; the PC will barely notice it."),
}
DEFAULT_PROFILE = "balanced"
# The fastest ONE product may be looked at (all readers together), per level; None = each store's own pace from the table (1 - 15 s).
# Until v50 every product carried its own minimum gap (5 s Amazon / GameStop, 15 s Walmart, 2.5 s Best Buy, 1 s Target): however many readers there were, a
# product was never looked at faster than that, which alone puts the average delay of a restock at half of it. A level now lowers that floor.
PRODUCT_GAP = {"full": 1.0, "balanced": 2.0, "light": 5.0, "minimum": None}
MAX_LANE = {"full": 99, "balanced": 2, "light": 1, "minimum": 0}      # the most extra readers ONE store may have at each level (0 = only its main reader)
DEFAULT_READER_CPU = 25.0        # % of ONE core one reader uses (until measured)
DEFAULT_READER_GB = 0.35         # memory of one reader (until measured)
MIN_READER_CPU = 4.0
MIN_READER_GB = 0.12
SAMPLE_EVERY = 5.0
RAMP_EVERY = 8.0                 # seconds between two extra readers being switched on
SHED_EVERY = 5.0                 # seconds between two extra readers being taken away while a ceiling is passed
OVER_CPU = 1.10                  # passed = this much over the ceiling (the cost estimate lags a little)
OVER_MEM = 1.05
UNDER = 0.92                     # a new reader is only added while both measurements are under this share of their ceiling

_L = threading.RLock()
_S = {
    "profile": DEFAULT_PROFILE,
    "wish": {},                  # store -> readers the program wants there (main + extra)
    "order": [],                 # [(store, lane)] extra readers in the order they are given out
    "n_allowed": 0,              # how many of `order` may run now
    "at_ramp": 0.0, "at_shed": 0.0, "at_tick": 0.0, "at_sample": 0.0,
    "cpu_hist": [], "mem_hist": [],
    "cost_cpu": None, "cost_gb": None,
    "meas_cpu": None, "meas_gb": None,
    "active": 0, "mains": 0,
    "why": "", "limit_by": "",
    "cores": None, "ram_gb": None,
    "psutil_ok": None,
    "procs": {},
}


def _cores():
    if _S["cores"]:
        return _S["cores"]
    n = None
    try:
        import psutil
        n = psutil.cpu_count(logical=True)
    except Exception:
        n = None
    n = n or (os.cpu_count() or 2)
    _S["cores"] = max(1, int(n))
    return _S["cores"]


def _ram():
    if _S["ram_gb"]:
        return _S["ram_gb"]
    r = None
    try:
        import psutil
        r = psutil.virtual_memory().total / 1073741824.0
    except Exception:
        r = None
    if r is None:
        try:
            import cpu_monitor
            r = cpu_monitor.ram_gb()
        except Exception:
            r = None
    _S["ram_gb"] = r or 8.0
    return _S["ram_gb"]


def set_pc(cores=None, ram_gb=None):
    """For tests: pretend the PC is this big."""
    with _L:
        if cores:
            _S["cores"] = int(cores)
        if ram_gb:
            _S["ram_gb"] = float(ram_gb)


def profile():
    return _S["profile"]


def set_profile(name):
    with _L:
        _S["profile"] = name if name in PROFILES else DEFAULT_PROFILE
        _S["at_ramp"] = 0.0
    return _S["profile"]


def ceilings(name=None):
    """-> (processor ceiling in % of ONE core, memory ceiling in GB) for a level on this PC."""
    _lab, cpu_share, mem_share, _t = PROFILES.get(name or _S["profile"], PROFILES[DEFAULT_PROFILE])
    return cpu_share * _cores() * 100.0, mem_share * _ram()


def _order(name=None):
    """The extra readers that this level allows at all, in the order they are given out."""
    ml = MAX_LANE.get(name or _S["profile"], 99)
    return [(s, l) for (s, l) in _S["order"] if l <= ml]


def product_gap():
    """-> the fastest one product may be looked at (seconds) under the chosen level, or None to leave each product's own number alone.
    (Best Buy keeps its own pace: it hangs up on faster asking. Tests switch this off with RK_NO_LOADPLAN.)"""
    if os.environ.get("RK_NO_LOADPLAN"):
        return None
    return PRODUCT_GAP.get(_S["profile"])


def set_wishes(wish, mains=None):
    """wish: {store: readers wanted there}. The extra readers (lane 1, 2 ...) are given out one round at a time, the stores that are
    read through a browser first, so every store gets its second reader before any store gets its third."""
    with _L:
        _S["wish"] = dict(wish)
        _S["mains"] = int(mains if mains is not None else len(wish))
        pri = ("walmart", "amazon", "gamestop", "target")
        stores = sorted(wish, key=lambda s: (pri.index(s) if s in pri else len(pri), s))
        order = []
        for rnd in range(1, max(list(wish.values()) or [1])):
            for s in stores:
                if wish[s] > rnd:
                    order.append((s, rnd))
        _S["order"] = order
        _S["n_allowed"] = min(_S["n_allowed"], len(order))


def _tree_usage():
    """-> (processor % of ONE core, memory GB) of this program and all the processes it started; None when it cannot be measured."""
    try:
        import psutil
    except Exception:
        _S["psutil_ok"] = False
        return None
    _S["psutil_ok"] = True
    try:
        me = psutil.Process()
        procs = [me] + me.children(recursive=True)
    except Exception:
        return None
    cpu, mem, seen = 0.0, 0, set()
    live = _S["procs"]
    for p in procs:
        try:
            pid = p.pid
            seen.add(pid)
            q = live.get(pid)
            if q is None:
                q = live[pid] = p
                p.cpu_percent(None)          # first call only starts the clock
                mem += p.memory_info().rss
                continue
            cpu += q.cpu_percent(None)
            mem += q.memory_info().rss
        except Exception:
            continue
    for pid in list(live):
        if pid not in seen:
            live.pop(pid, None)
    return cpu, mem / 1073741824.0


def sample(now=None, usage=None):
    """One measurement (every SAMPLE_EVERY seconds). `usage` = (cpu %, GB) lets a test feed numbers."""
    now = now or time.time()
    with _L:
        if usage is None and now - _S["at_sample"] < SAMPLE_EVERY:
            return
        _S["at_sample"] = now
    u = usage if usage is not None else _tree_usage()
    if u is None:
        return
    try:                                   # v90: how busy the WHOLE PC is (all programs) - a buffer is always kept for your other programs
        if PC_BUSY is not None:
            pcb = PC_BUSY()
        else:
            import psutil
            pcb = psutil.cpu_percent(None)
    except Exception:
        pcb = None
    with _L:
        if pcb is not None:
            _S["pc_hist"] = (_S.get("pc_hist", []) + [float(pcb)])[-6:]
            _S["pc_busy"] = sum(_S["pc_hist"]) / len(_S["pc_hist"])
        _S["cpu_hist"] = (_S["cpu_hist"] + [u[0]])[-6:]          # the last 30 seconds
        _S["mem_hist"] = (_S["mem_hist"] + [u[1]])[-6:]
        _S["meas_cpu"] = sum(_S["cpu_hist"]) / len(_S["cpu_hist"])
        _S["meas_gb"] = _S["mem_hist"][-1]


PARTS = None              # v80: () -> {"cpu": {part: %}, "mb": {part: MB}} (cpu_monitor.parts_now); tests may replace it
PC_FREE = None            # v80: () -> free memory of the whole PC in GB (cpu_monitor.pc_free_gb)
READER_PARTS = ("amazon", "bestbuy", "target", "walmart", "gamestop", "reader")
PC_FREE_RAMP_GB = 6.0     # v80: an extra reader is only added while the PC itself has this much free memory
PC_FREE_SHED_GB = 3.0     #      and one is taken away below this
PC_BUSY = None            # v90: () -> % busy of the whole PC (tests may replace it)
PC_BUSY_SHED = 85.0       # v90 (owner 2026-11-02: "There needs to always be a buffer of CPU room for other programs"): above this the extra
PC_BUSY_RAMP = 70.0       #      readers are taken away one by one, and one is added back only below this - at every speed level


def _parts():
    try:
        if PARTS is not None:
            return PARTS()
        import cpu_monitor
        return cpu_monitor.parts_now()
    except Exception:
        return None


def _pc_free():
    try:
        if PC_FREE is not None:
            return PC_FREE()
        import cpu_monitor
        return cpu_monitor.pc_free_gb()
    except Exception:
        return None


def _costs(active):
    """Cost of one reader, learned slowly.
    v80 (diagnostics 67: "one reader costs 6.3 GB" while the readers' browsers really used about 1 GB each - the buying browser's 14 GB
    and the other buying browsers were counted as readers, so 10 extra readers waited "for room" for good): measured on the READING
    browsers only; everything else (buying browsers, alerts, pages, Python) is a fixed cost taken off the ceiling first."""
    c, g = _S["cost_cpu"], _S["cost_gb"]
    mc, mg = _S["meas_cpu"], _S["meas_gb"]
    pr = _parts()
    if pr is not None and mc is not None and mg is not None:
        rc = sum(v for k, v in pr["cpu"].items() if k in READER_PARTS)
        rg = sum(v for k, v in pr["mb"].items() if k in READER_PARTS) / 1024.0
        _S["fixed_cpu"], _S["fixed_gb"] = max(0.0, mc - rc), max(0.0, mg - rg)
        if active >= 1 and rg > 0:
            nc, ng = max(MIN_READER_CPU, rc / active), max(MIN_READER_GB, rg / active)
            c = nc if c is None else 0.7 * c + 0.3 * nc
            g = ng if g is None else 0.7 * g + 0.3 * ng
            _S["cost_cpu"], _S["cost_gb"] = c, g
        return (c if c is not None else DEFAULT_READER_CPU), (g if g is not None else DEFAULT_READER_GB)
    if active >= 2 and mc is not None and mg is not None and len(_S["cpu_hist"]) >= 3:
        nc = max(MIN_READER_CPU, mc / active)
        ng = max(MIN_READER_GB, mg / active)
        c = nc if c is None else 0.7 * c + 0.3 * nc
        g = ng if g is None else 0.7 * g + 0.3 * ng
        _S["cost_cpu"], _S["cost_gb"] = c, g
    return (c if c is not None else DEFAULT_READER_CPU), (g if g is not None else DEFAULT_READER_GB)


def capacity(name, active=None):
    """How many readers (main + extra, all stores) fit under a level's ceilings on this PC, and which ceiling is the limit."""
    cc, cg = _costs(active if active is not None else _S["active"])
    ceil_cpu, ceil_gb = ceilings(name)
    ceil_cpu, ceil_gb = max(0.0, ceil_cpu - (_S.get("fixed_cpu") or 0.0)), max(0.0, ceil_gb - (_S.get("fixed_gb") or 0.0))     # (v80)
    by_cpu, by_mem = int(ceil_cpu // cc), int(ceil_gb // cg)
    return (min(by_cpu, by_mem), "processor" if by_cpu <= by_mem else "memory", cc, cg)


def tick(active_now, now=None, usage=None):
    """Called about once a second by the stores' reader managers (cheap; does its work every few seconds).
    active_now = number of readers working right now (main + extra)."""
    now = now or time.time()
    with _L:
        if usage is None and now - _S["at_tick"] < 1.0:
            return
        _S["at_tick"] = now
    sample(now, usage)
    with _L:
        _S["active"] = int(active_now)
        n_order = len(_order())
        mains = max(1, _S["mains"])
        cap, by, cc, cg = capacity(_S["profile"], max(1, active_now))
        _S["limit_by"] = by
        fit_extras = max(0, cap - mains)
        target = min(n_order, fit_extras)
        ceil_cpu, ceil_gb = ceilings(_S["profile"])
        mc, mg = _S["meas_cpu"], _S["meas_gb"]
        pf = _pc_free()
        pcb = _S.get("pc_busy")
        over = ((mc is not None and mc > ceil_cpu * OVER_CPU) or (mg is not None and mg > ceil_gb * OVER_MEM) or (pf is not None and pf < PC_FREE_SHED_GB)
                or (pcb is not None and pcb > PC_BUSY_SHED))
        roomy = ((mc is None or mc < ceil_cpu * UNDER) and (mg is None or mg < ceil_gb * UNDER) and (pf is None or pf >= PC_FREE_RAMP_GB)
                 and (pcb is None or pcb < PC_BUSY_RAMP))
        n = _S["n_allowed"]
        why = ""
        if over and n > 0:
            if now - _S["at_shed"] >= SHED_EVERY:
                n -= 1
                _S["at_shed"] = now
                why = "the whole PC is busy (other programs need room)" if (pcb is not None and pcb > PC_BUSY_SHED) else "over the ceiling"
        elif n > target:
            if now - _S["at_shed"] >= SHED_EVERY:
                n -= 1
                _S["at_shed"] = now
                why = "over the level's room"
        elif n < target and roomy and not over:
            if now - _S["at_ramp"] >= RAMP_EVERY:
                n += 1
                _S["at_ramp"] = now
        _S["n_allowed"] = max(0, min(n, n_order))
        if why:
            _S["why"] = why


def lane_allowed(store, lane):
    """May this extra reader work now? (The main reader, lane 0, always may.)"""
    if lane <= 0 or os.environ.get("RK_NO_LOADPLAN"):          # (RK_NO_LOADPLAN: tests only)
        return True
    with _L:
        full = _S["order"]
        if (store, lane) not in full:
            return True                      # not in the plan (e.g. a store added a moment ago): leave it to the other rules
        o = _order()
        try:
            i = o.index((store, lane))
        except ValueError:
            return False                     # this level allows no such reader
        return i < _S["n_allowed"]


def snapshot():
    """Everything the page and the diagnostics show."""
    with _L:
        order = _order()
        allowed = order[:_S["n_allowed"]]
        waiting = order[_S["n_allowed"]:]
        mains = _S["mains"]
        active = _S["active"]
        cc, cg = _costs(max(1, active))
        ceil_cpu, ceil_gb = ceilings()
        cores, ram = _cores(), _ram()
        levels = []
        for key, (lab, cs, ms, txt) in PROFILES.items():
            cap, by, _a, _b = capacity(key, max(1, active))
            total = max(mains, min(cap, mains + len(_order(key))))
            extras = total - mains
            levels.append({
                "key": key, "label": lab, "text": txt, "readers": total, "extra": extras,
                "cpu_pct_pc": round(((_S.get("fixed_cpu") or 0.0) + total * cc) / cores, 0),
                "gb": round((_S.get("fixed_gb") or 0.0) + total * cg, 1), "ceiling_cpu_pc": int(cs * 100), "ceiling_gb": round(ms * ram, 1),
                "limit": by, "current": key == _S["profile"], "gap": PRODUCT_GAP.get(key),
            })
        return {
            "profile": _S["profile"], "levels": levels, "cores": cores, "ram_gb": round(ram, 1),
            "measured": _S["meas_cpu"] is not None,
            "cpu_pct_pc": None if _S["meas_cpu"] is None else round(_S["meas_cpu"] / cores, 0),
            "cpu_cores": None if _S["meas_cpu"] is None else round(_S["meas_cpu"] / 100.0, 1),
            "gb": None if _S["meas_gb"] is None else round(_S["meas_gb"], 1),
            "readers_active": active, "readers_main": mains, "readers_extra_allowed": len(allowed),
            "readers_extra_waiting": len(waiting), "waiting": [f"{s} #{l + 1}" for s, l in waiting],
            "per_reader_cpu_pc": round(cc / cores, 1), "per_reader_cpu_core": round(cc / 100.0, 2), "per_reader_gb": round(cg, 2),
            "ceiling_cpu_pc": int(PROFILES[_S["profile"]][1] * 100), "ceiling_gb": round(ceil_gb, 1),
            "limit_by": _S["limit_by"], "last_cut": _S["why"],
            "fixed_gb": round(_S.get("fixed_gb") or 0.0, 1), "fixed_cpu_core": round((_S.get("fixed_cpu") or 0.0) / 100.0, 1), "pc_free_gb": _pc_free(),
        }


def text():
    """One plain sentence for the diagnostics."""
    s = snapshot()
    now_ = ("not measured yet" if s["cpu_pct_pc"] is None else
            f"the program uses {s['cpu_pct_pc']:.0f}% of the PC's processor ({s['cpu_cores']} of {s['cores']} cores) and {s['gb']} GB of memory")
    lv = PROFILES[s["profile"]][0]
    return (f"Speed setting: {lv}. {now_}. {s['readers_active']} readers working "
            f"({s['readers_main']} main + {s['readers_extra_allowed']} extra); {s['readers_extra_waiting']} extra readers are waiting for room"
            + (f" ({', '.join(s['waiting'][:6])})" if s["waiting"] else "") + f". One reader costs about {s['per_reader_cpu_pc']}% of the PC's processor and "
            f"{s['per_reader_gb']} GB (measured on the reading browsers only; the buying browsers, alerts and the rest take {s['fixed_gb']} GB and "
            f"{s['fixed_cpu_core']} cores on their own). PC free memory: {s['pc_free_gb'] if s['pc_free_gb'] is not None else '?'} GB (an extra reader is "
            f"added only above {PC_FREE_RAMP_GB:.0f} GB free). Ceilings at this level: {s['ceiling_cpu_pc']}% processor, {s['ceiling_gb']} GB memory. "
            f"Whole PC busy now (all programs): {(_S.get('pc_busy') or 0):.0f}% - above {PC_BUSY_SHED:.0f}% the extra readers make room for your other programs (v90).")
