"""Discord as a SOURCE (v45): other trackers post their alerts into a Discord server of YOUR OWN, and this program reads that server.

Why: every extra place a restock gets announced is one more chance to hear about it early. Many trackers can post to a Discord server
(follow their Announcement channel into yours, or invite their bot). This program then reads the channels like a person would and treats
every message that names one of OUR products at a store we watch (and at a price under the limit) as a tracker alert: the product's
store page is looked at right away, and the alert goes through the same checks and messages as every other tracker.

How it reads (free, no extra software): a small bot of YOUR OWN (made once at discord.com/developers, 3 minutes) is added to your new server
with permission to only SEE channels and READ messages. The program asks Discord for the newest messages of each channel every ~2 seconds
(the normal way every Discord bot reads). The bot token is a password: it is kept only in discord_bot.json on this PC.

Nothing here posts to Discord. (Posting TO Discord is the separate webhook in notify.py; this copy's own posts are ignored here, while
v99: other copies' posts ("Restalker · <their name>") are counted - the crowd feed.)
"""
VERSION = "v104"

import collections
import json
import os
import re
import threading
import time
from datetime import datetime, timezone

import requests

import hotness
import matrix
import products
import push_listener
from http_utils import append_csv_row

API = "https://discord.com/api/v10"
CONFIG = "discord_bot.json"
TRACKER_ID = "discord_in"
POLL_SEC = 2.0                 # how often each channel is looked at
GAMING_X = 2.0                 # slower while a game is running
REFRESH_CHANNELS_SEC = 120.0   # how often the list of channels is re-read (a channel you add later is picked up by itself)
MAX_CHANNELS = 10              # most channels read at once (keeps the load small)
MAX_AGE_SEC = 300.0            # a message older than this when seen is not an alert any more
OWN_NAMES = ("restalker", "restock benchmark", "restock latency benchmark")
DEDUPE_SEC = 90.0              # the same product shown twice in one channel this fast is one alert (edits, double posts)
INTENT_BITS = (1 << 18) | (1 << 19)      # "Message Content Intent" switched on (limited / full)
INVITE_PERMS = 66560                      # View Channels + Read Message History, nothing else

BUILTIN = {"id": TRACKER_ID, "name": "Discord server (your own)", "kind": "discord_in", "tier": "free",
           "feed_url": "https://discord.com/developers/applications", "claimed_latency_sec": None, "interval_sec": 2, "active": True,
           "claimed_note": "other trackers post into a Discord server of yours; this program reads it (one-time bot set-up on the Trackers tab)"}

HTTP = None          # tests replace this: HTTP(path, token, params) -> (status code, json or None, headers dict)

_lock = threading.Lock()
STATUS = {"running": False, "note": "not started", "channels": [], "seen": 0, "counted": 0, "last_at": None, "recent": [], "empty_streak": 0,
          "bot": "", "intent": None}
_recent = collections.deque(maxlen=30)


# ------------------------------------------------------------------ the saved token

def _read():
    try:
        with open(CONFIG, encoding="utf-8") as f:
            d = json.load(f)
        return d if isinstance(d, dict) else {}
    except Exception:
        return {}


_TOKEN_RE = re.compile(r"^[\w.\-]{50,120}$")


def token():
    t = str(_read().get("token") or "").strip()
    return t if _TOKEN_RE.match(t) else ""


def configured():
    return bool(token())


def set_token(text):
    """Saves (or, with an empty text, removes) the bot token. Returns '' when fine, else what is wrong."""
    text = (text or "").strip()
    if text.lower().startswith("bot "):
        text = text[4:].strip()
    if not text:
        try:
            if os.path.exists(CONFIG):
                os.remove(CONFIG)
        except OSError:
            pass
        return ""
    if not _TOKEN_RE.match(text):
        return "That does not look like a bot token (it is one long line of letters, numbers, dots and dashes, about 70 characters). Copy it again from the Bot page."
    try:
        with open(CONFIG, "w", encoding="utf-8") as f:
            json.dump({"token": text}, f)
    except OSError as e:
        return f"Could not save it: {e}"
    return ""


# ------------------------------------------------------------------ talking to Discord

def _http(path, tok, params=None):
    if HTTP is not None:
        return HTTP(path, tok, params)
    try:
        r = requests.get(API + path, params=params, timeout=10,
                         headers={"Authorization": "Bot " + tok, "User-Agent": "DiscordBot (https://github.com/restalker, 1.0)"})
        try:
            body = r.json()
        except Exception:
            body = None
        return r.status_code, body, dict(r.headers)
    except Exception as e:
        return 0, {"error": f"{type(e).__name__}: {str(e)[:80]}"}, {}


def snowflake_time(i):
    """When a Discord message / object was created (seconds since 1970), from its id."""
    return ((int(i) >> 22) + 1420070400000) / 1000.0


def list_channels(tok):
    """-> (channels [{id, name, guild}], error text). Text and Announcement channels the bot can see, in every server it is in."""
    code, guilds, _ = _http("/users/@me/guilds", tok)
    if code == 401:
        return [], "Discord says the bot token is wrong or was reset. Paste a new one."
    if code != 200 or not isinstance(guilds, list):
        return [], f"could not reach Discord (code {code})"
    out = []
    for g in guilds:
        c2, chs, _ = _http(f"/guilds/{g.get('id')}/channels", tok)
        if c2 != 200 or not isinstance(chs, list):
            continue
        for c in chs:
            if c.get("type") in (0, 5):
                out.append({"id": str(c["id"]), "name": c.get("name", "?"), "guild": g.get("name", "?")})
    return out, ""


def check():
    """The one-press test: is the token good, is the intent switched on, is the bot in a server, what can it see."""
    tok = token()
    if not tok:
        return {"state": "off", "text": "Not set up yet (optional). Follow the steps on the Trackers tab, then paste the bot token.", "invite": ""}
    code, me, _ = _http("/users/@me", tok)
    if code == 401:
        return {"state": "bad", "text": "Discord does not accept this token (wrong, or it was reset). Paste the newest token from the Bot page.", "invite": ""}
    if code != 200 or not isinstance(me, dict):
        return {"state": "bad", "text": f"Could not reach Discord (code {code}). Check the internet connection and try again.", "invite": ""}
    bot = me.get("username", "bot")
    c2, app, _ = _http("/applications/@me", tok)
    invite, intent = "", None
    if c2 == 200 and isinstance(app, dict):
        invite = f"https://discord.com/oauth2/authorize?client_id={app.get('id')}&scope=bot&permissions={INVITE_PERMS}"
        intent = bool(int(app.get("flags") or 0) & INTENT_BITS)
    with _lock:
        STATUS["bot"], STATUS["intent"] = bot, intent
    if intent is False:
        return {"state": "bad", "invite": invite, "text": f"Connected as '{bot}', but 'Message Content Intent' is OFF, so every message would arrive empty. "
                "On the Bot page of your application turn ON 'Message Content Intent' and press Save Changes, then check again."}
    chs, err = list_channels(tok)
    if err:
        return {"state": "bad", "text": err, "invite": invite}
    if not chs:
        return {"state": "warn", "invite": invite, "text": f"Connected as '{bot}', but it cannot see any channel yet. Open the invite link below, choose your new server and press Authorize. "
                "(If it is already in the server: make sure the bot's role can 'View Channel' and 'Read Message History'.)"}
    names = ", ".join("#" + c["name"] for c in chs[:8]) + (f" and {len(chs) - 8} more" if len(chs) > 8 else "")
    extra = f" (only the first {MAX_CHANNELS} are read)" if len(chs) > MAX_CHANNELS else ""
    return {"state": "ok", "invite": invite, "text": f"Working. Bot '{bot}' can read {len(chs)} channel(s){extra}: {names}."}


# ------------------------------------------------------------------ turning a message into words

def _embed_text(e):
    out = []
    for key in ("title", "description", "url"):
        if e.get(key):
            out.append(str(e[key]))
    for k in ("author", "footer", "provider"):
        v = e.get(k)
        if isinstance(v, dict) and v.get("name" if k != "footer" else "text"):
            out.append(str(v.get("name" if k != "footer" else "text")))
    for f in e.get("fields") or []:
        out.append(f"{f.get('name', '')}: {f.get('value', '')}")
    return " ".join(out)


def message_text(m):
    """Everything a person reads in the message: its text, its embeds (title, body, fields, links) and the file names."""
    parts = [str(m.get("content") or "")]
    for e in m.get("embeds") or []:
        parts.append(_embed_text(e))
    for snap in m.get("message_snapshots") or []:          # a forwarded message
        mm = snap.get("message") if isinstance(snap, dict) else None
        if isinstance(mm, dict):
            parts.append(message_text(mm))
    for c in m.get("components") or []:                    # link buttons ("Buy at Target")
        for b in (c.get("components") or []) if isinstance(c, dict) else []:
            if isinstance(b, dict):
                parts.append(f"{b.get('label', '')} {b.get('url', '')}")
    parts += [str(a.get("filename", "")) for a in m.get("attachments") or []]
    text = " ".join(p for p in parts if p).strip()
    return re.sub(r"\[([^\]]*)\]\((https?://[^)\s]+)\)", r"\1 \2", text)      # markdown link -> words + address


def is_own(m, own_id=""):
    """True for THIS copy's own posts (its bot, or its webhook name "Restalker · <this copy's name>", or the plain names older copies
    used). v99: another copy's "Restalker · <other name>" is NOT own - it is counted, like any tracker (the crowd feed)."""
    a = m.get("author") or {}
    nm = str(a.get("username") or a.get("global_name") or m.get("webhook_name") or "").strip().lower()
    if own_id and str(a.get("id")) == str(own_id):
        return True
    try:
        import notify
        if nm == notify.crowd_name().lower():
            return True
    except Exception:
        pass
    return nm in OWN_NAMES


# ------------------------------------------------------------------ counting an alert

def handle_message(m, ch, targets, out_path, log_fn, report, state, start_ts, now=None, own_id=""):
    """Looks at one message. Returns what became of it (a short word) - also kept for the 'latest messages' list."""
    now = now if now is not None else time.time()
    mid = str(m.get("id"))
    if mid in state["done"]:
        return "again"
    state["done"].add(mid)
    if len(state["done"]) > 4000:
        state["done"] = set(list(state["done"])[-2000:])
    try:
        posted = snowflake_time(mid)
    except (TypeError, ValueError):
        return "bad id"
    if posted < start_ts - 2:
        return "before start"
    if is_own(m, own_id):
        return "own message"
    text = message_text(m)
    with _lock:
        STATUS["seen"] += 1
    if not text:
        with _lock:
            STATUS["empty_streak"] += 1
        _remember(posted, ch, "", "empty (is 'Message Content Intent' on?)")
        return "empty"
    with _lock:
        STATUS["empty_streak"] = 0
    if now - posted > MAX_AGE_SEC:
        _remember(posted, ch, text, "too old when seen")
        return "old"
    live = [t for t in targets if not matrix.is_off(t)]
    matched, why = push_listener.classify(text, live)
    if not matched:
        _remember(posted, ch, text, "not counted: " + why)
        return "no match"
    n = 0
    norm = push_listener._norm(text)
    for t in matched:
        k = (ch["id"], t["id"])
        prev = state["seen_t"].get(k)
        if prev and abs(posted - prev) < DEDUPE_SEC:
            continue
        state["seen_t"][k] = posted
        iso = datetime.fromtimestamp(posted, timezone.utc).isoformat()
        try:
            hotness.mark(t["id"])
        except Exception:
            pass
        pr = products.prices_in(text)
        log_fn(f"[{iso}] NEW MENTION: {TRACKER_ID} / {t['id']} (posted in Discord #{ch['name']}, seen {max(0.0, now - posted):.1f}s later)"
               + (f" price ${pr[0]:.2f}" if pr else ""))
        snippet = f"[discord #{ch['name']}] {text[:300]} || store: {push_listener.retailer_word(t.get('url', ''))} || seen {max(0.0, now - posted):.1f}s after posting"
        if not append_csv_row(out_path, [iso, TRACKER_ID, t["id"], snippet]):
            log_fn(f"[error] {out_path} could not be written to (is it open in Excel?). This alert is saved in {out_path}.pending.")
        if report:
            try:
                report("tracker", TRACKER_ID, last_mention_at=time.time(), last_mention_target=t["id"])
            except Exception:
                pass
        n += 1
    if n:
        with _lock:
            STATUS["counted"] += n
            STATUS["last_at"] = time.time()
        _remember(posted, ch, text, f"COUNTED for {n} product link(s)")
        return "counted"
    _remember(posted, ch, text, "same alert as one just counted")
    return "dup"


def _remember(posted, ch, text, outcome):
    _recent.appendleft({"at": datetime.fromtimestamp(posted, timezone.utc).strftime("%H:%M:%S"), "channel": ch.get("name", "?"),
                        "words": (text or "")[:140], "outcome": outcome})
    with _lock:
        STATUS["recent"] = list(_recent)[:12]


# ------------------------------------------------------------------ the reader

def _wait(stop, secs):
    if stop is None:
        time.sleep(secs)
        return False
    return stop.wait(secs)


def run(targets, out_path, stop_event=None, log_fn=print, report=None, start_ts=None):
    """Reads the Discord server(s) until stopped. Does nothing (and says so) when no bot token has been saved."""
    tok = token()
    note = lambda s, ok=None: (STATUS.update(note=s), report and report("tracker", TRACKER_ID, checked_at=time.time(), ok=ok, note=s))
    if os.environ.get("RK_NO_DISCORD_IN"):
        return
    if not tok:
        note("not set up (optional) - see the steps on the Trackers tab")
        log_fn("[info] Discord server source: no bot token saved (optional). Steps are on the Trackers tab.")
        return
    start_ts = start_ts if start_ts is not None else time.time()
    with _lock:
        STATUS.update(running=True, seen=0, counted=0, empty_streak=0)
    state = {"done": set(), "seen_t": {}}
    own_id = ""
    chans, nxt, last_list, last_id, blocked = [], {}, 0.0, {}, {}
    fail = 0
    log_fn("[info] Discord server source: started (reads the channels of your new server about every 2 seconds).")
    try:
        while not (stop_event and stop_event.is_set()):
            now = time.time()
            if now - last_list >= (REFRESH_CHANNELS_SEC if chans else 20.0):
                last_list = now
                if not own_id:
                    c, me, _ = _http("/users/@me", tok)
                    if c == 200 and isinstance(me, dict):
                        own_id = str(me.get("id") or "")
                lst, err = list_channels(tok)
                if err:
                    fail += 1
                    note(err, ok=False)
                    if fail in (1, 10):
                        log_fn(f"[warn] Discord server source: {err}")
                else:
                    fail = 0
                    chans = lst[:MAX_CHANNELS]
                    with _lock:
                        STATUS["channels"] = [f"{c['guild']} / #{c['name']}" for c in chans]
                    if not chans:
                        note("the bot is not in a server yet (or cannot see any channel)", ok=False)
                    else:
                        note(f"reading {len(chans)} channel(s)", ok=True)
            due = [c for c in chans if nxt.get(c["id"], 0) <= now and blocked.get(c["id"], 0) <= now]
            for ch in due:
                if stop_event and stop_event.is_set():
                    break
                params = {"limit": 50 if ch["id"] in last_id else 20}
                if ch["id"] in last_id:
                    params["after"] = last_id[ch["id"]]
                code, body, hdr = _http(f"/channels/{ch['id']}/messages", tok, params)
                gap = POLL_SEC * (GAMING_X if hotness.gaming() else 1.0)
                nxt[ch["id"]] = time.time() + gap
                if code == 429:
                    ra = 1.0
                    try:
                        ra = float((body or {}).get("retry_after", 1.0))
                    except (TypeError, ValueError):
                        pass
                    nxt[ch["id"]] = time.time() + max(ra, gap)
                    continue
                if code in (403, 404):
                    blocked[ch["id"]] = time.time() + 600
                    log_fn(f"[info] Discord server source: cannot read #{ch['name']} (code {code}); skipped for 10 minutes.")
                    continue
                if code == 401:
                    note("Discord does not accept the bot token any more", ok=False)
                    last_list = 0.0
                    continue
                if code != 200 or not isinstance(body, list):
                    continue
                msgs = sorted((m for m in body if isinstance(m, dict) and m.get("id")), key=lambda m: int(m["id"]))
                for m in msgs:
                    try:
                        handle_message(m, ch, targets, out_path, log_fn, report, state, start_ts, own_id=own_id)
                    except Exception as e:
                        log_fn(f"[warn] Discord server source: could not read one message: {type(e).__name__}: {str(e)[:100]}")
                if msgs:
                    last_id[ch["id"]] = str(msgs[-1]["id"])
                if report:
                    report("tracker", TRACKER_ID, checked_at=time.time(), ok=True,
                           note=(STATUS["note"] if STATUS["empty_streak"] < 5 else "messages arrive EMPTY: turn on 'Message Content Intent' in the bot's settings"))
            if _wait(stop_event, 0.25):
                break
    finally:
        with _lock:
            STATUS["running"] = False
    log_fn("[info] Discord server source: stopped.")


def snapshot():
    with _lock:
        s = dict(STATUS)
    s["set"] = configured()
    s["recent"] = list(s.get("recent") or [])
    return s
