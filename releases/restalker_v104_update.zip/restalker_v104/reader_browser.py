"""v65: the store reader's own browser.

Diagnostics 61: the store readers (v64's "sweepers") read every store through the BUYING browser - Best Buy's data every 3 s, Walmart's
product pages, Target's data. The stores then refused that same browser when it had to buy: Walmart sent it to its "Robot or human?"
page at checkout, Best Buy's product pages stopped loading in it ("Frame with ID 0 is showing error page", 25 times out of 25).
A store judges a browser by everything it did, so the browser that buys must not be the one that reads all day.

So the reading now happens in a SEPARATE, light browser: the same built-in Chromium, its own profile folder (reader_profile, never
signed in to anything), parked off-screen, with a tiny read-only extension (folder reader_engine: it can only fetch store pages and
data the way the store's own page does - it has no buying code at all). It talks to Restalker over the same local link as the buying
browser (path /reader, its own secret). The buying browser only buys, checks sign-ins and runs Amazon's own engine as before.
Human checks are never answered here either.
"""
import json
import os
import secrets
import subprocess
import threading
import time

VERSION = "v104"

HERE = os.path.dirname(os.path.abspath(__file__))
READER_DIR = os.path.join(HERE, "reader_engine")
PROFILE_DIR = os.path.abspath(os.environ.get("RK_READER_PROFILE", "reader_profile"))
LINK_FILE = os.path.join(READER_DIR, "reader_link.json")
TOKEN = secrets.token_hex(16)

state = {"proc": None, "state": "not started", "detail": "", "launched_at": 0.0, "launches": 0, "fails": 0, "next_try": 0.0,
         "last_conn": 0.0, "stop": False}
_lock = threading.RLock()
LOG = [None]


def _log(msg):
    try:
        if LOG[0]:
            LOG[0]("[reader] " + msg)
    except Exception:
        pass


def alive():
    p = state.get("proc")
    return p is not None and p.poll() is None


def _write_link(port):
    try:
        with open(LINK_FILE, "w", encoding="utf-8") as f:
            json.dump({"token": TOKEN, "port": port, "note": "Restalker writes this at every start; it proves the reader is Restalker's own."}, f)
        return True
    except Exception as e:
        state.update(state="cannot start", detail=f"cannot write {LINK_FILE}: {e}")
        return False


def _kill_orphans():
    try:
        import psutil
        mark = "--user-data-dir=" + PROFILE_DIR
        mine = state["proc"].pid if state.get("proc") else None
        victims = []
        for pr in psutil.process_iter(["pid", "cmdline"]):
            try:
                cl = pr.info.get("cmdline") or []
                if pr.pid != mine and any(str(x) == mark for x in cl) and not any(str(x).startswith("--type=") for x in cl):
                    victims.append(pr)
            except Exception:
                continue
        for v in victims:
            try:
                for k in v.children(recursive=True):
                    k.kill()
                v.kill()
            except Exception:
                pass
        if victims:
            psutil.wait_procs(victims, timeout=5)
    except Exception:
        pass


def _wipe_code_cache():
    import shutil
    d = os.path.join(PROFILE_DIR, "Default", "Service Worker")
    if os.path.isdir(d):
        try:
            shutil.rmtree(d)
        except Exception:
            pass


def launch(find_exe, port):
    with _lock:
        if alive():
            return True
        _kill_orphans()
        if not os.path.exists(os.path.join(READER_DIR, "manifest.json")):
            state.update(state="cannot start", detail="the reader_engine folder is missing next to app.py (copy it from the update)")
            return False
        exe = find_exe()
        if not exe:
            state.update(state="cannot start", detail="no built-in Chromium on this PC yet")
            return False
        if not _write_link(port):
            return False
        os.makedirs(PROFILE_DIR, exist_ok=True)
        _wipe_code_cache()
        args = [exe, f"--user-data-dir={PROFILE_DIR}", f"--load-extension={READER_DIR}", f"--disable-extensions-except={READER_DIR}",
                "--no-first-run", "--no-default-browser-check", "--disable-session-crashed-bubble", "--hide-crash-restore-bubble",
                "--disable-backgrounding-occluded-windows", "--disable-renderer-backgrounding", "--disable-background-timer-throttling",
                "--disable-features=IntensiveWakeUpThrottling,CalculateNativeWinOcclusion",
                "--mute-audio", "--window-size=1100,800", "--window-position=-32000,-32000", "--rk-store=reader", "about:blank"]
        extra = os.environ.get("RK_READER_EXTRA_ARGS") or os.environ.get("RK_BUYER_EXTRA_ARGS")       # (tests only)
        if extra:
            args[1:1] = json.loads(extra) if extra.strip().startswith("[") else extra.split()
        flags = (0x08000000 | 0x00000020) if os.name == "nt" else 0
        try:
            state["proc"] = subprocess.Popen(args, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, creationflags=flags)
        except Exception as e:
            state.update(state="cannot start", detail=f"the reader browser did not start: {e}")
            return False
        state.update(state="starting", detail="", launched_at=time.time(), launches=state["launches"] + 1)
        _log("the store reader's own browser started (parked off-screen; it only reads, it never buys).")
        return True


def kill():
    with _lock:
        p = state.get("proc")
        if p is None:
            return
        try:
            import psutil
            pp = psutil.Process(p.pid)
            kids = pp.children(recursive=True)
            pp.terminate()
            for k in kids:
                try:
                    k.terminate()
                except Exception:
                    pass
            _gone, still = psutil.wait_procs([pp] + kids, timeout=6)
            for k in still:
                try:
                    k.kill()
                except Exception:
                    pass
        except Exception:
            try:
                p.kill()
            except Exception:
                pass
        try:
            p.wait(5)
        except Exception:
            pass
        state["proc"] = None


def watch_once(find_exe, port, connected):
    """Keeps the reader browser running (called every few seconds by the buying browser's watchdog thread)."""
    try:
        now = time.time()
        if state.get("stop"):
            if alive():
                kill()
            return
        if alive():
            if connected():
                state.update(state="running", detail="", fails=0, last_conn=now)
            elif now - max(state["launched_at"], state.get("last_conn") or 0) > 90:
                state.update(state="not answering", detail="the reader browser runs but does not answer - restarting it")
                _log(state["detail"])
                kill()
            return
        if now < state.get("next_try", 0):
            return
        if state["launches"]:
            state["fails"] += 1
            if state["fails"] >= 3:
                state["fails"] = 0
                state["next_try"] = now + 60
                state["state"] = "not answering"
                _log("the reader browser keeps closing - starting it again in a minute (the stores' own browsers read meanwhile).")
                return
        if not launch(find_exe, port):
            state["next_try"] = now + 60
            _log("the reader browser cannot start: " + str(state.get("detail")))
    except Exception as e:
        _log(f"reader watchdog: {e}")


def line():
    return f"{state['state']}" + (f" ({state['detail']})" if state.get("detail") else "") + f"; started {state['launches']}x"
