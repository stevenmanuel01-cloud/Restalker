"""Amazon auto-buy (v54): Restalker buys on Amazon by itself.

One program, one page:
- Restalker starts its OWN buying browser (the built-in Chromium, its own folder "buyer_profile", parked off-screen) with the
  "buying engine" inside it: the MTG Amazon Buyer's field-tested checkout (folder buyer_engine; its checkout code is unchanged).
  You sign in to Amazon in that browser once ("Sign in to Amazon" on the page); it stays signed in.
- You arm products on Restalker's page. The most it pays for the item is the product's price cap in Restalker's table.
- When Restalker sees an Amazon restock (its own read within the cap, or a tracker report) it tells the engine at once; the engine
  reloads that exact listing in the signed-in browser and buys it only if it is ARMED and the live Amazon price is under the cap
  (its own checks: exact product, quantity one, tax at most 10 %, shipping over $20 asks you first, at most 3 tries in 60 s).
- Purchases, problems and "approve shipping" requests come to your phone as Restalker messages and are shown on the page.

Safety kept from the Buyer: one purchase per arming (Buy again must be pressed for another), nothing is ever re-armed after an
unclear / failed order, Emergency stop disarms everything at once, the switch OFF stops the browser and every purchase.

The link between Restalker and the engine is a tiny local WebSocket server (python standard library) at 127.0.0.1:17861; only the
engine Restalker started (it proves it with a secret written into buyer_engine/restalker_link.json) is accepted. The separate
MTG Amazon Buyer extension in your normal Chrome is refused (it could buy a second time) and the page tells you to remove it."""
import base64
import collections
import hashlib
import json
import os
import re
import secrets
import socket
import struct
import subprocess
import sys
import threading
import time
from datetime import datetime, timezone

VERSION = "v102"

HOST = "127.0.0.1"
PORT = int(os.environ.get("RK_BUYER_PORT", "17861"))     # fixed in the engine (detector_bridge.js)
PATH = "/bridge"
READER_PATH = "/reader"         # v65: the separate store-reader browser
SETTINGS_FILE = "amazon_buy.json"
HERE = os.path.dirname(os.path.abspath(__file__))
ENGINE_DIR = os.path.join(HERE, "buyer_engine")
PROFILE_DIR = os.path.abspath(os.environ.get("RK_BUYER_PROFILE", "buyer_profile"))   # NOT "browser_profile*" (the focus guard marker)
LINK_FILE = os.path.join(ENGINE_DIR, "restalker_link.json")
SIGNIN_URL = "https://www.amazon.com/gp/css/homepage.html"
HEARTBEAT_SEC = 20.0          # keeps the engine's background page awake while connected (Chrome lets it sleep after 30 s of silence)
REPEAT_GAP_SEC = 15.0         # the same ASIN is signalled at most once per 15 s
RETRY_FOR_SEC = 60.0
RETRY_EVERY_SEC = 3.0
QUEUE_FOR_SEC = 60.0          # a signal made while the engine is not connected is kept this long
ACCOUNT_EVERY_SEC = 1800.0    # how often the engine checks it is still signed in to Amazon (one light page request)
ASIN_RE = re.compile(r"(?:/dp/|/gp/product/|/gp/aw/d/|/product/|[?&]asin=)(B[0-9A-Z]{9})", re.I)
_WS_GUID = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11"

LOG = None            # set by app.py: log(text)
DESCRIBE = None       # set by app.py: target id -> {"store", "product", "cap", "url", ...} or None
ROWS = None           # set by app.py: () -> list of targets (each has id, url, max_price, active)
NOTIFY = None         # set by app.py: send(title, msg, key) -> the phone / Discord message
STATUS = None         # set by app.py: target id -> the newest reading of that store page ({"status", "price", ...}) or None
BB_SIGNIN_URL = "https://www.bestbuy.com/identity/global/signin"
BB_PRACTICE_SEARCH = "https://www.bestbuy.com/site/searchpage.jsp?st=usb+c+cable"
_bb = {"sent": {}, "global": None, "account": {"at": 0.0, "signedIn": None, "reason": None}, "practice": None, "practice_running": False}

_lock = threading.RLock()
_clients = {}
_next_id = [0]
_server = {"listening": False, "error": None, "since": None, "sock": None, "stop": False}
_settings = {"on": True, "armed": [], "bb_pickup": False, "bb_practice_at": 0, "announced": {}, "seeded": False, "old_seeded": False}          # armed = ASINs you armed on Restalker's page (re-armed after every browser start)
_recent = collections.deque(maxlen=40)          # the latest restock signals
_events = collections.deque(maxlen=60)          # the latest purchase events (shown on the page)
_pending = {}
_last_sent = {}
_queue = []
_cmd_wait = {}        # cmdId -> [Event, result]
_busy = {}            # ASIN -> "arming..." while an action runs
_prev = {}            # ASIN -> the engine's last product state (to notice purchases / problems)
_foreign = {"at": 0.0, "count": 0, "logged": 0.0, "name": "", "why": {}}
_emergency = {"at": 0.0}
# v90: how the buying engine's connections went (diagnostics 71: 97 connections refused, none accepted, for 20 minutes)
_link = {"init_ms": None, "init_error": None, "hellos": 0, "bad_key": 0, "bad_key_at": 0.0, "bad_key_len": 0, "bad_key_logged": 0.0, "early": 0, "attempts": 0, "last_attempt": 0.0}
EARLY_KEEP = 20.0            # seconds a new connection may take to say hello (its earlier messages are kept until then)
EARLY_TYPES = ("catalog_sync", "ack", "command_result", "event", "heartbeat_ack", "pong")


def _note_foreign(c, t):
    why = (f"{c.hello} hello" if c.hello else f"'{t}' with no hello") + (f" (from {c.origin[:60]})" if c.origin else "")
    _foreign["why"][why] = _foreign["why"].get(why, 0) + 1
    if len(_foreign["why"]) > 12:
        _foreign["why"].pop(next(iter(_foreign["why"])))
    _foreign.update(at=time.time(), count=_foreign["count"] + 1)
_account = {"at": 0.0, "signedIn": None, "name": None, "challenge": False, "error": None}
_engine = {"proc": None, "exe": None, "state": "not started", "detail": "", "visible": False, "launched_at": 0.0, "launches": 0,
           "rearm_due": False, "install": "", "fail_at": 0.0, "fails": 0}
_token = secrets.token_hex(16)
_boot = f"rs-{int(time.time())}-{os.getpid()}"
_t_boot = time.time()
_wake = threading.Event()


def _log(msg):
    try:
        if LOG:
            LOG("[buyer] " + msg)
    except Exception:
        pass


def _dbg(msg):
    if os.environ.get("RK_BUYER_DEBUG"):
        _log("(debug) " + msg)


def _now_iso(t=None):
    return datetime.fromtimestamp(t if t is not None else time.time(), timezone.utc).isoformat().replace("+00:00", "Z")


def _money(v):
    try:
        return f"${float(v):,.2f}"
    except Exception:
        return ""


def _phone(title, msg, key, popup=False, meta=None, actions=None):
    try:
        if NOTIFY:
            try:
                if actions:
                    NOTIFY(title, msg, key, popup, meta, actions)
                else:
                    NOTIFY(title, msg, key, popup, meta)
            except TypeError:
                NOTIFY(title, msg, key)
    except Exception as e:
        _log(f"could not send the phone message '{title}': {e}")


# ---------------------------------------------------------------- settings

def load_settings():
    try:
        with open(SETTINGS_FILE, encoding="utf-8") as f:
            d = json.load(f)
        if isinstance(d, dict):
            if "on" in d:
                _settings["on"] = bool(d["on"])
            if isinstance(d.get("armed"), list):
                _settings["armed"] = [str(a).upper() for a in d["armed"] if re.fullmatch(r"B[0-9A-Z]{9}", str(a).upper())] + \
                                     [str(a) for a in d["armed"] if str(a).startswith("bb:")]
            for k in ("bb_pickup", "bb_practice_at", "announced", "seeded", "old_seeded", "unknown", "sibling_off", "locked", "locked_at", "rest", "practice_at", "v68_unlocked", "engine_origin"):
                if k in d:
                    _settings[k] = d[k]
            _settings["bb_pickup"] = False          # v65 (your rule): store pickup is never allowed - not even from an old settings file
            # v68 (once): Walmart products the program LOCKED after its own failed tries (diagnostics 62: "not in the cart" every time -
            # the cause is fixed) are set back to Buy - only those the program locked, never one you switched off yourself
            if not _settings.get("v68_unlocked"):
                lk = _settings.get("locked") or {}
                back = [u for u in list(lk) if str(u).startswith("bb:walmart_")]
                for u in back:
                    lk.pop(u, None)
                    if u not in _settings["armed"]:
                        _settings["armed"].append(u)
                _settings["v68_unlocked"] = back or True
                _save()
    except Exception:
        pass


def _save():
    try:
        with open(SETTINGS_FILE, "w", encoding="utf-8") as f:
            json.dump(_settings, f)
    except Exception:
        pass


def enabled():
    return bool(_settings.get("on", True))


def _want(asin, on):
    with _lock:
        was = asin in (_settings.get("armed") or [])
        a = [x for x in _settings["armed"] if x != asin]
        if on:
            a.append(asin)
        _settings["armed"] = a
    _save()
    if on and not was:
        try:
            _co_forget(asin)               # v90: you chose Buy (again): the copy's "already ordered" for this product is cleared
        except Exception:
            pass
        if enabled():
            _multi_hold(False)             # (v90b: after an emergency stop, choosing Buy again lets the browsers buy again)


def wanted(asin):
    return asin in (_settings.get("armed") or [])


# ---------------------------------------------------------------- tiny WebSocket server (RFC 6455, text frames)

class _Client:
    def __init__(self, cid, sock, origin):
        self.id = cid
        self.sock = sock
        self.origin = origin
        self.wlock = threading.Lock()
        self.connected_at = time.time()
        self.alive = True
        self.trusted = False          # True once it proved it is the engine Restalker started
        self.engine_name = ""
        self.code = ""
        self.catalog = {}
        self.bb = {}                  # v56: Best Buy products of the engine (key = Restalker's row id)
        self.global_monitoring = False
        self.global_live = False
        self.emergency = False
        self.cart_owner = None
        self.topic = ""
        self.revision = 0
        self.synced_at = None
        self.syncs = 0
        self.kind = "buyer"           # v65: "reader" = the separate store-reader browser (reads only, never buys)
        self.path = ""
        self.hello = None             # v90: None = no hello yet; "ok" / "bad key" / "not ours"
        self.early = []               # v90: messages that came BEFORE the hello (kept, handled once the hello proves it is ours)

    def send(self, obj):
        data = json.dumps(obj).encode("utf-8")
        n = len(data)
        if n < 126:
            head = struct.pack("!BB", 0x81, n)
        elif n < 65536:
            head = struct.pack("!BBH", 0x81, 126, n)
        else:
            head = struct.pack("!BBQ", 0x81, 127, n)
        try:
            with self.wlock:
                self.sock.sendall(head + data)
            return True
        except Exception:
            self.close()
            return False

    def _control(self, opcode, payload=b""):
        try:
            with self.wlock:
                self.sock.sendall(struct.pack("!BB", 0x80 | opcode, len(payload)) + payload)
        except Exception:
            pass

    def close(self):
        if not self.alive:
            return
        self.alive = False
        self._control(0x8)
        try:
            self.sock.close()
        except Exception:
            pass


def _recv_exact(sock, n):
    buf = b""
    while len(buf) < n:
        chunk = sock.recv(min(n - len(buf), 1 << 20))
        if not chunk:
            raise ConnectionError("closed")
        buf += chunk
    return buf


def _read_message(c):
    parts, first_op = [], None
    while True:
        b1, b2 = _recv_exact(c.sock, 2)
        fin, op = b1 & 0x80, b1 & 0x0F
        masked, n = b2 & 0x80, b2 & 0x7F
        if n == 126:
            n = struct.unpack("!H", _recv_exact(c.sock, 2))[0]
        elif n == 127:
            n = struct.unpack("!Q", _recv_exact(c.sock, 8))[0]
        if n > 64_000_000:
            raise ConnectionError("message too large")
        mask = _recv_exact(c.sock, 4) if masked else b""
        payload = _recv_exact(c.sock, n) if n else b""
        if masked:
            m4 = (mask * (n // 4 + 1))[:n]
            payload = (int.from_bytes(payload, "big") ^ int.from_bytes(m4, "big")).to_bytes(n, "big") if n else b""
        if op == 0x8:
            return None
        if op == 0x9:
            c._control(0xA, payload[:125])
            continue
        if op == 0xA:
            continue
        if op in (0x1, 0x2):
            first_op, parts = op, [payload]
        elif op == 0x0:
            parts.append(payload)
        if fin and first_op is not None:
            return b"".join(parts).decode("utf-8", "replace")


def _http_reply(sock, code, body, ctype="application/json"):
    data = body.encode("utf-8")
    reason = {200: "OK", 403: "Forbidden", 404: "Not Found"}.get(code, "OK")
    head = (f"HTTP/1.1 {code} {reason}\r\nContent-Type: {ctype}\r\nContent-Length: {len(data)}\r\n"
            "Cache-Control: no-store\r\nConnection: close\r\n\r\n")
    try:
        sock.sendall(head.encode("ascii") + data)
    except Exception:
        pass


def _process_metrics():
    p = {"bootId": _boot, "pid": os.getpid(), "uptimeSeconds": round(time.time() - _t_boot, 1),
         "program": "Restalker", "eventLoop": None, "memory": None, "cpuUsageMicroseconds": None}
    try:
        import psutil
        pr = psutil.Process()
        ct = pr.cpu_times()
        p["cpuUsageMicroseconds"] = {"user": int(ct.user * 1e6), "system": int(ct.system * 1e6)}
        p["memory"] = {"rss": pr.memory_info().rss}
    except Exception:
        pass
    return {"exportedAt": _now_iso(), "process": p, "detector": "Restalker " + VERSION}


def _handle(sock, addr):
    c = None
    try:
        sock.settimeout(10)
        raw = b""
        while b"\r\n\r\n" not in raw:
            chunk = sock.recv(4096)
            if not chunk:
                return
            raw += chunk
            if len(raw) > 16384:
                return
        head = raw.split(b"\r\n\r\n", 1)[0].decode("latin-1")
        lines = head.split("\r\n")
        try:
            method, path, _ = lines[0].split(" ", 2)
        except ValueError:
            return
        hdr = {}
        for ln in lines[1:]:
            if ":" in ln:
                k, v = ln.split(":", 1)
                hdr[k.strip().lower()] = v.strip()
        path_only = path.split("?", 1)[0]
        origin = hdr.get("origin", "")
        web_page = origin.startswith("http://") or origin.startswith("https://")
        if hdr.get("upgrade", "").lower() != "websocket":
            if method == "GET" and path_only == "/api/diagnostics" and not web_page:
                _http_reply(sock, 200, json.dumps(_process_metrics()))
            else:
                _http_reply(sock, 404, '{"ok":false}')
            return
        if path_only not in (PATH, READER_PATH) or web_page or not hdr.get("sec-websocket-key"):
            _http_reply(sock, 403, '{"ok":false}')
            return
        accept = base64.b64encode(hashlib.sha1((hdr["sec-websocket-key"] + _WS_GUID).encode()).digest()).decode()
        sock.sendall(("HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\n"
                      f"Sec-WebSocket-Accept: {accept}\r\n\r\n").encode("ascii"))
        sock.settimeout(None)        # the engine may stay quiet for minutes; a dead link is found by the heartbeat Restalker sends
        with _lock:
            _next_id[0] += 1
            c = _Client(_next_id[0], sock, origin)
            c.path = path_only
            _clients[c.id] = c
            if path_only == PATH:
                _link["attempts"] += 1
                _link["last_attempt"] = time.time()
        while c.alive:
            try:
                msg = _read_message(c)
            except socket.timeout:
                break
            if msg is None:
                break
            try:
                _on_message(c, json.loads(msg))
            except Exception as e:
                _log(f"could not understand a message from the buying engine: {str(e)[:120]}")
    except Exception as e:
        _dbg(f"link error: {type(e).__name__}: {str(e)[:160]}")
    finally:
        with _lock:
            if c is not None:
                _clients.pop(c.id, None)
        if c is not None:
            was = c.trusted
            c.close()
            if was and c.kind != "reader":
                _log("the buying engine disconnected (it reconnects by itself within about 10 s).")
        try:
            sock.close()
        except Exception:
            pass


def _on_message(c, m):
    t = m.get("type")
    if t == "hello" and c.path == READER_PATH:
        # v65: the separate store-reader browser (its own secret; it can only read)
        import reader_browser
        if m.get("engine") == "restalker-reader" and secrets.compare_digest(str(m.get("token") or ""), reader_browser.TOKEN):
            c.trusted = True
            c.kind = "reader"
            c.engine_name = str(m.get("name") or "")[:120]
            c.code = str(m.get("code") or "old")[:20]
            c.synced_at = time.time()
            if not _rstate.get("connected_once"):
                _rstate["connected_once"] = True
                _log(f"the store reader's own browser connected ({c.engine_name}; code {c.code}).")
        else:
            c.close()
        return
    if c.path == READER_PATH:
        if c.trusted and t == "command_result":
            w = _cmd_wait.get(str(m.get("cmdId") or ""))
            if w:
                w[1] = m.get("result") or {}
                w[0].set()
        return
    if t == "hello":
        _link["hellos"] += 1
        key_ok = secrets.compare_digest(str(m.get("token") or ""), _token)
        # v90: the same engine as before (its browser identity - the address of THIS folder's buyer_engine, which no web page and not the
        # separate Buyer extension can have) is accepted even when its key file could not be read
        known = bool(c.origin) and c.origin.startswith("chrome-extension://") and c.origin == _settings.get("engine_origin")
        if m.get("engine") == "restalker-buyer-engine" and (key_ok or known):
            c.trusted = True
            c.hello = "ok" if key_ok else "ok (known engine, key not readable)"
            if key_ok and c.origin.startswith("chrome-extension://") and _settings.get("engine_origin") != c.origin:
                _settings["engine_origin"] = c.origin
                _save()
            if not key_ok:
                _link["bad_key"] += 1
                _log("the buying engine's key could not be read - accepted by its known browser identity.")
            c.engine_name = str(m.get("name") or "")[:120]
            c.code = f"{m.get('code') or 'old'}/{m.get('bbCode') or 'old'}"
            ini = m.get("init") if isinstance(m.get("init"), dict) else {}
            _link["init_ms"] = ini.get("ms")
            _link["init_error"] = ini.get("error")
            _log(f"the buying engine connected ({c.engine_name}; code {c.code})"
                 + (f" - {time.time() - _engine['launched_at']:.0f} s after the buying browser started" if _engine.get("launched_at") else "")
                 + (f"; its start-up work took {float(ini['ms']) / 1000:.1f} s" if isinstance(ini.get("ms"), (int, float)) else "")
                 + (f"; START-UP ERROR: {str(ini['error'])[:160]}" if ini.get("error") else "") + ".")
            _engine_version_check(c.engine_name, c.code)
            early, c.early = c.early, []
            for em in early:                       # v90: what it sent before its hello (diagnostics 71) is handled now
                _on_message(c, em)
        elif m.get("engine") == "restalker-buyer-engine":
            # v90: Restalker's own engine, but its key is not this run's key (the engine could not read buyer_engine/restalker_link.json,
            # or read an old one). It is told so and re-reads the key at its next connection (in about 10 s).
            c.hello = "bad key"
            _link["bad_key"] += 1
            _link["bad_key_at"] = time.time()
            _link["bad_key_len"] = len(str(m.get("token") or ""))
            if time.time() - _link["bad_key_logged"] > 600:
                _link["bad_key_logged"] = time.time()
                _log(f"the buying engine said hello with a key that does not match this run (its key has {_link['bad_key_len']} characters) - "
                     "the key file is written again and the engine reconnects in about 10 s.")
            _write_link()
            c.close()
        else:
            c.hello = "not ours"           # (refused at its next message, as before)
        return
    if not c.trusted and c.path == PATH and c.hello is None and time.time() - c.connected_at < EARLY_KEEP and m.get("type") in EARLY_TYPES:
        # v90 (diagnostics 71: every connection of the buying engine was refused - it sent its state a moment BEFORE its hello, and that
        # was taken for the separate Buyer extension, so the buying browser never connected and nothing was bought): kept until the hello.
        _link["early"] += 1
        if m.get("type") == "catalog_sync":
            c.early = [x for x in c.early if x.get("type") != "catalog_sync"]
        c.early.append(m)
        c.early = c.early[-8:]
        return
    if not c.trusted:
        # A Buyer extension that is not Restalker's own engine: most likely the separate MTG Amazon Buyer in your normal Chrome.
        now = time.time()
        _note_foreign(c, t)
        if now - _foreign["logged"] > 3600:
            _foreign["logged"] = now
            _log("REFUSED a second Amazon buyer: the separate 'MTG Amazon Buyer' extension in your normal Chrome tried to connect. "
                 "Restalker buys by itself now; remove that extension (chrome://extensions -> Remove) so it can never buy a second time.")
        if t == "catalog_sync":
            _old_buyer_purchases(m)
            c.send({"type": "catalog_sync_ack", "ok": False, "revision": m.get("revision"),
                    "reason": "Restalker does its own buying now - this separate Buyer extension is not used (remove it)"})
        c.close()
        return
    if t == "catalog_sync":
        rev = m.get("revision") or 0
        try:
            rev = float(rev)
        except Exception:
            rev = 0
        if rev and rev < c.revision:
            c.send({"type": "catalog_sync_ack", "ok": False, "stale": True, "revision": m.get("revision"), "currentRevision": c.revision})
            return
        prods = {}
        for p in m.get("products") or []:
            a = str(p.get("asin") or "").upper()
            if re.fullmatch(r"B[0-9A-Z]{9}", a):
                prods[a] = p
        first = c.synced_at is None
        with _lock:
            c.catalog = prods
            _old_bb = c.bb
            c.bb = {str(x.get("key")): x for x in (m.get("bbProducts") or []) if x.get("key")}
            if any((_old_bb.get(k) or {}).get("status") != v.get("status") or (_old_bb.get(k) or {}).get("inProgress") != v.get("inProgress") for k, v in c.bb.items()):
                _wake.set()                  # v70b: a checkout result is handled AT ONCE (retry, lock, message) - not at the next 5-s round
            if "signinOpen" in m and not m.get("signinOpen") and _engine.get("signin_open"):
                _engine["signin_open"] = False
                _signin_closed()
                _guard(False)
                _account["at"] = 0
                _bb["account"]["at"] = 0
            pr = m.get("amazonProbe")
            if isinstance(pr, dict) and pr.get("at") and pr.get("at") != (_probe.get("rec") or {}).get("at"):
                _probe["rec"] = pr
                _probe["new"] = True
            c.global_monitoring = bool(m.get("globalMonitoring"))
            c.global_live = bool(m.get("globalLivePurchase"))
            c.emergency = bool(m.get("emergencyStop"))
            c.cart_owner = m.get("cartOwner")
            c.topic = str(m.get("phoneTopic") or "")
            c.revision = rev
            c.synced_at = time.time()
            c.syncs += 1
        try:
            _co_remember(c)                  # v90: the copy used while the buying browser is down
        except Exception:
            pass
        c.send({"type": "catalog_sync_ack", "ok": True, "revision": m.get("revision"), "enabledProducts": len(prods)})
        if first:
            _log(f"buying engine ready: {len(prods)} Amazon products known.")

            def after_connect():
                try:
                    _co_push()                 # v90: first what the other browsers did meanwhile ...
                except Exception as e:
                    _log(f"could not tell the buying browser what the other browsers did: {str(e)[:120]}")
                _flush_queue()                 # ... then the restocks that waited
                try:
                    _co_learn()                    # v90: each Amazon listing's checks, for the other browsers while the buying browser is down
                except Exception:
                    pass
            threading.Thread(target=after_connect, daemon=True, name="buyer-after-connect").start()
            threading.Thread(target=push_card_code, daemon=True, name="card-code").start()     # v77: your saved security code -> the buying browser's memory
        _wake.set()                  # the hub thread looks at the new state (never here: this thread must keep reading)
    elif t == "ack":
        _on_ack(c, m)
    elif t == "command_result":
        w = _cmd_wait.get(str(m.get("cmdId") or ""))
        if w:
            w[1] = m.get("result") or {}
            w[0].set()


def _old_buyer_purchases(m):
    """v57: the separate MTG Amazon Buyer extension (still installed in your normal Chrome) can buy BY ITSELF. Restalker never lets it
    in, but it reads the product list it sends: a product it bought is reported to you like any other purchase."""
    try:
        first = not _settings.get("old_seeded")
        for p in m.get("products") or []:
            a = str(p.get("asin") or "").upper()
            if not a:
                continue
            u = "old:" + a
            if p.get("purchased"):
                if _ann(u).get("bought"):
                    continue
                _ann(u)["bought"] = "1"
                if not first:
                    nm = str(p.get("name") or a)[:120]
                    _ledger_add(time.time(), "Amazon", nm, p.get("price"), p.get("orderNumber"), "the old MTG Amazon Buyer extension", None, u)
                    _event(u, nm, "OLDBOUGHT", f"BOUGHT on Amazon by the OLD MTG Amazon Buyer extension - {nm}",
                           "This purchase was made by the separate Buyer extension in your normal Chrome, not by Restalker. "
                           "Remove that extension (chrome://extensions -> Remove) so it cannot buy a second time.")
            elif _ann(u).get("bought"):
                _ann(u).pop("bought", None)
        _settings["old_seeded"] = True
        _save()
    except Exception as e:
        _log(f"old Buyer extension list: {e}")


def engine_disk_name():
    """The version written in buyer_engine/manifest.json (what the NEXT start of the buying browser will run)."""
    try:
        with open(os.path.join(ENGINE_DIR, "manifest.json"), encoding="utf-8") as f:
            return str(json.load(f).get("name") or "")
    except Exception as e:
        return f"(unreadable: {e})"


def engine_problem():
    """Plain words when the buying engine is not the version of this Restalker (v57: the cause of 'no Best Buy purchases' in diagnostics 56)."""
    disk = engine_disk_name()
    if VERSION not in disk:
        return (f"The buyer_engine folder holds OLD files ({disk or 'missing'}), not {VERSION}. Copy the whole buyer_engine folder from the update "
                "into your Restalker folder (replace everything), then close and restart Restalker. Until then Best Buy cannot buy.")
    run = _engine.get("running_name")
    code = _engine.get("running_code")
    if run and (VERSION not in run or (code is not None and code != f"{VERSION}/{VERSION}")):
        return (f"The buying browser still runs an OLD engine ({run}). Restalker restarts it by itself; if this stays, close Restalker "
                "(Stop) and start it again.")
    return None


def _engine_version_check(name, code=""):
    _engine["running_name"] = name
    _engine["running_code"] = code
    # v58: the NAME comes from manifest.json (always read fresh) but the CODE can be an old copy the browser kept in its cache
    # (diagnostics 57: name said v57, code was v54 -> every Best Buy command and order check refused). Both must match.
    if VERSION in (name or "") and code == f"{VERSION}/{VERSION}":
        _engine["stale_restarts"] = 0
        return
    _log(f"the buying browser runs an OLD engine (name {name}, code {code or 'old'}) - this Restalker is {VERSION}. " +
         (f"The files in buyer_engine say: {engine_disk_name()}." if VERSION not in engine_disk_name() else "Restarting the buying browser so it loads the new files."))
    if VERSION in engine_disk_name() and _engine.get("stale_restarts", 0) < 2:
        _engine["stale_restarts"] = _engine.get("stale_restarts", 0) + 1
        _engine["restart_now"] = True


def _engine_client():
    with _lock:
        cl = [c for c in _clients.values() if c.alive and c.trusted and c.synced_at and c.kind != "reader"]
    return cl[-1] if cl else None


_rstate = {"connected_once": False}


def _reader_client():
    """v65: the separate store-reader browser (reads only)."""
    with _lock:
        cl = [c for c in _clients.values() if c.alive and c.trusted and c.kind == "reader"]
    return cl[-1] if cl else None


def reader_command(cmd, timeout=30.0):
    c = _reader_client()
    if not c:
        return {"ok": False, "reason": "the reader browser is not connected yet"}
    cid = secrets.token_hex(8)
    ev = threading.Event()
    _cmd_wait[cid] = [ev, None]
    try:
        if not c.send({"type": "command", "cmdId": cid, "command": cmd}):
            return {"ok": False, "reason": "the reader browser did not take the command"}
        if not ev.wait(timeout):
            return {"ok": False, "reason": "the reader browser did not answer in time"}
        return _cmd_wait[cid][1] or {"ok": False}
    finally:
        _cmd_wait.pop(cid, None)


def command(cmd, timeout=30.0):
    """Sends one command to the engine and waits for its answer: {"ok": bool, "reason": ...}."""
    if str(cmd.get("type", "")).startswith("BB_") and cmd.get("key") and not cmd.get("store"):
        cmd = dict(cmd, store=_store_of_key(cmd["key"]))
    c = _engine_client()
    if not c:
        return {"ok": False, "reason": "the buying browser is not connected yet"}
    cid = secrets.token_hex(8)
    ev = threading.Event()
    _cmd_wait[cid] = [ev, None]
    try:
        if not c.send({"type": "command", "cmdId": cid, "command": cmd}):
            return {"ok": False, "reason": "the buying browser did not take the command"}
        if not ev.wait(timeout):
            return {"ok": False, "reason": "the buying browser did not answer in time"}
        return _cmd_wait[cid][1] or {"ok": False}
    finally:
        _cmd_wait.pop(cid, None)


# ---------------------------------------------------------------- restock signals

def asin_of(url):
    m = ASIN_RE.search(str(url or ""))
    return m.group(1).upper() if m else None


def _is_amazon(url):
    return "amazon." in str(url or "").lower()


SHOPS = ("bestbuy", "target", "walmart", "gamestop")      # v60: stores bought by Restalker's own shop checkouts (Amazon: the Buyer's)


def _shop(url):
    u = str(url or "").lower()
    for s_ in SHOPS:
        if s_ + ".com" in u:
            return s_
    return None


def _is_bestbuy(url):
    """(v60: any shop store - Best Buy, Target, Walmart, GameStop - they all go through the same shop checkout path)"""
    return _shop(url) is not None


_KEYSTORE = {}


def _store_of_key(key):
    """'bestbuy' / 'target' / ... for a row id (or 'bb:<row id>')."""
    key = str(key or "")
    key = key[3:] if key.startswith("bb:") else key
    if key not in _KEYSTORE:
        for t in _amazon_rows(force=True):
            if _shop(t.get("url")):
                _KEYSTORE[t["id"]] = _shop(t.get("url"))
    return _KEYSTORE.get(key, "bestbuy")


_said_wrong = {}


def _bb_signal(tid, d, source, price, detected):
    """v56: a Best Buy restock of a row -> the engine's Best Buy checkout (it buys only if armed, under the cap)."""
    cap = (d or {}).get("cap")
    if price is not None and cap:
        try:
            if float(price) > float(cap):
                return "over cap"
        except Exception:
            pass
    u = "bb:" + tid
    if _resting(u):
        return "resting"                    # v88: 10 checkouts in a row did not buy - it waits 5 minutes, then goes on by itself
    if _fresh_restock(source):
        _soldout_n.pop(u, None)
    st_name = STORE_NAMES.get(_shop((d or {}).get("url")) or _store_of_key(tid))
    if _hc and _hc.get("store") == st_name and time.time() - _hc.get("at", 0) < HC_KEEP and source != "after your check":
        if wanted(u):
            _multi_go(tid, d, detected if detected and abs(time.time() - detected) < 300 else time.time(), source)   # (v75: the OTHER browsers go on)
        return "paused - " + st_name + (" wants you to sign in" if _hc.get("why") == "signin" else " shows a human check")   # (no loop)
    if u in _probs:
        if wanted(u) and time.time() - _said_wrong.get(u, 0) > 600:
            _said_wrong[u] = time.time()
            _log(f"{(d or {}).get('product') or tid} at {STORE_NAMES.get(_store_of_key(tid), 'the store')}: restocked, NOT bought - {_probs[u]}")
        return "wrong link"                     # v62: never bought at a link that does not show the row's exact product
    now = time.time()
    with _lock:
        if now - _last_sent.get(u, 0.0) < REPEAT_GAP_SEC:
            return "repeat"
        _last_sent[u] = now
    t_det = detected if detected and abs(now - detected) < 300 else now
    store = _shop((d or {}).get("url")) or _store_of_key(tid)
    _episode_note(u, t_det, source)
    # v75 (diagnostics 64: the restock came while the buying browser was still arming its products one by one - "not armed - not
    # bought", 14 s lost): a link you set to Buy that the engine has not armed yet is armed RIGHT HERE, before the restock is passed on
    c0 = _engine_client()
    p0 = (c0.bb.get(tid) if c0 else None) or {}
    if (p0 and wanted(u) and not p0.get("armed") and not p0.get("purchased") and not p0.get("attempted") and not p0.get("inProgress")
            and not p0.get("submissionPending") and not (_settings.get("locked") or {}).get(u) and not unclear(p0)):
        ra = command({"type": "BB_ARM", "key": tid}, 5)
        if ra.get("ok"):
            _arm_try[u] = time.time()
    rec = {"eventId": f"rs-bb-{int(now * 1000)}-{abs(hash(tid)) % 100000}", "asin": u, "key": tid, "store": store, "tid": tid,
           "product": STORE_NAMES.get(store, store) + " " + ((d or {}).get("product") or tid), "source": source, "price": price, "detectedAt": _now_iso(min(t_det, now)),
           "made_at": now, "result": "", "ok": None}
    _recent.appendleft(rec)
    if not _engine_client():
        with _lock:
            _queue.append(rec)
        rec["result"] = "waiting: the buying browser is not connected"
        if wanted(u):
            _multi_go(tid, d, t_det, source)        # v90: the other browsers buy meanwhile (diagnostics 71)
            rec["result"] += " - the other browsers check out now"
        return "queued"
    with _lock:
        _pending[rec["eventId"]] = rec
    if not _send_signal(rec):
        with _lock:
            _pending.pop(rec["eventId"], None)
        rec["result"] = f"not sent: the buying browser does not know this {STORE_NAMES.get(store, store)} product yet"
        return "not in buyer"
    rec["result"] = "sent - waiting for the answer"
    if wanted(u):
        _log(f"{rec['product']} restocked ({source}{', $%.2f' % price if price else ''}) and is ARMED - buying browser told at once.")
        _multi_go(tid, d, t_det, source)
    return "sent"


def _multi_go(tid, d, t_det, source):
    """v75 (your rule): the same restock -> every OTHER buying browser (Chrome, Firefox, Camoufox) starts its checkout at this moment too."""
    if str(source).startswith("retry"):
        return                              # (each other browser makes its own tries)
    try:
        import multibuy
        t = next((o for o in _amazon_rows() if o.get("id") == tid), None)
        c = _engine_client()
        if not t:
            return                          # (v90: the buying browser is not needed - while it is down Restalker's copy keeps the rules)
        cap = _row_cap(t)
        if not cap:
            return
        mine = _user_link(t)
        toks, forbid = ([], []) if mine else _bb_words(t)
        job = {"key": tid, "store": _shop(t.get("url")) or _store_of_key(tid), "url": t.get("url"), "cap": cap, "name": _name("bb:" + tid, None, t),
               "sku": str(t.get("sku") or "") or None, "tokens": toks, "forbid": forbid, "trusted": mine, "detected": t_det, "source": str(source), **_group_info(t, c)}
        n = multibuy.go(job)
        if n:
            _log(f"{job['name']} at {STORE_NAMES.get(job['store'], job['store'])}: {n} other browser(s) start the checkout too.")
    except Exception as e:
        _log(f"other buying browsers: {str(e)[:160]}")


def _synth_amazon_product(asin, t, cap):
    """The checks for an Amazon listing the buying browser does not know yet (the same as for a listing you add there)."""
    try:
        import products as _pr
        shape = {"rkShape": "", "rkTheme": []} if _user_link(t) else {"rkShape": _pr.kind_of(t), "rkTheme": _pr.theme_words(_pr.theme_of(t))}
    except Exception:
        shape = {"rkShape": None, "rkTheme": None}
    return {"id": "rk-" + asin, "set": "Custom ASIN", "name": "Restalker listing " + asin, "asin": asin, "url": "https://www.amazon.com/dp/" + asin,
            "search": "https://www.amazon.com/s?k=" + asin, "tokens": [], "forbid": [], "cap": float(cap), "customProduct": True, "enabled": True, **shape}


def _multi_go_amazon(asin, tid, d, t_det, source):
    """v88 (owner 2026-11-01: "incorporate it as you have for all other stores ... all browsers simultaneously"): an Amazon restock of a
    listing set to Buy -> every other buying browser starts its own Amazon checkout at this moment too (Buy now; one order per product)."""
    if str(source).startswith("retry"):
        return
    try:
        import multibuy
        c = _engine_client()
        _co_load()
        p = (c.catalog.get(asin) if c else None) or _co["amz"].get(asin) or {}      # (v90: from the copy while the buying browser is down)
        cap = (d or {}).get("cap") or p.get("cap")
        if not cap or _resting(asin):
            return
        t = next((o for o in _amazon_rows() if _is_amazon(o.get("url")) and asin_of(o.get("url")) == asin), None)
        synth = None
        if not p.get("id"):
            # v90: a listing the buying browser does not know (yet): the other browsers buy it with the same checks the buying browser
            # uses for a listing you add - the exact ASIN on the page, the page's own title, your cap, and the kind / set of the row
            if not t:
                return
            synth = _synth_amazon_product(asin, t, cap)
            g = _name("", None, t)
        else:
            g = multi_command({"type": "BB_AMZGROUP", "productId": p["id"]}, 5).get("group") or ("amzpid:" + str(p["id"]))
        pid = p.get("id") or synth["id"]
        job = {"key": asin, "store": "amazon", "url": "https://www.amazon.com/dp/" + asin, "cap": float(cap), "pid": pid,
               "name": (d or {}).get("product") or p.get("name") or asin, "group": g, "amazonPid": pid, "detected": t_det, "source": str(source)}
        if synth:
            job["product"] = synth
        n = multibuy.go(job)
        if n:
            _log(f"{job['name']} at Amazon: {n} other browser(s) start the checkout too.")
    except Exception as e:
        _log(f"other buying browsers (Amazon): {str(e)[:160]}")


def _multi_still(key):
    c = _engine_client()
    if re.fullmatch(r"B[0-9A-Z]{9}", str(key)):          # v88: an Amazon job of the other browsers (key = the listing's ASIN)
        p = ((c.catalog.get(key) if c else None) or {})
        r = {"wanted": wanted(key), "purchased": bool(p.get("purchased")), "attempted": bool(p.get("attempted")),
             "submissionPending": bool(p.get("submissionPending")), "locked": unclear(p)}
        u = key
    else:
        p = ((c.bb.get(key) if c else None) or {})
        u = "bb:" + key
        r = {"wanted": wanted(u), "purchased": bool(p.get("purchased")), "attempted": bool(p.get("attempted")),
             "submissionPending": bool(p.get("submissionPending")), "locked": bool((_settings.get("locked") or {}).get(u)) or unclear(p)}
    if not r["purchased"] and (not c or not p):
        # v90: Restalker's copy says whether this product was ordered (any store, any browser) - while the buying browser is down, or
        # for a listing it does not know yet (when it knows the listing, its own record decides, as before)
        t = next((o for o in _amazon_rows() if (asin_of(o.get("url")) == u if not u.startswith("bb:") else o.get("id") == u[3:])), None)
        if _co_other(_name("", None, t) if t else None) or _co_other(u):
            r["purchased"] = True
    return r


# ---------------------------------------------------------------- v90: the other browsers keep buying while the buying browser is down
# (diagnostics 71: the buying browser could not connect for 20 minutes; every restock in that time ended "the buying browser is not
#  connected" - and the other buying browsers did not try either, because the one-order rules (who presses Place order, whose turn the
#  shared cart is, what was already ordered) were kept only inside the buying browser.) Now Restalker keeps a copy of those rules:
#  - while the buying browser is connected, it decides, exactly as before, and Restalker writes down every answer (the copy);
#  - while it is NOT connected, Restalker answers the other browsers from the copy - still ONE Place order per product, one browser at a
#    time in a store's cart, nothing bought twice - and the restock goes to the other browsers at once;
#  - the moment it connects again, it is told who is holding what and what was ordered meanwhile, BEFORE it gets any restock.
CO_FILE = "engine_copy.json"
CO_LATCH_FOR = 600.0          # the same as the buying browser's own rule (a Place-order turn ends by itself after 10 minutes)
CO_CART_FOR = 720.0
CO_UNCLEAR_FOR = 900.0
_co = {"latch": {}, "cart": {}, "ordered": {}, "replay": [], "rt": {}, "groups": {}, "amz": {}, "last": {}, "last_at": 0.0, "loaded": False,
       "answered": 0, "offline_answers": 0, "pushed": 0}
_co_lock = threading.RLock()


def _co_load():
    if _co["loaded"]:
        return
    _co["loaded"] = True
    try:
        with open(CO_FILE, encoding="utf-8") as f:
            d = json.load(f)
        _co["last_at"] = float(d.get("last_at") or 0)
        for k in ("rt", "groups", "amz", "last"):
            if isinstance(d.get(k), dict):
                _co[k] = d[k]
        if isinstance(d.get("replay"), list):
            _co["replay"] = [x for x in d["replay"] if isinstance(x, dict) and time.time() - float(x.get("_at") or 0) < 86400]
    except Exception:
        pass


def _co_save():
    try:
        with _co_lock:
            d = {k: _co[k] for k in ("rt", "groups", "amz", "last", "replay", "last_at")}
        tmp = CO_FILE + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(d, f)
        os.replace(tmp, CO_FILE)
    except Exception:
        pass


def _co_remember(c):
    """While connected: what the buying browser knows about every product (its id, whether it was bought) - used when it is down."""
    _co_load()
    with _co_lock:
        amz = {a: {"id": p.get("id"), "name": p.get("name"), "cap": p.get("cap")} for a, p in c.catalog.items() if p.get("id")}
        last = {a: {"purchased": bool(p.get("purchased")), "pending": bool(p.get("submissionPending") or p.get("inProgress"))}
                for a, p in c.catalog.items()}
        last.update({"bb:" + k: {"purchased": bool(p.get("purchased")), "pending": bool(p.get("submissionPending") or p.get("inProgress"))}
                     for k, p in c.bb.items()})
        if amz != _co["amz"] or last != _co["last"]:
            _co["dirty"] = True
        _co["amz"], _co["last"] = amz, last
        _co["last_at"] = time.time()
    if _co.get("dirty") and time.time() - _co.get("saved_at", 0) > 30:
        _co["saved_at"] = time.time()
        _co["dirty"] = False
        _co_save()


def _co_valid(d, k, ttl):
    v = d.get(k)
    if v and (time.time() - v[1] < ttl):
        return v[0]
    d.pop(k, None)
    return None


def _co_group_rows(group):
    out = []
    for o in _amazon_rows():
        if _name("", None, o) == group or (str(group).startswith("amzpid:") and _is_amazon(o.get("url")) and
                                           ((_co["amz"].get(asin_of(o.get("url")) or "") or {}).get("id") == group[7:])):
            a = asin_of(o.get("url")) if _is_amazon(o.get("url")) else None
            out.append(a if a else "bb:" + o["id"])
    return out


def _co_other(group):
    """-> who already ordered this product (any store, any browser), else None."""
    if not group:
        return None
    with _co_lock:
        o = _co["ordered"].get(group)
        if o and (o[2] is None or time.time() < o[2]):
            return o[0]
        for u in _co_group_rows(group):
            o = _co["ordered"].get(u)
            if o and (o[2] is None or time.time() < o[2]):
                return o[0]
            r = _co["last"].get(u) or {}
            if r.get("purchased"):
                return "an earlier order (" + (STORE_NAMES.get(_store_of_key(u[3:]), "Amazon") if u.startswith("bb:") else "Amazon") + ")"
    return None


def _co_order_note(cmd):
    """An order state from one of the other browsers -> the copy (one per product)."""
    t, stt = cmd.get("type"), str(cmd.get("state") or "")
    if t == "RK_AMZ_EXTRA_STATE":
        pid = str(cmd.get("productId") or "")
        a = pid[3:] if pid.startswith("rk-") else next((x for x, v in _co["amz"].items() if str(v.get("id")) == pid), None)
        keys = [k for k in (cmd.get("group"), "amzpid:" + pid if pid else None, a) if k]
        by = "Amazon (" + str(cmd.get("browser") or "another browser")[:40] + ")"
    else:
        keys = [k for k in (cmd.get("group"), "bb:" + str(cmd.get("key") or "")) if k and k != "bb:"]
        by = STORE_NAMES.get(cmd.get("store"), "the store") + " (" + str(cmd.get("browser") or "another browser")[:40] + ")"
    with _co_lock:
        for k in keys:
            if stt == "bought":
                _co["ordered"][k] = (by, time.time(), None)
            elif stt in ("submitting", "unclear"):
                _co["ordered"][k] = (by, time.time(), time.time() + CO_UNCLEAR_FOR)
            elif stt == "failed" and (_co["ordered"].get(k) or (None, 0, 0))[2] is not None:
                _co["ordered"].pop(k, None)


def _co_forget(u):
    t = next((o for o in _amazon_rows() if (o.get("id") == u[3:] if u.startswith("bb:") else (_is_amazon(o.get("url")) and asin_of(o.get("url")) == u))), None)
    g = _name("", None, t) if t else None
    with _co_lock:
        for k in [u, g, "rk-" + u] + ([] if not g else _co_group_rows(g)):
            if k:
                _co["ordered"].pop(k, None)
        if u in _co["last"]:
            _co["last"][u] = dict(_co["last"][u], purchased=False)


def _co_mirror(cmd, r):
    t = cmd.get("type")
    with _co_lock:
        if t == "BB_LATCH" and r.get("ok") and cmd.get("group"):
            _co["latch"][cmd["group"]] = (cmd.get("owner"), time.time())
        elif t == "BB_UNLATCH" and (_co["latch"].get(cmd.get("group")) or ("",))[0] == cmd.get("owner"):
            _co["latch"].pop(cmd.get("group"), None)
        elif t == "BB_CARTLOCK" and r.get("ok") and cmd.get("cartStore"):
            _co["cart"][cmd["cartStore"]] = (cmd.get("owner"), time.time())
        elif t == "BB_CARTUNLOCK" and (_co["cart"].get(cmd.get("cartStore")) or ("",))[0] == cmd.get("owner"):
            _co["cart"].pop(cmd.get("cartStore"), None)
        elif t == "RK_RUNTIME_PRODUCT" and r.get("ok") and isinstance(r.get("product"), dict):
            _co["rt"][str(cmd.get("productId"))] = r["product"]
            _co_save()
        elif t == "BB_AMZGROUP" and r.get("ok") and r.get("group"):
            if _co["groups"].get(str(cmd.get("productId"))) != r["group"]:
                _co["groups"][str(cmd.get("productId"))] = r["group"]
                _co_save()
    if t in ("BB_EXTRA_STATE", "RK_AMZ_EXTRA_STATE") and r.get("ok"):
        _co_order_note(cmd)


def _co_offline(cmd):
    """The buying browser is not connected: the other browsers' questions are answered from the copy (same rules)."""
    _co_load()
    t = cmd.get("type")
    _co["offline_answers"] += 1
    with _co_lock:
        if t == "RK_RUNTIME_PRODUCT":
            p = _co["rt"].get(str(cmd.get("productId")))
            return {"ok": True, "product": p} if p else {"ok": False, "reason": "the buying browser is not connected and this product's checks are not known yet"}
        if t == "BB_AMZGROUP":
            pid = str(cmd.get("productId") or "")
            return {"ok": bool(pid), "group": _co["groups"].get(pid) or ("amzpid:" + pid)}
        if t == "BB_LATCH":
            g, owner = str(cmd.get("group") or ""), str(cmd.get("owner") or "")
            if not g:
                return {"ok": True}
            h = _co_valid(_co["latch"], g, CO_LATCH_FOR)
            if h and h != owner:
                return {"ok": False, "holder": str(h).split(":")[0]}
            other = _co_other(g)
            if other:
                return {"ok": False, "other": other}
            if time.time() - float(_co.get("last_at") or 0) < CO_UNCLEAR_FOR and any((_co["last"].get(u) or {}).get("pending") for u in _co_group_rows(g)):
                # the buying browser was in the middle of buying this very product when it stopped: maybe ordered - never pressed twice
                return {"ok": False, "other": "the buying browser (it was checking out this product when it stopped - look in your orders)"}
            _co["latch"][g] = (owner, time.time())
            return {"ok": True}
        if t == "BB_UNLATCH":
            if (_co["latch"].get(cmd.get("group")) or ("",))[0] == cmd.get("owner"):
                _co["latch"].pop(cmd.get("group"), None)
            return {"ok": True}
        if t == "BB_CARTLOCK":
            st, owner = str(cmd.get("cartStore") or ""), str(cmd.get("owner") or "")
            h = _co_valid(_co["cart"], st, CO_CART_FOR)
            if h and h != owner:
                return {"ok": False, "holder": h}
            _co["cart"][st] = (owner, time.time())
            return {"ok": True, "holder": None}
        if t == "BB_CARTUNLOCK":
            if (_co["cart"].get(cmd.get("cartStore")) or ("",))[0] == cmd.get("owner"):
                _co["cart"].pop(cmd.get("cartStore"), None)
            return {"ok": True}
        if t in ("BB_SHADOW", "BB_VERDICT"):
            return {"ok": True}
        if t == "BB_SHADOWQ":
            return {"ok": True, "active": False}
        if t in ("BB_EXTRA_STATE", "RK_AMZ_EXTRA_STATE"):
            x = dict(cmd)
            x["_at"] = time.time()
            _co["replay"].append(x)
            _co["replay"] = _co["replay"][-200:]
    if t in ("BB_EXTRA_STATE", "RK_AMZ_EXTRA_STATE"):
        _co_order_note(cmd)
        _co_save()
        try:
            _co_announce(cmd)
        except Exception as e:
            _log(f"order message (buying browser not connected): {str(e)[:160]}")
        return {"ok": True}
    return {"ok": False, "reason": "the buying browser is not connected yet"}


def _co_announce(cmd):
    """An order placed by another browser while the buying browser is down -> told now (phone, page), the product is set to not-buy
    everywhere (one per product). When the buying browser connects again it gets the same record, and it is not told a second time."""
    stt = str(cmd.get("state") or "")
    if stt not in ("bought", "unclear"):
        return
    if cmd.get("type") == "RK_AMZ_EXTRA_STATE":
        pid = str(cmd.get("productId") or "")
        u = pid[3:] if pid.startswith("rk-") else next((a for a, v in _co["amz"].items() if str(v.get("id")) == pid), None)
        store = "Amazon"
    else:
        u = "bb:" + str(cmd.get("key") or "")
        store = STORE_NAMES.get(cmd.get("store"), "the store")
    if not u:
        return
    t = next((o for o in _amazon_rows() if (o.get("id") == u[3:] if u.startswith("bb:") else asin_of(o.get("url")) == u)), None)
    who = str(cmd.get("browser") or "another browser")[:40]
    p = {"_offline": True, "orderNumber": cmd.get("orderNumber") or None, "price": cmd.get("price"), "attempted": True,
         "submitAt": cmd.get("orderNumber") or f"offline-{int(time.time())}"}
    if stt == "bought":
        p.update(purchased=True, status=f"PURCHASE SUCCESS — {who}" + (f" — order {cmd['orderNumber']}" if cmd.get("orderNumber") else ""))
        _ann(u)["offline"] = time.time()
        with _co_lock:
            _co["last"][u] = {"purchased": True, "pending": False}
        _announce_bought(u, p, t, store)
    else:
        p.update(purchased=False, status=f"ORDER MAY HAVE BEEN SUBMITTED — CHECK {store.upper()} ({who})")
        _event(u, _name(u, p, t), "CHECK", f"CHECK YOUR {store.upper()} ORDERS - {_name(u, p, t)}",
               f"{who} pressed Place order but could not read the result (the buying browser was not connected to look it up). "
               f"Nothing more is bought for this product for {CO_UNCLEAR_FOR / 60:.0f} minutes. Check your orders, then tap the answer on this message.",
               situation="unclear")


def multi_command(cmd, timeout=5.0):
    """The other buying browsers' questions: to the buying browser when it is connected (its answer is written down), else the copy."""
    _co_load()
    if _engine_client():
        r = command(cmd, timeout)
        if cmd.get("type") in ("RK_AMZ_EXTRA_STATE", "BB_EXTRA_STATE") and not r.get("ok") and "unknown product" in str(r.get("reason")):
            # v90: an order for a listing the buying browser does not know (yet) - Restalker records and announces it itself, and the
            # buying browser is told that this product (its group) was ordered, so nobody presses for it again
            if str(cmd.get("state")) in ("bought", "submitting", "unclear") and cmd.get("group"):
                command({"type": "BB_MARKORDERED", "group": cmd["group"], "by": "Amazon (" + str(cmd.get("browser") or "another browser")[:40] + ")",
                         "ttl": 6 * 3600 * 1000 if cmd.get("state") == "bought" else int(CO_UNCLEAR_FOR * 1000)}, 5)
            return _co_offline(cmd)
        if r.get("reason") != "the buying browser is not connected yet":
            _co["answered"] += 1
            try:
                _co_mirror(cmd, r)
            except Exception:
                pass
            return r
    return _co_offline(cmd)


def _co_push():
    """The buying browser just connected: it is told who holds a Place-order turn / a cart and what was ordered meanwhile - before any
    restock is passed to it (so it never presses for a product another browser is ordering or has ordered)."""
    _co_load()
    n = 0
    with _co_lock:
        latches = [(g, v[0]) for g, v in _co["latch"].items() if time.time() - v[1] < CO_LATCH_FOR]
        carts = [(s_, v[0]) for s_, v in _co["cart"].items() if time.time() - v[1] < CO_CART_FOR]
        replay = list(_co["replay"])
    for g, owner in latches:
        if (_co["latch"].get(g) or ("",))[0] == owner and command({"type": "BB_LATCH", "group": g, "owner": owner}, 5).get("ok") is not None:
            n += 1
    for s_, owner in carts:
        if (_co["cart"].get(s_) or ("",))[0] == owner:
            command({"type": "BB_CARTLOCK", "cartStore": s_, "owner": owner}, 5)
            n += 1
    done = []
    for x in replay:
        cmd = {k: v for k, v in x.items() if not k.startswith("_")}
        r = command(cmd, 10)
        if r.get("ok") or "unknown product" in str(r.get("reason")):
            done.append(x)
            n += 1
    if done:
        with _co_lock:
            _co["replay"] = [x for x in _co["replay"] if x not in done]
        _co_save()
    _co["pushed"] += n
    if n:
        _log(f"the buying browser was told what the other browsers did while it was not connected ({n} item(s)).")


def _co_learn():
    c = _engine_client()
    if not c:
        return
    for a, p in list(c.catalog.items()):
        if p.get("id") and wanted(a):
            multi_command({"type": "RK_RUNTIME_PRODUCT", "productId": p["id"]}, 8)
            multi_command({"type": "BB_AMZGROUP", "productId": p["id"]}, 5)


def _logins_line():
    try:
        import logins
        st = logins.status()
        have = [STORE_NAMES.get(k, k) for k, v in st["stores"].items() if v.get("saved")]
        return (f"Saved store sign-ins (v90b, encrypted on this PC: {st['on_disk']}): " + (", ".join(have) or "none")
                + f"; the buying browser signed itself in: " + (", ".join(f"{STORE_NAMES.get(k, k)} {_ago(v)}" for k, v in _autologin_at.items()) or "not yet"))
    except Exception as e:
        return f"Saved store sign-ins: not read ({e})"


def _co_line():
    with _co_lock:
        lat = sum(1 for v in _co["latch"].values() if time.time() - v[1] < CO_LATCH_FOR)
        ordd = sum(1 for v in _co["ordered"].values() if v[2] is None or time.time() < v[2])
    return (f"Other browsers while the buying browser is down (v90): answered by the buying browser {_co['answered']}, from Restalker's copy "
            f"{_co['offline_answers']}; Place-order turns held {lat}; ordered (one per product) {ordd}; waiting to tell the buying browser "
            f"{len(_co['replay'])}; told after reconnecting {_co['pushed']}; products whose checks are known {len(_co['rt'])}")


def _multi_start():
    try:
        import multibuy
        multibuy.LOG = _log
        multibuy.COMMAND = multi_command          # v90: answered from Restalker's copy while the buying browser is down
        multibuy.STILL = _multi_still
        multibuy.ASK = lambda key, name, title, body: _event("bb:" + key, name, "CHECK", title, body, situation="remote")     # v78b: "sign in in this window" -> you are told
        multibuy.start()
    except Exception as e:
        _log(f"other buying browsers could not start: {str(e)[:160]}")


def _send_signal(rec):
    c = _engine_client()
    if rec.get("store") in SHOPS:
        if not c or rec["key"] not in c.bb:
            return 0
        ev = {"type": "restock", "store": rec["store"], "key": rec["key"], "eventId": rec["eventId"], "detectedAt": rec["detectedAt"],
              "source": rec["source"], "price": rec.get("price"), "product": rec.get("product")}
    elif not c or rec["asin"] not in c.catalog:
        return 0
    else:
        ev = {"type": "restock", "eventId": rec["eventId"], "amazonAsin": rec["asin"], "detectedAt": rec["detectedAt"],
              "source": rec["source"], "store": "amazon", "price": rec.get("price"), "product": rec.get("product")}
    if c.send(ev):
        rec["sent_at"] = rec.get("sent_at") or time.time()
        rec["tries"] = rec.get("tries", 0) + 1
        return 1
    return 0


_PLAIN = {
    "fresh Amazon check dispatched": "the buying browser is checking the store page now",
    "monitor disabled": "not armed - not bought",
    "target completed; manual rearm required": "already bought / tried - press Buy again to allow another",
    "target already in checkout": "already checking out",
    "target checkout already started": "already checking out",
    "already accepted": "already had this restock",
    "ASIN absent from buyer catalog": "this listing is not known to the buying browser yet (switch its Auto-buy on once)",
}


def _on_ack(c, m):
    eid = str(m.get("eventId") or "")
    with _lock:
        rec = _pending.get(eid)
    if not rec:
        return
    reason = str(m.get("reason") or "")
    rec["answered_at"] = time.time()
    rec["ok"] = bool(m.get("ok"))
    ms = int((rec["answered_at"] - rec["made_at"]) * 1000)
    if m.get("retryable") and not m.get("ok") and time.time() - rec["made_at"] < RETRY_FOR_SEC:
        wait = 1.0 if "other checkout" in reason else min(24.0, RETRY_EVERY_SEC * (2 ** max(0, rec.get("tries", 1) - 1)))
        rec["retry_at"] = time.time() + wait
        rec["result"] = f"busy - asking again in {int(wait)} s: " + reason
        return
    with _lock:
        _pending.pop(eid, None)
    plain = _PLAIN.get(reason, reason or ("accepted" if m.get("ok") else "refused"))
    rec["result"] = plain
    a_ = str(rec.get("asin") or "")
    if reason == "monitor disabled" and not a_.startswith("bb:") and wanted(a_) and not _resting(a_) and not str(rec.get("source")).startswith("retry after re-arm"):
        # v84: you set it to Buy, but the buying browser was not watching it -> armed again at once and this restock is passed on again
        _need_rearm[a_] = time.time()
        _arm_try.pop(a_, None)
        _wake.set()
        rec["result"] = "the buying browser was not watching it - arming it again and passing the restock on again"
        _log(f"{rec['product']} ({a_}): restocked, but the buying browser was not watching it although you set it to Buy - arming it again now "
             "and passing this restock on again.")

        def again(rec=rec):
            for _ in range(20):
                time.sleep(0.5)
                if a_ not in _need_rearm:
                    break
                _wake.set()                  # (v94: the hub asks again every half second, not once)
            try:
                det = datetime.fromisoformat(str(rec.get("detectedAt")).replace("Z", "+00:00")).timestamp()
            except Exception:
                det = None
            with _lock:
                _last_sent.pop(a_, None)
            _signal_one(rec.get("tid") or a_, "retry after re-arm (" + str(rec.get("source"))[:60] + ")", rec.get("price"), det)
        threading.Thread(target=again, daemon=True, name="rearm-retry").start()
        return
    if wanted(rec["asin"]) or "checking" in plain:
        _log(f"{rec['product']} ({rec['asin']}): buying browser answered after {ms} ms - {plain}.")


def _flush_queue():
    now = time.time()
    with _lock:
        q, _queue[:] = list(_queue), []
    for rec in q:
        if now - rec["made_at"] > QUEUE_FOR_SEC:
            rec["result"] = "not sent: the buying browser was not running within 60 s"
            continue
        if _send_signal(rec):
            with _lock:
                _pending[rec["eventId"]] = rec
            rec["result"] = "sent (after the buying browser connected) - waiting for its answer"
        else:
            rec["result"] = "not sent: this listing is not known to the buying browser"


def _tick():
    last_hb = 0.0
    while not _server["stop"]:
        time.sleep(1.0)
        now = time.time()
        try:
            with _lock:
                items = list(_pending.items())
            for eid, rec in items:
                if rec.get("retry_at") and now >= rec["retry_at"]:
                    rec["retry_at"] = None
                    _send_signal(rec)
                elif now - rec["made_at"] > RETRY_FOR_SEC + 10:
                    with _lock:
                        _pending.pop(eid, None)
                    if not rec.get("answered_at"):
                        rec["result"] = "no answer from the buying browser"
            if _queue and _engine_client():
                _flush_queue()
            with _lock:
                for rec in [r for r in _queue if now - r["made_at"] > QUEUE_FOR_SEC]:
                    rec["result"] = "not sent: the buying browser was not running within 60 s"
                    _queue.remove(rec)
            if now - last_hb >= HEARTBEAT_SEC:
                last_hb = now
                with _lock:
                    cl = [c for c in _clients.values() if c.alive and c.trusted]
                for c in cl:
                    c.send({"type": "heartbeat", "at": _now_iso(now)})
        except Exception:
            pass


_TS = re.compile(r"\[(\d{4}-\d\d-\d\dT[\d:.]+(?:[+-]\d\d:\d\d|Z)?)\]")
_RESTOCK = re.compile(r"RESTOCK DETECTED: (\S+)")
_MENTION = re.compile(r"NEW MENTION: (\S+) / (\S+) \(")
_PRICE = re.compile(r" price \$([\d,]+(?:\.\d+)?)")


FANOUT_GAP = 60.0          # v75: an "in stock" reading starts the OTHER stores of the same product at most this often (a restock alert: always)
FANOUT_BURST_GAP = 600.0   # v86: another store that says sold out is looked at again for the same product's restocks at most this often ...
FANOUT_OLD = 300.0         # ... while its own reading is younger than this (an older reading: looked at as before)
_fanned = {}
_fanout_skipped = {}     # v80: link -> times a fan-out was not needed (that store's own fresh reading said sold out)


FANOUT_ON = False        # v90 (owner 2026-11-02: "Target never had a restock, so I don't know why the Restalker would reference or try to
                         # check out there"): a store is opened for a checkout ONLY when that store itself shows the product in stock (its
                         # own readers, or a tracker alert naming that store). A restock at Amazon no longer opens Target, Walmart, Best Buy
                         # and GameStop "in case" (diagnostics 74: that happened ~100 times, never found stock, and loaded the buying browser).


def _fan_out(tid, source, detected, always):
    """v75: a restock seen at ONE store -> every other store link of the same product that is set to buy starts its checkout
    at the same moment. v90: OFF (see FANOUT_ON)."""
    if not FANOUT_ON:
        return
    try:
        rows = _amazon_rows()
        me = next((o for o in rows if o.get("id") == tid), None)
        if not me:
            return
        nm = _name("", None, me)
        for o in rows:
            if o.get("id") == tid or _name("", None, o) != nm:
                continue
            ou = _u_of(o)
            if not ou or not wanted(ou) or (_settings.get("locked") or {}).get(ou) or ou in _probs:
                continue
            ost = STORE_NAMES.get(_shop(o.get("url")) or "amazon", "Amazon")
            if _hc and _hc.get("store") == ost and time.time() - _hc.get("at", 0) < HC_KEEP:
                continue                        # (that store waits for your "prove you are a person" check)
            now = time.time()
            if not always and now - _fanned.get(ou, 0.0) < FANOUT_GAP:
                continue
            # v80 (diagnostics 67: a tracker's alert for one store opened the product pages of the other stores again and again - GameStop
            # "pre-order", Best Buy "coming soon" read 3-4 s earlier - and every such checkout paused all the readers): a store whose own
            # reading is FRESH (under 15 s old) and says sold out is not opened; its next reading starts the checkout the moment it changes
            try:
                lr = STATUS(o["id"]) if STATUS else None
                lg = (lr or {}).get("last_good") or {}
                if lg.get("status") == "OUT_OF_STOCK" and now - float(lg.get("at") or 0) < 15:
                    _fanout_skipped[ou] = _fanout_skipped.get(ou, 0) + 1
                    continue
            except Exception:
                pass
            # v86 (diagnostics 70: the Amazon Hobbit box flickered in and out of stock dozens of times an hour, and EVERY flicker opened the
            # Target and Walmart pages too - each showed sold out, each paused the readers): another store whose own reading says sold out
            # is looked at once per restock burst - again only after FANOUT_BURST_GAP, or when its own reading is old
            try:
                lr = STATUS(o["id"]) if STATUS else None
                lg = (lr or {}).get("last_good") or {}
                if (lg.get("status") == "OUT_OF_STOCK" and now - float(lg.get("at") or 0) < FANOUT_OLD
                        and now - _fanned.get(ou, 0.0) < FANOUT_BURST_GAP):
                    _fanout_skipped[ou] = _fanout_skipped.get(ou, 0) + 1
                    continue
            except Exception:
                pass
            _fanned[ou] = now
            _signal_one(o["id"], "same product restocked (" + str(source)[:60] + ")", None, detected)
    except Exception as e:
        _log(f"could not start the other stores of the same product: {str(e)[:160]}")


def signal(tid, source, price=None, detected=None):
    """A restock of row `tid` -> its checkout now; a restock alert or in-stock reading -> the same product's other stores too (v75)."""
    r = _signal_one(tid, source, price, detected)
    src = str(source)
    if enabled() and not src.startswith(("retry", "after your check", "same product")):
        _fan_out(tid, source, detected, always=(src == "Restalker" or src.startswith("tracker:")))
    return r


_episode = {}       # v75: link -> {"at": time of the DETECTION that started this restock, "last": last signal} - the banner counts from it


def _episode_note(u, t_det, source):
    """v75 (your rule): the checkout banner counts from the DETECTION, not from each try. A retry keeps the time of the first detection;
    a new detection after 10 minutes without signals starts a new count."""
    now = time.time()
    e = _episode.get(u)
    if e is None or (now - e.get("last", 0) > 600 and not str(source).startswith("retry")):
        _episode[u] = {"at": min(t_det or now, now), "last": now}
    else:
        e["last"] = now


def _signal_one(tid, source, price=None, detected=None):
    """Tell the buying engine that the product of Restalker row `tid` restocked."""
    if not enabled():
        return "off"
    try:
        d = DESCRIBE(tid) if DESCRIBE else None
    except Exception:
        d = None
    url = (d or {}).get("url") or ""
    if _is_bestbuy(url):
        return _bb_signal(tid, d, source, price, detected)
    if not _is_amazon(url):
        return "not amazon"
    asin = asin_of(url)
    if not asin:
        return "no asin"
    if asin in _probs:
        return "wrong link"                     # v62: never bought at a link that does not show the row's exact product
    if _resting(asin):
        return "resting"                        # v88: 10 checkouts in a row did not buy - it waits 5 minutes, then goes on by itself
    cap = (d or {}).get("cap")
    if price is not None and cap:
        try:
            if float(price) > float(cap):
                return "over cap"
        except Exception:
            pass
    now = time.time()
    with _lock:
        if now - _last_sent.get(asin, 0.0) < REPEAT_GAP_SEC:
            return "repeat"
        _last_sent[asin] = now
    t_det = detected if detected and abs(now - detected) < 300 else now
    _episode_note(asin, t_det, source)
    if _fresh_restock(source):
        _soldout_n.pop(asin, None)            # v94: a NEW restock -> the "sold out under us" retries count from 0 again
    rec = {"eventId": f"rs-{asin}-{int(now * 1000)}", "asin": asin, "tid": tid, "product": (d or {}).get("product") or tid,
           "source": source, "price": price, "detectedAt": _now_iso(min(t_det, now)), "made_at": now, "result": "", "ok": None}
    _recent.appendleft(rec)
    if not _engine_client():
        with _lock:
            _queue.append(rec)
        rec["result"] = "waiting: the buying browser is not connected"
        if wanted(asin):
            _log(f"{rec['product']} ({asin}) restocked and is ARMED, but the buying browser is not connected yet; kept for 60 s - "
                 "the other browsers check out now.")
            _multi_go_amazon(asin, tid, d, t_det, source)     # v90: the other browsers buy meanwhile (diagnostics 71)
            rec["result"] += " - the other browsers check out now"
        return "queued"
    with _lock:
        _pending[rec["eventId"]] = rec
    if not _send_signal(rec):
        with _lock:
            _pending.pop(rec["eventId"], None)
        rec["result"] = "not sent: this listing is not known to the buying browser (switch its Auto-buy on once)"
        if wanted(asin):
            # v90 (diagnostics 73: a new Amazon listing restocked twice while the buying browser was still adding it - nothing tried
            # for 6 minutes): the other browsers check out NOW (they read the page themselves), and the buying browser adds it now
            _arm_try.pop(asin, None)
            _wake.set()
            _multi_go_amazon(asin, tid, d, t_det, source)
            rec["result"] = "the buying browser is still adding this listing - the other browsers check out now"
            _log(f"{rec['product']} ({asin}) restocked and is set to Buy, but the buying browser does not know this listing yet - "
                 "the other browsers check out now, and it is added to the buying browser now.")
        return "not in buyer"
    rec["result"] = "sent - waiting for the answer"
    if wanted(asin):
        _log(f"{rec['product']} ({asin}) restocked ({source}{', $%.2f' % price if price else ''}) and is ARMED - buying browser told at once.")
        _multi_go_amazon(asin, tid, d, t_det, source)
    return "sent"


def from_log(msg):
    try:
        if not enabled():
            return
        pm = _PRICE.search(msg)
        price = float(pm.group(1).replace(",", "")) if pm else None
        det = None
        tm = _TS.search(msg)
        if tm:
            try:
                det = datetime.fromisoformat(tm.group(1).replace("Z", "+00:00")).timestamp()
            except Exception:
                det = None
        if "RESTOCK DETECTED" in msg:
            m = _RESTOCK.search(msg)
            if m:
                signal(m.group(1), "Restalker", price, det)
        elif "NEW MENTION" in msg:
            m = _MENTION.search(msg)
            if m:
                signal(m.group(2), "tracker:" + m.group(1), price, det)
    except Exception as e:
        _log(f"could not pass a restock to the buying browser: {str(e)[:160]}")


# ---------------------------------------------------------------- the buying browser (built-in Chromium + the engine)

def _find_exe():
    env = os.environ.get("RK_BUYER_EXE")
    if env and os.path.exists(env):
        return env
    if _engine.get("exe") and os.path.exists(_engine["exe"]):
        return _engine["exe"]
    out = {}

    def look():
        try:
            from playwright.sync_api import sync_playwright
            with sync_playwright() as p:
                out["exe"] = p.chromium.executable_path
        except Exception as e:
            out["err"] = str(e)[:200]
    th = threading.Thread(target=look, daemon=True)        # (its own thread: Playwright refuses to start inside another running loop)
    th.start()
    th.join(60)
    exe = out.get("exe")
    if exe and os.path.exists(exe):
        _engine["exe"] = exe
        return exe
    return None


def _install_chromium():
    """The built-in Chromium (Playwright's) is what can carry the engine: Google Chrome and Edge no longer load an extension started
    by a program. Installed once (a few minutes, about 150 MB, free) if this PC does not have it yet."""
    if _engine["install"] in ("installing", "failed") or os.environ.get("RK_NO_ENGINE_INSTALL"):
        return
    _engine["install"] = "installing"
    _engine.update(state="installing", detail="installing the built-in Chromium for the buying browser (one time, a few minutes)")
    _log(_engine["detail"] + "...")
    try:
        r = subprocess.run([sys.executable, "-m", "playwright", "install", "chromium"], capture_output=True, text=True, timeout=1800,
                           creationflags=(0x08000000 if os.name == "nt" else 0))
        ok = r.returncode == 0
        txt = ((r.stdout or "") + (r.stderr or "")).strip().splitlines()
    except Exception as e:
        ok, txt = False, [str(e)]
    _engine["install"] = "done" if ok else "failed"
    if ok:
        _log("built-in Chromium installed for the buying browser.")
    else:
        _engine.update(state="cannot start", detail="the built-in Chromium could not be installed: " + (txt[-1][:160] if txt else "?"))
        _log(_engine["detail"])


_elock = threading.RLock()   # starting / stopping the buying browser happens one at a time (the watchdog and the page's buttons)


def _kill_orphans():
    """Any other browser still using the buying profile (left over from a crash): a second start would only hand over to it and close."""
    try:
        import psutil
        mark = "--user-data-dir=" + PROFILE_DIR
        mine = _engine["proc"].pid if _engine.get("proc") else None
        victims = []
        for pr in psutil.process_iter(["pid", "cmdline"]):
            try:
                cl = pr.info.get("cmdline") or []
                if pr.pid != mine and any(str(x) == mark for x in cl) and not any(str(x).startswith("--type=") for x in cl):
                    victims.append(pr)
            except Exception:
                continue
        for v in victims:
            try:
                for k in v.children(recursive=True):
                    k.kill()
                v.kill()
            except Exception:
                pass
        if victims:
            psutil.wait_procs(victims, timeout=5)
            _log(f"closed {len(victims)} leftover copy of the buying browser.")
    except Exception:
        pass


def _alive():
    p = _engine.get("proc")
    return p is not None and p.poll() is None


def _kill_engine():
    p = _engine.get("proc")
    if p is None:
        return
    try:
        import psutil
        pp = psutil.Process(p.pid)
        kids = pp.children(recursive=True)
        pp.terminate()
        for k in kids:
            try:
                k.terminate()
            except Exception:
                pass
        gone, still = psutil.wait_procs([pp] + kids, timeout=6)
        for k in still:
            try:
                k.kill()
            except Exception:
                pass
    except Exception:
        try:
            p.kill()
        except Exception:
            pass
    try:
        p.wait(5)
    except Exception:
        pass
    _engine["proc"] = None


def _write_link():
    try:
        with open(LINK_FILE, "w", encoding="utf-8") as f:
            json.dump({"token": _token, "written": _now_iso(), "note": "Restalker writes this at every start; it proves the buying engine is Restalker's own."}, f)
        return True
    except Exception as e:
        _engine.update(state="cannot start", detail=f"cannot write {LINK_FILE}: {e}")
        return False


def _launch(visible=False):
    if _engine.get("halted"):
        return False
    with _elock:
        if _engine.get("halted"):
            return False
        return _launch_locked(visible)


def _wipe_code_cache():
    """v58: Chromium keeps a copy of the engine's background code in the profile's 'Service Worker' folder and keeps running
    THAT copy after the buyer_engine files are replaced (tested: new files + new name -> old code still ran). Removing the
    folder before every start makes the browser load the files that are on disk. Sign-ins (cookies) and the engine's saved
    settings live elsewhere and are kept."""
    import shutil
    for sub in ("Service Worker",):
        d = os.path.join(PROFILE_DIR, "Default", sub)
        if os.path.isdir(d):
            try:
                shutil.rmtree(d)
            except Exception as e:
                _log(f"could not clear the buying browser's code cache ({e}) - it may run old engine code")


def _launch_locked(visible=False):
    _kill_orphans()
    if not os.path.exists(os.path.join(ENGINE_DIR, "manifest.json")):
        _engine.update(state="cannot start", detail="the buyer_engine folder is missing next to app.py (copy it from the update)")
        return False
    exe = _find_exe()
    if not exe:
        _install_chromium()
        exe = _find_exe()
        if not exe:
            if _engine["state"] != "cannot start":
                _engine.update(state="cannot start", detail="no built-in Chromium on this PC")
            return False
    if not _write_link():
        return False
    os.makedirs(PROFILE_DIR, exist_ok=True)
    _wipe_code_cache()
    args = [exe, f"--user-data-dir={PROFILE_DIR}", f"--load-extension={ENGINE_DIR}", f"--disable-extensions-except={ENGINE_DIR}",
            "--no-first-run", "--no-default-browser-check", "--disable-session-crashed-bubble", "--hide-crash-restore-bubble",
            # a checkout in a window you do not look at must run at full speed (no throttling of hidden pages and their timers)
            "--disable-backgrounding-occluded-windows", "--disable-renderer-backgrounding", "--disable-background-timer-throttling",
            # v62: nor the "once a minute" timer limit Chrome puts on pages hidden for 5 minutes (a checkout step would wait a minute)
            "--disable-features=IntensiveWakeUpThrottling,CalculateNativeWinOcclusion",
            "--mute-audio", "--window-size=1280,900"]
    if visible:
        st = _engine.get("signin_store")
        args += ["--window-position=80,40", "--rk-buyer-visible"] + ([SIGNIN_URL] if st == "amazon" else [BB_SIGNIN_URL] if st == "bestbuy" else [SIGNIN_URL, BB_SIGNIN_URL])     # (no --rk-store mark: the focus guard leaves it alone)
    else:
        args += ["--window-position=-32000,-32000", "--rk-store=buyer", "about:blank"]
    extra = os.environ.get("RK_BUYER_EXTRA_ARGS")          # (tests / special set-ups only)
    if extra:
        args[1:1] = json.loads(extra) if extra.strip().startswith("[") else extra.split()
    flags = (0x08000000 | 0x00000020) if os.name == "nt" else 0     # no console window; NORMAL priority (a checkout must not wait)
    try:
        _engine["proc"] = subprocess.Popen(args, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, creationflags=flags)
    except Exception as e:
        _engine.update(state="cannot start", detail=f"the buying browser did not start: {e}")
        return False
    _engine.update(state="starting", detail="", visible=visible, launched_at=time.time(), launches=_engine["launches"] + 1, rearm_due=True, bb_rearm_due=True)
    _bb["global"] = None
    try:
        import focus_guard
        focus_guard.suspend(bool(visible))
    except Exception:
        pass
    _log(f"buying browser started ({'VISIBLE - sign in to Amazon there' if visible else 'parked off-screen'}).")
    return True


STORE_NAMES = {"amazon": "Amazon", "bestbuy": "Best Buy", "target": "Target", "walmart": "Walmart", "gamestop": "GameStop"}
PRACTICE_SEARCH = {"target": "https://www.target.com/s?searchTerm=usb+c+cable", "walmart": "https://www.walmart.com/search?q=usb+c+cable",
                   "gamestop": "https://www.gamestop.com/search/?q=usb+c+cable"}
SIGNIN_URLS = {"amazon": SIGNIN_URL, "bestbuy": BB_SIGNIN_URL, "target": "https://www.target.com/account",
               "walmart": "https://www.walmart.com/account/login", "gamestop": "https://www.gamestop.com/login/"}


def _guard(on):
    try:
        import focus_guard
        focus_guard.suspend(bool(on))
    except Exception:
        pass


def _to_front():
    """v65: the window just opened (sign-in / a store link) is brought in front of everything, on screen (Windows does not let a
    background program do that by itself - the window only flashed in the taskbar, so it seemed never to open)."""
    p = _engine.get("proc")
    if p is None:
        return

    def work():
        try:
            import focus_guard
            ok = focus_guard.bring_forward(p.pid)
            _dbg(f"window brought to the front: {ok}")
        except Exception:
            pass
    threading.Thread(target=work, daemon=True, name="buyer-to-front").start()


def _signin_closed():
    """v62: the sign-in window was closed: that store's sign-in is checked again right away (the table shows the result in seconds)."""
    st = _engine.get("signin_store") or "amazon"
    try:
        # v65: you just did a store's "prove you are a person" check yourself -> the stopped purchase is tried again at once
        signed = _hc.get("why") == "signin" and _hc.get("skey") == st             # (v75: you signed in with the store's own Sign in button)
        if (_hc.get("opened") or signed) and time.time() - _hc.get("at", 0) < HC_KEEP and _hc.get("tid"):
            tid = _hc["tid"]
            _hc.clear()
            _last_sent.pop("bb:" + tid, None)
            d = DESCRIBE(tid) if DESCRIBE else None
            r = _bb_signal(tid, d, "after your check", None, None)
            _log(f"{(d or {}).get('product') or tid}: you closed the store window after its check - the purchase is tried again now ({r}).")
    except Exception as e:
        _log(f"could not try the purchase again after the check: {e}")
    if st == "amazon":
        _account["at"] = 0.0
    else:
        a = (_bb.get("accounts") or {}).get(st)
        if a is not None:
            a["at"] = 0.0
    _wake.set()


def show_browser(visible, store=None):
    """v59b: sign in to ONE store in one small separate window (only that store's sign-in page). The buying browser keeps running
    hidden with all its work - nothing restarts, nothing is disarmed. visible=False closes that window again."""
    c = _engine_client()
    if not enabled():
        return {"ok": False, "reason": "turn buying ON first (top bar)"}
    if c:
        if visible:
            r = command({"type": "SIGNIN_OPEN", "url": SIGNIN_URLS.get(store or "amazon", SIGNIN_URL)}, 20)
            if r.get("ok"):
                _engine["signin_store"] = store or "amazon"
                _engine["signin_open"] = True
                _guard(True)                   # (you are using that window on purpose: the focus helper leaves it alone)
                _to_front()
            return r
        r = command({"type": "SIGNIN_CLOSE"}, 20)
        _engine["signin_open"] = False
        _guard(False)
        _signin_closed()
        return r
    if not visible:
        _engine["signin_open"] = False
        _guard(False)
        return {"ok": True}
    return {"ok": False, "reason": "the buying browser is starting - try again in a few seconds"}


ENGINE_QUIET_LIMIT = 120.0
ENGINE_SLOW_LIMIT = 300.0


def _no_answer_for():
    return time.time() - max(_engine["launched_at"], _engine.get("last_conn") or 0)


def _watchdog():
    """Keeps the buying browser running while auto-buy is ON (and closed while it is OFF)."""
    while not _server["stop"]:
        time.sleep(3)
        with _elock:
            _watch_once()


def halt_now(why="Stop"):
    """v101 (owner 2026-11-05: "is the emergency stop button needed? ... no need to disarm anything, but instant stoppage is desired"): Stop
    ends the buying browser THIS instant (a checkout in it ends where it is; nothing is disarmed) and it is never started again until the
    program starts again. The other buying browsers are held at once by Stop too (multibuy.hold)."""
    _engine["halted"] = why
    _server["stop"] = True                   # (no watchdog brings it back)
    _multi_hold(True, why)
    got = _elock.acquire(timeout=2.0)       # (never waits long for a start that is under way - the browser is ended either way)
    try:
        _kill_engine()
        _engine.update(state="off", detail="stopped by you")
    finally:
        if got:
            _elock.release()
    _log(f"{why}: the buying browser is closed this instant - nothing is bought until Restalker starts again (nothing was disarmed).")


def _watch_once():
    try:
        if _engine.get("halted"):
            return
        if not enabled():
            if _alive():
                _kill_engine()
                _engine.update(state="off", detail="")
            return
        if _alive() and _engine.pop("restart_now", False) and not _engine.get("visible"):
            _kill_engine()
            _engine["state"] = "restarting"
            _launch(False)
            return
        if _alive():
            c = _engine_client()
            if c:
                _engine.update(state="running", detail="", fails=0, last_conn=time.time())
            elif not _engine["visible"] and _no_answer_for() > (ENGINE_SLOW_LIMIT if _link["last_attempt"] > _engine["launched_at"] and
                                                               time.time() - _link["last_attempt"] < 60 else ENGINE_QUIET_LIMIT):
                # v90: a browser whose engine IS calling Restalker (only slow to finish starting, e.g. the PC is busy) gets up to
                # ENGINE_SLOW_LIMIT; one that never calls, ENGINE_QUIET_LIMIT. (Before: 90 s for both - diagnostics 71 restarted it 12 times.)
                _engine.update(state="not answering", detail="the buying browser runs but its engine does not answer - restarting it")
                _log(_engine["detail"])
                _kill_engine()
            return
        if time.time() < (_engine.get("next_try") or 0):
            return
        if _engine["state"] == "cannot start" and time.time() - _engine["fail_at"] < 300:
            return
        if _engine["launches"] and _engine["state"] in ("running", "starting", "not answering"):
            _engine["fails"] += 1
            if _engine["fails"] > 3:
                _engine["fails"] = 0              # (the minute is over: try again)
            elif _engine["fails"] == 3:
                _engine["next_try"] = time.time() + 60
                _engine["state"] = "not answering"
                _log("the buying browser keeps closing - starting it again in a minute.")
                return
            _log("the buying browser closed - starting it again.")
        if not _launch(False):
            _engine["fail_at"] = time.time()
            _log("the buying browser cannot start: " + str(_engine.get("detail")))
    except Exception as e:
        _log(f"buying browser watchdog: {e}")


# ---------------------------------------------------------------- the hub: caps, re-arming, purchases -> messages

def _rows_by_asin():
    out = {}
    for t in _amazon_rows():
        a = asin_of(t.get("url"))
        if a and a not in out:
            out[a] = t
    return out


def _row_cap(t):
    try:
        v = float(t.get("max_price"))
        return v if v > 0 else None
    except Exception:
        return None


_names = {}           # target id -> (time, product name): DESCRIBE reads the whole table from disk, so it is asked at most once a minute


def _name(asin, p=None, t=None):
    if t:
        hit = _names.get(t["id"])
        if hit and time.time() - hit[0] < 60:
            return hit[1]
        try:
            d = DESCRIBE(t["id"]) if DESCRIBE else None
            if d and d.get("product"):
                _names[t["id"]] = (time.time(), d["product"])
                return d["product"]
        except Exception:
            pass
    return (p or {}).get("name") or asin


_UNCLEAR = re.compile(r"CHECK AMAZON|UNCERTAIN|UNCLEAR|MAY HAVE BEEN SUBMITTED", re.I)
_GAVE_UP = re.compile(r"RE-ARM REQUIRED|CANCELLED|TERMINAL|RETRY LIMIT", re.I)
_checks = {}          # ASIN -> the order-history check running after an unclear result
ORDER_CHECK_WAITS = (15, 45, 120, 420)   # seconds before each look in the Amazon orders (15 s, 1 min, 3 min, 10 min after the unclear result)


def unclear(p):
    """An order Place Order was pressed for, whose result the engine could not read (it never tries again by itself)."""
    return bool(p and p.get("attempted") and not p.get("purchased") and not p.get("submissionPending") and not p.get("inProgress"))


_POPUP_KINDS = {"BOUGHT", "APPROVE", "CVV", "OLDBOUGHT", "CHECK"}
# v58 (your rule): a message to your phone / PC ONLY when something was BOUGHT - plus the two questions a running purchase cannot finish
# without (card security code, shipping over $20). "Not bought", "not confirmed", "checking" etc. are shown in the table and the log only.
_PHONE_KINDS = {"BOUGHT", "APPROVE", "CVV", "OLDBOUGHT", "CHECK", "UNKNOWN"}
# v96: + UNKNOWN - "order result UNKNOWN" (Place order was pressed, the result could not be found in 10 minutes): only you can settle it.
# v65: + CHECK - a store showed the buying browser a "prove you are a person" page during a checkout. The program never answers it;
# you can (one press opens it in front of you), and the purchase is tried again right after you close that window.
# v83 (owner 2026-10-31: "I am not in front of the computer and would only be able to do it remotely"): when a store wants a sign-in or a
# person check, the program opens that window on the PC by itself at once, and the phone message says how to reach it from the phone
# (Chrome Remote Desktop: free, Google's own app - you see the PC's screen and type on it; the program still never types a password).
REMOTE_HINT = ("The window is ALREADY OPEN on your PC. Away from the PC? Open the Chrome Remote Desktop app on your phone "
               "(https://remotedesktop.google.com/access), ")


def _auto_open_check():
    def go():
        try:
            time.sleep(1.0)
            r = act("checkopen")
            if not (r or {}).get("ok"):
                _log(f"could not open the store's sign-in / check window by itself ({(r or {}).get('reason') or 'no answer'}) - press it in Restalker.")
        except Exception as e:
            _log(f"could not open the store's sign-in / check window by itself ({str(e)[:80]})")
    threading.Thread(target=go, daemon=True, name="auto-open-check").start()


_hc = {}            # the latest such check: {"u", "tid", "store", "product", "url", "at", "opened"}
HC_KEEP = 900.0     # how long the "Open <store>" offer stays (a restock is usually over after that)


EVENTS_FILE = "purchase_events.json"     # v65: the list of purchases and problems survives a restart (the program runs for days)


def _save_events():
    try:
        with open(EVENTS_FILE, "w", encoding="utf-8") as f:
            json.dump(list(_events)[:60], f)
    except Exception:
        pass


def _load_events():
    try:
        with open(EVENTS_FILE, encoding="utf-8") as f:
            old = json.load(f)
        if isinstance(old, list) and not _events:
            for e in reversed(old[:60]):
                if isinstance(e, dict) and e.get("text"):
                    _events.appendleft(e)
    except Exception:
        pass
    try:
        if not os.path.exists(BUY_EVENTS_CSV) and _events:       # v100: the first start with the kept history - what the list has goes in, once
            for e in reversed(list(_events)):
                _bev_add(e)
    except Exception:
        pass


def _tid_of(u):
    """'bb:<row id>' or an ASIN -> the table row id (what the page's buttons send)."""
    u = str(u or "")
    if u.startswith("bb:"):
        return u[3:]
    t = _rows_by_asin().get(u)
    return t.get("id") if t else None


def _store_word(u):
    u = str(u or "")
    return STORE_NAMES.get(_store_of_key(u), "the store") if u.startswith("bb:") else "Amazon"


def _event(asin, nm, kind, title, body, phone=True, situation=None, extra=None):
    """situation (v96): the buttons the phone message gets (see phone_actions.buttons) - and a message with a situation is sent to the
    phone even when its kind is not one of _PHONE_KINDS (e.g. the 'Buy one more' reminder)."""
    _log(f"{nm} ({asin}): {title} - {body}")
    _events.appendleft({"at": time.strftime("%m-%d %H:%M:%S"), "t": time.time(), "asin": asin, "product": nm, "kind": kind, "title": title, "text": title + " - " + body})
    _save_events()
    _bev_add(_events[0])
    if phone and (kind in _PHONE_KINDS or situation):
        acts = None
        if situation:
            try:
                import phone_actions
                acts = phone_actions.buttons(situation, _tid_of(asin) if situation != "remote" else "", nm, _store_word(asin), extra) or None
            except Exception as e:
                _log(f"the phone buttons could not be made ({str(e)[:80]}) - the message goes out without them")
        # v57: purchase messages ALSO pop up on the PC (Windows) - besides the phone, Discord and the page's browser alert
        _phone(title, body, f"buy-{asin}-{kind}-{int(time.time())}", popup=kind in _POPUP_KINDS,
               meta={"kind": "purchase " + kind.lower(), "source": "auto-buy", "target": asin, "price": None}, actions=acts)


# ---- v100: every buy event is also kept in buy_events.csv (the list above keeps only the newest 60) - the product's restock history
# window (owner 2026-11-05: "time date and bought or not bought along with super brief explanation") reads it. Never in it: anything
# secret (the texts are the same ones the log and the page show; a card code or sign-in is never in them).
BUY_EVENTS_CSV = "buy_events.csv"
BUY_EVENTS_MAX = 4_000_000            # bytes; past it the older half is dropped (months of events)
_bev_lock = threading.Lock()
_bev_cache = {"key": None, "rows": []}


def _bev_add(e):
    import csv as _csv
    try:                                 # (the cached rows only: never a fresh read of the product list from here - no lock is taken)
        u = str(e.get("asin") or "")
        tid = u[3:] if u.startswith("bb:") else next((t.get("id") or "" for t in (_rows_cache.get("rows") or []) if asin_of(t.get("url")) == u), "")
    except Exception:
        tid = ""
    with _bev_lock:
        try:
            new = not os.path.exists(BUY_EVENTS_CSV)
            with open(BUY_EVENTS_CSV, "a", encoding="utf-8", newline="") as f:
                w = _csv.writer(f)
                if new:
                    w.writerow(["time_utc", "kind", "row", "listing", "product", "title", "text"])
                w.writerow([datetime.fromtimestamp(e.get("t") or time.time(), timezone.utc).isoformat(timespec="seconds"), e.get("kind", ""), tid,
                            str(e.get("asin") or ""), str(e.get("product") or "")[:120], str(e.get("title") or "")[:300], str(e.get("text") or "")[:600]])
            if os.path.getsize(BUY_EVENTS_CSV) > BUY_EVENTS_MAX:
                with open(BUY_EVENTS_CSV, encoding="utf-8", errors="replace") as f:
                    lines = f.readlines()
                keep = [lines[0]] + lines[1 + (len(lines) - 1) // 2:]
                with open(BUY_EVENTS_CSV + ".tmp", "w", encoding="utf-8", newline="") as f:
                    f.writelines(keep)
                os.replace(BUY_EVENTS_CSV + ".tmp", BUY_EVENTS_CSV)
        except Exception as ex:
            _log(f"the buy event could not be written to {BUY_EVENTS_CSV}: {str(ex)[:100]}")


def buy_events_all():
    """Every kept buy event, oldest first: [{"t", "kind", "tid", "u", "product", "title", "text"}]. A broken line is skipped."""
    import csv as _csv
    try:
        st_ = os.stat(BUY_EVENTS_CSV)
        key = (st_.st_mtime_ns, st_.st_size)
    except Exception:
        return []
    with _bev_lock:
        if _bev_cache["key"] != key:
            rows = []
            try:
                with open(BUY_EVENTS_CSV, encoding="utf-8", errors="replace", newline="") as f:
                    r = _csv.reader(f)
                    next(r, None)
                    for x in r:
                        if len(x) < 7:
                            continue
                        try:
                            t = datetime.fromisoformat(x[0]).timestamp()
                        except Exception:
                            continue
                        rows.append({"t": t, "kind": x[1], "tid": x[2], "u": x[3], "product": x[4], "title": x[5], "text": x[6]})
            except Exception:
                rows = []
            _bev_cache.update(key=key, rows=rows)
        return list(_bev_cache["rows"])


# ---- v57: each purchase outcome is announced ONCE, from a saved record - so a restart, a missed moment or an error can never swallow it
def _pid(p):
    return str(p.get("submitAt") or p.get("orderNumber") or "1")


def _ann(u):
    return _settings.setdefault("announced", {}).setdefault(u, {})


def _mark(u, what, value):
    _ann(u)[what] = value
    _save()


def _announce_submitted(u, p, t, store):
    nm = _name(u, p, t)
    if _ann(u).get("submitted") == _pid(p):
        return
    if _ann(u).get("offline") and time.time() - _ann(u)["offline"] < 86400:
        _mark(u, "submitted", _pid(p))         # (v90: see _announce_bought)
        return
    _mark(u, "submitted", _pid(p))
    # (v75: the other stores are NOT paused at the press - they wait ready in the buying browser and press at once if this one fails;
    #  they are paused when it is BOUGHT or may have been, below)
    if not p.get("purchased"):
        _event(u, nm, "SUBMITTED", f"ORDER SUBMITTED on {store} - {_money(p.get('price'))} - {nm}",
               f"{time.strftime('%H:%M:%S')} - Place Order was pressed. Restalker is confirming it now.")


def _announce_bought(u, p, t, store):
    if _ann(u).get("bought") == _pid(p):
        return
    off = _ann(u).get("offline")
    if off and not p.get("_offline") and time.time() - off < 86400:
        # v90: bought by another browser while the buying browser was down - you were told then; this is the same order arriving in the
        # buying browser's record after it reconnected
        _ann(u).pop("offline", None)
        _mark(u, "bought", _pid(p))
        _mark(u, "submitted", _pid(p))
        return
    _mark(u, "bought", _pid(p))
    _mark(u, "submitted", _pid(p))
    try:
        _one_per_product(u, t, _name(u, p, t), store)
    except Exception as e:
        _log(f"one-per-product: {e}")
    _fails.pop(u, None)
    (_settings.get("locked") or {}).pop(u, None)
    nm = _name(u, p, t)
    _ledger_add(time.time(), store, nm, p.get("price"), p.get("orderNumber"), _bought_by(p), (t or {}).get("id"), u)
    st = str(p.get("status") or "")
    how = f" (found in your {store} orders)" if "order history" in st.lower() or ("orders" in st.lower() and "found" in st.lower()) else ""
    _event(u, nm, "BOUGHT", f"BOUGHT on {store} - {_money(p.get('price'))} - {nm}",
           " - ".join(x for x in (time.strftime("%H:%M:%S"), ("Order " + p["orderNumber"]) if p.get("orderNumber") else "",
                                  "confirmed" + how + ". It is frozen now: nothing more is bought for it (tap Buy one more on this message, or "
                                  "choose Buy next to it in Restalker, for one more).") if x), situation="bought")
    _want(u, False)


# ---- v97 (owner 2026-11-04: "the area that says purchases includes both purchases and problems and those 2 things should be separated ...
# a nice clean area where I can just see track and verify all purchases"): every purchase is written ONCE to purchases.csv (kept for good;
# the list of events only keeps the newest 60 of everything)
PURCHASES_CSV = "purchases.csv"
PURCHASE_KINDS = ("BOUGHT", "OLDBOUGHT")
PROBLEM_KINDS = ("APPROVE", "CVV", "CHECK", "UNKNOWN")     # (the messages that needed you; ACTION / FAILED / REST ... fixed themselves)
_ledger = {"mtime": None, "rows": []}
_ledger_lock = threading.Lock()


def _ledger_add(at, store, nm, price, order, by, tid, u):
    import csv as _csv
    with _ledger_lock:
        try:
            new = not os.path.exists(PURCHASES_CSV)
            with open(PURCHASES_CSV, "a", encoding="utf-8", newline="") as f:
                w = _csv.writer(f)
                if new:
                    w.writerow(["time_utc", "store", "product", "price", "order", "bought_by", "row", "listing"])
                w.writerow([datetime.fromtimestamp(at, timezone.utc).isoformat(timespec="seconds"), store, nm,
                            "" if price in (None, "") else f"{float(price):.2f}", order or "", by or "", tid or "", u or ""])
        except Exception as e:
            _log(f"the purchase could not be written to {PURCHASES_CSV}: {str(e)[:100]}")


def _bought_by(p):
    st = str((p or {}).get("status") or "")
    m = re.search(r"PURCHASE SUCCESS\s*[\u2014-]\s*([^\u2014]+?)(?:\s*[\u2014-]\s*order\b|$)", st, re.I)
    who = (m.group(1).strip() if m else "") or "the buying browser"
    return who[:60]


def purchases_list(limit=300):
    """Every purchase ever recorded, newest first: [{"t", "store", "product", "price", "order", "by", "tid"}]."""
    import csv as _csv
    try:
        st_ = os.stat(PURCHASES_CSV)
        mt = (st_.st_mtime_ns, st_.st_size)             # (size too: two purchases within one clock tick still show)
    except Exception:
        return []
    with _ledger_lock:
        if _ledger["mtime"] != mt:
            rows = []
            try:
                with open(PURCHASES_CSV, encoding="utf-8", errors="replace", newline="") as f:
                    r = _csv.reader(f)
                    next(r, None)
                    for x in r:
                        if len(x) < 7:
                            continue
                        try:
                            t = datetime.fromisoformat(x[0]).timestamp()
                        except Exception:
                            continue
                        try:
                            pr = float(x[3]) if x[3] else None
                        except Exception:
                            pr = None
                        rows.append({"t": t, "store": x[1], "product": x[2], "price": pr, "order": x[4], "by": x[5], "tid": x[6], "n": len(rows)})
            except Exception:
                rows = []
            rows.sort(key=lambda r_: (-r_["t"], -r_["n"]))      # (newest first; written later = newer within the same second)
            _ledger.update(mtime=mt, rows=rows)
        return list(_ledger["rows"][:limit])


_EV_RX = re.compile(r"^(?:BOUGHT on Amazon by the OLD MTG Amazon Buyer extension|BOUGHT on (?P<store>Amazon|Best Buy|Target|Walmart|GameStop)) - "
                    r"(?:(?P<price>\$[\d,]+\.\d\d) - )?(?P<nm>.+)$")


def _ledger_seed():
    """v97: the first start with the purchase list: the purchases still in the list of events are written into it (once)."""
    if os.path.exists(PURCHASES_CSV):
        return
    n = 0
    for e in reversed(list(_events)):
        if e.get("kind") not in PURCHASE_KINDS:
            continue
        m = _EV_RX.match(str(e.get("title") or ""))
        if not m:
            continue
        om = re.search(r"Order ([A-Za-z0-9-]{4,40})", str(e.get("text") or ""))
        price = m.group("price")
        _ledger_add(float(e.get("t") or time.time()), (m.group("store") or "Amazon").strip(), (m.group("nm") or e.get("product") or "").strip(),
                    float(price[1:].replace(",", "")) if price else None, om.group(1) if om else "",
                    "the old MTG Amazon Buyer extension" if e.get("kind") == "OLDBOUGHT" else "", "", e.get("asin"))
        n += 1
    if n:
        _log(f"the purchase list ({PURCHASES_CSV}) was started with the {n} purchase(s) still in the list of events.")


def _announce_unclear(u, p, t, store):
    if _ann(u).get("check") == _pid(p):
        if u not in _checks and _ann(u).get("check_done") != _pid(p):    # (after a restart an unfinished look in the order history starts again)
            _start_order_check(u, p, t, store)
        return
    _mark(u, "check", _pid(p))
    nm = _name(u, p, t)
    try:
        _one_per_product(u, t, nm, store)
    except Exception as e:
        _log(f"one-per-product: {e}")
    _event(u, nm, "CHECK", f"ORDER RESULT NOT CONFIRMED YET - {nm}",
           f"{p.get('status')}. Place Order was pressed, but {store}'s confirmation page was not read. Restalker is looking for it in your {store} orders now.",
           situation="checking")
    _start_order_check(u, p, t, store)


def _durable(u, p, t, store):
    """Every pass, for every product: anything not announced yet is announced now (once)."""
    try:
        if p.get("attempted") or p.get("submissionPending"):
            _announce_submitted(u, p, t, store)
        if p.get("purchased"):
            _announce_bought(u, p, t, store)
        elif unclear(p):
            _announce_unclear(u, p, t, store)
    except Exception as e:
        _log(f"purchase message for {u}: {e}")


def _seed(c):
    """First start of v57: purchases that happened before are recorded as told (no flood of old messages); orders whose result was
    never confirmed are NOT, so they are looked up in the order history and you are told now."""
    if _settings.get("seeded"):
        return
    for a, p in list(c.catalog.items()):
        if p.get("purchased"):
            _ann(a).update(bought=_pid(p), submitted=_pid(p))
    for k, p in list(c.bb.items()):
        if p.get("purchased"):
            _ann("bb:" + k).update(bought=_pid(p), submitted=_pid(p))
    _settings["seeded"] = True
    _save()


def _notice(asin, p, prev, t, store="Amazon"):
    """Every checkout event -> the log, the page (ribbon) and your phone. v55: EVERY outcome of a pressed Place Order sends a message.
    v56: also for Best Buy (asin is then the key 'bb:<row id>')."""
    nm = _name(asin, p, t)
    prev = prev or {}
    st, pst = str(p.get("status") or ""), str(prev.get("status") or "")
    clock = time.strftime("%H:%M:%S")
    if p.get("inProgress") and not prev.get("inProgress") and not p.get("purchased"):
        if time.time() - _fanned.get(asin, 0.0) < 90:
            # v86 (owner 2026-11-01: "why does the program keep saying it's checking out at Target when the product is showing detection
            # at Amazon?"): this is only a LOOK at this store's page because the same product restocked at another store
            _event(asin, nm, "CHECKOUT", f"checking {store} too - {nm}", f"the same product restocked at another store, so the buying browser "
                   f"looks at {store}'s page in case it is back there too (it buys only if {store} shows it in stock under your cap)", phone=False)
        else:
            _event(asin, nm, "CHECKOUT", f"CHECKOUT STARTED - {_money(p.get('price'))} - {nm}", "the buying browser is checking out now", phone=False)
            own = time.time() - _last_sent.get(asin, 0.0) > 60      # (v90b: a checkout a restock signal started has the others going already)
            if not own:
                pass
            elif not str(asin).startswith("bb:") and t and wanted(asin):
                # v88: the buying browser started an Amazon checkout by itself (its own check saw it buyable) -> the other browsers go too
                _multi_go_amazon(asin, t.get("id"), {"cap": _row_cap(t), "product": nm}, time.time(), "the buying browser's own check")
            elif str(asin).startswith("bb:") and t and wanted(asin):
                # v90b (owner 2026-11-02: "every BROWSER checks out at the same time ... all at the same store which we got a positive
                # detection for"): the buying browser started a checkout at THIS store by itself -> every other browser, same store, now
                _multi_go(t.get("id"), DESCRIBE(t["id"]) if DESCRIBE else None, time.time(), "the buying browser's own check")
    if p.get("purchased"):
        return                          # (BOUGHT / SUBMITTED / unconfirmed are announced by _durable, once, even across restarts)
    if p.get("approval") and not prev.get("approval"):
        a = p["approval"]
        _event(asin, nm, "APPROVE", f"ACTION NEEDED - {store} shipping {_money(a.get('shipping'))} - {nm}",
               f"Item {_money(a.get('base'))}, tax {_money(a.get('tax'))}, shipping {_money(a.get('shipping'))}, total {_money(a.get('total'))}. "
               "Tap Approve or Do not buy on this message, or press Approve shipping or Cancel in Restalker (within 10 minutes).",
               situation="approve", extra={"shipping": _money(a.get("shipping"))})
        return
    if p.get("needCvv") and not prev.get("needCvv") and _card_have():
        # v77: your saved security code is typed in at once (the buying browser had lost it - e.g. it restarted): no waiting for you
        threading.Thread(target=_auto_cvv, args=(re.sub(r"^bb:", "", str(asin)),), daemon=True, name="card-code-answer").start()
        return
    if p.get("needCvv") and not prev.get("needCvv"):
        _event(asin, nm, "CVV", f"ACTION NEEDED - {store} asks for your card's security code - {nm}",
               "Open Restalker and type the 3-4 digit code in the top bar within 10 minutes - away from the PC: the button opens Remote Desktop "
               "(the code is never sent by phone message). (Save it under Card code (top bar) and checkouts never wait for it again.)", situation="remote")
        return
    # v70b: a NEW try that ended with the same words as the one before is a new result too (each try has its own start time)
    new_try = bool(p.get("hitAt")) and p.get("hitAt") != prev.get("hitAt") and not p.get("inProgress")
    if st == pst and not new_try:
        return
    if st.startswith("ORDER NOT PLACED") and not p.get("purchased") and card_code_wrong(store, st):
        _event(asin, nm, "CVV", f"ACTION NEEDED - {store} turned down your saved card security code - {nm}",
               "Nothing was ordered. Open Restalker, press Card code (top bar) and save the right code (until then you are asked at each checkout).",
               situation="remote")
    if st.startswith("ORDER NOT PLACED") and not p.get("purchased"):
        _event(asin, nm, "FAILED", f"not bought - {store} - {nm}", st + " - nothing was ordered; it is tried again at once.")
        _failed(asin, st)
        _retry_now(asin, t, "failed")
        return
    if st.startswith("NOT BOUGHT") and "sold out" in st.lower() and not p.get("purchased"):
        _retry_now(asin, t, "sold out")      # v70b: the store said sold out - asked again at once (a restock often flickers)
        return
    if unclear(p):
        return
    if st.startswith("ACTION REQUIRED") and t and ("does not match the product: " in st or "different kind of product" in st):
        # v62: the checkout saw the product page itself and it is NOT this row's product -> remembered: never bought at this link
        try:
            import linkcheck
            ttl = st.split("does not match the product: ", 1)[1] if "does not match the product: " in st else st.split("): ", 1)[-1]
            if not linkcheck.user_link(t):         # (v75: a link YOU gave is never judged by its page name)
                linkcheck.note_title(dict(t, found_by=t.get("found_by") or "checkout"), ttl.strip(), _log)
        except Exception:
            pass
    if st.startswith("ACTION REQUIRED") and not p.get("approval") and "human / security check" in st and t and t.get("url"):
        again = bool(_hc and _hc.get("store") == store and time.time() - _hc.get("told", 0) < 1800)
        told = _hc.get("told", 0) if again else time.time()
        _hc.clear()
        _hc.update(u=asin, tid=t.get("id"), store=store, product=nm, url=t.get("url"), at=time.time(), opened=0.0, told=told)
        # (one message per store per 30 min; the top bar always shows the newest)
        _event(asin, nm, "CHECK" if not again else "ACTION", f"ACTION NEEDED - {store} wants you to show you are a person - {nm}",
               f"{store} showed a 'prove you are a person' page, so nothing was ordered. " + (REMOTE_HINT if not again else
               f"Open Restalker and press 'Open {store}' in the top bar, ") + "do the check yourself in that window and close it - the purchase is "
               "tried again right away while it is still in stock. (The program never answers these checks.)",
               situation=None if again else "remote")
        if not again:
            _auto_open_check()
        return
    if st.startswith("ACTION REQUIRED") and not p.get("approval") and t and re.search(r"sign in|signin|verify your account", st, re.I):
        # v75 (diagnostics 64: Best Buy asked for the password at its checkout and the checkout was started again and again, 7 times in
        # 4 minutes): that store is PAUSED - no more tries - until you sign in; then the purchase is tried again at once
        skey = _shop(t.get("url")) or "amazon"
        if not re.search(r"verify your account", st, re.I):
            # v90b: with your saved sign-in it signs itself in and the purchase is tried again at once - nobody is asked

            def relog(skey=skey, asin=asin, t=t, nm=nm, store=store):
                if _engine_autologin(skey, "the checkout asked for it"):
                    _last_sent.pop(asin, None)
                    d = DESCRIBE(t["id"]) if DESCRIBE else None
                    r = _bb_signal(t["id"], d, "after signing in", None, None) if asin.startswith("bb:") else _signal_one(t["id"], "after signing in")
                    _log(f"{nm}: signed in again - the purchase is tried again now ({r}).")
                else:
                    _ask_signin(asin, t, nm, store, skey)       # (it could not: you are asked, as before)
            try:
                import logins
                have = bool(logins.get(skey))
            except Exception:
                have = False
            if have and time.time() - _autologin_at.get(skey, 0.0) >= AUTOLOGIN_EVERY:
                threading.Thread(target=relog, daemon=True, name="buyer-relogin").start()
                return
        _ask_signin(asin, t, nm, store, skey)
        return
    if st.startswith("ACTION REQUIRED") and not p.get("approval"):
        _event(asin, nm, "ACTION", f"not bought - {store} checkout stopped - {nm}", st + " - nothing was ordered; it is armed again by itself.")
        _failed(asin, st)
        return
    if (_GAVE_UP.search(st) or st.startswith("FAILED")) and not p.get("purchased") and not p.get("attempted") and (prev.get("inProgress") or "RETRY" in pst or new_try):
        _event(asin, nm, "FAILED", f"not bought - {store} - {nm}", st + " - nothing was ordered; it is tried again at once.", phone=False)
        _failed(asin, st)
        # v94 (review): a checkout the store took away (sold out under us) is asked again at once only SOLDOUT_TRIES times in a row -
        # it does not count toward the 5-minute rest, so without this limit a page that keeps showing stock that checkout keeps refusing
        # would be tried again and again for ever
        _retry_now(asin, t, "sold out" if _RACE_RX.search(str(st)) else "failed")


def _ask_signin(asin, t, nm, store, skey):
    """The store wants the password at its checkout and the buying browser could not sign itself in: that store pauses and you are asked."""
    again = bool(_hc and _hc.get("store") == store and time.time() - _hc.get("told", 0) < 1800)
    told = _hc.get("told", 0) if again else time.time()
    _hc.clear()
    _hc.update(u=asin, tid=t.get("id"), store=store, skey=skey, product=nm, url=SIGNIN_URLS.get(skey) or t.get("url"), at=time.time(),
               opened=0.0, told=told, why="signin")
    _event(asin, nm, "CHECK" if not again else "ACTION", f"ACTION NEEDED - {store} wants your password before checkout - {nm}",
           f"{store} asked you to sign in again at its checkout, so nothing was ordered there by the buying browser and it is paused at {store} "
           f"(no more tries; the other buying browsers go on). " + (REMOTE_HINT if not again else "Open Restalker, ") +
           f"sign in (tick 'Keep me signed in'), then close that window - the purchase is tried "
           "again right away. (Save the store's sign-in under Sign-ins (top bar) and the browsers sign themselves in; a code the "
           "store sends you is never answered by the program.)", situation=None if again else "remote")
    if not again:
        _auto_open_check()


_autologin_at = {}
AUTOLOGIN_EVERY = 1800.0
_SIGNIN_RX = {"amazon": r"amazon\.com/ap/(signin|mfa|cvf)", "bestbuy": r"bestbuy\.com/identity/",
              "target": r"target\.com/(login|account/sign|co-login|gsp/login)|login\.target\.com",
              "walmart": r"walmart\.com/(account/login|account/signin|identity)", "gamestop": r"gamestop\.com/(login|account/login|signin)"}


def _engine_autologin(store, why=""):
    """v90b (owner 2026-11-02: "I just want it to already be signed in and not ask me multiple times per session. The program should be able
    to save my login information and/or log me in automatically"): the BUYING browser signs itself back in with your saved sign-in
    (Sign-ins (top bar)). One try per store every 30 minutes; a code / "verify it's you" / a puzzle is never answered.
    -> True / False / None (no saved sign-in, or tried a moment ago)."""
    try:
        import logins
        import multibuy
        cred = logins.get(store)
    except Exception:
        return None
    if not cred or time.time() - _autologin_at.get(store, 0.0) < AUTOLOGIN_EVERY or not _engine_client():
        return None
    _autologin_at[store] = time.time()
    r = command({"type": "BB_AUTOLOGIN", "store": store, "url": multibuy.AUTO_SIGNIN_URL.get(store), "email": cred[0], "password": cred[1],
                 "host": multibuy.STORE_HOSTS.get(store), "signinRx": _SIGNIN_RX.get(store)}, 60)
    nm = STORE_NAMES.get(store, store)
    if r.get("ok"):
        _log(f"{nm}: the buying browser signed itself in again with your saved sign-in" + (f" ({why})" if why else "") + ".")
        if store == "amazon":
            _account["at"] = 0.0
        else:
            a = (_bb.get("accounts") or {}).get(store)
            if a is not None:
                a["at"] = 0.0
        _wake.set()
        return True
    _log(f"{nm}: the buying browser could not sign itself in - {r.get('why') or r.get('reason') or 'no answer'}.")
    return False


def _one_per_product(u, t, nm, store):
    """v56: ONE of a product, not one per store - once an order is submitted at one store, auto-buy for the same product at the other store is switched off."""
    if not t:
        return
    for o in _amazon_rows(force=True):
        if o.get("id") == t.get("id") or _name("", None, o) != nm:
            continue
        ou = ("bb:" + o["id"]) if _is_bestbuy(o.get("url")) else asin_of(o.get("url"))
        if not ou or not wanted(ou):
            continue
        r = act("disarmgroup", [o["id"]])
        _settings.setdefault("sibling_off", {})[ou] = u           # (switched on again by itself if that order turns out NOT placed)
        _save()
        _log(f"{nm}: ordered at {store}, so buying at the other store is paused (one per product)" + ("" if r.get("ok") else f" - FAILED: {r.get('reason')}"))


def _start_order_check(asin, p, t, store="Amazon"):
    """After an unclear result Restalker decides by itself (v58): it looks in the account's recent orders 15 s, 1 min, 3 min and 10 min later.
    Found -> BOUGHT (frozen). The order list was read every time and the product is not in it -> NOT ordered -> armed again by itself.
    The order list could not be read -> result UNKNOWN -> frozen (never bought twice by guessing)."""
    if asin in _checks and _checks[asin].get("state") == "checking":
        return
    pid0 = _pid(p or {})
    _checks[asin] = {"state": "checking", "at": time.time(), "pid": pid0}
    nm = _name(asin, p, t)

    def run():
        res, reads = None, 0
        bb = asin.startswith("bb:")
        for wait in ORDER_CHECK_WAITS:
            time.sleep(wait)
            c = _engine_client()
            cur = ((c.bb.get(asin[3:]) if bb else c.catalog.get(asin)) if c else None) or {}
            if cur.get("purchased") or (cur and _pid(cur) != pid0 and (cur.get("submitAt") or cur.get("orderNumber"))):
                _checks[asin] = {"state": "bought" if cur.get("purchased") else "done", "at": time.time()}
                return
            if cur and not unclear(cur):
                _checks[asin] = {"state": "done", "at": time.time()}
                return
            r = command({"type": "BB_ORDER_CHECK", "key": asin[3:]} if bb else {"type": "ORDER_CHECK", "asin": asin}, 90)
            res = r
            if r.get("ok") and r.get("checked"):
                reads += 1
            if r.get("ok") and r.get("found"):
                if bb:
                    command({"type": "BB_MARK", "key": asin[3:], "bought": True, "orderNumber": r.get("orderNumber"),
                             "status": "PURCHASE SUCCESS - found in your Best Buy order history"}, 20)
                else:
                    pid = cur.get("id") or (p or {}).get("id")
                    command({"type": "SET_PRODUCT", "productId": pid, "values": {
                        "purchased": True, "attempted": True, "submissionPending": False, "inProgress": False,
                        "orderNumber": r.get("orderNumber") or cur.get("orderNumber"),
                        "status": "PURCHASE SUCCESS - found in your Amazon order history"}}, 20)
                _checks[asin] = {"state": "bought", "at": time.time(), "order": r.get("orderNumber")}
                _wake.set()
                return
        _mark(asin, "check_done", pid0)
        if reads == len(ORDER_CHECK_WAITS):
            # read the order list every time, the product was never in it: nothing was ordered
            if bb:
                command({"type": "BB_MARK", "key": asin[3:], "bought": False}, 20)
            else:
                c = _engine_client()
                cur = (c.catalog.get(asin) if c else None) or {}
                pid = cur.get("id") or (p or {}).get("id")
                command({"type": "SET_PRODUCT", "productId": pid, "values": {
                    "purchased": False, "attempted": False, "submissionPending": False, "inProgress": False, "armed": False, "autoBuy": False,
                    "status": f"NOT ORDERED - not in your {store} orders (looked {reads} times)"}}, 20)
            _checks[asin] = {"state": "not ordered", "at": time.time()}
            for ou, src in list((_settings.get("sibling_off") or {}).items()):
                if src == asin:                                   # nothing was ordered: the other store buys again too
                    _settings["sibling_off"].pop(ou, None)
                    _want(ou, True)
            _failed(asin, "not ordered")
            _event(asin, nm, "NOTFOUND", f"not bought - {nm}", f"the order is not in your {store} orders (looked {reads} times over 10 minutes): nothing was ordered. It is armed again by itself.")
            _wake.set()
            return
        why = (res or {}).get("reason") or f"your {store} order list could not be read"
        _checks[asin] = {"state": "unknown", "at": time.time(), "why": why}
        _settings.setdefault("unknown", {})[asin] = pid0
        _want(asin, False)
        _event(asin, nm, "UNKNOWN", f"order result UNKNOWN - {nm}",
               f"Place Order was pressed but the result could not be confirmed ({why}). It is frozen, so it is never bought twice by guessing. "
               f"Check your {store} orders, then tap the answer on this message (or choose Buy next to it in Restalker if nothing was ordered).",
               situation="unclear")
    threading.Thread(target=run, daemon=True, name="buyer-ordercheck").start()


def _hub_pass():
    try:
        _unlock_expired()
    except Exception as e:
        _log(f"lock check: {e}")
    c = _engine_client()
    if not c:
        return
    if _probe.get("new"):
        _probe["new"] = False
        _log("Amazon checkout page evidence:\n" + _probe_text(_probe.get("rec")))
    with _lock:
        cat = dict(c.catalog)
    rows = _rows_by_asin()
    _seed(c)
    # 1) purchase events
    for a, p in cat.items():
        prev = _prev.get(a)
        if prev is not None:
            try:
                _notice(a, p, prev, rows.get(a))
            except Exception as e:
                _log(f"buyer notice: {e}")
        _prev[a] = p
        _durable(a, p, rows.get(a), "Amazon")
    # 2) the engine's own phone messages are switched off: Restalker sends them (one hub, one phone topic)
    if c.topic:
        command({"type": "SET_TOPIC", "topic": ""}, 10)
    # 3) the master switch
    if not enabled() and c.global_live:
        command({"type": "SET_GLOBAL", "values": {"liveGlobal": False}}, 10)
        _bb_pass(c)
        return
    busy_cart = bool(c.cart_owner)
    # 4) one price cap: the product's cap in Restalker's table is the most the engine may pay for the item
    for a, t in rows.items():
        p = cat.get(a)
        cap = _row_cap(t)
        if not p or cap is None or busy_cart or p.get("inProgress") or p.get("submissionPending") or p.get("attempted") or p.get("purchased"):
            continue
        if p.get("cap") is None or abs(float(p["cap"]) - cap) > 0.005:
            r = command({"type": "SET_PRODUCT", "productId": p["id"], "values": {"cap": cap, "monitor": bool(p.get("armed"))}}, 20)
            _log(f"{_name(a, p, t)}: buying cap set to {_money(cap)} (your table's cap)" + ("" if r.get("ok") else f" - FAILED: {r.get('reason')}"))
    # 4b) v62: the kind and set name each Amazon listing must show on its page - the buying browser checks the page against them
    #     right before buying (a single pack is never bought for a box row, nor another set)
    try:
        import products as _pr
        for a, t in rows.items():
            p = cat.get(a)
            if not p or busy_cart or p.get("inProgress") or p.get("submissionPending"):
                continue
            want = ({"rkShape": "", "rkTheme": []} if _user_link(t) else         # v75: a link YOU gave is the product
                    {"rkShape": _pr.kind_of(t), "rkTheme": _pr.theme_words(_pr.theme_of(t))})
            sig = json.dumps(want, sort_keys=True)
            if _shape_sent.get(a) != sig:
                r = command({"type": "SET_PRODUCT", "productId": p["id"], "values": want}, 20)
                if r.get("ok"):
                    _shape_sent[a] = sig
    except Exception as e:
        _log(f"product checks for the buying browser: {e}")
    # 5) v58: what you set to Buy stays armed - after every start of the buying browser, after a checkout that did not buy,
    #    and right after you choose Buy (the click itself only records your wish, so it shows at once; this does the work)
    _engine["rearm_due"] = False
    try:
        _reconcile(c, cat)
    except Exception as e:
        _log(f"buy switches: {e}")
    try:
        _verify_links()
    except Exception:
        pass
    if not busy_cart:
        _keep_armed(cat, rows)
    # 6) sign-in check (light: one page request every 30 min, and soon after each start)
    if time.time() - _account["at"] > (ACCOUNT_EVERY_SEC if _account["signedIn"] else 120):
        check_account()
    # 7) v56: Best Buy
    try:
        _bb_pass(c)
    except Exception as e:
        _log(f"Best Buy hub: {e}")


_arm_said = {}          # v94: the last arming refusal written to the log, per product
_need_rearm = {}        # v84: Amazon product -> when the buying browser answered "monitor disabled" for it although you set it to Buy
_said_unwatched = {}
_said_stale = {}
_arm_failed = {}


_arm_try = {}           # product -> time of the last arming attempt (an attempt is not repeated within ARM_RETRY_SEC)
ARM_RETRY_SEC = 2.0     # v58b: no waiting - armed again at once after a checkout that did not buy
_fails = {}             # product -> checkouts in a row that did not buy
LOCK_FOR = 0.0          # v88: the program never locks a product any more (owner 2026-11-01) - old program locks end at once
REST_FOR = 300.0        # v88: after LOCK_AFTER failed checkouts in a row the product RESTS this long, then it is armed again by itself
LOCK_AFTER = 10         # v88: 10 (owner) - ... after this many in a row the product is LOCKED (disarmed, no more CPU spent on it) until you choose Buy again


_RACE_RX = re.compile(r"sold out|out of stock|no longer available|target unavailable|currently unavailable|quantity is zero|"
                      r"identity not verified|not in your .* orders|not ordered", re.I)


def _failed(u, why=""):
    """v88 (owner 2026-11-01: "increase the limit to 10 tries before stopping ... fail open ... may wait 5 minutes before trying to buy
    again, but I don't want it to lock itself (since this is a program error not a product error). Locking the product should only
    happen after a successful purchase or if I manually lock it"): after LOCK_AFTER failed checkouts in a row the product RESTS for
    REST_FOR (5 minutes) and is then armed again by itself. It stays set to Buy the whole time; nothing is locked. A checkout that failed
    because the product sold out under it does not count."""
    if why and _RACE_RX.search(str(why)):
        return
    n = _fails.get(u, 0) + 1
    _fails[u] = n
    if n >= LOCK_AFTER:
        _fails[u] = 0
        _settings.setdefault("rest", {})[u] = time.time() + REST_FOR
        _save()
        _event(u, _name(u, None, None), "REST", f"resting {REST_FOR / 60:.0f} min - {n} checkouts in a row did not buy",
               f"{n} checkouts in a row did not buy, so it waits {REST_FOR / 60:.0f} minutes and then tries again by itself. It stays set to Buy "
               "(nothing is locked).", phone=False)


def _resting(u):
    return max(0.0, float((_settings.get("rest") or {}).get(u) or 0) - time.time())


def _unlock_expired():
    """v85: a program-made lock ends by itself after LOCK_FOR; the product is set to Buy again (never one you switched off yourself)."""
    lk = _settings.get("locked") or {}
    at = _settings.setdefault("locked_at", {})
    now = time.time()
    back = []
    for u in list(lk):
        t0 = at.get(u)
        if t0 is None:
            at[u] = t0 = now - LOCK_FOR             # (a lock from before v85: it ends now)
        if now - t0 >= LOCK_FOR:
            lk.pop(u, None)
            at.pop(u, None)
            _fails.pop(u, None)
            if u not in (_settings.get("armed") or []):
                _want(u, True)
            back.append(u)
    if back:
        _save()
        _log("Locks ended - armed again: " + ", ".join(back[:10]))
        _wake.set()


def _rearm_wait(u):
    return _resting(u)                   # v88: a product resting after LOCK_AFTER failed checkouts is armed again when its rest is over


SOLDOUT_TRIES = 5        # v70b: "sold out" answers in a row that are asked again at once (then the next in-stock reading starts it again)


def _fresh_restock(source):
    """v94 (review): only a NEW restock (the page went from sold out to in stock - 'Restalker' - or a tracker's alert) starts the
    'sold out under us' tries from 0 again; the 20-second "in stock now" reminders, the same product at another store and the retries
    do not (otherwise a page that keeps showing stock which the checkout keeps refusing would be tried 5x every 20 s for ever)."""
    s = str(source or "")
    return s == "Restalker" or s.startswith("tracker:")
_soldout_n = {}
_retrying = set()


def _retry_now(u, t, why):
    """v70b (your rule): a checkout that did not buy is tried again AT ONCE - until the product is locked (LOCK_AFTER failures in a row).
    "Sold out" answers are asked again at once too, up to SOLDOUT_TRIES in a row (they never lock it). Never when you must act
    (human check, sign-in, wrong link), never over the cap, never after an order was placed or may have been."""
    if not t or not t.get("id") or u in _retrying:
        return
    if why == "sold out":
        n = _soldout_n.get(u, 0) + 1
        _soldout_n[u] = n
        if n > SOLDOUT_TRIES:
            return
    else:
        _soldout_n.pop(u, None)
    if not wanted(u) or (_settings.get("locked") or {}).get(u) or _resting(u):
        return
    _retrying.add(u)

    def work():
        try:
            end = time.time() + 15
            while time.time() < end:
                c = _engine_client()
                p = ((c.bb.get(u[3:]) if u.startswith("bb:") else c.catalog.get(u)) if c else None) or {}
                if p.get("purchased") or p.get("attempted") or p.get("submissionPending") or unclear(p) or not wanted(u):
                    return
                if p.get("armed", p.get("monitor")) and not p.get("inProgress"):
                    break
                _wake.set()                      # (the hub arms it again at once)
                time.sleep(0.25)
            with _lock:
                _last_sent.pop(u, None)
                _last_sent.pop(t["id"], None)
            _instock_try[u] = time.time()
            r = signal(t["id"], "retry after: " + why)
            _log(f"{_name(u, None, t)}: tried again at once ({why}) - {r}.")
        finally:
            _retrying.discard(u)
    threading.Thread(target=work, daemon=True, name="buy-retry").start()


_adding = {"busy": False}


_rec = {"at": 0.0}


def _u_of(t):
    return ("bb:" + t["id"]) if _shop(t.get("url")) else asin_of(t.get("url"))


_shape_sent = {}
_probs = {}            # v62: link (asin or 'bb:<row id>') -> why it may NOT be bought (its page shows another product, or not confirmed yet)
_seen_names = {}


def _link_problem(u, t, p=None):
    """v62: '' when this link may be bought, else why not (see linkcheck.buy_problem). The buying browser's own copy of an Amazon
    listing it added itself (its page title) counts as a reading of that page too."""
    if not t:
        return ""
    try:
        import linkcheck
        nm = str((p or {}).get("name") or "")
        if p and p.get("custom") and nm and not nm.startswith(("Amazon ", "Loading ", "Custom ASIN")) and _seen_names.get(u) != nm:
            _seen_names[u] = nm
            linkcheck.note_title(t, nm, _log, source="buying browser")
        why = linkcheck.buy_problem(t)
        if why.startswith("found by search") and u.startswith("bb:"):
            # v67: Target / Walmart / GameStop / Best Buy - the checkout itself opens the product page in the buying browser and goes on
            # only if that page names this exact product (set name and kind) before anything is added to the cart. A store that refuses
            # the readers (Walmart, diagnostics 61) could never "confirm" a found link beforehand, so it was never bought - silently.
            return ""
        return why
    except Exception:
        return ""


_vlinks = {"at": 0.0, "tried": {}}


def _verify_links():
    """v62: a store link that may not be bought only because its page was not read yet (e.g. found by search, or a Best Buy link that is
    read through Best Buy's small data request, which has no product name) is read once through the buying browser's quiet store tab:
    its product name then confirms it (or shows it is the wrong product). One link every 8 seconds, each at most every 10 minutes."""
    if time.time() - _vlinks["at"] < 8:
        return
    _vlinks["at"] = time.time()
    rows = {("bb:" + t["id"]) if _is_bestbuy(t.get("url")) else asin_of(t.get("url")): t for t in _amazon_rows()}
    for u, why in list(_probs.items()):
        t = rows.get(u)
        if not t or not why.startswith("found by search") or time.time() - _vlinks["tried"].get(t["id"], 0) < 600:
            continue
        store = _shop(t.get("url")) or "amazon"
        if store != "amazon" and not reader_ok(store):
            continue
        try:
            import sweep as _sw
            if _sw.resting(store):
                continue                          # v64: the store refused a request a moment ago - nothing is asked of it meanwhile
        except Exception:
            pass
        _vlinks["tried"][t["id"]] = time.time()

        def run(t=t, store=store):
            try:
                import thumbs
                import linkcheck
                text, err = page_fetch(t["url"], store, timeout=25.0)
                title = thumbs.page_title(text or "") if text else ""
                if title:
                    ok = linkcheck.note_title(t, title, _log, source="buying browser")
                    _log(f"{t['id']}: its page was read to confirm the product - " + ("RIGHT product, it can be bought now" if ok else f"'{title[:80]}' is NOT this row's product - never bought"))
            except Exception:
                pass
        threading.Thread(target=run, daemon=True, name="link-verify").start()
        return


def _reconcile(c, cat):
    """v61: the table is the truth. Every few seconds:
      - a product set to Buy is armed at EVERY store whose square is switched on (and only there): a square or store switched off,
        or the product switched off, is never armed - whatever was set before (diagnostics 58: products switched off were still armed);
      - a wish for a link that no longer exists is dropped;
      - anything armed in the buying browser that is NOT wanted is disarmed there (so nothing can be bought that the table does not show as Buy).
    Bought (frozen), unknown-result, locked and 'paused because ordered at another store' links are left as they are."""
    if time.time() - _rec["at"] < 4:
        return
    _rec["at"] = time.time()
    import matrix as _mx
    rows = _amazon_rows()
    wanted_set = set(_settings.get("armed") or [])
    by_prod, known = {}, set()
    for t in rows:
        u = _u_of(t)
        if not u:
            continue
        known.add(u)
        by_prod.setdefault(_mx.key_of(t), []).append((t, u))
    locked = _settings.get("locked") or {}
    paused = _settings.get("sibling_off") or {}

    def engine_rec(u):
        return (c.bb.get(u[3:]) if u.startswith("bb:") else cat.get(u)) or {}
    # v62: links that may not be bought (wrong product, or found by search and not confirmed yet) - never armed, disarmed at once
    probs = {}
    for _lines in by_prod.values():
        for t, u in _lines:
            why = _link_problem(u, t, engine_rec(u))
            if why:
                probs[u] = why
    for u, why in probs.items():
        if _probs.get(u) != why and u in wanted_set:
            _log(f"{_name(u, None, next((t for ls in by_prod.values() for t, uu in ls if uu == u), None))} at "
                 f"{STORE_NAMES.get(_store_of_key(u) if u.startswith('bb:') else 'amazon', 'Amazon')}: NOT BUYING here - {why}")
    _probs.clear()
    _probs.update(probs)
    changed = []
    for key, lines in by_prod.items():
        if not any(u in wanted_set for _, u in lines):
            continue
        any_bought = any(engine_rec(u).get("purchased") for _, u in lines)
        for t, u in lines:
            off = _mx.is_off(t) or not _row_cap(t)
            if off and u in wanted_set:
                _want(u, False)
                wanted_set.discard(u)
                changed.append(f"{_name(u, None, t)} at {STORE_NAMES.get(_shop(t.get('url')) or 'amazon', 'Amazon')}: OFF (its switch in the table is off)")
            elif (not off and u not in wanted_set and not any_bought and u not in locked and u not in paused
                  and not engine_rec(u).get("purchased") and not unclear(engine_rec(u))):
                _want(u, True)
                wanted_set.add(u)
                changed.append(f"{_name(u, None, t)} at {STORE_NAMES.get(_shop(t.get('url')) or 'amazon', 'Amazon')}: ON (the product is set to Buy)")
    for u in list(wanted_set):
        if u not in known:
            _want(u, False)
            changed.append(f"{u}: OFF (that link is no longer in the table)")
    if changed:
        _log("Buy switches brought in line with the table: " + "; ".join(changed[:12]) + (f" (+{len(changed) - 12} more)" if len(changed) > 12 else ""))
    # nothing armed in the buying browser that the table does not show as Buy
    wanted_set = set(_settings.get("armed") or [])
    for a, p in cat.items():
        if p.get("armed") and (a not in wanted_set or a in probs) and not (p.get("inProgress") or p.get("submissionPending")):
            r = command({"type": "DISARM_PRODUCT", "productId": p["id"]}, 20)
            _log(f"{_name(a, p, None)}: disarmed in the buying browser - " + ("NOT the right product at this link: " + probs[a] if a in probs else "it is not set to Buy in the table")
                 + ("" if r.get("ok") else f" ({r.get('reason')})"))
    for k, p in c.bb.items():
        if p.get("armed") and (("bb:" + k) not in wanted_set or ("bb:" + k) in probs) and not (p.get("inProgress") or p.get("submissionPending")):
            r = command({"type": "BB_DISARM", "key": k}, 20)
            _log(f"{_name('bb:' + k, p, None)}: disarmed in the buying browser - " + ("NOT the right product at this link: " + probs["bb:" + k] if ("bb:" + k) in probs else "it is not set to Buy in the table")
                 + ("" if r.get("ok") else f" ({r.get('reason')})"))


def _keep_armed(cat, rows):
    """Every product you set to Buy is armed in the buying engine - unless it is bought (frozen), its last order is being checked,
    its result is unknown (frozen) or a checkout of it is running."""
    for a in [x for x in list(_settings.get("armed") or []) if not x.startswith("bb:")]:
        t = rows.get(a)
        if not t:
            continue
        p = cat.get(a)
        if p is None:
            # a listing the engine does not know yet: added in the background (it opens the page once), then armed
            if not _adding["busy"] and time.time() - _arm_try.get(a, 0) > 60:
                _arm_try[a] = time.time()
                _adding["busy"] = True

                def add(a=a):
                    try:
                        r = command({"type": "ADD_ASIN", "asin": a}, 90)
                        if not r.get("ok"):
                            _log(f"{_name(a, None, rows.get(a))}: the buying browser could not add this Amazon listing yet ({r.get('reason')}) - trying again in a minute.")
                    finally:
                        _adding["busy"] = False
                        _wake.set()
                threading.Thread(target=add, daemon=True, name="buyer-add").start()
            continue
        if p.get("inProgress") or p.get("submissionPending") or p.get("approval"):
            continue
        try:
            import multibuy
            if not p.get("armed") and str(p.get("id") or "").startswith("custom") and multibuy.busy_with(a):
                continue                        # v90: another browser is buying this new listing right now - armed after it (one order)
        except Exception:
            pass
        if p.get("armed") and (p.get("monitor") or "monitor" not in p) and a not in _need_rearm:
            # v84: armed and watched - but is it really being checked? Its last check is long ago while the other products are checked
            # -> armed again (the same as not watched), at most once per 15 minutes
            lc = float(p.get("lastCheck") or 0) / 1000.0
            others = [float(q.get("lastCheck") or 0) / 1000.0 for b, q in cat.items() if b != a and q.get("monitor")]
            fresh_others = others and time.time() - max(others) < 120
            if not (lc and fresh_others and time.time() - lc > 900 and time.time() - _said_stale.get(a, 0) > 900):
                continue
            _said_stale[a] = time.time()
            _log(f"{_name(a, p, t)}: armed, but the buying browser has not checked it for {(time.time() - lc) / 60:.0f} min while it checks "
                 "the others - arming it again.")
        # v84 (diagnostics 69: ~60 restocks of the Amazon Hobbit box at $455.88 in 5 hours, every one answered "monitor disabled" by the
        # buying browser - it showed the product as armed but was no longer watching it, so nothing re-armed it): a product you set to
        # Buy that is armed but NOT being watched is armed again here, the same as one that is not armed
        if p.get("armed") and a not in _need_rearm and time.time() - _said_unwatched.get(a, 0) > 600:
            _said_unwatched[a] = time.time()
            _log(f"{_name(a, p, t)}: the buying browser showed it armed but was not watching it - arming it again.")
        if a in _probs:
            continue                            # v62: this link does not (yet) show the row's exact product - never armed
        if p.get("purchased"):
            continue                            # bought: frozen (the BOUGHT announcement switched the wish off; not repeated here, so a
                                                # 'Buy one more' that the browser has not reported back yet is never undone)
        if unclear(p):
            continue                            # the order check decides (bought -> frozen, not ordered -> armed again, unknown -> frozen)
        if time.time() - _arm_try.get(a, 0) < ARM_RETRY_SEC or _rearm_wait(a) > 0:
            continue
        _nr = _need_rearm.get(a)
        if _nr and time.time() - _nr > 60:
            _need_rearm.pop(a, None)            # v94: the quick re-arming lasts one minute after the restock that wanted it
            _nr = None
        if time.time() - _arm_failed.get(a, 0) < (1.0 if _nr else 60):
            continue                            # v84: the engine refused the last arming - asked again once a minute, not every 2 s
                                                # (v94: every second while a restock waits for it - diagnostics 75: re-armed 20 s - 3 min late)
        _arm_try[a] = time.time()
        cap = _row_cap(t)
        if not cap:
            continue
        if p.get("cap") is None or abs(float(p["cap"]) - cap) > 0.005:
            command({"type": "SET_PRODUCT", "productId": p["id"], "values": {"cap": cap, "monitor": True}}, 20)
        r = command({"type": "ARM_PRODUCT", "productId": p["id"]}, 30)
        if not r.get("ok"):
            _arm_failed[a] = time.time()
        if r.get("ok"):
            _arm_failed.pop(a, None)
            _need_rearm.pop(a, None)
            _last_sent.pop(a, None)          # v58b: armed again -> the very next restock report goes straight to the buying browser (no repeat pause)
        _said = "" if r.get("ok") else str(r.get("reason"))
        if r.get("ok") or _arm_said.get(a) != _said:        # (v94: a refusal is written once, not every second)
            _log(f"{_name(a, p, t)}: ARMED - bought automatically at the next restock at or under {_money(cap)}" + ("" if r.get("ok") else f" - not yet: {r.get('reason')}"))
        _arm_said[a] = _said


# ---------------------------------------------------------------- v58: reading store pages through the buying browser
_reader = {"ok": {}, "failed": {}, "last": {}, "off_until": {}, "fails_row": {}}


def reader_ok(store=None):
    """True when the store reader's own browser can read store pages (connected, current code, not resting for this store).
    v65: this is a SEPARATE browser - the buying browser no longer reads for the watchers (diagnostics 61: the stores refused it at checkout)."""
    c = _reader_client()
    if not c or c.code != VERSION:
        return False
    return time.time() >= _reader["off_until"].get(store or "", 0)


def page_fetch(url, store=None, timeout=25.0):
    """-> (text, error). The store's page or small data request, fetched by the buying browser's quiet tab on that store's own site."""
    text, err, _final = page_fetch_ex(url, store, timeout)
    return text, err


def page_fetch_ex(url, store=None, timeout=25.0, cookies=None):
    """v64: page_fetch, and also the address the store answered from (a store that sends a refused request to its 'blocked' page).
    cookies: names of the store's own place cookies to hand back too (Target's store / zip) - kept in memory only, never logged."""
    store = store or ""
    cmd = {"type": "PAGE_FETCH", "url": url, "timeoutMs": int(timeout * 1000)}
    if cookies:
        _buyer_place(store, cookies)
    r = reader_command(cmd, timeout + 8)
    final = r.get("url") if isinstance(r.get("url"), str) else None
    ok = bool(r.get("ok")) and r.get("text") is not None and int(r.get("status") or 0) < 400
    if ok:
        _reader["ok"][store] = _reader["ok"].get(store, 0) + 1
        _reader["fails_row"][store] = 0
        _reader["last"][store] = f"OK HTTP {r.get('status')} in {r.get('ms')} ms"
        if _reader["ok"][store] == 1:
            _log(f"{STORE_NAMES.get(store, store)}: read through the store reader's own browser (HTTP {r.get('status')}, {r.get('ms')} ms).")
        return r.get("text"), None, final
    why = r.get("reason") or (f"HTTP {r.get('status')}" if r.get("status") else "no answer")
    _reader["failed"][store] = _reader["failed"].get(store, 0) + 1
    n = _reader["fails_row"][store] = _reader["fails_row"].get(store, 0) + 1
    _reader["last"][store] = f"FAILED: {why}"
    if _reader["failed"][store] in (1, 5, 25) or _reader["failed"][store] % 200 == 0:
        _log(f"{STORE_NAMES.get(store, store)}: the reader browser could not read a page ({why[:160]}) - {_reader['failed'][store]} times so far; the other browsers read it meanwhile.")
    if n >= 5:                     # five failures in a row: this store rests from the buying browser for a few minutes (the other browsers carry on)
        _reader["off_until"][store] = time.time() + min(900, 60 * (n - 4))
    return None, f"reader browser: {why}", final


_PLACE_EVERY = 6 * 3600.0


def _buyer_place(store, names):
    """v65: the place (store / zip) your own store pages use is taken from the BUYING browser's cookies - one tiny same-site request
    every 6 hours (it is signed in; the reader browser is not). Kept in memory only, never logged."""
    try:
        rec = _reader.setdefault("cookies_at", {})
        if time.time() - rec.get(store, 0) < _PLACE_EVERY or not _engine_client() or _engine.get("visible"):
            return
        rec[store] = time.time()
        site = {"target": "https://www.target.com/robots.txt"}.get(store)
        if not site:
            return
        r = command({"type": "PAGE_FETCH", "url": site, "timeoutMs": 20000, "cookies": list(names)[:8]}, 30)
        if isinstance(r.get("cookies"), dict) and r["cookies"]:
            _reader.setdefault("cookies", {})[store] = dict(r["cookies"])
    except Exception:
        pass


# v92 (diagnostics 75: the Amazon Hobbit box was looked at every ~5 s in quiet times, but its longest blind spots - 125-134 s -
# fell exactly in the restock waves: every checkout PAUSED all of the store's readers, up to 2 minutes, and five browsers check out at
# once, so the program went blind in the very minutes the next waves came). A checkout no longer pauses the readers of these stores:
# they keep looking at their normal pace (no more requests than usual). v94 (review): only Amazon and Best Buy (0 refusals in 100,000+
# answers). Walmart and Target judge the whole PC's internet address (v83) - more reading while six browsers check out there could bring
# a human check onto the checkout itself - so they, and GameStop, pause for the checkout as before (at most READ_PAUSE_MAX). When the
# whole PC is busy every store pauses.
READ_DURING_CHECKOUT = {"amazon", "bestbuy"}
READ_PAUSE_MAX = 120.0


def readers_pause(store):
    """v92: True when the readers of `store` should wait for the checkout running there (see READ_DURING_CHECKOUT)."""
    if not store:
        return False
    try:
        if store in READ_DURING_CHECKOUT:
            import loadplan
            pcb = loadplan._S.get("pc_busy")
            if pcb is None or pcb <= loadplan.PC_BUSY_SHED:
                return False
    except Exception:
        return False
    return checkout_busy(store)


def checkout_busy(store=None):
    """True while a checkout runs (Amazon or Best Buy): the store readers pause so the checkout has the PC to itself.
    v86: with `store`, only a checkout AT THAT STORE counts (a look at Target's page no longer pauses the Amazon readers)."""
    try:
        import multibuy
        if multibuy.busy(store) if store else multibuy.busy():
            return True                    # (v75: one of the other buying browsers is checking out)
    except Exception:
        pass
    c = _engine_client()
    if not c:
        return False
    if store:
        try:
            import sweep
            return store in sweep._busy_stores()
        except Exception:
            return False
    if c.cart_owner:
        return True
    with _lock:
        return any(p.get("inProgress") or p.get("submissionPending") for p in list(c.catalog.values()) + list(c.bb.values()))


def bb_pdp_check(url):
    """v59b: Best Buy's product page: can the item be SHIPPED (not 'in store only')?
    v65: read by the store reader's own browser (the page's text as the store sends it), never by the buying browser (diagnostics 61:
    every one of these page loads failed in the buying browser, and then its checkout page did too)."""
    text, err = page_fetch(url, "bestbuy", 30)
    if not text:
        return {"ok": False, "reason": err or "no page"}
    return bb_ship_verdict(text)


def bb_ship_verdict(html):
    """Plain reading of a Best Buy product page: is shipping offered, or is it in store only? Unclear -> neither (the data's answer stands)."""
    low = (html or "").lower()
    import stock_detect
    chk = stock_detect.human_check_reason(html)
    if chk:
        return {"ok": True, "check": True, "ships": False, "storeOnly": False, "fulfillment": ["human check page (not answered)"]}
    m = re.search(r"<title[^>]*>(.*?)</title>", html or "", re.I | re.S)
    title = re.sub(r"\s+", " ", m.group(1)).strip() if m else None
    no_ship = re.search(r"(shipping|delivery)\W{0,3}(is\s+)?(not available|unavailable)|not available for (shipping|delivery)|"
                        r"unavailable for (shipping|delivery)|in[- ]store only|pickup only|\"shippingEligible\"\s*:\s*false", low)
    ship = re.search(r"free shipping|get it by|ships? (to|by|in)|shipping\W{0,3}(available|on |\$)|delivery\W{0,3}(available|by )|"
                     r"\"shippingEligible\"\s*:\s*true", low)
    notes = []
    if ship:
        notes.append("page offers shipping")
    if no_ship:
        notes.append("page says: " + no_ship.group(0)[:40])
    sk = re.search(r"SKU:?\s*(?:<[^>]{0,80}>\s*){0,4}(\d{7,9})\b", html or "") or re.search(r'"skuId"\s*:\s*"?(\d{7,9})\b', html or "")
    return {"ok": True, "ships": bool(ship) and not no_ship, "storeOnly": bool(no_ship), "title": title,
            "fulfillment": notes or ["page does not say"], "check": False, "sku": sk.group(1) if sk else None}


def reader_text():
    stores = sorted(set(_reader["ok"]) | set(_reader["failed"]))
    if not stores:
        return "not used yet"
    return "; ".join(f"{s or '?'}: {_reader['ok'].get(s, 0)} OK, {_reader['failed'].get(s, 0)} failed, last {_reader['last'].get(s)}"
                     + (f", resting {int(_reader['off_until'][s] - time.time())} s" if time.time() < _reader["off_until"].get(s, 0) else "") for s in stores)


def check_account():
    r = command({"type": "ACCOUNT_CHECK"}, 40)
    _account["at"] = time.time()
    if r.get("ok"):
        before = _account.get("signedIn")
        _account.update(signedIn=bool(r.get("signedIn")), name=r.get("name"), challenge=bool(r.get("challenge")), error=None)
        if not _account["signedIn"] and not _account.get("challenge"):
            threading.Thread(target=_engine_autologin, args=("amazon", "its sign-in check found it signed out"), daemon=True,
                             name="buyer-relogin").start()             # v90b
        try:
            import logins
            _have_amz = bool(logins.get("amazon"))
        except Exception:
            _have_amz = False
        if before is not False and not _account["signedIn"] and (_settings.get("armed") or []) and not _have_amz:
            try:
                import phone_actions
                _acts = phone_actions.buttons("remote", "")
            except Exception:
                _acts = None
            _phone("ACTION NEEDED - Restalker is not signed in to Amazon",
                   "Armed products cannot be bought. Open Restalker and press 'Sign in to Amazon' (away from the PC: the button opens Remote Desktop).",
                   "buy-signin", actions=_acts)
        if _account["signedIn"] != before:
            _log("Amazon: " + (f"signed in as {_account['name']}." if _account["signedIn"] else
                               ("Amazon shows a 'verify you are human' page - press 'Sign in to Amazon' and answer it yourself."
                                if _account["challenge"] else "NOT signed in - press 'Sign in to Amazon' on the page.")))
    else:
        _account.update(error=r.get("reason"))
    return r


BUYER_MEM_RESTART_GB = float(os.environ.get("RK_BUYER_MEM_GB", "9") or 9)   # v80: the buying browser alone above this ...
BUYER_MEM_MINUTES = 5                                                     # ... for this long, while nothing is being bought ...
BUYER_MEM_EVERY_H = 1                                                     # ... is restarted (at most this often)  (v90: was 20 min / 6 h)
# v90 (diagnostics 74: the buying browser reached 34 GB and 20 processor cores; the PC was down to 0.1 GB free memory and had to be
# stopped): the PC itself is protected too - when the PC has under PC_LOW_GB free memory, or the buying browser alone keeps more than
# BUYER_CPU_CORES cores busy for BUYER_CPU_MINUTES, it is started fresh at once (never during a checkout; at most every 15 minutes)
PC_LOW_GB = 3.0
BUYER_CPU_CORES = 6.0
BUYER_CPU_MINUTES = 5
BUYER_GUARD_EVERY = 900.0
_buyer_mem = {"over_since": 0.0, "last": 0.0, "n": 0, "why": ""}


def _buyer_mem_check(now=None, mb=None):
    """v80 (diagnostics 67: the buying browser held 14 GB in 87 processes, the whole program 23-39 GB, the PC down to 3 GB free - and the
    extra readers could not start for lack of room): the buying browser is started fresh when it has grown too big and nothing is being
    bought. Its sign-ins are kept (same profile) and every product set to Buy is armed again by itself. Returns True when restarted."""
    now = now or time.time()
    try:
        if mb is None:
            import cpu_monitor
            mb = cpu_monitor.part_mb("buyer")
    except Exception:
        mb = None
    if mb is None:
        return False
    why = None
    try:
        import cpu_monitor
        pf = cpu_monitor.pc_free_gb()
        pr = cpu_monitor.parts_now() or {}
        cores = float((pr.get("cpu") or {}).get("buyer", 0.0)) / 100.0
    except Exception:
        pf, cores = None, 0.0
    if cores > BUYER_CPU_CORES:
        _buyer_mem["cpu_since"] = _buyer_mem.get("cpu_since") or now
    else:
        _buyer_mem["cpu_since"] = 0.0
    if now - _buyer_mem["last"] >= BUYER_GUARD_EVERY:
        if pf is not None and pf < PC_LOW_GB and mb / 1024.0 > 2.0:
            why = f"the PC has only {pf:.1f} GB of free memory left (the buying browser holds {mb / 1024.0:.1f} GB)"
        elif _buyer_mem.get("cpu_since") and now - _buyer_mem["cpu_since"] >= BUYER_CPU_MINUTES * 60:
            why = f"it kept {cores:.0f} processor cores busy for {BUYER_CPU_MINUTES} minutes while nothing was being bought"
    if why is None:
        if mb / 1024.0 < BUYER_MEM_RESTART_GB:
            _buyer_mem["over_since"] = 0.0
            return False
        if not _buyer_mem["over_since"]:
            _buyer_mem["over_since"] = now
        if now - _buyer_mem["over_since"] < BUYER_MEM_MINUTES * 60 or now - _buyer_mem["last"] < BUYER_MEM_EVERY_H * 3600:
            return False
    if checkout_busy() or _engine.get("visible") or _hc or _engine.get("signin_open") or _engine.get("state") != "running":
        return False                        # (never during a checkout, a sign-in window or a check you are doing)
    c = _engine_client()
    if c and any(p.get("inProgress") or p.get("submissionPending") or p.get("needCvv") or p.get("approval") for p in list((c.bb or {}).values())):
        return False
    _buyer_mem.update(last=now, n=_buyer_mem["n"] + 1, over_since=0.0, cpu_since=0.0, why=why or f"{mb / 1024.0:.1f} GB")
    _log(f"[buyer] " + (f"to protect the PC ({why})" if why else
                        f"the buying browser has grown to {mb / 1024.0:.1f} GB (limit {BUYER_MEM_RESTART_GB:.0f} GB for {BUYER_MEM_MINUTES} min)")
         + " - nothing is being bought, so it is started fresh (sign-ins kept; your products are armed again by themselves; the other browsers buy meanwhile).")
    _kill_engine()
    return True


def _hub():
    _multi_start()                          # v75: the other buying browsers start with the hub
    _acc = {"at": time.time()}
    _memchk = {"at": time.time()}
    while not _server["stop"]:
        _wake.wait(5)
        _wake.clear()
        if time.time() - _memchk["at"] > 60:
            _memchk["at"] = time.time()
            try:
                _buyer_mem_check()
            except Exception as e:
                _log(f"buyer memory check: {str(e)[:120]}")
        if time.time() - _acc["at"] > 1800:     # (v75: the other browsers' sign-ins are looked at every 30 minutes)
            _acc["at"] = time.time()
            try:
                import multibuy
                multibuy.check_accounts()
            except Exception:
                pass
        if _engine_client() and time.time() - _engine_events["at"] > 600 and not _engine_events["busy"]:
            threading.Thread(target=refresh_engine_events, daemon=True, name="engine-events").start()
        try:
            _hub_pass()
        except Exception as e:
            _log(f"buyer hub: {e}")
        try:
            _instock_amazon()               # v90: works with or without the buying browser
        except Exception as e:
            _log(f"in-stock check (Amazon): {str(e)[:120]}")


# ---------------------------------------------------------------- what the page asks for

def _work(asin, label, fn):
    def run():
        _busy[asin] = label
        try:
            r = fn()
        except Exception as e:
            r = {"ok": False, "reason": str(e)}
        finally:
            _busy.pop(asin, None)
        if not r.get("ok"):
            _events.appendleft({"at": time.strftime("%m-%d %H:%M:%S"), "t": time.time(), "asin": asin, "product": asin, "kind": "ERROR", "text": f"{label} failed: {r.get('reason')}"})
            _log(f"{asin}: {label} failed: {r.get('reason')}")
        _wake.set()
    threading.Thread(target=run, daemon=True, name="buyer-action").start()
    return {"ok": True, "working": label}


def _row(tid):
    t = next((x for x in _amazon_rows(force=True) if x.get("id") == tid), None)
    if not t:
        return None, None, {"ok": False, "reason": "unknown product link"}
    if _is_bestbuy(t.get("url")):
        return t, "bb:" + t["id"], None
    a = asin_of(t.get("url"))
    if not a:
        return None, None, {"ok": False, "reason": "its Amazon link has no product code (ASIN)"}
    return t, a, None


def act(action, tid=None):
    if action in ("on", "off"):
        set_enabled(action == "on")
        return {"ok": True}
    if action == "show":
        return show_browser(True)
    if action == "signin":                      # v58: sign in to ONE store (its own link next to the store in the table)
        return show_browser(True, tid if tid in SIGNIN_URLS else None)
    if action == "hide":
        r = show_browser(False)
        threading.Timer(15, check_account).start()
        _bb["account"]["at"] = 0                 # (Best Buy's sign-in is checked again right away too)
        return r
    if action == "account":
        return check_account()
    if action in ("pickup", "practice"):
        # v65 (your rule): store pickup is never allowed and there is no test run - both options are gone
        return {"ok": False, "reason": "that option was removed"}
    if action == "checkopen":
        # v65: the store page that showed the buying browser a human check, opened in front of you (you answer it; the program never does)
        if not _hc or time.time() - _hc.get("at", 0) > HC_KEEP:
            return {"ok": False, "reason": "that check is over"}
        r = command({"type": "SIGNIN_OPEN", "url": _hc["url"]}, 20)
        if r.get("ok"):
            _hc["opened"] = time.time()
            _engine["signin_store"] = _shop(_hc["url"]) or "amazon"
            _engine["signin_open"] = True
            _guard(True)
            _to_front()
        return r
    if action == "extrasignin":             # v75: sign in to a store in one of the other buying browsers (you type; the program never does)
        import multibuy
        kind, store = (str(tid or "") + ":").split(":")[:2]
        return multibuy.signin(kind, store)
    if action == "checkdismiss":
        _hc.clear()
        return {"ok": True}
    if action == "openlink":
        # v63: a store link from the table opens in Restalker's own buying browser (signed in, and the store answers it) - not in your
        # everyday browser, which a store may be blocking. The window closes with "Done" like the sign-in window.
        url = str(tid or "")
        st = _shop(url) or ("amazon" if _is_amazon(url) else None)
        if not st or not url.startswith("https://"):
            return {"ok": False, "reason": "not a store link"}
        c = _engine_client()
        if not c or not enabled():
            return {"ok": False, "reason": "the buying browser is not running"}
        r = command({"type": "SIGNIN_OPEN", "url": url}, 20)
        if r.get("ok"):
            _engine["signin_store"] = st
            _engine["signin_open"] = True
            _guard(True)
            _to_front()
        return r
    if action in ("verify_yes", "verify_no"):
        # v63: you opened a link the program was not sure about and answered: is it exactly this product?
        t = next((x for x in _amazon_rows(force=True) if x["id"] == tid), None)
        if not t:
            return {"ok": False, "reason": "that link is no longer in the table"}
        import linkcheck
        linkcheck.confirm_by_you(t, action == "verify_yes")
        _seen_names.clear()
        _rec["at"] = 0.0
        if action == "verify_no":
            try:
                import matrix
                matrix.set_cell(t["id"], False)
                matrix.bump()
            except Exception:
                pass
        _log(f"{_name(None, None, t)} at {STORE_NAMES.get(_shop(t.get('url')) or 'amazon', 'Amazon')}: you checked the link - "
             + ("it IS the right product (it may be bought)." if action == "verify_yes" else "it is NOT the right product: its square is switched off and it is never bought there. Change the link to the right page."))
        _wake.set()
        return {"ok": True}
    if action == "stop":
        # v90b (owner 2026-11-02: "the emergency stop and regular stop buttons do not work"): INSTANT and complete - every product is
        # disarmed, buying is switched OFF, and EVERY browser (the buying browser and the other five) stops this instant: none starts a
        # checkout, none presses Place order. The buying browser is told and closed in the background (the page never waits for it).
        _settings["armed"] = []
        _emergency["at"] = time.time()
        _multi_hold(True, "EMERGENCY STOP")

        def tell():
            r = command({"type": "EMERGENCY_STOP"}, 10)
            command({"type": "BB_GLOBAL", "emergencyStop": True}, 10)
            _log("EMERGENCY STOP: the buying browser " + ("disarmed everything." if r.get("ok") else f"did not answer ({r.get('reason')}) - it is closed now."))
            set_enabled(False)
        threading.Thread(target=tell, daemon=True, name="emergency-stop").start()
        threading.Thread(target=_save, daemon=True).start()
        _log("EMERGENCY STOP pressed: every product is disarmed, buying is switched OFF, and no browser starts or finishes a purchase.")
        return {"ok": True}
    if action in ("arm", "disarm"):
        action, tid = action + "group", [tid]
    if action in ("armgroup", "disarmgroup"):
        # v58: INSTANT. The click records your wish at once (the page shows it right away); the buying browser is brought in line
        # a moment later by the hub (arming waits by itself while a checkout is running - nothing is lost).
        tids = [x for x in (tid or []) if isinstance(x, str)] if isinstance(tid, list) else []
        c = _engine_client()
        frozen, nocap, done = [], [], 0
        for x in tids:
            t, u, err = _row(x)
            if err:
                continue
            if action == "disarmgroup":
                if wanted(u):
                    _want(u, False)
                    done += 1
                p = (c.bb.get(u[3:]) if u.startswith("bb:") else c.catalog.get(u)) if c else None
                if p and p.get("armed") and not (p.get("inProgress") or p.get("submissionPending")):
                    cmd = {"type": "BB_DISARM", "key": u[3:]} if u.startswith("bb:") else {"type": "DISARM_PRODUCT", "productId": p["id"]}
                    threading.Thread(target=command, args=(cmd, 20), daemon=True, name="buyer-disarm").start()
                continue
            p = (c.bb.get(u[3:]) if u.startswith("bb:") else c.catalog.get(u)) if c else None
            if p and (p.get("purchased") or unclear(p)):
                frozen.append({"tid": x, "product": _name(u, p, t), "why": "bought" if p.get("purchased") else "unknown"})
                continue
            sib = _bought_elsewhere(t, c) if c else None
            if sib and x not in [f["tid"] for f in frozen]:
                frozen.append({"tid": x, "product": _name(u, p, t) + f" (already bought at {sib})", "why": "bought"})
                continue
            if not _row_cap(t):
                nocap.append(_name(u, p, t))
                continue
            _fails.pop(u, None)                 # (your click: armed right away, whatever happened before)
            (_settings.get("locked") or {}).pop(u, None)
            _last_sent.pop(u, None)
            if not wanted(u):
                _want(u, True)
                _arm_try.pop(u, None)
                done += 1
        if done:
            _log(f"Buy {'ON' if action == 'armgroup' else 'OFF'} for {done} product link(s) - set by you.")
        _wake.set()
        return {"ok": True, "frozen": frozen, "nocap": nocap, "done": done}
    return _act_one(action, tid)


def _act_one(action, tid, wait=False):
    t, a, err = _row(tid)
    if err:
        return err
    if a in _busy and not wait:
        return {"ok": False, "reason": _busy[a] + " already running"}
    work = (lambda asin, label, fn: fn()) if wait else _work
    c = _engine_client()
    if not c:
        return {"ok": False, "reason": "the buying browser is not connected yet (wait a few seconds)"}
    if a.startswith("bb:"):
        return _bb_act(action, t, a, c, work)
    p = c.catalog.get(a)
    cap = _row_cap(t)
    if action == "arm" and p and p.get("armed"):
        return {"ok": True, "reason": "already armed"}
    if action == "disarm" and not (p and p.get("armed")):
        _want(a, False)
        return {"ok": True, "reason": "already off"}
    if action == "arm" and p and p.get("purchased"):
        return {"ok": False, "reason": "already bought once - press 'Buy again' for another"}
    if action == "arm" and unclear(p):
        return {"ok": False, "reason": "the last order's result is not confirmed - check Amazon, then press 'It was bought' or 'Not bought'"}
    if action == "arm":
        if not enabled():
            return {"ok": False, "reason": "turn Amazon auto-buy ON first"}
        if not cap:
            return {"ok": False, "reason": "set a price cap for this product in the table first"}

        def arm():
            pid = (p or {}).get("id")
            if not pid:
                r = command({"type": "ADD_ASIN", "asin": a}, 90)          # a listing the engine did not know: it opens and checks it once
                if not r.get("ok"):
                    return r
                pid = r["productId"]
            r = command({"type": "SET_PRODUCT", "productId": pid, "values": {"cap": cap, "monitor": True}}, 20)
            if not r.get("ok"):
                return r
            r = command({"type": "ARM_PRODUCT", "productId": pid}, 30)
            if r.get("ok"):
                _want(a, True)
                _log(f"{_name(a, p, t)} ARMED by you: it is bought automatically at the next restock at or under {_money(cap)} (item price).")
            return r
        return work(a, "arming", arm)
    if not p:
        return {"ok": False, "reason": "the buying browser does not know this listing yet"}
    if action == "disarm":
        _want(a, False)

        def dis():
            r = command({"type": "DISARM_PRODUCT", "productId": p["id"]}, 20)
            if r.get("ok"):
                _log(f"{_name(a, p, t)} disarmed by you.")
            return r
        return work(a, "disarming", dis)
    if action == "again" and unclear(p):
        _settings.get("unknown", {}).pop(a, None)
        _checks.pop(a, None)

        def unfreeze():
            r = command({"type": "SET_PRODUCT", "productId": p["id"], "values": {
                "purchased": False, "attempted": False, "submissionPending": False, "inProgress": False, "armed": False, "autoBuy": False,
                "status": "NOT ORDERED - set by you"}}, 20)
            if r.get("ok"):
                _want(a, True)
                _arm_try.pop(a, None)
                _log(f"{_name(a, p, t)}: you chose Buy after an unknown result - armed again.")
            return r
        return work(a, "arming", unfreeze)
    if action == "again":
        if not enabled():
            return {"ok": False, "reason": "turn Amazon auto-buy ON first"}
        if not p.get("purchased"):          # v91/v94: its SAME product was bought at another store/listing - you chose one more
            return _buy_more_sibling(a, t, p)

        def again():
            r = command({"type": "REARM_PURCHASED", "productId": p["id"], "expectedAsin": a, "confirmedAdditionalPurchase": True,
                         "expectedPriorSubmitAt": p.get("submitAt") or 0}, 30)
            if r.get("ok"):
                _want(a, True)
                _last_sent.pop(a, None)
                _log(f"{_name(a, p, t)}: Buy again confirmed by you - armed for ONE more purchase.")
                _event(a, _name(a, p, t), "AGAIN", f"BUY ONE MORE chosen by you - Amazon - {_name(a, p, t)}",
                       "armed for ONE more purchase (recorded so every order can be traced to your choice)", phone=False)
                _buy_more_done(t)
            return r
        return work(a, "buy again", again)
    if action in ("markbought", "marknot"):
        if not unclear(p) and not (action == "marknot" and p.get("attempted")):
            return {"ok": False, "reason": "there is no unconfirmed order for this product"}
        vals = ({"purchased": True, "attempted": True, "status": "PURCHASE SUCCESS - confirmed by you"} if action == "markbought" else
                {"purchased": False, "attempted": False, "submissionPending": False, "inProgress": False, "armed": False, "autoBuy": False,
                 "status": "NOT ORDERED - checked by you"})

        def mark():
            r = command({"type": "SET_PRODUCT", "productId": p["id"], "values": vals}, 20)
            if r.get("ok"):
                _checks.pop(a, None)
                _log(f"{_name(a, p, t)}: you marked the unconfirmed order as {'BOUGHT' if action == 'markbought' else 'NOT bought'}.")
            return r
        return work(a, "saving", mark)
    if action == "approve":
        return work(a, "approving shipping", lambda: command({"type": "APPROVE_SHIPPING", "productId": p["id"]}, 30))
    if action == "cancel":
        _want(a, False)
        return work(a, "cancelling", lambda: command({"type": "CANCEL_SHIPPING", "productId": p["id"]}, 30))
    return {"ok": False, "reason": "unknown action"}


def _multi_hold(on, why=""):
    """v90b: the other buying browsers stop at once (no new checkout; none presses Place order) - or may buy again."""
    try:
        import multibuy
        multibuy.hold(on, why)
    except Exception:
        pass


def set_enabled(on):
    """v90b (owner 2026-11-02: "the emergency stop and regular stop buttons do not work"): answers AT ONCE - the switch is set, every
    browser stops starting checkouts this instant; closing the buying browser happens right after, in the background (it could take
    seconds, and the page waited for it)."""
    _settings["on"] = bool(on)
    _multi_hold(not on, "buying is OFF")
    if not on:
        _engine["state"] = "off"

        def close():
            command({"type": "SET_GLOBAL", "values": {"liveGlobal": False}}, 5)     # first: no purchase may start; then the browser is closed
            command({"type": "BB_GLOBAL", "live": False}, 5)
            with _elock:
                _kill_engine()
                _engine.update(state="off", detail="")
        threading.Thread(target=close, daemon=True, name="buyer-off").start()
    threading.Thread(target=_save, daemon=True).start()
    _log(f"Amazon auto-buy switched {'ON' if on else 'OFF - no purchase can start and the buying browser is closed'} by you.")


# ---------------------------------------------------------------- v56: Best Buy (Restalker's own checkout in the same buying browser)

_STOP_WORDS = {"the", "of", "and", "a", "an", "mtg", "magic", "gathering", "-", "&", ":", "tcg", "wizards", "coast"}


def _user_link(t):
    """v75: a link YOU gave (not found by the program's search) - see linkcheck.user_link."""
    try:
        import linkcheck
        return linkcheck.user_link(t)
    except Exception:
        return False


def _bb_words(t):
    """The words the store's product page / cart / checkout must show for this row, and words it must NOT show.
    v62: the row's KIND is always among them (diagnostics 60: rows like 'Phyrexia: All Will Be One' carry only the set name, so a single
    pack would have passed for the box): a box row needs box / display / case, a pack row may not show them, a bundle row needs bundle."""
    import products as _pr
    kind = _pr.kind_of(t)
    name = str(t.get("match_name") or "").lower()
    toks = [w for w in re.findall(r"[a-z0-9']+", name) if w not in _STOP_WORDS and len(w) > 1]
    toks = ["box|display|case" if w in ("box", "display") else w for w in toks]       # v60: Target calls a box a "Display"
    toks = ["collector|collecter" if w == "collector" else w for w in toks]      # v62: GameStop spells it "Collecter" on some pages
    forbid = []
    if kind in ("box", "play_booster_box", "set_booster_box"):
        if "box|display|case" not in toks:
            toks.append("box|display|case")
        if kind == "box" and "collector|collecter" not in toks:
            toks.append("collector|collecter")
    elif kind == "pack":
        toks = [w for w in toks if w != "box|display|case"]
        forbid += ["booster box", "booster display", "collector box", "booster case"]   # a single pack row must never buy a box
        if "collector|collecter" not in toks:
            toks.append("collector|collecter")
    elif kind == "bundle" and "bundle" not in toks:
        toks.append("bundle")
    if "bundle" not in toks:
        forbid.append("bundle")
    if kind != "commander_deck":
        forbid.append("commander deck")
    # the kind words go first: the engine keeps at most 8 words
    kw = [w for w in toks if w in ("box|display|case", "bundle", "collector|collecter")]
    rest = [w for w in toks if w not in kw]
    return (kw + rest)[:8], forbid[:6]


def _bb_rows():
    return {t["id"]: t for t in _amazon_rows() if _is_bestbuy(t.get("url"))}


# v94 (review of v91): "Buy one more" is ONE more of the PRODUCT. The links of it at the other stores were frozen only because it was
# bought at one of them; they follow that one: while it is still marked bought they wait (they never check out - the one-per-product
# rule would only stop them at Place order, again and again), and the moment it is set to Buy one more they are set to Buy too, and the
# buying browser's own "already ordered" notes for the product (an order placed by one of the other browsers) are cleared.
_more_wait = {}           # product (row name) -> {"links": set of links, "at": time}
_more_granted = {}        # product (row name) -> when its bought link was set to Buy one more
MORE_WAIT_FOR = 900.0


def _buy_more_sibling(u, t, p):
    c = _engine_client()
    g = _name("", None, t)
    sib = _bought_elsewhere(t, c) if c else None
    if sib and time.time() - _more_granted.get(g, 0) < MORE_WAIT_FOR:
        sib = None                            # (its bought link WAS just set to Buy one more - the record here is only a moment behind)
    if sib:
        w = _more_wait.setdefault(g, {"links": set(), "at": time.time()})
        w["links"].add(u)
        w["at"] = time.time()
        _log(f"{_name(u, p, t)}: Buy one more - set to Buy the moment the order at {sib} is set to Buy one more (one more of the product in all).")

        def remind(g=g, u=u, sib=sib):
            time.sleep(60)
            w = _more_wait.get(g)
            if w and u in w["links"]:
                _event(u, g, "ACTION", f"Buy one more of {g}: choose 'Buy one more' on the {sib} listing too",
                       f"The order at {sib} is still marked bought, so the other stores wait for it (one more of the product in all).", phone=False)
        threading.Thread(target=remind, daemon=True, name="buy-more-remind").start()
        return {"ok": True, "waiting_for": sib}
    _want(u, True)
    _arm_try.pop(u, None)
    _last_sent.pop(u, None)
    _log(f"{_name(u, p, t)}: Buy one more confirmed by you - armed.")
    return {"ok": True}


def buy_one_more(tid):
    """v96: 'Buy one more' from the phone message = what pressing Buy on that product in Restalker's table does after a purchase (and
    answering 'Buy ONE MORE?' with OK): every link of the product that is switched on is set to Buy; the bought one(s) are set to buy ONE
    more (an order whose result is UNKNOWN is NOT unfrozen this way - that needs your answer to that order)."""
    import matrix as _mx
    t, a, err = _row(tid)
    if err:
        return err
    if not enabled():
        return {"ok": False, "reason": "buying is switched OFF on the PC (top bar) - nothing changed"}
    if _mx.is_off(t):
        return {"ok": False, "reason": "this product is switched off in the table - nothing changed"}
    key = _mx.key_of(t)
    tids = [o["id"] for o in _amazon_rows(force=True) if _mx.key_of(o) == key and not _mx.is_off(o)]
    c = _engine_client()
    for x in tids:
        # an order of this product whose result is not known yet: nothing is armed anywhere (a second one could be bought meanwhile)
        t_, u_, e_ = _row(x)
        p_ = ((c.bb.get(u_[3:]) if u_.startswith("bb:") else c.catalog.get(u_)) if (c and u_) else None)
        if p_ and unclear(p_):
            return {"ok": False, "reason": f"its order at {_store_word(u_)} has no confirmed result yet - answer that message (It was bought / "
                                           "Not ordered) first; nothing changed"}
    r = act("armgroup", tids) or {}
    if not r.get("ok"):
        return r
    fr = r.get("frozen") or []
    bought = [f for f in fr if f.get("why") == "bought"]
    unknown = [f for f in fr if f.get("why") != "bought"]
    if not bought:
        if r.get("done"):
            return {"ok": True, "text": f"{_name(a, None, t)} is set to Buy again ({r['done']} link(s)) - it was not marked bought anywhere."}
        return {"ok": False, "reason": ("its last order's result is still UNKNOWN - answer that message first" if unknown else
                                        "it is not bought and already set to Buy - nothing to change")}
    bad = []
    for f in bought:
        x = act("again", f["tid"]) or {}
        if not x.get("ok"):
            bad.append(f"{f.get('product')}: {x.get('reason')}")
    if bad and len(bad) == len(bought):
        return {"ok": False, "reason": "; ".join(bad)[:300]}
    return {"ok": True, "text": f"Armed for ONE more: {_name(a, None, t)} is bought once more at the next restock, at or under its price cap."
            + (f" (Not changed: {'; '.join(bad)[:200]})" if bad else "") + (" An order with an UNKNOWN result stays frozen." if unknown else "")}


def phone_do(kind, tid):
    """v96: what a button on a phone message does (phone_actions.py) - the same as the same button on Restalker's own page, with the
    state checked again first (the message may be minutes old: an order may have been confirmed meanwhile)."""
    if kind == "more":
        return buy_one_more(tid)
    t, a, err = _row(tid)
    if err:
        return err
    if a in _busy:
        return {"ok": False, "reason": _busy[a] + " is already running for it - try again in a moment"}
    c = _engine_client()
    if not c:
        return {"ok": False, "reason": "the buying browser is not connected right now"}
    p = (c.bb.get(a[3:]) if a.startswith("bb:") else c.catalog.get(a)) or {}
    nm = _name(a, p, t)
    if kind == "bought":
        if p.get("purchased"):
            return {"ok": True, "text": f"{nm} is already recorded as bought - nothing more is bought for it."}
        r = _act_one("markbought", tid, wait=True) or {}
        if r.get("ok"):
            r["text"] = f"{nm} is marked as BOUGHT - nothing more is bought for it (tap Buy one more on a purchase message to buy another)."
        return r
    if kind == "notbought":
        if not unclear(p):
            return {"ok": False, "reason": ("it was confirmed BOUGHT meanwhile" if p.get("purchased") else
                                            "its order is no longer unconfirmed") + " - nothing changed"}
        r = _act_one("again", tid, wait=True) or {}
        if r.get("ok"):
            r["text"] = f"{nm}: recorded as NOT ordered and set to Buy again - it is bought at the next restock, at or under its price cap."
        return r
    if kind in ("approve", "cancel"):
        if not p.get("approval"):
            return {"ok": False, "reason": "that checkout is no longer waiting for your answer"}
        r = _act_one(kind, tid, wait=True) or {}
        if r.get("ok"):
            r["text"] = (f"{nm}: shipping approved - the checkout goes on." if kind == "approve" else f"{nm}: not bought (shipping not approved).")
        return r
    return {"ok": False, "reason": "unknown button"}


def _buy_more_done(t):
    g = _name("", None, t)
    _more_granted[g] = time.time()
    try:
        c = _engine_client()
        info = _group_info(t, c) if c else {}
        command({"type": "BB_UNMARKORDERED", "group": g, "pid": info.get("amazonPid")}, 5)
    except Exception:
        pass
    try:
        import multibuy
        multibuy.unlock(g)
    except Exception:
        pass
    try:
        for u2 in _co_group_rows(g):
            _co_forget(u2)
    except Exception:
        pass
    w = _more_wait.pop(g, None)
    if w and time.time() - w["at"] < MORE_WAIT_FOR:
        for u2 in w["links"]:
            _want(u2, True)
            _arm_try.pop(u2, None)
            _last_sent.pop(u2, None)
        _log(f"{g}: its other store links you chose Buy one more for are set to Buy now ({len(w['links'])}).")
        _wake.set()


def _bought_elsewhere(t, c):
    """v60: the store where the same product (same row) was already bought, or None - one of a product across all stores."""
    nm = _name("", None, t)
    for o in _amazon_rows():
        if o.get("id") == t.get("id") or _name("", None, o) != nm:
            continue
        if _is_amazon(o.get("url")):
            q = c.catalog.get(asin_of(o.get("url")) or "")
            st = "Amazon"
        else:
            q = c.bb.get(o["id"])
            st = STORE_NAMES.get(_shop(o.get("url")), "another store")
        if q and q.get("purchased"):
            return st
    return None


def _group_info(t, c):
    """v60: the product a shop link belongs to (its row name) and that product's Amazon listing in the buying browser - so a Place Order
    is never pressed at one store while the same product is being or was ordered at another (one of a product, across all stores)."""
    nm = _name("", None, t)
    pid = None
    for o in _amazon_rows():
        if _is_amazon(o.get("url")) and _name("", None, o) == nm:
            a = asin_of(o.get("url"))
            pid = ((c.catalog.get(a) or {}).get("id")) if (c and a) else None
            break
    return {"group": nm, "amazonPid": pid}


def _bb_pass(c):
    if time.time() < _bb.get("blocked_until", 0):
        return
    if VERSION not in (_engine.get("running_name") or VERSION) or (_engine.get("running_code") or f"{VERSION}/{VERSION}") != f"{VERSION}/{VERSION}":
        return                                   # (an old engine does not know the Best Buy commands: nothing is sent, see engine_problem())
    rows = _bb_rows()
    with _lock:
        bb = dict(c.bb)
    # 1) purchase events -> log, top bar, phone
    for key, p in bb.items():
        u = "bb:" + key
        prev = _prev.get(u)
        if prev is not None:
            try:
                _notice(u, p, prev, rows.get(key), STORE_NAMES.get(_store_of_key(key), "Best Buy"))
            except Exception as e:
                _log(f"Best Buy notice: {e}")
        _prev[u] = p
        _durable(u, p, rows.get(key), STORE_NAMES.get(_store_of_key(key), "Best Buy"))
    # 2) the switches: live (the master switch), store pickup
    want = (enabled(), bool(_settings.get("bb_pickup")))
    if _bb["global"] != want:
        r = command({"type": "BB_GLOBAL", "live": want[0], "allowPickup": want[1]}, 15)
        if r.get("ok"):
            _bb["global"] = want
    if not enabled():
        return
    running = any(p.get("inProgress") or p.get("submissionPending") for p in bb.values())
    # 3) the product data (link, words, cap, Best Buy number) - the cap in the table is the most it pays for the item
    for key, t in rows.items():
        p = bb.get(key)
        if p and (p.get("inProgress") or p.get("submissionPending")):
            continue
        toks, forbid = _bb_words(t)
        mine = _user_link(t)
        if mine:
            toks, forbid = [], []                 # v75: a link YOU gave is the product - not checked against the row's name
        data = {"type": "BB_SET", "key": key, "url": t.get("url"), "name": _name("bb:" + key, None, t), "tokens": toks, "forbid": forbid,
                "sku": str(t.get("sku") or "") or None, "cap": _row_cap(t), "trusted": mine, **_group_info(t, c)}
        sig = json.dumps(data, sort_keys=True)
        if p is None or _bb["sent"].get(key) != sig or (data["cap"] and p.get("cap") != data["cap"]):
            r = command(data, 15)
            if r.get("ok"):
                _bb["sent"][key] = sig
            elif "not allowed" in str(r.get("reason")) or "unknown" in str(r.get("reason")):
                _bb["blocked_until"] = time.time() + 600
                _log(f"Best Buy: the buying engine refused the product list ({r.get('reason')}) - " + (engine_problem() or "trying again in 10 minutes."))
                return
    # 4) v58: what you set to Buy stays armed (also right after a checkout that did not buy); bought or unknown = frozen
    _engine["bb_rearm_due"] = False
    # (v75: not held back while ANOTHER store or product is checking out - every store checks out at the same moment; each store's
    #  own checkout takes one product at a time by itself, and the buying browser presses ONE Place order of a product at a time)
    if True:
        for u in [x for x in (_settings.get("armed") or []) if x.startswith("bb:")]:
            key = u[3:]
            p = bb.get(key)
            if key not in rows or not p or p.get("armed") or p.get("inProgress") or p.get("submissionPending") or p.get("needCvv") or p.get("approval"):
                continue
            if u in _probs:
                continue                        # v62: the link does not (yet) show the row's exact product
            if p.get("purchased"):
                continue
            if unclear(p) or time.time() - _arm_try.get(u, 0) < ARM_RETRY_SEC or _rearm_wait(u) > 0:
                continue
            _arm_try[u] = time.time()
            r = command({"type": "BB_ARM", "key": key}, 15)
            if r.get("ok"):
                _last_sent.pop(u, None)
                _last_sent.pop(key, None)
            _log(f"{_name(u, p, rows[key])} ({STORE_NAMES.get(_store_of_key(key), 'Best Buy')}): ARMED" + ("" if r.get("ok") else f" - not yet: {r.get('reason')}"))
    # 4c) v65: set to buy AND in stock right now at or under the cap -> bought now (diagnostics 61: the Walmart sleeves were read IN STOCK
    #     at $8.95, cap $15, set to buy - and nothing happened, because a purchase only started when a product TURNED from out to in)
    if True:
        try:
            _instock_now(rows, bb)
        except Exception as e:
            _log(f"in-stock check for buying: {e}")
    # 5) v60: sign-in of every shop store (every 30 min) and each store's daily practice run of its checkout
    stores = ["bestbuy"] + sorted({_store_of_key(k) for k in rows} - {"bestbuy"})
    accs = _bb.setdefault("accounts", {"bestbuy": _bb["account"]})
    for store in stores:
        a = accs.setdefault(store, {"at": 0.0, "signedIn": None, "reason": None})
        nm = STORE_NAMES.get(store, store)
        if time.time() - a["at"] > (ACCOUNT_EVERY_SEC if a["signedIn"] else 300) and not a.get("busy") and not _engine.get("signin_open"):
            a["busy"] = True

            def acc(a=a, store=store, nm=nm):
                # v62: in the background - the hub (arming, restocks) never waits for a sign-in check
                try:
                    r = command({"type": "BB_ACCOUNT", "store": store}, 60)
                    before = a["signedIn"]
                    got = r.get("signedIn") if r.get("ok") else None
                    # a check that could not decide never turns "signed in" into "not signed in" (it is asked again in a minute)
                    a.update(at=time.time() if got is not None else time.time() - (ACCOUNT_EVERY_SEC if before else 300) + 60,
                             signedIn=got if got is not None else before, reason=r.get("reason"), how=r.get("how"))
                    if a["signedIn"] is False and _engine_autologin(store, "its sign-in check found it signed out"):
                        pass                                   # (v90b: signed itself in - checked again in a moment)
                    elif a["signedIn"] is False and before is not False:
                        _log(f"{nm}: NOT signed in in the buying browser - use 'Sign in' above the {nm} column and sign in once"
                             " (or save its sign-in under Sign-ins (top bar): then it signs itself in).")
                    elif a["signedIn"] and not before:
                        _log(f"{nm}: signed in.")
                        _settings.setdefault("practice_at", {})[store] = 0          # just signed in: its practice run comes right away
                finally:
                    a["busy"] = False
            threading.Thread(target=acc, daemon=True, name="shop-account").start()
        due = time.time() - float((_settings.get("practice_at") or {}).get(store, _settings.get("bb_practice_at") if store == "bestbuy" else 0) or 0) > 20 * 3600
        if (PRACTICE_RUNS and a["signedIn"] and due and not running and not _bb["practice_running"] and time.time() - _engine.get("launched_at", 0) > 120
                and not _engine.get("signin_open")):
            practice_run(manual=False, store=store)
            break


INSTOCK_FRESH = 180.0      # v65: a reading this recent counts as "in stock right now"
INSTOCK_LAST = 6 * 3600.0  # ... or, while the store is not answering the readers, its last real answer within this long (v67: was 30 min)
INSTOCK_STORE_GAP = 60.0   # ... that older answer is tried by the buying browser at most once per this long per store (it opens one page)
_instock_store = {}
INSTOCK_EVERY = 20.0       # the same product is tried this way at most this often (a checkout that did not buy re-arms it by itself)
_instock_try = {}


def _instock_now(rows, bb):
    """v65: a product you set to buy that is IN STOCK at or under its cap right now is bought now - not only at the moment it turns from
    out of stock to in stock. One at a time; the checkout itself checks everything again (exact product, stock, price, cap)."""
    if not STATUS:
        return
    now = time.time()
    for key, t in rows.items():
        p = bb.get(key)
        u = "bb:" + key
        if not p or not p.get("armed") or p.get("purchased") or p.get("attempted") or p.get("inProgress") or p.get("submissionPending"):
            continue
        if u in _probs or now - _instock_try.get(u, 0.0) < INSTOCK_EVERY:
            continue
        r = STATUS(key) or {}
        st, price, at = r.get("status"), r.get("price"), float(r.get("checked_at") or 0)
        lg = r.get("last_good") or {}
        store = _store_of_key(key)
        if _hc and _hc.get("store") == STORE_NAMES.get(store) and now - _hc.get("at", 0) < HC_KEEP:
            continue                              # (the store showed a "prove you are a person" page: it waits for you, not asked again -
                                                  #  also while its window is open; closing it tries again at once. v75: was asked again
                                                  #  while you were doing the check, which showed a new check and lost your "close")
        over_then = st == "OUT_OF_STOCK" and r.get("high_price") and price is not None and now - at < INSTOCK_FRESH
        if over_then:
            pass                                  # v90: for sale over the cap a moment ago - bought now if your cap was raised to cover it
        elif not (st == "IN_STOCK" and now - at < INSTOCK_FRESH):
            if not (st not in ("IN_STOCK", "OUT_OF_STOCK") and lg.get("status") == "IN_STOCK" and now - float(lg.get("at") or 0) < INSTOCK_LAST):
                continue
            if now - float(lg.get("at") or 0) > INSTOCK_FRESH and now - _instock_store.get(store, 0.0) < INSTOCK_STORE_GAP:
                continue                          # (the store refuses the readers: its last real answer is tried, calmly)
            price, at = lg.get("price"), float(lg.get("at") or 0)
            _instock_store[store] = now
        cap = _row_cap(t)
        try:
            if cap is None or (price is not None and float(price) > cap + 0.001):
                continue
        except Exception:
            continue
        _instock_try[u] = now
        _last_sent.pop(u, None)
        d = DESCRIBE(key) if DESCRIBE else None
        res = _bb_signal(key, d, "in stock now", price, at or None)
        _fan_out(key, "in stock now", at or None, always=False)      # (v75: the other stores of the same product at the same moment)
        _log(f"{_name(u, p, t)} ({STORE_NAMES.get(_store_of_key(key), 'Best Buy')}): set to buy and IN STOCK at {_money(price)} "
             f"(cap {_money(cap)}) - buying now ({res}).")
        # (v75: no "one at a time" - every product in stock starts now; each store's checkout takes its own turn)


def _instock_amazon():
    """v90 (your report, diagnostics 73: a new Amazon listing was for sale at $12.99, your cap $10; you raised the cap to $15 and nothing
    was bought for minutes): an Amazon listing you set to Buy that is for sale at or under its cap RIGHT NOW is passed on at once - also
    when the cap was just raised over a price read a moment ago, and also when the buying browser does not know the listing yet (the
    other browsers then buy it). Not more often than every INSTOCK_EVERY seconds per listing."""
    if not STATUS or not enabled():
        return
    now = time.time()
    for a in [x for x in list(_settings.get("armed") or []) if not x.startswith("bb:")]:
        if a in _probs or _resting(a) or now - _instock_try.get(a, 0.0) < INSTOCK_EVERY:
            continue
        t = next((o for o in _amazon_rows() if _is_amazon(o.get("url")) and asin_of(o.get("url")) == a), None)
        if not t:
            continue
        r = STATUS(t["id"]) or {}
        st, price, at = r.get("status"), r.get("price"), float(r.get("checked_at") or 0)
        if now - at > INSTOCK_FRESH or price is None:
            continue
        if not (st == "IN_STOCK" or (st == "OUT_OF_STOCK" and r.get("high_price"))):
            continue
        cap = _row_cap(t)
        try:
            if cap is None or float(price) > cap + 0.001:
                continue
        except Exception:
            continue
        c = _engine_client()
        p = (c.catalog.get(a) if c else None) or {}
        if p.get("purchased") or p.get("inProgress") or p.get("submissionPending") or unclear(p):
            continue
        _instock_try[a] = now
        _last_sent.pop(a, None)
        res = _signal_one(t["id"], "in stock now" if st == "IN_STOCK" else "cap raised - for sale under your cap now", price, at)
        _log(f"{_name(a, p, t)} (Amazon): set to buy and for sale at {_money(price)} (cap {_money(cap)}) - buying now ({res}).")


PRACTICE_RUNS = False      # v65 (your rule): no test runs at the stores (they also added to the store's view of the buying browser)


def practice_run(manual=True, store=None):
    """A store's checkout walked on the REAL site, stopping before 'Place Your Order'; the item is taken out of the cart again.
    It proves every step (and records what the store's pages show) without buying anything. Daily by itself for each store you are
    signed in to, or for every store by the button. Best Buy can practise with a search item; the other stores practise with one of
    YOUR products when the table shows it in stock (a store with nothing in stock is practised later)."""
    if _bb["practice_running"]:
        return {"ok": False, "reason": "a practice run is already running"}
    c = _engine_client()
    if not c:
        return {"ok": False, "reason": "the buying browser is not connected yet"}
    stores = [store] if store else ["bestbuy"] + sorted({_store_of_key(k) for k in _bb_rows()} - {"bestbuy"})
    plan = []
    for st_ in stores:
        pick = None
        for key, t in _bb_rows().items():
            if _store_of_key(key) != st_:
                continue
            stt = (STATUS(key) if STATUS else None) or {}
            if stt.get("status") == "IN_STOCK":
                pick = t
                break
        nm = STORE_NAMES.get(st_, st_)
        if pick:
            toks, forbid = _bb_words(pick)
            plan.append((st_, {"type": "BB_PRACTICE", "store": st_, "url": pick["url"], "name": _name("bb:" + pick["id"], None, pick), "tokens": toks, "mode": "product"},
                         _name("bb:" + pick["id"], None, pick) + " (in stock now in your table)"))
        elif st_ == "bestbuy":
            plan.append((st_, {"type": "BB_PRACTICE", "store": st_, "url": BB_PRACTICE_SEARCH, "name": "first item of a Best Buy search for 'usb c cable'", "mode": "search"},
                         "an in-stock item from a Best Buy search (none of your products is in stock right now)"))
        else:
            # v61: like Best Buy, the other stores practise with a cheap in-stock item from a search (taken out of the cart again)
            plan.append((st_, {"type": "BB_PRACTICE", "store": st_, "url": PRACTICE_SEARCH[st_], "name": f"first item of a {nm} search for 'usb c cable'", "mode": "search"},
                         f"an in-stock item from a {nm} search (none of your {nm} products is in stock right now)"))
    _save()
    if not plan:
        return {"ok": False, "reason": "no store has an in-stock item to practise with right now"}
    _bb["practice_running"] = True

    def run():
        try:
            for st_, cmd, what in plan:
                nm = STORE_NAMES.get(st_, st_)
                _settings.setdefault("practice_at", {})[st_] = time.time()
                if st_ == "bestbuy":
                    _settings["bb_practice_at"] = time.time()
                _save()
                _bb.setdefault("practices", {})[st_] = {"at": time.time(), "running": True, "what": what}
                if st_ == "bestbuy":
                    _bb["practice"] = _bb["practices"][st_]
                _log(f"{nm} practice run started ({'by you' if manual else 'daily, by itself'}): {what}. It stops before 'Place Your Order' and empties the cart again.")
                r = command(cmd, 1200)
                res = (r or {}).get("result") or r or {}
                steps = [x.get("name") for x in (res.get("steps") or [])]
                ok = bool(res.get("ok"))
                _bb["practices"][st_] = {"at": time.time(), "running": False, "what": what, "ok": ok, "steps": steps, "reason": res.get("reason"),
                                         "kind": res.get("kind"), "removed": res.get("removed"), "page": res.get("page"), "raw_steps": res.get("steps")}
                if st_ == "bestbuy":
                    _bb["practice"] = _bb["practices"][st_]
                _settings.setdefault("practice_last", {})[st_] = {k: v for k, v in _bb["practices"][st_].items() if k in ("at", "what", "ok", "steps", "reason")}
                _save()                            # v62: kept, so the diagnostics show each store's last practice run also after a restart
                if ok:
                    _log(f"{nm} practice run PASSED: " + " -> ".join(steps) + ("" if res.get("removed") else " (the item could NOT be taken out of the cart - please remove it)"))
                else:
                    _log(f"{nm} practice run STOPPED at '{steps[-1] if steps else 'start'}': {res.get('reason')}. Page seen: {json.dumps(res.get('page'))[:600]}")
        finally:
            _bb["practice_running"] = False
            _wake.set()
    threading.Thread(target=run, daemon=True, name="shop-practice").start()
    return {"ok": True, "working": "practice run"}


def _bb_act(action, t, u, c, work):
    key = u[3:]
    p = c.bb.get(key)
    cap = _row_cap(t)
    nm = _name(u, p, t) + f" ({STORE_NAMES.get(_store_of_key(u), 'Best Buy')})"
    if action == "arm":
        if p and p.get("armed"):
            return {"ok": True, "reason": "already armed"}
        if p and p.get("purchased"):
            return {"ok": False, "reason": "already bought once - press 'Buy again' for another"}
        if unclear(p):
            return {"ok": False, "reason": "the last order's result is not confirmed - check Best Buy, then press 'It was bought' or 'Not bought'"}
        if not enabled():
            return {"ok": False, "reason": "turn auto-buy ON first (top bar)"}
        if not cap:
            return {"ok": False, "reason": "set a price cap for this product in the table first"}

        def arm():
            toks, forbid = _bb_words(t)
            mine = _user_link(t)
            if mine:
                toks, forbid = [], []             # v75: a link YOU gave is the product
            r = command({"type": "BB_SET", "key": key, "url": t.get("url"), "name": _name(u, None, t), "tokens": toks, "forbid": forbid,
                         "sku": str(t.get("sku") or "") or None, "cap": cap, "trusted": mine}, 15)
            if not r.get("ok"):
                return r
            r = command({"type": "BB_ARM", "key": key}, 15)
            if r.get("ok"):
                _want(u, True)
                _log(f"{nm} ARMED by you: it is bought automatically at the next restock at or under {_money(cap)} (item price).")
                st = (STATUS(key) if STATUS else None) or {}
                try:
                    pr = float(st.get("price")) if st.get("price") not in (None, "") else None
                except Exception:
                    pr = None
                if st.get("status") == "IN_STOCK" and (pr is None or pr <= cap):
                    _last_sent.pop(u, None)
                    signal(key, "Restalker (in stock when armed)", pr)
            return r
        return work(u, "arming", arm)
    if not p:
        if action == "disarm":
            _want(u, False)
            return {"ok": True}
        return {"ok": False, "reason": "the buying browser does not know this Best Buy product yet"}
    if action == "disarm":
        _want(u, False)
        return work(u, "disarming", lambda: command({"type": "BB_DISARM", "key": key}, 15))
    if action == "again" and unclear(p):
        _settings.get("unknown", {}).pop(u, None)
        _checks.pop(u, None)

        def unfreeze():
            r = command({"type": "BB_MARK", "key": key, "bought": False}, 15)
            if r.get("ok"):
                _want(u, True)
                _arm_try.pop(u, None)
                _log(f"{nm}: you chose Buy after an unknown result - armed again.")
            return r
        return work(u, "arming", unfreeze)
    if action == "again":
        if not enabled():
            return {"ok": False, "reason": "turn auto-buy ON first (top bar)"}
        if not p.get("purchased"):          # v91/v94: its SAME product was bought at another store - you chose one more
            return _buy_more_sibling(u, t, p)

        def again():
            r = command({"type": "BB_BUY_AGAIN", "key": key, "confirmedAdditionalPurchase": True}, 15)
            if r.get("ok"):
                _want(u, True)
                _last_sent.pop(u, None)
                _log(f"{nm}: Buy again confirmed by you - armed for ONE more purchase.")
                _event(u, nm, "AGAIN", f"BUY ONE MORE chosen by you - {nm}",
                       "armed for ONE more purchase (recorded so every order can be traced to your choice)", phone=False)
                _buy_more_done(t)
            return r
        return work(u, "buy again", again)
    if action in ("markbought", "marknot"):
        if not unclear(p) and not (action == "marknot" and p.get("attempted")):
            return {"ok": False, "reason": "there is no unconfirmed order for this product"}

        def mark():
            r = command({"type": "BB_MARK", "key": key, "bought": action == "markbought", "status": "PURCHASE SUCCESS - confirmed by you" if action == "markbought" else None}, 15)
            if r.get("ok"):
                _checks.pop(u, None)
                _log(f"{nm}: you marked the unconfirmed order as {'BOUGHT' if action == 'markbought' else 'NOT bought'}.")
            return r
        return work(u, "saving", mark)
    if action in ("approve", "cancel"):
        if action == "cancel":
            _want(u, False)
        return command({"type": "BB_ANSWER", "key": key, "answer": action}, 15)
    if action == "cvv":
        return {"ok": False, "reason": "use the security-code box in the top bar"}
    return {"ok": False, "reason": "unknown action"}


def _card_have():
    try:
        import cardcode
        return cardcode.have() and not cardcode.status()["paused"]
    except Exception:
        return False


def push_card_code():
    """v77: puts your saved card security code (or none) into the buying browser's MEMORY - its checkouts type it in themselves."""
    try:
        import cardcode
        v = cardcode.get() or ""
    except Exception:
        v = ""
    r = command({"type": "BB_SETCODE", "value": v}, 10)
    if not r.get("ok"):
        _log(f"[buyer] the saved card security code could not be given to the buying browser ({r.get('reason')}) - you would be asked at checkout.")
    return r


def _auto_cvv(tid):
    try:
        import cardcode
        v = cardcode.get()
    except Exception:
        v = None
    if not v:
        return
    r = command({"type": "BB_ANSWER", "key": tid, "answer": "cvv", "value": v}, 15)
    _log(f"{STORE_NAMES.get(_store_of_key(tid), 'Best Buy')}: your saved card security code was typed in for {tid}" + ("." if r.get("ok") else f" - not taken: {r.get('reason')}."))
    push_card_code()


def card_code_wrong(store, text):
    """v77: a store said the security code is wrong -> the saved code is not used again until you save it again."""
    try:
        import cardcode
        if cardcode.have() and cardcode.looks_wrong(text) and cardcode.mark_wrong(store, text):
            _log(f"[buyer] {store} turned down the card security code - the saved code is NOT used again until you save it again (Card code (top bar)).")
            threading.Thread(target=push_card_code, daemon=True).start()
            return True
    except Exception:
        pass
    return False


def give_cvv(tid, value):
    """The card security code typed in the top bar, for the ONE Best Buy checkout waiting for it. Never stored, never logged."""
    c = _engine_client()
    if not c:
        return {"ok": False, "reason": "the buying browser is not connected"}
    v = re.sub(r"\D", "", str(value or ""))
    if not 3 <= len(v) <= 4:
        return {"ok": False, "reason": "the security code has 3 or 4 digits"}
    r = command({"type": "BB_ANSWER", "key": str(tid), "answer": "cvv", "value": v}, 15)
    _log(f"{STORE_NAMES.get(_store_of_key(str(tid)), 'Best Buy')}: the card security code was given for {tid} ({'accepted' if r.get('ok') else 'not accepted: ' + str(r.get('reason'))}).")
    return r



# ---------------------------------------------------------------- start / stop / status

def _serve():
    told = False
    while not _server["stop"]:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        try:
            if os.name == "nt":
                s.setsockopt(socket.SOL_SOCKET, getattr(socket, "SO_EXCLUSIVEADDRUSE", socket.SO_REUSEADDR), 1)
            else:
                s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            s.bind((HOST, PORT))
            s.listen(8)
        except OSError as e:
            try:
                s.close()
            except Exception:
                pass
            _server["listening"] = False
            _server["error"] = (f"port {PORT} is used by another program (most likely the older separate 'detector' program). "
                                "Close it; Restalker takes over within 30 s.")
            if not told:
                _log(_server["error"] + f" ({e})")
                told = True
            time.sleep(30)
            continue
        _server.update(listening=True, error=None, since=time.time(), sock=s)
        told = False
        try:
            while not _server["stop"]:
                conn, addr = s.accept()
                threading.Thread(target=_handle, args=(conn, addr), daemon=True, name="buyer-link").start()
        except Exception:
            pass
        finally:
            _server["listening"] = False
            try:
                s.close()
            except Exception:
                pass
        if not _server["stop"]:
            time.sleep(2)


def start(log_fn=None, describe=None, rows=None, notify_fn=None, launch=True, status_fn=None):
    global LOG, DESCRIBE, ROWS, NOTIFY, STATUS
    STATUS = status_fn or STATUS
    LOG = log_fn or LOG
    DESCRIBE = describe or DESCRIBE
    ROWS = rows or ROWS
    NOTIFY = notify_fn or NOTIFY
    load_settings()
    _load_events()
    try:
        _ledger_seed()
    except Exception as e:
        _log(f"purchase list: {str(e)[:100]}")
    for fn, nm in ((_serve, "buyer-server"), (_tick, "buyer-tick"), (_hub, "buyer-hub")):
        threading.Thread(target=fn, daemon=True, name=nm).start()
    if launch and not os.environ.get("RK_NO_BUYER_BROWSER"):
        threading.Thread(target=_watchdog, daemon=True, name="buyer-watchdog").start()
    if launch and not os.environ.get("RK_NO_READER_BROWSER"):
        threading.Thread(target=_reader_watchdog, daemon=True, name="reader-watchdog").start()


def _reader_watchdog():
    """v65: keeps the store reader's own browser running (whether buying is on or off: reading is what the alerts need)."""
    import reader_browser
    reader_browser.LOG[0] = LOG
    time.sleep(2)
    while not _server["stop"]:
        if _server.get("listening"):
            reader_browser.watch_once(_find_exe, PORT, lambda: _reader_client() is not None)
        time.sleep(3)


def stop():
    _server["stop"] = True
    try:
        if _server.get("sock"):
            _server["sock"].close()
    except Exception:
        pass
    with _lock:
        cl = list(_clients.values())
    for c in cl:
        c.close()
    _kill_engine()
    try:
        import reader_browser
        reader_browser.state["stop"] = True
        reader_browser.kill()
    except Exception:
        pass


def _ago(t):
    if not t:
        return "never"
    s = max(0, int(time.time() - t))
    return f"{s} s ago" if s < 120 else (f"{s // 60} min ago" if s < 7200 else f"{s // 3600} h ago")


_rows_cache = {"at": 0.0, "rows": []}


def _amazon_rows(force=False):
    if force or time.time() - _rows_cache["at"] > 10:
        try:
            _rows_cache["rows"] = [t for t in (ROWS() if ROWS else []) if (_is_amazon(t.get("url")) or _is_bestbuy(t.get("url"))) and t.get("active", True)]
        except Exception:
            pass
        _rows_cache["at"] = time.time()
    return _rows_cache["rows"]


def _step_text(r):
    st = {"cart": "adding to cart", "checkout": "on the checkout page", "shipping_approval": "waiting for your shipping approval",
          "submitted": "Place Order pressed - waiting for Amazon's confirmation"}.get(r.get("step") or "")
    if r.get("approval"):
        return "waiting for your shipping approval"
    if r.get("needCvv"):
        return "waiting for your card security code"
    return st or re.sub(r"^CHECKING OUT:\s*", "", r.get("status") or "") or "checking out"


def _plain_status(p, u=None):
    if not p:
        return "not known to the buying browser yet (switching Auto-buy on adds it)"
    s = str(p.get("status") or "")
    if p.get("purchased"):
        return "BOUGHT" + (f" - order {p['orderNumber']}" if p.get("orderNumber") else "") + (f" at {_money(p.get('price'))}" if p.get("price") else "")
    if unclear(p):
        ck = (_checks.get(u or str(p.get("asin") or "")) or {}).get("state")
        sn = STORE_NAMES.get(_store_of_key(u), "Best Buy") if (u or "").startswith("bb:") else "Amazon"
        return "ORDER NOT CONFIRMED - " + ({"checking": f"looking in your {sn} orders...", "not found": f"not found in your {sn} orders - check {sn}"}.get(ck, f"check {sn}"))
    if p.get("approval"):
        return f"WAITING FOR YOU: shipping {_money(p['approval'].get('shipping'))} - approve or cancel"
    if p.get("inProgress"):
        return "CHECKING OUT: " + s
    return s or "waiting"


def snapshot(brief=False):
    c = _engine_client()
    cat = dict(c.catalog) if c else {}
    bbs = dict(c.bb) if c else {}
    out = {"on": enabled(), "listening": _server["listening"], "error": _server["error"], "connected": bool(c),
           "browser": _engine["state"], "browser_detail": _engine["detail"], "visible": bool(_engine.get("signin_open")) or (bool(_engine.get("visible")) and _alive()), "signin_store": _engine.get("signin_store"),
           "signed_in": _account["signedIn"], "account": _account["name"], "challenge": _account["challenge"],
           "account_checked": _ago(_account["at"]) if _account["at"] else "not yet",
           "live": bool(c and c.global_live), "emergency": bool(c and c.emergency),
           "foreign": bool(_foreign["at"] and time.time() - _foreign["at"] < 120),
           "armed_count": sum(1 for p in cat.values() if p.get("armed")) + sum(1 for p in bbs.values() if p.get("armed")),
           "engine_problem": engine_problem(),
           "shop_signed_in": {k: v.get("signedIn") for k, v in (_bb.get("accounts") or {}).items()},
           "bb_signed_in": _bb["account"]["signedIn"], "bb_pickup": bool(_settings.get("bb_pickup")),
           "bb_practice": {k: v for k, v in (_bb["practice"] or {}).items() if k in ("at", "running", "what", "ok", "steps", "reason", "removed")} or None,
           "checkout": bool(c and (c.cart_owner or any(p.get("inProgress") or p.get("submissionPending") for p in bbs.values())))}
    if brief:
        return out
    rows = []
    for t in _amazon_rows():
        bb = _is_bestbuy(t.get("url"))
        a = ("bb:" + t["id"]) if bb else asin_of(t.get("url"))
        if not a:
            continue
        p = bbs.get(t["id"]) if bb else cat.get(a)
        rows.append({"tid": t["id"], "asin": a, "store": (_shop(t.get("url")) or "bestbuy") if bb else "amazon", "product": _name(a, p, t), "cap": _row_cap(t),
                     "needCvv": bool(p and p.get("needCvv")), "hitAt": (p or {}).get("hitAt"),
                     "armed": bool(p and p.get("armed")), "watched": bool(p and p.get("monitor")), "wanted": wanted(a), "purchased": bool(p and p.get("purchased")),
                     "approval": (p or {}).get("approval"), "busy": _busy.get(a), "price": (p or {}).get("price"),
                     "status": _plain_status(p, a), "known": bool(p), "unclear": unclear(p),
                     "check": (_checks.get(a) or {}).get("state"), "step": (p or {}).get("step"), "inprogress": bool(p and (p.get("inProgress") or p.get("submissionPending"))),
                     # v90: only LOOKING at this store's page because the same product restocked at another store (not a checkout yet)
                     "looking": bool(p and p.get("inProgress") and not p.get("submissionPending") and time.time() - _fanned.get(a, 0.0) < 90),
                     # v58: bought = frozen; unknown result = frozen; checking = Restalker is looking in the order list right now
                     "frozen": "bought" if (p and p.get("purchased")) else ("unknown" if (unclear(p) and (_checks.get(a) or {}).get("state") != "checking"
                                                                                           and (a in (_settings.get("unknown") or {}) or (_checks.get(a) or {}).get("state") == "unknown")) else None),
                     "locked": (_settings.get("locked") or {}).get(a),
                     "checking": bool(unclear(p) and (_checks.get(a) or {}).get("state") == "checking"),
                     "order": (p or {}).get("orderNumber"), "problem": _probs.get(a)})
    rows.sort(key=lambda r: (not (r["armed"] or r["wanted"] or r["purchased"] or r["approval"]), r["product"]))
    now = time.time()
    live = [r for r in rows if r["inprogress"] or r["approval"] or r["needCvv"]]
    out["checkout_now"] = [{"product": r["product"], "tid": r["tid"], "store": STORE_NAMES.get(r["store"], "Amazon"), "step": _step_text(r), "price": r["price"],
                            "looking": r["looking"],
                            "since": (_episode.get(r["asin"]) or {}).get("at") or (r.get("hitAt") or (cat.get(r["asin"]) or {}).get("hitAt") or 0) / 1000.0,
                            "approval": r["approval"], "needCvv": r["needCvv"]} for r in live]
    fin = next((e for e in _events if e["kind"] in ("BOUGHT", "OLDBOUGHT") and now - e.get("t", 0) < 1800), None)      # v58: the top bar keeps only purchases
    out["checkout_last"] = fin
    out["human_check"] = ({k: _hc.get(k) for k in ("store", "product", "at", "opened", "why")} if _hc and now - _hc.get("at", 0) < HC_KEEP else None)
    try:
        import multibuy
        out["extra"] = multibuy.status()
        for kind, w in out["extra"].items():           # (v75: another browser's live checkout shows in the banner too)
            if w.get("busy"):
                t = next((o for o in _amazon_rows() if o.get("id") == w["busy"] or (_is_amazon(o.get("url")) and asin_of(o.get("url")) == w["busy"])), None)
                out.setdefault("checkout_now", []).append({"tid": w["busy"], "product": _name("" if t and _is_amazon(t.get("url")) else "bb:" + w["busy"], None, t) if t else w["busy"],
                                                         "store": STORE_NAMES.get(_shop((t or {}).get("url")) or ("amazon" if _is_amazon((t or {}).get("url")) else ""), ""),
                                                         "browser": w["name"],
                                                         "step": w.get("step") or "", "since": (_episode.get("bb:" + w["busy"]) or {}).get("at") or w.get("since"),
                                                         "approval": None, "needCvv": False, "price": None})
    except Exception:
        pass
    evs = list(_events)
    out.update({"rows": rows, "events": evs[:12], "purchases": purchases_list(),
                "problems_log": [e for e in evs if e.get("kind") in PROBLEM_KINDS][:20],
                "activity": [e for e in evs if e.get("kind") not in PURCHASE_KINDS and e.get("kind") not in PROBLEM_KINDS][:20],
                "recent": [{"at": time.strftime("%H:%M:%S", time.localtime(r["made_at"])), "product": r["product"], "asin": r["asin"],
                            "source": r["source"], "price": r.get("price"), "result": r.get("result") or ""} for r in list(_recent)[:8]]})
    return out


def summary_line(s=None):
    s = s or snapshot(brief=True)
    if not s["on"]:
        return "OFF - nothing is bought (the buying browser is closed)."
    if not s["listening"]:
        return "NOT READY - " + (s["error"] or "starting...")
    if s["browser"] in ("cannot start", "installing"):
        return ("PREPARING - " if s["browser"] == "installing" else "PROBLEM - ") + (s["browser_detail"] or s["browser"])
    if s.get("engine_problem"):
        return "PROBLEM - " + s["engine_problem"]
    if not s["connected"]:
        return "starting the buying browser..."
    if s["visible"]:
        return f"a sign-in window is open for {STORE_NAMES.get(_engine.get('signin_store'), 'the store')}: sign in there, then press 'Done' above that store's column."
    if s["emergency"]:
        return "EMERGENCY STOP is on - every product is disarmed. Arm products again to resume."
    amz = (f"Amazon: {s['account']}" if s["signed_in"] else
           ("Amazon: 'verify you are human' page" if s["challenge"] else "Amazon: NOT signed in") if s["signed_in"] is False else "Amazon: checking sign-in")
    ss = s.get("shop_signed_in") or {"bestbuy": s.get("bb_signed_in")}
    bb = " · ".join(f"{STORE_NAMES.get(k, k)}: " + {True: "signed in", False: "NOT signed in"}.get(v, "checking sign-in")
                    for k, v in sorted(ss.items(), key=lambda kv: list(STORE_NAMES).index(kv[0]) if kv[0] in STORE_NAMES else 9))
    n = s["armed_count"]
    if s["checkout"]:
        return f"CHECKING OUT NOW ({amz} · {bb})."
    need = " - use 'Sign in' above that store's column" if (s["signed_in"] is False or False in ss.values()) else ""
    return (f"{amz} · {bb}{need}. " + (f"{n} product{'s' if n != 1 else ''} ARMED - bought automatically at the next restock under the cap."
                                       if n else "Nothing set to auto-buy yet - choose Buy next to a product (or a group)."))


def short_line(s=None):
    """v101 (owner 2026-11-05: "the banner line showing the browsers sign in status is too long still. it kicks buttons down a line"):
    the same facts in a few words for the top bar; the full sentence (summary_line) is its tooltip."""
    s = s or snapshot(brief=True)
    if not s["on"]:
        return "OFF - nothing is bought"
    if not s["listening"]:
        return "starting..."
    if s["browser"] in ("cannot start", "installing"):
        return "preparing the buying browser..." if s["browser"] == "installing" else "PROBLEM - the buying browser cannot start"
    if s.get("engine_problem"):
        return "PROBLEM - see Problems"
    if not s["connected"]:
        return "starting the buying browser..."
    if s["visible"]:
        return f"Sign in to {STORE_NAMES.get(_engine.get('signin_store'), 'the store')} in the window, then press Done"
    if s["emergency"]:
        return "STOPPED - nothing is bought"
    if s["checkout"]:
        return "CHECKING OUT NOW"
    ss = dict(s.get("shop_signed_in") or {"bestbuy": s.get("bb_signed_in")})
    ss["amazon"] = s["signed_in"]
    order = list(STORE_NAMES)
    no = [STORE_NAMES.get(k, k) for k in sorted(ss, key=lambda k: order.index(k) if k in order else 9) if ss[k] is False]
    chk = sum(1 for v in ss.values() if v is None)
    yes = sum(1 for v in ss.values() if v is True)
    if no:
        sign = "NOT signed in: " + ", ".join(no)
    elif chk:
        sign = f"{yes} of {len(ss)} signed in, checking {chk}"
    else:
        sign = f"all {len(ss)} stores signed in" if len(ss) > 1 else "signed in"
    n = s["armed_count"]
    return sign + " · " + (f"{n} set to Buy" if n else "nothing set to Buy yet")


_probe = {"rec": None, "new": False}


def _probe_text(pr):
    if not pr:
        return "  (none yet - it is recorded the next time Amazon's checkout page opens)"
    return "\n".join([
        f"  {datetime.fromtimestamp(pr['at'] / 1000.0).strftime('%m-%d %H:%M:%S')}  product {pr.get('productId')} ({pr.get('asin')}), step '{pr.get('step')}', page {pr.get('page')}",
        f"  the product's code (ASIN) found on the page {pr.get('asinOnPage')} times; quantity boxes: {pr.get('quantityBoxes')}",
        f"  product words FOUND on the checkout page: {pr.get('wordsFound')}",
        f"  product words MISSING from the checkout page: {pr.get('wordsMissing')}",
        f"  forbidden words seen there: {pr.get('forbiddenSeen') or 'none'}",
        f"  product lines on the page: {pr.get('productLines')}",
        f"  page headings (v85): {pr.get('headings')}",
        f"  page buttons (v85): {pr.get('buttons')}",
        f"  page choices (v85): {pr.get('choices')}"])


_engine_events = {"at": 0.0, "lines": [], "error": None, "busy": False}
_NOISY = {"detector_catalog_sync_sent", "detector_catalog_sync_ack", "check_governor_wait", "resource_sample", "check_start", "check_page_ready"}


def refresh_engine_events():
    """The engine's own records, fetched in the background (never while the diagnostics download waits). Repeated lines are counted, not listed."""
    if _engine_events["busy"]:
        return
    _engine_events["busy"] = True
    try:
        r = command({"type": "EXPORT_DIAGNOSTICS"}, 60)
        data = r.get("data") if r.get("ok") else None
        if not data:
            _engine_events.update(error=r.get("reason"), at=time.time())
            return
        try:
            with open("engine_diagnostics.json", "w", encoding="utf-8") as f:
                json.dump(data, f)
        except Exception:
            pass
        evs = [e for e in (data.get("diagnosticEvents") or []) if e.get("type") not in _NOISY]
        out, last, rep_n = [], None, 0
        for e in evs[-1500:]:
            if e.get("type") == "restalker_command" and e.get("ok"):
                continue
            # v68: a checkout's steps are each their own line (diagnostics 62 merged "opening the product page", "added to cart", "cart read"
            # into one "repeated 5 more times" line, which hid what happened)
            key = (e.get("type"), e.get("command"), e.get("reason"), e.get("productId"), e.get("key"), e.get("step"))
            if key == last:
                rep_n += 1
                continue
            if rep_n:
                out.append(f"      (the line above repeated {rep_n} more times)")
            rep_n, last = 0, key
            ts = datetime.fromtimestamp((e.get("ts") or 0) / 1000.0).strftime("%m-%d %H:%M:%S") if e.get("ts") else "?"
            rest = {k: v for k, v in e.items() if k not in ("ts", "type")}
            if str(e.get("type") or "").startswith("bb_"):
                # v68: a checkout record: its reason and steps first, the page snapshot after, and up to 3000 characters (was 500 -
                # the reason was cut off)
                first = {k: rest.pop(k) for k in ("key", "kind", "reason", "step", "steps", "how", "items", "target") if k in rest}
                out.append(f"  {ts} {e.get('type')} {json.dumps({**first, **rest})[:3000]}")
            else:
                out.append(f"  {ts} {e.get('type')} {json.dumps(rest)[:500]}")
        if rep_n:
            out.append(f"      (the line above repeated {rep_n} more times)")
        _engine_events.update(lines=out[-300:], at=time.time(), error=None)
    except Exception as e:
        _engine_events.update(error=str(e), at=time.time())
    finally:
        _engine_events["busy"] = False


def _tabs_line():
    """v80: what the buying browser has open (its windows and tabs by site)."""
    try:
        r = command({"type": "BB_TABS"}, 5)
        if not r.get("ok"):
            return f"Buying browser tabs: not read ({r.get('reason')})"
        by = collections.Counter((t.get("site") or "?") + (t.get("path") or "") for t in r.get("tabs") or [])
        j = r.get("janitor") or {}
        return (f"Buying browser tabs: {len(r.get('tabs') or [])} tabs in {r.get('windows')} windows - "
                + ", ".join(f"{k} x{v}" for k, v in by.most_common(25))
                + (f"\nTab janitor (v90: closes tabs idle 15 min while nothing is being bought): {j.get('closed', 0)} closed so far" if j else ""))
    except Exception as e:
        return f"Buying browser tabs: not read ({e})"


def _buyer_mem_line():
    m = _buyer_mem
    return (f"Buying browser memory restarts (v80: restarted when it alone holds more than {BUYER_MEM_RESTART_GB:.0f} GB for "
            f"{BUYER_MEM_MINUTES} minutes while nothing is being bought; at most once every {BUYER_MEM_EVERY_H} hours): {m['n']}"
            + (f", last {_ago(m['last'])} ({m['why']})" if m["last"] else "")
            + f"\nOther stores NOT opened after a restock elsewhere, because their own reading of a few seconds before said sold out (v80): "
            + (", ".join(f"{k[3:]} x{v}" for k, v in sorted(_fanout_skipped.items(), key=lambda kv: -kv[1])[:10]) or "none yet"))


def diag_text():
    s = snapshot()
    L = [f"Amazon auto-buy ({VERSION}): switch {'ON' if s['on'] else 'OFF'}; link {'listening on 127.0.0.1:%d' % PORT if s['listening'] else 'NOT listening: ' + str(s['error'])}",
         f"Buying browser: {s['browser']} {s['browser_detail']}; exe {_engine.get('exe')}; launches {_engine['launches']}; visible {s['visible']}; engine connected {s['connected']}",
         f"Amazon sign-in: {s['signed_in']} ({s['account'] or '-'}), checked {s['account_checked']}{'; human-check page' if s['challenge'] else ''}{'; error ' + str(_account['error']) if _account['error'] else ''}",
         f"Live purchase {s['live']}; emergency stop {s['emergency']}; checkout running {s['checkout']}; armed {s['armed_count']}; armed by you: {', '.join(_settings.get('armed') or []) or 'none'}",
         f"Separate MTG Amazon Buyer extension refused: {_foreign['count']} times" + (f", last {_ago(_foreign['at'])}" if _foreign["at"] else "")
         + (" - why: " + ", ".join(f"{k} x{v}" for k, v in _foreign["why"].items()) if _foreign["why"] else ""),
         f"Buying engine link (v90): connections {_link['attempts']}" + (f" (last {_ago(_link['last_attempt'])})" if _link["last_attempt"] else "")
         + f"; hellos {_link['hellos']}; messages kept until its hello {_link['early']}; wrong key {_link['bad_key']}"
         + (f"; engine start-up work took {float(_link['init_ms']) / 1000:.1f} s" if isinstance(_link.get("init_ms"), (int, float)) else "")
         + (f"; engine START-UP ERROR {_link['init_error']}" if _link.get("init_error") else ""),
         _logins_line(), _co_line(), "Summary: " + summary_line(), _tabs_line(), _buyer_mem_line(), "Products:"]
    for r in s["rows"]:
        L.append(f"  {r['product']} ({r['asin']}) cap {_money(r['cap'])} armed {r['armed']}" + ("" if r.get("watched", True) or not r['armed'] else " but NOT WATCHED")
                 + f" (wanted {r['wanted']}) - {r['status']}")
    L.append("Purchase events:")
    L += [f"  {e['at']}  {e['kind']}  {e['text']}" for e in s["events"]] or ["  (none yet)"]
    L.append("Order checks after unclear results: " + (json.dumps(_checks) if _checks else "none"))
    a = _bb["account"]
    L.append(f"Best Buy: signed in {a['signedIn']} (checked {_ago(a['at']) if a['at'] else 'not yet'}{'; ' + str(a['reason']) if a.get('reason') else ''}); "
             f"store pickup allowed: {bool(_settings.get('bb_pickup'))}; armed by you: {', '.join(x[3:] for x in (_settings.get('armed') or []) if x.startswith('bb:')) or 'none'}")
    pr = _bb["practice"]
    if pr:
        L.append(f"Best Buy practice run ({datetime.fromtimestamp(pr['at']).strftime('%m-%d %H:%M:%S')}): " +
                 ("RUNNING" if pr.get("running") else ("PASSED" if pr.get("ok") else f"STOPPED - {pr.get('reason')}")) + f" - item: {pr.get('what')}")
        for st in pr.get("raw_steps") or []:
            L.append("    " + json.dumps(st)[:300])
        if pr.get("page"):
            L.append("    page seen where it stopped (no personal data): " + json.dumps(pr["page"])[:2500])
    else:
        L.append("Best Buy practice run: not run yet")
    for st_, a2 in sorted((_bb.get("accounts") or {}).items()):
        if st_ != "bestbuy":
            L.append(f"{STORE_NAMES.get(st_, st_)}: signed in {a2.get('signedIn')} (checked {_ago(a2['at']) if a2.get('at') else 'not yet'}{'; ' + str(a2.get('reason')) if a2.get('reason') else ''})")
    for st_, pr2 in sorted((_bb.get("practices") or {}).items()):
        if st_ == "bestbuy":
            continue
        L.append(f"{STORE_NAMES.get(st_, st_)} practice run ({datetime.fromtimestamp(pr2['at']).strftime('%m-%d %H:%M:%S')}): " +
                 ("RUNNING" if pr2.get("running") else ("PASSED" if pr2.get("ok") else f"NOT PASSED - {pr2.get('reason')}")) + f" - item: {pr2.get('what')}")
        for st in pr2.get("raw_steps") or []:
            L.append("    " + json.dumps(st)[:300])
        if pr2.get("page"):
            L.append("    page seen where it stopped (no personal data): " + json.dumps(pr2["page"])[:2500])
    for st_, pl in sorted((_settings.get("practice_last") or {}).items()):
        L.append(f"last practice run at {STORE_NAMES.get(st_, st_)} (kept): {datetime.fromtimestamp(pl.get('at') or 0).strftime('%m-%d %H:%M')} - "
                 + ("PASSED" if pl.get("ok") else f"NOT PASSED - {pl.get('reason')}") + f" - steps: {' -> '.join(pl.get('steps') or [])[:400]}")
    for st_, a2 in sorted((_bb.get("accounts") or {}).items()):
        L.append(f"sign-in check {STORE_NAMES.get(st_, st_)}: {a2.get('signedIn')} ({a2.get('how') or '-'}; {a2.get('reason') or 'ok'})")
    ec = _engine_events
    L.append(f"Buying engine's own records (checkout related; collected {_ago(ec['at']) if ec['at'] else 'not yet'} in the background; full copy in engine_diagnostics.json):")
    if not ec["at"] or time.time() - ec["at"] > 120:
        threading.Thread(target=refresh_engine_events, daemon=True, name="engine-events").start()
    for line in ec["lines"] or ["  (not collected yet" + (f": {ec['error']}" if ec.get("error") else "") + ")"]:
        L.append(line)
    try:
        import reader_browser
        rc = _reader_client()
        L.append(f"Store reader's own browser (v65; reads for the watchers - the buying browser only buys): {reader_browser.line()}; "
                 f"connected {bool(rc)}" + (f" ({rc.engine_name}; code {rc.code})" if rc else ""))
    except Exception as e:
        L.append(f"Store reader's own browser: ({e})")
    L.append("Store pages read through it: " + reader_text())
    L.append("")
    L.append("Amazon checkout page - what it showed about the product (read only; no address or payment details):")
    L.append(_probe_text(_probe.get("rec")))
    L.append("")
    L.append("Latest restock signals:")
    L += [f"  {r['at']}  {r['product']} ({r['asin']}) from {r['source']} {('$%.2f' % r['price']) if r['price'] else ''} -> {r['result']}" for r in s["recent"]] or ["  (none yet)"]
    return "\n".join(L) + "\n"
