#!/usr/bin/env python3
"""
Tracker feed poller.

For each tracker in trackers.yaml, this loads its public feed page (a
page anyone can view without an account, listing recent restocks) and
watches for new mentions of the products in targets.yaml. When a new
mention appears, it logs the timestamp — this is the tracker's half of
the latency measurement, captured the same way the ground truth poller
captures the retailer's half: by polling a public page, not by
subscribing to a private notification.

Why "mentions" instead of exact structured parsing: every tracker's page
has different HTML, and hand-writing a scraper per tracker doesn't scale
to dozens of them. Instead this does a simpler, more robust thing: strip
the page to plain text, find every spot where a watched product's
match_name appears, and treat any new surrounding text snippet (one we
haven't seen before) as a new restock mention. Spot-check alerts.csv
snippets occasionally to confirm they look like real restock entries.

Self-healing: same automatic browser-mode upgrade as ground_truth_poller
— a tracker feed that starts failing 3x in a row live tries a real
browser immediately, and switches over permanently if that fixes it.

Usually run automatically by app.py — see README. Standalone use:
    python tracker_feed_poller.py --trackers trackers.yaml --targets targets.yaml --out alerts.csv
"""
VERSION = "v102"   # checked by app.py so a half-copied update is caught immediately

import argparse
import csv
import os
import re
import time
from datetime import datetime, timezone

import yaml
import hotness
from bs4 import BeautifulSoup

from http_utils import fetch, append_csv_row, flush_pending_csv
from browser_fetch import BrowserFetcher
import recon
import samples

SNIPPET_WINDOW = 80  # characters of context captured around each match
MAX_SEEN_PER_PAIR = 200  # cap memory growth for long-running sessions

# Matches relative-time text like "6m ago", "11 minutes ago", "2h ago",
# "3 days ago" — this text changes on its own as time passes even when
# the underlying listing hasn't changed, which would otherwise make the
# same entry look "new" every time its displayed age ticks over.
RELATIVE_TIME_RE = re.compile(
    r"\b(?:\d+\s*(?:s|sec|secs|second|seconds|m|min|mins|minute|minutes|"
    r"h|hr|hrs|hour|hours|d|day|days)\s*ago|just now)\b", re.IGNORECASE
)


def _dedupe_key(snippet: str) -> str:
    """Strip ticking relative-time text before using a snippet as the
    'have we seen this before' key, so a listing doesn't count as a new
    mention just because its displayed age changed. The raw snippet
    (with the real time text) is still what gets saved to alerts.csv."""
    return RELATIVE_TIME_RE.sub("<TIME>", snippet)


# TYPA also has one page per brand. The Magic page lists Amazon cards (the main /back-in-stock page does not), so it is read
# as an EXTRA source for the same tracker: its cards are saved as "typa" like any other TYPA card.
EXTRA_TYPA_PAGE = "https://www.typa.app/brands/magic-the-gathering"
EXTRA_GAP_SEC = 8.0      # the extra page is read at most this often
CARD_WINDOW = 350   # characters after the product name that still belong to the same feed entry


def find_snippets(page_text: str, match_name: str) -> list:
    """One text window per occurrence of match_name: a little before it,
    and up to CARD_WINDOW after it - but never running into the NEXT
    occurrence, so each window is one feed entry (including its retailer
    name, price and time)."""
    lower = page_text.lower()
    needle = match_name.lower()
    spots, start = [], 0
    while True:
        idx = lower.find(needle, start)
        if idx == -1:
            break
        spots.append(idx)
        start = idx + len(needle)
    out = []
    for k, i in enumerate(spots):
        nxt = spots[k + 1] if k + 1 < len(spots) else len(page_text)
        s0 = max(0, i - 40)
        e0 = min(nxt, i + len(needle) + CARD_WINDOW)
        out.append(page_text[s0:e0].strip())
    return out


RETAILER_WORDS = {"amazon": "amazon", "target": "target", "walmart": "walmart",
                  "bestbuy": "best buy", "gamestop": "gamestop"}


KNOWN_RETAILERS = ("amazon", "target", "walmart", "best buy", "bestbuy", "gamestop")


def clearly_other_retailer(snippet: str, want: str) -> bool:
    """True only when the entry names a DIFFERENT known retailer and not
    ours. If it names none of the known ones, we keep it (the analysis
    step does the strict check later), so nothing is lost on a layout
    we haven't seen."""
    if not want:
        return False
    low = snippet.lower()
    mine = {want, want.replace(" ", "")}
    if any(m in low for m in mine):
        return False
    return any(r in low for r in KNOWN_RETAILERS if r not in mine)


def retailer_word(url: str) -> str:
    """Retailer name expected in a tracker snippet, from the product URL
    (so a TYPA 'Amazon' alert is never credited to the Target product)."""
    host = (url or "").lower().split("/")[2] if "//" in (url or "") else ""
    for key, word in RETAILER_WORDS.items():
        if key in host:
            return word
    return ""


from urllib.parse import unquote

AGE_RE = re.compile(r"(\d+)\s*(s|sec|secs|second|seconds|m|min|mins|minute|minutes|"
                    r"h|hr|hrs|hour|hours|d|day|days)\s*ago", re.IGNORECASE)
RETAILER_DOMAINS = {"amazon": ("amazon.com",), "target": ("target.com",), "walmart": ("walmart.com",),
                    "bestbuy": ("bestbuy.com",), "gamestop": ("gamestop.com",)}
STALE_AT_FIRST_SIGHT = 180   # an entry already this old when first seen is history, not a live event
AGE_SLACK = 360              # the TYPA page itself is only refreshed about every 5 minutes (measured), and ages are rounded down


def parse_age_sec(text):
    """'1m ago' -> 60, '2h ago' -> 7200, 'just now' -> 0, unknown -> None."""
    m = AGE_RE.search(text or "")
    if m:
        n, u = int(m.group(1)), m.group(2).lower()
        mult = 1 if u.startswith("s") else 60 if u.startswith("m") else 3600 if u.startswith("h") else 86400
        return n * mult
    if re.search(r"\b(just now|now)\b", text or "", re.IGNORECASE):
        return 0
    return None


def age_span_sec(text):
    """How coarse the card's age is: '45s ago' -> 1, '5m ago' -> 60, '2h ago' -> 3600. A card that says '1h ago' is
    anywhere from 60 to 119 minutes old, so its age cannot tell us when it was posted to within seconds."""
    m = AGE_RE.search(text or "")
    if not m:
        return 1
    u = m.group(2).lower()
    return 1 if u.startswith("s") else 60 if u.startswith("m") else 3600 if u.startswith("h") else 86400


import products
import matrix


def kind_is_box(target):
    return products.kind_of(target) == "box"


def _norm(text):
    """Make titles comparable across stores: Target and Walmart say
    'Booster Display', others say 'Booster Box'; trademark signs and
    punctuation differ too."""
    t = (text or "").lower()
    t = re.sub(r"[\u2122\u00ae\u00a9|:\-\u2013\u2014,()]", " ", t)
    t = re.sub(r"\s+", " ", t).strip()
    return t.replace("booster display", "booster box")


def feed_cards(soup, match_name):
    """TYPA-style feeds show each restock as one clickable card: the
    product, the store, the price and the age, with a link to the store's
    own page. One card = one <a>, so the store can be read exactly (from
    the card text and from the link) with no guessing about neighbours."""
    needle = _norm(match_name)
    cards = []
    for a in soup.find_all("a", href=True):
        txt = " ".join(a.get_text(" ").split())
        if needle in _norm(txt):
            cards.append({"text": txt, "href": unquote(unquote(a["href"]))})
    return cards


def all_anchor_cards(soup):
    """Every clickable card on the feed page, read ONCE per poll (text, link and
    the comparable form of the text), so matching 13+ products afterwards is just
    cheap substring tests instead of re-reading the whole page for each."""
    out = []
    for a in soup.find_all("a", href=True):
        txt = " ".join(a.get_text(" ").split())
        if txt:
            out.append({"text": txt, "href": unquote(unquote(a["href"])), "norm": _norm(txt)})
    return out


def card_is_for_store(card, target_url):
    """Does this card name the same STORE as the product we watch?"""
    host = (target_url or "").lower().split("/")[2] if "//" in (target_url or "") else ""
    for key, domains in RETAILER_DOMAINS.items():
        if key in host:
            low_txt, low_href = card["text"].lower(), card["href"].lower()
            word = {"bestbuy": "best buy"}.get(key, key)
            return (any(d in low_href for d in domains) or word in low_txt
                    or key in low_txt.replace(" ", ""))
    return True   # store we have no rule for: keep it


# ---- "status page" trackers: a public table of products with In Stock / Out of Stock (NowInStock.net and the like) -----------
# Unlike TYPA's cards there is no "how long ago" on each entry, so an event is the moment this program first SEES a product's row
# change from Out of Stock to In Stock. That is an upper bound for the tracker's own delay (the page itself refreshes about once a minute).
BUILTIN_FEEDS = [
    {"id": "nowinstock", "name": "NowInStock.net", "kind": "status_table", "feed_url": "https://www.nowinstock.net/toys/magicthegathering/",
     "claimed_latency_sec": 60, "claimed_note": "public table, refreshed about every minute (its own statement); mostly Amazon, some Walmart / Target / Best Buy",
     "interval_sec": 15, "active": True, "fetch_mode": "http"},
]

# ---- v39: per-product public pages (HotStock, TrackaLacker) and a public feed (Restockd): plain web requests in their own thread (never slow
# TYPA's 2-second polling, no browser, no log-in, no alert pop-up). A "flip" from Out of Stock to In Stock is a mention, exactly like the
# NowInStock status table (an upper bound for the tracker's own delay). The pages below are the three Amazon collector boxes.
_PAGE_BOXES = [
    ("Reality Fracture Collector Booster Box", "hotstock", "https://www.hotstock.io/us/p/reality-fracture-collector-booster-box-or-12-packs"),
    ("The Hobbit Collector Booster Box", "hotstock", "https://www.hotstock.io/us/p/or-the-hobbit-collector-booster-box-or-12-packs-1-foil-box-topper-card-or-collectible-trading-card-game"),
    ("Star Trek Collector Booster Box", "hotstock", "https://www.hotstock.io/us/p/magic-the-gathering-or-star-trek-collector-booster-box"),
    ("Reality Fracture Collector Booster Box", "trackalacker", "https://www.trackalacker.com/products/showcase/mtg-reality-fracture-collector-booster-box/listings/294499/mtg-reality-fracture-collector-booster-box"),
    ("The Hobbit Collector Booster Box", "trackalacker", "https://www.trackalacker.com/products/showcase/magic-the-gathering-the-hobbit-collector-booster-box/listings/294131/magic-the-gathering-the-hobbit-collector-booster-box"),
    ("Star Trek Collector Booster Box", "trackalacker", "https://www.trackalacker.com/products/showcase/magic-the-gathering-star-trek-collector-booster-box/listings/305862/magic-the-gathering-star-trek-collector-booster-box"),
    ("Final Fantasy Collector Booster Box", "trackalacker", "https://www.trackalacker.com/products/showcase/magic-the-gathering-final-fantasy-collector-booster-box/listings/192812/magic-the-gathering-final-fantasy-collector-booster-box"),
]
BUILTIN_FEEDS += [
    {"id": "hotstock_page", "name": "HotStock (public page)", "kind": "status_page", "parser": "hotstock", "feed_url": "https://www.hotstock.io/us",
     "pages": [{"name": n, "url": u} for n, k, u in _PAGE_BOXES if k == "hotstock"],
     "claimed_latency_sec": None, "claimed_note": "the product's public page (Amazon row), read directly every ~10 s: no log-in, no alerts, no pop-up",
     "interval_sec": 10, "active": True, "fetch_mode": "http"},
    {"id": "trackalacker_page", "name": "TrackaLacker (public page)", "kind": "status_page", "parser": "trackalacker", "feed_url": "https://www.trackalacker.com/",
     "pages": [{"name": n, "url": u} for n, k, u in _PAGE_BOXES if k == "trackalacker"],
     "claimed_latency_sec": None, "claimed_note": "the product's public listing (Amazon), read directly every ~10 s: no log-in, no alerts, no pop-up",
     "interval_sec": 10, "active": True, "fetch_mode": "http"},
    {"id": "restockd", "name": "Restockd (public feed)", "kind": "event_page", "parser": "restockd", "feed_url": "https://restockd.app/products",
     "claimed_latency_sec": None, "claimed_note": "v63: switched off - Restockd does not list Magic: The Gathering (only Pokemon, One Piece, Riftbound, Topps, NeeDoh)",
     "interval_sec": 20, "active": False, "fetch_mode": "http"},
]
PAGE_KINDS = ("status_page", "event_page")
_STATUS_ANY = re.compile(r"\b(out of stock|sold out|no longer in stock|not (?:yet |currently )?in stock|currently unavailable|unavailable|no stock|in stock|pre-?order|above msrp|price surge)\b", re.I)
_NEG_STATUS = re.compile(r"^(out of stock|sold out|no longer in stock|not (?:yet |currently )?in stock|currently unavailable|unavailable|no stock)$", re.I)
_RETAILER_WORDS_ALL = ("amazon", "best buy", "bestbuy", "walmart", "target", "gamestop", "ebay", "costco", "sam's club")


def _status_of(text):
    """'IN' / 'OUT' / None for a piece of text; None when it names both (cannot tell) or neither."""
    found = {("OUT" if _NEG_STATUS.match(m.group(1)) else "IN") for m in _STATUS_ANY.finditer(text or "")}
    return found.pop() if len(found) == 1 else None


_HS_NEG = r"(?:out of stock|no longer in stock|not (?:yet |currently )?in stock|never in stock|not (?:yet |currently )?available|sold out|unavailable|no stock|no longer available|preorders? (?:closed|ended|unavailable))"
_HS_POS = r"(?:in stock|pre-?order)"
_HS_STATUS = re.compile(r"\b(will be in stock|coming soon|" + _HS_NEG + "|" + _HS_POS + r")\b", re.I)
_HS_OTHER = r"\b(?:best buy|bestbuy|walmart|target|gamestop|ebay)\b"
_HS_PRODUCT_WORDS = re.compile(r"\b(?:collector booster|play booster|set booster|booster (?:box|pack|display)|bundle|commander deck)\b", re.I)


def parse_hotstock_page(html, is_ours=None):
    """HotStock's product page lists a row per retailer: 'Amazon <product> <In Stock / Out of Stock> <price>'. Same idea as the other program's
    reader: work on the page's words, look at each 'Amazon' and read only up to the next 'Amazon' / other retailer (so Best Buy or eBay can never
    bleed into Amazon). A row that names a DIFFERENT product (when is_ours(text) says it is not ours) is skipped. Returns
    {'status','label','price','row'} when every usable Amazon row agrees, else None (unreadable, conflicting or 'coming soon')."""
    if not html or len(html) > 2_000_000:
        return None
    try:
        soup = BeautifulSoup(html, "html.parser")
        for tag in soup(["script", "style", "svg", "noscript"]):
            tag.decompose()
        text = " ".join(soup.get_text(" ").split())
    except Exception:
        return None
    pos = [m.start() for m in re.finditer(r"\bamazon\b", text, re.I)]
    states = []
    for i, p0 in enumerate(pos):
        end = min(pos[i + 1] if i + 1 < len(pos) else len(text), p0 + 6 + 700)
        row = text[p0:end]
        body = row[6:]
        if re.match(r"\s*(?:associate|affiliate|partner|prime|logo)", body, re.I):
            continue                                            # 'As an Amazon Associate ...' is not a row
        nxt = re.search(_HS_OTHER, body, re.I)
        bounded = body[:nxt.start()] if nxt else body
        bounded = bounded[:450]
        ms = list(_HS_STATUS.finditer(bounded))
        other_in = re.search(r"\b(?:in stock|pre-?order)\s+(?:at|on)\s+(?:best buy|walmart|target|gamestop|ebay)\b", body[:520], re.I)
        if other_in and (not ms or other_in.start() <= ms[0].start()):      # 'In stock at Best Buy' is not Amazon evidence
            states.append(("AMBIG", row))
            continue
        if not ms:
            continue
        if is_ours is not None and not is_ours(bounded):
            continue                                            # another product's Amazon row (or a sentence that only mentions Amazon)
        before = bounded[:ms[0].start()]
        if _HS_PRODUCT_WORDS.search(before) and is_ours is None and len(ms) > 1:
            states.append(("AMBIG", row))
            continue
        words = [m.group(1).lower() for m in ms]
        neg = any(re.fullmatch(_HS_NEG, w) for w in words)
        pros = any(w in ("will be in stock", "coming soon") for w in words)
        pos_ = any(re.fullmatch(_HS_POS, w) for w in words)
        if pros or (neg and pos_):
            states.append(("AMBIG", row))
            continue
        states.append(("OUT" if neg else "IN", bounded[:300]))
    sts = {x for x, _ in states}
    if len(sts) != 1 or "AMBIG" in sts:
        return None
    st = sts.pop()
    row = next(r for x, r in states if x == st)
    m = re.search(r"\$\s*([0-9][0-9,]*(?:\.[0-9]{1,2})?)", row)
    return {"status": st, "label": ("in stock" if st == "IN" else "out of stock"), "price": float(m.group(1).replace(",", "")) if m else None, "row": ("Amazon " + row.strip())[:240]}


def parse_trackalacker_page(html):
    """TrackaLacker's listing page: 'Stock Tracker for <product> at Amazon' followed by the status word (Out of Stock / In Stock (MSRP) /
    Above MSRP / Price Surge / Pre-order) and a price. Returns {'status','label','price','row'} or None."""
    if not html:
        return None
    try:
        soup = BeautifulSoup(html, "html.parser")
        for tag in soup(["script", "style", "svg"]):
            tag.decompose()
        text = " ".join(soup.get_text(" ").split())
    except Exception:
        return None
    if re.search(r"no longer tracking", text[:700], re.I):
        return None
    h = re.search(r"Stock Tracker for", text[:14000], re.I)
    rm = re.search(r"\bat (Amazon|Target|Walmart|Best Buy|GameStop)\b", text[:14000], re.I)    # v63: every retailer's listing, not only Amazon's
    if not h or not rm:
        return None
    retailer = rm.group(1).lower()
    local = text[h.end():h.end() + 650]
    end = re.search(r"\b(?:View at (?:Amazon|Target|Walmart|Best Buy|GameStop)|or check out|As an Amazon Associate|Get notified|We're tracking stock)\b", local, re.I)
    if end:
        local = local[:end.start()]
    m = re.search(r"\b(Out of Stock|Above MSRP|In Stock(?: \(MSRP\))?|Price Surge|Pre-?order(?: \(MSRP\))?)(?=\s|\$|$)", local, re.I)
    if not m:
        return None
    label = m.group(1)
    st = "OUT" if re.match(r"out of stock", label, re.I) else "IN"
    pm = re.search(r"\$\s*([0-9][0-9,]*(?:\.[0-9]{1,2})?)", local[m.end():m.end() + 100])
    return {"status": st, "label": label, "price": float(pm.group(1).replace(",", "")) if pm else None, "row": (retailer.title() + ": " + local[:140]).strip(),
            "retailer": retailer}


_AGE_UNIT = {"s": 1, "m": 60, "h": 3600}


def parse_restockd_events(html, name_norm_fn, max_age=180):
    """Restockd lists 'product ... restocked N minutes ago' (or 'now'). Returns [{'text','norm','age'}] for every such line that is not
    clearly another retailer's; the caller decides which of our products it is."""
    if not html:
        return []
    try:
        soup = BeautifulSoup(html, "html.parser")
        for tag in soup(["script", "style", "svg"]):
            tag.decompose()
    except Exception:
        return []
    out = []
    blocks = soup.find_all(["tr", "li", "article", "a"]) or []
    texts = []
    for b in blocks:
        t = " ".join(b.get_text(" ").split())
        if 8 < len(t) < 400:
            texts.append(t)
    seen_t = set()
    for t in texts:
        if t in seen_t:                                 # a list item and the link inside it hold the same words
            continue
        seen_t.add(t)
        m = re.search(r"\b(just now|(?:restocked|in stock|available|listed|added)\s+now|(\d+)\s*(s|sec|secs|seconds?|m|mins?|minutes?|h|hrs?|hours?)\s+ago)\b", t, re.I)
        if not m:
            continue
        age = 0 if m.group(2) is None else int(m.group(2)) * _AGE_UNIT[m.group(3)[0].lower()]
        if age > max_age:
            continue
        low = t.lower()
        other = [w for w in ("best buy", "walmart", "target", "gamestop", "ebay") if re.search(r"\b" + w + r"\b", low)]
        if other and "amazon" not in low:
            continue
        out.append({"text": t[:200], "norm": name_norm_fn(t), "age": age})
    return out


def pages_for_tracker(t):
    return [p for p in (t.get("pages") or []) if p.get("url")]


def _page_cycle_one(t, pg, targets, st_state, noted, log_fn, out_path, report, fetch_page, alt_fetch=None, via=None, alt_tried=None):
    """One read of one public page. Returns ('ok'|'unread'|'blocked'|'error', detail).
    If the plain web request cannot be used for this page (connection error, 403, or a page the reader cannot understand) and a browser
    fallback exists, the page is read once with the program's own browser; if that works the page keeps being read that way."""
    tid = t["id"]
    parser = t.get("parser")
    key = (tid, pg["url"])
    via = via if via is not None else {}
    alt_tried = alt_tried if alt_tried is not None else {}
    want = [x for x in list(targets) if retailer_word(x.get("url", "")) == (pg.get("retailer") or "amazon")
            and (pg.get("retailer") or kind_is_box(x)) and products.title_matches(_norm(pg["name"]), x)]

    def read(fetch):
        code, html, err = fetch(pg["url"])
        if err:
            return code, html, err, None
        if code in (401, 403, 429) or (code and code >= 400):
            return code, html, None, None
        res = (parse_hotstock_page(html, is_ours=lambda seg: any(products.title_matches(_norm(seg), x) for x in want))
               if parser == "hotstock" else parse_trackalacker_page(html))
        return code, html, None, res

    code, html, err, res = read(alt_fetch if (via.get(key) and alt_fetch) else fetch_page)
    _fails = alt_tried.get(("fails", key), 0)
    if (err or res is None) and code != 429 and alt_fetch and not via.get(key) and time.time() - alt_tried.get(key, 0) > min(1800.0, 120.0 * (2 ** min(_fails, 4))):
        alt_tried[key] = time.time()
        c2, h2, e2, r2 = read(alt_fetch)
        if not r2:
            alt_tried[("fails", key)] = _fails + 1          # v49: a page its browser cannot read either is tried less and less often (2, 4, 8, 16, 30 min)
        if r2:
            via[key] = True
            why0 = err if err else (f"HTTP {code}" if code != 200 else "page not understood")
            log_fn(f"[info] {tid} page {pg['name']}: the plain web request could not be used ({why0}) - reading it with the program's browser instead.")
            code, html, err, res = c2, h2, e2, r2
    if err:
        return "error", err
    if code in (401, 403, 429):
        return "blocked", f"HTTP {code}"
    if code and code >= 400:
        return "error", f"HTTP {code}"
    if not noted.get(key):
        noted[key] = True
        log_fn(f"[diagnostic] {tid} page {pg['name']}: " + (f"read OK - Amazon says {res['label']}" + (f" ${res['price']:.2f}" if res.get("price") else "") + f" ({res['row'][:90]!r})" if res else
               f"could not be understood (HTTP {code}, {len(html or '')} characters). A copy was saved for the diagnostics."))
        if not res:
            samples.save(f"feed_{tid}", "unparsed", html or "", pg["url"])
    if not res:
        return "unread", ""
    for target in want:
        if matrix.is_off(target):
            continue
        sk = (tid, target["id"])
        prev = st_state.get(sk)
        st_state[sk] = res["status"]
        if prev == "OUT" and res["status"] == "IN":
            text = res["row"]
            if not products.price_ok(text if res.get("price") else "", target):
                log_fn(f"[info] {tid} lists {target['id']} above your price limit (${target.get('max_price')}) - not counted: " + text[:120])
                continue
            ts = datetime.now(timezone.utc).isoformat()
            try:
                hotness.mark(target["id"])
            except Exception:
                pass
            log_fn(f"[{ts}] NEW MENTION: {tid} / {target['id']} (public page flipped to In Stock)" + (f" price ${res['price']:.2f}" if res.get("price") else ""))
            if not append_csv_row(out_path, [ts, tid, target["id"], text + " [status page: first seen In Stock just now] || " + pg["url"][:160]]):
                log_fn(f"[error] {out_path} could not be written to (is it open in Excel?). This mention is saved in {out_path}.pending.")
            if report:
                report("tracker", tid, last_mention_at=time.time(), last_mention_target=target["id"])
    return "ok", ""


def _restockd_cycle(t, targets, ev_seen, noted, log_fn, out_path, report, fetch_page):
    tid = t["id"]
    code, html, err = fetch_page(t["feed_url"])
    if err:
        return "error", err
    if code in (401, 403, 429):
        return "blocked", f"HTTP {code}"
    events = parse_restockd_events(html, _norm)
    if not noted.get(tid):
        noted[tid] = True
        ours = [e for e in events if any(w in e["norm"] for w in ("star trek", "reality fracture", "hobbit"))]
        log_fn(f"[diagnostic] {tid} feed {t['feed_url']}: HTTP {code}, {len(html or '')} characters, {len(events)} recent restock lines, {len(ours)} for our sets. Examples: "
               + " || ".join(e["text"][:100] for e in (ours or events)[:3]))
        if not events:
            samples.save(f"feed_{tid}", "no_events", html or "", t["feed_url"])
    now = time.time()
    for e in events:
        published = now - e["age"]
        for target in list(targets):
            if matrix.is_off(target) or retailer_word(target.get("url", "")) != "amazon" or not products.title_matches(e["norm"], target):
                continue
            k = (tid, target["id"])
            last = ev_seen.get(k)
            if last is not None and abs(published - last) < 150:
                continue                       # the same restock (its age grows by the second; ages are rounded)
            ev_seen[k] = published
            if not products.price_ok(e["text"], target):
                continue
            ts = datetime.fromtimestamp(published, timezone.utc).isoformat()
            try:
                hotness.mark(target["id"])
            except Exception:
                pass
            log_fn(f"[{ts}] NEW MENTION: {tid} / {target['id']} (restock listed {e['age']}s ago)")
            if not append_csv_row(out_path, [ts, tid, target["id"], e["text"] + " || " + t["feed_url"][:160]]):
                log_fn(f"[error] {out_path} could not be written to (is it open in Excel?). This mention is saved in {out_path}.pending.")
            if report:
                report("tracker", tid, last_mention_at=time.time(), last_mention_target=target["id"])
    return "ok", ""


# ---- v63: TrackaLacker's public listing page of EVERY retailer (Amazon, Target, Walmart, Best Buy, GameStop) for every product of yours.
# The program finds them by itself: TrackaLacker's Magic: The Gathering category pages list its products; a product whose name is one of
# yours is opened once and the links of its retailer listings are kept. Each listing page is then read like the others (a flip from
# Out of Stock to In Stock is a mention for that store's square). Found again every 6 hours. Light: at most one request a second there.
TL_CATEGORY = "https://www.trackalacker.com/category/toys-and-games/trading-cards/magic-the-gathering?page={n}"
_TL_SHOW = re.compile(r"/products/showcase/([a-z0-9][a-z0-9\-]{8,160})(?=[\"'/?#])", re.I)
_TL_LIST = re.compile(r"(/products/showcase/[a-z0-9\-]+/listings/(\d+)/[a-z0-9\-]+)", re.I)
_TL_RET = re.compile(r"\bat (Amazon|Target|Walmart|Best Buy|GameStop)\b", re.I)


def discover_trackalacker(targets, fetch_page, log_fn, pages=6):
    """-> [{'name','url','retailer'}] TrackaLacker listing pages of our products at our stores."""
    slugs = []
    for n in range(1, pages + 1):
        code, html, err = fetch_page(TL_CATEGORY.format(n=n))
        if err or not html or (code and code >= 400):
            break
        new = [m.group(1).lower() for m in _TL_SHOW.finditer(html)]
        new = [x for x in dict.fromkeys(new) if "/listings/" not in x and x not in slugs]
        if not new:
            break
        slugs += new
        time.sleep(1.0)
    ours = {}
    for t in targets:
        st = retailer_word(t.get("url", ""))
        if st and not matrix.is_off(t):
            ours.setdefault(products.theme_of(t) + "|" + products.kind_of(t), []).append((t, st))
    found, used = [], set()
    for slug in slugs:
        title = re.sub(r"(\s\d{3,})+$", "", slug.replace("-", " "))          # ("...-collector-booster-48130": the number is TrackaLacker's own)
        hit = None
        for key, rows in ours.items():
            if key in used:
                continue
            if any(products.title_matches(_norm(title), t) and products.kind_fits(products.kind_of(t), title) for t, _ in rows):
                hit = key
                break
        if not hit:
            continue
        code, html, err = fetch_page("https://www.trackalacker.com/products/showcase/" + slug)
        time.sleep(1.0)
        if err or not html:
            continue
        used.add(hit)
        stores = {st for _, st in ours[hit]}
        for path, lid in dict.fromkeys(_TL_LIST.findall(html)):
            # the retailer of a listing: the words right after its link ("... at Target")
            i = html.find(path)
            m = _TL_RET.search(re.sub(r"<[^>]+>", " ", html[i:i + 1500])) if i >= 0 else None
            ret = (m.group(1).lower() if m else "")
            if ret and ret in stores:
                found.append({"name": title, "url": "https://www.trackalacker.com" + path, "retailer": ret})
    log_fn(f"[info] TrackaLacker: found {len(found)} public listing page(s) of your products at your stores "
           f"({len(used)} of {len(ours)} products; {len(slugs)} Magic products listed there).")
    return found


def _plain_page(url, timeout=12.0):
    """(status code, text, error) with the thread's own cookie-keeping session."""
    import http_utils
    try:
        r = http_utils._session().get(url, timeout=timeout)
        return r.status_code, r.text, None
    except Exception as ex:
        return None, None, str(ex)[:120]


def pages_loop(trackers, targets, out_path, stop_event, log_fn, report=None, fetch_page=None, alt_fetch=None):
    """The public-page trackers, in a thread of their own. Every page is read about every `interval_sec` seconds (staggered, so the requests
    to one site are spread out). A page that errors or is blocked rests 1, 2, 4 ... 10 minutes - the pace is never pushed."""
    holder = {"b": None}
    if fetch_page is None:
        fetch_page = _plain_page
        if alt_fetch is None and not os.environ.get("RK_NO_PAGE_BROWSER"):
            def alt_fetch(url):
                try:
                    if holder["b"] is None:
                        class _PageBrowser(BrowserFetcher):
                            CHANNELS = ["chrome", "msedge", None]          # v47: an ordinary light browser (v46 started a whole Camoufox just for this)
                        holder["b"] = _PageBrowser(store="pages")
                    html, e = holder["b"].fetch(url, timeout=25.0)
                    return (200 if html else None), html, e
                except Exception as ex:
                    return None, None, str(ex)[:120]
    via, alt_tried = {}, {}
    st_state, noted, ev_seen = {}, {}, {}
    due, fails, unread = {}, {}, {}
    jobs = []
    for t in trackers:
        if t.get("kind") not in PAGE_KINDS or not t.get("active", True):
            continue
        if t.get("kind") == "event_page":
            jobs.append((t, {"name": t.get("name"), "url": t["feed_url"]}))
        else:
            for pg in pages_for_tracker(t):
                jobs.append((t, pg))
    tl = next((t for t in trackers if t.get("id") == "trackalacker_page" and t.get("active", True)), None)
    tl_found = {"at": 0.0}
    if not jobs and tl is None:
        return
    gap0 = {}
    for i, (t, pg) in enumerate(jobs):
        n = sum(1 for tt, _ in jobs if tt["id"] == t["id"])
        j = sum(1 for tt, _ in jobs[:i] if tt["id"] == t["id"])
        due[(t["id"], pg["url"])] = time.time() + (float(t.get("interval_sec", 15)) / max(1, n)) * j
    log_fn(f"[info] public-page trackers: reading {len(jobs)} page(s) directly ({', '.join(sorted({t['id'] for t, _ in jobs}))}).")
    while stop_event is None or not stop_event.is_set():
        now = time.time()
        if tl is not None and now - tl_found["at"] > 6 * 3600 and not os.environ.get("RK_NO_TL_DISCOVERY"):
            tl_found["at"] = now
            try:
                have = {pg["url"] for _, pg in jobs}
                extra = [pg for pg in discover_trackalacker(targets, fetch_page, log_fn) if pg["url"] not in have]
                for i, pg in enumerate(extra):
                    jobs.append((dict(tl, interval_sec=max(30.0, 1.2 * len(extra))), pg))
                    due[(tl["id"], pg["url"])] = time.time() + 1.2 * i       # (spread: about one request a second)
            except Exception as ex:
                log_fn(f"[warn] TrackaLacker listing pages could not be found this time: {str(ex)[:120]}")
        for t, pg in jobs:
            k = (t["id"], pg["url"])
            if due.get(k, 0) > now:
                continue
            gap = float(t.get("interval_sec", 15))
            try:
                if t.get("kind") == "event_page":
                    status, why = _restockd_cycle(t, targets, ev_seen, noted, log_fn, out_path, report, fetch_page)
                else:
                    status, why = _page_cycle_one(t, pg, targets, st_state, noted, log_fn, out_path, report, fetch_page, alt_fetch, via, alt_tried)
            except Exception as ex:
                status, why = "error", f"{type(ex).__name__}: {ex}"[:120]
            if via.get((t["id"], pg["url"])):
                gap = max(gap, 30.0)                  # a page read with the browser is looked at at most every 30 s
            if status == "ok":
                fails[k] = 0
                unread[k] = 0
            elif status == "unread":
                unread[k] = unread.get(k, 0) + 1
                if unread[k] >= 6:
                    gap = 300.0                # the page keeps showing something we cannot read: look only every 5 min
                    if unread[k] in (6, 30):
                        log_fn(f"[warn] {t['id']} page {pg['name']} keeps showing something the program cannot read - checking it only every 5 min (a copy is in the diagnostics samples).")
            else:
                fails[k] = fails.get(k, 0) + 1
                gap = min(600.0, 60.0 * (2 ** min(fails[k] - 1, 4))) if status == "blocked" or fails[k] >= 3 else gap
                if fails[k] in (1, 3) or fails[k] % 20 == 0:
                    log_fn(f"[warn] {t['id']} page {pg['name']}: {status} ({why}); " + (f"resting {gap / 60:.0f} min." if gap > 60 else "will retry."))
            due[k] = time.time() + gap
            if status == "ok":
                gap0[t["id"]] = time.time()
            if report:                                  # v63: a tracker is "working" while any of its pages was read in the last 10 minutes
                report("tracker", t["id"], checked_at=time.time(), ok=(status == "ok" or time.time() - gap0.get(t["id"], 0) < 600), fetch_mode="http")
        if _sleep_or_stop(0.5, stop_event):
            break
    if holder["b"] is not None:
        try:
            holder["b"].close()
        except Exception:
            pass


_OUT_RE = re.compile(r"\b(out of stock|sold out|unavailable|out-of-stock|currently unavailable)\b", re.I)
_IN_RE = re.compile(r"\b(in stock|in-stock|available now|add to cart)\b", re.I)
_ROW_RETAILERS = ("amazon", "walmart", "target", "best buy", "bestbuy", "gamestop", "sam's club", "disney store")


def row_status(text):
    """'IN' / 'OUT' / None for one table row's words."""
    if _OUT_RE.search(text):
        return "OUT"
    if _IN_RE.search(text):
        return "IN"
    return None


def parse_status_rows(soup):
    """[{'text','norm','status','retailer'}] for every table row that shows a stock word. The retailer is the word after the
    last ' : ' of the product name (NowInStock writes 'The Hobbit Gift Bundle : Amazon'); None when the row names none."""
    rows = []
    for tr in soup.find_all("tr"):
        cells = [" ".join(td.get_text(" ").split()) for td in tr.find_all(["td", "th"])]
        cells = [c for c in cells if c]
        if not cells or tr.find("th"):
            continue
        txt = " | ".join(cells)
        st = row_status(txt)
        if st is None:
            continue
        name = cells[0]
        retailer = None
        if " : " in name:
            tail = name.rsplit(" : ", 1)[1].strip().lower()
            retailer = next((r for r in _ROW_RETAILERS if tail.startswith(r)), tail)
            name = name.rsplit(" : ", 1)[0]
        else:
            low = txt.lower()
            retailer = next((r for r in _ROW_RETAILERS if r in low), None)
        rows.append({"text": txt, "name_norm": _norm(name), "status": st, "retailer": retailer})
    return rows


def status_events(rows, target, state):
    """Rows of this tracker that are our product at our store. Returns the rows that just flipped Out -> In (state is updated:
    {row key: last status}). The first time a row is seen it is only remembered - when it came into stock is unknown."""
    want = retailer_word(target.get("url", ""))
    fresh = []
    for r in rows:
        if not products.title_matches(r["name_norm"], target):
            continue
        if want and r["retailer"] and r["retailer"].replace(" ", "") != want.replace(" ", ""):
            continue
        if want and not r["retailer"]:
            continue
        k = r["name_norm"] + "|" + (r["retailer"] or "")
        prev = state.get(k)
        state[k] = r["status"]
        if prev == "OUT" and r["status"] == "IN":
            fresh.append(r)
    return fresh


def _sleep_or_stop(seconds, stop_event):
    end = time.time() + seconds
    while time.time() < end:
        if stop_event is not None and stop_event.is_set():
            return True
        time.sleep(min(0.5, max(0, end - time.time())))
    return False


_FEED_STRIP = [re.compile(r"(?is)<script\b.*?</script>"), re.compile(r"(?is)<style\b.*?</style>"),
               re.compile(r"(?is)<svg\b.*?</svg>"), re.compile(r"(?s)<!--.*?-->"),
               re.compile(r"(?i)<(?:img|link|source)\b[^>]*>")]


def _read_feed(html, tracker_id, last_feed):
    """(soup, text) for the feed page - or (None, previous text) if the page is
    byte-for-byte the same as the last poll (nothing to do). Scripts and styles
    are dropped before reading, which is most of the page's size."""
    lean = html
    for rx in _FEED_STRIP:
        lean = rx.sub("", lean)
    if last_feed.get(tracker_id) == lean:
        return None, "same"
    last_feed[tracker_id] = lean
    soup = BeautifulSoup(lean, "html.parser")
    return soup, re.sub(r"\s+", " ", soup.get_text(separator=" ")).strip()


class _LazyBrowser:
    def __init__(self):
        self._instance = None

    def get(self):
        if self._instance is None:
            self._instance = BrowserFetcher()
        return self._instance

    def close(self):
        if self._instance:
            self._instance.close()


def run(trackers, targets, out_path, stop_event=None, log_fn=print, report=None):
    """trackers, targets: parsed lists from their yaml configs. Runs until
    stop_event is set (or forever, if stop_event is None — use Ctrl+C standalone).
    report(kind, item_id, **fields), if given, is called with live status
    updates ('tracker', id, checked_at=...), on new mentions ('tracker',
    id, last_mention_at=..., last_mention_target=...), and on an
    automatic fetch_mode upgrade ('tracker', id, fetch_mode='browser',
    auto_upgraded=True) so app.py can persist it to disk."""
    browser = _LazyBrowser()
    seen = {}  # (tracker_id, target_id) -> set of snippets already logged
    ages = {}            # (tracker, target) -> {card key: (youngest age, when seen)}
    layout_warned = {}
    warn_state = {}
    backoff_until = {}
    last_feed = {}
    st_noted, st_state = {}, {}       # status-page trackers: noted once / last status of each row

    if not os.path.exists(out_path):
        with open(out_path, "w", newline="", encoding="utf-8") as f:
            csv.writer(f).writerow(["timestamp_utc", "tracker_id", "target_id", "snippet"])
    flush_pending_csv(out_path)

    work = list(trackers)
    if os.environ.get("RK_EXTRA_FEED"):        # OFF by default: measured to be refreshed only about hourly, so useless for timing
        for t0 in trackers:
            if "typa.app" in (t0.get("feed_url") or "") and not any(x.get("feed_url") == EXTRA_TYPA_PAGE for x in trackers):
                work.append(dict(t0, id=t0["id"] + "_magic", _as=t0["id"], _extra=True, feed_url=EXTRA_TYPA_PAGE,
                                 fetch_mode="http", interval_sec=EXTRA_GAP_SEC))
                break
    last_poll = {}
    extra_note_at = {}
    log_fn(f"[version] feed checker {VERSION}. Polling {len(trackers)} tracker(s) for mentions of {len(targets)} product(s)"
           f"{' (+ the TYPA Magic page as an extra source)' if len(work) > len(trackers) else ''}.")
    _pg_thread = None
    if any(t.get("kind") in PAGE_KINDS and t.get("active", True) for t in work) and not os.environ.get("RK_NO_PAGE_TRACKERS"):
        import threading as _th
        _pg_thread = _th.Thread(target=pages_loop, args=([t for t in work], targets, out_path, stop_event, log_fn, report), daemon=True, name="page-trackers")
        _pg_thread.start()
    try:
        while stop_event is None or not stop_event.is_set():
            for t in work:
                now = time.time()
                if t.get("_extra") and now - last_poll.get(t["id"], 0) < EXTRA_GAP_SEC:
                    continue
                if t.get("kind") in PAGE_KINDS:
                    continue                  # read by pages_loop, in its own thread
                if t.get("kind") == "status_table":
                    if now - last_poll.get(t["id"], 0) < float(t.get("interval_sec", 15)):
                        continue
                    last_poll[t["id"]] = now
                if backoff_until.get(t["id"], 0) > now:
                    if _sleep_or_stop(0.05, stop_event):
                        return
                    continue

                tracker_id = t["id"]
                out_id = t.get("_as", tracker_id)       # the name written to alerts.csv ("typa" for the extra page too)
                if t.get("_extra"):
                    last_poll[tracker_id] = now
                if t.get("fetch_mode") == "browser":
                    html, err = browser.get().fetch(t["feed_url"])
                else:
                    html, err = fetch(t["feed_url"])
                if html and not err:
                    samples.save(f"feed_{tracker_id}", "first_poll", html, t["feed_url"])

                if err:
                    fails = warn_state.get(tracker_id, 0) + 1
                    warn_state[tracker_id] = fails
                    if fails == 1 or fails % 30 == 0:
                        log_fn(f"[warn] fetch failed for tracker '{tracker_id}' ({fails}x so far): {err}")

                    if fails == 3 and t.get("fetch_mode") != "browser" and not t.get("_extra"):
                        b_html, b_err = browser.get().fetch(t["feed_url"])
                        if not b_err:
                            log_fn(f"[info] tracker '{tracker_id}' failed {fails}x via plain requests — "
                                   f"auto-upgraded to browser mode, which works. Continuing with that.")
                            t["fetch_mode"] = "browser"
                            warn_state[tracker_id] = 0
                            if report:
                                report("tracker", tracker_id, fetch_mode="browser", auto_upgraded=True)
                            html, err = b_html, None
                        else:
                            log_fn(f"[info] tracker '{tracker_id}' failed {fails}x via plain requests; "
                                   f"tried a real browser too, still blocked ({b_err}). Backing off.")

                    if err:
                        fails = warn_state.get(tracker_id, 0)
                        if fails >= 3:
                            delay = min(300, 15 * (2 ** min(fails - 3, 4)))
                            backoff_until[tracker_id] = time.time() + delay
                        text = ""
                    else:
                        soup, text = _read_feed(html, tracker_id, last_feed)
                else:
                    warn_state[tracker_id] = 0
                    soup, text = _read_feed(html, tracker_id, last_feed)

                if report and not t.get("_extra"):
                    report("tracker", tracker_id, checked_at=time.time(), ok=bool(text),
                           fetch_mode=t.get("fetch_mode", "http"))

                if not text:
                    if _sleep_or_stop(0.2, stop_event):
                        return
                    continue
                if soup is None:
                    # the page is exactly what it was last poll: nothing new can be in it
                    if _sleep_or_stop(0.2, stop_event):
                        return
                    continue
                if t.get("kind") == "status_table":
                    rows = parse_status_rows(soup)
                    if not st_noted.get(tracker_id):
                        st_noted[tracker_id] = True
                        ours = [r for r in rows if any(w in r["name_norm"] for w in ("star trek", "reality fracture", "hobbit"))]
                        log_fn(f"[diagnostic] status page {t['feed_url']}: {len(rows)} product rows, {len(ours)} for our sets. Examples: "
                               + " || ".join(r["text"][:110] for r in ours[:4]))
                        samples.save(f"feed_{tracker_id}", "first_poll", html, t["feed_url"])
                    for target in list(targets):
                        if matrix.is_off(target):
                            continue
                        for r in status_events(rows, target, st_state.setdefault((tracker_id, target["id"]), {})):
                            if not products.price_ok(r["text"], target):
                                log_fn(f"[info] {tracker_id} lists {target['id']} above your price limit (${target.get('max_price')}) - not counted: " + r["text"][:120])
                                continue
                            ts = datetime.now(timezone.utc).isoformat()
                            try:
                                hotness.mark(target["id"])
                            except Exception:
                                pass
                            _pr = products.prices_in(r["text"])
                            log_fn(f"[{ts}] NEW MENTION: {tracker_id} / {target['id']} (status page flipped to In Stock)" + (f" price ${_pr[0]:.2f}" if _pr else ""))
                            if not append_csv_row(out_path, [ts, tracker_id, target["id"], r["text"] + " [status page: first seen In Stock just now] || " + t["feed_url"][:160]]):
                                log_fn(f"[error] {out_path} could not be written to (is it open in Excel?). This mention is saved in {out_path}.pending.")
                            if report:
                                report("tracker", tracker_id, last_mention_at=time.time(), last_mention_target=target["id"])
                    if _sleep_or_stop(0.2, stop_event):
                        return
                    continue
                anchors = all_anchor_cards(soup)
                text_n = _norm(text)
                if t.get("_extra") and now - extra_note_at.get(tracker_id, 0) > 6 * 3600:
                    extra_note_at[tracker_id] = now          # once at the start, then every 6 h: what this page really holds
                    try:
                        ours = [c for c in anchors if any(w in c["norm"] for w in ("star trek", "reality fracture", "hobbit"))]
                        log_fn(f"[diagnostic] extra TYPA page {t['feed_url']}: {len(anchors)} clickable cards, {len(ours)} for our products. "
                               f"Examples: " + " || ".join((c["text"] or "")[:140] for c in ours[:6]))
                    except Exception:
                        pass
                for target in list(targets):
                    if matrix.is_off(target):
                        continue            # switched off in the table
                    key = (tracker_id, target["id"])
                    state = ages.setdefault(key, {})   # card key -> (youngest age seen, when)
                    now_t = time.time()
                    needle = _norm(target["match_name"])
                    cards = [c for c in anchors if products.title_matches(c["norm"], target)]
                    if not cards and products.title_matches(text_n, target) and kind_is_box(target):
                        if not layout_warned.get(tracker_id):
                            layout_warned[tracker_id] = True
                            i = text.lower().find(target["match_name"].lower())
                            log_fn(f"[evidence] feed '{tracker_id}': product text found but not inside "
                                   f"clickable cards - layout may have changed: {text[max(0, i-60):i+300]}")
                    # several cards can share one key (same product, store, price);
                    # keep the youngest of each
                    youngest = {}
                    for c in cards:
                        if not card_is_for_store(c, target.get("url", "")):
                            continue
                        k = _dedupe_key(c["text"])
                        age = parse_age_sec(c["text"])
                        if k not in youngest or (age is not None and (youngest[k][0] is None or age < youngest[k][0])):
                            youngest[k] = (age, c)
                    for k, (age, c) in youngest.items():
                        prev = state.get(k)
                        is_new = False
                        if prev is None:
                            # first time we see this card: a live event only if it is fresh
                            is_new = (age is None) or (age <= STALE_AT_FIRST_SIGHT)
                        else:
                            expected = (prev[0] or 0) + (now_t - prev[1])
                            # same product/store/price listed again, younger than it
                            # should be = it was restocked again
                            # the shown age is rounded DOWN to its unit, so it can lag the real age by up to one unit
                            is_new = (age is not None and prev[0] is not None
                                      and age + max(AGE_SLACK, age_span_sec(c["text"])) < expected)
                        state[k] = (age, now_t)
                        if is_new and not products.price_ok(c["text"], target):
                            # the tracker lists it, but only at a price above YOUR limit (a reseller): not a restock we are waiting for
                            log_fn(f"[info] {out_id} lists {target['id']} above your price limit (${target.get('max_price')}) - not counted: " + (c["text"] or "")[:120])
                            is_new = False
                        if is_new:
                            ts = datetime.now(timezone.utc).isoformat()
                            try:
                                hotness.mark(target["id"])      # a tracker just alerted: look at this product at full speed for a while
                            except Exception:
                                pass
                            _pr = products.prices_in(c["text"])
                            log_fn(f"[{ts}] NEW MENTION: {out_id} / {target['id']} (feed says {age if age is not None else '?'}s old)" + (f" price ${_pr[0]:.2f}" if _pr else ""))
                            samples.save(f"feed_{tracker_id}", "mention", html, f"target={target['id']} age={age}", force=True)
                            if age is not None and age <= 600:      # only a fresh card is worth a close look
                                try:
                                    recon.mention(target["id"], target.get("url", ""),
                                                  {"tracker": out_id, "snippet": (c["text"] or "")[:240],
                                                   "href": (c["href"] or "")[:200]}, age)
                                except Exception:
                                    pass
                            if not append_csv_row(out_path, [ts, out_id, target["id"], c["text"] + " || " + c["href"][:160]]):
                                log_fn(f"[error] {out_path} could not be written to (is it open in Excel?). This mention is "
                                       f"saved in {out_path}.pending and is added automatically when the file is free.")
                            if report:
                                report("tracker", out_id, last_mention_at=time.time(),
                                       last_mention_target=target["id"])
                    if len(state) > 400:
                        for kk in list(state)[:100]:
                            state.pop(kk, None)
                if _sleep_or_stop(0.2, stop_event):
                    return
            if _sleep_or_stop(min(t.get("interval_sec", 2) for t in trackers), stop_event):
                return
    except KeyboardInterrupt:
        log_fn("Stopped.")
    finally:
        browser.close()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--trackers", required=True)
    ap.add_argument("--targets", required=True)
    ap.add_argument("--out", default="alerts.csv")
    args = ap.parse_args()

    with open(args.trackers) as f:
        tracker_cfg = yaml.safe_load(f)
    with open(args.targets) as f:
        target_cfg = yaml.safe_load(f)

    run(tracker_cfg["trackers"], target_cfg["targets"], args.out)


if __name__ == "__main__":
    main()
