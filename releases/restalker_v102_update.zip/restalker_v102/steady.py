"""v101: a product's square on the Products tab stays steady (owner 2026-11-05: "I noticed products flashing in stock and out of stock I
think based on cycling through multiple browsers. we need to be sure and static, so one of those browsers may not be reporting correctly").

Several browsers read the same product, one after the other. They do not always see the same page (one is shown the other sellers'
offer over your cap, the next one "currently unavailable"), so the square jumped between "for sale - over cap" and "out" with every
reading. Now:
- a reading that can be BOUGHT (in stock under the cap) shows at once - and buying never waits for this (it never did: the buying side
  does not read the square);
- any other change shows only when it holds: the last 3 readings agree, or it is the clear majority of the last 6;
- every reading keeps which browser it came from, so the diagnostics name a browser that disagrees with the others.
Display only: nothing here decides a restock or a purchase."""
import collections
import threading
import time

VERSION = "v102"
WINDOW = 6
HOLD = 3
KEEP = 400                 # readings kept per product for the who-said-what count
KEEP_FOR = 7200.0          # s
_L = threading.Lock()
_S = {}


def cls_of(status, high):
    if status == "IN_STOCK":
        return "in"
    if status == "OUT_OF_STOCK":
        return "over" if high else "out"
    return None


def _st(tid):
    s = _S.get(tid)
    if s is None:
        s = _S[tid] = {"recent": collections.deque(maxlen=WINDOW), "shown": None, "price": None, "since": 0.0,
                       "log": collections.deque(maxlen=KEEP), "raw_flips": collections.deque(maxlen=KEEP),
                       "shown_flips": collections.deque(maxlen=KEEP), "last_raw": None}
    return s


def note(tid, status, high=False, price=None, src="", now=None):
    """One real reading of product tid -> what its square shows: {"status", "high", "price", "since"} (or None for a non-reading)."""
    c = cls_of(status, high)
    if c is None:
        return shown(tid)
    now = now or time.time()
    with _L:
        s = _st(tid)
        s["recent"].append((c, price))
        s["log"].append((now, src or "?", c))
        if s["last_raw"] is not None and s["last_raw"] != c:
            s["raw_flips"].append(now)
        s["last_raw"] = c
        cur = s["shown"]
        rec = [x[0] for x in s["recent"]]
        new = cur
        if c == "in" or cur is None:
            new = c
        elif c != cur:
            last = rec[-HOLD:]
            cnt = collections.Counter(rec)
            if (len(last) == HOLD and all(x == c for x in last)) or cnt[c] > cnt[cur]:
                new = c
            if cur == "in" and not (len(rec) >= 2 and rec[-2] != "in"):
                new = cur                    # (from in stock: two readings in a row that are not - as the restock rules too)
        if new != cur:
            if cur is not None:
                s["shown_flips"].append(now)
            s["shown"], s["since"] = new, now
        if new == c:
            s["price"] = price
        elif s["price"] is None:
            s["price"] = next((p for k, p in reversed(s["recent"]) if k == new and p is not None), None)
        return _out(s)


def _out(s):
    if s["shown"] is None:
        return None
    return {"status": "IN_STOCK" if s["shown"] == "in" else "OUT_OF_STOCK", "high": s["shown"] == "over", "price": s["price"], "since": s["since"]}


def shown(tid):
    with _L:
        s = _S.get(tid)
        return _out(s) if s else None


WORDS = {"in": "can be bought", "over": "for sale over the cap", "out": "sold out"}


def report_text(names=None, now=None, limit=12):
    """Diagnostics: products whose readings disagree, and who said what (last 2 hours)."""
    now = now or time.time()
    rows = []
    with _L:
        items = list(_S.items())
    for tid, s in items:
        log = [x for x in s["log"] if now - x[0] <= KEEP_FOR]
        if len(log) < 4:
            continue
        raw = sum(1 for t in s["raw_flips"] if now - t <= KEEP_FOR)
        shw = sum(1 for t in s["shown_flips"] if now - t <= KEEP_FOR)
        by = collections.defaultdict(collections.Counter)
        for _, src, c in log:
            by[src][c] += 1
        tot = collections.Counter(c for _, _, c in log)
        main = tot.most_common(1)[0][0]
        odd = []
        for src, cn in by.items():
            n = sum(cn.values())
            other = n - cn[main]
            if n >= 3 and other / n >= 0.3:
                odd.append(f"{src} says {', '.join(f'{WORDS[k]} {v}' for k, v in cn.most_common())}")
        rows.append((raw, tid, len(log), raw, shw, tot, odd, by))
    rows.sort(key=lambda r: -r[0])
    out = []
    for _, tid, n, raw, shw, tot, odd, by in rows[:limit]:
        if raw == 0:
            continue
        nm = (names or {}).get(tid, tid)
        out.append(f"  {nm}: {n} readings, they changed {raw}x - the square changed {shw}x. All readings: "
                   + ", ".join(f"{WORDS[k]} {v}" for k, v in tot.most_common()))
        for src, cn in sorted(by.items(), key=lambda kv: -sum(kv[1].values()))[:8]:
            out.append(f"      {src}: " + ", ".join(f"{WORDS[k]} {v}" for k, v in cn.most_common()))
        if odd:
            out.append("      DISAGREES with most readings: " + " | ".join(odd))
    return "\n".join(out) if out else "  every product's readings agree (no change between readings in the last 2 hours)"
