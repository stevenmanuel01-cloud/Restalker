"""v52: keeps a program that is meant to run for months small, without anybody restarting it.

What was found in a 6-hour run (v47): the program held 23-27 GB; 3 GB of it inside the program itself (4.9 million small objects) and 6 GB in the
nine automation helper processes. Cause (proved with real browsers): every full page load leaves ~400 objects behind for as long as the same
browser tab stays open. The fix is in browser_fetch.py (a tab is replaced by a new one in the same browser after PAGE_NAVS page loads / PAGE_SECS
seconds; the "listen to every answer" hook only where needed). This file adds the regular housekeeping on top:

  1. every 5 minutes: free the program's unused memory (python's garbage, and - on Windows - the unused pages of the program and of its
     browsers are handed back: that is the "clear the memory cache" part; it costs nothing, pages come back from memory when needed);
  2. every CACHE_EVERY seconds each reader clears its browser's page cache (not cookies, not logins) - see _run_one;
  3. if the program's total memory passes MEM_HARD_GB (default 30 % of the PC's memory) the readers' browsers are restarted one by one, at quiet
     moments (see pressure()), one by one - so memory can never grow without limit;
  4. every hour the folders that fill up on their own (samples, recon) are cut back to a size limit, oldest files first;
  5. one line an hour in the log, and a section in the diagnostics: how big the program is and what the housekeeping did.
Nothing here slows a read: it all happens between reads and outside the checking threads."""
import gc
import os
import threading
import time

VERSION = "v102"
TRIM_EVERY = 300.0            # seconds between housekeeping rounds
CACHE_EVERY = 1800.0          # seconds between a reader clearing its browser's cache
LOG_EVERY = 3600.0
PRUNE_EVERY = 3600.0
PRUNE_LIMITS = {"samples": 600 * 1048576, "recon": 400 * 1048576}      # bytes kept per folder
_S = {"rounds": 0, "trimmed": 0, "trim_mb": 0.0, "gc_freed": 0, "pressure_since": 0.0, "pressure_n": 0, "pressure_hits": 0, "last_log": 0.0,
      "last_prune": 0.0, "pruned_files": 0, "pruned_mb": 0.0, "cache_clears": 0, "recycles": 0, "last": "", "hard_gb": None, "soft_gb": None}
_LOCK = threading.Lock()
_pressure = {"on": False, "until": 0.0}


def limits(ram_gb=None):
    """-> (soft_gb, hard_gb): the program's total memory (python + browsers) above which it starts tidying harder / restarting readers' browsers."""
    try:
        if ram_gb is None:
            import cpu_monitor
            ram_gb = cpu_monitor.ram_gb()
    except Exception:
        ram_gb = None
    ram_gb = ram_gb or 16.0
    hard = float(os.environ.get("RK_MEM_HARD_GB", "0") or 0) or max(3.0, 0.30 * ram_gb)
    soft = max(2.0, 0.6 * hard)
    return soft, hard


def pressure():
    """True while the program is over its hard memory limit: each reader restarts its browser at its next quiet moment (one at a time)."""
    return bool(_pressure["on"]) and time.time() < _pressure["until"]


def note_cache_clear(n=1):
    with _LOCK:
        _S["cache_clears"] += n


def note_recycle(n=1):
    with _LOCK:
        _S["recycles"] += n


def trim_working_sets(pids):
    """Windows: hands back the unused memory pages of these processes (they come back from memory when needed). Returns (count, MB freed)."""
    if os.name != "nt":
        return 0, 0.0
    n, freed = 0, 0.0
    try:
        import ctypes
        import psutil
        k = ctypes.windll.kernel32
        ps = ctypes.windll.psapi
        for pid in pids:
            try:
                before = psutil.Process(pid).memory_info().rss
            except Exception:
                before = 0
            h = k.OpenProcess(0x0100 | 0x0400, False, int(pid))        # PROCESS_SET_QUOTA | PROCESS_QUERY_INFORMATION
            if not h:
                continue
            try:
                if ps.EmptyWorkingSet(h):
                    n += 1
                    try:
                        freed += max(0, before - psutil.Process(pid).memory_info().rss) / 1048576.0
                    except Exception:
                        pass
            finally:
                k.CloseHandle(h)
    except Exception:
        pass
    return n, freed


def prune_dir(path, max_bytes):
    """Deletes the OLDEST files of a folder until it is under max_bytes. Returns (files removed, MB removed)."""
    try:
        files = []
        total = 0
        for root, _d, names in os.walk(path):
            for nm in names:
                p = os.path.join(root, nm)
                try:
                    st = os.stat(p)
                except Exception:
                    continue
                files.append((st.st_mtime, st.st_size, p))
                total += st.st_size
        if total <= max_bytes:
            return 0, 0.0
        files.sort()
        n, mb = 0, 0.0
        for _mt, sz, p in files:
            if total <= max_bytes:
                break
            try:
                os.remove(p)
                total -= sz
                n += 1
                mb += sz / 1048576.0
            except Exception:
                continue
        return n, mb
    except Exception:
        return 0, 0.0


def _round(psutil, me, log_fn):
    now = time.time()
    _S["rounds"] += 1
    try:
        _S["gc_freed"] += gc.collect()
    except Exception:
        pass
    try:
        kids = me.children(recursive=True)
    except Exception:
        kids = []
    mine_gb = None
    try:
        rss = me.memory_info().rss
        for k in kids:
            try:
                rss += k.memory_info().rss
            except Exception:
                pass
        mine_gb = rss / 1073741824.0
    except Exception:
        pass
    try:
        ram = psutil.virtual_memory().total / 1073741824.0
    except Exception:
        ram = None
    soft, hard = limits(ram)
    _S["soft_gb"], _S["hard_gb"] = soft, hard
    # 1. hand back unused pages (Windows) - always when the program is over its soft limit, and every other round otherwise
    if os.name == "nt" and mine_gb is not None and (mine_gb > soft or _S["rounds"] % 2 == 0):
        n, mb = trim_working_sets([me.pid] + [k.pid for k in kids])
        _S["trimmed"] += n
        _S["trim_mb"] += mb
    # 3. over the hard limit for two rounds in a row: the readers restart their browsers (one at a time, at quiet moments)
    if mine_gb is not None and mine_gb > hard:
        _S["pressure_hits"] += 1
        if _S["pressure_hits"] >= 2:
            if not _pressure["on"]:
                _S["pressure_n"] += 1
                _S["pressure_since"] = now
                log_fn(f"[hygiene] the program holds {mine_gb:.1f} GB (limit {hard:.1f} GB for this PC): the readers' browsers are restarted one by one, "
                       f"at quiet moments, until it is back under the limit.")
            _pressure["on"] = True
            _pressure["until"] = now + TRIM_EVERY * 1.5
    else:
        _S["pressure_hits"] = 0
        if _pressure["on"] and mine_gb is not None and mine_gb < hard * 0.85:
            _pressure["on"] = False
            log_fn(f"[hygiene] back under the limit ({mine_gb:.1f} GB of {hard:.1f} GB).")
    # 4. folders that fill up on their own
    if now - _S["last_prune"] >= PRUNE_EVERY:
        _S["last_prune"] = now
        for d, lim in PRUNE_LIMITS.items():
            n, mb = prune_dir(d, lim)
            if n:
                _S["pruned_files"] += n
                _S["pruned_mb"] += mb
                log_fn(f"[hygiene] folder '{d}' was over {lim // 1048576} MB: the {n} oldest files ({mb:.0f} MB) were removed.")
    try:
        import browser_fetch
        tabs = browser_fetch.tab_stats()["tabs"]
    except Exception:
        tabs = 0
    _S["last"] = (f"program {mine_gb:.1f} GB (soft {soft:.1f}, hard {hard:.1f}); tabs replaced {tabs}; browser caches cleared {_S['cache_clears']}; "
                  f"browsers restarted for memory {_S['recycles']}; memory handed back {_S['trim_mb']:.0f} MB in {_S['trimmed']} steps"
                  if mine_gb is not None else "not measured")
    # 5. one line an hour
    if now - _S["last_log"] >= LOG_EVERY:
        _S["last_log"] = now
        log_fn("[hygiene] " + _S["last"])


def start(log_fn=print):
    def loop():
        try:
            import psutil
        except Exception:
            return
        me = psutil.Process()
        _S["last_log"] = time.time() - LOG_EVERY + 600.0          # the first line after 10 minutes
        while True:
            time.sleep(TRIM_EVERY)
            try:
                _round(psutil, me, log_fn)
            except Exception as e:
                try:
                    log_fn(f"[hygiene] round failed: {e}")
                except Exception:
                    pass
    threading.Thread(target=loop, daemon=True, name="hygiene").start()


def text():
    """For the diagnostics."""
    s = _S["last"] or "no round yet (the first is 5 minutes after the start)"
    soft, hard = (_S["soft_gb"], _S["hard_gb"]) if _S["hard_gb"] else limits()
    try:
        import browser_fetch
        t = browser_fetch.tab_stats()
        tab = f" Tabs replaced so far: {t['tabs']} (after {browser_fetch.PAGE_NAVS} page loads or {int(browser_fetch.PAGE_SECS // 60)} min)."
    except Exception:
        tab = ""
    return (f"Memory housekeeping (v52): {s}.{tab} Limits for this PC: tidy harder above {soft:.1f} GB, restart browsers above {hard:.1f} GB. "
            f"Times over the hard limit: {_S['pressure_n']}. Folders cut back: {_S['pruned_files']} files ({_S['pruned_mb']:.0f} MB).")
