"""v99: a copy of Restalker to take elsewhere - two kinds (owner 2026-11-04: "an export feature with two options (either cloning the current
version with or without all data populated/saved) one being for new users and the other for me to use at a different computer").

- "new": for a NEW USER - the program and (if you choose) your product list with its links and price caps. Nothing of yours: no
  sign-ins, card code, phone or Discord names, purchases, history, logs, settings or browsers. Nothing is set to Buy.
- "move": for YOU on another PC - the program and your data: products, switches, settings, phone and Discord set-up, purchases and
  history. Never in it (they cannot work on another PC): your saved store sign-ins and card code (locked to this PC's Windows account -
  type them in once there), the browsers' own sign-ins, and this PC's private listening name for phone buttons (the new PC makes its own).

Updates sent later contain only program files, never data, so a copy of either kind takes the same updates."""
import io, os, time, zipfile

VERSION = "v105"
HERE = os.path.dirname(os.path.abspath(__file__))

# what the program itself is made of (both kinds)
PROGRAM_DIRS = ("buyer_engine", "reader_engine")
PROGRAM_FILES_EXT = (".py", ".bat")
PROGRAM_EXTRA = ("msrp.yaml", "new_products.yaml")
# never in any copy: secrets locked to this PC, links between the program and its browsers (they carry a key), and caches
NEVER = {"store_logins.bin", "store_logins.bin.tmp", "card_code.bin", "card_code.bin.tmp", "restalker_link.json", "reader_link.json",
         "notify_cmd.txt", "phone_actions.json", "phone_actions.json.tmp", "engine_copy.json", "engine_copy.json.tmp", "engine_diagnostics.json",
         "restalker_children.txt", "last_readings.json", "products_merged.txt", "debug.log", "debug.log.1", "sweep_pace.json", "export_tmp.zip", "buy_events.csv.tmp"}
# your data, in the copy for your other PC
MOVE_DATA = ("targets.yaml", "trackers.yaml", "ui_state.yaml", "amazon_buy.json", "notify_phone.txt", "notify_popup.txt", "notify_restocks.txt",
             "discord_webhook.txt", "discord_bot.json", "bestbuy_key.txt", "browsers_off.json", "engine_first.txt", "game_programs.txt",
             "light_off2.txt", "linkcheck_state.json", "purchases.csv", "purchase_events.json", "buy_events.csv", "ground_truth.csv", "alerts.csv",
             "notifications.csv", "push_events.csv", "amazon_offers.csv", "tcg_prices.csv", "tcg_groups.json", "price_stats.json",
             "alert_episodes.json", "discord_share_off.txt", "discord_personal.txt", "help_link.txt", "KNOWN_ISSUES.md", "RELEASE_HISTORY.md", "PROJECT_REQUIREMENTS.md")
MOVE_DIRS = ("icons",)
# in the copy for a new user (only these, and only when chosen)
NEW_PRODUCTS = ("targets.yaml", "linkcheck_state.json", "tcg_groups.json")
NEW_DIRS = ("icons",)
NEW_ALWAYS = ("trackers.yaml", "help_link.txt")
TOP = "Restalker"

START_NEW = """RESTALKER - FIRST START (new user)

1. Install Python (free) from https://www.python.org/downloads/ - tick "Add python.exe to PATH" during the install.
2. Unzip this folder anywhere (for example Documents\\Restalker).
3. Double-click setup_first_time.bat once (it installs what the program needs; a few minutes).
4. Double-click start_app.bat. The program opens in your browser.
5. Press Help (top right) for the guide - or scan its QR code with your phone.

Nothing is set to buy yet. Sign in to your stores (Sign in, above each store's column), save your card code (Card code, top bar),
then choose Buy next to the products you want. The price cap is the most it ever pays.
"""
START_MOVE = """RESTALKER - YOUR COPY FOR ANOTHER PC

Everything of yours is in it: products, switches, settings, phone and Discord set-up, purchases and history.

On the other PC:
1. Install Python from https://www.python.org/downloads/ (tick "Add python.exe to PATH") and double-click setup_first_time.bat once.
2. Double-click start_app.bat.
3. Type in again (they are locked to the old PC's Windows account and could not be copied): your store sign-ins (Sign-ins, top bar)
   and your card code (Card code, top bar). Sign in to each store once (Sign in, above each store's column).
4. Press Send a test (top bar): the phone buttons use a new private name for this PC by themselves.

IMPORTANT: run Restalker on ONE PC at a time. Two PCs buying the same products can buy one each.
KEEP THIS FILE PRIVATE: it holds your phone and Discord names.
"""
SETUP_BAT = """@echo off
rem Restalker - installs what the program needs (once). Python must be installed first (python.org, tick "Add python.exe to PATH").
cd /d "%~dp0"
echo Installing what Restalker needs (a few minutes)...
py -m pip install --upgrade --disable-pip-version-check flask pyyaml requests beautifulsoup4 playwright psutil pillow
py -m playwright install chromium
echo.
echo Done. Now double-click start_app.bat.
pause
"""


START_BAT = r"""@echo off
rem The program runs inside this black window (it is the program itself, not a log to read). It starts minimized in the taskbar;
rem everything worth reading is on the web page ("Show more log") and in debug.log. Closing this window stops the program.
if /i not "%~1"=="min" (
  start "Restalker" /min cmd /c ""%~f0" min"
  exit /b
)
title Restalker
cd /d "%~dp0"
echo Starting the Restalker app...
echo.
echo Closing any older copy and its leftover browsers (if there are none, nothing happens)...
powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-NetTCPConnection -LocalPort 8001 -State Listen -ErrorAction SilentlyContinue | ForEach-Object { taskkill /F /T /PID $_.OwningProcess | Out-Null }; Get-CimInstance Win32_Process | Where-Object { $_.ProcessId -ne $PID -and $_.CommandLine -like ('*--rk-' + 'store=*') } | ForEach-Object { taskkill /F /T /PID $_.ProcessId | Out-Null }" >nul 2>&1
ping 127.0.0.1 -n 4 >nul
echo.
echo Your browser will open automatically in a moment.
echo Please do not close this window while using the app (it is minimized in the taskbar).
echo.
py -m pip install --quiet --disable-pip-version-check psutil pillow >nul 2>&1
py app.py
if errorlevel 1 (
  echo.
  echo The app stopped because of a problem. Press any key to close this window.
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Add-Type -AssemblyName System.Windows.Forms; [void][System.Windows.Forms.MessageBox]::Show('The Restalker stopped because of a problem. Open the black window in the taskbar to see why, or send the file debug.log.','Restalker')" >nul 2>&1
  pause >nul
)
"""


def _program_entries():
    out = []
    for n in sorted(os.listdir(HERE)):
        p = os.path.join(HERE, n)
        if os.path.isfile(p) and (n.endswith(PROGRAM_FILES_EXT) or n in PROGRAM_EXTRA) and n not in NEVER:
            out.append((p, n))
    for d in PROGRAM_DIRS:
        out += _tree(d)
    return out


def _tree(d):
    out = []
    base = os.path.join(HERE, d)
    for root, dirs, files in os.walk(base):
        dirs[:] = [x for x in dirs if x != "__pycache__"]
        for f in files:
            if f in NEVER or f.endswith(".pyc"):
                continue
            p = os.path.join(root, f)
            out.append((p, os.path.relpath(p, HERE).replace("\\", "/")))
    return out


def plan(kind, products=True, discord=False):
    """-> list of (source path, name in the zip) and the texts written into it. kind: "new" or "move"."""
    if kind not in ("new", "move"):
        raise ValueError("kind must be 'new' or 'move'")
    files = _program_entries()
    if kind == "move":
        names = list(MOVE_DATA)
        dirs = list(MOVE_DIRS)
    else:
        names = list(NEW_ALWAYS) + (list(NEW_PRODUCTS) if products else []) + (["discord_webhook.txt"] if discord else [])
        dirs = list(NEW_DIRS) if products else []
    for n in names:
        p = os.path.join(HERE, n)
        if n not in NEVER and os.path.isfile(p):
            files.append((p, n))
    for d in dirs:
        if os.path.isdir(os.path.join(HERE, d)):
            files += _tree(d)
    seen, uniq = set(), []
    for p, n in files:
        if n not in seen:
            seen.add(n)
            uniq.append((p, n))
    texts = {"START HERE.txt": START_NEW if kind == "new" else START_MOVE, "setup_first_time.bat": SETUP_BAT, "start_app.bat": START_BAT}
    return uniq, texts


def build(kind, products=True, discord=False, out_path=None):
    """Writes the zip (to out_path, or into memory) -> (bytes or path, {"files": n, "bytes": size})."""
    files, texts = plan(kind, products, discord)
    buf = open(out_path, "wb") if out_path else io.BytesIO()
    n = 0
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        for p, name in files:
            try:
                z.write(p, f"{TOP}/{name}")
                n += 1
            except Exception:
                pass                         # (a file being written this moment is left out rather than copied half)
        for name, txt in texts.items():
            if not any(nm == name for _, nm in files):         # (your own start_app.bat is kept when this folder has one)
                z.writestr(f"{TOP}/{name}", txt)
                n += 1
    if out_path:
        buf.close()
        return out_path, {"files": n, "bytes": os.path.getsize(out_path)}
    data = buf.getvalue()
    return data, {"files": n, "bytes": len(data)}


def filename(kind):
    return f"Restalker-{VERSION}-{'for-a-new-user' if kind == 'new' else 'for-my-other-PC'}-{time.strftime('%Y%m%d')}.zip"
