"""Keeps the program's own (hidden) browsers from taking over the screen.

On Windows, a browser window that is created or reloaded - even one parked off-screen - can grab the keyboard focus, so
whatever you were typing in is suddenly not the active window. This watches which window is active. If it turns out to be one
of OUR browsers (never one you opened), it hands the focus straight back to the window you were using.
It only ever looks at which window is active (about 20 quick looks per second, no measurable load) and does nothing on
other systems. It is paused while you deliberately open the alert-browser set-up window."""
import os, time, threading

VERSION = "v106"

MARKERS = ("--rk-store=", "playwright_chromiumdev_profile", "browser_profile")   # how our own browsers are recognised
LOOK_EVERY = 0.05          # seconds between looks at the active window
GIVE_UP_AFTER = 20         # tries to hand the focus back before leaving it alone for a moment

_suspended = False
_started = False
_lock = threading.Lock()
stats = {"restored": 0, "failed": 0, "last_at": ""}


def suspend(flag):
    """True while the user is deliberately using one of our windows (the alert-browser set-up)."""
    global _suspended
    _suspended = bool(flag)


class _WinBackend:
    """The few Windows calls needed. Kept apart so the logic can be tested without Windows."""
    def __init__(self):
        import ctypes
        from ctypes import wintypes
        self.u = ctypes.windll.user32
        self.k = ctypes.windll.kernel32
        self.wt = wintypes
        self.u.GetForegroundWindow.restype = wintypes.HWND
        self.u.GetShellWindow.restype = wintypes.HWND
        self.u.IsWindow.argtypes = [wintypes.HWND]
        self.u.IsIconic.argtypes = [wintypes.HWND]
        self.u.SetForegroundWindow.argtypes = [wintypes.HWND]
        self.u.BringWindowToTop.argtypes = [wintypes.HWND]
        self.u.ShowWindow.argtypes = [wintypes.HWND, ctypes.c_int]
        self.u.GetWindowThreadProcessId.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.DWORD)]
        self.u.AttachThreadInput.argtypes = [wintypes.DWORD, wintypes.DWORD, wintypes.BOOL]
        self.ctypes = ctypes

    def foreground(self):
        h = self.u.GetForegroundWindow()
        return int(h) if h else 0

    def pid_of(self, hwnd):
        pid = self.wt.DWORD(0)
        self.u.GetWindowThreadProcessId(hwnd, self.ctypes.byref(pid))
        return int(pid.value)

    def alive(self, hwnd):
        return bool(self.u.IsWindow(hwnd))

    def minimized(self, hwnd):
        return bool(self.u.IsIconic(hwnd))

    def shell(self):
        """The desktop (taskbar shell) window - a harmless place to put the focus."""
        h = self.u.GetShellWindow()
        return int(h) if h else 0

    def restore(self, hwnd):
        """Make hwnd the active window again."""
        u = self.u
        # v59b: NEVER un-minimise anything. (Diagnosed from your report: you minimise a window -> Windows hands the focus to one of
        # Restalker's hidden browsers -> this used to RESTORE the window you had just minimised, so every window popped back up.)
        cur = self.k.GetCurrentThreadId()
        fg = u.GetForegroundWindow()
        fg_thread = u.GetWindowThreadProcessId(fg, None) if fg else 0
        attached = False
        try:
            if fg_thread and fg_thread != cur:
                attached = bool(u.AttachThreadInput(cur, fg_thread, True))
            u.BringWindowToTop(hwnd)
            ok = bool(u.SetForegroundWindow(hwnd))
        finally:
            if attached:
                u.AttachThreadInput(cur, fg_thread, False)
        return ok


def bring_forward(root_pid, wait=6.0, sleep=time.sleep):
    """v65: the sign-in / store-link window of the buying browser comes to the FRONT, on screen.
    Your report: the Target sign-in window "never opens" and store links "do not open". Windows does not let a program in the background
    put a new window in front (it only flashes in the taskbar), and the buying browser's other window is parked off-screen. This finds
    the browser's window that is NOT parked (the one just opened), moves it onto the screen if needed, and makes it the active window.
    Windows only; elsewhere nothing to do. -> True when a window was brought forward."""
    if os.name != "nt" or not root_pid:
        return False
    try:
        import ctypes
        from ctypes import wintypes
        import psutil
        u = ctypes.windll.user32
        k = ctypes.windll.kernel32
        try:
            pids = {root_pid} | {c.pid for c in psutil.Process(root_pid).children(recursive=True)}
        except Exception:
            pids = {root_pid}
        EnumProc = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
        u.GetWindowThreadProcessId.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.DWORD)]
        u.IsWindowVisible.argtypes = [wintypes.HWND]
        u.GetWindowRect.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.RECT)]
        u.GetWindowTextLengthW.argtypes = [wintypes.HWND]
        u.GetForegroundWindow.restype = wintypes.HWND
        u.SetWindowPos.argtypes = [wintypes.HWND, wintypes.HWND, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int, wintypes.UINT]
        u.ShowWindow.argtypes = [wintypes.HWND, ctypes.c_int]
        u.IsIconic.argtypes = [wintypes.HWND]
        u.SetForegroundWindow.argtypes = [wintypes.HWND]
        u.BringWindowToTop.argtypes = [wintypes.HWND]
        u.AttachThreadInput.argtypes = [wintypes.DWORD, wintypes.DWORD, wintypes.BOOL]
        end = time.time() + wait
        while time.time() < end:
            found = []

            def cb(h, _l):
                pid = wintypes.DWORD(0)
                u.GetWindowThreadProcessId(h, ctypes.byref(pid))
                if pid.value in pids and u.IsWindowVisible(h) and u.GetWindowTextLengthW(h) > 0:
                    r = wintypes.RECT()
                    u.GetWindowRect(h, ctypes.byref(r))
                    found.append((h, r.left, r.top, r.right - r.left, r.bottom - r.top))
                return True
            u.EnumWindows(EnumProc(cb), 0)
            # the window just opened is the one that is not parked far off-screen (the parked one sits at -32000)
            cand = [f for f in found if f[1] > -10000 and f[2] > -10000 and f[3] > 200 and f[4] > 200]
            if cand:
                h, x, y, w, ht = cand[-1]
                if u.IsIconic(h):
                    u.ShowWindow(h, 9)                       # SW_RESTORE
                sw, sh = u.GetSystemMetrics(0), u.GetSystemMetrics(1)
                if x < 0 or y < 0 or x > sw - 100 or y > sh - 100:
                    u.SetWindowPos(h, None, 120, 60, 0, 0, 0x0001 | 0x0004)        # onto the screen (keep size, keep order)
                u.SetWindowPos(h, wintypes.HWND(-1), 0, 0, 0, 0, 0x0001 | 0x0002)   # on top of everything for a moment ...
                u.SetWindowPos(h, wintypes.HWND(-2), 0, 0, 0, 0, 0x0001 | 0x0002)   # ... then a normal window again
                cur = k.GetCurrentThreadId()
                fg = u.GetForegroundWindow()
                fg_thread = u.GetWindowThreadProcessId(fg, None) if fg else 0
                attached = False
                try:
                    if fg_thread and fg_thread != cur:
                        attached = bool(u.AttachThreadInput(cur, fg_thread, True))
                    u.BringWindowToTop(h)
                    u.SetForegroundWindow(h)
                finally:
                    if attached:
                        u.AttachThreadInput(cur, fg_thread, False)
                return True
            sleep(0.25)
    except Exception:
        return False
    return False


BROWSER_EXES = ("chrome", "msedge", "firefox", "camoufox", "chromium", "headless_shell")
CACHE_FOR = 30.0           # seconds an answer is kept


def _is_ours(pid, cache):
    """Is this process one of the program's own browsers?
    v90: the answer is remembered with the process's START TIME and only for CACHE_FOR seconds. (Before, it was remembered by its number
    alone, for good: Windows gives the number of a closed process to a new one, so once one of the program's many browsers had closed,
    a window you opened later - an Explorer folder window, say - could be taken for one of ours, and the focus was handed away from it
    again and again: it seemed never to open.) And only a browser program can be ours - never Explorer or anything else."""
    try:
        import psutil
        p = psutil.Process(pid)
        born = p.create_time()
    except Exception:
        return False
    now = time.time()
    hit = cache.get(pid)
    if hit and hit[0] == born and now - hit[2] < CACHE_FOR:
        return hit[1]
    ours = False
    try:
        name = (p.name() or "").lower()
        if any(b in name for b in BROWSER_EXES):
            cl = " ".join(p.cmdline() or [])
            ours = any(m in cl for m in MARKERS)
    except Exception:
        ours = False
    if len(cache) > 400:
        cache.clear()
    cache[pid] = (born, ours, now)
    return ours


def run_loop(backend, stop=None, is_ours=None, sleep=time.sleep, max_loops=None):
    """The watcher. Remembers the last active window that was not ours; if one of ours becomes active, puts that one back."""
    cache = {}
    is_ours = is_ours or (lambda pid: _is_ours(pid, cache))
    my_pid = os.getpid()
    last_good = 0
    tries = 0
    loops = 0
    while not (stop and stop.is_set()):
        loops += 1
        if max_loops is not None and loops > max_loops:
            return
        try:
            fg = backend.foreground()
            if fg:
                pid = backend.pid_of(fg)
                if pid and is_ours(pid) and pid != my_pid:
                    if (not _suspended) and last_good and backend.alive(last_good) and tries < GIVE_UP_AFTER:
                        target = last_good
                        if getattr(backend, "minimized", None) and backend.minimized(last_good):
                            # you minimised that window on purpose: leave it down; the focus goes to the desktop instead
                            target = backend.shell() if getattr(backend, "shell", None) else 0
                            if not target:
                                tries = GIVE_UP_AFTER
                                continue
                        ok = backend.restore(target)
                        tries += 1
                        stats["restored" if ok else "failed"] += 1
                        stats["last_at"] = time.strftime("%H:%M:%S")
                else:
                    tries = 0
                    if pid:
                        last_good = fg
        except Exception:
            pass
        sleep(LOOK_EVERY)


def start():
    """Start the watcher once (Windows only; safe to call again)."""
    global _started
    with _lock:
        if _started or os.name != "nt":
            return False
        try:
            backend = _WinBackend()
        except Exception:
            return False
        _started = True
    threading.Thread(target=run_loop, args=(backend,), daemon=True, name="focus-guard").start()
    return True
