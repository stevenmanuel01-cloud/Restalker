/* Restalker v68 - checkout at Target, Walmart and GameStop: the SAME deciding part as Best Buy's (bb_engine.js - generated from it, with
 * each store's addresses), so every money and safety rule is identical: exact product, quantity 1, only that product in the cart,
 * item price <= cap, tax <= 12 % of item + shipping (v78), extra fees <= $3, shipping over $20 asks you, card security code typed by you per order
 * (never stored), Place Order latched (never pressed twice), one of a product across ALL stores, human / identity checks never answered.
 * The page part is store_content.js. A practice run walks the real site and stops before Place Order.
 */
'use strict';
function makeStoreEngine(S) {
  const K = key => S.prefix + key;
  const G = S.prefix + 'g';
  const CART = S.cart;
  const ORDERS = S.orders;
  const CONFIRM_WAIT_MS = 90000, APPROVAL_WAIT_MS = 600000, QUEUE_WAIT_MS = 1800000;
  const SHIP_MAX = 20, TAX_SHARE = 0.12, FEES_MAX = 3;      // v78: tax <= 12 % of item + shipping (diagnostics 65: GameStop taxes the shipping too - $2.11 on $16.99 + $7.99 was stopped)
  const FAIL_WINDOW_MS = 600000, FAIL_MAX = 10;      // v70b: the same as Restalker's lock (5 in a row) - never gives up earlier
  let diag = () => {};
  const secrets = {};                 // security codes typed in Restalker for ONE checkout: memory only, never stored, never logged
  const waiters = {};                 // key -> resolve() for "you answered" (security code / shipping approval)
  // v93/v94: key -> until when the store's add-to-cart link is skipped (it added another seller's offer) - kept in storage (survives a restart)
  const LO = 'rkLinkOther:' + S.store;          // (not under the product records' prefix - nothing that lists products sees it)
  async function linkOtherOn(key) { try { const v = (await chrome.storage.local.get(LO))[LO] || {}; return Number(v[key] || 0) > Date.now(); } catch { return false; } }
  async function linkOtherSet(key, until) { try { const v = (await chrome.storage.local.get(LO))[LO] || {}; v[key] = until; await chrome.storage.local.set({[LO]: v}); } catch {} }
  let running = null;                 // key of the checkout that owns the Best Buy tab
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  async function st(key) { return (await chrome.storage.local.get(K(key)))[K(key)] || null; }
  async function setp(key, patch) { const s = (await st(key)) || {key}; const n = {...s, ...patch, key}; await chrome.storage.local.set({[K(key)]: n}); return n; }
  async function g() { return (await chrome.storage.local.get(G))[G] || {}; }
  async function setg(patch) { const x = await g(); await chrome.storage.local.set({[G]: {...x, ...patch}}); }
  async function all() {                // (v75: from memory - never the whole storage)
    if (globalThis.RestalkerRecs) return globalThis.RestalkerRecs.byPrefix(S.prefix);
    const a = await chrome.storage.local.get(null);
    return Object.entries(a).filter(([k]) => k.startsWith(S.prefix)).map(([, v]) => v);
  }
  // ---- the one Best Buy tab
  async function tab() {
    const x = await g();
    let id = null;
    if (Number.isInteger(x.tab)) { try { const t = await chrome.tabs.get(x.tab); if (t && t.id) id = t.id; } catch {} }
    if (id === null) { const t = await chrome.tabs.create({url: 'about:blank', active: false}); id = t.id; await setg({tab: id}); }
    await onScreen(id);
    return id;
  }
  // v68 (diagnostics 62: every Walmart "Add to cart" press did nothing; on the real walmart.com the same press works at once in a tab
  // that is shown): the checkout tab is made the ACTIVE tab of its window, and that window is never a minimised one - a background tab
  // is not drawn, and modern store pages may not answer their buttons until they are drawn. The window stays parked off-screen, and
  // it is not focused (it never comes in front of your windows).
  async function onScreen(id) {
    try {                              // v75: in this store's OWN window - another store's checkout at the same moment never hides it
      if (globalThis.RestalkerWindows && globalThis.RestalkerWindows.checkoutWindow) { await globalThis.RestalkerWindows.checkoutWindow(S.store, id); return; }
    } catch {}
    try {
      let t = await chrome.tabs.get(id);
      let w = await chrome.windows.get(t.windowId);
      if (w.state === 'minimized' || w.id === globalThis.__rkSigninWin) {
        const all = await chrome.windows.getAll({windowTypes: ['normal']});
        let to = all.find(v => v.id !== globalThis.__rkSigninWin && v.state !== 'minimized' && ((v.left || 0) < -5000 || (v.top || 0) < -5000));
        if (!to) {
          // (rare: the parked window is gone) a new one, not focused; Chrome may refuse an off-screen place - then it is made where
          // Chrome puts it, still never focused
          try { to = await chrome.windows.create({focused: false, state: 'normal', left: -32000, top: -32000, width: 1280, height: 900}); }
          catch { to = await chrome.windows.create({focused: false, state: 'normal'}); }
        }
        await chrome.tabs.move(id, {windowId: to.id, index: -1});
      }
      await chrome.tabs.update(id, {active: true});
    } catch {}
  }
  // A page counts as "arrived" only after it really STARTED loading after we asked (status 'loading'), then finished, and its address
  // fits. (v56 test finding: the page we were leaving is already 'complete' and was taken for the new one.)
  function waitLoad(id, pred, ms = 30000, kick = null) {
    return new Promise(res => {
      let done = false, started = false;
      const fin = v => { if (done) return; done = true; clearTimeout(to); chrome.tabs.onUpdated.removeListener(fn); res(v); };
      const fn = (i, ch, t) => {
        if (i !== id) return;
        if (ch.status === 'loading' || ch.url) started = true;
        if (started && t.status === 'complete' && (!pred || pred(t.url || ''))) fin(t.url);
      };
      const to = setTimeout(() => fin(null), ms);
      chrome.tabs.onUpdated.addListener(fn);
      if (kick) Promise.resolve().then(kick).catch(() => fin(null));
    });
  }
  const blockedUrl = u => { try { return /^\/(blocked|captcha|challenge)/i.test(new URL(u).pathname); } catch { return false; } };
  const TW_SKIP = new Set(['the', 'and', 'for', 'with', 'new', 'pack', 'black', 'white', 'size', 'count']);
  const titleWords = t => [...new Set(String(t || '').toLowerCase().replace(/[™®©]/g, '').match(/[a-z0-9]{3,}/g) || [])].filter(w => !TW_SKIP.has(w)).slice(0, 4);
  // v75: like waitLoad, but gives up after startMs when the page does not even START to move (a Buy now that does nothing costs
  // 3 s, not 8) - once it moves, it waits up to ms for a page that fits
  // v75 (your rule: checkout is the top priority): the product page is used as soon as it is THERE - not after every picture and
  // advert on it finished loading (a few seconds on bestbuy.com). The page part answers once the page's content is in.
  // v75: the store's cart is used by one browser at a time (see RestalkerShops.cartLock); this browser waits ready until it is free
  // v87 (owner 2026-11-01: "ALL browser sources are intended to attempt checkout SIMULTANEOUSLY, not sequentially"): the account has ONE
  // cart per store, so ONE browser adds the item - but the others no longer wait for it to finish: the moment the item is in that shared
  // cart they go to the checkout too (they add and remove nothing). The first to reach Place order presses; the others press at once if
  // that one does not go through (the latch below keeps it to ONE order). -> 'mine' (this browser adds) or 'shadow'.
  async function takeCart(key, step, id, want) {
    const RS = globalThis.RestalkerShops;
    if (!RS || !RS.cartLock) return 'mine';
    let told = false, lastLook = 0;
    const t0 = Date.now();
    for (;;) {
      const v = RS.verdictFor ? RS.verdictFor(S.store, key, t0 - 2000, 'this browser:' + key) : null;      // (v78)
      if (v) throw new Stop(v.kind === 'needyou' ? 'fees' : v.kind, 'another browser (' + v.owner.split(':')[0] + ') just found: ' + v.reason);
      const h = RS.cartLock(S.store, 'this browser:' + key);
      if (!h) { if (told) await step('the cart is free now - going on (' + ((Date.now() - t0) / 1000).toFixed(1) + ' s)'); return 'mine'; }
      if (id && want && Date.now() - t0 >= 2000 && Date.now() - lastLook >= 1500) {
        lastLook = Date.now();
        try {
          if (!onCart(await urlOf(id))) await go(id, CART, u => onCart(u), 8000);
          const c = await ask(id, {bb: 'cart', want}, 6000);
          if (c && c.check) throw new Stop('check', c.check);
          const tg = c && c.target;
          if (tg && c.count === 1 && (!tg.qty || tg.qty === 1)) { try { RS.shadowNote && RS.shadowNote(S.store, 'this browser:' + key); } catch {} await step('the item is in the shared cart - going to the checkout at the same time as ' + String(h).split(':')[0]); return 'shadow'; }
        } catch (e) { if (e instanceof Stop) throw e; }
      }
      if (!told) { told = true; await step('ready - another browser (' + String(h).split(':')[0] + ') is using the ' + S.name + ' cart; going on the moment it is free'); }
      if (Date.now() - t0 > 12 * 60 * 1000) throw new Stop('page', 'the cart stayed busy');
      await sleep(150);
      const me = await st(key), gx = await g();
      // (v75: while another browser is pressing Place order for this link - "submitting" - this one keeps waiting: if that order does not go
      //  through, this browser goes on at once; bought or maybe bought -> it stops)
      if (me && me.submissionPending && !me.purchased) continue;
      if (!me || !me.armed || me.purchased || me.attempted || gx.emergencyStop || gx.live === false) throw new Stop(me && (me.purchased || me.attempted) ? 'other' : 'cancelled', me && (me.purchased || me.attempted) ? 'it was ordered by another browser' : 'auto-buy was switched off during the checkout');
    }
  }
  async function goFast(id, url, ms = 20000) {
    let started = false;
    const fn = (i, ch) => { if (i === id && (ch.status === 'loading' || ch.url)) started = true; };
    chrome.tabs.onUpdated.addListener(fn);
    try {
      await chrome.tabs.update(id, {url});
      const end = Date.now() + ms;
      while (Date.now() < end) {
        await sleep(100);
        let t = null; try { t = await chrome.tabs.get(id); } catch { return null; }
        if (started && !t.pendingUrl && String(t.url || '').startsWith(S.origin)) return t.url;
      }
      return null;
    } catch (e) { diag('bb_nav_error', {url: String(url).replace(/\?.*/, ''), error: String(e && e.message || e)}); return null; }
    finally { chrome.tabs.onUpdated.removeListener(fn); }
  }
  async function waitNav(id, pred, startMs, ms, kick, failed) {
    const u00 = await urlOf(id);
    const p = waitLoad(id, pred, ms, kick);
    const t0 = Date.now();
    let moving = false;
    const watch = (async () => {
      while (Date.now() - t0 < startMs) {
        await sleep(200);
        if (failed && failed()) return 'failed';            // (v75: the press itself said no - nothing to wait for)
        // (v75: only a NEW address counts as moving - a store page keeps "loading" small parts all the time; diagnostics 64 waited 15 s)
        try { const t = await chrome.tabs.get(id); if ((t.url || '') !== u00 || (t.pendingUrl && t.pendingUrl !== u00)) { moving = true; return 'moving'; } } catch { return 'gone'; }
      }
      return 'still';
    })();
    const first = await Promise.race([p.then(v => ({v})), watch.then(w => ({w}))]);
    if (first.v !== undefined) return first.v;
    if ((first.w === 'still' || first.w === 'failed') && !moving) return null;
    return await p;
  }
  async function go(id, url, pred, ms) {
    const want = pred || (u => u.startsWith(S.origin));
    // (v75: a store's 'prove you are a person' page counts as arrived - it is then reported to you, never waited on for 30 s)
    return waitLoad(id, u => want(u) || blockedUrl(u), ms, () => chrome.tabs.update(id, {url}).catch(e => { diag('bb_nav_error', {url: String(url).replace(/\?.*/, ''), error: String(e && e.message || e)}); throw e; }));
  }
  const CONTENT_FILE = 'store_content.js';
  async function inject(id) {
    // v62: the page part is put into the page by the engine itself when it is not there (instead of waiting for the browser to do it)
    try { await chrome.scripting.executeScript({target: {tabId: id}, files: [CONTENT_FILE]}); return null; }
    catch (e) { return String(e && e.message || e); }
  }
  // v68: requests that PRESS something are delivered at most once. Real walmart.com moves to its "Added to cart" page right after the
  // press; the old code then sent "press Add to Cart" again to that page (where the first "Add to cart" is another product's).
  const ONCE = new Set(['add', 'place', 'tocheckout', 'advance', 'cvv', 'cvvsubmit', 'qty1', 'remove', 'ship', 'dismiss', 'searchadd', 'buynow']);
  async function ask(id, msg, ms = 20000) {
    const end = Date.now() + ms, t0 = Date.now();
    let last = null, injected = false, injErr = null;
    const once = ONCE.has(msg && msg.bb);
    if (once || (msg && msg.ship)) await onScreen(id);          // (v75: the product page is DRAWN before Shipping is chosen on it)
    while (Date.now() < end) {
      try {
        const r = await Promise.race([chrome.tabs.sendMessage(id, msg), sleep(Math.max(1000, end - Date.now())).then(() => ({ok: false, error: 'the page did not answer in time', timeout: true}))]);
        if (r) return r;
      } catch (e) {
        last = String(e && e.message || e);
        // delivered, but the page went away before it answered (the store moved to another page): never sent again
        if (once && !/receiving end does not exist|could not establish connection|no tab with id/i.test(last)) return {ok: false, error: last, lost: true};
      }
      if (!injected && Date.now() - t0 > 1500) {          // (no answer at all: the page part is missing - it is added now)
        injected = true;
        const why = await inject(id);
        if (why) injErr = 'the page part could not be added: ' + why + ' (page: ' + (await urlOf(id)).replace(/\?.*/, '').slice(0, 90) + ')';
      }
      await sleep(250);
    }
    return {ok: false, error: (injErr || last || 'the page did not answer')};
  }
  async function settle(id) { await waitLoad(id, null, 3000); await sleep(300); }
  async function urlOf(id) { try { return (await chrome.tabs.get(id)).url || ''; } catch { return ''; } }
  const isCheckout = u => S.isCheckout(u);
  // v75: "on the cart page" is read from the page's PATH - Walmart's checkout address carries "?cartId=..." and was taken for the cart
  // (so an item was never taken out of the cart again after a stop on the checkout page)
  const onCart = u => { try { const x = new URL(u); return /cart/i.test(x.pathname) && !isCheckout(u); } catch { return false; } };
  const isSignin = u => S.isSignin(u);
  // ---- one checkout
  class Stop extends Error { constructor(kind, msg, extra) { super(msg); this.kind = kind; this.extra = extra || {}; } }
  async function campaign(key, {dryRun = false, reason = 'restock'} = {}) {
    if (running && running !== key) return {ok: false, busy: true, reason: 'another ' + S.name + ' checkout is running'};
    if (running === key) return {ok: true, already: true};
    running = key;                      // (v70c: taken AT ONCE - two restock signals in the same moment once ran two checkouts = two orders)
    let p;
    try {
      p = await st(key);
      if (!p) { running = null; return {ok: false, reason: 'unknown ' + S.name + ' product'}; }
      if (!dryRun) {
        const x = await g();
        if (!p.armed || p.purchased || p.attempted || p.inProgress || p.submissionPending || x.emergencyStop || x.live === false) { running = null; return {ok: false, reason: 'not armed'}; }
      }
    } catch (e) { running = null; throw e; }
    const steps = [];
    const t0 = Date.now();
    const step = async (name, extra) => { steps.push({name, ms: Date.now() - t0, ...(extra || {})}); diag('bb_step', {key, dryRun, step: name, ms: Date.now() - t0, ...(extra || {})});
      if (!dryRun) await setp(key, {step: name, status: 'CHECKOUT — ' + name}); };
    const want = {sku: p.sku || null, tokens: p.tokens || [], forbid: p.forbid || [], name: p.name};
    const forbidden = title => (p.forbid || []).find(w => String(title || '').toLowerCase().includes(String(w).toLowerCase()));
    let latched = false, id = null;
    try {
      if (!dryRun) await setp(key, {inProgress: true, hitAt: Date.now(), campaignStartedAt: Date.now(), approval: null, needCvv: false, step: 'opening the product page', status: 'CHECKOUT — STARTING'});
      id = await tab();
      // 1) product page
      let addedVia = 'product page', fastAdd = false, viaBuyNow = false, c = null, shadowCart = false;
      if (p.mode === 'search') {
        if (!dryRun) await takeCart(key, step);
        await step('search page');
        if (!await go(id, p.url)) throw new Stop('page', 'the search page did not load');
        const r = await ask(id, {bb: 'searchadd'}, 20000);
        if (!r.ok) throw new Stop('page', 'search page: ' + (r.error || 'no item could be added'));
        want.tokens = []; want.sku = null; want.title = r.title; want.href = r.href; addedVia = 'search results (' + r.title + ')';
        await step('added to cart', {title: r.title});
      } else if (S.addLink && S.skuOf && !dryRun && (want.sku || S.skuOf(p.url)) && !(await linkOtherOn(key))) {
        // v68b: FAST - straight into the cart with the store's own add-to-cart link (no product page); the cart then checks the exact
        // item (its number and its name), the price and the quantity before anything is ordered
        want.sku = want.sku || S.skuOf(p.url);
        if (await takeCart(key, step, id, want) !== 'shadow') {
          fastAdd = true;
          await step('adding to the cart (' + S.name + '\'s own add-to-cart link)');
          if (!await go(id, S.addLink(want.sku), u => onCart(u) && !/addToCart/i.test(u), 8000)) await go(id, CART, u => onCart(u), 12000);
        } else { addedVia = 'the shared cart (another browser added it)'; shadowCart = true; }
      } else {
        await step('opening the product page');
        if (!await goFast(id, p.url)) throw new Stop('page', 'the product page did not load');
        let info = await ask(id, {bb: 'pdp', want, ship: !dryRun}, 25000);
        if (!info.ok && /error page/i.test(String(info.error || ''))) {
          // v65: the browser's own error page (the store did not answer the page load) - loaded once more before giving up
          await step('product page did not load - loading it again');
          await sleep(1500);
          if (!await go(id, p.url)) throw new Stop('page', 'the product page did not load');
          info = await ask(id, {bb: 'pdp', want, ship: !dryRun}, 25000);
        }
        if (info.check) throw new Stop('check', info.check);
        if (!info.ok) throw new Stop('page', 'product page: ' + (info.error || 'unreadable'));
        await step('product page read', {title: (info.title || '').slice(0, 80), sku: info.sku, price: info.price, button: info.button});
        if (p.sku && info.sku && String(info.sku) !== String(p.sku) && !(p.skuAlt || []).includes(String(info.sku))) {
          // Best Buy moved products to new 8-digit numbers: the PAGE's own number is learned the first time its title matches the product
          const toks = (p.tokens || []).map(x => x.toLowerCase());
          if (p.trusted || (toks.length && toks.every(k => k.split('|').some(x => (info.title || '').toLowerCase().includes(x))))) { await setp(key, {skuAlt: [...(p.skuAlt || []), String(info.sku)]}); want.sku = String(info.sku); }
          else throw new Stop('identity', `this page is product ${info.sku}, not ${p.sku}`);
        }
        if (!p.sku && info.sku) { await setp(key, {sku: String(info.sku)}); want.sku = String(info.sku); }
        if (info.sku) want.sku = String(info.sku);
        // v75 (your rule): a link YOU gave is the right product - its page is not checked against the row's name. The cart and the
        // checkout then recognise the item by the page's own item number and the words of the page's own product name.
        if (p.trusted && !(p.tokens || []).length && info.title) want.tokens = titleWords(info.title);
        if (info.skuAlt && info.skuAlt.length) want.skuAlt = info.skuAlt;          // (GameStop: the cart uses another number for the same item)
        const toks = (p.tokens || []).map(x => x.toLowerCase());
        if (toks.length && !toks.every(k => k.split('|').some(x => (info.title || '').toLowerCase().includes(x)))) throw new Stop('identity', 'the page title does not match the product: ' + (info.title || '?').slice(0, 80));
        if (forbidden(info.title)) throw new Stop('identity', 'the page is a different kind of product ("' + forbidden(info.title) + '"): ' + (info.title || '?').slice(0, 80));
        if (info.soldOut) throw new Stop('soldout', S.name + ' shows "' + info.button + '"');
        if (!dryRun && info.price != null && info.price > p.cap + 0.001) throw new Stop('overcap', `price $${info.price.toFixed(2)} is over the cap $${p.cap.toFixed(2)}`);
        if (info.shipTile) await step('Shipping chosen (not store pickup)');
        let skipAdd = false;
        if (!dryRun && await takeCart(key, step, id, want) === 'shadow') { skipAdd = true; addedVia = 'the shared cart (another browser added it)'; shadowCart = true; }
        // v75 (your rule): "Buy now" goes straight to the checkout (no cart step) - used when the product's own box has it
        // v78b (diagnostics 66): Target's "Buy now" opens its own pop-up on the product page (no checkout page) - every try lost 3 s on it, so
        // Target goes straight to Add to cart
        if (info.buyNow && !dryRun && !skipAdd && !info.queue && !info.inCart && S.store !== 'target') {
          await step('pressing Buy now (straight to the checkout)');
          await onScreen(id);
          let bn = null;
          const u0 = await waitNav(id, u => isCheckout(u) || isSignin(u) || onCart(u) || blockedUrl(u), 3000, 15000, async () => { bn = await ask(id, {bb: 'buynow'}, 8000); }, () => !!(bn && !bn.ok));
          if (bn && bn.check) throw new Stop('check', bn.check);
          if (u0 && isSignin(u0)) throw new Stop('signin', S.name + ' wants you to sign in again before checking out');
          if (u0 && isCheckout(u0)) { viaBuyNow = true; addedVia = 'Buy now'; }
          else if (u0 && onCart(u0)) { skipAdd = true; addedVia = 'Buy now (it opened the cart)'; await step('Buy now opened the cart'); }
          else if (u0 && blockedUrl(u0)) throw new Stop('check', S.name + ' shows a human / security check');
          else await step('Buy now did not open the checkout - using Add to cart' + (bn && bn.error ? ' (' + bn.error + ')' : ''));
        }
        if (viaBuyNow || skipAdd) {
          // (nothing more on the product page)
        } else if (info.inCart && !info.inStock) {
          // v67: already in the cart (left there by an earlier try): not added again - the cart page decides (quantity set to 1 there)
          await step('already in the cart');
        } else {
          if (!info.inStock && !info.queue) throw new Stop('soldout', 'no Add to Cart button (' + (info.button || 'none') + ')');
          await step(info.queue ? 'in ' + S.name + '\'s queue (Please Wait)' : 'pressing Add to Cart', {vis: info.vis || null});
          await onScreen(id);
          const a = await ask(id, {bb: 'add', maxQueueMs: 20000}, 50000);      // v88: Target / Walmart / GameStop have no waiting line - a button that stays greyed out was waited for 30 min
          if (a.check) throw new Stop('check', a.check);
          if (a.soldOut) throw new Stop('soldout', 'sold out while adding to the cart');
          if (a.lost) {
            // the store moved on right after the press (real Walmart: its "Added to cart" page /pac?id=<item>)
            await waitLoad(id, null, 6000);
            const u = await urlOf(id);
            await step('added to cart', {how: S.addedUrl && S.addedUrl(u, want.sku) ? S.name + '\'s "added to cart" page' : 'the page changed - the cart decides'});
          } else if (!a.ok) {
            if (!S.addLink || !/did not answer|in time|no confirmation/i.test(String(a.error || ''))) throw new Stop('page', 'Add to Cart: ' + (a.error || 'no confirmation'));
            await step('Add to Cart did not answer - the cart decides', {error: a.error || null});
          } else await step('added to cart', {queued: !!a.queued, how: a.how || null, vis: a.vis || null});
        }
      }
      if (!viaBuyNow) {
      // 2) cart
      if (!fastAdd || !onCart(await urlOf(id))) {
        await step('cart');
        if (!await go(id, CART, u => onCart(u))) throw new Stop('page', 'the cart did not load');
      }
      c = await ask(id, {bb: 'cart', want}, 15000);
      // v93/v94 (diagnostics 76: Walmart's add-to-cart link put ANOTHER seller's offer of the product in the cart - Toywiz at $644.88 -
      // while the product page shows the $357.99 offer that was read as the restock): that line is taken out again and the offer on
      // the product page is added instead; this product then skips the link for 7 days (v95). Only for a line of exactly THIS item number,
      // quantity 1, whose price was read (never on a guess), and only by the browser that added it (never from a shared cart).
      const skuOk = i => !!(want.sku && i.sku && (String(i.sku) === String(want.sku) || (want.skuAlt || []).map(String).includes(String(i.sku))));
      const overLine = i => i && i.mine && skuOk(i) && i.price != null && i.price > p.cap + 0.001 && (!i.qty || i.qty === 1);
      const firstOver = (c.target && overLine(c.target)) ? c.target : (c.items || []).find(overLine);
      if (fastAdd && !shadowCart && !c.check && firstOver) {
        await step('the add-to-cart link chose another seller ($' + Number(firstOver.price).toFixed(2) + ', over the cap) - taking the product page\'s offer instead');
        await linkOtherSet(key, Date.now() + 7 * 24 * 3600 * 1000);   // (v95: 7 days - diagnostics 76-77: the link chose the other seller every time)
        const rr = await ask(id, {bb: 'removeover', want, cap: -1}, 25000);
        if (!rr || !rr.ok) throw new Stop('page', 'the other seller\'s line could not be taken out of the cart (' + ((rr && (rr.reason || rr.error)) || 'no answer') + ')');
        await settle(id);
        c = await ask(id, {bb: 'cart', want}, 10000);
        if ((c.items || []).some(i => i.mine)) throw new Stop('page', 'the other seller\'s line is still in the cart');
        c.target = null;
      }
      if (fastAdd && !c.target && !c.check) {
        await step('not in the cart after the link - using the product page');
        // v93: two tries on the product page (the cart is read between them, so a second press never puts a second one in): a page
        // that is still being drawn may not answer its first press
        for (let tr = 0; tr < 2; tr++) {
          await go(id, p.url);
          const info = await ask(id, {bb: 'pdp', want, ship: true}, 25000);
          if (info.check) throw new Stop('check', info.check);
          // v94 (review): the same identity checks as the product page path (not another kind of product, the same item number)
          if (info.title && forbidden(info.title)) throw new Stop('identity', 'the product page is a different kind of product: ' + String(info.title).slice(0, 80));
          if (want.sku && info.sku && String(info.sku) !== String(want.sku) && !(want.skuAlt || []).map(String).includes(String(info.sku))) throw new Stop('identity', 'the product page shows another item number');
          if (info.soldOut || (!info.inStock && !info.inCart)) throw new Stop('soldout', S.name + ' shows "' + (info.button || 'no Add to cart') + '"');
          if (info.price != null && info.price > p.cap + 0.001) throw new Stop('overcap', `price $${info.price.toFixed(2)} is over the cap $${p.cap.toFixed(2)}`);
          if (!info.inCart) { await onScreen(id); await settle(id); if (tr) await sleep(1000);
            const a = await ask(id, {bb: 'add', maxQueueMs: 0}, 30000);
            if (a.check) throw new Stop('check', a.check); if (a.soldOut) throw new Stop('soldout', 'sold out while adding to the cart'); if (a.lost) await sleep(1500); }
          if (!onCart(await urlOf(id))) await go(id, CART, u => onCart(u));
          c = await ask(id, {bb: 'cart', want}, 15000);
          if (c.check || c.target || (c.items || []).some(x => x.mine)) break;
          if (tr === 0) await step('the product page\'s first press did not put it in the cart - once more');
        }
        addedVia = 'product page (after the link)';
      }
      if (c.check) throw new Stop('check', c.check);
      if (p.mode === 'search' && !c.target && c.items) { const mine = c.items.filter(i => want.title && i.title && want.title.toLowerCase().startsWith(i.title.toLowerCase().slice(0, 30))); if (mine.length === 1) { want.tokens = [mine[0].title.toLowerCase().slice(0, 30)]; c = await ask(id, {bb: 'cart', want}, 8000); } }
      await step('cart read', {items: c.count, target: c.target, subtotal: c.subtotal});
      const cartRead = !!(c && c.ok && c.page === 'cart' && Number.isInteger(c.count) && onCart(await urlOf(id)));
      const anyMine = (c.items || []).some(i => i.mine || (want.sku && String(i.sku) === String(want.sku)));
      if (!fastAdd && !c.target && !c.check && S.addLink && want.sku && p.mode !== 'search' && cartRead && !anyMine) {
        // v68: the store's OWN add-to-cart link (real walmart.com, tested: /sc/cart/addToCart?items=<item> adds it and opens the cart).
        // Used only when the cart was just read WITHOUT this product, so it can never put a second one in.
        await step('not in the cart - using ' + S.name + '\'s own add-to-cart link');
        if (!await go(id, S.addLink(want.sku), u => onCart(u) && !/addToCart/i.test(u), 30000)) {
          if (!onCart(await urlOf(id))) await go(id, CART, u => onCart(u));
        }
        c = await ask(id, {bb: 'cart', want}, 15000);
        if (c.check) throw new Stop('check', c.check);
        await step('cart read', {items: c.count, target: c.target, subtotal: c.subtotal, via: 'add-to-cart link'});
      }
      if (!c.target && !c.check && !shadowCart && (c.items || []).filter(i => i.mine).length > 1) {
        // v93/v94: the product is in the cart once per seller (Walmart): the lines over the cap go, the cheapest within it stays - only
        // when every such line has THIS item number and a price that was read; otherwise it stops (never guesses)
        const mineL = (c.items || []).filter(i => i.mine);
        if (!mineL.every(i => skuOk(i) && i.price != null)) throw new Stop('cart', `the ${S.name} cart has this product ${mineL.length} times and not every line could be read for sure - nothing was ordered`);
        const r = await ask(id, {bb: 'removeover', want, cap: p.cap}, 30000);
        if (!r || !r.ok) throw new Stop('cart', 'the product is in the cart more than once and could not be made one (' + ((r && (r.reason || r.error)) || 'no answer') + ')');
        await step('the product was in the cart from ' + mineL.length + ' sellers - kept the one within the cap', {kept: r.kept, removed: r.removed});
        await settle(id);
        c = await ask(id, {bb: 'cart', want}, 10000);
      }
      if (!c.target) throw new Stop('page', S.addLink ? 'the product did not go into the cart - neither by its Add to cart button nor by ' + S.name + '\'s own add-to-cart link (' + (c.count || 0) + ' item(s) there)' : 'the product is not in the cart (' + (c.count || 0) + ' item(s) there)');
      if (forbidden(c.target.title)) throw new Stop('identity', 'the cart item is a different kind of product: ' + c.target.title);
      { const tk = (p.tokens || []).map(x => x.toLowerCase());
        if (tk.length && !tk.every(k => k.split('|').some(x => String(c.target.title || '').toLowerCase().includes(x)))) throw new Stop('identity', 'the cart item is not this product: ' + c.target.title); }
      if (c.count !== 1) throw new Stop('cart', `the ${S.name} cart has ${c.count} different items - only this product may be in it`);
      if (c.target.qty && c.target.qty !== 1) {
        // v68b: set to 1, then the cart is READ AGAIN to be sure (the store may reload the page while changing it)
        for (let i = 0; i < 3 && c.target && c.target.qty && c.target.qty !== 1; i++) {
          await ask(id, {bb: 'qty1', want}, 12000);
          await settle(id);
          c = await ask(id, {bb: 'cart', want}, 10000);
        }
        if (!c.target || (c.target.qty && c.target.qty !== 1)) throw new Stop('cart', 'the quantity in the cart is ' + (c.target ? c.target.qty : '?') + ', not 1');
        await step('quantity set to 1');
      }
      if (!dryRun && c.target.price != null && c.target.price > p.cap + 0.001) throw new Stop('overcap', `the cart price $${c.target.price.toFixed(2)} is over the cap $${p.cap.toFixed(2)}`);
      const sh = await ask(id, {bb: 'ship', want, allowPickup: !!(await g()).allowPickup}, 10000);
      if (!sh.ok) throw new Stop('cart', sh.error || 'could not choose shipping');
      await step('delivery chosen', {how: sh.how});
      // 3) checkout
      // v78 (diagnostics 65): the Check out button is waited for (Target draws it after the items), and a sign-in pop-up that opens on
      // the SAME page (Target: "Sign in to your account" - passkey / password / code) is seen within about a second, not after 15 s
      let tcErr = null, tcCheck = null, u1 = null;
      const tc = await ask(id, {bb: 'tocheckout'}, 12000);
      if (!tc.ok) { if (tc.check) tcCheck = tc.check; else tcErr = tc.error || 'no Checkout button'; }
      else {
        const endAt = Date.now() + 15000;
        let lastPing = Date.now();
        while (Date.now() < endAt) {
          await sleep(250);
          let t = null; try { t = await chrome.tabs.get(id); } catch { break; }
          const u = String(t.url || '');
          if (t.status === 'complete' && (isCheckout(u) || isSignin(u))) { u1 = u; break; }
          if (t.status === 'complete' && !t.pendingUrl && Date.now() - lastPing > 900) {
            lastPing = Date.now();
            const pz = await ask(id, {bb: 'ping', check: true}, 1500);
            if (pz && pz.ok && pz.check) { tcCheck = pz.check; break; }
          }
        }
      }
      if (tcCheck) throw new Stop(/sign in/i.test(tcCheck) ? 'signin' : 'check', tcCheck);
      if (tcErr) throw new Stop('page', tcErr);
      if (!u1) {
        // v69 (real target.com): Check out may open a SIGN-IN pop-up on the cart page instead of a new page - never answered
        const z = await ask(id, {bb: 'cart', want}, 5000);
        if (z && z.check) throw new Stop(/sign in/i.test(z.check) ? 'signin' : 'check', z.check);
        throw new Stop('page', 'the checkout page did not open');
      }
      if (isSignin(u1)) throw new Stop('signin', S.name + ' wants you to sign in again before checking out');
      }
      await step(viaBuyNow ? 'checkout page (Buy now)' : 'checkout page');
      await onScreen(id);
      const dz = await ask(id, {bb: 'dismiss'}, 15000);
      if (dz && dz.closed && dz.closed.length) await step('offer closed (nothing accepted): ' + dz.closed.join('; '));
      if (dz && dz.unknown && dz.unknown.some(u => u.aboutOrder)) throw new Stop('action', S.name + ' shows a pop-up about the order: "' + dz.unknown.find(u => u.aboutOrder).text + '"');
      let k = await ask(id, {bb: 'checkout', want}, 25000);
      if (k.check) throw new Stop('check', k.check);
      // v67: a "Continue" / "Review order" step before Place order (it places nothing) - pressed, at most 3 times, then read again
      for (let i = 0; i < 4 && k.ok && (!k.place || S.stepsFirst) && !k.check; i++) {      // (GameStop: its "Save & Continue" steps first)
        const adv = await ask(id, {bb: 'advance'}, 15000);
        if (!adv.ok || adv.ready) break;
        await step('checkout step: ' + (adv.pressed || 'continue'));
        await sleep(3000);                       // (the next part of the checkout loads; its page part is put in again if needed)
        k = await ask(id, {bb: 'checkout', want}, 25000);
        if (k.check) throw new Stop('check', k.check);
      }
      if (k.pickup) {                          // v75 (your rule: always shipping): set to store pickup -> switched to shipping, read again
        const sh2 = await ask(id, {bb: 'ship', want, allowPickup: false}, 10000);
        await step('the checkout was set to store pickup - ' + (sh2 && sh2.ok ? 'switched to shipping' : 'shipping could not be chosen'));
        await settle(id);
        k = await ask(id, {bb: 'checkout', want}, 25000);
        if (k.check) throw new Stop('check', k.check);
      }
      if (k.total == null && k.placeAmount != null) k.total = k.placeAmount;
      await step('checkout read', {identity: k.identity, qtyOne: k.qtyOne, base: k.base, tax: k.tax, shipping: k.shipping, total: k.total, fees: k.fees, cvv: k.cvv, place: k.place, placeAmount: k.placeAmount, popups: k.popups, vis: k.vis});
      // v68: the amount on the button you would press ("Place order for $18.68") must be the total that was checked
      if (k.placeAmount != null && k.total != null && Math.abs(k.placeAmount - k.total) > 0.011) throw new Stop('fees', `the Place order button says $${k.placeAmount.toFixed(2)}, but the total read is $${k.total.toFixed(2)}`);
      if (k.problems && k.problems.length) throw new Stop('action', k.problems.join('; '));
      // v67: the checkout may show the item only as a picture. The cart was read a moment ago with ONLY this exact product in it; a
      // checkout that says "1 item" is that cart.
      const cartOnlyMine = !!(c && c.target && c.count === 1) && k.itemsN === 1;
      if (!k.identity && p.mode !== 'search' && !cartOnlyMine) throw new Stop('identity', 'the checkout page does not show this product');
      if (!k.qtyOne) throw new Stop('cart', 'the checkout does not show exactly one item');
      if (k.base == null) throw new Stop('page', 'the item price is not readable on the checkout page');
      if (!dryRun && k.base > p.cap + 0.001) throw new Stop('overcap', `checkout item price $${k.base.toFixed(2)} is over the cap $${p.cap.toFixed(2)}`);
      const capRef = dryRun ? Math.max(p.cap || 0, k.base) : p.cap;
      if (k.tax != null && k.tax > (Math.min(k.base, capRef) + (k.shipping || 0)) * TAX_SHARE + 0.01) throw new Stop('fees', `tax $${k.tax.toFixed(2)} is more than 12 % of item + shipping`);
      if (k.fees != null && k.fees > FEES_MAX) throw new Stop('fees', `extra fees $${k.fees.toFixed(2)}`);
      if (k.total != null && k.tax != null) {
        const sum = k.base + (k.tax || 0) + (k.shipping || 0) + (k.fees || 0);
        if (Math.abs(sum - k.total) > 0.06 && k.total > sum) throw new Stop('fees', `the total $${k.total.toFixed(2)} is more than item + tax + shipping ($${sum.toFixed(2)})`);
      }
      if (!k.place) throw new Stop('page', 'no Place Your Order button on the checkout page');
      // shipping over $20: ask you (dry run only reports it)
      if (!dryRun && (k.shipping || 0) > SHIP_MAX) {
        await setp(key, {approval: {base: k.base, tax: k.tax, shipping: k.shipping, total: k.total, created: Date.now()}, status: `ACTION REQUIRED — SHIPPING $${k.shipping.toFixed(2)}`, step: 'waiting for your shipping approval'});
        const ans = await waitFor(key, APPROVAL_WAIT_MS);
        await setp(key, {approval: null});
        if (ans !== 'approve') throw new Stop('cancelled', ans === 'cancel' ? 'you cancelled (shipping)' : 'shipping approval timed out');
        k = await ask(id, {bb: 'checkout', want}, 15000);
      }
      // the card's security code, if Best Buy asks for it: typed by you in Restalker for this one checkout
      if (k.cvv && !k.cvvFilled) {
        if (dryRun) await step('security code would be asked from you');
        else {
          if (!secrets[key] && globalThis.__rkCardCode) { secrets[key] = globalThis.__rkCardCode; await step('security code typed in by Restalker (your saved code)'); }   // v77: no waiting for you
          if (!secrets[key]) {
            await setp(key, {needCvv: true, status: 'WAITING FOR YOU — ' + S.name + ' asks for the card security code', step: 'waiting for the card security code'});
            const ans = await waitFor(key, APPROVAL_WAIT_MS);
            await setp(key, {needCvv: false});
            if (ans !== 'cvv' || !secrets[key]) throw new Stop('cancelled', ans === 'cancel' ? 'you cancelled' : 'no security code was typed in time');
          }
          const f = await ask(id, {bb: 'cvv', value: secrets[key]}, 8000);
          delete secrets[key];
          if (!f.ok) throw new Stop('page', 'the security code could not be filled in');
          await step('security code filled in');
        }
      }
      if (dryRun) {
        await step('READY TO PLACE THE ORDER - practice run stops here');
        await go(id, CART, u => onCart(u));
        const rm = await ask(id, {bb: 'remove', want}, 15000);
        await step(rm.ok ? 'item taken out of the cart again' : 'could NOT take the item out of the cart - please remove it yourself');
        return {ok: true, dryRun: true, steps, addedVia, removed: !!rm.ok};
      }
      // 4) Place Your Order - latched BEFORE the click: never pressed twice, and an unclear result is never retried by itself
      p = await st(key);
      const x = await g();
      if (!p.armed || p.purchased || p.attempted || x.emergencyStop || x.live === false) throw new Stop('cancelled', 'auto-buy was switched off during the checkout');
      // v60: one of a product - not one per store: never pressed while the same product is being / was ordered at another store
      const RS = globalThis.RestalkerShops;
      // v75 (your rule): every store races to THIS point at the same moment. The first one presses Place order; the others wait here,
      // ready. Bought there -> this one stops (its item leaves the cart again). Not bought there -> this one presses AT ONCE.
      let waited = 0;
      for (;;) {
        const holder = RS ? RS.tryLatch(p.group, S.store, key) : null;      // (taken at once, before anything else can run)
        if (!holder) {                          // (our turn: was it ordered somewhere meanwhile? then never pressed here)
          const other = RS ? await RS.otherOrdered(p, S.store, key) : null;
          if (other) { RS.release(p.group, key); throw new Stop('other', 'it was ordered at ' + other + ' (one per product)'); }
          break;
        }
        if (!waited) { waited = Date.now(); await step('ready - ' + holder + ' is placing the order this moment; pressed here at once if that one does not go through'); }
        if (Date.now() - waited > APPROVAL_WAIT_MS + 120000) throw new Stop('page', 'waited too long for ' + holder);
        await sleep(100);
        const me = await st(key), gx = await g();
        if (me && me.submissionPending && !me.purchased) continue;     // (v75: another browser is pressing Place order for this link right now)
        if (!me || !me.armed || me.purchased || me.attempted || gx.emergencyStop || gx.live === false) throw new Stop('cancelled', 'auto-buy was switched off during the checkout');
      }
      if (waited) {                            // (the checkout page is read again: still this product, still under the cap, the same total)
        const k2 = await ask(id, {bb: 'checkout', want}, 15000);
        const RSr = () => { try { RS.release(p.group, key); } catch {} };
        if (k2.check) { RSr(); throw new Stop('check', k2.check); }
        if (k2.total == null && k2.placeAmount != null) k2.total = k2.placeAmount;
        if (!k2.ok || !k2.place || k2.base == null || k2.base > p.cap + 0.001 || (k.total != null && k2.total != null && k2.total > k.total + 0.011) ||
            (k2.placeAmount != null && k2.total != null && Math.abs(k2.placeAmount - k2.total) > 0.011) || !k2.qtyOne) {
          RSr(); throw new Stop('page', 'the checkout page changed while waiting for the other store');
        }
        await step('checkout read again after waiting ' + ((Date.now() - waited) / 1000).toFixed(1) + ' s', {base: k2.base, total: k2.total});
      }
      latched = true;
      await setp(key, {attempted: true, armed: false, submissionPending: true, submitAt: Date.now(), price: k.base, status: 'SUBMITTING ORDER', step: 'Place Your Order pressed - waiting for ' + S.name + '\'s confirmation'});
      const pl = await ask(id, {bb: 'place'}, 8000);
      if (!pl.ok) { latched = false; await setp(key, {attempted: false, submissionPending: false, armed: true}); throw new Stop('page', pl.error || 'Place Your Order could not be pressed'); }
      diag('bb_place_pressed', {key, ms: Date.now() - t0});
      // 5) confirmation
      let endAt = Date.now() + CONFIRM_WAIT_MS, cvvAfter = false;
      let conf = null;
      while (Date.now() < endAt) {
        await sleep(250);                        // (v75: the answer is seen within a quarter second - a waiting store presses at once)
        const cur = await st(key);
        if (cur && cur.purchased) return {ok: true, order: cur.orderNumber, by: 'order history'};   // Restalker already found it in your orders
        const r = await ask(id, {bb: 'confirm'}, 4000);
        if (!r || !r.ok) continue;
        if (r.failed) { conf = {failed: r.failed}; break; }
        if (r.check) { conf = null; diag('bb_check_after_place', {key, check: r.check}); break; }   // (unclear: checked in your orders)
        if (r.cvv && !cvvAfter && !k.cvv) {
          // v68: the card security code asked AFTER Place order (Walmart may do that): typed by you, sent once. While you are asked, the
          // page is still watched - if the order goes through anyway, that is taken at once
          cvvAfter = true;
          if (!secrets[key] && globalThis.__rkCardCode) { secrets[key] = globalThis.__rkCardCode; await step('security code typed in by Restalker (your saved code)'); }   // v77: no waiting for you
          if (!secrets[key]) {
            await setp(key, {needCvv: true, status: 'WAITING FOR YOU — ' + S.name + ' asks for the card security code', step: 'waiting for the card security code'});
            const ansP = waitFor(key, APPROVAL_WAIT_MS);
            let ans = null, through = null;
            for (;;) {
              ans = await Promise.race([ansP, sleep(2000).then(() => null)]);
              if (ans !== null) break;
              const r2 = await ask(id, {bb: 'confirm'}, 4000);
              if (r2 && r2.ok && r2.placed) { through = r2; break; }
            }
            await setp(key, {needCvv: false});
            if (through) { if (waiters[key]) waiters[key]('placed'); conf = through; break; }
            if (ans !== 'cvv' || !secrets[key]) { conf = null; diag('bb_cvv_after_place_unanswered', {key, ans}); break; }   // (unclear: checked in your orders)
          }
          const f = await ask(id, {bb: 'cvvsubmit', value: secrets[key]}, 10000);
          delete secrets[key];
          await step(f.ok ? 'security code sent (' + (f.pressed || '') + ')' : 'the security code could not be sent: ' + (f.error || ''));
          endAt = Date.now() + CONFIRM_WAIT_MS;
          continue;
        }
        if (r.placed && r.order) { conf = r; break; }
        if (r.placed) conf = r;                  // thank-you words seen; keep looking a little for the order number
        if (conf && Date.now() > endAt - CONFIRM_WAIT_MS + 15000) break;
      }
      if (conf && conf.failed) {
        if (/security code|\bcvv\b|\bcvc\b|\bcsc\b|card (verification|code)/i.test(String(conf.failed))) globalThis.__rkCardCode = null;   // v77: a turned-down saved code is never typed again by itself
        await setp(key, {attempted: false, submissionPending: false, inProgress: false, armed: false, step: null, status: 'ORDER NOT PLACED — ' + S.name + ' says: ' + conf.failed});
        diag('bb_order_failed', {key, reason: conf.failed});
        return {ok: false, failed: conf.failed};
      }
      if (conf && conf.placed) {
        await setp(key, {purchased: true, submissionPending: false, inProgress: false, orderNumber: conf.order || null, step: null, status: 'PURCHASE SUCCESS' + (conf.order ? ' — order ' + conf.order : '')});
        diag('bb_purchase_success', {key, order: conf.order, ms: Date.now() - t0});
        return {ok: true, order: conf.order};
      }
      if ((await st(key) || {}).purchased) return {ok: true};
      await setp(key, {submissionPending: false, inProgress: false, step: null, status: 'ORDER MAY HAVE BEEN SUBMITTED — CHECK ' + S.name.toUpperCase()});
      diag('bb_submission_unclear', {key, ms: Date.now() - t0, url: (await urlOf(id)).replace(/\?.*/, '')});
      return {ok: false, unclear: true};
    } catch (e) {
      const kind = e instanceof Stop ? e.kind : 'error', msg = String(e && e.message || e);
      let fp = null;
      try { if (id) { fp = await ask(id, {bb: 'fingerprint'}, 4000); } } catch {}
      diag('bb_stopped', {key, dryRun, kind, reason: msg, steps: steps.map(s => s.name), page: fp && fp.ok ? fp : null});
      try { if (!dryRun && !/^another browser/.test(String(msg)) && globalThis.RestalkerShops && globalThis.RestalkerShops.verdict) globalThis.RestalkerShops.verdict(S.store, key, kind, msg, 'this browser:' + key); } catch {}
      if (dryRun) {
        let removed = null;
        if (id && !['cart', 'check', 'signin'].includes(kind)) { try { await go(id, CART, u => onCart(u)); removed = !!(await ask(id, {bb: 'remove', want}, 12000)).ok; } catch {} }
        return {ok: false, dryRun: true, kind, reason: msg, steps, page: fp && fp.ok ? fp : null, removed};
      }
      if (latched) {
        await setp(key, {submissionPending: false, inProgress: false, step: null, status: 'ORDER MAY HAVE BEEN SUBMITTED — CHECK ' + S.name.toUpperCase() + ' (' + msg.slice(0, 80) + ')'});
        return {ok: false, unclear: true};
      }
      // nothing was ordered. Take the item out of the cart again if it got there and the reason was money / identity / cart
      if (id && !['check', 'signin'].includes(kind) && !(globalThis.RestalkerShops && globalThis.RestalkerShops.shadowActive && globalThis.RestalkerShops.shadowActive(S.store) && kind !== 'overcap' && kind !== 'identity') && (!globalThis.RestalkerShops || !globalThis.RestalkerShops.cartHolder || globalThis.RestalkerShops.cartHolder(S.store) === 'this browser:' + key)) {   // (v75: only while THIS browser has the cart)   // nothing was ordered: THIS item leaves the cart again (others are never touched)
        try {
          diag('bb_cart_cleanup', {key, kind, step: 'start', url: (await urlOf(id)).replace(/\?.*/, '')});
          if (!onCart(await urlOf(id))) await go(id, CART, u => onCart(u));
          for (let i = 0; i < 3; i++) {                     // (v68b: removed, then the cart is read again to be sure)
            const r0 = await ask(id, {bb: 'cart', want}, 8000);
            diag('bb_cart_cleanup', {key, kind, step: 'cart read', url: (await urlOf(id)).replace(/\?.*/, ''), ok: !!(r0 && r0.ok), mine: !!(r0 && (r0.items || []).some(x => x.mine)), n: r0 && r0.items ? r0.items.length : null});
            if (!r0 || !r0.ok || !(r0.items || []).some(x => x.mine)) break;
            const rm = await ask(id, {bb: 'remove', want}, 12000);
            diag('bb_cart_cleanup', {key, kind, removed: !!(rm && rm.ok), error: rm && rm.error || null});
            await settle(id);
          }
        } catch (e) { diag('bb_cart_cleanup', {key, kind, error: String(e && e.message || e)}); }
      }
      const cur = await st(key) || {};
      const fails = (cur.fails || []).filter(t => Date.now() - t < FAIL_WINDOW_MS).concat(['soldout', 'overcap', 'other'].includes(kind) ? [] : [Date.now()]);
      const needYou = ['check', 'signin', 'action', 'cart', 'identity'].includes(kind);
      const giveUp = needYou || kind === 'cancelled' || kind === 'other' || fails.length >= FAIL_MAX;
      const label = {other: 'NOT BOUGHT — ' + msg, soldout: 'NOT BOUGHT — sold out again', overcap: 'NOT BOUGHT — OVER CAP', check: 'ACTION REQUIRED — ' + msg, signin: 'ACTION REQUIRED — ' + msg,
                     action: 'ACTION REQUIRED — ' + msg, cart: 'ACTION REQUIRED — ' + msg, identity: 'ACTION REQUIRED — check the ' + S.name + ' link: ' + msg, cancelled: 'PURCHASE CANCELLED — RE-ARM REQUIRED (' + msg + ')'}[kind] || ('FAILED — ' + msg);
      await setp(key, {inProgress: false, step: null, approval: null, needCvv: false, fails, armed: giveUp ? false : cur.armed,
                       status: (cur.purchased || cur.submissionPending) ? cur.status : giveUp && !needYou && kind !== 'cancelled' && kind !== 'other' ? label + ' — ' + FAIL_MAX + ' tries failed; MANUAL RE-ARM REQUIRED' : (kind === 'soldout' || kind === 'overcap' ? label + ' (still armed)' : label + (giveUp ? '' : ' (still armed)'))});
      return {ok: false, kind, reason: msg};
    } finally {
      running = null;
      delete secrets[key];
      try { if (globalThis.RestalkerShops) globalThis.RestalkerShops.release(p && p.group, key); } catch {}
      try { if (globalThis.RestalkerShops) globalThis.RestalkerShops.cartUnlock(S.store, 'this browser:' + key); } catch {}
      if (!dryRun) { const s = await st(key); if (s && s.inProgress && !s.submissionPending) await setp(key, {inProgress: false}); }
    }
  }
  function waitFor(key, ms) {
    return new Promise(res => { const to = setTimeout(() => { delete waiters[key]; res('timeout'); }, ms); waiters[key] = v => { clearTimeout(to); delete waiters[key]; res(v); }; });
  }
  // ---- order history (after an unclear result) and the sign-in check
  async function readPage(url, settle = 3500) {
    let t = null;
    // v62: waits for the page to finish - or at most 15 s, then reads what is there (a store page that keeps loading adverts must not
    // count as "did not load")
    const ready = new Promise(r => { const fn = (i, ch, tt) => { if (t && i === t.id && tt.status === 'complete' && tt.url && tt.url !== 'about:blank') { chrome.tabs.onUpdated.removeListener(fn); r(tt.url); } }; chrome.tabs.onUpdated.addListener(fn); setTimeout(() => { chrome.tabs.onUpdated.removeListener(fn); r(null); }, 15000); });
    t = await chrome.tabs.create({url, active: false});
    try {
      let u = await ready;
      if (!u) { const cur = await urlOf(t.id); if (cur && /^https:/.test(cur)) u = cur; }
      if (!u) return {ok: false, error: 'page did not load'};
      if (isSignin(u)) return {ok: true, signin: true, url: u};
      const r = await ask(t.id, {bb: 'text', settle}, 20000);
      return r.ok ? {ok: true, url: u, text: r.text} : r;
    } finally { try { await chrome.tabs.remove(t.id); } catch {} }
  }
  // v59b: is an item that Best Buy's data calls buyable really buyable for us (can it be SHIPPED)? The product page is looked at in a
  // separate quiet tab (never the checkout tab), read only.
  let checkTab = null, checkBusy = Promise.resolve();
  async function pdpCheck(url) {
    if (!url.startsWith(S.origin)) return {ok: false, reason: 'not a ' + S.name + ' product page'};
    const run = async () => {
      let id = null;
      try { if (checkTab !== null && (await chrome.tabs.get(checkTab))) id = checkTab; } catch {}
      if (id === null) { const t = await chrome.tabs.create({url: 'about:blank', active: false}); id = checkTab = t.id; }
      const u = await go(id, url, null, 30000);
      if (!u) return {ok: false, reason: 'the product page did not load'};
      const r = await ask(id, {bb: 'pdp', wait: 8000}, 15000);
      if (!r || !r.ok) return {ok: false, reason: (r && r.error) || 'the page did not answer'};
      return {ok: true, sku: r.sku || null, inStock: !!r.inStock, storeOnly: !!r.storeOnly, ships: !!r.ships, button: r.button, price: r.price, title: r.title, fulfillment: r.fulfillment, check: r.check};
    };
    const p = checkBusy.then(run, run);
    checkBusy = p.catch(() => {});
    return p;
  }
  async function orderCheck(key) {
    const p = await st(key);
    if (!p) return {ok: false, reason: 'unknown product'};
    const r = await readPage(ORDERS, 5000);
    if (!r.ok) return {ok: true, checked: false, reason: r.error};
    if (r.signin) return {ok: true, checked: false, reason: 'not signed in to ' + S.name};
    const t = r.text.toLowerCase(), toks = (p.tokens || []).map(x => x.toLowerCase());
    const skus = [p.sku, ...(p.skuAlt || [])].filter(Boolean).map(String);
    let i = -1;
    for (const s of skus) { i = t.indexOf(s); if (i >= 0) break; }
    if (i < 0 && toks.length) { const k0 = t.indexOf(toks[0]); if (k0 >= 0 && toks.every(k => k.split('|').some(x => t.slice(Math.max(0, k0 - 400), k0 + 600).includes(x)))) i = k0; }
    if (i < 0) return {ok: true, checked: true, found: false};
    const before = r.text.slice(Math.max(0, i - 3000), i + 400), ids = [...before.matchAll(S.orderRx)];
    return {ok: true, checked: true, found: true, orderNumber: ids.length ? ids[ids.length - 1][1] : null};
  }
  // v62: signed in? The store's own order page is OPENED in a quiet background tab, exactly as when you open it yourself (diagnostics 60:
  // the small request for it failed every time at Best Buy and GameStop - "Failed to fetch" - so they always showed "NOT signed in").
  // A sign-in page = not signed in; the order page itself = signed in; a page that cannot be judged = unknown (never "not signed in").
  const SIGNIN_WORDS = /\b(sign in|log in|signin|login)\b[^.]{0,60}\b(password|email|e-mail)\b|forgot (your )?password|sign in to (see|view|track) (your )?orders?/;
  const ACCOUNT_WORDS = /\b(order history|your orders|my orders|purchase history|order details|orders placed|track (your )?(order|package)|sign out|log ?out)\b/;
  let accountBusy = null;
  async function account() {
    if (accountBusy) return accountBusy;
    accountBusy = (async () => {
      const r = await readPage(ORDERS, 2500);
      if (!r.ok) return {ok: true, signedIn: null, reason: 'the order page did not open (' + (r.error || '?') + ')', how: 'page'};
      if (r.signin) return {ok: true, signedIn: false, how: 'page', url: (r.url || '').replace(/\?.*/, '').slice(0, 90)};
      const t = String(r.text || '').toLowerCase();
      if (/verify (that )?you are (a )?human|are you a robot|robot or human|press (and|&) hold|access denied|request unsuccessful/.test(t))
        return {ok: true, signedIn: null, reason: 'the store showed a human check on its order page (not answered)', how: 'page'};
      if (ACCOUNT_WORDS.test(t)) return {ok: true, signedIn: true, how: 'page'};
      if (SIGNIN_WORDS.test(t)) return {ok: true, signedIn: false, how: 'page', url: (r.url || '').replace(/\?.*/, '').slice(0, 90)};
      if (t.length < 200) return {ok: true, signedIn: null, reason: 'the order page was empty', how: 'page'};
      // the store kept us on its order page (it sends anyone not signed in to its sign-in page) and asks for no password: signed in
      return {ok: true, signedIn: true, how: 'page (stayed on the order page)'};
    })();
    try { return await accountBusy; } finally { accountBusy = null; }
  }
  // ---- what Restalker can ask
  async function command(c) {
    const key = String(c.key || '');
    if (c.type === 'BB_SET') {          // product data from Restalker's table (link, name words, cap, Best Buy number)
      const cur = await st(key) || {};
      const moved = !!c.url && String(c.url) !== String(cur.url || '');       // (v75: a NEW link - the old page's item number is forgotten)
      const v = {url: String(c.url || cur.url || ''), name: String(c.name || cur.name || ''), tokens: Array.isArray(c.tokens) ? c.tokens.map(String).slice(0, 8) : (cur.tokens || []),
                 sku: c.sku ? String(c.sku) : (moved ? null : (cur.sku || null)), forbid: Array.isArray(c.forbid) ? c.forbid.map(String).slice(0, 6) : (cur.forbid || []),
                 group: c.group ? String(c.group) : (cur.group || null), amazonPid: c.amazonPid ? String(c.amazonPid) : (cur.amazonPid || null),
                 trusted: c.trusted === undefined ? !!cur.trusted : !!c.trusted};     // v75: a link YOU gave - its page is the product
      if (moved) v.skuAlt = [];
      if (c.cap != null) { const cap = Number(c.cap); if (!(cap > 0)) return {ok: false, reason: 'invalid cap'}; if (cur.inProgress || cur.submissionPending) return {ok: false, reason: 'checkout running'}; v.cap = cap; }
      await setp(key, v); return {ok: true};
    }
    if (c.type === 'BB_ARM') {
      const p = await st(key);
      if (!p || !p.url || !(p.cap > 0)) return {ok: false, reason: 'the product needs its ' + S.name + ' link and a price cap'};
      if (p.purchased || p.attempted || p.submissionPending) return {ok: false, reason: 'Already purchased, attempted or order unresolved. Do not re-purchase automatically'};
      await setp(key, {armed: true, fails: [], status: 'ARMED — AUTO BUY ON'}); await setg({emergencyStop: false}); return {ok: true};
    }
    if (c.type === 'BB_DISARM') {
      const p = await st(key);
      if (p && (p.inProgress || p.submissionPending)) { if (waiters[key]) waiters[key]('cancel'); }
      if (p) await setp(key, {armed: false, status: p.purchased ? p.status : 'PRODUCT DISARMED'});
      return {ok: true};
    }
    if (c.type === 'BB_BUY_AGAIN') {
      const p = await st(key);
      if (!p || !p.purchased) return {ok: false, reason: 'No confirmed prior purchase to re-authorize'};
      if (!c.confirmedAdditionalPurchase) return {ok: false, reason: 'confirm the additional purchase'};
      await setp(key, {priorPurchases: [...(p.priorPurchases || []), {order: p.orderNumber, at: p.submitAt, price: p.price}], purchased: false, attempted: false,
                       submissionPending: false, inProgress: false, orderNumber: null, armed: true, fails: [], status: 'RE-ARMED FOR ONE ADDITIONAL PURCHASE'});
      return {ok: true};
    }
    if (c.type === 'BB_EXTRA_STATE') {    // v75: an order placed by one of Restalker's OTHER buying browsers - written here, so every rule sees it
      const p = await st(key); if (!p) return {ok: false, reason: 'unknown product'};
      const who = String(c.browser || 'another browser').slice(0, 30), stt = String(c.state || '');
      if (stt === 'submitting') await setp(key, {attempted: true, submissionPending: true, extraPrevArmed: !!p.armed, armed: false, submitAt: Date.now(), price: c.price ?? p.price ?? null, status: 'SUBMITTING ORDER — ' + who});
      else if (stt === 'bought') await setp(key, {purchased: true, attempted: true, submissionPending: false, inProgress: false, orderNumber: c.orderNumber || null, status: 'PURCHASE SUCCESS — ' + who + (c.orderNumber ? ' — order ' + c.orderNumber : '')});
      else if (stt === 'unclear') await setp(key, {submissionPending: false, inProgress: false, status: 'ORDER MAY HAVE BEEN SUBMITTED — CHECK ' + S.name.toUpperCase() + ' (' + who + ')'});
      else if (stt === 'failed') await setp(key, {attempted: false, submissionPending: false, armed: !!p.extraPrevArmed, status: 'ORDER NOT PLACED — ' + who + ': ' + String(c.reason || '').slice(0, 120)});
      return {ok: true};
    }
    if (c.type === 'BB_MARK') {
      const p = await st(key); if (!p) return {ok: false, reason: 'unknown product'};
      if (c.bought) await setp(key, {purchased: true, attempted: true, orderNumber: c.orderNumber || p.orderNumber || null, status: c.status || 'PURCHASE SUCCESS — confirmed'});
      else await setp(key, {purchased: false, attempted: false, submissionPending: false, inProgress: false, armed: false, status: 'NOT ORDERED — checked by you'});
      return {ok: true};
    }
    if (c.type === 'BB_ANSWER') {       // security code / shipping approval / cancel, typed or pressed in Restalker
      if (c.answer === 'cvv') { const v = String(c.value || '').replace(/\D/g, ''); if (v.length < 3 || v.length > 4) return {ok: false, reason: 'the security code has 3 or 4 digits'}; secrets[key] = v; }
      if (!waiters[key]) return {ok: false, reason: 'nothing is waiting for an answer'};
      waiters[key](c.answer === 'cvv' ? 'cvv' : c.answer === 'approve' ? 'approve' : 'cancel');
      return {ok: true};
    }
    if (c.type === 'BB_GLOBAL') { const v = {}; if ('live' in c) v.live = !!c.live; if ('allowPickup' in c) v.allowPickup = !!c.allowPickup; if (c.emergencyStop) v.emergencyStop = true; await setg(v);
      if (c.emergencyStop) for (const p of await all()) { if (!p.submissionPending && !p.attempted) await setp(p.key, {armed: false, status: p.purchased ? p.status : 'EMERGENCY STOP — DISARMED'}); if (waiters[p.key]) waiters[p.key]('cancel'); }
      return {ok: true}; }
    if (c.type === 'BB_PRACTICE') {     // practice run: the whole checkout on the real site, stops before Place Your Order, empties the cart again
      if (running) return {ok: false, reason: 'a ' + S.name + ' checkout is running'};
      const tmp = 'practice';
      await setp(tmp, {url: String(c.url || ''), name: String(c.name || 'practice item'), tokens: Array.isArray(c.tokens) ? c.tokens : [], sku: c.sku ? String(c.sku) : null,
                       cap: Number(c.cap) || 100000, mode: c.mode === 'search' ? 'search' : 'product', armed: false, practice: true});
      const r = await campaign(tmp, {dryRun: true});
      await chrome.storage.local.remove(K(tmp));
      const res = {at: Date.now(), ...r};
      await setg({practice: res});
      return {ok: true, result: res};
    }
    if (c.type === 'BB_PDP_CHECK') return pdpCheck(String(c.url || ''));
    if (c.type === 'BB_ORDER_CHECK') return orderCheck(key);
    if (c.type === 'BB_ACCOUNT') return account();
    if (c.type === 'BB_FORGET') { const p = await st(key); if (p && !p.inProgress && !p.submissionPending) await chrome.storage.local.remove(K(key)); return {ok: true}; }
    return {ok: false, reason: 'unknown ' + S.name + ' command'};
  }
  async function onRestock(ev) {
    const key = String(ev.key || '');
    const p = await st(key);
    if (!p) return {ok: false, retryable: false, reason: 'ASIN absent from buyer catalog'};
    if (p.purchased || p.attempted) return {ok: true, reason: 'target completed; manual rearm required'};
    const x = await g();
    if (!p.armed || x.emergencyStop || x.live === false) return {ok: true, reason: 'monitor disabled'};
    if (running === key || p.inProgress) return {ok: true, reason: 'target checkout already started'};
    if (running) return {ok: false, retryable: true, reason: 'other checkout owns buyer; retry after release'};
    campaign(key, {reason: 'restock'}).catch(e => diag('bb_campaign_error', {key, reason: String(e && e.message || e)}));
    return {ok: true, reason: 'fresh Amazon check dispatched'};
  }
  async function snapshot() {
    return (await all()).filter(p => !p.practice).map(p => ({key: p.key, store: S.store, name: p.name, sku: p.sku, cap: p.cap ?? null, armed: !!p.armed && !p.purchased && !p.attempted,
      purchased: !!p.purchased, attempted: !!p.attempted, inProgress: !!p.inProgress, submissionPending: !!p.submissionPending, status: String(p.status || '').slice(0, 240),
      step: p.step || null, price: p.price ?? null, orderNumber: p.orderNumber || null, submitAt: p.submitAt || null, hitAt: p.hitAt || null,
      approval: p.approval || null, needCvv: !!p.needCvv}));
  }
  async function startup() {
    // like the Amazon checkout: after a browser start nothing is left half-way. A pressed Place Order without an answer = unconfirmed.
    const s = await chrome.storage.session.get(S.prefix + 'rec');
    if (s[S.prefix + 'rec']) return;
    for (const p of await all()) {
      if (p.practice) { await chrome.storage.local.remove(K(p.key)); continue; }
      if (p.submissionPending) await setp(p.key, {submissionPending: false, inProgress: false, armed: false, status: 'ORDER STATE UNCERTAIN AFTER BROWSER RESTART — CHECK ' + S.name.toUpperCase()});
      else if (p.inProgress) await setp(p.key, {inProgress: false, armed: false, approval: null, needCvv: false, status: 'PURCHASE INTERRUPTED — RE-ARM REQUIRED'});
      else if (p.armed) await setp(p.key, {armed: false, status: 'DISARMED AFTER BROWSER RESTART'});
    }
    await setg({tab: null});
    await chrome.storage.session.set({[S.prefix + 'rec']: true});
  }
  return {CODE: 'v106', store: S.store, name: S.name, command, onRestock, snapshot, startup, setDiag: fn => { diag = fn; }, running: () => running};
}

// ---------------------------------------------------------------- the stores
const RK_STORE_DEFS = {
  target: {store: 'target', name: 'Target', prefix: 'tg:', origin: 'https://www.target.com', cart: 'https://www.target.com/cart',
           orders: 'https://www.target.com/orders', orderRx: /\b(\d{12,16})\b/g,
           isCheckout: u => /target\.com\/(co-review|checkout|co-cart)/i.test(u) && !/thank|confirmation|order-confirmation/i.test(u),
           isSignin: u => /target\.com\/(login|account\/sign|co-login|gsp\/login)/i.test(u) || /login\.target\.com/i.test(u)},
  walmart: {store: 'walmart', name: 'Walmart', prefix: 'wm:', origin: 'https://www.walmart.com', cart: 'https://www.walmart.com/cart',
            // v68 (tested on the real walmart.com 2026-10-29): Walmart's own add-to-cart link, and its "Added to cart" page after a press
            addLink: sku => 'https://www.walmart.com/sc/cart/addToCart?items=' + encodeURIComponent(sku),
            skuOf: u => (String(u || '').match(/\/ip\/(?:[^/?]+\/)?(\d{5,})/) || [])[1] || null,
            addedUrl: (u, sku) => /walmart\.com\/pac\?/i.test(u) && (!sku || new RegExp('[?&]id=' + sku + '(&|$)').test(u)),
            orders: 'https://www.walmart.com/orders', orderRx: /\b(\d{7}-\d{6,9}|\d{4}-?\d{6}-?\d{4,7}|\d{13,16})\b/g,
            isCheckout: u => /walmart\.com\/checkout/i.test(u) && !/thank|confirmation|order-confirmation/i.test(u),
            isSignin: u => /walmart\.com\/(account\/login|account\/signin|identity)/i.test(u)},
  gamestop: {stepsFirst: true,store: 'gamestop', name: 'GameStop', prefix: 'gs:', origin: 'https://www.gamestop.com', cart: 'https://www.gamestop.com/cart/',
             orders: 'https://www.gamestop.com/account/order-history/', orderRx: /\b(\d{8,14})\b/g,
             isCheckout: u => /gamestop\.com\/(mrt\/)?(checkout|spcheckout)/i.test(u) && !/confirmation|thank/i.test(u),
             isSignin: u => /gamestop\.com\/(login|account\/login|signin)/i.test(u)}
};
globalThis.RestalkerStores = Object.fromEntries(Object.entries(RK_STORE_DEFS).map(([k, d]) => [k, makeStoreEngine(d)]));

// One dispatcher for every shop checkout (Best Buy + the stores above), and the one-of-a-product rule across them.
globalThis.RestalkerShops = (() => {
  const latches = {};                         // product group -> {store, key, at}: a Place Order is being pressed for it right now
  const engines = () => ({...(globalThis.RestalkerBestBuy ? {bestbuy: globalThis.RestalkerBestBuy} : {}), ...(globalThis.RestalkerStores || {})});
  const PREFIX = {bestbuy: 'bb:', target: 'tg:', walmart: 'wm:', gamestop: 'gs:'};
  function tryLatch(group, store, key) {
    if (!group) return null;
    const l = latches[group];
    if (l && l.key !== key && Date.now() - l.at < 10 * 60 * 1000) return l.store === 'amazon' ? 'Amazon' : l.store === 'extra' ? String(l.key).split(':')[0] : engines()[l.store] ? engines()[l.store].name || l.store : l.store;
    latches[group] = {store, key, at: Date.now()};
    return null;
  }
  function release(group, key) { if (group && latches[group] && latches[group].key === key) delete latches[group]; }
  // v88: a product ordered by one of Restalker's OTHER browsers at Amazon -> nobody presses for it again (ttl 0 = for good; an unclear
  // result: for ttl ms, while Restalker looks in your orders)
  const ordered = {};
  function markOrdered(group, by, ttl, pid) { for (const g of [group, pid ? 'amzpid:' + pid : null]) if (g) ordered[g] = {by, until: ttl ? Date.now() + ttl : Infinity}; }
  function orderedBy(group) { const o = group && ordered[group]; return o && Date.now() < o.until ? o.by : null; }
  // v75 (your rule: every BROWSER checks out at the same moment): a store keeps ONE cart per account - shared by every browser signed in
  // to it. Two browsers putting the item in at once would make it 2, and one taking it out would spoil the other's checkout. So the cart
  // of a store is used by ONE browser at a time; the others wait ready (product page read, Shipping chosen) and go on the moment it is free.
  const carts = {};
  const CART_HOLD_MS = 12 * 60 * 1000;
  // v78 (diagnostics 65: six browsers took turns at ONE GameStop cart and each found the same "tax too high" - the buying browser waited
  // 2 minutes): what one browser found about THE PRODUCT at a store (over the cap, tax / fees, not this product, sold out) is told to
  // every other browser waiting for that cart - they stop at once instead of repeating it. (Sign-in, human checks and page trouble are
  // the browser's own: the others still go on.)
  const VERDICT_KINDS = new Set(['overcap', 'fees', 'identity', 'soldout', 'needyou', 'action']);
  const verdicts = {};
  function verdict(store, key, kind, reason, owner) {
    if (!VERDICT_KINDS.has(kind)) return;
    verdicts[store + '|' + key] = {kind, reason: String(reason || '').slice(0, 160), owner: String(owner || ''), at: Date.now()};
  }
  function verdictFor(store, key, since, owner) {
    const v = verdicts[store + '|' + key];
    return v && v.at >= (since || 0) && v.owner !== String(owner || '') ? v : null;
  }
  function cartLock(store, owner) {
    const c = carts[store];
    if (c && c.owner !== owner && Date.now() - c.at < CART_HOLD_MS) return c.owner;
    carts[store] = {owner, at: Date.now()};
    return null;
  }
  function cartUnlock(store, owner) { if (carts[store] && carts[store].owner === owner) delete carts[store]; }
  // v87: browsers checking out from the shared cart that another browser filled - while one is, the item is never taken out of the cart
  const shadows = {};
  function shadowNote(store, owner) { shadows[store] = {owner: String(owner || ''), at: Date.now()}; }
  function shadowActive(store) { const x = shadows[store]; return !!(x && Date.now() - x.at < 90000); }
  function cartHolder(store) { const c = carts[store]; return c && Date.now() - c.at < CART_HOLD_MS ? c.owner : null; }
  async function otherOrdered(p, store, key) {
    if (!p || !p.group) return null;
    if (orderedBy(p.group)) return orderedBy(p.group);
    // (v75: the same product's records found in memory, then read FRESH from storage - only those few)
    const mates = globalThis.RestalkerRecs ? (await globalThis.RestalkerRecs.entries()).filter(([, v]) => v && v.group === p.group).map(([k]) => k) : null;
    const all = mates ? await chrome.storage.local.get(mates.concat(p.amazonPid ? ['p:' + p.amazonPid] : [])) : await chrome.storage.local.get(null);
    for (const [st, pre] of Object.entries(PREFIX)) {
      for (const [k, v] of Object.entries(all)) {
        if (!k.startsWith(pre) || !v || v.practice || (st === store && v.key === key) || v.group !== p.group) continue;
        if (v.submissionPending || v.purchased || (v.attempted && !v.purchased)) return (engines()[st] && engines()[st].name) || st;
      }
    }
    if (p.amazonPid) {                         // the same product's Amazon listing (the Amazon checkout's own record)
      const a = all['p:' + p.amazonPid];
      if (a && (a.submissionPending || a.purchased || (a.attempted && !a.purchased))) return 'Amazon';
    }
    return null;
  }
  // v75: the Amazon checkout takes its turn here too, right before its Place order (all stores race at once; ONE presses at a time).
  // Amazon-only products (no store link of the same product) never wait.
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  // (kept in memory, so Amazon's hot path never reads the whole storage: Amazon listing -> its product group)
  const amzGroups = new Map();                  // store record key -> {pid, group}
  const noteRec = (k, v) => { if (!/^(bb|tg|wm|gs):/.test(k)) return; if (v && !v.practice && v.group && v.amazonPid) amzGroups.set(k, {pid: String(v.amazonPid), group: v.group}); else amzGroups.delete(k); };
  let amzScan = null;
  const amzReady = () => amzScan || (amzScan = (globalThis.RestalkerRecs ? globalThis.RestalkerRecs.entries().then(es => Object.fromEntries(es)) : chrome.storage.local.get(null)).then(all => { for (const [k, v] of Object.entries(all)) noteRec(k, v); }).catch(() => { amzScan = null; }));
  try { chrome.storage.onChanged.addListener((ch, area) => { if (area !== 'local') return; for (const [k, c] of Object.entries(ch)) noteRec(k, c.newValue); }); } catch {}
  void amzReady();
  async function amazonGroup(pid) {
    await amzReady();
    for (const v of amzGroups.values()) if (v.pid === String(pid)) return v.group;
    return null;
  }
  async function amazonTurn(pid, stillWanted) {
    // v88: an Amazon-only product (no store link of the same product) takes the latch too - the other browsers buy at Amazon now
    const group = (await amazonGroup(pid)) || ('amzpid:' + pid);
    if (orderedBy(group) || orderedBy('amzpid:' + pid)) return {ok: false, reason: 'it was ordered at ' + (orderedBy(group) || orderedBy('amzpid:' + pid)) + ' (one per product)'};
    const key = 'amazon:' + pid, t0 = Date.now();
    for (;;) {
      const holder = tryLatch(group, 'amazon', key);
      if (!holder) {
        const other = await otherOrdered({group, amazonPid: null}, 'amazon', key);
        if (other) { release(group, key); return {ok: false, reason: 'it was ordered at ' + other + ' (one per product)'}; }
        return {ok: true, waitedMs: Date.now() - t0};
      }
      if (Date.now() - t0 > 240000) return {ok: false, reason: 'waited too long for ' + holder};
      if (stillWanted && !(await stillWanted())) return {ok: false, reason: 'auto-buy was switched off'};
      await sleep(100);
    }
  }
  async function amazonPidOf(group) { await amzReady(); for (const v of amzGroups.values()) if (v.group === group) return v.pid; return null; }
  async function amazonDone(pid) { const group = (await amazonGroup(pid)) || ('amzpid:' + pid); release(group, 'amazon:' + pid); }
  // v90b: the buying browser signs itself back in with your saved sign-in (Restalker hands it over only for this; it is never stored
  // here, never logged, and only typed into a page of that store's own address). A code / "verify it's you" / a puzzle is never answered.
  function rkLoginStep(email, pw, onSi) {
    const vis = e => { if (!e) return false; const r = e.getBoundingClientRect(), s = getComputedStyle(e); return r.width > 2 && r.height > 2 && s.visibility !== 'hidden' && s.display !== 'none'; };
    const q = sel => [...document.querySelectorAll(sel)].filter(vis);
    const txt = (document.body && document.body.innerText || '').slice(0, 5000);
    const NEED = /verification code|one[- ]time (pass)?code|enter (the|your) code|we('ve| have)? (just )?sent (you )?a code|code (was )?sent|verify (it'?s|that it'?s) you|two[- ]step|2[- ]step|passkey|approve the (notification|request)|solve this puzzle|captcha|press (&|and) hold|not a robot|unusual activity|account (is )?(locked|on hold)/i;
    const BAD = /(password|e-?mail).{0,40}(incorrect|is wrong|not (correct|recognized|valid))|incorrect (password|e-?mail)|(cannot|can't|couldn't) find an account|no account (found|with)/i;
    if (q('input[autocomplete=one-time-code], input[name*=otp i], input[id*=otp i]').length || NEED.test(txt)) return {needyou: true};
    if (BAD.test(txt)) return {bad: true};
    const pws = q('input[type=password]');
    const ems = q('input[type=email], input[autocomplete=username], input[autocomplete=email], input[name*=email i], input[id*=email i], input[name*=user i], input[id*=user i], input[name=username], input[id=fld-e]').filter(e => !['password', 'hidden', 'checkbox'].includes(e.type));
    const choice = [...document.querySelectorAll('a, button, [role=button]')].filter(vis).find(x => /use (a |my |your )?password|enter (your )?password|sign in with (a |your )?password|password instead/i.test(x.innerText || ''));
    if (!onSi && !pws.length && !choice) return {done: true};
    const set = (el, v) => { const d = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value'); el.focus(); d.set.call(el, v); el.dispatchEvent(new Event('input', {bubbles: true})); el.dispatchEvent(new Event('change', {bubbles: true})); };
    for (const cb of q('input[type=checkbox]')) { const l = ((cb.labels && cb.labels[0] && cb.labels[0].innerText) || cb.name || cb.id || '').toLowerCase(); if (/keep me signed in|remember|stay signed in|rememberme/.test(l) && !cb.checked) cb.click(); }
    let acted = false;
    if (ems.length && !ems[0].value) { set(ems[0], email); acted = true; }
    if (pws.length) { set(pws[0], pw); acted = true; }
    if (!acted && choice) { choice.click(); return {acted: true}; }
    const btn = q('button[type=submit], input[type=submit]')[0] || [...document.querySelectorAll('button, [role=button]')].filter(vis).find(x => /^\s*(sign in|continue|next|log in|login)\b/i.test(x.innerText || ''));
    if (btn) { btn.click(); return {acted: true}; }
    const f = (pws[0] || ems[0] || {}).form; if (f && f.requestSubmit) { f.requestSubmit(); return {acted: true}; }
    return {acted};
  }
  async function autoLogin(store, url, email, pw, host, signinRx) {
    const rx = new RegExp(signinRx || 'signin|login', 'i');
    let t = null;
    try {
      t = await chrome.tabs.create({url, active: false});
      for (let i = 0; i < 10; i++) {
        await sleep(1800);
        let cur = '';
        try { cur = (await chrome.tabs.get(t.id)).url || ''; } catch { return {ok: false, why: 'the sign-in tab was closed'}; }
        let h = ''; try { h = new URL(cur).hostname.toLowerCase(); } catch {}
        if (!(h === host || h.endsWith('.' + host))) { if (i < 2) continue; return {ok: false, why: 'the sign-in page is not on ' + host + ' (nothing was typed)'}; }
        const onSi = rx.test(cur);
        let r = null;
        try { r = (await chrome.scripting.executeScript({target: {tabId: t.id}, func: rkLoginStep, args: [email, pw, onSi]}))[0].result; } catch { continue; }
        if (!r) continue;
        if (r.needyou) return {ok: false, why: 'the store asks for a code / a check that only you can answer'};
        if (r.bad) return {ok: false, why: 'the store says the saved e-mail or password is not right - save it again'};
        if (r.done) return {ok: true};
      }
      let cur = ''; try { cur = (await chrome.tabs.get(t.id)).url || ''; } catch {}
      return rx.test(cur) ? {ok: false, why: 'the sign-in page did not let it through'} : {ok: true};
    } finally { try { if (t) await chrome.tabs.remove(t.id); } catch {} }
  }
  async function command(c) {
    const e = engines();
    if (c.type === 'BB_AUTOLOGIN') return autoLogin(String(c.store || ''), String(c.url || ''), String(c.email || ''), String(c.password || ''), String(c.host || ''), String(c.signinRx || ''));
    // v75: the other buying browsers (Chrome, Firefox, Camoufox - run by Restalker) take the same turns as this browser
    if (c.type === 'BB_CARTLOCK') {
      const v = c.key ? verdictFor(String(c.cartStore || ''), String(c.key), Number(c.since || 0), String(c.owner || '')) : null;
      if (v) return {ok: false, holder: null, verdict: v};
      const h = cartLock(String(c.cartStore || ''), String(c.owner || '')); return {ok: !h, holder: h};
    }
    if (c.type === 'BB_AMZGROUP') { const pid = String(c.productId || ''); return {ok: !!pid, group: (await amazonGroup(pid)) || ('amzpid:' + pid)}; }   // (v88)
    if (c.type === 'BB_SHADOW') { shadowNote(String(c.cartStore || ''), String(c.owner || '')); return {ok: true}; }
    if (c.type === 'BB_SHADOWQ') return {ok: true, active: shadowActive(String(c.cartStore || ''))};
    // v80: what the buying browser has open (diagnostics 67: it held 14 GB in 87 processes) - addresses cut to the site and the first part of the path
    if (c.type === 'BB_TABS') {
      const ws = await chrome.windows.getAll({populate: true});
      const tabs = [];
      for (const w of ws) for (const t of (w.tabs || [])) {
        let site = '', path = '';
        try { const u = new URL(t.url || t.pendingUrl || ''); site = u.hostname ? u.hostname.replace(/^www\./, '') : u.protocol + (u.pathname || ''); path = u.hostname ? u.pathname.split('/').slice(0, 2).join('/') : ''; } catch {}
        tabs.push({win: w.id, state: w.state, site, path, active: !!t.active, discarded: !!t.discarded, audible: !!t.audible});
      }
      return {ok: true, windows: ws.length, tabs, janitor: globalThis.RK_JANITOR ? {closed: globalThis.RK_JANITOR.closed, last: globalThis.RK_JANITOR.last} : null};
    }
    if (c.type === 'BB_VERDICT') { verdict(String(c.cartStore || ''), String(c.key || ''), String(c.kind || ''), c.reason, String(c.owner || '')); return {ok: true}; }
    if (c.type === 'BB_CARTUNLOCK') { cartUnlock(String(c.cartStore || ''), String(c.owner || '')); return {ok: true}; }
    if (c.type === 'BB_LATCH') {
      const group = String(c.group || ''), owner = String(c.owner || '');
      if (!group) return {ok: true};
      const h = tryLatch(group, 'extra', owner);
      if (h) return {ok: false, holder: h};
      const amz = group.startsWith('amzpid:') ? null : await amazonPidOf(group);
      if (orderedBy(group)) { release(group, owner); return {ok: false, other: orderedBy(group)}; }
      const other = await otherOrdered({group, amazonPid: amz}, 'extra', owner);
      if (other) { release(group, owner); return {ok: false, other}; }
      return {ok: true};
    }
    if (c.type === 'BB_UNLATCH') { release(String(c.group || ''), String(c.owner || '')); return {ok: true}; }
    // v90: an order placed by one of Restalker's other browsers for a listing this browser does not know (yet): nobody presses again
    // v94: "Buy one more" (your choice) of a product an earlier order of which was placed by another browser: its 'ordered' note goes
    if (c.type === 'BB_UNMARKORDERED') { for (const k of [c.group ? String(c.group) : null, c.pid ? 'amzpid:' + String(c.pid) : null]) if (k) delete ordered[k]; return {ok: true}; }
    if (c.type === 'BB_MARKORDERED') { if (c.group) markOrdered(String(c.group), String(c.by || 'another browser').slice(0, 60), Number(c.ttl) || 0, null); return {ok: !!c.group}; }
    // v77: your saved card security code (kept in this browser's memory only - never in storage, never in the diagnostics); '' = none
    if (c.type === 'BB_SETCODE') { const v = String(c.value || '').replace(/\D/g, ''); globalThis.__rkCardCode = (v.length >= 3 && v.length <= 4) ? v : null; return {ok: true, set: !!globalThis.__rkCardCode}; }
    if (c.type === 'BB_GLOBAL' && !c.store) { let first = null; for (const x of Object.values(e)) { const r = await x.command(c); first = first || r; } return first || {ok: false, reason: 'no shop checkout'}; }
    const x = e[c.store || 'bestbuy'];
    return x ? x.command(c) : {ok: false, reason: 'no checkout for ' + c.store};
  }
  async function onRestock(ev) { const x = engines()[ev.store || 'bestbuy']; return x ? x.onRestock(ev) : {ok: false, reason: 'no checkout for ' + ev.store}; }
  async function snapshot() { let out = []; for (const x of Object.values(engines())) { try { out = out.concat(await x.snapshot()); } catch {} } return out; }
  async function startup() { for (const x of Object.values(engines())) { try { await x.startup(); } catch {} } }
  function setDiag(fn) { for (const x of Object.values(engines())) x.setDiag(fn); }
  return {CODE: 'v106', command, onRestock, snapshot, startup, setDiag, tryLatch, release, otherOrdered, amazonTurn, amazonDone, cartLock, cartUnlock, cartHolder, shadowNote, shadowActive, markOrdered, verdict, verdictFor, running: () => Object.values(engines()).some(x => x.running())};
})();
