"""Problem reports to Claude (v122).

Owner 2026-11-16: "The log needs to be downloadable or uploadable such that screenshots aren't required. Ideally, there should just be a way
to report the bug to you and have you automatically move to fix it ... I am unable to easily give you results from desktop and app
simultaneously".
"Report problem" (the button at the top of the page) sends the diagnostics file - the same one Download diagnostics gives (no passwords,
card code or addresses) - to this Restalker's own private ntfy channel ("rkr-" + 20 random letters, made once: report_topic.txt).
Claude reads it with that report code. The phone app has the same button (its own code). With automatic reports on (the default), a report
is also sent by itself when a checkout does not buy or something needs you - at most one every 30 minutes.
"""
import os
import re
import secrets
import threading
import time
import urllib.request

VERSION = "v127"
SERVER = "https://ntfy.sh"
TOPIC_FILE = "report_topic.txt"
AUTO_OFF_FILE = "report_auto_off.txt"
AUTO_GAP = 30 * 60
RETRY_WAIT = 5
ABC = "abcdefghijkmnpqrstuvwxyz23456789"
PROBLEM_KINDS = {"FAILED", "ACTION", "CHECK", "UNKNOWN", "NOTFOUND", "REST", "APPROVE", "CVV"}
_st = {"last_auto": 0.0, "sent": 0, "last": "", "error": "", "busy": False}
_lock = threading.Lock()
BUILD = None          # app.py: () -> diagnostics text (str)
LOG = None


def valid(t):
    return bool(re.fullmatch(r"rkr-[a-z0-9]{20}", t or ""))


def code():
    """This Restalker's report code (made the first time)."""
    try:
        t = open(TOPIC_FILE, encoding="utf-8").read().strip()
        if valid(t):
            return t
    except Exception:
        pass
    t = "rkr-" + "".join(secrets.choice(ABC) for _ in range(20))
    with open(TOPIC_FILE, "w", encoding="utf-8") as f:
        f.write(t)
    return t


def auto_on():
    return not os.path.exists(AUTO_OFF_FILE)


def set_auto(on):
    if on:
        try:
            os.remove(AUTO_OFF_FILE)
        except OSError:
            pass
    else:
        with open(AUTO_OFF_FILE, "w", encoding="utf-8") as f:
            f.write("automatic problem reports switched off by you\n")


def _put(url, headers, body):
    req = urllib.request.Request(url, data=body, method="PUT", headers=dict(headers, **{"User-Agent": "Restalker/" + VERSION}))
    with urllib.request.urlopen(req, timeout=90) as r:
        return r.status


def send(text, why, put=None):
    """Sends the diagnostics text as a file. -> (ok, code)."""
    topic = code()
    body = text.encode("utf-8", "replace") if isinstance(text, str) else text
    headers = {"Title": "Restalker desktop report", "Filename": "restalker-desktop-report.txt", "Tags": "restalker-report",
               "Message": re.sub(r"[\r\n]+", " ", str(why))[:300]}
    ok = False
    for attempt in range(3):                     # v123: the report server sometimes refuses for a moment - 3 tries, 5 s apart
        if attempt:
            time.sleep(RETRY_WAIT)
        try:
            st = (put or _put)(SERVER + "/" + topic, headers, body)
            ok = 200 <= int(st) < 300
            _st["error"] = "" if ok else f"the report server answered {st}"
        except Exception as e:
            ok = False
            _st["error"] = str(e)[:120]
        if ok:
            break
    if ok:
        _st["sent"] += 1
        _st["last"] = time.strftime("%m-%d %H:%M:%S")
    if LOG:
        LOG(f"[report] {'sent to Claude (code ' + topic + ')' if ok else 'could not be sent: ' + _st['error']} - {why}")
    return ok, topic


def send_now(why, put=None):
    """Builds the diagnostics and sends them (one at a time). -> (ok, code)."""
    with _lock:
        if _st["busy"]:
            return False, code()
        _st["busy"] = True
    try:
        text = "REPORT: " + str(why) + "\n\n" + (BUILD() if BUILD else "(no diagnostics builder)")    # v126: your note first
        return send(text, why, put)
    finally:
        _st["busy"] = False


def auto(kind, title, now=None, put=None, background=True):
    """A report by itself after a problem event - automatic reports on, and at most one every 30 minutes. -> True when one is sent."""
    if kind not in PROBLEM_KINDS or not auto_on():
        return False
    t = now if now is not None else time.time()
    with _lock:
        if t - _st["last_auto"] < AUTO_GAP:
            return False
        _st["last_auto"] = t
    if background:
        threading.Thread(target=send_now, args=("automatic: " + str(title)[:200], put), daemon=True, name="report").start()
    else:
        send_now("automatic: " + str(title)[:200], put)
    return True


# v127 (owner: "The PC version does not seem to be sending you diagnostics automatically ... such that i can go to sleep and you
# can present me with a brief summary of actions taken overnight"): besides the reports after a problem, a regular report every 4 hours
# while automatic reports are on - Claude follows the night from them.
PERIODIC = 4 * 3600
PERIODIC_FILE = "report_periodic.txt"


def _periodic_last():
    try:
        with open(PERIODIC_FILE, encoding="utf-8") as f:
            return float(f.read().strip() or 0)
    except Exception:
        return 0.0


def periodic_due(now=None):
    t = time.time() if now is None else now
    return auto_on() and t - _periodic_last() >= PERIODIC


def periodic_once(now=None, put=None):
    """Sends the regular report when it is due. -> True when sent."""
    t = time.time() if now is None else now
    if not periodic_due(t):
        return False
    try:
        with open(PERIODIC_FILE, "w", encoding="utf-8") as f:
            f.write(str(t))
    except OSError:
        pass
    ok, _ = send_now("automatic: regular report (every 4 hours, so Claude can follow how things went)", put)
    return ok


def start_periodic(first_wait=600, every=300):
    def loop():
        time.sleep(first_wait)
        while True:
            try:
                periodic_once()
            except Exception as e:
                _st["error"] = str(e)[:120]
            time.sleep(every)
    threading.Thread(target=loop, daemon=True, name="report-periodic").start()


def status():
    return (f"problem reports (v122): code {code()}; automatic {'on' if auto_on() else 'off'}; sent {_st['sent']}"
            + (f", last {_st['last']}" if _st["last"] else "") + (f"; last problem: {_st['error']}" if _st["error"] else ""))
