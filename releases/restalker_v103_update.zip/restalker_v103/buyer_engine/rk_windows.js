/* Restalker v65 - every tab the buying engine opens by itself (checkouts, sign-in checks, the order page) goes into the engine's OWN
 * hidden window, never into the window you are looking at.
 * Your report (v64): the Target sign-in window "never opens", store links "do not open", and the windows "pop up with the hidden ones".
 * Cause: a new tab goes into whichever window was used last. Once the sign-in / link window was open, the engine's own background
 * tabs (checkouts, sign-in checks, store pages) opened INSIDE it, on top of your page. Now they always open in the hidden window.
 */
'use strict';
(() => {
  if (globalThis.__rkTabsWrapped) return;
  globalThis.__rkTabsWrapped = true;
  globalThis.__rkSigninWin = null;            // the window you are using (sign-in or a store link) - set by detector_bridge.js
  const orig = chrome.tabs.create.bind(chrome.tabs);
  let work = null;
  const own = {};                             // v75: store -> its OWN checkout window (several stores check out at the same moment)
  async function workWindow() {
    try {
      if (work !== null && work !== globalThis.__rkSigninWin && !Object.values(own).includes(work)) {
        const w = await chrome.windows.get(work);
        if (w && w.type === 'normal') return work;
      }
    } catch {}
    work = null;
    const all = await chrome.windows.getAll({windowTypes: ['normal']});
    const mine = new Set(Object.values(own));
    const others = all.filter(w => w.id !== globalThis.__rkSigninWin && !mine.has(w.id));   // (v75: never a store's own checkout window)
    const parked = others.find(w => (w.left || 0) < -5000 || (w.top || 0) < -5000) || others.find(w => w.state === 'minimized');
    if (parked) { work = parked.id; return work; }
    // (no hidden window left - e.g. it was closed: a new one is made, minimised so it never covers anything)
    const w = await chrome.windows.create({url: 'about:blank', focused: false, state: 'minimized'});
    work = w.id;
    return work;
  }
  chrome.tabs.create = async function (props) {
    props = Object.assign({}, props || {});
    if (props.windowId === undefined || props.windowId === globalThis.__rkSigninWin) {
      try { props.windowId = await workWindow(); } catch {}
    }
    return orig(props);
  };
  // v75 (your rule: every store checks out AT THE SAME MOMENT): a checkout tab must be the ACTIVE tab of a window that is not minimised
  // (an inactive tab is not drawn and store buttons do nothing). One window cannot show two active tabs, so each store gets its OWN window.
  // Made with no place given, Chrome puts it where the buying browser's windows go (off-screen, set when it starts) - never focused.
  const making = {};
  async function checkoutWindow(store, tabId) {
    const t = await chrome.tabs.get(tabId);
    let w = null;
    if (own[store] != null) { try { w = await chrome.windows.get(own[store]); } catch { w = null; } }
    if (w && w.type === 'normal' && w.state !== 'minimized' && w.id !== globalThis.__rkSigninWin) {
      if (t.windowId !== w.id) await chrome.tabs.move(tabId, {windowId: w.id, index: -1});
      await chrome.tabs.update(tabId, {active: true});
      return w.id;
    }
    if (making[store]) { await making[store]; return checkoutWindow(store, tabId); }
    let done; making[store] = new Promise(r => { done = r; });
    try {
      const nw = await chrome.windows.create({tabId, focused: false, state: 'normal'});
      own[store] = nw.id;
      return nw.id;
    } finally { delete making[store]; done(); }
  }
  try { chrome.windows.onRemoved.addListener(id => { for (const [k, v] of Object.entries(own)) if (v === id) delete own[k]; }); } catch {}
  // v75 (diagnostics 64: the buying engine answered slowly - every state change made it read the WHOLE storage, the 12,000-line
  // diagnostics journal included, four times): the store checkouts' records are kept in memory here, updated as they change.
  globalThis.RestalkerRecs = (() => {
    const RX = /^(bb|tg|wm|gs):/, recs = new Map();
    let ready = null;
    const load = () => ready || (ready = chrome.storage.local.get(null).then(all => { for (const [k, v] of Object.entries(all)) if (RX.test(k) && v) recs.set(k, v); }).catch(() => { ready = null; }));
    try { chrome.storage.onChanged.addListener((ch, area) => { if (area !== 'local') return; for (const [k, c] of Object.entries(ch)) if (RX.test(k)) { if (c.newValue) recs.set(k, c.newValue); else recs.delete(k); } }); } catch {}
    void load();
    async function byPrefix(prefix) { await load(); return [...recs.entries()].filter(([k]) => k.startsWith(prefix)).map(([, v]) => v); }
    async function entries() { await load(); return [...recs.entries()]; }
    return {byPrefix, entries};
  })();
  globalThis.RestalkerWindows = {CODE: 'v103', workWindow, checkoutWindow, own: () => ({...own})};
})();
