"""Published prices (MSRP) and the prices we actually see.

MSRP of a row: (1) the number you typed in the table, else (2) the published price in msrp.yaml (shipped with the program),
else (3) calculated: the price of one pack x the number of packs in a box (12 for a Collector Booster Box, 30 for a Play Booster Box).
The table says which of the three it is. Unknown = blank (no guess).

Price notes: every price a store shows is remembered in price_stats.json (one sample per CHANGE of price, or one every 30 minutes
if the price stays the same, so a price that is checked every second does not count a thousand times). The table uses it for
"+x% over MSRP" and the diagnostics list the averages per product, so the price caps can be set from real numbers later.
"""
import json
import os
import threading
import time

import yaml

VERSION = "v103"
DATA = os.path.join(os.path.dirname(os.path.abspath(__file__)), "msrp.yaml")
STATS_PATH = "price_stats.json"
PACKS_PER_BOX = {"box": 12, "play_booster_box": 30}
SAME_PRICE_EVERY = 1800.0
SAVE_EVERY = 60.0

_lock = threading.Lock()
_known = {"mtime": None, "rows": {}}
_stats = {}
_loaded = [False]
_dirty = [False]
_saved_at = [0.0]


def known():
    """{row key: {msrp, how, note}} from msrp.yaml (re-read if the file changed)."""
    try:
        mt = os.path.getmtime(DATA)
    except OSError:
        return {}
    if _known["mtime"] != mt:
        try:
            with open(DATA, encoding="utf-8") as f:
                d = yaml.safe_load(f) or {}
            _known["rows"] = {str(k): dict(v) for k, v in (d.get("rows") or {}).items() if isinstance(v, dict) and v.get("msrp")}
        except Exception:
            _known["rows"] = {}
        _known["mtime"] = mt
    return _known["rows"]


def for_row(key, overrides=None):
    """-> {'value': 455.88, 'how': 'yours'|'published'|'calc', 'note': '...'} or None."""
    overrides = overrides or {}
    v = overrides.get(key)
    try:
        if v is not None and float(v) > 0:
            return {"value": round(float(v), 2), "how": "yours", "note": "the value you typed"}
    except (TypeError, ValueError):
        pass
    kn = known().get(key)
    if kn:
        src = kn.get("source")
        if not src and kn.get("how") == "calc":          # v63: a box worked out from its pack: the pack's source shows the pack price
            src = (known().get(f"{key.partition('|')[0]}|pack") or {}).get("source")
        return {"value": round(float(kn["msrp"]), 2), "how": kn.get("how", "published"), "note": str(kn.get("note", "")), "source": src}
    theme, _, kind = key.partition("|")
    n = PACKS_PER_BOX.get(kind or "box")
    if n:
        pk = f"{theme}|pack"
        pv = None
        try:
            if overrides.get(pk) is not None and float(overrides[pk]) > 0:
                pv = float(overrides[pk])
        except (TypeError, ValueError):
            pv = None
        if pv is None and known().get(pk):
            pv = float(known()[pk]["msrp"])
        if pv:
            return {"value": round(pv * n, 2), "how": "calc", "note": f"{n} packs x ${pv:.2f}", "source": (known().get(pk) or {}).get("source")}
    return None


def pct_over(price, msrp):
    try:
        return (float(price) / float(msrp) - 1.0) * 100.0
    except (TypeError, ValueError, ZeroDivisionError):
        return None


# ------------------------------------------------------------------ price notes
def _load():
    if _loaded[0]:
        return
    _loaded[0] = True
    try:
        with open(STATS_PATH, encoding="utf-8") as f:
            d = json.load(f)
        if isinstance(d, dict):
            _stats.update(d)
    except Exception:
        pass


def record(item_id, status, price, now=None):
    """One look at a link: remembers its price (in stock / out of stock). Cheap; safe to call for every look."""
    if price in (None, "") or status not in ("IN_STOCK", "OUT_OF_STOCK"):
        return
    try:
        price = round(float(price), 2)
    except (TypeError, ValueError):
        return
    if not 0.5 < price < 100000:
        return
    now = now or time.time()
    g = "in" if status == "IN_STOCK" else "out"
    with _lock:
        _load()
        s = _stats.setdefault(item_id, {}).setdefault(g, {"n": 0, "sum": 0.0, "min": price, "max": price, "last": None, "ts": 0.0})
        if s["last"] == price and now - s["ts"] < SAME_PRICE_EVERY:
            return
        s["n"] += 1
        s["sum"] = round(s["sum"] + price, 2)
        s["min"] = min(s["min"], price)
        s["max"] = max(s["max"], price)
        s["last"], s["ts"] = price, now
        _dirty[0] = True
        due = _dirty[0] and now - _saved_at[0] >= SAVE_EVERY
    if due:
        flush()


def flush():
    with _lock:
        if not _dirty[0]:
            return
        data = json.dumps(_stats)
        _dirty[0] = False
        _saved_at[0] = time.time()
    try:
        tmp = STATS_PATH + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            f.write(data)
        os.replace(tmp, STATS_PATH)
    except Exception:
        pass


def forget(ids):
    with _lock:
        _load()
        for i in ids:
            _stats.pop(i, None)
        _dirty[0] = True


def seen(ids):
    """Average / lowest / highest price seen over these links: {'in': {n, avg, min, max} or None, 'out': ...}."""
    out = {}
    with _lock:
        _load()
        for g in ("in", "out"):
            n = tot = 0
            lo = hi = None
            for i in ids:
                s = _stats.get(i, {}).get(g)
                if not s or not s.get("n"):
                    continue
                n += s["n"]
                tot += s["sum"]
                lo = s["min"] if lo is None else min(lo, s["min"])
                hi = s["max"] if hi is None else max(hi, s["max"])
            out[g] = {"n": n, "avg": round(tot / n, 2), "min": lo, "max": hi} if n else None
    return out


def report_text(rows, min_samples=1):
    """rows: [{'title','label','cap','msrp'(dict|None),'ids'[...]}]. Plain lines for the diagnostics."""
    lines = []
    for r in rows:
        sn = seen(r["ids"])
        m = r.get("msrp")
        mv = m["value"] if m else None
        cap = r.get("cap")
        txt = f"{r['title']} | {r['label']} | MSRP " + (f"${mv:.2f} ({m['how']})" if m else "unknown") + " | cap " + (f"${cap:g}" if cap else "none")
        if mv and cap:
            txt += f" ({pct_over(cap, mv):+.0f}% vs MSRP)"
        for g, nm in (("in", "in stock"), ("out", "out of stock")):
            s = sn.get(g)
            if s and s["n"] >= min_samples:
                p = f" ({pct_over(s['avg'], mv):+.0f}% vs MSRP)" if mv else ""
                txt += f" | {nm}: avg ${s['avg']:.2f}{p}, low ${s['min']:.2f}, high ${s['max']:.2f}, {s['n']} price(s)"
        lines.append(txt)
    return "\n".join(lines)
