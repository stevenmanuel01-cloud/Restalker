"""Keeps a few real page copies (in the 'samples' folder) so that anything
the program misreads can be fixed from the actual page instead of guessed.
Only a handful per product are kept (first of each kind), so the folder
stays small. API keys are blanked out before saving."""
import os
import re
import threading
from datetime import datetime, timezone

VERSION = "v103"
DIR = "samples"
MAX_PER_ITEM = 10
MAX_BYTES = 2_500_000
_LOCK = threading.Lock()
_seen = set()


def _clean(text):
    text = re.sub(r"(?is)<style\b.*?</style>", "", text)
    text = re.sub(r"(?is)<svg\b.*?</svg>", "", text)
    text = re.sub(r"data:image/[a-zA-Z+]+;base64,[A-Za-z0-9+/=]+", "data:image", text)
    text = re.sub(r"(?i)(api[_-]?key|apikey|key)=([^&\s\"'<>]+)", r"\1=REDACTED", text)
    return text


def save(item_id, kind, text, note="", force=False):
    """Save one page copy. Only the first of each (item, kind) is kept per
    program run, unless force=True (used for restock moments)."""
    try:
        if not text:
            return
        with _LOCK:
            key = (item_id, kind)
            if key in _seen and not force:
                return
            os.makedirs(DIR, exist_ok=True)
            mine = [f for f in os.listdir(DIR) if f.startswith(item_id + "__")]
            if len(mine) >= MAX_PER_ITEM and not force:
                return
            if len(mine) >= MAX_PER_ITEM * 2:
                return
            _seen.add(key)
            ts = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
            body = _clean(text)
            if len(body) > MAX_BYTES:
                body = body[:MAX_BYTES]
            name = f"{item_id}__{kind}__{ts}.html"
            with open(os.path.join(DIR, name), "w", encoding="utf-8", errors="replace") as f:
                f.write(f"<!-- saved {ts} UTC | {kind} | {note[:400]} -->\n{body}")
    except Exception:
        pass   # best effort, never disturb the watching
