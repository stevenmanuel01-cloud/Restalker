"""v137 (owner 2026-11-17: "contributors ... crowdsourcing the information for everyone to share" - chose "Build real sharing"):
the Restalker crowd. Every Restalker (PCs and phone apps) that has sharing on tells the others, on one public channel, when it sees a
product of the central list (mobile/catalog.json) come IN STOCK at a store - the product's Amazon code, the store, the price and the time.
Nothing else: no name, no account, no order, no address, no products of your own that are not on the central list. Each device has a
random contributor number (made here, not tied to anything) so the devices can be counted.

What a sighting from the crowd does here: the program LOOKS at that product at that store itself at once (like a tracker alert) - it
never buys on the crowd's word; it buys only what its own look sees in stock under YOUR cap. A false or old sighting therefore costs one
extra look at most (and each product is looked at no more than once every 2 minutes because of the crowd).
"""
import json
import os
import re
import secrets
import threading
import time
import urllib.request

VERSION = "v140"
SERVER = "https://ntfy.sh"
TOPIC = "restalker-crowd-5e1f0c7a92b4"
FILE = "crowd.json"
CATALOG_URL = "https://raw.githubusercontent.com/stevenmanuel01-cloud/Restalker/main/mobile/catalog.json"
STORES = ("Amazon", "Target", "Walmart", "Best Buy", "GameStop", "TCGplayer", "Barnes & Noble", "Costco", "Sam's Club", "Pokemon Center")
HELLO_EVERY = 6 * 3600
POLL_EVERY = 20
LOOK_GAP = 120                 # a product at a store is looked at no more than once in 2 minutes because of the crowd
LOOKS_PER_HOUR = 40
FIRST_SINCE = "12h"             # v139: the first read goes back 12 h (the channel keeps 12 h; everyone says hello every 6 h) - the count is right at once
SEEN_MAX = 20000
ASIN = re.compile(r"^B[0-9A-Z]{9}$")
LOG = print

_lock = threading.Lock()
_st = None
_cat = {"at": 0.0, "asins": set()}
_looked = {}                   # (asin, store) -> time looked because of the crowd
_hour = []                     # times of looks because of the crowd (last hour)
_stats = {"heard": 0, "shared": 0, "looks": 0, "ignored": 0, "error": "", "last": 0.0}


def _load():
    global _st
    if _st is None:
        try:
            with open(FILE, encoding="utf-8") as f:
                _st = json.load(f)
        except Exception:
            _st = {}
        if not re.fullmatch(r"[0-9a-f]{12}", str(_st.get("id") or "")):
            _st["id"] = secrets.token_hex(6)
        _st.setdefault("on", True)
        _st.setdefault("seen", {})
        _st.setdefault("since", "")
        _st.setdefault("hello", 0.0)
    return _st


def _save():
    try:
        tmp = FILE + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(_st, f)
        os.replace(tmp, FILE)
    except Exception:
        pass


def on():
    with _lock:
        return bool(_load().get("on"))


def set_on(v):
    with _lock:
        _load()["on"] = bool(v)
        _save()
    LOG(f"[crowd] sharing with the Restalker crowd switched {'ON' if v else 'OFF'}.")


def my_id():
    with _lock:
        return _load()["id"]


def count():
    """Every contributor heard so far (this one included) - the 'total contributors and counting'."""
    with _lock:
        s = _load()
        return len(set(s["seen"]) | {s["id"]})


def _catalog(http=None, now=None):
    """The central list's Amazon codes (fetched at most every 6 hours) - only these products are shared."""
    now = now or time.time()
    if now - _cat["at"] < 6 * 3600 and _cat["asins"]:
        return _cat["asins"]
    try:
        body = (http or _get)(CATALOG_URL)
        d = json.loads(body)
        a = {str(x.get("a")) for x in d.get("products") or [] if ASIN.match(str(x.get("a") or ""))}
        if a:
            _cat.update(at=now, asins=a)
    except Exception as e:
        _stats["error"] = f"central list: {str(e)[:80]}"
        _cat["at"] = now - 6 * 3600 + 600          # (try again in 10 minutes)
    return _cat["asins"]


def _get(url, timeout=25):
    req = urllib.request.Request(url, headers={"User-Agent": "Restalker/" + VERSION, "Cache-Control": "no-cache"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read(2_000_000).decode("utf-8", "replace")


def _post(obj, http=None):
    data = json.dumps(obj, separators=(",", ":")).encode()
    if http:
        return http(f"{SERVER}/{TOPIC}", data)
    req = urllib.request.Request(f"{SERVER}/{TOPIC}", data=data, method="POST",
                                 headers={"User-Agent": "Restalker/" + VERSION, "Title": "rk-crowd"})
    with urllib.request.urlopen(req, timeout=20) as r:
        return r.status


def clean(m, now=None):
    """One message from the channel -> a clean dict, or None (anything odd is dropped)."""
    now = now or time.time()
    if not isinstance(m, dict) or m.get("v") != 1:
        return None
    c = str(m.get("c") or "")
    if not re.fullmatch(r"[0-9a-f]{12}", c):
        return None
    k = m.get("k")
    if k == "h":
        return {"k": "h", "c": c}
    if k != "s":
        return None
    a, s, st = str(m.get("a") or ""), str(m.get("s") or ""), m.get("st")
    if not ASIN.match(a) or s not in STORES or st not in ("in", "out"):
        return None
    try:
        t = float(m.get("t"))
    except Exception:
        return None
    if abs(now - t) > 3600:                       # only fresh news
        return None
    p = m.get("p")
    p = float(p) if isinstance(p, (int, float)) and 0 < p < 100000 else None
    return {"k": "s", "c": c, "a": a, "s": s, "st": st, "p": p, "t": t}


def share(asin, store, st="in", price=None, http=None, now=None, catalog=None):
    """This program saw [asin] (a product of the central list) in stock at [store]: tell the crowd. -> True when sent."""
    now = now or time.time()
    if not on() or not ASIN.match(str(asin or "")) or store not in STORES or st not in ("in", "out"):
        return False
    if asin not in (catalog if catalog is not None else _catalog()):
        return False
    o = {"v": 1, "c": my_id(), "k": "s", "a": asin, "s": store, "st": st, "t": round(now, 1)}
    if isinstance(price, (int, float)) and 0 < price < 100000:
        o["p"] = round(float(price), 2)
    try:
        _post(o, http)
        _stats["shared"] += 1
        return True
    except Exception as e:
        _stats["error"] = f"share: {str(e)[:80]}"
        return False


def hello(http=None, now=None, force=False):
    """Every 6 hours: 'this contributor is here' (for the count)."""
    now = now or time.time()
    with _lock:
        s = _load()
        if not s.get("on") or (not force and now - float(s.get("hello") or 0) < HELLO_EVERY):
            return False
    try:
        _post({"v": 1, "c": my_id(), "k": "h"}, http)
        with _lock:
            _load()["hello"] = now
            _save()
        return True
    except Exception as e:
        _stats["error"] = f"hello: {str(e)[:80]}"
        return False


def take(lines, look, now=None):
    """Messages read from the channel (ntfy's json lines) -> contributors counted; a fresh in-stock sighting of another contributor
    makes [look](asin, store, price) run (at most once per product and store in LOOK_GAP, LOOKS_PER_HOUR in all)."""
    now = now or time.time()
    me = my_id()
    for line in lines:
        try:
            ev = json.loads(line)
        except Exception:
            continue
        if not isinstance(ev, dict):
            continue
        if ev.get("id"):
            with _lock:
                _load()["since"] = str(ev["id"])[:40]
        if ev.get("event") != "message":
            continue
        try:
            m = clean(json.loads(ev.get("message") or ""), now)
        except Exception:
            m = None
        if not m:
            _stats["ignored"] += 1
            continue
        _stats["heard"] += 1
        with _lock:
            seen = _load()["seen"]
            seen[m["c"]] = round(now)
            if len(seen) > SEEN_MAX:
                for k_ in sorted(seen, key=seen.get)[: len(seen) - SEEN_MAX]:
                    seen.pop(k_, None)
        if m["k"] != "s" or m["st"] != "in" or m["c"] == me or not on():
            continue
        key = (m["a"], m["s"])
        _hour[:] = [x for x in _hour if now - x < 3600]
        if now - _looked.get(key, 0) < LOOK_GAP or len(_hour) >= LOOKS_PER_HOUR:
            continue
        _looked[key] = now
        _hour.append(now)
        try:
            if look(m["a"], m["s"], m["p"]):
                _stats["looks"] += 1
        except Exception:
            pass
    with _lock:
        _save()


def poll(look, http=None, now=None):
    """One read of the channel (only what is new since the last read)."""
    with _lock:
        since = _load().get("since") or ""
    url = f"{SERVER}/{TOPIC}/json?poll=1&since={since or FIRST_SINCE}"      # v139: the first read hears every hello of the last 12 h
    try:
        body = (http or _get)(url)
        _stats["last"] = now or time.time()
        take(body.splitlines(), look, now)
        _stats["error"] = ""
    except Exception as e:
        _stats["error"] = f"read: {str(e)[:80]}"


def start(look, stop_event):
    """The program: read the channel every POLL_EVERY seconds; say hello every 6 hours."""
    def loop():
        while not stop_event.is_set():
            if on():
                hello()
                poll(look)
            stop_event.wait(POLL_EVERY)
    threading.Thread(target=loop, daemon=True, name="crowd").start()


def status_text():
    s = _stats
    return (f"Restalker crowd (v137): sharing {'ON' if on() else 'OFF'}; {count()} contributor(s) heard so far; this session: "
            f"{s['heard']} message(s) read, {s['shared']} sighting(s) shared, {s['looks']} look(s) because of the crowd, {s['ignored']} odd message(s) "
            f"dropped" + (f"; last problem: {s['error']}" if s['error'] else ""))
