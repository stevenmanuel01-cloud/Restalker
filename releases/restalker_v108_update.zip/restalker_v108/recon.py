"""The "recorder". It writes down what each store's page really sends, so that the way a store
reports stock never has to be guessed again.

What it keeps (small, in the 'recon' folder, API keys / e-mail addresses blanked out):
  * every data request a real product page makes (address, answer code, size) and, for the small
    data answers, what they say (the stock words in particular);
  * stock-looking words found inside the page itself;
  * at a restock moment (and just after), the same again - so an IN-STOCK page can be compared to an
    OUT-OF-STOCK page;
  * "control" readings: the same small stock request for a few OTHER products shown on the same page,
    so the words for 'in stock' are seen even while our own products are all sold out.
It is light: a product is recorded once at the start, again only every 30 min, and around restocks.
Nothing here ever changes what is monitored."""
import json
import os
import shutil
import re
import threading
import time
from datetime import datetime, timezone

VERSION = "v108"
DIR = "recon"
EVERY = 1800.0               # re-record the same product at most this often
MAX_PER_ITEM = 8             # files per product (restock-moment files can go a bit beyond)
MAX_TOTAL_BYTES = 7_000_000
MAX_BODY = 400_000           # larger data answers are not read
KEEP_BODY = 20000                 # characters kept from a data answer that carries stock words
KEEP_BODY_PLAIN = 500        # ... and from one that does not

_LOCK = threading.Lock()
_reg = {}                    # normalized url -> (item_id, store)
_last = {}                   # normalized url -> time of last recording
_force = {}                  # normalized url -> recordings still wanted soon
_count = {}                  # item_id -> files written
_reads = {}                  # item_id -> recent (time, status, price) readings, newest last
_watch = {}                  # item_id -> a tracker has just claimed a restock: keep recording this product for a while
_mcount = {}                 # item_id -> mention-related files written (separate allowance)
MAX_MENTION_MOMENTS = 6      # per product: "a tracker just claimed a restock" files
MAX_MENTION_NOTES = 24       # per product: the readings recorded after such a claim
WATCH_SECONDS = 300
WATCH_EVERY = 20
WATCH_MAX = 8                # readings recorded after each claim

STOCK_KEY = re.compile(
    r"(availab|stock|inventor|fulfil|orderable|sellable|buttonstate|button_state|buyable|purchasab|"
    r"addtocart|add_to_cart|soldout|sold_out|comingsoon|coming_soon|preorder|pre_order|shippable|"
    r"pickup|delivery|oos|backorder|cta|sku_status|saleable|isinstock|in_stock|outofstock)", re.I)
STOCK_PHRASE = re.compile(
    r"(add to cart|add to basket|sold out|out of stock|in stock|currently unavailable|coming soon|"
    r"pre-?order|notify me|get in line|see all buying options|not available|temporarily out|check stores?|"
    r"available for|ready within|buy now|only \d+ left|shop all|similar items?)", re.I)


def _norm(url):
    return re.sub(r"[?#].*$", "", url or "").rstrip("/").lower()


_every = {}                  # normalized url -> its own re-record interval (added "extra" products are recorded rarely)


def register(url, item_id, store="", every=None, skip_first=False):
    """every: re-record this product at most this often (default EVERY). skip_first: do not record it at the start
    (an added "extra" product; it is still recorded around a restock)."""
    with _LOCK:
        k = _norm(url)
        _reg[k] = (item_id, store)
        if every:
            _every[k] = every
        if skip_first:
            _last[k] = time.time()


def want(url):
    """True when the page being opened should be recorded now."""
    k = _norm(url)
    with _LOCK:
        if k not in _reg:
            return False
        if _force.get(k, 0) > 0:
            return True
        if _count.get(_reg[k][0], 0) >= MAX_PER_ITEM:
            return False
        return time.time() - _last.get(k, 0.0) >= _every.get(k, EVERY)


def force(url, n=2):
    """Record the next n page loads of this product (used around restocks)."""
    with _LOCK:
        k = _norm(url)
        if k in _reg:
            _force[k] = max(_force.get(k, 0), n)


_RUN_STARTED = False
PREV_DIR = "recon_prev"


def new_run():
    """Called once each time the program starts watching for the first time: last run's recordings are put aside
    (one generation kept), so old files can never fill the allowance or crowd this run's evidence out of the report."""
    global _RUN_STARTED
    with _LOCK:
        if _RUN_STARTED:
            return
        _RUN_STARTED = True
        try:
            if os.path.isdir(DIR) and os.listdir(DIR):
                if os.path.isdir(PREV_DIR):
                    shutil.rmtree(PREV_DIR, ignore_errors=True)
                try:
                    os.rename(DIR, PREV_DIR)
                except Exception:
                    # a file may be open; copy what we can, then clear the folder
                    os.makedirs(PREV_DIR, exist_ok=True)
                    for fn in os.listdir(DIR):
                        try:
                            shutil.move(os.path.join(DIR, fn), os.path.join(PREV_DIR, fn))
                        except Exception:
                            pass
        except Exception:
            pass


def note_read(item_id, status, price=None, err=None):
    """Remembers the last few readings of a product, so a tracker's claim can be compared with what we saw."""
    with _LOCK:
        L = _reads.setdefault(item_id, [])
        L.append((time.time(), status, price, (err or "")[:80] or None))
        if len(L) > 400:
            del L[:100]


def _write_m(item_id, tag, obj, cap):
    try:
        obj = json.loads(redact(json.dumps(obj, ensure_ascii=False, default=str)))
        obj["when_utc"] = datetime.now(timezone.utc).isoformat()
        with _LOCK:
            os.makedirs(DIR, exist_ok=True)
            n = _mcount.get((item_id, tag), 0)
            if n >= cap or not _size_ok(4_000_000):
                return None
            _mcount[(item_id, tag)] = n + 1
            stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S")
            path = os.path.join(DIR, f"{item_id}__{tag}{n + 1}__{stamp}.json")
            with open(path, "w", encoding="utf-8") as f:
                json.dump(obj, f, ensure_ascii=False, indent=0)
            return path
    except Exception:
        return None


def mention(item_id, url, info, age_sec=None):
    """A tracker has just claimed a restock of this product. Write down what WE saw around that time and
    keep recording what the store shows for the next few minutes."""
    now = time.time()
    back = (age_sec if isinstance(age_sec, (int, float)) else 120) + 180
    with _LOCK:
        recent = [(datetime.fromtimestamp(t, timezone.utc).strftime("%H:%M:%S"), st, pr, er)
                  for (t, st, pr, er) in _reads.get(item_id, []) if now - t <= back]
        _watch[item_id] = {"until": now + WATCH_SECONDS, "n": 0, "last": 0.0}
    if recent and len(recent) > 150:
        recent = recent[:75] + recent[-75:]
    force(url, 3)
    return _write_m(item_id, "mention_moment", {"item": item_id, "tracker_card": info, "card_age_sec": age_sec,
                                                "our_readings_in_that_period": recent,
                                                "readings_count": len(recent)}, MAX_MENTION_MOMENTS)


def watching(item_id):
    now = time.time()
    with _LOCK:
        w = _watch.get(item_id)
        return bool(w and now < w["until"] and w["n"] < WATCH_MAX and now - w["last"] >= WATCH_EVERY)


def watch_note(item_id, obj):
    with _LOCK:
        w = _watch.get(item_id)
        if not w:
            return None
        w["n"] += 1
        w["last"] = time.time()
        n = w["n"]
    obj = dict(obj)
    obj["after_mention_reading"] = n
    return _write_m(item_id, "after_mention", obj, MAX_MENTION_NOTES)


def redact(s):
    if not s:
        return s
    s = re.sub(r"(?i)((?:api[_-]?key|apikey|key|token|access_token|auth|authorization|session|sid|cookie)=)([^&\s\"'<>]+)",
               r"\1REDACTED", s)
    s = re.sub(r'(?i)("(?:api[_-]?key|apikey|token|access_token|authorization|x-api-key)"\s*:\s*")([^"]+)', r"\1REDACTED", s)
    s = re.sub(r"[\w.+-]+@[\w-]+\.[\w.-]+", "EMAIL", s)
    return s


def _clean(text):
    text = re.sub(r"(?is)<style\b.*?</style>", "", text)
    text = re.sub(r"(?is)<svg\b.*?</svg>", "", text)
    text = re.sub(r"data:image/[a-zA-Z+]+;base64,[A-Za-z0-9+/=]+", "data:image", text)
    return text


def key_values(text, limit=60):
    """Stock-looking  "name": value  pairs found in JSON-ish text, with how often each one appears."""
    found = {}
    for m in re.finditer(r'"([A-Za-z_][\w\-]{2,60})"\s*:\s*("(?:[^"\\]|\\.){0,60}"|true|false|null|-?\d{1,9}(?:\.\d+)?)', text or ""):
        name, val = m.group(1), m.group(2)
        if STOCK_KEY.search(name):
            key = f"{name}={val}"
            found[key] = found.get(key, 0) + 1
    items = sorted(found.items(), key=lambda kv: (-kv[1], kv[0]))
    return [f"{k}  (x{n})" for k, n in items[:limit]]


def phrases(html, limit=40, ctx=70):
    """Stock words as they appear in the visible page, each with a little text around it."""
    out, seen = [], set()
    if not html:
        return out
    plain = re.sub(r"(?is)<script\b.*?</script>", " ", html)
    plain = re.sub(r"(?s)<[^>]+>", " ", plain)
    plain = re.sub(r"\s+", " ", plain)
    for m in STOCK_PHRASE.finditer(plain):
        a, b = max(0, m.start() - ctx), min(len(plain), m.end() + ctx)
        snip = plain[a:b]
        key = m.group(1).lower()
        if (key, snip[:40]) in seen:
            continue
        seen.add((key, snip[:40]))
        out.append(snip)
        if len(out) >= limit:
            break
    return out


def describe_response(r):
    """Turns one browser response into a plain dict. Never raises."""
    d = {}
    try:
        req = r.request
        d["method"] = req.method
        d["type"] = req.resource_type
        d["url"] = r.url
        d["status"] = r.status
        h = r.headers
        d["ct"] = (h.get("content-type") or "")[:40]
        d["len"] = h.get("content-length")
        try:
            pd = req.post_data
            if pd:
                d["post"] = pd[:1500]
        except Exception:
            pass
        if req.resource_type in ("xhr", "fetch") and ("json" in d["ct"] or "text" in d["ct"] or not d["ct"]):
            # an answer that is still arriving (a live stream, a long wait) would make reading it wait forever
            still = "event-stream" in d["ct"]
            try:
                tm = req.timing
                if tm and tm.get("responseEnd", 0) is not None and tm.get("responseEnd", 0) < 0:
                    still = True
            except Exception:
                pass
            if still:
                d["body_err"] = "still arriving - not read"
                return d
            try:
                body = r.body()
                d["size"] = len(body)
                if len(body) <= MAX_BODY:
                    d["body"] = body.decode("utf-8", errors="replace")
            except Exception as e:
                d["body_err"] = str(e).split("\n")[0][:80]
    except Exception as e:
        d["err"] = str(e).split("\n")[0][:80]
    return d


def _detect(text, url=""):
    try:
        from stock_detect import detect_availability
        return detect_availability(text, hint=url)
    except Exception:
        return "?"


def _size_ok(extra=0):
    try:
        tot = sum(os.path.getsize(os.path.join(DIR, f)) for f in os.listdir(DIR))
        return tot < MAX_TOTAL_BYTES + extra
    except Exception:
        return True


def _write(item_id, tag, obj, forced=False):
    with _LOCK:
        os.makedirs(DIR, exist_ok=True)
        n = _count.get(item_id, 0)
        if n >= MAX_PER_ITEM * (2 if forced else 1) or not _size_ok():
            return None
        _count[item_id] = n + 1
        stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S")
        path = os.path.join(DIR, f"{item_id}__{tag}{n + 1}__{stamp}.json")
        with open(path, "w", encoding="utf-8") as f:
            json.dump(obj, f, ensure_ascii=False, indent=0)
        return path


def save(url, net, html, tag="page", note=""):
    """Writes one recording of a product page. Returns the list of data answers kept (or [])."""
    try:
        k = _norm(url)
        with _LOCK:
            item_id, store = _reg.get(k, ("unknown", ""))
            forced = _force.get(k, 0) > 0
            if forced:
                _force[k] -= 1
            _last[k] = time.time()
        reqs, bodies = [], []
        for d in net or []:
            line = {kk: d.get(kk) for kk in ("method", "type", "status", "ct", "len", "size") if d.get(kk) is not None}
            line["url"] = redact(d.get("url", ""))[:400]
            if d.get("post"):
                line["post"] = redact(d["post"])[:600]
            if d.get("body_err"):
                line["body_err"] = d["body_err"]
            reqs.append(line)
            body = d.get("body")
            if body:
                kv = key_values(body, 40)
                keep = KEEP_BODY if kv or STOCK_PHRASE.search(body) else KEEP_BODY_PLAIN
                bodies.append({"url": redact(d.get("url", ""))[:400], "status": d.get("status"),
                               "stock_fields": kv, "says": _detect(body, d.get("url", "")),
                               "text": redact(body[:keep])})
        clean = _clean(html or "")
        obj = {"item": item_id, "store": store, "url": redact(url), "when_utc": datetime.now(timezone.utc).isoformat(),
               "note": note, "restock_moment": forced,
               "page_says": _detect(html or "", url) if html else "?",
               "page_length": len(html or ""), "request_count": len(reqs),
               "page_stock_fields": key_values(clean, 60), "page_stock_words": phrases(html or ""),
               "requests": reqs[:250], "answers": bodies[:60]}
        _write(item_id, tag, obj, forced)
        return bodies
    except Exception:
        return []


def save_extra(item_id, tag, obj):
    """Writes any other small piece of evidence (a control reading, a note)."""
    try:
        obj = json.loads(redact(json.dumps(obj, ensure_ascii=False, default=str)))
        obj["when_utc"] = datetime.now(timezone.utc).isoformat()
        return _write(item_id, tag, obj, True)
    except Exception:
        return None


def related_ids(html, kind, own):
    """Other product numbers mentioned on the page (for 'control' readings of items that ARE in stock)."""
    pats = {"target": [r'"tcin"\s*:\s*"?(\d{7,10})', r"/A-(\d{7,10})"],
            "bestbuy": [r'"sku(?:Id)?"\s*:\s*"?(\d{7})', r"/(\d{7})\.p\b", r"skuId=(\d{7})"]}.get(kind, [])
    out = []
    for p in pats:
        for m in re.finditer(p, html or ""):
            v = m.group(1)
            if v != str(own) and v not in out:
                out.append(v)
    return out


def report(max_bytes=520_000):
    """Everything recorded so far, as plain text for the diagnostics file."""
    if not os.path.isdir(DIR) and not os.path.isdir(PREV_DIR):
        return "(nothing recorded yet)"
    files = [(DIR, fn, 0) for fn in (sorted(os.listdir(DIR)) if os.path.isdir(DIR) else [])]
    files += [(PREV_DIR, fn, 10) for fn in (sorted(os.listdir(PREV_DIR)) if os.path.isdir(PREV_DIR) else [])]
    out = [f"{sum(1 for x in files if x[2] == 0)} recording file(s) from this run in the 'recon' folder"
           + (f" (+{sum(1 for x in files if x[2])} from the run before, shown last)" if any(x[2] for x in files) else "")]
    budget = max_bytes
    loaded = []
    for d, fn, bump in files:
        try:
            with open(os.path.join(d, fn), encoding="utf-8") as f:
                o = json.load(f)
        except Exception as e:
            out.append(f"== {fn}: unreadable ({e})")
            continue
        if bump:
            fn = "(previous run) " + fn
        # most informative first: restock moments, control readings, then Target / Best Buy pages, then the rest
        pr = 0 if ("restock_moment" in fn or "mention_moment" in fn) else 1 if "control_" in fn else 2 if o.get("store") in ("target", "bestbuy") else 3
        if "after_mention" in fn:
            pr = 4
        loaded.append((pr + bump, o.get("when_utc", ""), fn, o))
    loaded.sort(key=lambda x: (x[0], x[1]))
    for _pr, _w, fn, o in loaded:
        blk = [f"== {fn}"]
        for k in ("item", "store", "when_utc", "note", "restock_moment", "page_says", "page_length", "request_count"):
            if k in o:
                blk.append(f"   {k}: {o[k]}")
        if o.get("page_stock_fields"):
            blk.append("   stock fields inside the page: " + "; ".join(o["page_stock_fields"][:40]))
        for p in (o.get("page_stock_words") or [])[:25]:
            blk.append(f"   page words: ...{p}...")
        for r in (o.get("requests") or []):
            if r.get("type") in ("xhr", "fetch", "document"):
                blk.append("   req " + " ".join(str(r.get(x)) for x in ("method", "status", "type", "size", "len")) + " " + r.get("url", "")[:260]
                           + (("  POST " + r["post"][:200]) if r.get("post") else ""))
        for a in (o.get("answers") or []):
            blk.append(f"   answer {a.get('status')} says={a.get('says')} {a.get('url', '')[:200]}")
            if a.get("stock_fields"):
                blk.append("      stock fields: " + "; ".join(a["stock_fields"][:25]))
            if a.get("stock_fields") or "tcin" in a.get("url", "") or "sku" in a.get("url", "").lower():
                blk.append("      text: " + (a.get("text") or "")[:6000].replace("\n", " "))
        for k in o:
            if k not in ("item", "store", "when_utc", "note", "restock_moment", "page_says", "page_length", "request_count",
                         "page_stock_fields", "page_stock_words", "requests", "answers", "url"):
                blk.append(f"   {k}: {json.dumps(o[k], ensure_ascii=False)[:9000]}")
        text = "\n".join(blk) + "\n"
        if len(text) > budget:
            text = text[:max(0, budget)] + "\n   (cut to keep the file small)\n"
        out.append(text)
        budget -= len(text)
        if budget <= 0:
            out.append("(more recordings exist in the 'recon' folder; cut to keep this file small)")
            break
    return "\n".join(out)
