"""Notices by itself that a game is being played, so Gaming mode can switch on and off without you.

A game is assumed when, for at least ~10 seconds, either
  * a program on the list of well-known games is running (cod.exe, fortnite, valorant, ... plus any exe name you add to the file
    game_programs.txt, one per line), or a program runs out of a games folder (Steam's steamapps\\common, Epic Games, Riot Games,
    Call of Duty, Xbox Games, ...), or
  * the window in front fills a whole screen (full-screen or borderless game window) and is not a browser, the desktop, a video
    player, Office, or this program.
It switches OFF again after about a minute without any of that (so a quick alt-tab does not end it).
Reading the list of running programs and the front window costs next to nothing. Windows only for the front-window check.
"""
import os
import re
import threading
import time

VERSION = "v108"
CHECK_EVERY = 5.0
ON_AFTER = 2          # checks in a row that must say "game" (x 5 s)
OFF_AFTER = 12        # checks in a row that must say "no game" (x 5 s = a minute)
USER_FILE = "game_programs.txt"

GAME_EXES = {
    "cod.exe", "cod25-cod.exe", "cod24-cod.exe", "codsp.exe", "blackops7.exe", "blackops6.exe", "modernwarfare.exe", "modernwarfare3.exe",
    "blackopscoldwar.exe", "s2_mp64_ship.exe", "s2_sp64_ship.exe", "warzone.exe",
    "fortniteclient-win64-shipping.exe", "valorant-win64-shipping.exe", "valorant.exe", "r5apex.exe", "cs2.exe", "csgo.exe",
    "league of legends.exe", "overwatch.exe", "rocketleague.exe", "gta5.exe", "gtav.exe", "eldenring.exe", "cyberpunk2077.exe",
    "rainbowsix.exe", "rainbowsix_vulkan.exe", "destiny2.exe", "dota2.exe", "pubg.exe", "tslgame.exe", "minecraft.exe",
    "baldursgate3.exe", "bg3.exe", "bg3_dx11.exe", "helldivers2.exe", "marvelrivals-win64-shipping.exe", "starfield.exe", "witcher3.exe",
    "hogwartslegacy.exe", "palworld-win64-shipping.exe", "diablo iv.exe", "wow.exe", "wowclassic.exe", "ffxiv_dx11.exe", "robloxplayerbeta.exe",
}
GAME_PATH_PARTS = ("\\steamapps\\common\\", "\\epic games\\", "\\riot games\\", "\\call of duty", "\\xboxgames\\", "\\ubisoft game launcher\\games\\",
                   "\\ea games\\", "\\origin games\\", "\\gog galaxy\\games\\", "\\blizzard\\", "\\battle.net\\games\\", "/steamapps/common/")
NOT_GAMES = {"wallpaper32.exe", "wallpaper64.exe", "ui32.exe", "steam.exe", "steamwebhelper.exe", "steamservice.exe", "epicgameslauncher.exe",
             "battle.net.exe", "agent.exe", "origin.exe", "ealauncher.exe", "easyanticheat.exe", "easyanticheat_eos.exe", "beservice.exe",
             # SteamVR's own helper programs run from the Steam games folder but are not games (v47: steamtours.exe kept Gaming mode ON all night)
             "steamtours.exe", "vrserver.exe", "vrmonitor.exe", "vrcompositor.exe", "vrdashboard.exe", "vrstartup.exe", "vrwebhelper.exe", "vrpathreg.exe", "vrcmd.exe", "vrservice.exe"}
NOT_GAME_NAME = re.compile(r"(launcher|crash|helper|installer|setup|unins|redist|updater|vc_redist|dxsetup|anticheat|eac_|battleye|overlay|webhelper|service)")
# programs that fill the screen but are not games
SKIP_FULLSCREEN = {"explorer.exe", "chrome.exe", "msedge.exe", "firefox.exe", "brave.exe", "opera.exe", "vivaldi.exe", "iexplore.exe",
                   "python.exe", "pythonw.exe", "py.exe", "code.exe", "devenv.exe", "vlc.exe", "mpc-hc64.exe", "potplayermini64.exe", "wmplayer.exe",
                   "powerpnt.exe", "winword.exe", "excel.exe", "onenote.exe", "outlook.exe", "teams.exe", "ms-teams.exe", "zoom.exe", "slack.exe",
                   "discord.exe", "obs64.exe", "applicationframehost.exe", "searchhost.exe", "shellexperiencehost.exe", "lockapp.exe", "taskmgr.exe",
                   "mstsc.exe", "vmware.exe", "virtualboxvm.exe", "cmd.exe", "powershell.exe", "windowsterminal.exe", "netflix.exe", "spotify.exe"}
SKIP_CLASSES = {"Progman", "WorkerW", "Shell_TrayWnd", "Shell_SecondaryTrayWnd"}

_lock = threading.Lock()
_st = {"on": False, "reason": "", "pos": 0, "neg": 0, "last_check": 0.0, "thread": None, "checks": 0}


def user_names():
    try:
        with open(USER_FILE, encoding="utf-8") as f:
            return {ln.strip().lower() for ln in f if ln.strip() and not ln.startswith("#")}
    except Exception:
        return set()


def classify(name, exe, extra=None):
    """Is this running program a game? -> reason text or ''."""
    n = (name or "").lower()
    if not n or n in NOT_GAMES:
        return ""
    if n in GAME_EXES or n in (extra or ()):
        return f"{name} is running"
    p = (exe or "").lower()
    if p and any(part in p for part in GAME_PATH_PARTS) and not NOT_GAME_NAME.search(n) and "\\steamvr\\" not in p:
        return f"{name} is running from a games folder"
    return ""


def _processes():
    import psutil
    out = []
    for p in psutil.process_iter(["name", "exe"]):
        try:
            out.append((p.info.get("name") or "", p.info.get("exe") or ""))
        except Exception:
            continue
    return out


def _foreground():
    """(program name, fills_a_whole_screen) of the window in front, or None. Windows only."""
    if os.name != "nt":
        return None
    import ctypes
    from ctypes import wintypes
    u = ctypes.windll.user32
    hwnd = u.GetForegroundWindow()
    if not hwnd:
        return None
    cls = ctypes.create_unicode_buffer(256)
    u.GetClassNameW(hwnd, cls, 256)
    if cls.value in SKIP_CLASSES:
        return None
    rc = wintypes.RECT()
    if not u.GetWindowRect(hwnd, ctypes.byref(rc)):
        return None

    class MONITORINFO(ctypes.Structure):
        _fields_ = [("cbSize", wintypes.DWORD), ("rcMonitor", wintypes.RECT), ("rcWork", wintypes.RECT), ("dwFlags", wintypes.DWORD)]
    mi = MONITORINFO()
    mi.cbSize = ctypes.sizeof(MONITORINFO)
    hmon = u.MonitorFromWindow(hwnd, 2)
    if not hmon or not u.GetMonitorInfoW(hmon, ctypes.byref(mi)):
        return None
    m = mi.rcMonitor
    full = rc.left <= m.left and rc.top <= m.top and rc.right >= m.right and rc.bottom >= m.bottom
    pid = wintypes.DWORD()
    u.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
    import psutil
    try:
        name = psutil.Process(pid.value).name()
    except Exception:
        name = ""
    return name, full


def detect():
    """One look. -> (is_game, reason)."""
    extra = user_names()
    try:
        for name, exe in _processes():
            why = classify(name, exe, extra)
            if why:
                return True, why
    except Exception:
        pass
    try:
        fg = _foreground()
        if fg:
            name, full = fg
            if full and name and name.lower() not in SKIP_FULLSCREEN and name.lower() != os.path.basename(__import__("sys").executable).lower():
                return True, f"{name} fills the whole screen"
    except Exception:
        pass
    return False, ""


def step(hit, reason):
    """Adds one look to the on/off decision. -> (changed, on, reason)."""
    with _lock:
        _st["checks"] += 1
        if hit:
            _st["pos"] += 1
            _st["neg"] = 0
            if not _st["on"] and _st["pos"] >= ON_AFTER:
                _st["on"], _st["reason"] = True, reason
                return True, True, reason
            if _st["on"]:
                _st["reason"] = reason
        else:
            _st["neg"] += 1
            _st["pos"] = 0
            if _st["on"] and _st["neg"] >= OFF_AFTER:
                _st["on"] = False
                r = _st["reason"]
                _st["reason"] = ""
                return True, False, "no game seen for a minute (was: " + r + ")"
        return False, _st["on"], _st["reason"]


def state():
    with _lock:
        return {"on": _st["on"], "reason": _st["reason"], "checks": _st["checks"]}


def start(on_change, log=None):
    """Background thread: calls on_change(on, reason) whenever the automatic decision changes."""
    with _lock:
        if _st["thread"] is not None and _st["thread"].is_alive():
            return _st["thread"]

    def loop():
        while True:
            try:
                hit, why = detect()
                changed, on, reason = step(hit, why)
                _st["last_check"] = time.time()
                if changed:
                    on_change(on, reason)
            except Exception as e:
                if log:
                    log(f"[pace] game check problem: {type(e).__name__}: {str(e)[:80]}")
            time.sleep(CHECK_EVERY)
    th = threading.Thread(target=loop, daemon=True, name="gamedetect")
    th.start()
    _st["thread"] = th
    return th
