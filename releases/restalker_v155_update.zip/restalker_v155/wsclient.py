"""A small WebSocket client (RFC 6455) on Python's own parts - Restalker installs nothing extra for it.

v151 (owner, 2026-11-24: "the capacity to receive thousands of users as well as send messages back to them in near zero latency"):
the PC keeps ONE connection to the Restalker relay open (relay.py). The relay pushes every new line down it the moment it arrives;
nothing is asked again and again. Text messages only (that is all the relay speaks); a ping is answered here."""
import base64, hashlib, os, socket, ssl, struct, threading, time, urllib.parse

VERSION = "v155"


class Closed(Exception):
    pass


class WS:
    def __init__(self, url, timeout=20.0):
        u = urllib.parse.urlsplit(url)
        tls = u.scheme == "wss"
        host, port = u.hostname, u.port or (443 if tls else 80)
        raw = socket.create_connection((host, port), timeout=timeout)
        raw.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        self.sock = ssl.create_default_context().wrap_socket(raw, server_hostname=host) if tls else raw
        key = base64.b64encode(os.urandom(16)).decode()
        path = (u.path or "/") + (("?" + u.query) if u.query else "")
        hostport = host if port in (80, 443) else f"{host}:{port}"
        self.sock.sendall((f"GET {path} HTTP/1.1\r\nHost: {hostport}\r\nUpgrade: websocket\r\nConnection: Upgrade\r\n"
                           f"Sec-WebSocket-Key: {key}\r\nSec-WebSocket-Version: 13\r\nUser-Agent: Restalker/{VERSION}\r\n\r\n").encode())
        head = b""
        while b"\r\n\r\n" not in head:
            part = self.sock.recv(4096)
            if not part:
                raise Closed("closed during the handshake")
            head += part
            if len(head) > 65536:
                raise Closed("handshake too long")
        head, rest = head.split(b"\r\n\r\n", 1)
        lines = head.decode("latin-1").split("\r\n")
        status = lines[0].split(" ", 2)
        self.status = int(status[1]) if len(status) > 1 and status[1].isdigit() else 0
        if self.status != 101:
            body = rest[:200].decode("utf-8", "replace")
            self._shut()
            raise Closed(f"refused: HTTP {self.status} {body}".strip())
        hdr = {k.strip().lower(): v.strip() for k, v in (ln.split(":", 1) for ln in lines[1:] if ":" in ln)}
        want = base64.b64encode(hashlib.sha1((key + "258EAFA5-E914-47DA-95CA-C5AB0DC85B11").encode()).digest()).decode()
        if hdr.get("sec-websocket-accept") != want:
            self._shut()
            raise Closed("not a WebSocket answer")
        self.buf = rest
        self.wlock = threading.Lock()
        self.open = True
        self.last_rx = time.time()
        self.frag = b""

    def _shut(self):
        try:
            self.sock.close()
        except Exception:
            pass

    def _frame(self, op, data):
        n = len(data)
        head = bytes([0x80 | op])
        if n < 126:
            head += bytes([0x80 | n])
        elif n < 65536:
            head += bytes([0x80 | 126]) + struct.pack(">H", n)
        else:
            head += bytes([0x80 | 127]) + struct.pack(">Q", n)
        mask = os.urandom(4)
        body = bytes(b ^ mask[i & 3] for i, b in enumerate(data)) if n < 4096 else (
            int.from_bytes(data, "big") ^ int.from_bytes((mask * (n // 4 + 1))[:n], "big")).to_bytes(n, "big")
        with self.wlock:
            self.sock.sendall(head + mask + body)

    def send(self, text):
        if not self.open:
            raise Closed("not open")
        self._frame(0x1, text.encode("utf-8"))

    def _parse(self):
        """-> (opcode, final, data) of the first whole frame in the buffer (and takes it out), or None when it is not all here yet."""
        b = self.buf
        if len(b) < 2:
            return None
        n, at = b[1] & 0x7F, 2
        if n == 126:
            if len(b) < 4:
                return None
            n, at = struct.unpack(">H", b[2:4])[0], 4
        elif n == 127:
            if len(b) < 10:
                return None
            n, at = struct.unpack(">Q", b[2:10])[0], 10
        if n > 8 * 1024 * 1024:
            raise Closed("message too long")
        mask = None
        if b[1] & 0x80:
            if len(b) < at + 4:
                return None
            mask, at = b[at:at + 4], at + 4
        if len(b) < at + n:
            return None
        data = b[at:at + n]
        self.buf = b[at + n:]
        if mask:
            data = bytes(x ^ mask[i & 3] for i, x in enumerate(data))
        return b[0] & 0x0F, bool(b[0] & 0x80), data

    def recv(self, timeout=30.0):
        """-> the next text message, or None when nothing came within `timeout` seconds. Raises Closed when the connection is over."""
        deadline = time.time() + timeout
        while True:
            f = self._parse()
            if f is None:
                left = deadline - time.time()
                if left <= 0:
                    return None
                self.sock.settimeout(max(0.05, left))
                try:
                    part = self.sock.recv(65536)
                except (socket.timeout, ssl.SSLWantReadError):
                    return None
                if not part:
                    self.open = False
                    raise Closed("the connection ended")
                self.buf += part
                continue
            op, fin, data = f
            self.last_rx = time.time()               # (anything at all from the relay: the connection is alive)
            if op == 0xA:
                continue                             # (the answer to our own ping)
            if op == 0x9:
                self._frame(0xA, data)
            elif op == 0x8:
                self.open = False
                code = struct.unpack(">H", data[:2])[0] if len(data) >= 2 else 1005
                try:
                    self._frame(0x8, data[:2])
                except Exception:
                    pass
                self._shut()
                raise Closed(f"closed by the relay ({code} {data[2:].decode('utf-8', 'replace')})".strip())
            elif op in (0x0, 0x1, 0x2):
                self.frag += data
                if fin:
                    out, self.frag = self.frag, b""
                    return out.decode("utf-8", "replace")

    def ping(self):
        """A protocol ping: answered by Cloudflare's edge itself - the relay is not woken, and it is not counted as a message."""
        self._frame(0x9, b"")

    def close(self):
        if self.open:
            self.open = False
            try:
                self._frame(0x8, struct.pack(">H", 1000))
            except Exception:
                pass
        self._shut()
