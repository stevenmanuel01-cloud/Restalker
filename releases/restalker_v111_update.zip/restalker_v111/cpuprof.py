"""v62: where the program's own Python time goes (for the diagnostics).

Twice a second this looks at what every thread of the program is doing at that moment and counts it. Threads that are only waiting
(sleeping, waiting for a page or a lock) are counted separately, so the list shows what really keeps the processor busy. Costs almost
nothing. Nothing personal is recorded - only the names of the program's own functions.
"""
import collections
import os
import sys
import threading
import time

VERSION = "v111"
_HERE = os.path.dirname(os.path.abspath(__file__))
_WAITS = {"wait", "sleep", "select", "poll", "acquire", "_wait_for_tstate_lock", "recv", "recv_into", "readinto", "accept", "read",
          "_sleep_or_stop", "join", "get", "sock_recv", "_run_once", "serve_forever", "readline", "_recv_bytes", "wait_for"}
_S = {"busy": collections.Counter(), "threads": collections.Counter(), "samples": 0, "started": 0.0, "lock": threading.Lock()}


def _ours(fr):
    return fr.f_code.co_filename.startswith(_HERE)


def _sample():
    me = threading.get_ident()
    names = {t.ident: t.name for t in threading.enumerate()}
    for tid, fr in sys._current_frames().items():
        if tid == me:
            continue
        top = fr.f_code.co_name
        if top in _WAITS:
            continue
        # the innermost frame that is the program's own code says what it is busy with
        f, own = fr, None
        while f is not None:
            if _ours(f):
                own = f
                break
            f = f.f_back
        where = f"{os.path.basename(own.f_code.co_filename)}:{own.f_code.co_name}" if own else f"(library) {top}"
        if own is not None and own is not fr:
            where += f" -> {top}"
        nm = names.get(tid, "?")
        nm = nm.split("-")[0] if nm.startswith("Thread-") else nm
        with _S["lock"]:
            _S["busy"][where] += 1
            _S["threads"][nm] += 1


def start():
    if _S["started"]:
        return
    _S["started"] = time.time()

    def loop():
        n = 0
        while True:
            time.sleep(0.5)
            try:
                _sample()
                n += 1
                _S["samples"] = n
                if n % 1200 == 0:                 # every 10 minutes the older half is forgotten (the list shows recent behaviour)
                    with _S["lock"]:
                        for c in (_S["busy"], _S["threads"]):
                            for k in list(c):
                                c[k] //= 2
                                if not c[k]:
                                    del c[k]
            except Exception:
                pass
    threading.Thread(target=loop, daemon=True, name="cpu-sampler").start()


def summary(n=15):
    with _S["lock"]:
        busy = _S["busy"].most_common(n)
        thr = _S["threads"].most_common(10)
        total = sum(_S["busy"].values()) or 1
    if not busy:
        return "not measured yet"
    lines = [f"{_S['samples']} looks (2 a second). What keeps the program's Python busy (share of busy moments):"]
    lines += [f"  {100.0 * c / total:5.1f}%  {w}" for w, c in busy]
    lines.append("busiest threads: " + ", ".join(f"{k} {100.0 * c / total:.0f}%" for k, c in thr))
    return "\n".join(lines)
