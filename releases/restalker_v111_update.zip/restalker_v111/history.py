"""v100: a product's restock history, short (owner 2026-11-05: "a popular style information windows could list simplified product
restock info. time date and bought or not bought along with super brief explanation").

Each line is one restock wave: the moments the program saw the product come back (ground_truth.csv, RESTOCK rows - one wave when the
stores restock within WAVE_GAP of each other) and the buying that followed (purchases.csv, buy_events.csv). A purchase or checkout
that came from an outside alert with no restock row of ours gets its own line. Read only - nothing here changes anything."""
from datetime import datetime

VERSION = "v111"

WAVE_GAP = 120          # s between two restock rows of one wave
AFTER = 900             # s after a wave's last restock row in which its checkouts and purchases count to it
BEFORE = 60
BUY_KINDS = ("CHECKOUT", "SUBMITTED", "BOUGHT", "OLDBOUGHT", "FAILED", "NOTFOUND", "UNKNOWN", "CHECK", "CVV", "APPROVE", "ACTION")


def _ts(s):
    try:
        return datetime.fromisoformat(str(s).strip().replace("Z", "+00:00")).timestamp()
    except Exception:
        return None


def _price(s):
    try:
        v = float(str(s).replace("$", "").replace(",", ""))
        return v if v > 0 else None
    except Exception:
        return None


def _brief(text, title):
    """'not bought - Walmart - X - ORDER NOT PLACED - sold out at checkout - nothing was ordered...' -> 'sold out at checkout'."""
    t = str(text or "")
    if title and t.startswith(title):
        t = t[len(title):]
    t = t.lstrip(" -—")
    for cut in (" - nothing was ordered", "; it is tried again", " - it is tried again"):
        i = t.find(cut)
        if i > 0:
            t = t[:i]
    for pre in ("ORDER NOT PLACED", "NOT BOUGHT"):
        if t.upper().startswith(pre):
            t = t[len(pre):].lstrip(" -—:")
    t = t.strip()
    return (t[:110].rstrip() + "...") if len(t) > 113 else t


def _why(evs):
    """The buy events of one wave -> (bought?, short reason) or None when there were none that tell."""
    kinds = [e["kind"] for e in evs]
    last = lambda k: next(e for e in reversed(evs) if e["kind"] == k)
    if "UNKNOWN" in kinds or ("CHECK" in kinds and "ORDERS" in last("CHECK").get("title", "").upper()):
        return False, "result not confirmed by the store - check your orders"
    if "CVV" in kinds:
        return False, "the store asked for the card's security code"
    if "APPROVE" in kinds:
        return False, "it waited for your shipping approval"
    for k in ("FAILED", "NOTFOUND"):
        if k in kinds:
            b = _brief(last(k).get("text"), last(k).get("title"))
            return False, b or "the checkout did not go through"
    acts = [e for e in evs if e["kind"] == "ACTION"]
    if acts:
        t = acts[-1].get("title", "")
        if "password" in t.lower() or "sign" in t.lower() or "show you are" in t.lower():
            return False, "the store wanted you to sign in or verify"
        if t.lower().startswith("not bought"):
            return False, _brief(acts[-1].get("text"), t) or "the checkout stopped"
    if "CHECK" in kinds:
        t = last("CHECK").get("title", "")
        for pre in ("ACTION NEEDED - ", "ACTION NEEDED: "):
            if t.startswith(pre):
                t = t[len(pre):]
        return False, ("it needed you: " + t)[:110]
    if "SUBMITTED" in kinds:
        return False, "the order was sent - the store did not confirm it"
    if "CHECKOUT" in kinds:
        return False, "a checkout started but no order was placed (likely sold out first)"
    return None


def build(ids, names, store_of, cap, gt_rows, purchases, events, wanted=None, now=None, limit=40):
    """ids: the product's row ids; names: its product names (for old purchases without a row id); store_of(id) -> store name;
    gt_rows: ground_truth.csv rows (lists); purchases: amazon_buy.purchases_list() rows; events: amazon_buy.buy_events_all() rows;
    wanted: True / False / None = is it set to Buy now. -> [{"t", "stores", "price", "bought", "why", "source"}], newest first."""
    ids = set(i for i in ids if i)
    names = set(n.strip().lower() for n in names if n)
    seeds = []
    for r in gt_rows:
        if len(r) < 3 or r[2] != "RESTOCK" or r[1] not in ids:
            continue
        t = _ts(r[0])
        if t:
            seeds.append((t, r[1], _price(r[6]) if len(r) > 6 else None))
    seeds.sort()
    waves = []
    for t, tid, pr in seeds:
        if waves and t - waves[-1]["end"] <= WAVE_GAP:
            w = waves[-1]
            w["end"] = t
        else:
            w = {"t": t, "end": t, "stores": [], "prices": [], "buys": [], "evs": [], "source": "seen by Restalker"}
            waves.append(w)
        s = store_of(tid)
        if s not in w["stores"]:
            w["stores"].append(s)
        if pr:
            w["prices"].append(pr)

    def home(t):
        for w in waves:
            if w["t"] - BEFORE <= t <= w["end"] + AFTER:
                return w
        w = {"t": t, "end": t, "stores": [], "prices": [], "buys": [], "evs": [], "source": "from an outside alert"}
        waves.append(w)
        waves.sort(key=lambda x: x["t"])
        return w

    mine = [p for p in purchases if (p.get("tid") in ids) or (not p.get("tid") and str(p.get("product", "")).strip().lower() in names)]
    for p in sorted(mine, key=lambda p: p["t"]):
        w = home(p["t"])
        w["buys"].append(p)
        if p.get("store") and p["store"] not in w["stores"]:
            w["stores"].append(p["store"])
    for e in sorted((e for e in events if e.get("tid") in ids and e.get("kind") in BUY_KINDS), key=lambda e: e["t"]):
        if e["kind"] in ("BOUGHT", "OLDBOUGHT"):
            continue                                   # (the purchase list holds the purchases themselves)
        w = home(e["t"])
        w["evs"].append(e)
        if not w["stores"] and e.get("tid"):
            w["stores"].append(store_of(e["tid"]))      # (a line from an outside alert: the store that checked out)
    out = []
    first_buy = min((p["t"] for p in mine), default=None)
    for w in waves:
        pr = min(w["prices"]) if w["prices"] else None
        if w["buys"]:
            b = w["buys"]
            why = ", ".join(f"{p.get('store') or 'store'}" + (f" ${p['price']:.2f}" if p.get("price") else "") +
                            (f" by {p['by']}" if p.get("by") and p["by"] != "the buying browser" else "") for p in b)
            out.append({"t": w["t"], "stores": w["stores"], "price": pr, "bought": True,
                        "why": ((f"{len(b)} bought: " if len(b) > 1 else "") + why), "source": w["source"]})
            continue
        r = _why(w["evs"])
        if r is None:
            if pr and cap and pr > cap + 0.004:
                r = (False, f"${pr:.2f} was over your cap ${cap:.2f}")
            elif first_buy is not None and first_buy < w["t"] - BEFORE and not wanted:
                r = (False, "one was already bought (one per product)")
            elif wanted is False:
                r = (False, "set to Searching - alerts only, never bought")
            else:
                r = (False, "no checkout was started")
        out.append({"t": w["t"], "stores": w["stores"], "price": pr, "bought": r[0], "why": r[1], "source": w["source"]})
    out.sort(key=lambda x: -x["t"])
    return out[:limit]
