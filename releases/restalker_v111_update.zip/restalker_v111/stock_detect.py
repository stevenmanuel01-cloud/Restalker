"""
Automatic stock-status detection.

Reads a page's own stock status without anyone hand-configuring button
text. Tried in order, most reliable first:

  0. The response is itself JSON (Shopify .json/.oembed, Best Buy's
     official API).
  1. schema.org JSON-LD   2. Open Graph product:availability
  3. microdata itemprop="availability"
  4. A retailer's own embedded data blob (Target's __TGT_DATA__,
     Next.js sites' __NEXT_DATA__ — Walmart and many others). Searched
     ONLY inside this product's own record when its ID is known (from
     the URL), so a "you may also like" product elsewhere on the page
     can't be mistaken for this one.
  5. Visible-text fallback (Amazon-style text, or the buy-box area
     near the product title).

Returns "IN_STOCK", "OUT_OF_STOCK", or "UNKNOWN".
"""
VERSION = "v111"   # checked by app.py so a half-copied update is caught immediately

import json
import re

from bs4 import BeautifulSoup
from bs4.element import Comment

_SKIP_TAGS = {"script", "style", "template", "noscript"}

# ---- cheap page reading -------------------------------------------------
# A retailer page is 1-3 MB, but the part that says whether the product can be
# bought is a small piece near the top. Building the full page tree took 1-7 s of
# processor time per check. So: drop scripts/styles/pictures first, keep only the
# first part of what is left, and build the tree ONCE per page (shared by the
# stock, price and evidence steps). If the short version cannot answer, the full
# page is read - same answers, much less work in the normal case.
import threading

_LEAN_RX = [re.compile(r"(?is)<script\b(?![^>]*ld\+json)[^>]*>.*?</script>"),
            re.compile(r"(?is)<style\b.*?</style>"),
            re.compile(r"(?is)<svg\b.*?</svg>"),
            re.compile(r"(?is)<noscript\b.*?</noscript>"),
            re.compile(r"(?s)<!--.*?-->"),
            re.compile(r"(?i)<(?:img|link|source|path|use)\b[^>]*>")]
SOUP_CAP = 350_000
_SOUP_CACHE = threading.local()


def get_soup(html, full=False):
    c = getattr(_SOUP_CACHE, "v", None)
    if c and c[0] is html and c[1] == full:
        return c[3]
    lean = html
    for rx in _LEAN_RX:
        lean = rx.sub("", lean)
    capped = False
    if not full and len(lean) > SOUP_CAP:
        cut = lean.rfind("<", 0, SOUP_CAP)
        lean, capped = lean[:cut if cut > 0 else SOUP_CAP], True
    soup = BeautifulSoup(lean, "html.parser")
    _SOUP_CACHE.v = (html, full, capped, soup)
    return soup


def was_capped(html):
    c = getattr(_SOUP_CACHE, "v", None)
    return bool(c and c[0] is html and not c[1] and c[2])


def _has_buy_area(soup, hint):
    if "amazon." in (hint or "").lower():
        return any(soup.find(id=i) for i in ("rightCol", "desktop_buybox", "buybox", "ppd"))
    return soup.find("h1") is not None


def _letters(s) -> str:
    """Lowercase and keep letters only, so 'In stock', 'IN_STOCK',
    'in-stock' and 'InStock' all compare equal."""
    return re.sub(r"[^a-z]", "", str(s).lower())


# ---------------------------------------------------------------- classify

def _classify(value):
    """schema.org / Open Graph / microdata availability values."""
    v = _letters(re.sub(r"^https?://schema\.org/", "", str(value).strip(), flags=re.IGNORECASE))
    if any(t in v for t in ("outofstock", "soldout", "discontinued", "unavailable", "notinstock")) or v == "oos":
        return "OUT_OF_STOCK"
    if any(t in v for t in ("instock", "limitedavailability", "instoreonly", "onlineonly")):
        return "IN_STOCK"
    return None


_BLOB_OOS = ("outofstock", "soldout", "unavailable", "notavailable", "notinstock",
             "discontinued", "nolongeravailable", "notsellable")
_BLOB_IN = ("instock", "limitedstock", "limitedavailability", "instoreonly", "onlineonly")


def _classify_blob_value(value):
    """Status strings found inside a retailer's own data blob."""
    v = _letters(value)
    if not v:
        return None
    if any(t in v for t in _BLOB_OOS):          # checked first: "unavailable" contains "available"
        return "OUT_OF_STOCK"
    if v == "available" or any(t in v for t in _BLOB_IN):
        return "IN_STOCK"
    return None


# ----------------------------------------------------------- json-ld etc.

def _search_jsonld(data):
    if isinstance(data, list):
        for item in data:
            r = _search_jsonld(item)
            if r:
                return r
        return None
    if not isinstance(data, dict):
        return None
    if "@graph" in data:
        r = _search_jsonld(data["@graph"])
        if r:
            return r
    offers = data.get("offers")
    if offers is not None:
        r = _search_jsonld(offers)
        if r:
            return r
    avail = data.get("availability")
    if avail:
        r = _classify(avail)
        if r:
            return r
    return None


def _search_shopify_json(data):
    """Shopify's public product JSON: {"product": {"variants": [{"available":
    bool}]}} (/products/<handle>.json) or {"offers": [{"in_stock": bool}]}
    (.oembed). Returns None if the data isn't that shape."""
    if not isinstance(data, dict):
        return None
    product = data.get("product")
    if isinstance(product, dict):
        variants = product.get("variants") or []
        if variants:
            return "IN_STOCK" if any(v.get("available") for v in variants) else "OUT_OF_STOCK"
    offers = data.get("offers")
    if isinstance(offers, list) and offers:
        vals = [o.get("in_stock") for o in offers if isinstance(o, dict) and "in_stock" in o]
        if vals:
            return "IN_STOCK" if any(vals) else "OUT_OF_STOCK"
    return None


def _search_bestbuy_api_json(data):
    """Best Buy's official Products API: {"products": [{"orderable": "...", "onlineAvailability": bool}]}.
    `orderable` mirrors the page's buy button (Available / SoldOut / ComingSoon)."""
    if not isinstance(data, dict):
        return None
    products = data.get("products")
    if isinstance(products, list) and products:
        p = products[0]
        if isinstance(p, dict):
            o = str(p.get("orderable", "")).strip().lower()
            if o in ("available", "preorder", "pre-order"):
                return "OUT_OF_STOCK" if p.get("onlineAvailability") is False else "IN_STOCK"
            if o in ("soldout", "sold out", "comingsoon", "coming soon", "notavailable", "unavailable"):
                return "OUT_OF_STOCK"
            if "onlineAvailability" in p:
                return "IN_STOCK" if p.get("onlineAvailability") else "OUT_OF_STOCK"
    return None


def parse_bestbuy_blocks(text):
    """Best Buy's own small data reply that its product pages use to draw the
    price and the buy button (it answers for several products at once).
    Reads it loosely on purpose, so a small change in its layout still works:
    for every product number it finds, the button word (ADD_TO_CART, SOLD_OUT
    ...), whether it is purchasable, and the current price.
    Returns {sku: {"state": str|None, "purchasable": bool|None, "price": float|None}}."""
    try:
        data = json.loads(text)
    except Exception:
        return {}
    out = {}

    def visit(node, sku, depth=0):
        if depth > 30:
            return
        if isinstance(node, dict):
            s = node.get("skuId") or node.get("sku") or node.get("skuid")
            if isinstance(s, (str, int)) and re.fullmatch(r"\d{5,9}", str(s)):
                sku = str(s)
            if sku:
                rec = out.setdefault(sku, {"state": None, "purchasable": None, "price": None})
                bs = node.get("buttonState")
                if isinstance(bs, str) and bs.strip():
                    rec["state"] = bs.strip().upper().replace(" ", "_").replace("-", "_")
                if isinstance(node.get("purchasable"), bool):
                    rec["purchasable"] = node["purchasable"]
                for k in ("currentPrice", "salePrice"):
                    if k in node and rec["price"] is None:
                        p = _num(node[k])
                        if p:
                            rec["price"] = p
            for k, v in node.items():
                visit(v, str(k) if re.fullmatch(r"\d{5,9}", str(k)) else sku, depth + 1)
        elif isinstance(node, list):
            for v in node:
                visit(v, sku, depth + 1)

    visit(data, None)
    return {k: v for k, v in out.items() if v["state"] or v["purchasable"] is not None or v["price"]}


def _bb_button_verdict(state, purchasable):
    if state in _BB_STATES_IN:
        return "IN_STOCK"
    if state in _BB_STATES_OUT:
        return "OUT_OF_STOCK"
    if state is None and purchasable is not None:
        return "IN_STOCK" if purchasable else "OUT_OF_STOCK"
    return None


def _search_rk_sweep(data):
    """v64: the compact record of a store sweep (sweep.py): {"rk_sweep": {"status": "IN_STOCK", "price": 12.34, ...}}."""
    if isinstance(data, dict) and isinstance(data.get("rk_sweep"), dict):
        st = str(data["rk_sweep"].get("status") or "")
        return st if st in ("IN_STOCK", "OUT_OF_STOCK") else "UNKNOWN"
    return None


def _search_bb_button(data):
    """The compact record our own Best Buy reader writes: {"bb_button": {...}}."""
    if isinstance(data, dict) and isinstance(data.get("bb_button"), dict):
        b = data["bb_button"]
        return _bb_button_verdict(b.get("state"), b.get("purchasable")) or "UNKNOWN"
    return None


# ------------------------------------------------ embedded-blob extraction

def _scan_js_string(text, i):
    """text[i] is a quote character. Returns (literal_including_quotes,
    end_index) for the JS string literal starting there, or (None, i)."""
    q = text[i]
    j = i + 1
    while True:
        p = text.find(q, j)
        if p == -1:
            return None, i
        backslashes = 0
        z = p - 1
        while z > i and text[z] == "\\":
            backslashes += 1
            z -= 1
        if backslashes % 2 == 0:
            return text[i:p + 1], p + 1
        j = p + 1


def _decode_js_string(lit):
    """Turn a JS string literal (with its quotes) into the text it
    represents. JS and JSON string escapes mostly coincide; handle the
    few that don't (\\xNN, \\', line continuations)."""
    q = lit[0]
    if q == '"':
        try:
            return json.loads(lit, strict=False)
        except Exception:
            pass
    s = lit[1:-1]
    s = re.sub(r"\\x([0-9a-fA-F]{2})", r"\\u00\1", s)
    s = s.replace("\\'", "'").replace("\\\n", "")
    if q == "'":
        s = re.sub(r'(?<!\\)"', r'\\"', s)
    try:
        return json.loads('"' + s + '"', strict=False)
    except Exception:
        return None


_BRACKET = re.compile(r'["{}\[\]]')


def _scan_balanced(text, i):
    """text[i] is '{' or '['. Returns the exact balanced JSON text,
    correctly skipping brackets inside string values."""
    depth = 0
    j = i
    n = len(text)
    while j < n:
        m = _BRACKET.search(text, j)
        if not m:
            return None
        c = m.group()
        p = m.start()
        if c == '"':
            k = p + 1
            while True:
                q = text.find('"', k)
                if q == -1:
                    return None
                b = 0
                z = q - 1
                while z > p and text[z] == "\\":
                    b += 1
                    z -= 1
                if b % 2 == 0:
                    break
                k = q + 1
            j = q + 1
            continue
        if c in "{[":
            depth += 1
        else:
            depth -= 1
            if depth == 0:
                return text[i:p + 1]
        j = p + 1
    return None


def _json_loads_maybe_double(text):
    data = json.loads(text, strict=False)
    if isinstance(data, str) and data.strip()[:1] in ("{", "["):
        data = json.loads(data, strict=False)
    return data


def _extract_script_var_json(html: str, name: str):
    """Pull the JSON a page stores under a variable/script name. Handles
    the forms real retailers use:
      <script id="__NEXT_DATA__">{...}</script>          (Next.js)
      window.NAME = {...};                               (plain object)
      NAME: {value: deepFreeze(JSON.parse("...escaped...")) }   (Target)
    Returns the parsed object, or None."""
    m = re.search(r'<script[^>]*\bid\s*=\s*["\']' + re.escape(name) + r'["\'][^>]*>(.*?)</script>',
                  html, re.DOTALL | re.IGNORECASE)
    if m:
        try:
            data = _json_loads_maybe_double(m.group(1).strip())
            if isinstance(data, (dict, list)) and data:
                return data
        except Exception:
            pass

    pos = 0
    for _ in range(12):
        idx = html.find(name, pos)
        if idx == -1:
            break
        pos = idx + len(name)
        tail = html[pos:pos + 1500]
        wrapped_first = bool(re.search(r"JSON\s*\.\s*parse", tail[:400]))

        def try_assignment():
            m1 = re.match(r"""["']?\s*[:=]\s*([\{\[])""", tail)
            if not m1:
                return None
            cand = _scan_balanced(html, pos + m1.start(1))
            if not cand:
                return None
            try:
                data = _json_loads_maybe_double(cand)
                return data if isinstance(data, (dict, list)) and data else None
            except Exception:
                return None

        def try_wrapped():
            m2 = re.search(r"""JSON\s*\.\s*parse\s*\(\s*(?=["'])""", tail)
            if not m2:
                return None
            lit, _end = _scan_js_string(html, pos + m2.end())
            if not lit:
                return None
            decoded = _decode_js_string(lit)
            if not decoded:
                return None
            try:
                data = _json_loads_maybe_double(decoded)
                return data if isinstance(data, (dict, list)) and data else None
            except Exception:
                return None

        for attempt in ((try_wrapped, try_assignment) if wrapped_first else (try_assignment, try_wrapped)):
            data = attempt()
            if data is not None:
                return data
    return None


# --------------------------------------------- searching inside a blob

_ID_KEYS = {"tcin", "usitemid", "itemid", "productid", "sku", "skuid", "partnumber"}


def _product_id_from_hint(hint: str):
    """Pull this product's own ID out of its URL, when the retailer's URL
    format is one we know (Target .../A-<tcin>, Walmart .../ip/.../<id>)."""
    if not hint:
        return None
    for pat in (r"/A-(\d{5,})", r"/ip/(?:[^/?#]+/)?(\d{5,})",
                r"bestbuy\.com/product/[^/?#]+/([A-Z0-9]{8,14})",
                r"gamestop\.com/.+/(\d{5,9})\.html"):
        m = re.search(pat, hint)
        if m:
            return m.group(1)
    return None


def _find_scoped_nodes(node, pid, found, depth=0):
    """Collect every dict that is this product's own record (it carries
    this product's ID under a known id-like key)."""
    if depth > 40:
        return
    if isinstance(node, dict):
        for k, v in node.items():
            if _letters(k) in _ID_KEYS and str(v) == pid:
                found.append(node)
                break
        for v in node.values():
            if isinstance(v, (dict, list)):
                _find_scoped_nodes(v, pid, found, depth + 1)
    elif isinstance(node, list):
        for item in node:
            _find_scoped_nodes(item, pid, found, depth + 1)


def _collect_statuses(node, out, depth=0):
    """Gather every availability-looking field under `node` as
    (status, key) pairs."""
    if depth > 40 or len(out) > 5000:
        return
    if isinstance(node, dict):
        for k, v in node.items():
            kl = _letters(k)
            if isinstance(v, bool):
                if "soldout" in kl or "outofstock" in kl:
                    out.append(("OUT_OF_STOCK" if v else "IN_STOCK", k))
                elif kl in ("instock", "isinstock"):
                    out.append(("IN_STOCK" if v else "OUT_OF_STOCK", k))
            elif isinstance(v, str) and ("availability" in kl or kl in (
                    "stockstatus", "fulfillmentstatus", "inventorystatus")):
                c = _classify_blob_value(v)
                if c:
                    out.append((c, k))
            if isinstance(v, (dict, list)):
                _collect_statuses(v, out, depth + 1)
    elif isinstance(node, list):
        for item in node:
            _collect_statuses(item, out, depth + 1)


def _verdict(statuses):
    kinds = {s for s, _ in statuses}
    if "IN_STOCK" in kinds:
        return "IN_STOCK"          # buyable anywhere/any way = restocked
    if "OUT_OF_STOCK" in kinds:
        return "OUT_OF_STOCK"
    return None


def _first_status(node, depth=0):
    """Unscoped fallback (product ID unknown): first availability field
    found in document order."""
    out = []
    _collect_statuses(node, out)
    return out[0][0] if out else None


def _shipping_statuses(node, out, depth=0):
    """Availability strings found inside a record's online-ordering
    ('shipping options') section, if it has one."""
    if depth > 40:
        return
    if isinstance(node, dict):
        for k, v in node.items():
            if _letters(k) in ("shippingoptions", "shippingoption", "shipping"):
                _collect_statuses_strings(v, out)
            elif isinstance(v, (dict, list)):
                _shipping_statuses(v, out, depth + 1)
    elif isinstance(node, list):
        for item in node:
            _shipping_statuses(item, out, depth + 1)


def _collect_statuses_strings(node, out, depth=0):
    """Like _collect_statuses but only explicit status words (no yes/no
    flags such as 'out of stock in ALL stores', which turn false the
    moment any single nearby store has one)."""
    if depth > 40 or len(out) > 500:
        return
    if isinstance(node, dict):
        for k, v in node.items():
            kl = _letters(k)
            if isinstance(v, str) and "availability" in kl:
                c = _classify_blob_value(v)
                if c:
                    out.append((c, k))
            elif isinstance(v, (dict, list)):
                _collect_statuses_strings(v, out, depth + 1)
    elif isinstance(node, list):
        for item in node:
            _collect_statuses_strings(item, out, depth + 1)


def _search_embedded_blob(data, product_id=None):
    if product_id:
        nodes = []
        _find_scoped_nodes(data, product_id, nodes)
        # Online ordering comes first: when the product's own record has
        # an explicit shipping/online status, THAT is the answer. A single
        # nearby store having stock must not count as a restock.
        ship = []
        for n in nodes:
            _shipping_statuses(n, ship)
        if ship:
            return _verdict(ship)
        statuses = []
        for n in nodes:
            _collect_statuses(n, statuses)
        # Scoped or nothing: if this product's own record can't be found,
        # do NOT fall back to scanning the whole page.
        return _verdict(statuses)
    return _first_status(data)


def status_evidence(html: str, hint: str = "") -> str:
    """One short line saying WHICH fields on the page produced the
    verdict - written to the log whenever a store reads in stock, so a
    wrong reading can be diagnosed from the log instead of guessed at."""
    if html.lstrip().startswith('{"bb_button"'):
        return "best buy data: " + html.strip()[:300]
    pid = _product_id_from_hint(hint)
    parts = []
    for name in ("__TGT_DATA__", "__NEXT_DATA__"):
        if name in html:
            blob = _extract_script_var_json(html, name)
            if blob and pid:
                nodes, ship, allst = [], [], []
                _find_scoped_nodes(blob, pid, nodes)
                for n in nodes:
                    _shipping_statuses(n, ship)
                    _collect_statuses(n, allst)
                parts.append(f"records={len(nodes)} online={[f'{k}={v}' for v, k in ship][:4]} "
                             f"all={[f'{k}={v}' for v, k in allst][:10]}")
            elif blob:
                parts.append("blob found but no product id in URL")
    try:
        _soup = get_soup(html)
        _bb = [e.get("data-button-state") for e in _soup.find_all(attrs={"data-button-state": True})][:4]
        if _bb:
            parts.append(f"best buy button states={_bb}")
        if "gamestop.com" in (hint or "").lower():
            parts.append(f"gamestop rule={_gamestop_status(_soup)}")
        region = _buybox_text(_soup)
        if region:
            parts.append("page text near title: " + region[:450])
    except Exception:
        pass
    return " | ".join(parts) or "no structured data; text only"


# ------------------------------------------------------- visible-text path

_OOS_PHRASES = [
    "we don't know when or if this item will be back in stock",
    "currently unavailable",
    "temporarily out of stock",
    "out of stock",
    "no longer available",
    "sold out",
    "coming soon",
]
_IN_PHRASES = [
    "in stock",
    "available from these sellers",
    "usually ships within",
    "ships from and sold by",
]
_CART_PHRASES = ("add to cart", "add to bag")


def _visible_strings(node):
    for s in node.find_all(string=True):
        if isinstance(s, Comment):
            continue
        if s.parent is not None and s.parent.name in _SKIP_TAGS:
            continue
        yield s


def _buybox_text(soup, limit=1800):
    """The visible text starting at the product title (first <h1>) — the
    area where a page states whether THIS product can be bought, as
    opposed to the recommendations further down."""
    h1 = soup.find("h1")
    if not h1:
        return None
    chunks, total = [], 0
    for s in h1.find_all_next(string=True):
        if isinstance(s, Comment) or (s.parent is not None and s.parent.name in _SKIP_TAGS):
            continue
        t = " ".join(str(s).split())
        if not t:
            continue
        chunks.append(t)
        total += len(t) + 1
        if total >= limit:
            break
    return " ".join(chunks).lower()


def _phrase_verdict(text, allow_cart=False):
    for p in _OOS_PHRASES:
        if p in text:
            return "OUT_OF_STOCK"
    for p in _IN_PHRASES:
        if p in text:
            return "IN_STOCK"
    if allow_cart and any(p in text for p in _CART_PHRASES):
        return "IN_STOCK"
    return None


def _first_verdict(text):
    """Near a product's own title, the FIRST stock wording is the one that
    belongs to that product; wording further down is usually another
    product (recommendations). So pick whichever appears earliest."""
    best = None
    def consider(phrases, verdict):
        nonlocal best
        for p in phrases:
            i = text.find(p)
            if i != -1 and (best is None or i < best[0]):
                best = (i, verdict)
    consider(_OOS_PHRASES + ["not in stock"], "OUT_OF_STOCK")
    consider(_IN_PHRASES + list(_CART_PHRASES), "IN_STOCK")
    return best[1] if best else None


TARGET_KNOWN_KEY = "9f36aeafbe60771e321a7cc95a78140772ab3e96"


def _tgt_where(ctx):
    """Place details for Target's requests: what Target's own page used for this visitor (when known),
    otherwise a generic city."""
    c = ctx or {}
    store = c.get("store_id") or "3991"
    zipc = c.get("zip") or "55403"
    state = c.get("state") or "MN"
    lat = c.get("latitude") or "44.9690"
    lon = c.get("longitude") or "-93.2730"
    vid = c.get("visitor_id") or "0123456789ABCDEF0123456789ABCDEF"
    return store, f"zip={zipc}&state={state}&latitude={lat}&longitude={lon}", f"visitor_id={vid}"


def target_api_url(tcin, key=TARGET_KNOWN_KEY, ctx=None):
    store, where, vid = _tgt_where(ctx)
    return ("https://redsky.target.com/redsky_aggregations/v1/web/pdp_client_v1"
            f"?key={key}&tcin={tcin}&pricing_store_id={store}&store_id={store}"
            f"&has_pricing_store_id=true&{vid}")


def target_fulfillment_urls(tcin, key=TARGET_KNOWN_KEY, ctx=None):
    """Target's product-availability requests (the ones that carry the ONLINE stock word).
    A few forms of the same request, most complete first."""
    base = "https://redsky.target.com/redsky_aggregations/v1/web/"
    store, where, vid = _tgt_where(ctx)
    return [
        (f"{base}pdp_fulfillment_v1?key={key}&tcin={tcin}&store_id={store}&has_store_id=true&{where}"
         f"&scheduled_delivery_store_id={store}&required_store_id={store}&has_required_store_id=true"
         f"&pricing_store_id={store}&is_bot=false&channel=WEB&{vid}"),
        f"{base}pdp_fulfillment_v1?key={key}&tcin={tcin}&store_id={store}&has_store_id=true&{where}&is_bot=false&{vid}",
        (f"{base}product_fulfillment_v1?key={key}&is_bot=false&tcin={tcin}&store_id={store}&{where}"
         f"&scheduled_delivery_store_id={store}&required_store_id={store}&has_required_store_id=true&channel=WEB&{vid}"),
    ]


def json_clues(text, limit=700, stock_only=False):
    """A short, key-names-only picture of a JSON answer (no personal data), for diagnostics:
    which parts exist, any stock-looking words, and any error messages."""
    import json as _json
    try:
        obj = _json.loads(text)
    except Exception:
        return "not JSON: " + (text or "")[:120].replace("\n", " ")
    out, errs = [], []
    if isinstance(obj, dict) and isinstance(obj.get("errors"), list):
        for e in obj["errors"][:3]:
            if isinstance(e, dict):
                errs.append("ERROR: " + str(e.get("message", ""))[:110])

    def walk(o, path, depth):
        if len(out) > 80 or depth > 8:
            return
        if isinstance(o, dict):
            for k, v in o.items():
                p = f"{path}.{k}" if path else str(k)
                if isinstance(v, (dict, list)):
                    if depth < 4 and not stock_only:
                        out.append(p + ("{}" if isinstance(v, dict) else "[]"))
                    walk(v, p, depth + 1)
                elif re.search(r"avail|stock|sold|inventory|sellable|status", str(k), re.I):
                    out.append(f"{p}={str(v)[:30]}")
        elif isinstance(o, list):
            for i, v in enumerate(o[:2]):
                walk(v, f"{path}[{i}]", depth + 1)
    walk(obj, "", 0)
    return (" ; ".join(errs) + (" ; " if errs and out else "") + ", ".join(out))[:limit]


def _search_target_api_json(parsed):
    """Target's own product-data service: data.product.fulfillment
    .shipping_options.availability_status is the ONLINE status."""
    try:
        prod = parsed["data"]["product"]
    except Exception:
        return None
    ful = prod.get("fulfillment") if isinstance(prod, dict) else None
    if not isinstance(ful, dict):
        return None
    ship = ful.get("shipping_options")
    st = ship.get("availability_status") if isinstance(ship, dict) else None
    if not st:
        return None
    st = str(st).upper()
    if st in ("IN_STOCK", "LIMITED_STOCK", "PRE_ORDER_SELLABLE"):
        return "IN_STOCK"
    if st in ("OUT_OF_STOCK", "UNAVAILABLE", "NOT_SOLD_ONLINE", "PRE_ORDER_UNSELLABLE", "NOT_AVAILABLE"):
        return "OUT_OF_STOCK"
    return None


def _gamestop_status(soup):
    """GameStop: 'Currently Unavailable' near the top of the product area
    means out of stock (its legend line 'Out of stock In stock unavailable'
    is on every page, so it is not used). Otherwise a real Add to Cart /
    Pre-Order button that is not part of the GameStop Pro membership box
    means in stock."""
    region = _buybox_text(soup, limit=3000) or ""
    if "currently unavailable" in region:
        return "OUT_OF_STOCK"
    h1 = soup.find("h1")
    it = h1.find_all_next(["button", "a", "input"]) if h1 else soup.find_all(["button", "a", "input"])
    for i, b in enumerate(it):
        if i > 400:
            break
        txt = " ".join((b.get_text(" ") or b.get("value") or "").split()).lower()
        if txt not in ("add to cart", "pre-order", "preorder", "pre order", "buy now"):
            continue
        if b.has_attr("disabled") or (b.get("aria-disabled") or "").lower() == "true":
            continue
        up, bad = b, False
        for _ in range(4):
            up = up.parent
            if up is None or up.name in ("body", "html", "main", "form"):
                break
            t = up.get_text(" ", strip=True).lower()
            if len(t) < 1200 and ("gamestop pro" in t or "pro member" in t or "membership" in t
                                  or "powerup" in t):
                bad = True
                break
        if not bad:
            return "IN_STOCK"
    return None


_BB_STATES_IN = {"ADD_TO_CART", "PRE_ORDER", "PREORDER"}
_BB_STATES_OUT = {"SOLD_OUT", "COMING_SOON", "CHECK_STORES", "UNAVAILABLE_NEARBY",
                  "NOT_AVAILABLE", "UNAVAILABLE", "OUT_OF_STOCK", "NO_PRICE",
                  "IN_STORE_ONLY", "FIND_A_STORE", "STORE_PICKUP_ONLY", "NO_RECORD"}   # (not buyable online / Best Buy has no listing yet)
_BB_TEXT_IN = {"add to cart", "pre-order", "preorder", "pre order"}
_BB_TEXT_OUT = {"sold out", "coming soon", "check stores", "unavailable nearby", "unavailable", "not available"}


def _bestbuy_button_state(soup):
    """Best Buy's own purchase button: first by its data-button-state
    marker, else by the button's words ("Sold Out", "Add to Cart"...).
    Only the first such button after the product title counts - buttons
    on recommended products come later on the page."""
    for el in soup.find_all(attrs={"data-button-state": True}):
        st = (el.get("data-button-state") or "").strip().upper()
        if st in _BB_STATES_IN:
            return "IN_STOCK"
        if st in _BB_STATES_OUT:
            return "OUT_OF_STOCK"
    h1 = soup.find("h1")
    it = h1.find_all_next(["button", "a", "input"]) if h1 else soup.find_all(["button", "a", "input"])
    for i, el in enumerate(it):
        if i > 600:
            break
        txt = " ".join((el.get_text(" ") or el.get("value") or "").split()).lower()
        if txt in _BB_TEXT_IN:
            return "IN_STOCK"
        if txt in _BB_TEXT_OUT:
            return "OUT_OF_STOCK"
    return None


def _amazon_no_real_offer(soup):
    """Amazon shows 'No featured offers available' or a 'High price' label
    in place of a price when only expensive resellers have it."""
    for box_id in ("desktop_buybox", "buybox", "rightCol", "mbc", "ppd"):
        box = soup.find(id=box_id)
        if box:
            t = box.get_text(" ").lower()
            if "no featured offers" in t or "high price" in t:
                return True
    return False


def _amazon_has_buying_options(soup):
    """Amazon sometimes shows "See All Buying Options" instead of "Add to
    Cart" when stock is available from sellers. Look only in the buy box
    itself - other products' cards on the page say it too."""
    if soup.find(id="buybox-see-all-buying-choices") or soup.find(id="buybox-see-all-buying-choices-announce"):
        return True
    for box_id in ("desktop_buybox", "buybox", "buyBoxAccordion", "rightCol", "mbc"):
        box = soup.find(id=box_id)
        if box and "buying options" in box.get_text(" ").lower():
            return True
    return False


def amazon_other_sellers_only(html):
    """Amazon page whose only 'buy' choice is 'See All Buying Options' - no Add to
    Cart / Buy Now - i.e. nobody is selling it at a normal price right now, only
    third-party sellers (the buy box shows no price of its own)."""
    try:
        soup = get_soup(html, True)
        if not soup.find(id="productTitle"):
            return False
        if soup.find(id="add-to-cart-button") or soup.find(id="buy-now-button"):
            return False
        return _amazon_has_buying_options(soup)
    except Exception:
        return False


def _search_visible_text(soup, scoped=False):
    """Amazon-style specific elements first, then phrases. When the
    product is identified (scoped), only the buy-box area near the title
    is trusted — the whole page is full of OTHER products' stock labels."""
    avail = soup.find(id="availability")
    if avail:
        text = avail.get_text(separator=" ").strip().lower()
        if text:
            if ("unavailable" in text or "out of stock" in text or "out of print" in text
                    or "no longer available" in text or "not available" in text):
                return "OUT_OF_STOCK"
            if "in stock" in text or "available" in text:
                return "IN_STOCK"
    if soup.find(id="add-to-cart-button") or soup.find(id="buy-now-button"):
        return "IN_STOCK"
    if soup.find(id="productTitle") and _amazon_no_real_offer(soup):
        return "OUT_OF_STOCK"
    if _amazon_has_buying_options(soup):
        return "IN_STOCK"
    if soup.find(id="outOfStock") or soup.find(id="outOfStockBuyBox"):
        return "OUT_OF_STOCK"

    region = _buybox_text(soup)
    if not scoped:
        full = re.sub(r"\s+", " ", " ".join(str(s) for s in _visible_strings(soup))).lower()
        r = _phrase_verdict(full)
        if r:
            return r
    if region:
        return _first_verdict(region)
    return None


# -------------------------------------------------------------- the entry

def detect_availability(html: str, hint: str = "") -> str:
    """`hint` is the product's URL; used only to learn its own ID so the
    search inside a retailer's data blob can be limited to this product."""
    r = _detect_availability(html, hint, False)
    if r != "IN_STOCK" and was_capped(html):
        # answered from the short version: trust it only if the buy area was in it
        if r == "UNKNOWN" or not _has_buy_area(get_soup(html, False), hint):
            r = _detect_availability(html, hint, True)
    return r


def _detect_availability(html, hint, full):
    stripped = html.strip()
    if stripped.startswith("{") or stripped.startswith("["):
        try:
            parsed = json.loads(stripped)
        except Exception:
            parsed = None
        if parsed is not None:
            for fn in (_search_rk_sweep, _search_bb_button, _search_target_api_json, _search_shopify_json, _search_bestbuy_api_json):
                result = fn(parsed)
                if result:
                    return result

    product_id = _product_id_from_hint(hint)

    # Fast path (Target / Walmart): when we know the product's own ID and
    # the page carries its data block, read that directly. This skips
    # parsing the whole 300KB page, which is what made every check costly
    # on the CPU - it keeps very frequent checking light.
    if product_id:
        for var_name in ("__TGT_DATA__", "__NEXT_DATA__"):
            if var_name in html:
                blob = _extract_script_var_json(html, var_name)
                if blob:
                    result = _search_embedded_blob(blob, product_id)
                    if result:
                        return result

    soup = get_soup(html, full)

    if "bestbuy.com" in (hint or "").lower():
        r = _bestbuy_button_state(soup)
        if r:
            return r

    for script in soup.find_all("script", type="application/ld+json"):
        try:
            data = json.loads(script.string or "", strict=False)
        except Exception:
            continue
        result = _search_jsonld(data)
        if result:
            return result

    og = soup.find("meta", attrs={"property": re.compile(r"^(?:product|og):availability$", re.I)}) or soup.find("meta", attrs={"name": re.compile(r"^(?:product|og):availability$", re.I)})
    if og and og.get("content"):
        result = _classify(og["content"])
        if result:
            return result

    for tag in soup.find_all(attrs={"itemprop": "availability"}):
        value = tag.get("href") or tag.get("content") or tag.get_text()
        if value:
            result = _classify(value)
            if result:
                return result

    for var_name in ("__TGT_DATA__", "__NEXT_DATA__"):
        if var_name not in html:
            continue
        blob = _extract_script_var_json(html, var_name)
        if blob:
            result = _search_embedded_blob(blob, product_id)
            if result:
                return result

    if "target.com" in (hint or "").lower():
        # Target's plain page does not carry the item's stock (it is filled
        # in later). Its generic "Add to cart" label is shown either way, so
        # it must not be read as stock.
        if "rk-rendered" in html[:40]:
            # A page read by a real browser AFTER its scripts ran: Target then
            # shows its real buy button ("Add to cart") only when the item can
            # be bought online; the un-rendered page shows that label always.
            region = _buybox_text(soup, limit=1500) or ""
            if any(p in region for p in ("out of stock", "sold out", "temporarily out", "not available")):
                return "OUT_OF_STOCK"
            if "add to cart" in region and "ship" in region:
                return "IN_STOCK"
            if "ship" in region and len(html) > 100000:
                return "OUT_OF_STOCK"
            return "UNKNOWN"
        r = _search_visible_text(soup, scoped=bool(product_id))
        return "OUT_OF_STOCK" if r == "OUT_OF_STOCK" else "UNKNOWN"

    if "gamestop.com" in (hint or "").lower():
        r = _gamestop_status(soup)
        return r or "UNKNOWN"

    result = _search_visible_text(soup, scoped=bool(product_id))
    if result:
        return result

    # Amazon, sold out: the page is a complete product page (big, has the
    # product title) but has NO add-to-cart, NO buy-now and NO "buying
    # options" link, and often no "Currently unavailable" sentence at all.
    # Previously that read as UNKNOWN, which hid the moment the item went
    # out of stock and made the timing window much wider than it should be.
    if ("amazon." in (hint or "").lower() and len(html) > 300000
            and soup.find(id="productTitle")
            and not _amazon_has_buying_options(soup)):
        return "OUT_OF_STOCK"

    return "UNKNOWN"


# ------------------------------------------------------------------ price
# Trackers only alert on restocks at (or near) the normal price; the same
# page can show "in stock" from an individual seller at several times that.
# So every IN_STOCK reading also gets a price, and the poller compares it
# with the product's `max_price` in targets.yaml.

_PRICE_RE = re.compile(r"\$\s?(\d{1,3}(?:,\d{3})+(?:\.\d{2})?|\d{1,5}(?:\.\d{2})?)")
_NOT_THE_PRICE = ("save", "starting at", "payments", "/mo", "per month", "was", "list price",
                  "typical", "shipping", "over", "off", "ship")


def _num(v):
    try:
        if isinstance(v, str):
            m = _PRICE_RE.search(v) or re.search(r"(\d[\d,]*\.?\d*)", v)
            v = (m.group(1) if m else v).replace(",", "")
        f = float(v)
        return f if 0.5 < f < 100000 else None
    except Exception:
        return None


def _first_price_in_text(text):
    text = re.sub(r"\$\s?(\d{1,3}(?:,\d{3})*)\s+(\d{2})\b(?!\.)", r"$\1.\2", text or "")   # "$ 449 99" -> "$449.99"
    for m in _PRICE_RE.finditer(text or ""):
        before = (text[max(0, m.start() - 20):m.start()]).lower().rstrip(" :-\u2013")
        if any(before.endswith(w) for w in _NOT_THE_PRICE):
            continue
        p = _num(m.group(1))
        if p:
            return p
    return None


def _walk(o, fn, depth=0):
    if depth > 40:
        return
    if isinstance(o, dict):
        fn(o)
        for v in o.values():
            _walk(v, fn, depth + 1)
    elif isinstance(o, list):
        for v in o:
            _walk(v, fn, depth + 1)


def _price_target_api(parsed):
    try:
        pr = parsed["data"]["product"]["price"]
    except Exception:
        return None
    for k in ("current_retail", "current_retail_min", "formatted_current_price", "reg_retail"):
        p = _num(pr.get(k)) if isinstance(pr, dict) else None
        if p:
            return p
    return None


def _price_walmart_blob(blob, pid):
    nodes = []
    _find_scoped_nodes(blob, pid, nodes)
    found = []

    def look(d):
        cp = d.get("currentPrice")
        if isinstance(cp, dict):
            p = _num(cp.get("price")) or _num(cp.get("priceString"))
            if p:
                found.append(p)
    for n in nodes:
        _walk(n, look)
    return found[0] if found else None


def _price_jsonld(soup):
    for script in soup.find_all("script", type="application/ld+json"):
        try:
            data = json.loads(script.string or "", strict=False)
        except Exception:
            continue
        got = []

        def look(d):
            if str(d.get("@type", "")).lower() == "offer" or "price" in d or "lowPrice" in d:
                for k in ("price", "lowPrice"):
                    if k in d:
                        p = _num(d[k])
                        if p:
                            got.append(p)
        _walk(data, look)
        if got:
            return got[0]
    return None


def _target_page_price(html, hint):
    m = re.search(r"/A-(\d{5,})", hint or "")
    if not m or not html:
        return None
    tcin = m.group(1)
    t = html.replace('\\"', '"')
    best = None
    for mm in re.finditer(r'"tcin"\s*:\s*"?' + tcin + r'\b', t):
        seg = t[mm.start():mm.start() + 6000]
        pm = re.search(r'"current_retail"\s*:\s*([0-9]+(?:\.[0-9]+)?)', seg) or re.search(r'"formatted_current_price"\s*:\s*"\$([0-9][0-9,]*(?:\.[0-9]{2})?)', seg)
        if pm:
            v = _num(pm.group(1))
            if v:
                best = v
                break
    return best


def detect_price(html: str, hint: str = ""):
    """The product's current price in dollars, or None if it cannot be
    read. Store-specific sources first, then generic ones."""
    p = _detect_price(html, hint, False)
    if p is None and was_capped(html):
        p = _detect_price(html, hint, True)
    return p


def detect_price_structured(html, hint=""):
    """v58b: the price ONLY from the page's data fields for the product (store data, JSON-LD, product meta) - never a number found in the
    page text. Used to confirm an unusually low price."""
    try:
        return _detect_price(html, hint, True, text_ok=False)
    except Exception:
        return None


def _detect_price(html, hint, full, text_ok=True):
    try:
        stripped = html.strip()
        if stripped.startswith("{"):
            try:
                parsed = json.loads(stripped)
            except Exception:
                parsed = None
            if parsed is not None:
                if isinstance(parsed, dict) and isinstance(parsed.get("bb_button"), dict):
                    return _num(parsed["bb_button"].get("price"))
                if isinstance(parsed, dict) and isinstance(parsed.get("rk_sweep"), dict):
                    return _num(parsed["rk_sweep"].get("price"))
                p = _price_target_api(parsed)
                if p:
                    return p
                # Best Buy API
                try:
                    items = parsed.get("products") or []
                    if items:
                        p = _num(items[0].get("salePrice") or items[0].get("regularPrice"))
                        if p:
                            return p
                except Exception:
                    pass
        pid = _product_id_from_hint(hint)
        if pid and "__NEXT_DATA__" in html:
            blob = _extract_script_var_json(html, "__NEXT_DATA__")
            if blob:
                p = _price_walmart_blob(blob, pid)
                if p:
                    return p
        if "target.com" in (hint or "").lower():
            # v58: Target's page carries the product's own price in its data ("current_retail") - diagnostics 57 showed $17.00
            # read from somewhere else on the drawn page for a $164.70 box. Use the price that belongs to THIS product number.
            p = _target_page_price(html, hint)
            if p:
                return p
        soup = get_soup(html, full)
        if "amazon." in (hint or "").lower():
            # Only the buy box's own price. The page is full of OTHER
            # products' prices (alternatives, sponsored), so no page-wide search.
            m = re.search(r'desktop_buybox_group_1"\s*:\s*\[\s*\{[^{}]*?"priceAmount"\s*:\s*([0-9]+(?:\.[0-9]+)?)', html, re.I)
            if m:
                p = _num(m.group(1))
                if p:
                    return p
            for sel in ("#corePriceDisplay_desktop_feature_div .a-offscreen", "#corePrice_feature_div .a-offscreen",
                        "#apex_desktop .a-offscreen", "#desktop_buybox .a-price .a-offscreen",
                        "#buybox .a-price .a-offscreen", "#rightCol .a-price .a-offscreen"):
                el = soup.select_one(sel)
                if el:
                    p = _num(el.get_text())
                    if p:
                        return p
            return None
        p = _price_jsonld(soup)
        if p:
            return p
        for prop in ("product:price:amount", "og:price:amount"):
            m = soup.find("meta", attrs={"property": prop})
            if m and m.get("content"):
                p = _num(m["content"])
                if p:
                    return p
        for tag in soup.find_all(attrs={"itemprop": "price"}):
            p = _num(tag.get("content") or tag.get_text())
            if p:
                return p
        if not text_ok:
            return None
        region = _buybox_text(soup, limit=2500)
        if region:
            return _first_price_in_text(region)
    except Exception:
        return None
    return None


def price_clues(html: str, hint: str = "") -> str:
    """When a page looks in stock but no price can be read: a compact note of
    what price-like things ARE on it, so the cause shows up in the log."""
    try:
        soup = get_soup(html, True)
        region = _buybox_text(soup, limit=2500) or ""
        clues = []
        for m in re.finditer(r"\$\s?\d[\d,]*(?:[.\s]\d{2})?", region):
            clues.append(region[max(0, m.start() - 40):m.end() + 20])
            if len(clues) >= 5:
                break
        off = [e.get_text()[:24] for e in soup.select(
            "#corePrice_feature_div .a-offscreen, #corePriceDisplay_desktop_feature_div .a-offscreen, "
            "#buybox .a-offscreen, #rightCol .a-offscreen")[:5]]
        extra = ""
        if "amazon." in (hint or "").lower():
            extra = (f" has_buybox_json={'desktop_buybox_group_1' in html} buying_options={_amazon_has_buying_options(soup)} "
                     f"no_real_offer={_amazon_no_real_offer(soup)}")
        return f"price clues={clues} offscreen={off}{extra} | text: {region[:300]}"
    except Exception as e:
        return f"(could not list price clues: {type(e).__name__})"


_HUMAN_PHRASES = ("robot or human", "activate and hold the button", "press & hold", "press and hold", "verify you are a human", "are you a robot",
                  "make sure you're not a robot", "enter the characters you see below")        # (v64: Amazon's check page too)


def human_check_reason(html: str):
    """None for an ordinary page; for a page asking a person to prove they are human (press-and-hold etc.) a short description
    of what was matched: 'phrase', size and the page's own title. The program never tries to solve these - it slows down.
    A big page that also carries product data is a normal page (its scripts may mention these words)."""
    if not html or len(html) > 60000:
        return None
    lower = html.lower()
    hit = next((p for p in _HUMAN_PHRASES if p in lower), None)
    if hit is None:
        return None
    if len(html) > 25000 and any(m in html for m in ('"availabilityStatus"', "availability_status", "__NEXT_DATA__", "add to cart", "Add to cart", "ADD_TO_CART")):
        return None
    m = re.search(r"<title[^>]*>(.*?)</title>", html, re.I | re.S)
    title = re.sub(r"\s+", " ", m.group(1)).strip()[:60] if m else ""
    return f'matched "{hit}", {len(html):,} characters' + (f', page title "{title}"' if title else "")


def is_human_check_page(html: str) -> bool:
    return human_check_reason(html) is not None


# ------------------------------------------------------------ diagnostics

def _raw_status_snippets(html, limit=4):
    out = []
    for m in re.finditer(r'availability_status|availabilityStatus|OUT_OF_STOCK|IN_STOCK|is_out_of_stock', html):
        s, e = max(0, m.start() - 60), min(len(html), m.end() + 80)
        out.append(re.sub(r"\s+", " ", html[s:e]))
        if len(out) >= limit:
            break
    return out


def explain_blobs(html: str, hint: str = "") -> dict:
    """Evidence about the retailer data blobs on a page: were they found,
    could they be parsed, and what status fields sit inside this
    product's own record. Logged when detection fails, so the next
    diagnostics file shows exactly why instead of leaving a guess."""
    pid = _product_id_from_hint(hint)
    out = {}
    for name in ("__TGT_DATA__", "__NEXT_DATA__"):
        if name not in html:
            continue
        idx = html.find(name)
        info = {"raw_context": re.sub(r"\s+", " ", html[idx:idx + 140]), "product_id": pid}
        data = _extract_script_var_json(html, name)
        info["parsed"] = data is not None
        if data is not None:
            info["top_level"] = list(data.keys())[:10] if isinstance(data, dict) else f"list[{len(data)}]"
            statuses, nodes = [], []
            if pid:
                _find_scoped_nodes(data, pid, nodes)
                for n in nodes:
                    _collect_statuses(n, statuses)
                info["product_records_found"] = len(nodes)
            else:
                _collect_statuses(data, statuses)
            info["status_fields"] = [f"{s}<-{k}" for s, k in statuses][:10]
        out[name] = info
    return out


def diagnose(html: str, hint: str = "") -> dict:
    """Short forensic summary of what a page contained, for when
    detect_availability() returns UNKNOWN. A long page with the real
    product title is the real page, not a block page."""
    if not html:
        return {"length": 0, "note": "empty content"}
    soup = get_soup(html, True)
    jsonld = soup.find_all("script", type="application/ld+json")
    title = soup.title.get_text().strip() if soup.title else None
    og_type = soup.find("meta", attrs={"property": "og:type"})
    region = _buybox_text(soup, limit=500)
    return {
        "length": len(html),
        "title": title,
        "og_type": og_type.get("content") if og_type else None,
        "jsonld_script_count": len(jsonld),
        "embedded_blobs": explain_blobs(html, hint) or None,
        "raw_status_snippets": _raw_status_snippets(html) or None,
        "text_near_title": region[:300] if region else None,
    }
