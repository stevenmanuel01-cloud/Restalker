/* Restalker v58 - reading store pages through the buying browser (read only).
 * Some stores refuse the program's watching browsers (diagnostics 57: Best Buy answered 0 of 93 tries, GameStop often sends nothing).
 * The buying browser is an ordinary browser window that you signed in to, so the store answers it. For such a store this keeps ONE
 * quiet background tab open on the store's own site and asks that tab to fetch a product page or the store's small data request -
 * the same request the store's own page makes. Nothing is clicked or typed; human checks are never answered.
 */
'use strict';
(() => {
  const tabs = {};                       // origin -> {id, at}
  const MAX_AGE = 30 * 60 * 1000;        // the reader tab is opened fresh every 30 minutes
  const stats = {ok: 0, failed: 0, last: null};
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  async function waitComplete(id, ms) {
    const t0 = Date.now();
    while (Date.now() - t0 < ms) {
      try { const t = await chrome.tabs.get(id); if (t.status === 'complete') return true; } catch { return false; }
      await sleep(250);
    }
    return false;
  }
  async function inject(id) {            // v64: the helper is put into the tab directly too (a tab opened before the engine started, or a store page whose own helper answers first)
    try { await chrome.scripting.executeScript({target: {tabId: id}, files: ['rk_fetch.js']}); return true; } catch { return false; }
  }
  async function ensure(origin) {
    const e = tabs[origin];
    if (e) {
      let alive = false;
      try { alive = !!(await chrome.tabs.get(e.id)); } catch {}
      if (alive && Date.now() - e.at < MAX_AGE) { await waitComplete(e.id, 30000); return e.id; }
      try { if (alive) await chrome.tabs.remove(e.id); } catch {}
      delete tabs[origin];
    }
    const t = await chrome.tabs.create({url: origin + '/', active: false});
    tabs[origin] = {id: t.id, at: Date.now()};
    await waitComplete(t.id, 45000);
    await sleep(600);                    // (the store's page settles; its content script is ready)
    await inject(t.id);
    return t.id;
  }
  // v159 - how a request to the store's own DATA address is sent (Target: redsky.target.com, asked from the reader's www.target.com
  // tab). The ladder (owner, 2026-11-25: fastest / best first, a fall-back only on proof, and back by itself):
  //   1. the default is the store's own way: with the browser's cookies for that store ('include').
  //   2. the browser does not allow it (credFail) -> the same request is asked again at once without them, and 'include' rests for
  //      30 minutes (then 1 h ... at most 6 h) before it is tried again.
  //   3. refusals: counted for both ways. 15 or more answers with 1 in 10 refused or more -> the other way is TRIED for 15
  //      answers. Refused at most half as often -> proven: kept for 30 minutes (then 1 h ... at most 8 h), then the default is
  //      tried again. Not clearly better -> back at once, no new trial for 2 hours (then 4 ... at most 24).
  // Nothing is answered, pressed or gone around: it is the same request, with or without the cookies the browser already has.
  const CRED = {};                       // data host -> its state
  const CN = {n: 15, share: 0.1, hold: 30 * 60000, holdMax: 8 * 3600000, quiet: 2 * 3600000, quietMax: 24 * 3600000, cors: 30 * 60000, corsMax: 6 * 3600000};
  const REFUSED = new Set([403, 429, 435, 503]);
  try { chrome.storage.local.get('rkCred').then(x => { const m = x && x.rkCred; if (m && typeof m === 'object') for (const h of Object.keys(m)) CRED[h] = m[h]; }).catch(() => {}); } catch {}
  const credSave = () => { try { void chrome.storage.local.set({rkCred: CRED}); } catch {} };
  function credOf(host) {
    return CRED[host] || (CRED[host] = {mode: 'include', stage: 'default', until: 0, hold: 0, quiet: 0, quietUntil: 0, base: 0, w: {n: 0, ref: 0},
      include: {n: 0, ref: 0}, omit: {n: 0, ref: 0}, cors: 0, corsFor: 0, corsUntil: 0, why: '', trials: 0, proven: 0});
  }
  function credMode(c) { return Date.now() < c.corsUntil ? 'omit' : c.mode; }
  function credTo(c, mode, stage, why, ms) { c.mode = mode; c.stage = stage; c.until = ms ? Date.now() + ms : 0; c.w = {n: 0, ref: 0}; c.why = why; credSave(); }
  function credNote(c, used, refused) {
    c[used].n++; if (refused) c[used].ref++;
    if (used !== c.mode) return credSave();                 // (asked without because the browser did not allow with: not this way's number)
    c.w.n++; if (refused) c.w.ref++;
    const now = Date.now(), sh = c.w.n ? c.w.ref / c.w.n : 0, other = c.mode === 'include' ? 'omit' : 'include', pct = x => Math.round(x * 100) + ' %';
    if (c.stage === 'trial') {
      if (c.w.n >= CN.n || (c.w.n >= 6 && c.w.ref >= 0.8 * c.w.n)) {
        if (c.w.n >= CN.n && sh <= 0.5 * c.base) {
          c.proven++; c.hold = Math.min(CN.holdMax, c.hold ? c.hold * 2 : CN.hold);
          credTo(c, c.mode, 'hold', 'proven: refused ' + pct(sh) + ' of the requests this way, ' + pct(c.base) + ' the default way - kept for ' + Math.round(c.hold / 60000) + ' minutes, then the default is tried again', c.hold);
        } else {
          c.quiet = Math.min(CN.quietMax, c.quiet ? c.quiet * 2 : CN.quiet); c.quietUntil = now + c.quiet;
          credTo(c, 'include', 'cleared', 'not proven: refused ' + pct(sh) + ' of the requests the other way too (' + pct(c.base) + ' the default way) - back to the default; not tried again for ' + Math.round(c.quiet / 3600000) + ' hours', 0);
        }
      }
    } else if (c.stage === 'hold') {
      if (now >= c.until) credTo(c, 'include', 'retry', 'the other way was kept for its time - the default is tried again', 0);
    } else {
      if (c.stage !== 'default' && c.w.n >= 40 && sh < 0.05) { c.hold = 0; c.quiet = 0; c.quietUntil = 0; c.stage = 'default'; c.why = ''; c.w = {n: 0, ref: 0}; }
      else if (c.w.n >= CN.n && sh >= CN.share && now >= c.quietUntil) { c.base = sh; c.trials++; credTo(c, other, 'trial', 'refused ' + c.w.ref + ' of ' + c.w.n + ' requests the default way - the other way is being TRIED for ' + CN.n + ' answers, then judged by the numbers', 0); }
      else if (c.w.n >= 60) { c.w.n = 30; c.w.ref = Math.floor(c.w.ref / 2); }
    }
    credSave();
  }
  function credText(c) {
    return {mode: credMode(c), stage: c.stage, why: c.why, include: c.include, omit: c.omit, cors: c.cors, corsLeftMin: Math.max(0, Math.round((c.corsUntil - Date.now()) / 60000)),
      leftMin: c.until ? Math.max(0, Math.round((c.until - Date.now()) / 60000)) : 0, trials: c.trials, proven: c.proven};
  }
  async function fetchUrl(url, timeoutMs, cookies) {
    timeoutMs = Math.max(3000, Math.min(60000, Number(timeoutMs) || 25000));
    const t0 = Date.now();
    let origin;
    try { const h = new URL(url).hostname; origin = 'https://www.' + h.split('.').slice(-2).join('.'); } catch { return {ok: false, reason: 'not a web address'}; }   // (one tab per store: its main site)
    let id;
    try { id = await ensure(origin); } catch (e) { stats.failed++; return {ok: false, reason: 'reader tab: ' + String(e && e.message || e)}; }
    try { globalThis.RK_JANITOR && globalThis.RK_JANITOR.seen.set(id, Date.now()); } catch {}     // (v90: in use - the tab janitor leaves it)
    let r, host = '', c = null;
    try { host = new URL(url).hostname; if ('https://' + host !== origin) c = credOf(host); } catch {}
    if (c && c.stage === 'hold' && Date.now() >= c.until) credTo(c, 'include', 'retry', 'the other way was kept for its time - the default is tried again', 0);
    let cred = c ? credMode(c) : null;
    for (let i = 0; i < 3; i++) {
      r = await Promise.race([
        chrome.tabs.sendMessage(id, {type: 'RK_FETCH', url, timeoutMs, cookies: cookies || null, cred}).catch(e => ({ok: false, reason: String(e && e.message || e), noScript: true})),
        sleep(timeoutMs + 3000).then(() => ({ok: false, reason: 'no answer in time'}))]);
      if (r && r.noScript && i === 0) { await inject(id); await sleep(500); continue; }       // the page was still loading its helper: put it in, once more
      if (r && r.credFail && c && cred === 'include') {      // the browser did not allow the store's own way: asked again without, at once
        c.cors++; c.corsFor = Math.min(CN.corsMax, c.corsFor ? c.corsFor * 2 : CN.cors); c.corsUntil = Date.now() + c.corsFor; credSave();
        cred = 'omit'; continue;
      }
      break;
    }
    if (c && r && r.ok && (r.sent === 'include' || r.sent === 'omit')) {
      if (r.sent === 'include' && c.corsFor) { c.corsFor = 0; }
      credNote(c, r.sent, REFUSED.has(Number(r.status)) || /\/(blocked|captcha)\b/i.test(String(r.url || '')));
    }
    if (c && r) r = {...r, cred: credText(c)};
    if (!r || (r.noScript)) { try { await chrome.tabs.remove(id); } catch {} delete tabs[origin]; }
    if (r && r.ok) stats.ok++; else stats.failed++;
    stats.last = {url: url.slice(0, 120), ok: !!(r && r.ok), status: r && r.status, reason: r && r.reason, at: Date.now()};
    return {...(r || {ok: false, reason: 'no answer'}), ms: Date.now() - t0};
  }
  function status() {
    return {tabs: Object.fromEntries(Object.entries(tabs).map(([o, e]) => [o, {tab: e.id, ageSec: Math.round((Date.now() - e.at) / 1000)}])), ...stats,
      cred: Object.fromEntries(Object.keys(CRED).map(h => [h, credText(CRED[h])]))};
  }
  globalThis.RestalkerReader = {CODE: 'v160', fetch: fetchUrl, status};
})();
