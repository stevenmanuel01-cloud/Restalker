"""Restalker v160 - price-drop alerts on the PC (owner, 2026-11-24: "price drop alerts on PC").

A watched product that is FOR SALE gets clearly cheaper -> one message (phone / Windows / Discord, as your other messages go). It is an
alert only: nothing is bought by it. The rule is the app's own (the app has had it since 2.12), so a phone and a PC say the same:

  - "clearly cheaper": at least 5 % AND at least $5 below the price it was last measured from (the mark).
  - once alerted, the lower price is the new mark. A price that goes back up does not move the mark for a day - a price that bounces
    between two values alerts once, not every time.
  - a product that is set to Buy and at or under its price limit is bought by itself - no drop alert for it (the purchase message says
    it). The moment a product comes under the limit or back in stock is a RESTOCK message, not a drop: the mark is set there without an
    alert, and only a further drop alerts.
  - sold out: nothing; the next time it is for sale the mark starts afresh.
The marks are kept in price_drop.json (so a restart does not alert again for what it already said). Switch: the page's "Price drops" box.
"""
import json
import os
import threading
import time

VERSION = "v160"
PCT = 0.05
MIN_USD = 5.0
HOLD = 24 * 3600.0
EVERY = 30.0
FRESH = 900.0                # a reading older than this says nothing about the price now
FILE = "price_drop.json"
_lock = threading.Lock()
_st = {"on": True, "marks": {}, "alerts": 0, "last": "", "scans": 0, "loaded": False, "dirty": False}


def _load():
    if _st["loaded"]:
        return
    _st["loaded"] = True
    try:
        d = json.load(open(FILE, encoding="utf-8"))
        _st["on"] = d.get("on") is not False
        _st["marks"] = {str(k): v for k, v in (d.get("marks") or {}).items() if isinstance(v, dict)}
    except Exception:
        pass


def _save():
    try:
        tmp = FILE + ".tmp"
        json.dump({"on": _st["on"], "marks": _st["marks"]}, open(tmp, "w", encoding="utf-8"))
        os.replace(tmp, FILE)
    except Exception:
        pass


def is_on():
    _load()
    return bool(_st["on"])


def set_on(on):
    _load()
    with _lock:
        _st["on"] = bool(on)
        _save()
    return _st["on"]


def check(ref, ref_at, price, now):
    """-> (alert now?, the new mark, the new mark's time)."""
    if price is None or price <= 0:
        return False, ref, ref_at
    if ref is None or ref <= 0:
        return False, price, now                         # (the first price seen: the mark, no alert)
    drop = ref - price
    if drop >= MIN_USD and drop >= ref * PCT:
        return True, price, now
    if price > ref and now - ref_at >= HOLD:
        return False, price, now                         # (higher for over a day: measured from there)
    return False, ref, ref_at


def _buys(t):
    try:
        import amazon_buy as ab
        u = t.get("url") or ""
        if ab._is_amazon(u):
            a = ab.asin_of(u)
            return bool(a and ab.wanted(a))
        if ab._is_bestbuy(u):
            return bool(ab.wanted("bb:" + str(t.get("id"))))
    except Exception:
        pass
    return False


def scan(rows, status, now=None, alert=None, buys=None):
    """One pass over the table. rows: the table's rows; status(id) -> {"status", "price", "checked_at", "high_price"}.
    alert(row, was, price, state) is called for each clear drop ("in" = at or under the price limit, "over" = for sale over it). -> alerts."""
    _load()
    now = time.time() if now is None else now
    buys = buys or _buys
    n = 0
    with _lock:
        _st["scans"] += 1
        marks = _st["marks"]
        live = set()
        for t in rows:
            tid = str(t.get("id") or "")
            if not tid or t.get("enabled") is False:
                continue
            live.add(tid)
            r = status(tid) or {}
            try:
                price = float(r.get("price")) if r.get("price") is not None else None
            except Exception:
                price = None
            st = r.get("status")
            if now - float(r.get("checked_at") or 0) > FRESH:
                continue
            state = "in" if st == "IN_STOCK" else "over" if (st == "OUT_OF_STOCK" and r.get("high_price") and price) else "out" if st == "OUT_OF_STOCK" else ""
            m = marks.get(tid) or {}
            if state == "out":
                if m.get("st"):
                    m["st"] = ""
                    marks[tid] = m
                    _st["dirty"] = True
                continue
            if state not in ("in", "over") or not price or price <= 0:
                continue
            if state == "in" and (buys(t) or m.get("st") != "in"):
                if m.get("ref") != price or m.get("st") != "in":
                    marks[tid] = {"ref": price, "at": now, "st": "in"}
                    _st["dirty"] = True
                continue
            go, mark, at = check(m.get("ref"), float(m.get("at") or 0), price, now)
            was = m.get("ref")
            if mark != m.get("ref") or at != m.get("at") or m.get("st") != state:
                marks[tid] = {"ref": mark, "at": at, "st": state}
                _st["dirty"] = True
            if go and _st["on"] and alert is not None:
                n += 1
                _st["alerts"] += 1
                _st["last"] = f"{time.strftime('%m-%d %H:%M', time.localtime(now))} {tid}: ${price:.2f} (was ${was:.2f})"
                try:
                    alert(t, was, price, state)
                except Exception:
                    pass
        for k in [k for k in marks if k not in live]:
            del marks[k]                                  # (a row that is gone)
            _st["dirty"] = True
        if _st["dirty"]:
            _st["dirty"] = False
            _save()
    return n


def words(store, name, was, price, state, cap, buys):
    """The message: (title, text)."""
    money = lambda v: f"${float(v):,.2f}"
    title = f"PRICE DROP - {store} - {name}: {money(price)} (was {money(was)})"
    if state == "in":
        text = (f"At or under your price limit of {money(cap)}. " if cap else "") + ("It is set to Buy." if buys else "It is NOT set to Buy - choose Buy in Restalker to buy it.")
    elif cap:
        text = f"Still over your price limit of {money(cap)} - nothing is bought. Raise the limit in Restalker if you want it at this price."
    else:
        text = "Watching only - no price limit is set."
    return title, text


def start(log, rows, status, describe, send):
    """describe(id) -> {"store", "product", "cap", "url"}; send(title, text, key, link)."""
    _load()

    def alert(t, was, price, state):
        d = describe(t["id"]) or {}
        title, text = words(d.get("store") or "store", d.get("product") or t.get("id"), was, price, state, d.get("cap"), _buys(t))
        log(f"[price drop] {title}. {text}")
        send(title, text, f"drop-{t['id']}-{int(price * 100)}", d.get("url") or t.get("url"))

    def loop():
        time.sleep(90)                                    # (the first readings after a start come in)
        while True:
            try:
                scan(rows(), status, alert=alert)
            except Exception as e:
                log(f"[price drop] the price check failed once: {str(e)[:120]}")
            time.sleep(EVERY)
    threading.Thread(target=loop, daemon=True, name="price-drop").start()


def report_text():
    _load()
    return (f"price-drop alerts (v160): {'ON' if _st['on'] else 'OFF (the page, Price drops)'}; a watched product for sale that gets at least 5 % and $5 cheaper -> one message "
            f"(nothing is bought by it); products with a price mark: {len(_st['marks'])}; alerts sent {_st['alerts']}" + (f", last: {_st['last']}" if _st["last"] else "")
            + f"; checks {_st['scans']}")
